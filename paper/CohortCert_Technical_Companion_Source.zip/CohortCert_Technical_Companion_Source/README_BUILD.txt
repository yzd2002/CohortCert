CohortCert Technical Companion v12: 22 pages, including the complete 23-execution runtime figure.
Compile technical_companion.tex with pdfLaTeX, BibTeX, pdfLaTeX twice.
This is separate public supplementary material, not an appendix in the submitted main PDF.
The six current figure sources and frozen plotting inputs are in the main LaTeX ZIP under figure_source/.
