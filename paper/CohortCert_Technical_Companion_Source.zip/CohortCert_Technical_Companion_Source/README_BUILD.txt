Separate online technical companion. Compile technical_companion.tex with pdflatex, bibtex, then pdflatex twice. All required bibliography and the included metadata figure are provided. The frozen method/experimental-parameter source texts match the preceding ten-author version byte for byte; only this wrapper uses the current nine-author list. This supplement is not appended to the main submission PDF.

Revision v6 clarifies that 20 pseudo-observations are added to Beta(1,1), giving concentration 22. No parameter changed. The AI declaration matches the main paper.
