CohortCert / v10 / Overleaf修正版

主文件：main.tex；编译器：pdfLaTeX。
main.tex首行现在直接声明documentclass；preamble.tex仅包含宏包和定义；frontmatter.tex包含原作者和标题信息。
本版摘要严格使用用户提供的新文本，1540字符。其他正文、八位作者、共同一作/通讯角色、实验数值和AI声明均不改。

导入方式：将ZIP作为新项目上传；或者将ZIP解压后全部文件上传到现有项目并覆盖同名文件（包括新增frontmatter.tex）。
File → Settings → Compiler：Main document选main.tex，Compiler选pdfLaTeX。
点击Recompile旁下拉菜单，选择Recompile from scratch。若当前界面没有该项，先Clear cached files，再Recompile。

本地编译：pdflatex main.tex → bibtex main → pdflatex main.tex（两次）。
投稿：更改CMT的Abstract并替换上传PDF；本文没有代登录CMT或修改在线Overleaf。

Revision v10: IEEEtran small-cap heading style retained; all section/subsection titles use consistent title case and shorter noun phrases. Section III is Adaptive Sampling and Cost Analysis. Introduction and method/result roadmaps clarify the execution order. The user-provided 1540-character abstract, eight author roles, AI declaration, seven displayed formula groups and empirical results are preserved.
