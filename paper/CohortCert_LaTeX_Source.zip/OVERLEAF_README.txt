CohortCert v12｜矢量图与统一表格版

将整个ZIP作为新项目上传Overleaf。Main document选择main.tex，Compiler选择pdfLaTeX；选择Recompile from scratch。
main.tex位于根目录，首行直接声明documentclass；preamble.tex为宏包定义，frontmatter.tex为作者信息。
本地编译：pdflatex main.tex；bibtex main；pdflatex main.tex（两次）。
PDF图已包含，不需要安装Python或运行绘图代码才能编译论文。figure_source/是额外提供的绘图源码、冻结输入和可编辑SVG。
正文12页，总14页（含参考文献与单段AI声明）；八位作者、前四位共同一作，郑杰鑫与王聪共同通讯。
本版重绘六幅矢量图、统一正文及Technical Companion的15张表格；实验结果、七组显示公式和用户指定摘要不变。
所有历史原始证据包保持不变；当前图形外观以本源码包为准。仅CMT的主PDF和Q8需要更新；如仍为旧摘要，也替换Abstract。
本地材料更新不代表在线Overleaf或CMT已保存；请在现有Paper ID 1734核对并保存更新。
