"""CohortCert v12: vector displays of unchanged, frozen public plotting values.

Run: python redraw_figures.py --inputs figure_inputs --out figures
No model, acquisition policy, solver, bootstrap or raw outcome collector is run.
"""
from pathlib import Path
import argparse, csv, hashlib, itertools, json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, Ellipse, FancyBboxPatch, FancyArrowPatch, PathPatch, Patch
from matplotlib.path import Path as MPath
from matplotlib.lines import Line2D
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.text import Text

NAVY="#20334A"; GRAY="#788391"; LIGHT="#E5EAF0"
BLUE="#437BB6"; TEAL="#168574"; VIOLET="#7964AD"; AMBER="#B97828"
COLORS={"dual_greedy":TEAL,"width":VIOLET,"neyman":BLUE,"matched":GRAY,"forecast":AMBER,"boundary":"#A06080"}
NAMES={"dual_greedy":"DifficultyGreedy","width":"WidthGreedy","neyman":"VarianceGreedy","matched":"Matched","forecast":"Forecast","boundary":"Boundary"}
STYLES={"dual_greedy":"-","width":(0,(4,2)),"neyman":(0,(4,1,1,1)),"matched":(0,(1,1.8)),"forecast":(0,(6,2))}
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":8,"axes.labelsize":8,
 "axes.titlesize":8.7,"axes.titleweight":"semibold","axes.titlelocation":"left",
 "xtick.labelsize":7.4,"ytick.labelsize":7.4,"legend.fontsize":7.4,
 "text.color":NAVY,"axes.labelcolor":NAVY,"xtick.color":NAVY,"ytick.color":NAVY,
 "axes.edgecolor":"#A1ABB6","axes.linewidth":.6,"pdf.fonttype":42,"ps.fonttype":42,
 "svg.fonttype":"none","svg.hashsalt":"CohortCert-v12","mathtext.fontset":"dejavusans",
 "savefig.facecolor":"white","hatch.linewidth":.55})
CHECKS={}
def read(name):return json.loads((INPUT/name).read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(fig,name,check):
 fig.canvas.draw()
 alltext=[t for t in fig.findobj(Text) if t.get_visible() and t.get_text()]
 bb=fig.bbox
 outside=[]
 for t in alltext:
  # Only visible text tied to an axis/figure; unused tick artists are not drawn.
  if t.axes and not t.axes.get_visible():continue
  b=t.get_window_extent(fig.canvas.get_renderer())
  if b.x0 < bb.x0-2 or b.y0 < bb.y0-2 or b.x1 > bb.x1+2 or b.y1 > bb.y1+2:
   outside.append(t.get_text())
 for ext in ("pdf","svg","png"):
  fig.savefig(OUT/(name+"."+ext),dpi=320,metadata={"Creator":"CohortCert vector display revision v12"} if ext=="pdf" else None)
 CHECKS[name]={**check,"size_inches":list(fig.get_size_inches()),"minimum_text_pt":min(t.get_fontsize() for t in alltext),
  "text_outside_canvas":outside,"outputs":{ext:sha(OUT/(name+"."+ext)) for ext in ("pdf","svg","png")}}
 plt.close(fig)
def style(ax,grid="y"):
 ax.spines[["top","right"]].set_visible(False);ax.set_axisbelow(True)
 ax.grid(axis=grid,color=LIGHT,lw=.55)
 ax.tick_params(length=2.5,width=.55,pad=3)
def label(ax,x,y,s,size=8,ha="left",weight="normal",color=NAVY,**kw):
 return ax.text(x,y,s,fontsize=size,ha=ha,va="center",weight=weight,color=color,**kw)
def box(ax,x,y,w,h,fill="#F3F6F9",edge="none",radius=.035,lw=.6):
 p=FancyBboxPatch((x,y),w,h,boxstyle=f"round,pad=0,rounding_size={radius}",facecolor=fill,edgecolor=edge,lw=lw)
 ax.add_patch(p);return p
def arrow(ax,a,b,color=GRAY,lw=.85):
 ax.add_patch(FancyArrowPatch(a,b,arrowstyle="-|>",mutation_scale=7,lw=lw,color=color,shrinkA=0,shrinkB=0))
def document(ax,x,y,color):
 verts=[(x,y),(x+.105,y),(x+.105,y+.14),(x+.073,y+.177),(x,y+.177),(x,y)]
 ax.add_patch(PathPatch(MPath(verts),facecolor="white",edgecolor=color,lw=.7))
 ax.plot([x+.073,x+.073,x+.105],[y+.177,y+.14,y+.14],color=color,lw=.7)
 for yy in (.043,.079,.112):ax.plot([x+.023,x+.080],[y+yy,y+yy],color=color,lw=.6)

def mechanism():
 fig=plt.figure(figsize=(7.16,2.56))
 ax=fig.add_axes([0,0,1,1]);ax.set(xlim=(0,7.16),ylim=(0,2.56));ax.axis("off")
 for x,title in [(.06,"Overlapping groups"),(2.48,"Shared evidence"),(4.94,"Supported answers")]:
  label(ax,x,2.44,title,9.1,weight="bold")
 label(ax,.06,2.25,"Comments with unknown labels",7.3,color=GRAY)
 label(ax,2.48,2.25,"Combine the shared contribution first",7.3,color=GRAY)
 label(ax,4.94,2.25,"One request, three questions",7.3,color=GRAY)
 arrow(ax,(2.21,2.43),(2.39,2.43));arrow(ax,(4.68,2.43),(4.86,2.43))
 # One shared region, colored once and reused in the count bounds.
 c1=Ellipse((.76,1.53),1.37,1.03,fc="#EAF1FB",ec=BLUE,lw=.95)
 c2=Ellipse((1.45,1.53),1.37,1.03,fc="#EAF6F3",ec=TEAL,lw=.95)
 ax.add_patch(c1);ax.add_patch(c2)
 shared=Ellipse((.76,1.53),1.37,1.03,fc="#E8E0F2",ec="none");shared.set_clip_path(c2);ax.add_patch(shared)
 ax.add_patch(Ellipse((.76,1.53),1.37,1.03,fc="none",ec=BLUE,lw=.95))
 label(ax,.61,2.14,"A: 100",7.7,ha="center",weight="bold",color=BLUE)
 label(ax,1.59,2.14,"B: 80",7.7,ha="center",weight="bold",color=TEAL)
 for x,col in [(.47,BLUE),(.66,BLUE),(1.05,VIOLET),(1.52,TEAL),(1.71,TEAL)]:document(ax,x,1.65,col)
 for x,n,t,col in [(.57,"80","A only",BLUE),(1.105,"20","Shared",VIOLET),(1.65,"60","B only",TEAL)]:
  label(ax,x,1.46,n,11,ha="center",weight="bold")
  label(ax,x,1.26,t,7.6,ha="center",color=col)
 label(ax,1.105,.94,"Label once, reuse",7.6,ha="center",weight="bold",color=VIOLET)
 label(ax,.06,.81,"Ranges for total positive counts",7.15,color=GRAY)
 for x,s,col,fc in [(.06,r"$K_1\in[40,48]$",BLUE,"#EAF1FB"),(.81,r"$K_2\in[8,12]$",VIOLET,"#EEE8F5"),(1.56,r"$K_3\in[20,24]$",TEAL,"#EAF6F3")]:
  box(ax,x,.53,.70,.21,fill=fc)
  label(ax,x+.35,.635,s,7.35,ha="center",color=col)
 label(ax,3.55,2.00,r"$\theta=K_1/100-K_2/400-K_3/80$",8.0,ha="center")
 label(ax,3.55,1.81,r"$\theta=\mathrm{rate}(A)-\mathrm{rate}(B)$",7.6,ha="center",color=GRAY)
 def xx(v):return 2.63+v/25*1.97
 for name,lo,hi,y,col in [("Separate rate bounds",3,25,1.45,GRAY),("Shared count bounds",7,21,1.04,VIOLET)]:
  label(ax,2.48,y+.21,name,7.4,weight="semibold",color=col)
  ax.plot([xx(lo),xx(hi)],[y,y],color=col,lw=2.1,solid_capstyle="butt")
  ax.plot([xx(lo),xx(lo)],[y-.045,y+.045],color=col,lw=1.1)
  ax.plot([xx(hi),xx(hi)],[y-.045,y+.045],color=col,lw=1.1)
  label(ax,xx(lo),y+.09,str(lo),7.2,ha="center",color=col)
  label(ax,xx(hi),y+.09,str(hi),7.2,ha="center",color=col)
 ax.plot([xx(0),xx(25)],[.88,.88],color=GRAY,lw=.6)
 for v in range(0,26,5):
  ax.plot([xx(v),xx(v)],[.88,.85],color=GRAY,lw=.6)
  label(ax,xx(v),.775,str(v),7.0,ha="center")
 label(ax,3.61,.65,"Rate difference (percentage points)",7.0,ha="center")
 # Single highlighted mathematical consequence.
 box(ax,2.67,.40,1.77,.17,fill="#EEE8F5")
 label(ax,3.555,.485,r"$\theta\in[0.07,0.21]$",8.1,ha="center",weight="bold",color=VIOLET)
 rows=[(1.86,"More than 5 points higher?","True",TEAL),(1.46,"Less than 6 points higher?","False",TEAL),(1.06,"Within 10 points?","Unresolved",AMBER)]
 for y,q,status,col in rows:
  box(ax,4.94,y-.15,2.15,.31,fill="#F1F6F6" if status!="Unresolved" else "#FAF4E8")
  label(ax,5.025,y+.04,q,7.3)
  label(ax,7.00,y-.075,status,7.6,ha="right",weight="bold",color=col)
  # A check denotes a supported assertion; false is not an error.
  if status!="Unresolved":
   ax.plot([6.46,6.485,6.535],[y-.075,y-.105,y-.045],color=TEAL,lw=.9)
 label(ax,6.015,.715,"2 of 3 supported",7.7,ha="center",weight="bold",color=AMBER)
 label(ax,6.015,.51,"Request remains incomplete",7.6,ha="center")
 # Four actions, one feedback loop. No prediction is depicted as evidence.
 nodes=[(.14,1.49,"Choose next records"),(1.98,1.28,"Obtain labels"),(3.60,1.60,"Update count ranges"),(5.53,1.47,"Check all questions")]
 for x,w,t in nodes:
  box(ax,x,.16,w,.19,fill="#F3F5F8",edge="#B9C2CD",radius=.035,lw=.6)
  label(ax,x+w/2,.255,t,7.2,ha="center")
 for i in range(3):arrow(ax,(nodes[i][0]+nodes[i][1]+.04,.255),(nodes[i+1][0]-.05,.255),lw=.7)
 ax.plot([6.265,6.265,4.73],[.16,.05,.05],color=GRAY,lw=.65)
 ax.plot([2.46,.885,.885],[.05,.05,.13],color=GRAY,lw=.65)
 arrow(ax,(.885,.11),(.885,.15),lw=.65)
 label(ax,3.595,.05,"If unresolved and budget remains",7.0,ha="center",color=GRAY)
 save(fig,"fig_main_v2",{"scope":"Illustrative interval arithmetic; not empirical savings",
  "cohort_sizes":[100,80],"disjoint_counts":[80,20,60],"total_positive_ranges":[[40,48],[8,12],[20,24]],
  "separate_difference":[.03,.25],"shared_difference":[.07,.21],"answers":["true","false","unresolved"]})

def overlap():
 d=read("figure_metadata_numbers.json");a=np.array(d["intersection_counts"]);counts=np.array(d["degree_counts"])
 assert a.shape==(8,8) and counts.sum()==30000 and d["multi_membership_rows"]==8767
 labels=["Male","Female","LGBTQ","Christian","Muslim","Other religions","Black","White"]
 fig=plt.figure(figsize=(7.16,2.55));ax=fig.add_axes([.134,.25,.37,.61]);bx=fig.add_axes([.64,.25,.345,.61])
 cmap=LinearSegmentedColormap.from_list("cohort",["#F0F5F9","#AECADC","#4D8FA6","#1C4F68"])
 # pcolormesh, not imshow: all heatmap cells remain vector polygons.
 ax.pcolormesh(np.arange(9)-.5,np.arange(9)-.5,a,cmap=cmap,vmin=0,vmax=10000,edgecolors="white",linewidth=.55,rasterized=False)
 ax.invert_yaxis();ax.set_aspect("equal")
 for i in range(8):
  for j in range(8):ax.text(j,i,f"{a[i,j]/1000:.1f}",ha="center",va="center",fontsize=7.05,color="white" if a[i,j]>5500 else NAVY)
 ax.set_xticks(range(8),labels,rotation=38,ha="right",fontsize=7.05);ax.set_yticks(range(8),labels,fontsize=7.2)
 ax.tick_params(length=0,pad=3)
 for spine in ax.spines.values():spine.set_visible(False)
 ax.set_title("(a) Cohort intersections",pad=13,loc="left")
 fig.text(.137,.868,"Counts in thousands",fontsize=7.2,color=GRAY)
 bx.bar(range(1,9),counts/30000*100,width=.64,color=[GRAY]+[TEAL]*7,zorder=3)
 for k,c in enumerate(counts):bx.text(k+1,c/30000*100+1.4,f"{c:,}",ha="center",fontsize=7.1,color=NAVY)
 bx.set(xlim=(.45,8.55),ylim=(0,82),xticks=range(1,9),yticks=[0,20,40,60,80],xlabel="Cohort memberships per comment",ylabel="Records (%)")
 bx.set_title("(b) Multiple membership",pad=13,loc="left");style(bx)
 bx.text(.99,.91,"8,767 / 30,000\nbelong to ≥2 cohorts",transform=bx.transAxes,ha="right",va="top",fontsize=7.5,color=TEAL)
 save(fig,"fig_natural_overlap_v2",{"scope":"Frozen metadata only","numbers_sha256":sha(INPUT/"figure_metadata_numbers.json"),"counts":counts.tolist(),"intersection_matrix":a.tolist(),"all_vector_heatmap":True})

def completion():
 d=read("FIGURE_DATA_V3.json")["completion"]
 fig,axes=plt.subplots(1,3,figsize=(7.16,2.37),sharex=True,sharey=True)
 for ax,(ctx,title) in zip(axes,[("civil_human","(a) CivilComments · crowd"),("civil_model","(b) CivilComments · model"),("go","(c) GoEmotions · crowd")]):
  for m in ["matched","forecast","neyman","width","dual_greedy"]:
   if m not in d[ctx]:continue
   row=d[ctx][m];assert row["n"]==4640
   ax.step(row["x"],row["cumulative_percent"],where="post",color=COLORS[m],ls=STYLES[m],lw=1.55 if m=="dual_greedy" else 1.05,label=NAMES[m])
  ax.set_title(title,pad=7,fontsize=8.2);style(ax)
  ax.set(xlim=(0,1),ylim=(0,100),xticks=[0,.25,.5,.75,1],yticks=[0,25,50,75,100])
  ax.set_xticklabels(["0",".25",".50",".75","1"])
  ax.set_xlabel("Used fraction of the 50% cap",fontsize=7.8)
 axes[0].set_ylabel("Correct complete requests (%)",fontsize=8)
 handles=[Line2D([0],[0],color=COLORS[m],ls=STYLES[m],lw=1.55 if m=="dual_greedy" else 1.05,label=NAMES[m]) for m in ["dual_greedy","width","neyman","matched","forecast"]]
 fig.legend(handles=handles,ncol=5,loc="upper center",bbox_to_anchor=(.525,1.01),frameon=False,handlelength=2.1,columnspacing=1.1)
 fig.subplots_adjust(left=.085,right=.99,top=.77,bottom=.22,wspace=.18)
 save(fig,"fig_completion_v3",{"contexts":{k:{m:{"n":v["n"],"correct":v["correct"]} for m,v in z.items()} for k,z in d.items()},"all_13_curves_preserved":True,"zero_to_100_y_axis":True,"x_y_values_unchanged":True})

def mechanisms():
 d=read("FIGURE_DATA_V3.json")
 fig=plt.figure(figsize=(7.16,2.42));a=fig.add_axes([.135,.24,.245,.54]);b=fig.add_axes([.48,.24,.218,.54]);c=fig.add_axes([.775,.24,.218,.54])
 a.set_title("(a) Across decisions",pad=9,fontsize=8.3)
 for y,r in enumerate(d["mechanism_effects"]):
  v=r["DG_minus_control_completion_pp"];lo,hi=r["completion_pp_seed_block_95_percentile"]
  a.errorbar(v,y,xerr=[[v-lo],[hi-v]],fmt="o",color=TEAL,ms=4,capsize=3,elinewidth=1.3,capthick=.9,zorder=3)
  a.text(v,y-.27,f"{v:+.2f}",ha="center",fontsize=7.5,color=TEAL,weight="semibold")
 a.axvline(0,color=GRAY,ls=(0,(2,2)),lw=.8);style(a,"x")
 a.set(xlim=(-.22,2.12),ylim=(2.55,-.55),yticks=[0,1,2],xticks=[0,1,2],xlabel="Completion difference (pp)")
 a.set_yticklabels(["Civil crowd","Civil model","GoEmotions"],fontsize=7.2)
 totals={}
 for ax,src,title in [(b,"human","(b) Crowd overlap"),(c,"model","(c) Model overlap")]:
  rows=d["oracle_ledger"][src];finite=[r for r in rows if r["uncoupled_lower_total"] is not None];assert len(rows)==96
  totals[src]={"total":96,"finite":len(finite),"certified":sum(r["certified_strict_extra_proof_cost"] for r in rows)}
  for flag,color,marker,area in [(False,"#B4BEC8","o",10),(True,AMBER,"D",16)]:
   rr=[r for r in finite if r["certified_strict_extra_proof_cost"]==flag]
   ax.scatter([r["signed_upper_total"]/r["support_size"] for r in rr],[r["uncoupled_lower_total"]/r["support_size"] for r in rr],s=area,c=color,marker=marker,alpha=.9,edgecolors="white",linewidths=.25,zorder=3 if flag else 2)
  # Same axes for both references; all points retained, no zoomed-in advantage.
  ax.plot([0,1.04],[0,1.04],ls=(0,(3,2)),color=GRAY,lw=.7)
  ax.set(xlim=(0,1.04),ylim=(0,1.04),xticks=[0,.5,1],yticks=[0,.5,1],xlabel="Signed upper / support")
  ax.set_aspect("equal",adjustable="box");style(ax,"both")
  ax.set_ylabel("Separate lower / support",fontsize=7.5,labelpad=2)
  ax.set_title(title,pad=9,fontsize=8.3)
  ax.text(.035,.96,f'{totals[src]["certified"]}/96 certified',transform=ax.transAxes,va="top",fontsize=7.3,color=AMBER,weight="semibold")
 fig.legend(handles=[Line2D([0],[0],marker="o",color="none",markerfacecolor="#B4BEC8",markeredgecolor="white",markersize=4,label="Inconclusive"),
  Line2D([0],[0],marker="D",color="none",markerfacecolor=AMBER,markeredgecolor="white",markersize=4,label="Strict cost increase")],
  loc="upper center",bbox_to_anchor=(.72,1.015),ncol=2,frameon=False,handletextpad=.3,columnspacing=1.2)
 fig.text(.135,.91,"Sum vs. maximum gain",fontsize=7.3,color=GRAY)
 save(fig,"fig_mechanisms_v3",{"cases":totals,"error_intervals_unchanged":True,"all_finite_points_preserved":True,"common_scatter_axes":[0,1.04]})

def oracle():
 d=read("ORACLE_PLOT_DATA.json")["plotted_data"]
 fig,axes=plt.subplots(1,2,figsize=(7.16,2.30),sharex=True,sharey=True)
 for ax,src,title in zip(axes,["human","model"],["(a) CivilComments · crowd","(b) CivilComments · model"]):
  r=d[src];assert r["denominator"]==96
  x=np.array(r["fraction_call_cap"])*100
  lo=np.array(r["oracle_completion_lower"])*100;hi=np.array(r["oracle_completion_upper"])*100
  ax.fill_between(x,lo,hi,step="post",color="#E1D9EF",alpha=1,label="Verified cost-bound band")
  ax.step(x,lo,where="post",color=VIOLET,lw=.7);ax.step(x,hi,where="post",color=VIOLET,lw=.7)
  for m in ["matched","forecast","dual_greedy"]:
   ax.step(x,np.array(r["method_completion_fractions"][m])*100,where="post",color=COLORS[m],ls=STYLES[m],lw=1.5 if m=="dual_greedy" else 1.05,label=NAMES[m])
  style(ax);ax.set(xlim=(0,100),ylim=(0,100),xticks=[0,25,50,75,100],yticks=[0,25,50,75,100],xlabel="Declared call cap used (%)")
  ax.set_title(title,pad=7,fontsize=8.5)
 axes[0].set_ylabel("Selected cases complete (%)")
 hs=[Patch(fc="#E1D9EF",ec=VIOLET,lw=.6,label="Verified cost-bound band")]+[Line2D([0],[0],color=COLORS[m],ls=STYLES[m],lw=1.3,label=NAMES[m]) for m in ["dual_greedy","matched","forecast"]]
 fig.legend(handles=hs,loc="upper center",bbox_to_anchor=(.53,1.025),ncol=4,frameon=False,columnspacing=1.0,handlelength=1.8)
 fig.subplots_adjust(left=.085,right=.973,top=.77,bottom=.23,wspace=.18)
 save(fig,"fig_oracle_v2",{"denominator_per_reference":96,"entire_cost_band_and_policy_arrays_unchanged":True,"band_is_not_statistical_CI":True})

def runtime():
 with (INPUT/"source_planned_units_23.csv").open() as f:rows=list(csv.DictReader(f))
 assert len(rows)==23
 for r in rows:
  r["seconds"]=float(r["query_wall_ms"])/1000;r["ok"]=r["source_proof_valid_correct_complete"]=="True"
  r["exclusion"]=r["source_cell_noncoverage"]=="True"
 warm=[r for r in rows if r["phase"]=="warm"];cold=[r for r in rows if r["phase"]=="cold"]
 fig,axes=plt.subplots(2,1,figsize=(7.16,4.45),gridspec_kw={"height_ratios":[1.8,1]})
 pos=0;marks=[]
 for q,gg in itertools.groupby(warm,key=lambda r:r["query_id"]):
  group=list(gg);xs=[]
  for r in group:
   axes[0].bar(pos,r["seconds"],width=.77,color=COLORS[r["method"]],ec="white" if r["ok"] else NAVY,lw=.45,hatch=None if r["ok"] else "///",zorder=3)
   xs.append(pos);pos+=1
  name=q.replace("civilcomments-","").replace("identity_attack","identity attack").replace("-","\n")
  if any(r["exclusion"] for r in group):name+="†"
  marks.append((np.mean(xs),name,xs[-1]));pos+=.65
 axes[0].set_xticks([x[0] for x in marks],[x[1] for x in marks],fontsize=7.1)
 for x in marks[:-1]:axes[0].axvline(x[2]+.825,color=LIGHT,lw=.55)
 axes[0].set(xlim=(-.7,pos-.8),ylim=(0,280),ylabel="Warm query time (s)")
 axes[0].set_title("(a) All 20 warm executions",pad=8)
 for i,r in enumerate(cold):
  parent=float(r["cold_parent_process_wall_ms"])/1000
  axes[1].bar(i,r["seconds"],width=.58,color=COLORS[r["method"]],ec="white",lw=.5,zorder=3)
  axes[1].bar(i,parent-r["seconds"],bottom=r["seconds"],width=.58,color="#D9DEE6",ec="white",lw=.5,zorder=3)
 axes[1].set_xticks(range(3),[NAMES[r["method"]]+"†" for r in cold])
 axes[1].set(ylim=(0,90),ylabel="Fresh-process time (s)")
 axes[1].set_title("(b) All 3 fresh-process executions",pad=8)
 axes[1].legend(handles=[Patch(fc="#D9DEE6",label="Time outside query")],frameon=False,loc="upper right")
 for ax in axes:style(ax);ax.tick_params(axis="x",length=0,pad=4)
 hs=[Patch(fc=COLORS[m],label=NAMES[m]) for m in ["dual_greedy","matched","forecast","boundary"]]
 hs += [Patch(fc="white",ec=NAVY,hatch="///",label="Unresolved at cap"),Patch(fc="none",ec="none",label="† Shared count exclusion")]
 fig.legend(handles=hs,ncol=3,loc="upper center",bbox_to_anchor=(.54,1.0),frameon=False,columnspacing=1.2,handlelength=1.3)
 fig.subplots_adjust(left=.10,right=.99,top=.835,bottom=.085,hspace=.65)
 save(fig,"fig_runtime_v2",{"warm":20,"fresh_process":3,"unresolved_indexes":[int(r["index"]) for r in warm if not r["ok"]],
  "exclusion_indexes":[int(r["index"]) for r in rows if r["exclusion"]],"all_original_observations_preserved":True})

if __name__=="__main__":
 p=argparse.ArgumentParser(description=__doc__);p.add_argument("--inputs",type=Path,required=True);p.add_argument("--out",type=Path,required=True);args=p.parse_args()
 INPUT=args.inputs.resolve();OUT=args.out.resolve();OUT.mkdir(parents=True,exist_ok=True)
 provenance=read("PROVENANCE.json")
 for row in provenance["files"]:assert sha(INPUT/row["name"])==row["sha256"]
 for fn in (mechanism,overlap,completion,mechanisms,oracle,runtime):fn()
 (OUT/"DISPLAY_VALIDATION.json").write_text(json.dumps({"scope":"Display-only v12 revision","method_executions":0,"raw_outcomes_read":False,"all_text_searchable_in_vector_PDF":True,
  "input_provenance":provenance,"palette":COLORS,"figures":CHECKS},indent=2)+"\n")
 print(json.dumps({k:{"font_min_pt":v["minimum_text_pt"],"outside":v["text_outside_canvas"]} for k,v in CHECKS.items()},indent=2))
