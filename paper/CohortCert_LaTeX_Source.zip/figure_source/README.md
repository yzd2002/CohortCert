# Redraw the six current vector figures

The main LaTeX project already includes the PDF figures. To redraw them independently, use Python with the versions in `requirements.txt`, then run from this directory:

```sh
python redraw_figures.py --inputs inputs --out redrawn_figures
```

Outputs: six PDF/SVG/PNG sets and `DISPLAY_VALIDATION.json`. No model inference, acquisition, bootstrap or solver is executed. `inputs/PROVENANCE.json` maps every input to its original frozen public archive member and checksum. `editable_svg/` contains the current editable figures. The original archive remains intact. `DESIGN_NOTES.txt` identifies primary design references and what was learned. PDF metadata timestamps may differ across redraws; plotted values and rendering are deterministic in the recorded environment.
