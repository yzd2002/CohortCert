CohortCert Overleaf-compatible v10.
Main file: main.tex. Compiler: pdfLaTeX; bibliography: BibTeX.
The exact user-supplied abstract is used. The main file declares documentclass and begins the document explicitly.
All eight authors and their roles, the scientific body, the AI declaration, references, tables and figures are unchanged.
Commands: pdflatex main.tex; bibtex main; pdflatex main.tex; pdflatex main.tex.

Revision v10: IEEEtran small-cap heading style retained; all section/subsection titles use consistent title case and shorter noun phrases. Section III is Adaptive Sampling and Cost Analysis. Introduction and method/result roadmaps clarify the execution order. The user-provided 1540-character abstract, eight author roles, AI declaration, seven displayed formula groups and empirical results are preserved.
