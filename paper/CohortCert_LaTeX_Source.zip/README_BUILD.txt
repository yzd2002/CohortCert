CohortCert Overleaf-compatible v11.
Main file: main.tex. Compiler: pdfLaTeX; bibliography: BibTeX.
The exact user-supplied abstract is used. The main file declares documentclass and begins the document explicitly.
All eight authors and their roles, the scientific body, the AI declaration, references, tables and figures are unchanged.
Commands: pdflatex main.tex; bibtex main; pdflatex main.tex; pdflatex main.tex.

Revision v11: IEEEtran small-cap heading style retained; all section/subsection titles use consistent title case and shorter noun phrases. Section III is Adaptive Sampling and Cost Analysis. Introduction and method/result roadmaps clarify the execution order. The user-provided 1540-character abstract, eight author roles, AI declaration, seven displayed formula groups and empirical results are preserved.

Revision v11 clarifies the request/decision/comparison hierarchy, total versus observed counts, reference labels, confidence sequences, forecast predictions and proof constraints. Figure 3 and Figure 5 captions now explicitly use percentages as shown on their axes. The exact author-supplied abstract, empirical values and mathematical definitions remain unchanged.
