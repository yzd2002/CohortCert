CohortCert final PDF review and submission authorship revision v7 (IEEEtran conference).

Compile from this source directory:
  pdflatex -interaction=nonstopmode -halt-on-error cohortcert.tex
  bibtex cohortcert
  pdflatex -interaction=nonstopmode -halt-on-error cohortcert.tex
  pdflatex -interaction=nonstopmode -halt-on-error cohortcert.tex

The complete source, IEEE template, bibliography and six vector figures are included. Standard IEEE font sizes, margins and line spacing are retained. The submission PDF contains no appendix; references and AI-generated-content acknowledgment follow the main body. The separate Technical Companion is online supplementary material and must not be appended to the submission PDF.

The eight authors are Zida Yang, Zisheng Kuang, Guquan You, Yongjun Dai, Junqin Chen, Haobing Liu, Jiexin Zheng, and Cong Wang. The first four share first authorship. Jiexin Zheng (author seven) and Cong Wang (author eight) are corresponding authors. They do not share first authorship. Author roles follow the authors' instructions.

This rewrite uses a worked request, a notation table, plain-language bridges for formulas, three groups of completion constraints, an experiment map and explanatory results tables. Full frozen definitions and parameters are retained in the Technical Companion. Implementations, empirical results, inputs and six vector PDFs are unchanged; illustrative examples are explicitly schematic. No new experiment or unfinished background result is claimed. This revision clarifies optimistic-grid endpoint rounding, the changed 171-read request, finite scatter exclusions, per-curve denominators, cost-band edges and the proxy prior concentration. It rewrites the abstract for readers new to the task and uses one concise AI declaration. The 157 within-budget proofs equal 67 crowd plus 90 model cases and are a hindsight diagnostic, not an online success rate. Use this PDF/source together with current metadata and the compatibility binding.
