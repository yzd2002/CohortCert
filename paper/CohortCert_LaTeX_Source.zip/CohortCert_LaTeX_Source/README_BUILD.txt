CohortCert final readability/authorship revision (IEEEtran conference).

Compile in this source directory:
  pdflatex -interaction=nonstopmode -halt-on-error cohortcert.tex
  bibtex cohortcert
  pdflatex -interaction=nonstopmode -halt-on-error cohortcert.tex
  pdflatex -interaction=nonstopmode -halt-on-error cohortcert.tex

All 32 source/template/bibliography/vector-figure files are included. Standard IEEEtran font sizes, margins and line spacing are retained. The submitted PDF has 12 body pages and 14 total pages; references and the separate AI-generated-content acknowledgment follow the body. No appendix is included.

This revision clarifies definitions, execution semantics and study units, adds the common executor pseudocode and verified artifact link, and updates nine-author metadata. The first four authors share first authorship; Xiaolong Shi is the sole corresponding author. Frozen implementations, experimental inputs, numerical results and all six supplied vector-figure PDFs are unchanged. The reported 157/192 within-cap proofs are the sum of the existing 67 crowd and 90 model cases. Full runtime and technical derivations remain in the linked artifact release. No new experiments or unfinished background results are asserted. Use this PDF/source together with the current author metadata and compatibility binding.
