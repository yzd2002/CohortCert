CohortCert final PDF review and submission authorship revision v7 (IEEEtran conference).

Compile from this source directory:
  pdflatex -interaction=nonstopmode -halt-on-error cohortcert.tex
  bibtex cohortcert
  pdflatex -interaction=nonstopmode -halt-on-error cohortcert.tex
  pdflatex -interaction=nonstopmode -halt-on-error cohortcert.tex

The complete source, IEEE template, bibliography and six vector figures are included. Standard IEEE font sizes, margins and line spacing are retained. The submission PDF contains no appendix; references and AI-generated-content acknowledgment follow the main body. The separate Technical Companion is online supplementary material and must not be appended to the submission PDF.

The eight authors are Zida Yang, Zisheng Kuang, Guquan You, Yongjun Dai, Junqin Chen, Haobing Liu, Jiexin Zheng, and Cong Wang. The first four share first authorship. Jiexin Zheng (author seven) and Cong Wang (author eight) are corresponding authors. They do not share first authorship. Author roles follow the authors' instructions.

This v8 revision rebuilds the exposition for readers unfamiliar with the task. It defines records/groups/labels/output and the worked example before formal notation, explains actual read selection before offline optimization, and gives data and request tables before measurement details. Seven displayed equation groups retain the central count propagation, sampling guarantee and full completion constraints. Full likelihood derivations, rational dual bounds and score definitions remain in the separate Technical Companion; TC5 retains the full prior result breakdowns. All numerical evidence, method implementations and six vector figures are unchanged. No new experiment is claimed.
