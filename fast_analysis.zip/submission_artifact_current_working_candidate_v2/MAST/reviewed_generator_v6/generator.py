"""Render only externally pinned, fully closed scientific audit outputs.

No online worker, label-map, actual-rank, source-log or method import exists.
This file is prepared statically; it must not be run before the final audit.
"""
from pathlib import Path
from hashlib import sha256
import argparse,csv,json,math,os

SCHEMA='disjoint-source-fixed56-scientific-audit-summary/v1'
CONTINUATION_SHA='f6c5c470ae7bc8484615b3f03ae5029f034a710636c7b4133551ff9e6ed5cf5b'
METHODS=(
 'VectorRoundRobinABC_v1',
 'VectorWidthSumGain_v1',
 'VectorDifficultyWeightedWidthGain_v1',
 'Evergreen_NativeExactVector_v1',
 'Evergreen_ProgressiveNativeVector_RR_v1',
 'SSS_Kelly_FiniteUpperNullCover_RR_v1',
 'SSS_Kelly_CommonLogEvidenceGreedy_v1')
LABELS=('Local-CS / RR','Local-CS / Width','Local-CS / DWidth',
        'NativeExact adapter','NativeProgressive / RR','Joint-Kelly / RR','Joint-Kelly / LogGreedy')
SHORT=('LC-RR','LC-W','LC-DW','NE','NP-RR','JK-RR','JK-LG')
BUDGETS=(75,150,225,300)
NORMAL='WORKER_SEALED'
CENSORED={'CENSORED_UNKNOWN','CLAIM_CONFLICT_UNKNOWN'}
UNRUN={'UNRUN_GLOBAL_STOP'}
KNOWN_ADMIN={NORMAL,'WORKER_FAILED_CLOSED','START_FAILED_UNSUBMITTED'}|CENSORED|UNRUN
MISSING='UNAVAILABLE'
ADMIN_KEYS=('normal','censor','unrun','other')
OVERLAY_KEYS=('verification_unknown','scientific_error','resource_ineligible')
COMPACT_STATUS_KEYS=ADMIN_KEYS+('resource_ineligible','scientific_error','verification_unknown')
PRESENTATION_ROOT=Path(__file__).resolve().parent.parent/'mast_audited_publication_outputs'

class AuditInputError(ValueError):pass

def require(ok,message):
    if not ok:raise AuditInputError(message)
def integer(value,low,high,name):
    require(type(value) is int and low<=value<=high,name+' must be a plain integer in range')
    return value
def expected_sha(value,name):
    require(type(value) is str and len(value)==64 and all(c in '0123456789abcdef' for c in value),name+' requires an external lowercase SHA256')
    return value
def file_hash(path):
    path=Path(path);require(path.is_file() and not path.is_symlink(),'regular nonsymlink audit file required')
    h=sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(65536),b''):h.update(block)
    return h.hexdigest()
def pairs(rows):
    out={}
    for key,value in rows:
        require(key not in out,'duplicate audit JSON key');out[key]=value
    return out
def read_json(path,cap=32*1024**2):
    path=Path(path);require(path.stat().st_size<=cap,'bounded audit JSON exceeded')
    with path.open('rb') as f:raw=f.read(cap+1)
    require(len(raw)<=cap,'bounded audit JSON exceeded')
    def finite_float(value):
        answer=float(value);require(math.isfinite(answer),'nonfinite audit JSON');return answer
    return json.loads(raw,object_pairs_hook=pairs,parse_float=finite_float,parse_constant=lambda _:(_ for _ in ()).throw(AuditInputError('nonfinite audit JSON')))
def canonical(value):return (json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()
def canonical_equal(a,b):return type(a) is type(b) and canonical(a)==canonical(b)
def safe_member(root,name):
    require(type(name) is str and name and not name.startswith('/') and '..' not in Path(name).parts,'canonical relative audit member required')
    p=root/name;require(not p.is_symlink() and p.resolve().is_relative_to(root),'audit member escapes sealed output directory')
    # Audit artifacts are distinct from online private packets or raw inputs.
    require('private' not in Path(name).parts and Path(name).name not in ('LOCKED_LABEL_VECTORS.json','RECORD_IDENTITIES.json','ACTUAL_ENTROPY_RANKS.json','RUN_PACKET.json','MAD_full_dataset.json'),'online private/raw input is outside presentation scope')
    return p

def planned_runs():
    out=[]
    for rep in range(8):
        shift=rep%7;order=METHODS[shift:]+METHODS[:shift]
        for method in order:out.append(dict(slot=len(out),replicate_id=rep,method_id=method,run_id=f'rep{rep:02d}__{method}'))
    return out

def authority_map(summary):
    values=summary.get('authority_hashes')
    require(type(values) is dict and bool(values),'summary must bind its audit authorities')
    for key,value in values.items():
        require(type(key) is str and bool(key),'authority name required');expected_sha(value,'authority '+key)
    return values

def load_closed_audit(audit_dir,summary_sha,closed_sha):
    """Only entry that reads future audit files; no automatic hash discovery."""
    expected_sha(summary_sha,'--summary-sha256');expected_sha(closed_sha,'--closed-sha256')
    root=Path(audit_dir).resolve();require(root.is_dir(),'explicit final audit directory required')
    sp=root/'SUMMARY.json';cp=root/'AUDIT_CLOSED.json'
    require(file_hash(cp)==closed_sha,'AUDIT_CLOSED external SHA mismatch')
    closed=read_json(cp)
    require(closed.get('summary_sha256')==summary_sha,'closure does not bind the externally specified summary')
    require(file_hash(sp)==summary_sha,'SUMMARY external SHA mismatch')
    inventory=closed.get('files');require(type(inventory) is list and inventory,'complete closed audit inventory required')
    members={};total=0
    for item in inventory:
        require(type(item) is dict and set(item)>={'path','bytes','sha256'},'closed inventory record schema')
        name=item['path'];require(name not in members,'duplicate audit inventory path')
        expected_sha(item['sha256'],'inventory '+str(name));size=integer(item['bytes'],0,2**31,'inventory bytes')
        path=safe_member(root,name);require(path.stat().st_size==size and file_hash(path)==item['sha256'],'closed audit member SHA/size mismatch')
        members[name]=item;total+=size
    require(total<=2**31 and len(members)<=131072,'audit artifact presentation bound exceeded')
    require('SUMMARY.json' in members and members['SUMMARY.json']['sha256']==summary_sha,'summary missing from closure inventory')
    expected_cases={f'CASE_{i:03d}.json' for i in range(56)}
    actual_cases={name for name in members if Path(name).name.startswith('CASE_') and Path(name).suffix=='.json'}
    require(actual_cases==expected_cases,'all56 global case files required without replacement or extra cases')
    summary=read_json(sp);require(summary.get('schema')==SCHEMA,'unsupported final scientific audit schema')
    integer(summary.get('planned_rows'),56,56,'planned audit cases')
    authorities=authority_map(summary)
    # The closure must identify the same global audit context. Per-source case
    # contexts may differ and are preserved in source_case, never relabelled.
    require(type(summary.get('context')) is str and bool(summary['context']),'summary audit context missing')
    require(closed.get('context')==summary['context'],'summary/closure audit context mismatch')
    if 'authority_hashes' in closed:require(canonical_equal(closed['authority_hashes'],authorities),'closure/summary authorities mismatch')
    cases=[]
    for run in planned_runs():
        item=read_json(root/f'CASE_{run["slot"]:03d}.json')
        require(canonical_equal(item.get('run'),run),'global case identity/order differs from the fixed56 plan')
        if 'audit_authority_hashes' in item:require(canonical_equal(item['audit_authority_hashes'],authorities),'case audit authority mismatch')
        cases.append(item)
    return root,summary,closed,cases,members

def optional_json(value):return MISSING if value is None else json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)

def source_provenance(summary,cases):
    """Validate only the closed audit's provenance; never open source trees."""
    require(summary.get('continuation_plan_sha256')==CONTINUATION_SHA,'current recursive continuation plan required')
    sources=summary.get('source_provenance')
    slots={'retained':list(range(4)),'new52':[4],'new51':list(range(5,50)),'new6':list(range(50,56))}
    require(type(sources) is dict and set(sources)==set(slots),'complete current four-source registry required')
    roots={};contexts={};eligibility={}
    for sid,expected_slots in slots.items():
        spec=sources[sid];require(type(spec) is dict and spec.get('source_id')==sid,'source registry identity differs')
        name=spec.get('root');require(type(name) is str and bool(name) and Path(name).is_absolute(),'absolute sealed source root required')
        roots[sid]=Path(name).resolve()
        context=spec.get('context');require(type(context) is str and bool(context),'original source context required');contexts[sid]=context
        # Retained registries preserve their entire original source deployment,
        # including old unrun slots superseded only by new first executions.
        selected=spec.get('selected_slots')
        require(type(selected) is list and all(type(slot) is int and 0<=slot<56 for slot in selected) and len(selected)==len(set(selected)),'source registry slot identities must be explicit and unique')
        require(set(expected_slots)<=set(selected),'source registry omits a retained/current case identity')
    for item in cases:
        source=item.get('source_case');require(type(source) is dict,'per-case original source provenance required')
        sid=source.get('source_id');require(sid in sources,'case source absent from the registry')
        require(item['run']['slot'] in slots[sid],'case assigned to the wrong retained/new source')
        name=source.get('study_root');require(type(name) is str and bool(name) and Path(name).is_absolute(),'absolute per-case source root required')
        require(Path(name).resolve()==roots[sid],'case and registry source roots differ')
        require(source.get('source_context')==contexts[sid],'case original source context differs from its registry')
        credit=item.get('source_scientific_credit_allowed');require(type(credit) is bool,'current ABI requires explicit boolean source eligibility')
        require(sid not in eligibility or eligibility[sid] is credit,'one source has inconsistent resource eligibility')
        eligibility[sid]=credit
    require(set(eligibility)==set(sources),'source eligibility registry incomplete')
    return roots,eligibility

def output_directory(name,audit_root,source_roots):
    """All publication writes belong to a dedicated, new sibling output tree."""
    base=PRESENTATION_ROOT
    require(base.is_absolute() and base.resolve()==base,'fixed presentation root must not be redirected by a symlink')
    out=Path(name).resolve()
    require(out.parent==base,'output must be a new direct child of '+str(base))
    require(not out.exists(),'new output directory required; outputs are never overwritten')
    for protected in (audit_root,*source_roots.values(),Path(__file__).resolve().parent):
        require(not out.is_relative_to(protected),'presentation must not change a sealed audit/source or generator directory')
    return out

def fee_fields(charge):
    if type(charge) is not dict:return MISSING,'UNKNOWN','UNKNOWN'
    prefix=charge.get('known_durable_submitted_prefix')
    if prefix is not None:integer(prefix,0,300,'known submitted fee prefix')
    exact=charge.get('exact_total');tail=charge.get('exact_tail')
    if exact is None:
        require(tail in (None,'UNKNOWN'),'unknown exact total cannot have a known tail')
        return MISSING if prefix is None else prefix,'UNKNOWN','UNKNOWN'
    integer(exact,0,300,'exact total fee')
    require(tail=='KNOWN','exact total needs an explicitly known tail')
    require(prefix is not None and exact==prefix,'exact total and independently known submitted prefix disagree')
    return prefix,exact,'KNOWN'

def inspect(summary,cases):
    methods=summary.get('methods');require(type(methods) is dict and set(methods)==set(METHODS),'all seven predeclared methods required')
    points={}
    for method in METHODS:
        block=methods[method];integer(block.get('planned_replicates'),8,8,'planned per-method denominator')
        rows=block.get('points');require(type(rows) is list and len(rows)==8,'eight paths per method required')
        seen=set()
        for point in rows:
            rep=integer(point.get('replicate_id'),0,7,'summary replicate');require(rep not in seen,'duplicate summary path');seen.add(rep)
            points[(method,rep)]=point
        require(seen==set(range(8)),'missing predeclared path')
    records=[];counts={m:{b:0 for b in BUDGETS} for m in METHODS}
    statuses={m:{key:0 for key in ADMIN_KEYS+OVERLAY_KEYS} for m in METHODS}
    for item in cases:
        run=item['run'];method=run['method_id'];rep=run['replicate_id'];point=points[(method,rep)]
        status=item.get('status');scientific=item.get('scientific_status')
        require(status in KNOWN_ADMIN,'unknown administrative status; do not silently regroup it')
        require(scientific in {'VERIFIED_ONLINE_COMPLETE','VERIFIED_INCOMPLETE','UNKNOWN','ERROR'},'unsupported scientific verification status')
        require(point.get('scientific_status')==scientific,'case/summary verification status mismatch')
        primary=item.get('whole28_primary');require(type(primary) is dict and set(primary)=={str(b) for b in BUDGETS},'complete four-budget case endpoint required')
        require(all(type(primary[str(b)]) is bool for b in BUDGETS),'case endpoints must be explicit booleans')
        require(canonical_equal(point.get('primary'),primary),'case/summary primary endpoint mismatch')
        values=[primary[str(b)] for b in BUDGETS];require(values==sorted(values),'fixed-run budget endpoint is nonmonotone')
        credit=item.get('source_scientific_credit_allowed')
        require(type(credit) is bool,'current ABI requires explicit boolean source eligibility')
        charge=item.get('charge');prefix,exact,tail=fee_fields(charge)
        if 'charge' in point:require(canonical_equal(point['charge'],charge),'case/summary charge metadata mismatch')
        errors=item.get('sticky_errors');issues=item.get('issues')
        source=item.get('source_case')
        require(source is None or type(source) is dict,'source provenance must be an object when present')
        summary_sticky=point.get('sticky_error_count')
        if summary_sticky is not None:integer(summary_sticky,0,1000000,'reported sticky error count')
        if errors is not None:require(type(errors) is list,'sticky error list schema')
        if issues is not None:require(type(issues) is list,'issue list schema')
        if any(values):
            require(status==NORMAL and scientific=='VERIFIED_ONLINE_COMPLETE' and credit is True,'completion credit requires normal verified eligible closure')
            require(type(exact) is int and tail=='KNOWN','completion cannot use a guessed or censored cost')
            require(errors==[] and issues==[],'completion cannot erase errors or unknown evidence')
            require(type(source) is dict and type(source.get('source_id')) is str and bool(source['source_id']),'completion lacks source provenance')
            require(all(not primary[str(b)] or exact<=b for b in BUDGETS),'completion exceeds stated physical budget')
        if run['slot'] in (3,4):
            require(method==METHODS[run['slot']] and rep==0 and status=='CENSORED_UNKNOWN' and not any(values),'both retained native startup censors must never be retried/promoted/omitted')
            require(prefix==0 and exact=='UNKNOWN' and tail=='UNKNOWN','retained native known-zero prefix or unknown expense tail was erased')
        if run['slot']==49:
            require(method==METHODS[0] and rep==7 and status=='CENSORED_UNKNOWN' and not any(values),'retained control-plane censor49 must never be retried/promoted/omitted')
            require(exact=='UNKNOWN' and tail=='UNKNOWN','control-plane censor49 exact expense tail remains unknown')
        if run['slot']==55:
            require(method==METHODS[6] and rep==7 and status=='CENSORED_UNKNOWN' and not any(values),'retained controller-budget censor55 must never be retried/promoted/omitted')
            require(exact=='UNKNOWN' and tail=='UNKNOWN','controller-budget censor55 exact expense tail remains unknown')
        for b in BUDGETS:counts[method][b]+=int(primary[str(b)])
        group='normal' if status==NORMAL else 'censor' if status in CENSORED else 'unrun' if status in UNRUN else 'other'
        statuses[method][group]+=1
        if scientific=='UNKNOWN':statuses[method]['verification_unknown']+=1
        if scientific=='ERROR':statuses[method]['scientific_error']+=1
        if not credit:statuses[method]['resource_ineligible']+=1
        source_id=source.get('source_id') if type(source) is dict else None
        records.append(dict(global_slot=run['slot'],run_id=run['run_id'],method_id=method,method_label=LABELS[METHODS.index(method)],replicate_id=rep,source_id=source_id if source_id is not None else MISSING,admin_status=status,scientific_status=scientific,source_credit_allowed=credit if credit is not None else MISSING,complete_at_75=primary['75'],complete_at_150=primary['150'],complete_at_225=primary['225'],complete_at_300=primary['300'],known_durable_fee_prefix=prefix,exact_total_fee=exact,exact_fee_tail=tail,case_sticky_error_count=len(errors) if errors is not None else MISSING,summary_reported_sticky_error_count=summary_sticky if summary_sticky is not None else MISSING,issues_json=optional_json(issues),source_case_json=optional_json(source)))
    for method in METHODS:
        require(sum(statuses[method][s] for s in ADMIN_KEYS)==8,'per-method operational denominator changed')
        aggregate=methods[method].get('whole28_correct_complete');require(type(aggregate) is dict and set(aggregate)=={str(b) for b in BUDGETS},'all four aggregate budgets required')
        for b in BUDGETS:
            a=aggregate[str(b)];integer(a.get('denominator'),8,8,'aggregate denominator');integer(a.get('successes'),0,8,'aggregate successes')
            require(a['successes']==counts[method][b],'recomputed all-case numerator disagrees with summary')
    return records,counts,statuses

def tex(value):
    table={'\\':r'\textbackslash{}','&':r'\&','%':r'\%','$':r'\$','#':r'\#','_':r'\_','{':r'\{','}':r'\}','~':r'\textasciitilde{}','^':r'\textasciicircum{}'}
    return ''.join(table.get(ch,ch) for ch in str(value))
def csv_file(path,rows,fields):
    with path.open('x',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader();writer.writerows(rows)
def text_file(path,value):
    with path.open('x',encoding='utf-8') as f:f.write(value)

def export_tables(out,records,counts,statuses):
    csv_file(out/'mast_all56_cases.csv',records,list(records[0]))
    rows=[]
    for method in METHODS:
        row=dict(method_id=method,method_label=LABELS[METHODS.index(method)],planned_paths=8)
        row.update({f'complete_at_{b}':counts[method][b] for b in BUDGETS});row.update(statuses[method]);rows.append(row)
    csv_file(out/'mast_method_summary.csv',rows,list(rows[0]))
    # Exactly seven fixed-order rows for the main paper's compact complete
    # table. They use the same audited counts as every existing export.
    compact=[]
    for i,method in enumerate(METHODS):
        fields=[tex(SHORT[i])]+[f'{counts[method][b]}/8' for b in BUDGETS]
        fields.extend(str(statuses[method][key]) for key in COMPACT_STATUS_KEYS)
        compact.append(' & '.join(fields)+r' \\')
    text_file(out/'mast_audited_compact_rows.tex','\n'.join(compact)+'\n')
    lines=[r'\begin{tabular}{lrrrr}',r'\toprule',r'Program & $75$ & $150$ & $225$ & $300$ \\',r'\midrule']
    for i,method in enumerate(METHODS):lines.append(tex(SHORT[i])+' & '+' & '.join(f'{counts[method][b]}/8' for b in BUDGETS)+r' \\')
    lines.extend([r'\bottomrule',r'\end{tabular}','% All eight planned paths per method; one fixed request. No confidence interval.'])
    text_file(out/'mast_completion_table.tex','\n'.join(lines)+'\n')
    lines=[r'\begin{tabular}{lrrrrrrr}',r'\toprule',r'Program & N & C & U & O & V? & E & R \\',r'\midrule']
    for i,method in enumerate(METHODS):lines.append(tex(SHORT[i])+' & '+' & '.join(str(statuses[method][k]) for k in ADMIN_KEYS+OVERLAY_KEYS)+r' \\')
    lines.extend([r'\bottomrule',r'\end{tabular}',r'% N=normal pipeline closure; C=censor/claim conflict; U=unrun; O=other administrative failure.',r'% V?=verification UNKNOWN, E=scientific ERROR, R=source resource-ineligible (no primary credit). These are overlapping diagnostics, not additional administrative outcomes.'])
    text_file(out/'mast_status_table.tex','\n'.join(lines)+'\n')
    lines=[r'% Artifact ledger; do not append this long table to the twelve-page paper.',r'\begin{longtable}{rllrrrrll}',r'\toprule',r'ID & Program/path & Admin/verif. & $75$ & $150$ & $225$ & $300$ & Fee prefix & Exact total \\',r'\midrule',r'\endhead']
    for row in records:
        label=SHORT[METHODS.index(row['method_id'])]+'/'+str(row['replicate_id'])
        state=row['admin_status']+'/'+row['scientific_status']+'/R='+str(int(not row['source_credit_allowed']))
        flags=['1' if row[f'complete_at_{b}'] else '0' for b in BUDGETS]
        lines.append(str(row['global_slot'])+' & '+tex(label)+' & '+tex(state)+' & '+' & '.join(flags)+' & '+tex(row['known_durable_fee_prefix'])+' & '+tex(row['exact_total_fee'])+r' \\')
    lines.extend([r'\bottomrule',r'\end{longtable}',r'% R=1 means source resource-ineligible, even if verification is COMPLETE; R=0 means resource-eligible. Administrative/verification states are retained.',r'% UNKNOWN is an unsealed/missing total, never zero or a best-cost observation.'])
    text_file(out/'mast_all56_cases.tex','\n'.join(lines)+'\n')

def draw_heatmap(out,counts,statuses):
    # Delayed import: even plotting libraries are loaded only after the closed
    # scientific audit and every case have passed all presentation checks.
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.colors import BoundaryNorm
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none'})
    fig=plt.figure(figsize=(6.9,3.3));grid=fig.add_gridspec(1,2,width_ratios=(4.0,2.0),wspace=.05)
    ax=fig.add_subplot(grid[0,0]);rail=fig.add_subplot(grid[0,1],sharey=ax)
    matrix=[[counts[m][b] for b in BUDGETS] for m in METHODS];cmap=plt.get_cmap('Blues',9);norm=BoundaryNorm([x-.5 for x in range(10)],cmap.N)
    im=ax.imshow(matrix,cmap=cmap,norm=norm,interpolation='nearest',aspect='auto')
    ax.set_xticks(range(4),[str(b) for b in BUDGETS]);ax.set_yticks(range(7),LABELS)
    ax.set_xlabel('Accepted whole-vector acquisition budget');ax.set_title('Whole-request correct completion',loc='left',fontsize=9)
    for y,method in enumerate(METHODS):
        for x,b in enumerate(BUDGETS):
            k=counts[method][b];ax.text(x,y,f'{k}/8',ha='center',va='center',color='white' if k>=5 else 'black',fontsize=8)
    ax.set_xticks([x-.5 for x in range(5)],minor=True);ax.set_yticks([y-.5 for y in range(8)],minor=True);ax.grid(which='minor',color='white',linewidth=.7);ax.tick_params(which='minor',length=0)
    rail.set_xlim(0,1);rail.set_xticks([]);rail.tick_params(axis='y',left=False,labelleft=False);rail.set_title('N / C / U / O / V? / E / R',fontsize=7)
    for y,method in enumerate(METHODS):
        values=[statuses[method][k] for k in ADMIN_KEYS+OVERLAY_KEYS]
        rail.text(.03,y,' / '.join(map(str,values)),va='center',fontsize=7)
    for spine in rail.spines.values():spine.set_visible(False)
    fig.subplots_adjust(left=.29,right=.99,bottom=.25,top=.88)
    fig.text(.02,.075,'One fixed request; eight random paths. N/C/U/O partition the eight administrative outcomes.',fontsize=6.7)
    fig.text(.02,.035,'Overlays: V? = verification unknown; E = scientific error; R = source resource-ineligible (no primary credit).',fontsize=6.7)
    fig.savefig(out/'mast_whole_request_completion.pdf',metadata={'Title':'Fixed released-judge request: all-path whole-request completion'},bbox_inches='tight')
    fig.savefig(out/'mast_whole_request_completion.svg',bbox_inches='tight')
    fig.savefig(out/'mast_whole_request_completion.png',dpi=300,bbox_inches='tight');plt.close(fig)

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--audit-dir',required=True);p.add_argument('--summary-sha256',required=True);p.add_argument('--closed-sha256',required=True);p.add_argument('--output-dir',required=True);a=p.parse_args()
    root,summary,closed,cases,members=load_closed_audit(a.audit_dir,a.summary_sha256,a.closed_sha256)
    source_roots,source_eligibility=source_provenance(summary,cases)
    records,counts,statuses=inspect(summary,cases)
    out=output_directory(a.output_dir,root,source_roots);out.mkdir(parents=True)
    export_tables(out,records,counts,statuses);draw_heatmap(out,counts,statuses)
    # Descriptive range among credited complete cases; never assign zero to an unknown.
    cost_lines=[]
    for method in METHODS:
        eligible=[row['exact_total_fee'] for row in records if row['method_id']==method and row['complete_at_300'] is True]
        require(len(eligible)==counts[method][300] and all(type(value) is int for value in eligible),'cost range must use exactly the verified eligible budget300 completions')
        cost_range=(str(min(eligible)) if min(eligible)==max(eligible) else str(min(eligible))+'--'+str(max(eligible))) if eligible else r'\textemdash'
        status=statuses[method]
        cost_lines.append(tex(LABELS[METHODS.index(method)])+' & '+str(len(eligible))+'/8 & '+cost_range+' & '+str(status['normal'])+' & '+str(status['censor'])+' & '+str(status['scientific_error'])+' & '+str(status['verification_unknown'])+r' \\')
    (out/'mast_audited_cost_range_rows.tex').write_text('\n'.join(cost_lines)+'\n')
    (out/'COST_RANGE_SCOPE.txt').write_text('Ranges are descriptive only among exactly those cases credited as verified complete at budget300; the k/8 denominator and full status ledger remain. Unknown costs are never zero. Do not compare conditional ranges as an unconditional mean or claim latency/LLM-forward/economic savings. Full four-budget results and N/C/U/O/R/E/V? remain in the inherited outputs.\n')
    caption=('Whole-request correct completion for one fixed released-judge vector request. Each cell is an integer k/8; all seven fixed programs, four budgets and eight planned paths remain. N=normal pipeline closure, C=censor/claim conflict, U=unrun, O=other administrative failure; these partition eight. Overlapping diagnostics are V?=verification UNKNOWN, E=scientific ERROR, and R=source resource-ineligible (no primary credit, even if otherwise verified complete). No confidence interval or interpolation is implied. All four retained censors (two at Native startup and two in control) are kept without retry, replacement or denominator reduction; they are execution outcomes, not algorithmic failures. Acquisition counts are not measured LLM forwards, tokens or dollars. Costs with an unknown exact tail remain UNKNOWN in the complete case ledger.\n')
    text_file(out/'mast_figure_caption.txt',caption)
    inputs=dict(schema=summary['schema'],audit_dir=str(root),summary_sha256=a.summary_sha256,audit_closed_sha256=a.closed_sha256,context=summary['context'],authority_hashes=summary['authority_hashes'],continuation_plan_sha256=CONTINUATION_SHA,protected_source_roots={sid:str(path) for sid,path in source_roots.items()},source_scientific_credit_allowed=source_eligibility,presentation_root=str(PRESENTATION_ROOT.resolve()),case_file_sha256={f'CASE_{i:03d}.json':members[f'CASE_{i:03d}.json']['sha256'] for i in range(56)},planned_cases=56,paths_per_method=8,methods=list(METHODS),budgets=list(BUDGETS),no_confidence_interval_or_result_selected_subset=True)
    text_file(out/'INPUT_BINDINGS.json',json.dumps(inputs,indent=2)+'\n')
    files=[dict(path=q.name,bytes=q.stat().st_size,sha256=file_hash(q)) for q in sorted(out.iterdir()) if q.is_file()]
    text_file(out/'OUTPUT_MANIFEST.json',json.dumps(dict(schema='audited-fixed56-presentation-output/v1',inputs=inputs,files=files),indent=2)+'\n')
    print(json.dumps(dict(status='AUDITED_PRESENTATION_WRITTEN',output_dir=str(out),input_summary_sha256=a.summary_sha256,output_manifest_sha256=file_hash(out/'OUTPUT_MANIFEST.json'))))

if __name__=='__main__':
    try:main()
    except (AuditInputError,OSError,KeyError,TypeError,json.JSONDecodeError) as e:
        raise SystemExit('No presentation produced from unverified/incompatible input: '+str(e))
