V6窄修改：只在conditional cost rows的N/C/V?之间加入scientific_error E列，成为Program,k300/8,conditional exact-cost range,N,C,E,V?共7列。全56/全7方法/全8路径/全4预算/永久censor3,4,49,55及所有旧守卫、指标、完整12列compact、图表均不变。不能把条件费用当全分母均值。
新审计必须经第二次posthoc环境核验与full56对照正式准入；原pair和UNKNOWN历史保留。仅源检查候选，尚未运行新渲染；需非作者Ready绑定新pair和实际ResultReady。不得读取Source192/B/私有在线输入。
