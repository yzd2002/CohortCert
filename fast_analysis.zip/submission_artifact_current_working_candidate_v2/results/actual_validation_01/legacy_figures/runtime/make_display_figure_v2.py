#!/usr/bin/env python3
"""Display-only runtime figure from the two bundled, audited source tables.

Run with Python + matplotlib. No executor, solver, tokenizer, model or experiment
is imported or run. This script writes only fresh figure/validation files in its
own directory and never alters the audited publication_v1 artifacts.
"""
from pathlib import Path
from collections import Counter
import csv
import hashlib
import itertools
import json
import math

HERE = Path(__file__).resolve().parent
EXPECTED_CSV = "e3ab774700627d3e706c0c7df10cbc90a8033a4d9be64fc62d87774abdb5e0ba"
EXPECTED_COSTS = "250275f005847517f1fe5be2b801baebfe4755b05a71eac733575b952d0a0dbb"
COLORS = {"matched": "#687782", "dual_greedy": "#00796b", "forecast": "#b05a16", "boundary": "#6c5b8c"}
NAMES = {"matched": "Matched", "dual_greedy": "DifficultyGreedy", "forecast": "Forecast", "boundary": "Boundary"}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    csv_path, cost_path = HERE / "source_planned_units_23.csv", HERE / "source_process_costs.json"
    assert sha(csv_path) == EXPECTED_CSV and sha(cost_path) == EXPECTED_COSTS
    with csv_path.open(newline="") as stream:
        rows = list(csv.DictReader(stream))
    costs = json.loads(cost_path.read_text())
    for row in rows:
        row["index"] = int(row["index"])
        row["ok"] = row["source_proof_valid_correct_complete"] == "True"
        row["cell_exclusion"] = row["source_cell_noncoverage"] == "True"
        row["query_seconds"] = float(row["query_wall_ms"]) / 1000
        row["parent_seconds"] = float(row["cold_parent_process_wall_ms"]) / 1000 if row["cold_parent_process_wall_ms"] else None
    assert len(rows) == len({r["index"] for r in rows}) == 23
    assert [r["index"] for r in rows] == list(range(23))
    warm = [r for r in rows if r["phase"] == "warm"]
    cold = [r for r in rows if r["phase"] == "cold"]
    assert len(warm) == 20 and len(cold) == 3
    assert sum(r["ok"] for r in warm) == 17 and sum(r["ok"] for r in cold) == 3
    assert [r["index"] for r in rows if r["cell_exclusion"]] == [10, 11, 12, 20, 21, 22]
    assert [r["index"] for r in warm if not r["ok"]] == [3, 4, 5]
    assert all(len({r["query_id"] for r in warm if r["method"] == m}) == 6 for m in ("matched", "dual_greedy", "forecast"))
    for row in cold:
        process = next(p for p in costs["processes"] if p["indexes"] == [row["index"]])
        assert math.isclose(process["process_wall_ms"] / 1000, row["parent_seconds"], abs_tol=1e-10)
        assert row["parent_seconds"] >= row["query_seconds"]
    for suffix in ("pdf", "svg", "png"):
        if (HERE / f"fig_runtime_v2.{suffix}").exists():
            raise FileExistsError("Keep existing derived display; use a fresh revision directory")
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.patches import Patch
    from matplotlib.text import Text
    plt.rcParams.update({"font.family": "serif", "font.serif": ["DejaVu Serif"], "font.size": 8,
                         "axes.labelsize": 7.8, "axes.titlesize": 8.5, "xtick.labelsize": 7.5, "ytick.labelsize": 7.5,
                         "legend.fontsize": 7.5, "pdf.fonttype": 42, "ps.fonttype": 42, "svg.fonttype": "none",
                         "axes.linewidth": .6, "hatch.linewidth": .65, "savefig.facecolor": "white"})
    fig, axes = plt.subplots(2, 1, figsize=(7.16, 4.7), gridspec_kw={"height_ratios": [2, 1]})
    fig.subplots_adjust(left=.103, right=.992, top=.845, bottom=.085, hspace=.61)
    legend = [Patch(facecolor=COLORS[m], edgecolor="none", label=NAMES[m]) for m in COLORS]
    legend += [Patch(facecolor="white", edgecolor="black", hatch="///", label="Unresolved at cap"),
               Patch(facecolor="none", edgecolor="none", label="† Shared cell-count exclusion")]
    fig.legend(handles=legend, ncols=3, loc="upper center", bbox_to_anchor=(.54, .998),
               frameon=False, fontsize=7.5, columnspacing=1.25, handlelength=1.4, handletextpad=.5, labelspacing=.45)
    position, group_marks = 0., []
    for qid, group in itertools.groupby(warm, key=lambda r: r["query_id"]):
        group = list(group)
        xs = []
        for row in group:
            xs.append(position)
            axes[0].bar(position, row["query_seconds"], width=.80, color=COLORS[row["method"]], edgecolor="#333333", linewidth=.45,
                        hatch=None if row["ok"] else "///", zorder=3)
            position += 1
        label = qid.replace("civilcomments-", "").replace("identity_attack", "identity attack").replace("-", "\n")
        if any(r["cell_exclusion"] for r in group):
            label += "†"
        group_marks.append({"center": sum(xs) / len(xs), "label": label, "last_x": xs[-1], "indexes": [r["index"] for r in group]})
        position += .5
    axes[0].set_xticks([g["center"] for g in group_marks], [g["label"] for g in group_marks], fontsize=7.5)
    for group in group_marks[:-1]:
        axes[0].axvline(group["last_x"] + .75, color="#dddddd", linewidth=.45, zorder=1)
    axes[0].set_xlim(-.7, position - .8)
    axes[0].set_ylim(0, 280)
    axes[0].set_ylabel("Observed warm query wall (s)", fontsize=7.8)
    axes[0].set_title("(a) All 20 planned warm executions", loc="left", fontsize=8.5, pad=4)
    for i, row in enumerate(cold):
        axes[1].bar(i, row["query_seconds"], width=.63, color=COLORS[row["method"]], edgecolor="#333333", linewidth=.45, zorder=3)
        axes[1].bar(i, row["parent_seconds"] - row["query_seconds"], bottom=row["query_seconds"], width=.63,
                    color="#bfbfbf", edgecolor="#333333", linewidth=.45, zorder=3)
    axes[1].set_xticks(range(3), [NAMES[r["method"]] + ("†" if r["cell_exclusion"] else "") for r in cold], fontsize=7.5)
    axes[1].set_ylim(0, 90)
    axes[1].set_ylabel("Process-cold wall (s)", fontsize=7.8)
    axes[1].set_title("(b) All 3 planned process-cold executions", loc="left", fontsize=8.5, pad=4)
    axes[1].legend(handles=[Patch(facecolor=COLORS["matched"], edgecolor="#333333", label="Query"),
                            Patch(facecolor="#bfbfbf", edgecolor="#333333", label="Outside query")],
                   ncols=2, loc="upper right", frameon=False, fontsize=7.5, handlelength=1.4, columnspacing=1.)
    for ax in axes:
        ax.spines[["top", "right"]].set_visible(False)
        ax.grid(axis="y", alpha=.18, linewidth=.5, zorder=0)
        ax.set_axisbelow(True)
        ax.tick_params(axis="x", length=0, pad=4, labelsize=7.5)
        ax.tick_params(axis="y", width=.6, length=3, labelsize=7.5)
    fig.canvas.draw()
    texts = [{"text": t.get_text(), "font_points": t.get_fontsize(), "font_family": t.get_fontfamily()}
             for t in fig.findobj(Text) if t.get_visible() and t.get_text()]
    assert min(t["font_points"] for t in texts) >= 7.5
    assert len(axes[0].patches) == 20 and len(axes[1].patches) == 6
    assert sum(bool(p.get_hatch()) for p in axes[0].patches) == 3
    for suffix in ("pdf", "svg", "png"):
        fig.savefig(HERE / f"fig_runtime_v2.{suffix}", dpi=240)
    plt.close(fig)
    validation = {"scope": "Display-only derivative; no new experimental observations.",
                  "code_sha256": sha(Path(__file__)), "source_csv_sha256": sha(csv_path), "source_costs_sha256": sha(cost_path),
                  "figure_inches": [7.16, 4.7], "minimum_font_points_at_native_width": min(t["font_points"] for t in texts),
                  "minimum_effective_font_points_at_43pc_IEEE_text_width": min(t["font_points"] for t in texts) * (516 * 72 / 72.27) / (7.16 * 72),
                  "warm_bars": 20, "cold_stacked_bars": 3, "hatched_unit_indexes": [3, 4, 5],
                  "cell_exclusion_unit_indexes": [10, 11, 12, 20, 21, 22], "main_method_unique_query_counts": {m: 6 for m in ("matched", "dual_greedy", "forecast")},
                  "cold_parent_seconds": {r["method"]: r["parent_seconds"] for r in cold}, "palette": COLORS,
                  "all_visible_text_fonts": texts, "output_sha256": {s: sha(HERE / f"fig_runtime_v2.{s}") for s in ("pdf", "svg", "png")}}
    with (HERE / "DISPLAY_VALIDATION.json").open("x") as stream:
        json.dump(validation, stream, indent=2, ensure_ascii=False)
        stream.write("\n")
    print(json.dumps({k: validation[k] for k in ("figure_inches", "minimum_font_points_at_native_width", "minimum_effective_font_points_at_43pc_IEEE_text_width", "warm_bars", "cold_stacked_bars", "output_sha256")}, indent=2))


if __name__ == "__main__":
    main()
