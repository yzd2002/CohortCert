# Airline data attribution and license notice

The source is **Twitter US Airline Sentiment**, originally from CrowdFlower's Data for Everyone collection and hosted on Kaggle by **Figure Eight / CrowdFlower** with a collaborator. Kaggle describes its release as a reformatted version of the original corpus and lists **Creative Commons Attribution–NonCommercial–ShareAlike 4.0 International (CC BY-NC-SA 4.0)**. The provider page was checked on 2026-11-02. [Provider data card](https://www.kaggle.com/datasets/crowdflower/twitter-airline-sentiment).

Keep credit to the source contributors and provider, link the source and license, and identify transformations. The stated license permits sharing/adaptation subject to attribution, noncommercial use, and ShareAlike conditions for distributed adaptations; it also forbids additional restrictions that defeat licensed permissions. [Official CC license deed](https://creativecommons.org/licenses/by-nc-sa/4.0/), [legal code](https://creativecommons.org/licenses/by-nc-sa/4.0/legalcode.en).

Changes made for CohortCert: all 14,640 source rows are retained as separate row records; row identifiers replace original tweet identifiers in the replay metadata; airline membership defines cohorts; the existing annotations are mapped to negative=1 and neutral/positive=0; text-free metadata and TF-IDF/SVD features are derived from the retained rows. The model-label file is a separate pinned-operator output. Source texts are downloaded/restored locally and are excluded from the reduced replay package. These changes do not imply provider endorsement.

This notice documents the dataset source and applies to accompanying dataset-derived material under the provider's stated terms. It does not replace software licenses, third-party notices, or model-weight licenses. No unrestricted or commercial-use data grant is made here. The CC legal code also preserves the limits of the licensor's rights; the provider's listing is not a grant of unrelated third-party rights.

Recorded source download:

- Provider: [Kaggle data card](https://www.kaggle.com/datasets/crowdflower/twitter-airline-sentiment).
- Archive endpoint: [public dataset download](https://www.kaggle.com/api/v1/datasets/download/crowdflower/twitter-airline-sentiment).
- Recorded archive SHA-256: `c0dbee48cac32110a607430dc5c1941a1728383adef20a893ded91adbbba2de2`.
- Exact `Tweets.csv` SHA-256: `ea94b23f41892b290dec3330bb8cf9cb6b8bc669eaae5f3a84c40f7b0de8f15e`.

The CSV content hash and retained row order identify this study's population. If the provider serves different CSV bytes, use the recorded release rather than silently substituting a new population.
