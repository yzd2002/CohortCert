#!/usr/bin/env python3
"""Working current-paper analysis candidate; no full experiment/replay admission.

All modes operate on explicit, pinned, local public summaries/projected results.
The unchanged MAST V5 generator keeps its own closure and output-root checks.
"""
import argparse
from collections import Counter
import json
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "tools"))
from artifact_common import (
    checked_json, checked_path, digest, fresh_output, low_impact_environment,
    member, verify_runtime_inputs, write_json,
)

SUMMARY_SHA = "23ac2fba2865bcebe9a3e06e968f3e7204d5eec2f39c3884a486f5eabb2f5ff1"
CLOSED_SHA = "6bc7adb9147561021b94c7367d600e3f933bd2f267e54664618742a4a3bc95ff"


def execute(argv):
    result = subprocess.run(argv, text=True, capture_output=True)
    if result.stdout:
        print(result.stdout, end="")
    if result.stderr:
        print(result.stderr, end="", file=sys.stderr)
    if result.returncode:
        raise RuntimeError(f"analysis command failed with exit status {result.returncode}")
    return {"argv": argv, "exit_code": result.returncode, "stdout": result.stdout, "stderr": result.stderr}


def primary(out):
    return execute([sys.executable, "-B", str(checked_path("tools/current_primary_table_renderer/render_primary_table.py")),
                    "--civil-summary", str(checked_path("inputs/public_summaries/FINAL_CONTROL_AND_MECHANISM_SUMMARY.json")),
                    "--go-summary", str(checked_path("inputs/public_summaries/FINAL_GOEMOTIONS_SUMMARY.json")),
                    "--outdir", str(out), "--compare-table", str(checked_path("reference/current_public_artifacts/generated_primary_table.tex"))])


def tables(out):
    return execute([sys.executable, "-B", str(checked_path("tools/summary_tables.py")), "tables", "--out", str(out)])


def legacy_summary(out):
    return execute([sys.executable, "-B", str(checked_path("tools/summary_tables.py")), "legacy-summary", "--out", str(out)])


def figures(out):
    return execute([sys.executable, "-B", str(checked_path("tools/portable_legacy_figures.py")), "--out", str(out)])


def mast(out):
    out = Path(out).resolve()
    fixed_parent = ROOT / "MAST/mast_audited_publication_outputs"
    if out.parent != fixed_parent or out.exists():
        raise ValueError("MAST output must be a new direct child of " + str(fixed_parent))
    script = checked_path("MAST/reviewed_generator_v5/generator.py")
    code_sha = digest(script)
    if code_sha != "fc7b085dfbff2d46ccba58e8d0e17ece44627a40ce79074da33f584193b64902":
        raise ValueError("exact reviewed MAST V5 generator required")
    audit = checked_path("inputs/mast_original56_public_audit/SUMMARY.json").parent
    result = execute([sys.executable, "-B", str(script), "--audit-dir", str(audit),
                      "--summary-sha256", SUMMARY_SHA, "--closed-sha256", CLOSED_SHA, "--output-dir", str(out)])
    comparisons = {}
    original_manifest = checked_json("reference/mast_original56_publication/OUTPUT_MANIFEST.json")
    for item in original_manifest["files"]:
        name = item["path"]
        if name.endswith((".tex", ".csv", ".txt")):
            comparisons[name] = {"generated_sha256": digest(out / name), "original_sha256": item["sha256"],
                                 "byte_identical": digest(out / name) == item["sha256"]}
    if not all(x["byte_identical"] for x in comparisons.values()):
        raise ValueError("MAST public table/ledger output differs from exact original pair")
    statuses = Counter()
    for slot in range(56):
        case = checked_json(f"inputs/mast_original56_public_audit/CASE_{slot:03d}.json")
        statuses[case["scientific_status"]] += 1
    if statuses["UNKNOWN"] != 11 or sum(v for k, v in statuses.items() if k.startswith("VERIFIED_")) != 45:
        raise ValueError("first-audit 45 VERIFIED/11 UNKNOWN state differs")
    receipt = {"schema": "portable-exact-v5-public-audit-presentation/v1", "status": "PASS_CLOSED_PUBLIC_AUDIT_TO_PRESENTATION_ONLY",
               "exact_reviewed_generator_sha256": code_sha, "summary_sha256": SUMMARY_SHA, "audit_closed_sha256": CLOSED_SHA,
               "original_publication_output_manifest_sha256": digest(checked_path("reference/mast_original56_publication/OUTPUT_MANIFEST.json")),
               "generated_output_manifest_sha256": digest(out / "OUTPUT_MANIFEST.json"), "scientific_status_counts": dict(statuses),
               "public_table_and_ledger_comparisons": comparisons,
               "original_source_absolute_provenance_strings_and_protection_checks_retained": True,
               "source_trees_or_raw_payloads_opened": False, "original_full_audit_admission_repeated": False,
               "Native_CI_method_model_or_entropy_calls": 0, "new_Native_revalidation_results_used": False,
               "relocation_scope": "The unchanged generator derives PRESENTATION_ROOT from its new script location; writes remain a new direct child. Authority hashes and old input pair are not replaced.",
               "new_wrapper_independently_reviewed": False}
    write_json(out / "PORTABLE_RENDER_RECEIPT.json", receipt)
    result["receipt"] = receipt
    return result


def verify_manifest():
    manifest = json.loads((ROOT / "MANIFEST.json").read_text())
    for item in manifest["files"]:
        path = member(item["path"])
        if not path.is_file() or path.stat().st_size != item["bytes"] or digest(path) != item["sha256"]:
            raise ValueError("candidate manifest mismatch: " + item["path"])
    return {"status": "PASS_CANDIDATE_FILE_INTEGRITY_ONLY", "verified_files": len(manifest["files"]),
            "submission_ready": False, "full_reproduction_pass": False}


def main():
    low_impact_environment()
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("mode", choices=("verify", "primary", "summary-tables", "legacy-summary", "legacy-figures", "mast", "all"))
    p.add_argument("--out", type=Path)
    p.add_argument("--run-id")
    a = p.parse_args()
    if a.mode == "verify":
        print(json.dumps(verify_manifest()))
        return
    checked = verify_runtime_inputs()
    if a.mode == "all":
        if not a.run_id or re.fullmatch(r"[A-Za-z0-9_-]{1,64}", a.run_id) is None:
            p.error("all requires a new --run-id with letters, digits, underscores or hyphens")
        out = ROOT / "results" / a.run_id
        mast_out = ROOT / "MAST/mast_audited_publication_outputs" / a.run_id
        if out.exists() or mast_out.exists():
            raise ValueError("run-id output already exists; choose a fresh run-id")
        fresh_output(out)
        jobs = {
            "primary": primary(out / "primary"),
            "summary_tables": tables(out / "summary_tables"),
            "legacy_summary": legacy_summary(out / "legacy_summary"),
            "legacy_figures": figures(out / "legacy_figures"),
            "mast": mast(mast_out),
        }
        receipt = {"schema": "working-current-paper-analysis-run/v1", "status": "PASS_EXECUTED_ANALYSIS_MODES_ONLY",
                   "runtime_pinned_files_checked": checked, "python_executable": sys.executable, "python_version": sys.version,
                   "nice_priority_at_least": 10, "numerical_thread_limits": 1, "arrow_io_thread_limit": 1, "jobs": jobs,
                   "full_experiment_or_clean_room_reproduction": False, "original_code_or_input_directories_changed": False,
                   "Source192_new_inputs_or_unclosed_Native_results_used": False, "submission_ready": False,
                   "new_wrapper_independently_reviewed": False}
        write_json(out / "RUN_RECEIPT.json", receipt)
        print(json.dumps({"status": receipt["status"], "receipt": str(out / "RUN_RECEIPT.json")}))
        return
    if a.out is None:
        p.error("this mode requires --out naming a fresh output directory")
    {"primary": primary, "summary-tables": tables, "legacy-summary": legacy_summary,
     "legacy-figures": figures, "mast": mast}[a.mode](a.out)


if __name__ == "__main__":
    try:
        main()
    except (ValueError, RuntimeError, OSError, KeyError) as error:
        raise SystemExit("Analysis candidate stopped: " + str(error))
