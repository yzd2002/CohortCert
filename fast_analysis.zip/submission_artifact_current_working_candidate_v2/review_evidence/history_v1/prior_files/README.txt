CohortCert 当前论文轻量分析复现候选（工作版，不是最终投稿/公开发布包）

论文绑定
冻结稿：manuscript_v5_mast_review_snapshot_v1，正文12页，全文14页，33条参考文献。
PDF SHA256: dd44f14bccc60b3693f2abb0414f8e808bce42bf0233ff37821849812c0acb71
完整PDF、编辑源码与投稿表单由外层论文交付目录管理；本候选保存纸面小型比较文件及上述版本绑定。
没有改论文作者、原目录、旧包或科学数值；没有公开URL、对外发布、许可授予或CMT操作。

用途与实测结论
这是离线、CPU、小体量的 public summaries/results -> tables/figures 分析重现材料。
2026-11-05最终在既有Linux/Python3.11环境实测 all（actual_validation_02），nice>=10、数值/CPU线程及Arrow I/O池均显式=1。已保留首轮actual_validation_01回执；首轮只约束数值/CPU线程，随后查明Arrow I/O池默认8，再补显式限制并完整重核本轻量分析。未测量首轮实际I/O线程利用。最终实测如下：
1) 已审主表原renderer从两个固定公开摘要生成13行，65字段一致；TeX逐字节等于冻结稿，SHA a17d99eefe6477dbef0d7c5f39a33c4e55383a0fc3083a410349204e6d38c2b9。
2) 新增候选wrapper生成Go段落和语义表，两文件均与冻结稿逐字节一致；语义表4行16指标。
3) 160个旧公开CSV保留全部72,480行及顺序，仅投影9个必要字段；原文件SHA均与旧ARTIFACT_SHA256一致。42项预设汇总的210字段复核通过（浮点容差<1e-12）；没有按成功/失败筛行。
4) 六幅旧正文图均由代码新绘制；13条主曲线的分母共60,320计划单位，未成功单位仍计入。Fig1为明确标注的示意图；Fig2为mention元数据；Fig3/4/5为旧公开结果展示；Fig6仅重画原23次模型观测。
5) MAST原V5 generator逐字节未改，用首轮原SUMMARY/AUDIT_CLOSED pair重新生成展示。所有公开TeX/CSV/说明与原产物逐字节一致；当前论文内联7行MAST表也逐行精确一致。原56项全部保留：45 VERIFIED、11 UNKNOWN（4永久censor +7 normal CI-consumer unavailable）。没有使用仍在运行的Native环境修正重核验结果。
6) 六图与MAST附加热图分别对同一原公开PDF以pdftoppm/110dpi呈现核对，7/7像素完全一致。PDF自身SHA可能因创建时间/路径元数据变化而不同；像素一致仅是展示验证。

运行命令（English command line；每次使用不存在的新输出名）
进入本候选目录后，Python3.11标准库即可运行主表模式：
  nice -n 10 python3 -B analysis_reproduce.py primary --out results/primary_demo01

完整轻量分析模式还需requirements/requirements_analysis_tested.txt中的五项依赖。
本机已测试的解释器为 /root/miniconda3/envs/cohortcert/bin/python；未新装依赖，未重建环境。
  nice -n 10 env OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 ARROW_IO_THREADS=1 /root/miniconda3/envs/cohortcert/bin/python -B analysis_reproduce.py all --run-id local_demo01
迁移到另一台机器时，将该解释器路径替换为已准备好的Python3.11解释器。
也可分别执行：
  python3 -B analysis_reproduce.py summary-tables --out results/tables_demo01
  python3 -B analysis_reproduce.py legacy-summary --out results/summary_demo01
  python3 -B analysis_reproduce.py legacy-figures --out results/figures_demo01
  python3 -B analysis_reproduce.py mast --out MAST/mast_audited_publication_outputs/mast_demo01
入口自身会限制数值/CPU线程与Arrow I/O池为1，并将本进程优先级降至nice>=10；子进程继承。Linux目录迁移为预期便携范围；Windows/macOS未经验证。
清单完整性：
  nice -n 10 python3 -B analysis_reproduce.py verify
verify仅核本候选文件，不运行实验，也不等于当前论文完整复现通过。

MAST路径与authority边界
原V5 generator要求输出是PRESENTATION_ROOT的新direct child；该root由脚本位置推导。保持原脚本字节和保护逻辑不变，复制后本候选实际root为 MAST/mast_audited_publication_outputs。
原source绝对路径、authority hashes、56案例身份与closure库存逐项校验均保留；source树、labels、ranks、raw和方法实现不会被打开。本候选不重授原full audit admission。
唯一输入pair固定为：
  SUMMARY 23ac2fba2865bcebe9a3e06e968f3e7204d5eec2f39c3884a486f5eabb2f5ff1
  CLOSED  6bc7adb9147561021b94c7367d600e3f933bd2f267e54664618742a4a3bc95ff
原展示manifest仍绑定864361389cfe41b46fa3bc9c62a377ae4b578187795cea6c59cc5af81af4f4c4。
本次便携输出manifest为15a79d3bc7f5bb46d16be1f28d792914bd6e7406e4cce58bc001254d09ce3870，包含新的本地audit/presentation路径，不能冒充原manifest或另一次科学审计。

目录与证据
analysis_reproduce.py：统一轻量入口；RUN_MODES.json给每种模式的范围。
inputs/public_summaries：两份已审主摘要；inputs/legacy_analysis为全部行的必要列投影与小型旧oracle公开汇总。
inputs/mast_original56_public_audit：原首轮闭合公开审计SUMMARY/CASE/CLOSED及closure内所需小文件。
tools/current_primary_table_renderer、MAST/reviewed_generator_v5：原已审组件；review_evidence保留各自精确Ready与来源证据。
tools/summary_tables.py、tools/portable_legacy_figures.py、tools/artifact_common.py、统一入口是本次新写的作者候选，尚未经独立审查。
tools/upstream/legacy_reference：字节未改的旧绘图脚本、reproduce.py/reproduce_v3.py和旧requirements，仅作出处/完整旧环境入口参考；薄包不含其完整实施/审计/标签/trace依赖，不能直接用这些旧adapter宣称完整重放。
reference：复制的原纸面产物/MAST展示，用于生成后的比较；这些“copy”本身不是再生。
results/actual_validation_02及MAST对应输出：本次实际代码生成，RUN_RECEIPT含完整命令、stdout及子回执。
validation：FINAL_PDF_RASTER_COMPARISON.json记录最终7图像素比较，另含当前正文内联MAST表绑定及最终实测范围。首轮比较单独保留。
assembly_notes：原字节复制与CSV投影回执；KEY_BINDINGS、MANIFEST给当前候选散列。
PAPER_TO_ARTIFACT.csv：逐图/表/段落入口与缺口；GAPS_AND_LIMITATIONS.txt必须一起保留。
LICENSE_NOTICES.txt只陈述已知来源/许可，未替作者选原创软件许可。依赖库代码和二进制未打包，仅保留其既有许可文本。

明确未执行
没有full method/saved-label replay、原raw-proof审计、Native/CI、GPU/模型推理、重新计时或重新抽取熵/bootstrap。
没有读取新Source192及其旧4case private/raw/maps/outputs；旧D公开oracle192是另一项已许可历史结果。没有MAST B raw payload/RNG或未闭合结果。没有读取大型MAD JSON，没有hash整个环境，也没有新profiling。
旧约703MB Artifact_v3 ZIP属于旧版本，且不含完整07_Raw_Trace_Archives；本候选没有复制/解压它或8.59GB原始trace。
本候选未做跨机clean-room安装验证，未给出“全部实验重跑”“完全复现”或“submission READY”结论。新wrapper/投影、版权许可和最终外层发布材料仍须Root/非作者整合审查。
