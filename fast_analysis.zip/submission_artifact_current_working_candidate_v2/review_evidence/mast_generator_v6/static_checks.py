#!/usr/bin/env python3
"""Static V6 source and small closed-public-JSON checks. Never imports a generator."""
from pathlib import Path
from collections import Counter, defaultdict
from hashlib import sha256
import ast
import difflib
import json
import math
import os

HERE=Path(__file__).resolve().parent
R=HERE.parent
V5=R/'mast_publication_presentation_candidate_v5'
V6=R/'mast_publication_presentation_candidate_v6'
OLD=R/'mast_bound56_scientific_audit_final6_v1'
NEW=R/'mast_bound56_scientific_audit_final6_native_context_revalidated_v1'
ACTUAL=R/'mast_native_ci_revalidation_actual_result_review_v1/RESULT_READY.json'
TERMINAL=R/'mast_native_ci_environment_revalidation_request_v1/TERMINAL_RECEIPT.json'
COMPARISON=R/'mast_native_ci_environment_revalidation_request_v1/FULL56_COMPARISON.json'
TARGET={10:'ERROR',16:'ERROR',22:'VERIFIED_ONLINE_COMPLETE',28:'VERIFIED_ONLINE_COMPLETE',41:'VERIFIED_ONLINE_COMPLETE',47:'VERIFIED_ONLINE_COMPLETE',53:'VERIFIED_ONLINE_COMPLETE'}
CENSORS=[3,4,49,55]
PINS={V6/'MANIFEST.json':'c2ebb838bf23824aad1ff7a467d926c099c67438e2a047cfc010f78b5a7b7383',
 V6/'generator.py':'1b80013c4f4f249ae8cdbf26050f463a1b6ffe02e1da7d8e0e8b59baf29b679b',
 V5/'MANIFEST.json':'16b54f5ee6bad030906d0dca4aacc889f232c758891c18704a9a48b23907bbbb',
 V5/'generator.py':'fc7b085dfbff2d46ccba58e8d0e17ece44627a40ce79074da33f584193b64902',
 ACTUAL:'5cc6b20bc0a32acc4e0837df9f891432b04e6a5b61b7b82ed84c14d2321b71c0',
 TERMINAL:'439146ba6b0e3644dfc19a9e2f002e7267d4766c23bbcb3b0d81b1d4014b79a2',
 COMPARISON:'407ee129fed0a1230c1e97ca6b68b1c2b3870d1c82bb02918e39ae5f4566eba8',
 NEW/'SUMMARY.json':'c657e3f68438ff3ce0255495f0057762203cf6fed704c6436f006e152f58840d',
 NEW/'AUDIT_CLOSED.json':'4787dbf3c7b295af4c58d7b7b8533f5b6591db0867dac10a5c0779c743ce98c0',
 OLD/'SUMMARY.json':'23ac2fba2865bcebe9a3e06e968f3e7204d5eec2f39c3884a486f5eabb2f5ff1',
 OLD/'AUDIT_CLOSED.json':'6bc7adb9147561021b94c7367d600e3f933bd2f267e54664618742a4a3bc95ff',
 R/'submission_artifact_current_working_candidate_v1/MANIFEST.json':'ef94bf90796f75e1f07f9c29142039f2c0c2ff06e25fc2f72407c758786e3e30'}
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','ARROW_IO_THREADS'):
 os.environ[key]='1'
if os.getpriority(os.PRIO_PROCESS,0)<10:os.nice(10-os.getpriority(os.PRIO_PROCESS,0))

def need(ok,message):
 if not ok:raise AssertionError(message)
def digest(path):return sha256(Path(path).read_bytes()).hexdigest()
def pairs(items):
 out={}
 for key,val in items:
  need(key not in out,'duplicate JSON key');out[key]=val
 return out
def load(path):
 return json.loads(Path(path).read_text(),object_pairs_hook=pairs,parse_constant=lambda _:(_ for _ in ()).throw(ValueError('nonfinite JSON')))
def put(name,data):
 with (HERE/name).open('x') as stream:json.dump(data,stream,ensure_ascii=False,indent=2,allow_nan=False);stream.write('\n')
def integer(v,lo,hi):return type(v) is int and lo<=v<=hi
def snapshot(paths):return [{'path':str(p),'bytes':p.stat().st_size,'sha256':digest(p)} for p in sorted(paths)]

for path,expected in PINS.items():need(digest(path)==expected,'pin mismatch '+str(path))
mf=load(V6/'MANIFEST.json');listed={x['path']:x for x in mf['files']}
need(len(listed)==len(mf['files'])==5,'V6 manifest member count')
for rel,spec in listed.items():
 p=V6/rel;need(not p.is_symlink() and not Path(rel).is_absolute() and '..' not in Path(rel).parts,'unsafe manifest member')
 need(p.stat().st_size==spec['bytes'] and digest(p)==spec['sha256'],'V6 complete manifest mismatch')
need({str(p.relative_to(V6)) for p in V6.rglob('*') if p.is_file()}==set(listed)|{'MANIFEST.json'},'V6 unlisted extra or missing file')
need((V6/'PARENT_MANIFEST_V5.json').read_bytes()==(V5/'MANIFEST.json').read_bytes(),'parent manifest byte copy mismatch')

old_code=(V5/'generator.py').read_bytes();new_code=(V6/'generator.py').read_bytes()
insertion=b"+' & '+str(status['scientific_error'])"
need(new_code.count(insertion)==1 and new_code.replace(insertion,b'',1)==old_code,'runtime delta exceeds one E insertion')
expected_patch=''.join(difflib.unified_diff(old_code.decode().splitlines(True),new_code.decode().splitlines(True),fromfile='v5/generator.py',tofile='v6/generator.py'))
need((V6/'GENERATOR_DELTA.patch').read_text()==expected_patch,'frozen patch not the exact diff')
ot=ast.parse(old_code);nt=ast.parse(new_code)
def assignments(tree):
 return {n.targets[0].id:ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ('METHODS','LABELS','BUDGETS','CONTINUATION_SHA')}
constants=assignments(nt);methods=list(constants['METHODS']);budgets=list(constants['BUDGETS'])
need(constants==assignments(ot) and budgets==[75,150,225,300] and len(methods)==7,'fixed constants changed')
guards=['safe_member','planned_runs','authority_map','load_closed_audit','source_provenance','output_directory','fee_fields','inspect','export_tables','draw_heatmap']
functions={n.name:n for n in nt.body if isinstance(n,ast.FunctionDef)}
old_functions={n.name:n for n in ot.body if isinstance(n,ast.FunctionDef)}
guard_evidence=[]
for name in guards:
 a=ast.get_source_segment(old_code.decode(),old_functions[name]);b=ast.get_source_segment(new_code.decode(),functions[name])
 need(a==b,'guard/export function changed '+name)
 guard_evidence.append(dict(function=name,start_line=functions[name].lineno,end_line=functions[name].end_lineno,source_sha256=sha256(b.encode()).hexdigest(),byte_identical_to_V5=True))
parent_ready_path=R/'mast_publication_v5_independent_review_v1/IMPLEMENTATION_READY.json'
parent=load(parent_ready_path)
need(parent['implementation_ready'] is True and parent['generator_ref']['sha256']==PINS[V5/'generator.py'] and parent['candidate_manifest_ref']['sha256']==PINS[V5/'MANIFEST.json'],'V5 Ready binding mismatch')
scope=load(V6/'REVISION_SCOPE.json');actual=load(ACTUAL);terminal=load(TERMINAL);comparison=load(COMPARISON)
need(scope['parent_manifest_sha256']==PINS[V5/'MANIFEST.json'] and scope['parent_generator_sha256']==PINS[V5/'generator.py'],'scope parent mismatch')
need(scope['actual_result_ready_ref']=={'path':str(ACTUAL),'sha256':PINS[ACTUAL]} and scope['actual_terminal_ref']=={'path':str(TERMINAL),'sha256':PINS[TERMINAL]},'scope external readiness mismatch')
need(actual['status']=='READY_FOR_REPORTING_AMENDED_AUD9_FULL56_WITH_RETAINED_ERRORS' and actual['new_audit_root']==str(NEW),'actual result admission mismatch')
need(actual['terminal_ref']==scope['actual_terminal_ref'] and actual['comparison_ref']=={'path':str(COMPARISON),'sha256':PINS[COMPARISON]},'actual evidence references mismatch')
need(terminal['status']=='AMENDED_AUD9_CLOSED_AND_FULL56_COMPARISON_PASSED' and terminal['exit_code']==0 and terminal['verification_run_number']==2,'terminal not closed successful second verification')
need(terminal['original_audit_unchanged'] and terminal['no_new_method_model_data_or_study_RNG'] and terminal['no_result_or_version_selection'],'terminal scope weakened')
need(comparison['status']=='PASS_FULL56_DETERMINISTIC_AMENDMENT_COMPARISON' and comparison['all49_non_target_CASE_bytes_identical'] and comparison['no_case_or_best_version_selection'],'full56 comparison mismatch')
for doc in (actual,terminal,comparison):
 need(doc['new_summary_sha256']==PINS[NEW/'SUMMARY.json'] and doc['new_closed_sha256']==PINS[NEW/'AUDIT_CLOSED.json'],'new pair differs across binding chain')
need(scope['approved_input_pair_candidate']=={'summary_sha256':PINS[NEW/'SUMMARY.json'],'audit_closed_sha256':PINS[NEW/'AUDIT_CLOSED.json']},'V6 scope pair mismatch')
need(comparison['old_summary_sha256']==PINS[OLD/'SUMMARY.json'] and comparison['old_closed_sha256']==PINS[OLD/'AUDIT_CLOSED.json'],'comparison old history mismatch')
summary=load(NEW/'SUMMARY.json');closed=load(NEW/'AUDIT_CLOSED.json');old_summary=load(OLD/'SUMMARY.json')
need(closed['summary_sha256']==PINS[NEW/'SUMMARY.json'] and closed['context']==summary['context'],'new closed context/pair mismatch')
need(summary['schema']=='disjoint-source-fixed56-scientific-audit-summary/v1' and summary['planned_rows']==56,'summary ABI mismatch')
need(summary['continuation_plan_sha256']==constants['CONTINUATION_SHA'],'plan mismatch')
need(summary['authority_hashes']==old_summary['authority_hashes'] and summary['source_provenance']==old_summary['source_provenance'] and summary['truth28']==old_summary['truth28'],'authority/source/truth changed')
inventory={x['path']:x for x in closed['files']}
need(len(inventory)==len(closed['files'])==58,'new closure inventory count mismatch')
need({n for n in inventory if Path(n).name.startswith('CASE_')}=={f'CASE_{i:03d}.json' for i in range(56)},'full56 inventory missing or extra')
for rel,spec in inventory.items():
 p=NEW/rel
 need(not p.is_symlink() and not Path(rel).is_absolute() and '..' not in Path(rel).parts and 'private' not in Path(rel).parts,'unsafe closed member')
 need(p.stat().st_size==spec['bytes'] and digest(p)==spec['sha256'],'closed inventory SHA/size mismatch')
need(inventory['SUMMARY.json']['sha256']==PINS[NEW/'SUMMARY.json'],'summary absent from inventory')
need(set(summary['methods'])==set(methods),'missing method')
points={}
for method in methods:
 block=summary['methods'][method]
 need(block['planned_replicates']==8 and len(block['points'])==8,'eight planned paths not retained')
 for point in block['points']:
  key=(method,point['replicate_id']);need(key not in points and integer(key[1],0,7),'duplicate or invalid replicate');points[key]=point
 need({x['replicate_id'] for x in block['points']}==set(range(8)),'path omitted')
records=[];state=Counter();admin=Counter();unchanged=[];fee_tuples=[];source_eligible={}
aggregate={m:{b:0 for b in budgets} for m in methods}
status={m:Counter() for m in methods}
for i in range(56):
 path=NEW/f'CASE_{i:03d}.json';op=OLD/path.name;case=load(path);old=load(op)
 rep,offset=divmod(i,7);method=methods[(rep%7+offset)%7]
 need(case['run']==dict(slot=i,replicate_id=rep,method_id=method,run_id=f'rep{rep:02d}__{method}'),'case identity/order mismatch')
 if i not in TARGET:
  need(path.read_bytes()==op.read_bytes(),'non-target case mutated');unchanged.append(i)
 else:need(case['scientific_status']==TARGET[i] and old['scientific_status']=='UNKNOWN','target status not retained')
 need(case['run']==old['run'] and case['source_case']==old['source_case'] and case['source_scientific_credit_allowed']==old['source_scientific_credit_allowed'],'source identity or eligibility changed')
 primary=case['whole28_primary'];point=points[method,rep]
 need(set(primary)=={str(b) for b in budgets} and all(type(primary[str(b)]) is bool for b in budgets),'four boolean endpoints absent')
 flags=[primary[str(b)] for b in budgets];need(flags==sorted(flags),'nonmonotone endpoints')
 need(point['primary']==primary and point['scientific_status']==case['scientific_status'],'point/case mismatch')
 if 'charge' in point:need(point['charge']==case['charge'],'point/case charge mismatch')
 charge=case.get('charge') or {};oldcharge=old.get('charge') or {}
 fee_keys=('known_durable_submitted_prefix','exact_total','exact_tail')
 need(tuple(charge.get(k) for k in fee_keys)==tuple(oldcharge.get(k) for k in fee_keys),'numerical fee/tail changed')
 prefix=charge.get('known_durable_submitted_prefix');exact=charge.get('exact_total');tail=charge.get('exact_tail')
 if prefix is not None:need(integer(prefix,0,300),'prefix outside budget')
 if exact is None:need(tail in (None,'UNKNOWN'),'unknown total has known tail')
 else:need(integer(exact,0,300) and exact==prefix and tail=='KNOWN','invalid exact cost')
 if any(flags):
  need(case['status']=='WORKER_SEALED' and case['scientific_status']=='VERIFIED_ONLINE_COMPLETE' and case['source_scientific_credit_allowed'] is True and type(exact) is int and tail=='KNOWN' and case.get('sticky_errors')==[] and case.get('issues')==[],'unsafe completion credit')
  need(all(not primary[str(b)] or exact<=b for b in budgets),'overbudget credit')
 if i in CENSORS:
  need(case['status']=='CENSORED_UNKNOWN' and case['scientific_status']=='UNKNOWN' and not any(flags) and exact is None and tail=='UNKNOWN','censor promoted or expense guessed')
 if i in (3,4):need(prefix==0,'startup durable prefix changed')
 if i==55:need(prefix==50,'known nonzero55prefix erased')
 if i in (10,16):need(case.get('sticky_errors')==[{'kind':'NATIVE_TRUE_COUNT_EXCLUDED','n':99,'stream':['B','2.2']}],'historical error changed')
 scientific=case['scientific_status'];administrative=case['status']
 need(scientific in ('VERIFIED_ONLINE_COMPLETE','VERIFIED_INCOMPLETE','UNKNOWN','ERROR'),'unrecognized scientific status')
 group='normal' if administrative=='WORKER_SEALED' else 'censor' if administrative in ('CENSORED_UNKNOWN','CLAIM_CONFLICT_UNKNOWN') else 'unrun' if administrative=='UNRUN_GLOBAL_STOP' else 'other'
 status[method][group]+=1;status[method]['E']+=scientific=='ERROR';status[method]['V?']+=scientific=='UNKNOWN';state[scientific]+=1;admin[administrative]+=1
 for b in budgets:aggregate[method][b]+=primary[str(b)]
 fee_tuples.append(dict(slot=i,known_prefix=prefix,exact_total=exact,exact_tail=tail,numerical_fee_tuple_unchanged=True))
 records.append(dict(slot=i,method=method,replicate=rep,scientific_status=scientific,admin_status=administrative,primary=primary,exact=exact))
need(len(unchanged)==49 and dict(state)=={'VERIFIED_ONLINE_COMPLETE':50,'UNKNOWN':4,'ERROR':2},'new complete56 status totals mismatch')
need(actual['new_status_counts']==dict(state) and actual['fixed_target_statuses']=={str(k):v for k,v in TARGET.items()},'actual ResultReady counters mismatch')
method_data=[]
for method,label in zip(methods,constants['LABELS']):
 for b in budgets:need(summary['methods'][method]['whole28_correct_complete'][str(b)]=={'denominator':8,'successes':aggregate[method][b]},'aggregate denominator/numerator mismatch')
 need(sum(status[method][k] for k in ('normal','censor','unrun','other'))==8,'admin denominator changed')
 eligible=[x['exact'] for x in records if x['method']==method and x['primary']['300']]
 need(len(eligible)==aggregate[method][300] and all(type(x) is int for x in eligible),'conditional cost eligibility changed')
 method_data.append(dict(method=method,label=label,all_four_budget_successes=aggregate[method],denominator=8,
  conditional_cost_min=min(eligible) if eligible else None,conditional_cost_max=max(eligible) if eligible else None,
  N=status[method]['normal'],C=status[method]['censor'],E=status[method]['E'],verification_unknown=status[method]['V?']))
before=snapshot(list(PINS)+[V6/n for n in listed]+[parent_ready_path]+[NEW/n for n in inventory])
put('EVIDENCE.json',dict(schema='independent-v6-one-line-static-review-evidence/v1',all_checks_pass=True,
 exact_byte_delta='Single38byte insertion of already-computed scientific_error into cost_lines only',
 exact_patch_matches=True,full_manifest_files_verified=5,candidate_actual_files=6,
 prior_V5_ready_sha256=digest(parent_ready_path),unchanged_guard_function_bytes=guard_evidence,
 new_ResultReady_sha256=PINS[ACTUAL],terminal_sha256=PINS[TERMINAL],comparison_sha256=PINS[COMPARISON],
 input_pair=dict(summary_sha256=PINS[NEW/'SUMMARY.json'],closed_sha256=PINS[NEW/'AUDIT_CLOSED.json']),
 new_closed_inventory_members=58,all_closed_inventory_hashes_and_sizes_pass=True,all56_identity_and_point_ABI_checks_pass=True,
 all49_nontarget_CASE_bytes_identical=True,unchanged_non_target_slots=unchanged,
 permanent_censors=CENSORS,censor55_known_prefix_retained=50,all56_numerical_fee_tuples_unchanged=True,
 authority_risk_provenance_truth_and_plan_unchanged=True,status_counts=dict(state),administrative_counts=dict(admin),
 target_statuses=TARGET,seven_column_order=['Program','k300/8','conditional exact-cost range','N','C','E','V?'],
 method_numeric_expectations_only_not_actual_render=method_data,fee_tuple_checks=fee_tuples,
 original7_UNKNOWN_history_retained=True,old_fastartifact_manifest_unchanged=True,
 actual_generator_or_draw_calls=0,new_CI_method_model_RNG_calls=0,new_Source192_B_private_or_source_tree_opens=0,
 static_parse_and_hash_only=True,nice=os.getpriority(os.PRIO_PROCESS,0),input_file_bindings=before))
need(before==snapshot([Path(x['path']) for x in before]),'input changed during static review')
put('INPUTS_UNCHANGED.json',dict(all_bound_paths_sizes_and_hashes_unchanged=True,input_bindings=len(before),writes_to_inputs=0))
print(json.dumps(dict(status='PASS_NARROW_V5_TO_V6_STATIC_AND_CLOSED_PUBLIC_BINDINGS',manifest_files=5,
 single_insertion_bytes=len(insertion),closed_inventory=58,cases=56,unchanged_non_targets=49,status_counts=dict(state),actual_generator_calls=0)))
