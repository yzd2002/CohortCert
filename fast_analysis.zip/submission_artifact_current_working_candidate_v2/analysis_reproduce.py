#!/usr/bin/env python3
"""Working current-paper analysis candidate; no full experiment/replay admission.

All modes operate on explicit, pinned, local public summaries/projected results.
The unchanged MAST V6 generator keeps its own closure and output-root checks.
The active pair is the one fixed full56 environment amendment. The old first
audit remains history; this interface offers no result/version selection.
"""
import argparse
from collections import Counter
import json
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "tools"))
from artifact_common import (
    checked_json, checked_path, digest, fresh_output, low_impact_environment,
    member, verify_runtime_inputs, write_json,
)

SUMMARY_SHA = "c657e3f68438ff3ce0255495f0057762203cf6fed704c6436f006e152f58840d"
CLOSED_SHA = "4787dbf3c7b295af4c58d7b7b8533f5b6591db0867dac10a5c0779c743ce98c0"
OLD_SUMMARY_SHA = "23ac2fba2865bcebe9a3e06e968f3e7204d5eec2f39c3884a486f5eabb2f5ff1"
OLD_CLOSED_SHA = "6bc7adb9147561021b94c7367d600e3f933bd2f267e54664618742a4a3bc95ff"
AMENDMENT_TARGETS = {10: "ERROR", 16: "ERROR", 22: "VERIFIED_ONLINE_COMPLETE",
                     28: "VERIFIED_ONLINE_COMPLETE", 41: "VERIFIED_ONLINE_COMPLETE",
                     47: "VERIFIED_ONLINE_COMPLETE", 53: "VERIFIED_ONLINE_COMPLETE"}


def execute(argv):
    result = subprocess.run(argv, text=True, capture_output=True)
    if result.stdout:
        print(result.stdout, end="")
    if result.stderr:
        print(result.stderr, end="", file=sys.stderr)
    if result.returncode:
        raise RuntimeError(f"analysis command failed with exit status {result.returncode}")
    return {"argv": argv, "exit_code": result.returncode, "stdout": result.stdout, "stderr": result.stderr}


def primary(out):
    return execute([sys.executable, "-B", str(checked_path("tools/current_primary_table_renderer/render_primary_table.py")),
                    "--civil-summary", str(checked_path("inputs/public_summaries/FINAL_CONTROL_AND_MECHANISM_SUMMARY.json")),
                    "--go-summary", str(checked_path("inputs/public_summaries/FINAL_GOEMOTIONS_SUMMARY.json")),
                    "--outdir", str(out), "--compare-table", str(checked_path("reference/current_public_artifacts/generated_primary_table.tex"))])


def tables(out):
    return execute([sys.executable, "-B", str(checked_path("tools/summary_tables.py")), "tables", "--out", str(out)])


def legacy_summary(out):
    return execute([sys.executable, "-B", str(checked_path("tools/summary_tables.py")), "legacy-summary", "--out", str(out)])


def figures(out):
    return execute([sys.executable, "-B", str(checked_path("tools/portable_legacy_figures.py")), "--out", str(out)])


def amendment_history_check():
    """Public artifact consistency only; no method, CI or source-tree read."""
    result_path = checked_path("review_evidence/native_amendment_result/RESULT_READY.json")
    if digest(result_path) != "5cc6b20bc0a32acc4e0837df9f891432b04e6a5b61b7b82ed84c14d2321b71c0":
        raise ValueError("exact independent amendment result Ready required")
    terminal_path = checked_path("review_evidence/native_amendment_provenance/TERMINAL_RECEIPT.json")
    if digest(terminal_path) != "439146ba6b0e3644dfc19a9e2f002e7267d4766c23bbcb3b0d81b1d4014b79a2":
        raise ValueError("exact actual closed amendment terminal required")
    original = "inputs/mast_original56_public_audit/"
    active = "inputs/mast_native_revalidated56_public_audit/"
    if digest(checked_path(original + "SUMMARY.json")) != OLD_SUMMARY_SHA or digest(checked_path(original + "AUDIT_CLOSED.json")) != OLD_CLOSED_SHA:
        raise ValueError("original first-audit history differs")
    retained = []
    charge_metadata_changed = []
    fee_fields = ("known_durable_submitted_prefix", "exact_total", "exact_tail")
    states = Counter()
    for slot in range(56):
        old_path = checked_path(original + f"CASE_{slot:03d}.json")
        new_path = checked_path(active + f"CASE_{slot:03d}.json")
        old, new = json.loads(old_path.read_text()), json.loads(new_path.read_text())
        if slot not in AMENDMENT_TARGETS:
            if old_path.read_bytes() != new_path.read_bytes():
                raise ValueError("non-target original CASE bytes changed")
            retained.append(slot)
        elif new["scientific_status"] != AMENDMENT_TARGETS[slot]:
            raise ValueError("fixed amended target outcome differs; no case selection allowed")
        for key in ("run", "source_case", "source_scientific_credit_allowed"):
            if old.get(key) != new.get(key):
                raise ValueError("amendment changed a case identity/source provenance field")
        old_charge, new_charge = old.get("charge"), new.get("charge")
        if type(old_charge) is not dict or type(new_charge) is not dict:
            if type(old_charge) is not type(new_charge) or old_charge != new_charge:
                raise ValueError("amendment changed unavailable charge metadata")
        else:
            for key in fee_fields:
                if key not in old_charge or key not in new_charge or type(old_charge[key]) is not type(new_charge[key]) or old_charge[key] != new_charge[key]:
                    raise ValueError("amendment changed a numerical fee prefix/total/tail field")
            if old_charge != new_charge:
                charge_metadata_changed.append(slot)
        states[new["scientific_status"]] += 1
    if len(retained) != 49 or dict(states) != {"VERIFIED_ONLINE_COMPLETE": 50, "UNKNOWN": 4, "ERROR": 2}:
        raise ValueError("fixed50/2/4 full56 amendment state differs")
    return {"all49_non_target_CASE_bytes_identical": True, "unchanged_case_slots": retained,
            "all56_run_source_and_numerical_fee_fields_unchanged": True,
            "numerical_fee_fields_compared": list(fee_fields),
            "charge_audit_metadata_shape_changed_slots": charge_metadata_changed,
            "old_and_new_complete_charge_objects_retained_in_public_CASE_history": True,
            "scientific_status_counts": dict(states),
            "target_outcomes": {str(k): v for k, v in AMENDMENT_TARGETS.items()},
            "old_pair_retained_as_history": True, "result_or_best_version_selection": False,
            "full_scientific_audit_repeated_by_this_check": False}


def mast(out):
    out = Path(out).resolve()
    fixed_parent = ROOT / "MAST/mast_audited_publication_outputs"
    if out.parent != fixed_parent or out.exists():
        raise ValueError("MAST output must be a new direct child of " + str(fixed_parent))
    script = checked_path("MAST/reviewed_generator_v6/generator.py")
    code_sha = digest(script)
    if code_sha != "1b80013c4f4f249ae8cdbf26050f463a1b6ffe02e1da7d8e0e8b59baf29b679b":
        raise ValueError("exact reviewed MAST V6 generator required")
    for relative, expected in (
        ("MAST/reviewed_generator_v6/MANIFEST.json", "c2ebb838bf23824aad1ff7a467d926c099c67438e2a047cfc010f78b5a7b7383"),
        ("review_evidence/mast_generator_v6/IMPLEMENTATION_READY.json", "bc9e36048a66c2852b2a193339a6d2ebdeb92415462661a306386fb25bd96cd2"),
        ("reference/mast_native_revalidated_publication/OUTPUT_MANIFEST.json", "861ddd2cef3ba102b8a1a7f2e2cc3ee66883addffd59df27568ae6e4ebb0bc4b"),
    ):
        if digest(checked_path(relative)) != expected:
            raise ValueError("fixed V6 admission/golden binding differs")
    history = amendment_history_check()
    audit = checked_path("inputs/mast_native_revalidated56_public_audit/SUMMARY.json").parent
    result = execute([sys.executable, "-B", str(script), "--audit-dir", str(audit),
                      "--summary-sha256", SUMMARY_SHA, "--closed-sha256", CLOSED_SHA, "--output-dir", str(out)])
    comparisons = {}
    golden_manifest = checked_json("reference/mast_native_revalidated_publication/OUTPUT_MANIFEST.json")
    for item in golden_manifest["files"]:
        name = item["path"]
        if name.endswith((".tex", ".csv", ".txt")):
            comparisons[name] = {"generated_sha256": digest(out / name), "active_root_golden_sha256": item["sha256"],
                                 "byte_identical": digest(out / name) == item["sha256"]}
    if not all(x["byte_identical"] for x in comparisons.values()):
        raise ValueError("MAST public table/ledger output differs from the fixed amended Root golden")
    cost_rows = (out / "mast_audited_cost_range_rows.tex").read_text()
    if len(cost_rows.splitlines()) != 7 or any(len(row.split("&")) != 7 for row in cost_rows.splitlines()):
        raise ValueError("seven rows with Program/k300/Cost/N/C/E/V? columns required")
    paper = checked_path("reference/current_public_artifacts/mast_results.tex").read_text()
    paper_rows = re.search(r"\\midrule\s*\n(.*?)\\bottomrule", paper, re.S)
    if not paper_rows or paper_rows.group(1).strip() != cost_rows.strip() or "$E$" not in paper or r"\begin{tabular}{@{}lrrrrrr@{}}" not in paper:
        raise ValueError("provisional paper seven-column E-header/table binding differs")
    receipt = {"schema": "portable-exact-v6-amended-public-audit-presentation/v1", "status": "PASS_FIXED_AMENDED_PUBLIC_AUDIT_TO_PRESENTATION_ONLY",
               "exact_reviewed_generator_sha256": code_sha, "summary_sha256": SUMMARY_SHA, "audit_closed_sha256": CLOSED_SHA,
               "active_Root_golden_output_manifest_sha256": digest(checked_path("reference/mast_native_revalidated_publication/OUTPUT_MANIFEST.json")),
               "generated_output_manifest_sha256": digest(out / "OUTPUT_MANIFEST.json"), "amendment_history_check": history,
               "scientific_status_counts": history["scientific_status_counts"],
               "public_table_and_ledger_comparisons": comparisons,
               "cost_column_count": 7, "cost_column_order": ["Program", "k300/8", "conditional exact-cost range", "N", "C", "E", "V?"],
               "provisional_paper_inline_seven_rows_and_E_header_match": True,
               "original_source_absolute_provenance_strings_and_protection_checks_retained": True,
               "source_trees_or_raw_payloads_opened": False, "original_full_audit_admission_repeated": False,
               "Native_CI_method_model_or_entropy_calls": 0, "independently_admitted_closed_environment_amendment_used": True,
               "old_and_new_version_or_result_selection_allowed": False,
               "two_ERROR_cases_not_asserted_algorithm_bugs_or_wrong_final28": True,
               "universal_native_machine_coverage": "UNKNOWN; posthoc diagnostic is separate and not risk calibration",
               "relocation_scope": "The unchanged V6 generator derives PRESENTATION_ROOT from its new script location; writes remain a new direct child. All authority/source/closure guards remain; only the one admitted amended pair is active.",
               "generator_execution": dict(result),
               "new_wrapper_independently_reviewed": False}
    write_json(out / "PORTABLE_RENDER_RECEIPT.json", receipt)
    result["receipt"] = receipt
    return result


def verify_manifest():
    manifest = json.loads((ROOT / "MANIFEST.json").read_text())
    for item in manifest["files"]:
        path = member(item["path"])
        if not path.is_file() or path.stat().st_size != item["bytes"] or digest(path) != item["sha256"]:
            raise ValueError("candidate manifest mismatch: " + item["path"])
    return {"status": "PASS_CANDIDATE_FILE_INTEGRITY_ONLY", "verified_files": len(manifest["files"]),
            "submission_ready": False, "full_reproduction_pass": False}


def main():
    low_impact_environment()
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("mode", choices=("verify", "primary", "summary-tables", "legacy-summary", "legacy-figures", "mast", "all"))
    p.add_argument("--out", type=Path)
    p.add_argument("--run-id")
    a = p.parse_args()
    if a.mode == "verify":
        print(json.dumps(verify_manifest()))
        return
    checked = verify_runtime_inputs()
    if a.mode == "all":
        if not a.run_id or re.fullmatch(r"[A-Za-z0-9_-]{1,64}", a.run_id) is None:
            p.error("all requires a new --run-id with letters, digits, underscores or hyphens")
        out = ROOT / "results" / a.run_id
        mast_out = ROOT / "MAST/mast_audited_publication_outputs" / a.run_id
        if out.exists() or mast_out.exists():
            raise ValueError("run-id output already exists; choose a fresh run-id")
        fresh_output(out)
        jobs = {
            "primary": primary(out / "primary"),
            "summary_tables": tables(out / "summary_tables"),
            "legacy_summary": legacy_summary(out / "legacy_summary"),
            "legacy_figures": figures(out / "legacy_figures"),
            "mast": mast(mast_out),
        }
        receipt = {"schema": "working-current-paper-analysis-run/v1", "status": "PASS_EXECUTED_ANALYSIS_MODES_ONLY",
                   "runtime_pinned_files_checked": checked, "python_executable": sys.executable, "python_version": sys.version,
                   "nice_priority_at_least": 10, "numerical_thread_limits": 1, "arrow_io_thread_limit": 1, "jobs": jobs,
                   "full_experiment_or_clean_room_reproduction": False, "original_code_or_input_directories_changed": False,
                   "Source192_new_inputs_or_unclosed_Native_results_used": False, "submission_ready": False,
                   "new_wrapper_independently_reviewed": False}
        write_json(out / "RUN_RECEIPT.json", receipt)
        print(json.dumps({"status": receipt["status"], "receipt": str(out / "RUN_RECEIPT.json")}))
        return
    if a.out is None:
        p.error("this mode requires --out naming a fresh output directory")
    {"primary": primary, "summary-tables": tables, "legacy-summary": legacy_summary,
     "legacy-figures": figures, "mast": mast}[a.mode](a.out)


if __name__ == "__main__":
    try:
        main()
    except (ValueError, RuntimeError, OSError, KeyError) as error:
        raise SystemExit("Analysis candidate stopped: " + str(error))
