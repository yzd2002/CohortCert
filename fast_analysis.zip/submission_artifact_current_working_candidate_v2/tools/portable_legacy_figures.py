"""Redraw the six retained manuscript figures from small legacy public inputs.

Figures 1/2 and 3/4 execute byte-identical old plotting code with explicit local
paths. Figure 5 extracts its existing plotting section without the old entry's
unrelated bootstrap/table work. Figure 6 executes the byte-identical display
script on its two pinned source tables. No experimental method is executed.
"""
import argparse
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys

from artifact_common import (
    ROOT, checked_json, checked_path, digest, fresh_output,
    low_impact_environment, write_json,
)


def run_logged(argv, log):
    result = subprocess.run(argv, text=True, capture_output=True)
    Path(log).write_text(result.stdout + result.stderr)
    if result.returncode:
        raise RuntimeError(f"plot command failed ({result.returncode}); see {log}")


def oracle_plot(out):
    # This is the Fig5 section of the retained make_results_figures.py, with
    # only the evidence path/output path made explicit. Its mathematics,
    # denominator, method order, color, labels and plotting style are unchanged.
    import numpy as np
    import pandas as pd
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({"font.family": "serif", "font.serif": ["DejaVu Serif"], "font.size": 8,
                         "axes.linewidth": .6, "pdf.fonttype": 42, "ps.fonttype": 42,
                         "savefig.facecolor": "white"})
    methods = ["matched", "dual_greedy", "forecast"]
    names = {"matched": "Matched", "dual_greedy": "DifficultyGreedy", "forecast": "Forecast"}
    colors = {"matched": "#687782", "dual_greedy": "#00796b", "forecast": "#b05a16"}
    display = {"human": "Crowd reference", "model": "Model reference"}
    fig, axes = plt.subplots(1, 2, figsize=(7.1, 2.3), sharex=True, sharey=True)
    numbers = []
    plotted = {}
    grid = np.linspace(0, 1, 201)
    for ax, source in zip(axes, ("human", "model")):
        path = checked_path("inputs/legacy_analysis/revision_evidence/oracle_evaluation/" + source + "_headroom_cases_v2.csv")
        cases = pd.read_csv(path)
        unique = cases.drop_duplicates("case_id").copy()
        assert len(unique) == 96
        no_proof = unique.oracle_at_cap.eq("no_source_valid_proof_on_legal_paths")
        lb = pd.to_numeric(unique.oracle_lower_total, errors="coerce").to_numpy(dtype=float, copy=True)
        ub = pd.to_numeric(unique.oracle_upper_total, errors="coerce").to_numpy(dtype=float, copy=True)
        lb[no_proof.to_numpy()] = np.inf
        ub[no_proof.to_numpy()] = np.inf
        assert np.all(np.isfinite(lb) | no_proof) and np.all(np.isfinite(ub) | no_proof) and np.all(lb <= ub)
        caps = unique.cap.to_numpy()
        lower = np.array([np.mean(ub / caps <= t) for t in grid])
        upper = np.array([np.mean(lb / caps <= t) for t in grid])
        ax.fill_between(100 * grid, 100 * lower, 100 * upper, step="post", color="#d4e3ed", alpha=.85, label="Verified oracle bracket")
        ax.step(100 * grid, 100 * lower, where="post", color="#69899e", lw=.6)
        ax.step(100 * grid, 100 * upper, where="post", color="#69899e", lw=.6)
        curves = {}
        for method in methods:
            z = cases[cases.method.eq(method)].copy()
            assert len(z) == 96
            ok = z.correct_complete.astype(str).eq("True")
            costs = np.sort((z.loc[ok, "actual_calls"] / z.loc[ok, "cap"]).to_numpy())
            curve = np.array([(costs <= t).sum() / 96 for t in grid])
            assert np.all(curve <= upper + 1e-12)
            ax.step(100 * grid, 100 * curve, where="post", color=colors[method], lw=1.1, label=names[method])
            curves[method] = curve.tolist()
        numbers.append({"source": source, "cases": 96, "within_cap_proof_upper": int(np.sum(ub <= caps)),
                        "above_cap_lower_or_no_proof": int(np.sum(lb > caps)), "no_legal_source_valid_proof": int(no_proof.sum())})
        plotted[source] = {"denominator": 96, "fraction_call_cap": grid.tolist(),
                           "oracle_completion_lower": lower.tolist(), "oracle_completion_upper": upper.tolist(),
                           "method_completion_fractions": curves}
        ax.spines[["top", "right"]].set_visible(False)
        ax.grid(alpha=.18, lw=.5)
        ax.set_axisbelow(True)
        ax.tick_params(labelsize=7.5)
        ax.set_xlim(0, 100)
        ax.set_ylim(0, 100)
        ax.set_xlabel("Request call cap used (%)", fontsize=8)
        ax.set_title(display[source], fontsize=8.5)
    axes[0].set_ylabel("Selected cases complete (%)", fontsize=8)
    h, labels = axes[0].get_legend_handles_labels()
    fig.legend(h, labels, ncol=4, loc="upper center", bbox_to_anchor=(.54, 1.09), frameon=False, fontsize=7.4)
    fig.subplots_adjust(wspace=.15, top=.87, bottom=.23)
    for ext in ("pdf", "svg"):
        fig.savefig(out / ("fig_oracle_v2." + ext), bbox_inches="tight", pad_inches=.025)
    fig.savefig(out / "fig_oracle_v2.png", bbox_inches="tight", pad_inches=.025, dpi=190)
    plt.close(fig)
    write_json(out / "ORACLE_PLOT_DATA.json", {"scope": "Legacy v3 public oracle192 only; no new Source192 input.",
                                              "numbers": numbers, "plotted_data": plotted})
    return numbers


def main(out):
    out = fresh_output(out)
    structure = out / "structure"
    script = checked_path("tools/upstream/legacy_reference/paper_figures/make_structure_figures.py")
    metadata = checked_path("inputs/legacy_metadata/metadata_only_snapshot.parquet")
    run_logged([sys.executable, "-B", str(script), "--workspace", str(metadata.parent), "--out", str(structure)],
               out / "structure.stdout.txt")
    v3 = out / "v3"
    v3.mkdir()
    script = checked_path("tools/upstream/legacy_reference/v3_evidence/make_figures_v3.py")
    spec = importlib.util.spec_from_file_location("retained_v3_plotter", script)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.ROOT = ROOT / "inputs/legacy_analysis/v3_evidence"
    module.OLD = ROOT / "inputs/legacy_analysis/revision_evidence"
    module.OUT = v3
    module.main()
    oracle = out / "oracle"
    oracle.mkdir()
    oracle_numbers = oracle_plot(oracle)
    runtime = out / "runtime"
    runtime.mkdir()
    for name in ("make_display_figure_v2.py", "source_planned_units_23.csv", "source_process_costs.json", "SOURCE_BINDINGS.json"):
        shutil.copy2(checked_path("tools/upstream/runtime_display/" + name), runtime / name)
    run_logged([sys.executable, "-B", str(runtime / "make_display_figure_v2.py")], out / "runtime.stdout.txt")
    figure_paths = {
        "fig_main_v2.pdf": structure / "fig_main_v2.pdf",
        "fig_natural_overlap_v2.pdf": structure / "fig_natural_overlap_v2.pdf",
        "fig_completion_v3.pdf": v3 / "fig_completion_v3.pdf",
        "fig_mechanisms_v3.pdf": v3 / "fig_mechanisms_v3.pdf",
        "fig_oracle_v2.pdf": oracle / "fig_oracle_v2.pdf",
        "fig_runtime_v2.pdf": runtime / "fig_runtime_v2.pdf",
    }
    figures = {}
    for name, generated in figure_paths.items():
        reference = checked_path("reference/current_public_artifacts/" + name)
        figures[name] = {"generated_path": str(generated), "generated_sha256": digest(generated),
                         "reference_sha256": digest(reference), "pdf_byte_identical": generated.read_bytes() == reference.read_bytes(),
                         "generation_operation": "new_plot_written_by_code; reference_PDF_not_used_for_generation"}
    projection = checked_json("assembly_notes/LEGACY_CSV_PROJECTION_RECEIPT.json")
    curve_data = json.loads((v3 / "FIGURE_DATA_V3.json").read_text())["completion"]
    curve_rows = [row for block in curve_data.values() for row in block.values()]
    if len(curve_rows) != 13 or any(row["n"] != 4640 for row in curve_rows):
        raise ValueError("all 13 original 4640-unit completion curves must remain")
    receipt = {"schema": "portable-six-legacy-figures-reproduction/v1", "status": "PASS_DISPLAY_REGENERATION_ONLY",
               "figures": figures, "figure_count": 6, "completion_curves": len(curve_rows),
               "primary_planned_units_across_curves": sum(row["n"] for row in curve_rows),
               "old_projected_public_csv_rows": sum(s["retained_rows"] for s in projection["files"]),
               "no_projection_outcome_filter": True, "oracle_numbers": oracle_numbers,
               "runtime_scope": "Redraw of all retained 23 observations; no model/timing repetition.",
               "upstream_v3_metadata_status_scope": "The inherited complete_from_full_audited_data string describes the old public provenance; this run performed no new audit.",
               "method_model_Native_calls": 0, "fresh_entropy_or_bootstrap_draws": 0,
               "new_Source192_or_MAST_raw_inputs_read": False, "independent_review_of_new_wrapper": False}
    write_json(out / "FIGURES_RECEIPT.json", receipt)
    return receipt


if __name__ == "__main__":
    low_impact_environment()
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--out", required=True)
    a = p.parse_args()
    result = main(a.out)
    print(json.dumps({"status": result["status"], "figure_count": result["figure_count"],
                      "primary_planned_units_across_curves": result["primary_planned_units_across_curves"]}))
