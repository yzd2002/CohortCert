"""Original publication figures: illustrative mechanism and frozen metadata.

No model/source outcome is manufactured here. Figure1 is explicitly schematic;
the metadata figure reads the frozen membership snapshot and writes its numbers.
"""
from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
import numpy as np
import pyarrow.parquet as pq

ROOT=Path(__file__).resolve().parent
plt.rcParams.update({'font.family':'serif','font.serif':['DejaVu Serif'],
 'font.size':8,'pdf.fonttype':42,'ps.fonttype':42,'axes.linewidth':.6,
 'savefig.facecolor':'white','mathtext.fontset':'dejavuserif'})
NAVY='#164567';TEAL='#00796b';ORANGE='#b05a16';GRAY='#57616c';PALE='#f3f6f8'


def save(fig,name):
 fig.savefig(ROOT/(name+'.pdf'),bbox_inches='tight',pad_inches=.025)
 fig.savefig(ROOT/(name+'.svg'),bbox_inches='tight',pad_inches=.025)
 fig.savefig(ROOT/(name+'.png'),bbox_inches='tight',pad_inches=.025,dpi=190)
 plt.close(fig)


def box(ax,x,y,w,h,text,fc=PALE,ec=NAVY,size=8):
 ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.008,rounding_size=0.015',facecolor=fc,edgecolor=ec,linewidth=.65,clip_on=False))
 ax.text(x+w/2,y+h/2,text,ha='center',va='center',fontsize=size,color=NAVY,linespacing=1.35)


def mechanism():
 fig=plt.figure(figsize=(7.1,2.38));ax=fig.add_axes([.01,.02,.98,.96]);ax.set_xlim(0,1);ax.set_ylim(0,1);ax.axis('off')
 for x,t in ((.0,'(a) Signed shared support'),(.355,'(b) Observed count evidence'),(.705,'(c) Every decision needs a value')):
  ax.text(x,.98,t,fontsize=8.4,fontweight='bold',color=NAVY,va='top')
 ax.text(.155,.84,r'$|A|=100,\ |B|=80,\ |A\cap B|=20$',ha='center',fontsize=8)
 specs=[(.0,.095,'80',r'$1/100$'),(.105,.095,'20',r'$-1/400$'),(.21,.095,'60',r'$-1/80$')]
 names=[r'$A\setminus B$',r'$A\cap B$',r'$B\setminus A$']
 for idx,(x,w,n,a) in enumerate(specs):
  box(ax,x,.505,w,.215,names[idx]+'\n'+n+' records',fc='#e5f0f3' if idx==1 else PALE,size=7.6)
  ax.text(x+w/2,.445,a,ha='center',fontsize=8.2,color=NAVY)
 ax.text(.155,.332,r'$\theta=K_1/100-K_2/400-K_3/80$',ha='center',fontsize=8.1)
 ax.annotate('',xy=(.345,.59),xytext=(.315,.59),arrowprops={'arrowstyle':'->','lw':.9,'color':NAVY})
 for y,txt in ((.735,r'$K_1\in[40,48]$'),(.6,r'$K_2\in[8,12]$'),(.465,r'$K_3\in[20,24]$')):
  box(ax,.365,y-.065,.23,.105,txt,size=8)
 ax.text(.48,.285,r'$\theta\in[0.07,\ 0.21]$',ha='center',fontsize=8.8,color=NAVY)
 ax.annotate('',xy=(.69,.59),xytext=(.61,.59),arrowprops={'arrowstyle':'->','lw':.9,'color':NAVY})
 for y,txt,status,col in ((.76,r'$D_1:\ \theta>0.05$','True',TEAL),(.58,r'$D_2:\ \theta<0.06$','False',ORANGE),(.40,r'$D_3:\ |\theta|<0.10$','Unresolved',GRAY)):
  ax.text(.705,y,txt,fontsize=8.4,color=NAVY,va='center')
  ax.text(.995,y,status,fontsize=8.1,color=col,ha='right',va='center',fontweight='bold')
 ax.text(.85,.235,'Request remains incomplete',ha='center',fontsize=8,color=GRAY)
 ax.plot([0,1],[.177,.177],color='#c5cdd4',lw=.6)
 labels=[(.10,'Allocation policy'),(.365,'Uniform-prefix read'),(.645,'Per-record sticky CS'),(.925,'Exact proof check')]
 for x,t in labels:ax.text(x,.075,t,ha='center',va='center',fontsize=7.7,color=NAVY)
 for x1,x2 in ((.195,.25),(.486,.535),(.765,.835)):
  ax.annotate('',xy=(x2,.075),xytext=(x1,.075),arrowprops={'arrowstyle':'->','lw':.8,'color':NAVY})
 save(fig,'fig_main_v2')


def overlap():
 groups=['male','female','LGBTQ','christian','muslim','other_religions','black','white']
 data=pq.read_table(WORKSPACE/'metadata_only_snapshot.parquet',columns=['mentions_'+g for g in groups]).to_pandas()
 x=data.to_numpy(dtype=np.int64);n=x.sum(0);inter=x.T@x;degree=x.sum(1);counts=np.bincount(degree,minlength=9)[1:]
 fig,(ax,bx)=plt.subplots(1,2,figsize=(7.1,2.55),gridspec_kw={'width_ratios':[1.12,.88]})
 labels=['Male','Female','LGBTQ','Christian','Muslim','Other religions','Black','White']
 img=ax.imshow(inter,cmap='Blues',vmin=0,vmax=10000)
 for i in range(8):
  for j in range(8):ax.text(j,i,f'{inter[i,j]/1000:.1f}',ha='center',va='center',fontsize=6.8,color='white' if inter[i,j]>5500 else NAVY)
 ax.set_xticks(range(8),labels,rotation=42,ha='right',fontsize=6.3)
 ax.set_yticks(range(8),labels,fontsize=6.6)
 ax.set_xticks(np.arange(-.5,8,1),minor=True);ax.set_yticks(np.arange(-.5,8,1),minor=True)
 ax.grid(which='minor',color='white',linewidth=.7);ax.tick_params(which='both',length=0)
 ax.set_title('(a) Intersections (thousands of rows)',fontsize=8.4,pad=7)
 bars=bx.bar(np.arange(1,9),counts/len(x)*100,color=[NAVY]+[TEAL]*7,width=.68)
 bx.set_xlabel('Number of mention cohorts per comment',fontsize=7.8)
 bx.set_ylabel('Frozen rows (%)',fontsize=7.8)
 bx.set_xticks(range(1,9));bx.tick_params(labelsize=7)
 bx.set_ylim(0,82);bx.grid(axis='y',alpha=.2,lw=.5);bx.set_axisbelow(True)
 for k,c in enumerate(counts):
  if c:bx.text(k+1,c/len(x)*100+1.1,f'{c:,}',ha='center',fontsize=6.8)
 bx.spines[['right','top']].set_visible(False)
 bx.set_title('(b) Natural multiple membership',fontsize=8.4,pad=7)
 fig.subplots_adjust(left=.105,right=.99,bottom=.26,top=.88,wspace=.39)
 save(fig,'fig_natural_overlap_v2')
 receipt={'snapshot_rows':len(x),'groups':groups,'group_sizes':n.tolist(),'intersection_counts':inter.tolist(),'degree_counts':counts.tolist(),'multi_membership_rows':int((degree>=2).sum()),'scope':'Existing crowd-annotated identity mentions; not author identities or population representativeness.'}
 (ROOT/'figure_metadata_numbers.json').write_text(json.dumps(receipt,indent=2)+'\n')


if __name__=='__main__':
 import argparse
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--workspace',type=Path,required=True)
 parser.add_argument('--out',type=Path,required=True)
 args=parser.parse_args();WORKSPACE=args.workspace.resolve();ROOT=args.out.resolve();ROOT.mkdir(parents=True,exist_ok=True)
 mechanism();overlap()
