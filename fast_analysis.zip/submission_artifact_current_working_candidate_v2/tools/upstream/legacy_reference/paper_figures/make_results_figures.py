"""Rebuild publication tables/plots from independently verified frozen evidence.

Do not run during the separate real-query timing collection. No model is loaded
and no acquisition policy is executed. Call --evidence-root on a relocated pack.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os


def prevent_live_timing():
    proc=Path('/proc')
    if not proc.exists():return
    for p in proc.iterdir():
        if not p.name.isdigit() or int(p.name)==os.getpid():continue
        try:args=[s for s in (p/'cmdline').read_bytes().decode(errors='replace').split('\0') if s]
        except (OSError,PermissionError):continue
        if any(Path(a).name=='run_runtime.py' for a in args) and '--mode' in args:
            mode=args[args.index('--mode')+1]
            if mode in ('run','worker'):raise RuntimeError('Finish the live timing collector before plotting or scanning result tables.')


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--evidence-root',type=Path,default=Path(__file__).resolve().parent.parent)
    ap.add_argument('--out',type=Path,default=Path(__file__).resolve().parent)
    a=ap.parse_args();prevent_live_timing()
    import numpy as np
    import pandas as pd
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    w=a.evidence_root.resolve();out=a.out.resolve();out.mkdir(parents=True,exist_ok=True)
    summary_path=w/'independent_analysis/final_two_sources_independent_summary.json'
    summary_bytes=summary_path.read_bytes()
    assert hashlib.sha256(summary_bytes).hexdigest()=='55e589095788fcf390075f51bca2b091d4f02b6ad87dfbe718bf70333068599a'
    summary=json.loads(summary_bytes)
    assert summary['audited_rows']==32960 and summary['audit_failures']==0
    protocol=json.loads((w/'independent_analysis/analysis_protocol_before_outcomes.json').read_text())
    frames=[]
    for folder in ['grid_human50_v1','grid_model50_v1','grid_boundary_human50_v1','grid_boundary_model50_v1']:
        completed=json.loads((w/folder/'results/completion.json').read_text())
        assert completed['status']=='complete' and completed['missing_planned_rows']==0
        for p in sorted((w/folder/'results/shards').glob('*.csv')):frames.append(pd.read_csv(p))
    df=pd.concat(frames,ignore_index=True)
    assert len(df)==32960 and df['run_key'].is_unique
    df['ok']=df.correct_complete.astype(str).eq('True')
    df['subtype']=df.summary_subtype.fillna('')
    assert (df.semantic_calls<=df.budget).all() and (df.support_size>0).all()
    names={'matched':'Matched','dual_greedy':'DifficultyGreedy','forecast':'Forecast','boundary':'Boundary'}
    colors={'matched':'#687782','dual_greedy':'#00796b','forecast':'#b05a16','boundary':'#6c5b8c'}
    methods=['matched','dual_greedy','forecast']
    sources=['human','model'];display={'human':'Crowd reference','model':'Model reference'}
    primary=df[df.family_scope.eq('primary_nonranking')]
    rows=[]
    for source in sources:
        for method in methods:
            z=primary[primary.source.eq(source)&primary.method.eq(method)]
            assert len(z)==4640
            audited=next(r for r in summary['micro_tables_lead'] if r['source']==source and r['method']==method and r['scope']=='primary_nonranking')
            assert z.ok.sum()==audited['proof_valid_correct_complete']
            assert abs(z.calls_per_support.mean()-audited['mean_calls_per_support'])<1e-12
            rows.append({'source':source,'method':method,'n':len(z),'correct':int(z.ok.sum()),
                         'mean_calls_support':float(z.calls_per_support.mean()),'errors':int(z.status.eq('execution_error').sum())})
    table=['\\begin{table}[t]','\\centering','\\caption{Primary nonranking results: $4{,}640$ planned units per row. Correct counts require every value and selected proof to match its own reference. Mean submitted calls/support includes all units; errors are sticky inference failures.}',
           '\\label{tab:primaryv2}','\\small','\\begin{tabular}{llrrr}','\\toprule','Reference & Allocator & Correct & Calls/$|I|$ & Errors \\\\','\\midrule']
    for r in rows:
        table.append(f"{'Crowd' if r['source']=='human' else 'Model'} & {names[r['method']]} & {r['correct']:,} & {r['mean_calls_support']:.4f} & {r['errors']} " + chr(92)*2)
    table+=['\\bottomrule','\\end{tabular}','\\end{table}']
    (out/'generated_primary_table.tex').write_text('\n'.join(table)+'\n')
    sem=json.loads((w/'independent_analysis/cross_source_reference_agreement.json').read_text())
    all_sem=[r for r in sem['all_fixed_maps_and_cohorts'] if r['comment_mention_group']=='ALL_FROZEN_ROWS']
    assert len(all_sem)==4 and all(r['n']==30000 for r in all_sem)
    sem_names={'toxicity':'Toxicity','insult':'Insult','identity_attack':'Identity attack','obscene':'Obscene'}
    table=['\\begin{table}[t]','\\centering','\\caption{Pinned model labels relative to existing thresholded crowd references, all $30{,}000$ rows per predicate. Percentages are descriptive; precision/recall concern the positive class.}',
           '\\label{tab:semanticv2}','\\small','\\begin{tabular}{lrrrr}','\\toprule','Predicate & Agreement & Precision & Recall & Bal. acc. \\\\','\\midrule']
    for pred in ['toxicity','insult','identity_attack','obscene']:
        r=next(z for z in all_sem if z['predicate']==pred)
        vals=[100*r[k] for k in ['agreement_accuracy_relative_crowd','precision_relative_crowd','recall_relative_crowd','balanced_accuracy_relative_crowd']]
        table.append(sem_names[pred]+' & '+' & '.join(f'{v:.2f}' for v in vals)+' \\\\')
    table+=['\\bottomrule','\\end{tabular}','\\end{table}']
    (out/'generated_semantic_table.tex').write_text('\n'.join(table)+'\n')
    plt.rcParams.update({'font.family':'serif','font.serif':['DejaVu Serif'],'font.size':8,
                         'axes.linewidth':.6,'pdf.fonttype':42,'ps.fonttype':42,'savefig.facecolor':'white'})
    def save(fig,name):
        for ext in ['pdf','svg']:fig.savefig(out/f'{name}.{ext}',bbox_inches='tight',pad_inches=.025)
        fig.savefig(out/f'{name}.png',bbox_inches='tight',pad_inches=.025,dpi=190);plt.close(fig)
    def style(ax):
        ax.spines[['top','right']].set_visible(False);ax.grid(alpha=.18,lw=.5);ax.set_axisbelow(True);ax.tick_params(labelsize=7.5)
    fig,axes=plt.subplots(1,2,figsize=(7.1,2.28),sharex=True,sharey=True)
    curves=[]
    for ax,source in zip(axes,sources):
        for method in methods:
            z=primary[primary.source.eq(source)&primary.method.eq(method)]
            costs=np.sort((z[z.ok].semantic_calls/z[z.ok].budget).to_numpy())
            x=np.r_[0,costs,1];y=np.r_[0,np.arange(1,len(costs)+1)/len(z),len(costs)/len(z)]
            ax.step(100*x,100*y,where='post',color=colors[method],lw=1.35,label=names[method])
            for cap in np.linspace(0,1,101):curves.append({'source':source,'method':method,'fraction_call_cap':float(cap),'correct_completion_fraction':float((costs<=cap).sum()/len(z))})
        ax.set_title(display[source],fontsize=8.5);style(ax);ax.set_xlim(0,100);ax.set_ylim(0,82)
        ax.set_xlabel('Request call cap used (%)',fontsize=8)
    axes[0].set_ylabel('Correct complete requests (%)',fontsize=8)
    h,l=axes[0].get_legend_handles_labels();fig.legend(h,l,ncol=3,loc='upper center',bbox_to_anchor=(.53,1.09),frameon=False,fontsize=8)
    fig.subplots_adjust(wspace=.15,top=.88,bottom=.22);save(fig,'fig_completion_v2')
    pd.DataFrame(curves).to_csv(out/'figure_stopping_curve_values.csv',index=False)
    rng=np.random.default_rng(int(protocol['uncertainty']['bootstrap_seed']))
    bootstrap=rng.integers(0,10,size=(protocol['uncertainty']['bootstrap_replicates'],10))
    specs=[('Pairwise',lambda d:d.kind.eq('pairwise')),('Equivalence',lambda d:d.kind.eq('equivalence')),
           ('Dominance (3)',lambda d:d.subtype.eq('dominance_3')),('Mixed (3)',lambda d:d.subtype.eq('mixed_3')),
           ('Strict ranking',lambda d:d.kind.eq('ranking'))]
    fig,axes=plt.subplots(1,2,figsize=(7.1,2.42),sharex=True,sharey=True);family_numbers=[]
    for ax,source in zip(axes,sources):
        for j,(label,select) in enumerate(specs):
            group=df[df.source.eq(source)&select(df)]
            rates=group[group.method.isin(methods)].pivot_table(index='seed_id',columns='method',values='ok',aggfunc='mean').reindex(range(10))
            assert rates.notna().all().all()
            for target,control,offset,marker,col in [('dual_greedy','matched',-.105,'s',colors['dual_greedy']),('forecast','dual_greedy',.105,'o',colors['forecast'])]:
                gaps=(rates[target]-rates[control]).to_numpy()*100
                lo,hi=np.quantile(gaps[bootstrap].mean(1),[.025,.975],method='linear');v=float(gaps.mean())
                ax.errorbar(v,j+offset,xerr=[[max(0.,v-lo)],[max(0.,hi-v)]],fmt=marker,ms=3.4,color=col,lw=.8,capsize=2,
                            label=f'{names[target]} − {names[control]}' if j==0 else None)
                family_numbers.append({'source':source,'family':label,'target':target,'control':control,'gap_percentage_points':v,'seedblock95':[float(lo),float(hi)]})
        ax.axvline(0,color='#687782',lw=.75,ls='--');style(ax);ax.set_title(display[source],fontsize=8.5)
        ax.set_xlabel('Completion difference (percentage points)',fontsize=7.8)
        ax.set_yticks(range(len(specs)),[s[0] for s in specs])
    axes[0].invert_yaxis()
    h,l=axes[0].get_legend_handles_labels();fig.legend(h,l,ncol=2,loc='upper center',bbox_to_anchor=(.54,1.08),frameon=False,fontsize=7.5)
    fig.subplots_adjust(left=.16,right=.99,wspace=.16,top=.86,bottom=.23);save(fig,'fig_family_v2')
    fig,axes=plt.subplots(1,2,figsize=(7.1,2.3),sharex=True,sharey=True);oracle_numbers=[]
    grid=np.linspace(0,1,201)
    for ax,source in zip(axes,sources):
        cases=pd.read_csv(w/f'oracle_evaluation/{source}_headroom_cases_v2.csv')
        unique=cases.drop_duplicates('case_id').copy();assert len(unique)==96
        no_proof=unique.oracle_at_cap.eq('no_source_valid_proof_on_legal_paths')
        lb=pd.to_numeric(unique.oracle_lower_total,errors='coerce').to_numpy(dtype=float,copy=True);ub=pd.to_numeric(unique.oracle_upper_total,errors='coerce').to_numpy(dtype=float,copy=True)
        lb[no_proof.to_numpy()]=np.inf;ub[no_proof.to_numpy()]=np.inf
        assert np.all(np.isfinite(lb)|no_proof) and np.all(np.isfinite(ub)|no_proof) and np.all(lb<=ub)
        caps=unique.cap.to_numpy();lower=np.array([np.mean(ub/caps<=t) for t in grid]);upper=np.array([np.mean(lb/caps<=t) for t in grid])
        ax.fill_between(100*grid,100*lower,100*upper,step='post',color='#d4e3ed',alpha=.85,label='Verified oracle bracket')
        ax.step(100*grid,100*lower,where='post',color='#69899e',lw=.6);ax.step(100*grid,100*upper,where='post',color='#69899e',lw=.6)
        for method in methods:
            z=cases[cases.method.eq(method)].copy();assert len(z)==96
            ok=z.correct_complete.astype(str).eq('True');costs=np.sort((z.loc[ok,'actual_calls']/z.loc[ok,'cap']).to_numpy())
            curve=np.array([(costs<=t).sum()/96 for t in grid]);assert np.all(curve<=upper+1e-12)
            ax.step(100*grid,100*curve,where='post',color=colors[method],lw=1.1,label=names[method])
        oracle_numbers.append({'source':source,'cases':96,'within_cap_proof_upper':int(np.sum(ub<=caps)),
                               'above_cap_lower_or_no_proof':int(np.sum(lb>caps)),'no_legal_source_valid_proof':int(no_proof.sum())})
        style(ax);ax.set_xlim(0,100);ax.set_ylim(0,100);ax.set_xlabel('Request call cap used (%)',fontsize=8);ax.set_title(display[source],fontsize=8.5)
    axes[0].set_ylabel('Selected cases complete (%)',fontsize=8)
    h,l=axes[0].get_legend_handles_labels();fig.legend(h,l,ncol=4,loc='upper center',bbox_to_anchor=(.54,1.09),frameon=False,fontsize=7.4)
    fig.subplots_adjust(wspace=.15,top=.87,bottom=.23);save(fig,'fig_oracle_v2')
    numbers={'summary_sha256':hashlib.sha256(summary_bytes).hexdigest(),'raw_grid_units':len(df),'primary_rows':rows,'semantic_overall_rows':all_sem,
             'family_differences':family_numbers,'oracle_cases':oracle_numbers,'bootstrap':protocol['uncertainty']}
    (out/'generated_figure_numbers.json').write_text(json.dumps(numbers,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps({'tables':2,'figures':3,'verified_grid_rows':len(df),'out':str(out)},indent=2))


if __name__=='__main__':main()
