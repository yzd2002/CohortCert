CohortCert v3 — 本地完整复现材料

优先使用 reproduce_v3.py 检查新增实验。全部输入、代码与结果都已保留；以下操作无需 GPU、模型、网络或服务密钥。

1. 安装 requirements_cpu.txt 对应依赖后：
python reproduce_v3.py verify
python reproduce_v3.py summary

verify 检查本包的文件哈希；summary 从原三策略及新增控制、GoEmotions的CSV重新计算预定主结果、分组结果和错误计数，并与已审计摘要逐项比较；旧排名边界对照另用 reproduce.py summary。它们不是重新执行统计实验，也不能替代原始轨迹审计。

2. 小规模真实执行器检查（输出目录必须不存在）：
python reproduce_v3.py smoke-go --out /一个新的Go检查目录
python reproduce_v3.py smoke-controls --out /一个新的对照检查目录

分别执行10条 GoEmotions 和14条 CivilComments 新控制的固定标签检查。它们是打包检查，不是新增主实验或模型推理。当前包已完成这24条检查，并额外验证了两种网格各一条独立进程重放路线。

3. 完整重跑需要先创建新的本地路径清单：
python reproduce_v3.py freeze-go --out /一个新的Go计划目录 --workers 1
python reproduce_v3.py freeze-controls --out /一个新的控制计划目录 --workers 1

这两步分别准备全部17,120和23,680次 CPU 重放，不启动完整实验。随后根据打印的实际清单路径和 SHA256：
python reproduce_v3.py execute-go --manifest /Go计划目录/run_manifest.json --expect-manifest-sha256 实际SHA256
python reproduce_v3.py execute-controls --manifest /控制计划目录/run_manifest.json --expect-manifest-sha256 实际SHA256

新本地路径、时间和清单哈希会产生新的运行标识；历史证据字节不改动。算法和输入相同不等于跨环境轨迹逐字节相同。默认一个工作进程，可明确指定1至20，须记录实际环境。

4. 原始轨迹检查（完整交付文件夹的07目录须保留在04目录旁边）：
python reproduce_v3.py audit-go --limit 2
python reproduce_v3.py audit-controls --limit 2

完整扫描将 --limit 改为0，分别要求17,120和23,680条。该入口检查独立源值/证明、确切传播、成本、读取前缀和CS结构；detail=False 不逐次重算全部数值似然端点。所有错误证明和未完成结果会据实分类，不能把“核对通过”误解为所有统计区间均覆盖真值。新增两组研究的完整独立代码审计合计完成40,800条，零核对差异；源排除和统计失败仍保留。

公开候选 ZIP 主要包含输入、代码、CSV、证书和已完成审计；体积较大的原始轨迹放在07目录。单独解压候选ZIP不足以扫描原始轨迹；需同时取得07目录，或按固定输入重新执行。缺失轨迹时审计会失败，不会将部分检查称为完整通过。

5. 重建新增图表（输出目录必须不存在）：
python reproduce_v3.py figures --out /一个新的图表目录

重建三组主要参考的完成成本曲线、跨决策聚合及重叠端点机制图，并输出精确作图数据。原图1/2/5/6的入口仍在 reproduce.py 及其原说明中；该旧入口的图3/4是历史v2图，不是新版正文图。

6. 目录说明
v3_evidence/control_study_freeze_v1：更强宽度/方差控制与 Sum/Max 机制，60个完整分片，共23,680条。
v3_evidence/goemotions_validation：固定30,000条 GoEmotions 输入、4种现有标注参考、528合同、代码冻结证据、40个分片及17,120条审计。
v3_evidence/uncoupled_oracle：同192案例的端点放宽实验和独立算术复核；不是重复读取，也不是线上速度实验。
v3_evidence/joint_inference：有限算术原型和顺序反例；没有部署为主实验的新统计内核，不得计作新主结果。
revision_evidence 与 legacy_core：不变的v2基础、旧语料复现、23次真实推理证据及早期原型。

模型 Qwen3-8B 的完整revision为 b968826d9c46dd6066d109eabc6255188de91218。当前原机权重14个文件已经验证；包内不分发16GB权重。下载路线和 AutoDL 官方网络加速说明见原 README_复现说明.txt。新增40,800次研究执行全部是固定标签CPU重放，不产生新的模型计时数据。

原始来源、软件公开许可证及发布URL需据实保留。软件许可证未替作者决定；本地候选包尚未公开。GoEmotions 数据从提供方完整原始文件恢复，包含第三方 Reddit 内容；不将仓库代码的Apache许可直接推断为所有源文本的独立再许可。
