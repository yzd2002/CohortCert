CohortCert-ResearchRevision-20261102 — 复现实验说明

这里包含新版本的冻结代码、输入、全部结果和核查证据。历史单向推断版本在legacy_core内单独保留，不能与新双向逐判断版本混合统计。未包含16GB模型权重；CPU复核不需要GPU、模型或网络。

一、最快复核

在本目录安装requirements_cpu.txt对应依赖后执行：
python reproduce.py verify
python reproduce.py summary
python reproduce.py figures --out /一个新的图表输出目录

verify核对核心文件SHA256；summary从全部CSV重新计算各方法分母、正确完成数、调用成本和错误数；figures从原始CSV及核查摘要重画正文统计图。默认统计图命令重建正文图3–5和两张表；使用--out向新目录输出，不覆盖实验数据。请在verify之后运行图表命令，后者可能因绘图库元数据改变生成文件的字节哈希，但不改变实验。

二、小规模执行检查

python reproduce.py smoke --out /一个全新的输出目录

这会使用本地固定标签、真实冻结执行器、两条固定元数据选取的请求、三种策略、两种参考及seed0，共12次CPU重放。它是打包可用性检查，不是新主实验，不产生任何真实模型推理。输出目录必须不存在，避免覆盖结果。软时限规划器的动作可能随机器负载变化，不承诺逐字节相同的轨迹。

三、完整CPU重跑

python reproduce.py freeze-grid --out /一个全新的计划目录

随后使用生成的清单及其实际SHA256：
python revision_evidence/policy_freeze_v1/executor_v2/run_grid.py --mode execute --manifest /计划目录/run_manifest.json --expect-manifest-sha256 实际SHA256

默认保留全部528请求、10组种子、两种参考、三种主策略，共31,680次。默认本地适配器选1个工作进程，可在生成新清单时明确更改；必须记录新环境和计算条件。独立排名对照需新清单并选择boundary。历史执行清单中的绝对路径和文件字节未改动；新的路径产生新清单和新运行标识是预期行为。

四、完整原始轨迹与独立复核

07_Raw_Trace_Archives保存全部32,960条新语料主实验和排名对照轨迹。各tar卷独立，将所有卷解包到本目录的revision_evidence内即可恢复结果目录。先核对RAW_ARCHIVE_INDEX.json的各卷SHA256。

恢复轨迹后：
python reproduce.py audit-civil --limit-per-grid 2
python reproduce.py audit-civil --limit-per-grid 0

第一条每个网格检查前两条可用记录；第二条检查全部。该可移植适配器在内存中映射路径，不修改历史清单；调用独立参考计算和轨迹检查器，核对固定源真值/正负证明、成本、采样前缀和CS结构。该入口detail=False不重新数值求解每个CS端点；已执行的完整独立核查过程、选择方案、数据库和完成回执在independent_analysis。不要把“通过核查”理解为每个统计区间都覆盖真值：所有已发现的排除事件、错误证明和未完成情况均保留。

192个离线最优边界案例、9,600条原语料重放、23次真实推理的完整材料在oracle_evaluation、legacy_replication_v1、runtime_revision_v1及内部审查文件内。离线源有效上界证明存在性，不保证原执行器在统计排除事件后能到达或选择该证明。

五、模型与真实计时

下载Qwen/Qwen3-8B，完整revision：b968826d9c46dd6066d109eabc6255188de91218。预期14个文件的大小及SHA256在natural_overlap/qwen_expected_file_manifest.json。下载方式可按AutoDL官方网络加速说明：https://www.autodl.com/docs/network_turbo/。不要把加速代理的账号、密码或临时环境值写入公开日志。

requirements_gpu_additional.txt记录实际GPU依赖版本。冻结的模型构建与运行时代码、提示词、精度、分词、参考标签和所有回执均已保留。其历史冻结清单绑定原计算机的路径；若要重新采集GPU数据，先用准备脚本创建绑定本地路径与新输出目录的新选择和清单，记录路径迁移及环境，不要直接修改历史清单后称为同一实验。原机使用RTX5090 32GB，单记录推理，无缓存/截断。

23次真实执行中20次正确完成；另3次为同一等价判断达到上限后未完成。69,799次语料推理全部与固定模型参考一致。一次共同的单元计数覆盖排除出现在6个相关的冷热启动重复中；最终对比区间和输出证明仍源有效。没有完整的物化构建成本账本，不能宣称已经测出经济交叉点。

六、使用范围与状态

本地材料已准备；尚未公开到远程仓库，也未代为投稿。软件公开许可证需作者确定；第三方数据和模型仍各受原有条款约束。CivilComments选取文本按提供方CC0说明保留；Airline派生数据按CC BY-NC-SA 4.0保留来源与变更说明；原始Airline文本需通过保留的下载/恢复程序取得。原CFPB/OpinRank重放不需要分发叙事文本。

历史源码内的“待执行”“仅准备”等说明反映冻结时状态，不能覆盖最终完成回执。最终状态以投稿文件夹README和各完成回执为准。全部代理审查均为内部模拟评阅，不是ICDE官方审稿。

可移植GPU重复计划入口（此步骤只准备清单，不启动推理）：
先运行 legacy_context/airline_validation/restore_airline_inputs.py --download，或用其--archive选项提供相同的原始压缩包；它校验Tweets.csv与重建文本的既有SHA256。然后：
python prepare_gpu_repetition.py --out /一个全新的GPU计划目录 --weights /完整Qwen3-8B模型目录

可用--airline-text指定已有、哈希匹配的私有文本快照。准备入口保留原六条查询、23次执行、顺序、种子和策略，移除原机已退出PID的编号，绑定新本地路径与环境，再生成新的冻结清单。它不是新的前瞻性选择。只有之后主动执行输出RUN_COMMANDS.txt内的run命令才会启动GPU测量。打包时仅验证了准备/冻结路线，未重复23次GPU实验。

其余图表的独立重建入口：
python reproduce.py structure-figures --out /一个新的结构图输出目录
python reproduce.py runtime-figure --out /一个不存在的运行时间图输出目录
前者重建图1的明确示意数字与图2的固定元数据；后者从已审计的23行CSV和进程成本表重建图6，不调用模型、策略或计时。完整原始轨迹未恢复时，audit-civil --limit-per-grid 0将以失败状态退出，不能把部分材料检查称为完整通过。
