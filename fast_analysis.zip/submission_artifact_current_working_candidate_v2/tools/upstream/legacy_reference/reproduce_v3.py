#!/usr/bin/env python3
"""Portable v3 replay/audit adapter; historical evidence bytes stay unchanged."""
from pathlib import Path
import argparse,collections,csv,gzip,hashlib,importlib,json,sys,threading
from datetime import datetime,timezone
BASE=Path(__file__).resolve().parent;E=BASE/'revision_evidence';V=BASE/'v3_evidence';C=BASE/'legacy_core';RAW=BASE.parent/'07_Raw_Trace_Archives'
PREFIXES=[('/root/autodl-tmp/cohortcert_research_v3_20261102',V),('/root/autodl-tmp/cohortcert_strong_revision_20261102',E),('/dev/shm/CohortCert_fixed_label_replay_20261031',C)]
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
 return h.hexdigest()
def read(p):return json.loads(Path(p).read_text())
def mapped(s):
 for prefix,target in PREFIXES:
  if s==prefix or s.startswith(prefix+'/'):return str(target)+s[len(prefix):]
 return s
def relocate(o):
 if isinstance(o,str):return mapped(o)
 if isinstance(o,list):return [relocate(x) for x in o]
 if isinstance(o,dict):return {mapped(k):relocate(v) for k,v in o.items()}
 return o
def manifest_path(dataset):return V/('goemotions_validation/grid_v1/run_manifest.json' if dataset=='go' else 'control_study_freeze_v1/run_manifest.json')
def runner():
 p=V/'goemotions_validation/code_freeze_v1';sys.path.insert(0,str(p));module=importlib.import_module('run_goemotions_grid');module.OLD=E;return module
def portable_initialize(m,results,stop):
 # Also runs in each freshly spawned child: do not depend on parent globals.
 module=runner();module.initialize(m,results,stop)
def replay_manifest(dataset):
 p=manifest_path(dataset);m=relocate(read(p))
 if dataset=='controls':m['extension_root']=m['v3_extension_dir']
 m['portable_path_mapping']={'original_manifest_sha256':sha(p),'note':'New local replay identity, not a modification or bit-identical rerun claim for historical traces.'}
 return m
def verify():
 d=read(BASE/'ARTIFACT_SHA256.json');bad=[]
 for name,h in d.items():
  p=BASE/name
  if not p.is_file() or sha(p)!=h:bad.append(name)
 if bad:raise RuntimeError('Missing/changed evidence files:'+str(bad[:20]))
 print(json.dumps({'status':'passed','verified_files':len(d),'full_raw_traces':'Separate07folder; its own index binds the new shards and originalv2tar parts.'},indent=2))
def summary():
 expected_civil=read(V/'independent_analysis_v1/FINAL_CONTROL_AND_MECHANISM_SUMMARY.json')['summary'];expected_go=read(V/'goemotions_validation/independent_analysis_v1/FINAL_GOEMOTIONS_SUMMARY.json')['summary'];groups=collections.defaultdict(list)
 paths=[*sorted((V/'control_study_freeze_v1/results/shards').glob('*.csv')),*sorted((V/'goemotions_validation/grid_v1/results/shards').glob('*.csv'))]
 for source in ['human','model']:paths.extend(sorted((E/f'grid_{source}50_v1/results/shards').glob('*.csv')))
 for p in paths:
  context='go' if 'goemotions_validation' in str(p) else 'civil'
  for r in csv.DictReader(p.open()):groups[context,r['source'],r['method']].append(r)
 out=[]
 for (dataset,source,method),rr in sorted(groups.items()):
  scopes=['summary'] if method=='max_dg' else ['primary','summary','ranking']
  for scope in scopes:
   rows=[r for r in rr if r['kind']==scope or scope=='primary' and r['kind']!='ranking'];expect=(expected_go if dataset=='go' else expected_civil[source])[method][scope]
   actual={'n':len(rows),'correct':sum(r['correct_complete']=='True' for r in rows),'mean_calls_per_support':sum(float(r['calls_per_support']) for r in rows)/len(rows),'sticky_or_other_execution_errors':sum(r['status']=='execution_error' for r in rows),'source_wrong_claim_or_proof_runs':sum(r['source_error']=='True' for r in rows)}
   for key,v in actual.items():assert abs(v-expect[key])<1e-12,(dataset,method,scope,key)
   out.append({'dataset':dataset,'source':source,'method':method,'scope':scope,**actual})
 print(json.dumps({'status':'all_prespecified_summaries_reconciled','rows':out},indent=2))
def smoke(dataset,out):
 out=out.resolve();m=replay_manifest(dataset);module=runner();rc=module.probe(m,None,out,'Packaging-only fixedmetadata probes from frozen labels; not new primary observations or model forwards')
 if rc:raise RuntimeError('Portable packaging probe failed')
def freeze(dataset,out,workers):
 assert 1<=workers<=20;out.mkdir(parents=True,exist_ok=False);m=replay_manifest(dataset);m['worker_count']=workers;m['created_utc']=datetime.now(timezone.utc).isoformat();m['fresh_replay_scope']='All original contracts/seeds/reference/methods; new local manifest and run hashes. Saved-label CPU only.'
 m['source_sha256'][str(Path(__file__).resolve())]=sha(Path(__file__).resolve())
 p=out/'run_manifest.json';p.write_text(json.dumps(m,indent=2)+'\n');print(json.dumps({'manifest':str(p),'sha256':sha(p),'runs':m['counts']['all_runs'],'workers':workers,'next':'execute-go or execute-controls with --manifest and --expect-manifest-sha256; freeze does not execute.'},indent=2))
def execute(path,expected):
 assert expected and sha(path)==expected
 module=runner();grid=module.get_grid();grid.worker_initialize=portable_initialize
 return grid.execute_manifest(argparse.Namespace(manifest=path,expect_manifest_sha256=expected,workers=None))
def audit(dataset,limit):
 code=V/('goemotions_validation/code_freeze_v1' if dataset=='go' else 'independent_analysis_v1');sys.path.insert(0,str(code));from reference import Reference;from trace_audit import audit_trace
 p=manifest_path(dataset);original=read(p);m=relocate(original);ref=Reference(m);root=RAW/('v3_goemotions_shards' if dataset=='go' else 'v3_control_shards');count=correct=0
 for shard in original['shards']:
  raw=root/(shard['name']+'.jsonl.gz')
  if not raw.exists():raise FileNotFoundError('Full raw trace missing: '+str(raw)+'; use the complete delivery folder or regenerate a fresh grid.')
  csvpath=raw.with_name(shard['name']+'.csv');rows={r['run_key']:r for r in csv.DictReader(csvpath.open())}
  with gzip.open(raw,'rb') as f:
   for line in f:
    record=json.loads(line);r=rows[record['run_key']];assert sha(p)==record['run_manifest_sha256'];assert hashlib.sha256(line.rstrip(b'\n')).hexdigest()==r['raw_record_sha256']
    verdict=ref.verdict(record['source'],ref.compiled[record['query_id']],record['result']['certificate']);assert verdict['correct_complete']==(r['correct_complete']=='True');audit_trace(ref,m,record,detail=False);count+=1;correct+=verdict['correct_complete']
    if limit and count>=limit:break
  if limit and count>=limit:break
 expected=17120 if dataset=='go' else 23680;assert count==(min(limit,expected) if limit else expected)
 print(json.dumps({'status':'passed','dataset':dataset,'records':count,'source_proof_correct_complete':correct,'expected_full':expected,'limit':limit,'scope':'Independent source/proof, exact signed propagation, costs, prefixes and countCSstructure. detailFalse does not recompute every numeric likelihood endpoint. Errors and source-wrong outputs are classified, not hidden.','model_forwards':0},indent=2))
def figures(out):
 import importlib.util
 out.mkdir(parents=True,exist_ok=False);p=V/'make_figures_v3.py';spec=importlib.util.spec_from_file_location('v3_figures',p);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);mod.ROOT=V;mod.OLD=E;mod.OUT=out;mod.main()
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('mode',choices=['verify','summary','smoke-go','smoke-controls','freeze-go','freeze-controls','execute-go','execute-controls','audit-go','audit-controls','figures']);p.add_argument('--out',type=Path);p.add_argument('--manifest',type=Path);p.add_argument('--expect-manifest-sha256');p.add_argument('--workers',type=int,default=1);p.add_argument('--limit',type=int,default=2);a=p.parse_args()
 if a.mode in ['verify','summary']:globals()[a.mode]();return
 if a.mode.startswith('audit-'):audit(a.mode[6:],a.limit);return
 if a.mode.startswith('execute-'):return execute(a.manifest.resolve(),a.expect_manifest_sha256)
 if a.out is None:p.error('--out is required')
 if a.mode.startswith('smoke-'):smoke(a.mode[6:],a.out)
 elif a.mode.startswith('freeze-'):freeze(a.mode[7:],a.out,a.workers)
 else:figures(a.out)
if __name__=='__main__':raise SystemExit(main())
