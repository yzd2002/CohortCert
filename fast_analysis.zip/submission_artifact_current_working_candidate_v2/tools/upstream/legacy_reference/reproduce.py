#!/usr/bin/env python3
"""Portable inspection/replay adapter. Historical evidence bytes stay unchanged."""
from pathlib import Path
import argparse,collections,csv,gzip,hashlib,json,os,subprocess,sys,threading
BASE=Path(__file__).resolve().parent;E=BASE/'revision_evidence';C=BASE/'legacy_core'
OLD='/root/autodl-tmp/cohortcert_strong_revision_20261102';OLDCORE='/dev/shm/CohortCert_fixed_label_replay_20261031'
GRIDS=['grid_human50_v1','grid_model50_v1','grid_boundary_human50_v1','grid_boundary_model50_v1']
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
 return h.hexdigest()
def mapped(s):
 if s==OLD or s.startswith(OLD+'/'):return str(E)+s[len(OLD):]
 if s==OLDCORE or s.startswith(OLDCORE+'/'):return str(C)+s[len(OLDCORE):]
 return s
def relocate(o):
 if isinstance(o,str):return mapped(o)
 if isinstance(o,list):return [relocate(v) for v in o]
 if isinstance(o,dict):return {mapped(k):relocate(v) for k,v in o.items()}
 return o
def verify():
 p=BASE/'ARTIFACT_SHA256.json';m=json.loads(p.read_text());bad=[]
 for rel,h in m.items():
  f=BASE/rel
  if not f.is_file() or sha(f)!=h:bad.append(rel)
 if bad:raise RuntimeError('Missing or changed files: '+str(bad[:20]))
 print(json.dumps({'verified_files':len(m),'status':'passed','raw_traces':'separate archives; verify their SHA256 index too'},indent=2))
def summary():
 out=[]
 for g in GRIDS:
  groups=collections.defaultdict(list)
  for p in sorted((E/g/'results/shards').glob('*.csv')):
   for r in csv.DictReader(p.open()):
    if g in GRIDS[:2] and r['kind']=='ranking':continue
    groups[(r['source'],r['method'])].append(r)
  for (s,m),rows in groups.items():out.append({'grid':g,'source':s,'method':m,'n':len(rows),'correct':sum(r['correct_complete']=='True' for r in rows),'mean_calls_per_support':sum(float(r['calls_per_support']) for r in rows)/len(rows),'errors':sum(r['status']=='execution_error' for r in rows)})
 print(json.dumps(out,indent=2))
def freeze_grid(out):
 cmd=[sys.executable,str(E/'policy_freeze_v1/executor_v2/run_grid.py'),'--mode','freeze','--workspace',str(E/'natural_overlap'),'--core-root',str(C),'--labels-dir','human='+str(E/'natural_overlap/source_reference_labels_v2'),'--labels-dir','model='+str(E/'natural_overlap/qwen_four_predicate_labels_v1'),'--out',str(out),'--workers','1']
 subprocess.run(cmd,check=True)
 return out/'run_manifest.json'
def smoke(out):
 p=freeze_grid(out/'fresh_full_plan');m=json.loads(p.read_text())
 # A separate packaging check, not an extra primary-grid observation.
 ids=[next(q['query_id'] for q in m['query_metadata'] if q['kind']==kind) for kind in ['pairwise','summary']]
 shards=[]
 for s in m['shards']:
  if s['seed_id']==0:
   s=dict(s,name='package_smoke__'+s['name'],query_ids=ids,expected_rows=len(ids));shards.append(s)
 m['shards']=shards;m['counts']['all_runs']=len(shards)*len(ids)
 m['packaging_smoke']={'scope':'two fixed metadata cases, all three main methods, two sources, seed0; not a primary rerun','fresh_full_plan_sha256':sha(p)}
 sp=out/'SMOKE_MANIFEST.json';sp.write_text(json.dumps(m,indent=2)+'\n');m['_runtime_manifest_sha256']=sha(sp)
 root=out/'results'
 for n in ['shards','progress']:(root/n).mkdir(parents=True,exist_ok=False)
 sys.path.insert(0,str(E/'policy_freeze_v1'))
 from executor_v2 import run_grid as grid
 stop=threading.Event();grid.worker_initialize(m,root,stop)
 reports=[grid.run_shard(s) for s in shards]
 if stop.is_set() or any(r.get('failure') for r in reports):raise RuntimeError('Packaging smoke failed: '+str(reports))
 report={'status':'passed','query_ids':ids,'runs':len(shards)*len(ids),'physical_model_forwards':0,'note':'Saved-label CPU replay. Soft-deadline planner traces are not promised bit-identical.','shards':reports}
 (out/'SMOKE_REPORT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
def audit(limit):
 sys.path.insert(0,str(E/'independent_analysis'))
 from reference import Reference
 from trace_audit import audit_trace
 count=0;correct=0;missing=[]
 for g in GRIDS:
  path=E/g/'run_manifest.json';original=json.loads(path.read_text());m=relocate(original)
  ref=Reference(m);n=0
  for s in original['shards']:
   f=E/g/'results/shards'/(s['name']+'.jsonl.gz')
   if not f.exists():missing.append(str(f.relative_to(E)));continue
   rows={r['run_key']:r for r in csv.DictReader(f.with_name(s['name']+'.csv').open())}
   with gzip.open(f,'rb') as stream:
    for b in stream:
     p=json.loads(b);r=rows[p['run_key']]
     assert hashlib.sha256(b.rstrip(b'\n')).hexdigest()==r['raw_record_sha256']
     assert p['run_manifest_sha256']==sha(path)
     verdict=ref.verdict(p['source'],ref.compiled[p['query_id']],p['result']['certificate'])
     assert verdict['correct_complete']==(r['correct_complete']=='True')
     audit_trace(ref,m,p,detail=False)
     count+=1;n+=1;correct+=int(verdict['correct_complete'])
     if limit and n>=limit:break
   if limit and n>=limit:break
  if n==0:print('No raw traces found for '+g+'; extract the separate trace archives into revision_evidence first.',file=sys.stderr)
 print(json.dumps({'audited_rows':count,'correct':correct,'missing_raw_shards':len(missing),'limit_per_grid':limit,'physical_model_forwards':0,'scope':'Independent source truth/proof, read-prefix/cost/CS structure; detail=False does not recompute every numeric endpoint.'},indent=2))
 if count==0 or (limit==0 and (count!=32960 or missing)) or (limit>0 and count<4*limit):raise SystemExit(2)
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('mode',choices=['verify','summary','figures','freeze-grid','smoke','audit-civil','structure-figures','runtime-figure']);p.add_argument('--out',type=Path);p.add_argument('--limit-per-grid',type=int,default=2);a=p.parse_args()
 if a.mode=='verify':verify()
 elif a.mode=='summary':summary()
 elif a.mode=='figures':subprocess.run([sys.executable,str(BASE/'paper_figures/make_results_figures.py'),'--evidence-root',str(E)]+(['--out',str(a.out)] if a.out else []),check=True)
 elif a.mode=='structure-figures':
  if a.out is None:p.error('--out is required')
  subprocess.run([sys.executable,str(BASE/'paper_figures/make_structure_figures.py'),'--workspace',str(E/'natural_overlap'),'--out',str(a.out)],check=True)
 elif a.mode=='runtime-figure':
  if a.out is None:p.error('--out is required')
  import shutil
  a.out.mkdir(parents=True,exist_ok=False)
  for f in (BASE/'paper_figures/runtime_display').iterdir():
   if f.is_file():shutil.copy2(f,a.out/f.name)
  subprocess.run([sys.executable,str(a.out/'make_display_figure_v2.py')],check=True)
 elif a.mode=='freeze-grid':
  if a.out is None:p.error('--out is required')
  print(freeze_grid(a.out))
 elif a.mode=='smoke':
  if a.out is None:p.error('--out is required')
  a.out.mkdir(parents=True,exist_ok=False);smoke(a.out)
 else:audit(a.limit_per_grid)
if __name__=='__main__':main()
