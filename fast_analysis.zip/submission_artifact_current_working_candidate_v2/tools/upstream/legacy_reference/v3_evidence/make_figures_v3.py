"""Recreate publication figures from complete, audited fixed workloads."""
from pathlib import Path
import json,csv,hashlib
from collections import defaultdict
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent;OLD=Path('/root/autodl-tmp/cohortcert_strong_revision_20261102');OUT=ROOT/'manuscript_v3'
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 civil=read(ROOT/'independent_analysis_v1/FINAL_CONTROL_AND_MECHANISM_SUMMARY.json');go=read(ROOT/'goemotions_validation/independent_analysis_v1/FINAL_GOEMOTIONS_SUMMARY.json');mechanism=read(ROOT/'uncoupled_oracle/study_v1/FINAL_UNCOUPLED_MECHANISM_SUMMARY.json')
 assert civil['status']=='complete' and go['status']=='complete_and_all17120_audited' and mechanism['status']=='complete_and_all192_verified'
 groups=defaultdict(list);inputs={};contexts=[('civil_human','(a) CivilComments: crowd'),('civil_model','(b) CivilComments: model'),('go','(c) GoEmotions: crowd')]
 for src in ['human','model']:
  paths=sorted((OLD/f'grid_{src}50_v1/results/shards').glob('*.csv'))
  paths+=sorted((ROOT/'control_study_freeze_v1/results/shards').glob(f'{src}__*.csv'))
  for p in paths:
   inputs[str(p)]=sha(p)
   for r in csv.DictReader(p.open()):
    if r['kind']!='ranking' and r['method']!='max_dg':groups['civil_'+src,r['method']].append(r)
 for p in sorted((ROOT/'goemotions_validation/grid_v1/results/shards').glob('*.csv')):
  inputs[str(p)]=sha(p)
  for r in csv.DictReader(p.open()):
   if r['kind']!='ranking' and r['method']!='max_dg':groups['go',r['method']].append(r)
 colors={'dual_greedy':'#14705b','width':'#ab5679','neyman':'#4b6caa','matched':'#999999','forecast':'#c3661a'}
 labels={'dual_greedy':'DifficultyGreedy','width':'WidthGreedy','neyman':'VarianceGreedy','matched':'Matched','forecast':'Forecast'}
 styles={'dual_greedy':'-','width':'--','neyman':'-.','matched':':','forecast':(0,(4,1,1,1))}
 plt.rcParams.update({'font.family':'DejaVu Serif','font.size':8,'axes.titlesize':8.5,'axes.labelsize':8,'xtick.labelsize':7.5,'ytick.labelsize':7.5,'legend.fontsize':7.5,'pdf.fonttype':42,'ps.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
 fig,axes=plt.subplots(1,3,figsize=(6.98,2.37),sharex=True,sharey=True)
 xs=np.linspace(0,1,501);plot_data={}
 for ax,(context,title) in zip(axes,contexts):
  plot_data[context]={}
  for method in ['matched','forecast','neyman','width','dual_greedy']:
   rr=groups.get((context,method));
   if rr is None:continue
   assert len(rr)==4640
   costs=[int(r['semantic_calls'])/int(r['budget']) for r in rr if r['correct_complete']=='True'];assert all(0<=v<=1 for v in costs)
   cumulative=100*np.searchsorted(np.sort(costs),xs,side='right')/len(rr)
   ax.step(xs,cumulative,where='post',color=colors[method],ls=styles[method],lw=1.4 if method=='dual_greedy' else 1.15,label=labels[method]);plot_data[context][method]={'n':len(rr),'correct':len(costs),'x':list(map(float,xs)),'cumulative_percent':list(map(float,cumulative))}
  ax.set_title(title,pad=6);ax.set_xlim(0,1);ax.set_ylim(0,100);ax.set_xticks([0,.25,.5,.75,1],['0','.25','.5','.75','1']);ax.set_yticks([0,25,50,75,100]);ax.grid(axis='y',color='#dddddd',lw=.45);ax.set_xlabel('Used fraction of the 50% cap')
 axes[0].set_ylabel('Correct complete requests (%)');handles,legend=axes[0].get_legend_handles_labels();fig.legend(handles,legend,loc='upper center',bbox_to_anchor=(.5,1.015),ncol=5,frameon=False,columnspacing=1.,handlelength=1.8)
 fig.subplots_adjust(left=.075,right=.99,top=.79,bottom=.22,wspace=.18)
 fig.savefig(OUT/'fig_completion_v3.pdf');fig.savefig(OUT/'fig_completion_v3.png',dpi=200);plt.close(fig)
 fig,axes=plt.subplots(1,3,figsize=(6.98,2.30));effects=[next(x for x in civil['contrasts'] if x['source']==s and x['control']=='max_dg') for s in ['human','model']]+[next(x for x in go['contrasts'] if x['control']=='max_dg')]
 for y,(effect,label) in enumerate(zip(effects,['Civil: crowd','Civil: model','GoEmotions'])):
  est=effect['DG_minus_control_completion_pp'];lo,hi=effect['completion_pp_seed_block_95_percentile'];axes[0].errorbar(est,y,xerr=[[est-lo],[hi-est]],fmt='o',color='#14705b',capsize=2.5,ms=4);axes[0].text(est,y-.21,f'{est:+.2f}',ha='center',va='center',fontsize=7.5)
 axes[0].axvline(0,color='#777777',lw=.8,ls='--');axes[0].set_yticks([0,1,2],['Civil crowd','Civil model','GoEmotions']);axes[0].set_ylim(2.55,-.55);axes[0].set_xlabel('Completion difference (pp)');axes[0].set_title('(a) Across decisions',pad=7);axes[0].grid(axis='x',color='#dddddd',lw=.45)
 c=read(ROOT/'uncoupled_oracle/study_v1/completion.json');mech_data={}
 for ax,source,title in zip(axes[1:],['human','model'],['(b) Crowd overlap','(c) Model overlap']):
  rr=[r for r in c['summary'] if r['source']==source];finite=[r for r in rr if r['uncoupled_lower_total'] is not None];allxy=[]
  for flag,color,label in [(False,'#a3a9b2','Inconclusive'),(True,'#c85d31','Strict cost increase')]:
   chosen=[r for r in finite if r['certified_strict_extra_proof_cost']==flag];xx=[r['signed_upper_total']/r['support_size'] for r in chosen];yy=[r['uncoupled_lower_total']/r['support_size'] for r in chosen];allxy+=xx+yy;ax.scatter(xx,yy,s=13 if flag else 10,c=color,alpha=.9 if flag else .65,edgecolors='none',label=label)
  top=max(.52,max(allxy)*1.08);ax.plot([0,top],[0,top],ls='--',color='#555555',lw=.8);ax.set_xlim(0,top);ax.set_ylim(0,top);ax.set_aspect('equal',adjustable='box');ax.set_title(title,pad=7);ax.set_xlabel('Signed upper / support');ax.set_ylabel('Relaxed lower / support',labelpad=2)
  ax.text(.04,.96,f'{sum(r["certified_strict_extra_proof_cost"] for r in rr)}/96 certified',transform=ax.transAxes,va='top',fontsize=7.5);mech_data[source]=rr
 handles,labels_=axes[1].get_legend_handles_labels();fig.legend(handles,labels_,loc='upper center',bbox_to_anchor=(.69,1.015),ncol=2,frameon=False,handletextpad=.3,columnspacing=.9)
 fig.subplots_adjust(left=.14,right=.98,top=.78,bottom=.22,wspace=.53)
 fig.savefig(OUT/'fig_mechanisms_v3.pdf');fig.savefig(OUT/'fig_mechanisms_v3.png',dpi=200);plt.close(fig)
 (OUT/'FIGURE_DATA_V3.json').write_text(json.dumps({'completion':plot_data,'mechanism_effects':effects,'oracle_ledger':mech_data},indent=2)+'\n')
 (OUT/'FIGURE_REGENERATION_METADATA_V3.json').write_text(json.dumps({'status':'complete_from_full_audited_data','script_sha256':sha(Path(__file__)),'all_primary_n_per_curve':4640,'mechanism_n_per_reference':1280,'all_oracle_cases':192,'source_csv_sha256':inputs,'native_min_font_points':7.5,'figures':{p.name:sha(p) for p in OUT.glob('*_v3.pdf')}},indent=2)+'\n')
 print('Generated two publication figures and exact plotted-data JSON from complete audited results')
if __name__=='__main__':main()
