"""Small-file checks shared by the working analysis candidate.

This module grants no scientific audit admission. All runtime input paths refer
to this portable candidate; original absolute provenance strings are not opened.
"""
from pathlib import Path
from hashlib import sha256
import json
import os

ROOT = Path(__file__).resolve().parent.parent
THREAD_VARIABLES = (
    "OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS",
    "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS", "BLIS_NUM_THREADS", "ARROW_IO_THREADS",
)


def low_impact_environment():
    for name in THREAD_VARIABLES:
        os.environ[name] = "1"
    os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
    os.environ["MPLCONFIGDIR"] = str(ROOT / "results" / ".matplotlib_cache")
    if hasattr(os, "getpriority") and hasattr(os, "nice"):
        priority = os.getpriority(os.PRIO_PROCESS, 0)
        if priority < 10:
            os.nice(10 - priority)


def digest(path):
    return sha256(Path(path).read_bytes()).hexdigest()


def member(relative):
    path = Path(relative)
    if path.is_absolute() or ".." in path.parts:
        raise ValueError("relative artifact member required")
    result = ROOT / path
    if result.is_symlink() or not result.resolve().is_relative_to(ROOT):
        raise ValueError("artifact member escapes the portable candidate")
    return result


def runtime_bindings():
    return json.loads((ROOT / "RUNTIME_INPUT_BINDINGS.json").read_text())


def checked_path(relative):
    spec = runtime_bindings()["files"][relative]
    path = member(relative)
    if not path.is_file() or path.stat().st_size != spec["bytes"]:
        raise ValueError("missing or changed pinned input: " + relative)
    if digest(path) != spec["sha256"]:
        raise ValueError("pinned input SHA mismatch: " + relative)
    return path


def checked_json(relative):
    return json.loads(checked_path(relative).read_text())


def verify_runtime_inputs():
    entries = runtime_bindings()["files"]
    for relative in entries:
        checked_path(relative)
    return len(entries)


def fresh_output(path):
    output = Path(path).resolve()
    protected = [ROOT / n for n in (
        "inputs", "tools", "reference", "review_evidence", "assembly_notes",
        "MAST/reviewed_generator_v5", "MAST/reviewed_generator_v6",
    )]
    if output == ROOT or any(output.is_relative_to(p) for p in protected):
        raise ValueError("output must be outside immutable inputs/code/references")
    output.mkdir(parents=True, exist_ok=False)
    return output


def write_json(path, value):
    with Path(path).open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")


def compare_after_generation(generated, reference_relative):
    reference = checked_path(reference_relative)
    return {
        "generated_sha256": digest(generated),
        "reference_sha256": digest(reference),
        "byte_identical": Path(generated).read_bytes() == reference.read_bytes(),
        "reference_opened_after_generation": True,
    }
