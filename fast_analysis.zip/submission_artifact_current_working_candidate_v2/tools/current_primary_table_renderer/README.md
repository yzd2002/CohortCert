Current13-row primary-table renderer candidate

This is a thin, standard-library-only renderer for the current manuscript table. It reads five already published primary-summary fields from each of13 rows in two pinned, already audited oldD JSON summary artifacts: n, correct, mean_calls_per_support, sticky_or_other_execution_errors, and source_wrong_claim_or_proof_runs. It preserves Civil crowd/model five-method rows and Go crowd three-method rows, every4640 planned-unit denominator, all-unit call means, execution errors and source-wrong claim/proof counts. It neither reads raw CSVs nor recomputes experiments.

The renderer does not take a TeX input for generation. The optional public-table comparison is opened only after the generated table is written. Missing source fields, wrong summary hashes/statuses or different denominators cause failure; it never backfills values from the current TeX. Header wording, display method names, row order and decimal formatting are presentation rules; experimental values come only from the pinned summaries.

Portable layout example from a fresh artifact root with the tool folder beside04_Reproducibility:

python tools/current_primary_table_renderer/render_primary_table.py \
  --civil-summary 04_Reproducibility/v3_evidence/independent_analysis_v1/FINAL_CONTROL_AND_MECHANISM_SUMMARY.json \
  --go-summary 04_Reproducibility/v3_evidence/goemotions_validation/independent_analysis_v1/FINAL_GOEMOTIONS_SUMMARY.json \
  --outdir /a/fresh/current_table_output \
  --compare-table 03_Source/generated_primary_table.tex

The exact structured argv used in the single author check is recorded in VALIDATION_SCOPE.json. SOURCE_BINDINGS.json must stay beside the script unless --bindings names its exact copied file. The output directory must not already exist and must be outside the source summary directories. No source file is rewritten. Only this command's new output folder is written.

One small real reproduction from the two public summaries passed:13rows,65numeric comparisons including denominators/Correct/Calls/E/W, and exact current TeX byte equality (SHAa17d99eefe6477dbef0d7c5f39a33c4e55383a0fc3083a410349204e6d38c2b9). No required field was missing. Source document hashes also matched the originalD ARTIFACT_SHA256 inventory. The test measured self CPU0.0058s and wall0.10s; no child process, experiment, model or Native call was launched.

This is an author candidate, not an independently approved artifact. The earlier independent inventory report remains unchanged and correctly records the gap before this component existed. Root or another nonauthor must review this new component before adding it to a final supplement. This numerical rendering receipt is not a new experiment, raw-proof audit, confidence calibration, clean-room replay or overall reproducibility pass. It does not solve the outstanding licenses, public URL, complete raw-trace packaging, current-paper release map, or pending SourceS192/MAST research gates. No current closed input was accessed, andD, N/current source and the user work bundle were unchanged.
