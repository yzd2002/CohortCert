#!/usr/bin/env python3
"""Render current13-row table from pinned public audit summaries, using stdlib only."""
from pathlib import Path
from hashlib import sha256
from decimal import Decimal
import argparse,json,math,os,re,resource,time
ROOT=Path(__file__).resolve().parent
FIELDS=('n','correct','mean_calls_per_support','sticky_or_other_execution_errors','source_wrong_claim_or_proof_runs')
NAMES={'dual_greedy':'DifficultyGreedy','width':'WidthGreedy','neyman':'VarianceGreedy','matched':'Matched','forecast':'Forecast'}

def raw_json(path,cap=1048576):
    p=Path(path)
    if p.is_symlink() or not p.is_file() or p.stat().st_size>cap:raise ValueError('bounded regular public summary required')
    raw=p.read_bytes();return raw,json.loads(raw)
def integer(value,lo,hi):
    if type(value) is not int or not lo<=value<=hi:raise ValueError('plain bounded public count required')
    return value

def selected_rows(civil_path,go_path,bindings):
    summaries={};hashes={}
    for role,path in [('civil',civil_path),('go',go_path)]:
        spec=bindings['sources'][role];p=Path(path)
        if p.name!=spec['filename'] or '..' in p.parts or 'private' in p.parts:raise ValueError('explicit public-summary input role required')
        raw,obj=raw_json(p)
        if len(raw)!=spec['bytes'] or sha256(raw).hexdigest()!=spec['sha256'] or obj.get('status')!=spec['expected_status']:raise ValueError('pinned audited public summary changed')
        summaries[role]=obj['summary'];hashes[role]=spec['sha256']
    rows=[]
    for reference,method in bindings['published_layout']:
        if reference not in ('Civil C','Civil M','Go C') or method not in NAMES:raise ValueError('declared table layout differs')
        node=summaries['go'][method]['primary'] if reference=='Go C' else summaries['civil']['human' if reference=='Civil C' else 'model'][method]['primary']
        missing=[key for key in FIELDS if key not in node]
        if missing:raise ValueError('required upstream public primary field absent: '+','.join(missing))
        n=integer(node['n'],1,10**9)
        if n!=bindings['expected_primary_units_per_row']:raise ValueError('original planned-unit denominator differs')
        correct=integer(node['correct'],0,n);errors=integer(node['sticky_or_other_execution_errors'],0,n);wrong=integer(node['source_wrong_claim_or_proof_runs'],0,n)
        mean=node['mean_calls_per_support']
        if type(mean) not in (int,float) or not math.isfinite(mean) or not 0<=mean<=1:raise ValueError('finite all-unit normalized-call mean required')
        rows.append(dict(reference=reference,method_id=method,allocator=NAMES[method],n=n,correct=correct,calls_display=f'{mean:.4f}',execution_errors=errors,source_wrong_claim_or_proof_runs=wrong))
    if len(rows)!=bindings['expected_rows'] or len({(r['reference'],r['method_id']) for r in rows})!=len(rows):raise ValueError('exact unique current table rows required')
    return rows,hashes

def render(rows):
    ns={r['n'] for r in rows}
    if len(ns)!=1:raise ValueError('one retained primary denominator required')
    denominator=f'{next(iter(ns)):,}'.replace(',','{,}')
    lines=[r'\begin{table}[t]',r'\centering',r'\caption{All primary nonranking units: $'+denominator+r'$ per row. Civil C/M: CivilComments crowd/model; Go C: GoEmotions crowd. Correct requires every value and selected proof to match its reference. Calls/$|I|$ averages all units. E/W counts execution errors/source-wrong proofs, retained as unsuccessful.}',r'\label{tab:primaryv2}',r'\small',r'\begin{tabular}{llrrr}',r'\toprule',r'Reference & Allocator & Correct & Calls/$|I|$ & E/W \\',r'\midrule']
    previous=None
    for row in rows:
        if previous is not None and previous!=row['reference']:lines.append(r'\midrule')
        lines.append(f"{row['reference']} & {row['allocator']} & {row['correct']:,} & {row['calls_display']} & {row['execution_errors']}/{row['source_wrong_claim_or_proof_runs']} "+chr(92)*2)
        previous=row['reference']
    return '\n'.join(lines+[r'\bottomrule',r'\end{tabular}',r'\end{table}'])+'\n'

def public_table_numbers(text):
    match=re.search(r'All primary nonranking units: \$([^$]+)\$ per row',text)
    if match is None:raise ValueError('declared paper denominator missing')
    n=int(match.group(1).replace('{,}','').replace(',',''));rows=[]
    for line in text.splitlines():
        if not line.startswith(('Civil C &','Civil M &','Go C &')):continue
        parts=[part.strip() for part in line.split('&')]
        if len(parts)!=5:raise ValueError('five public table columns required')
        e,w=parts[4].rstrip(chr(92)).strip().split('/')
        rows.append((parts[0],parts[1],n,int(parts[2].replace(',','')),Decimal(parts[3]),int(e),int(w)))
    return rows

def write_new(path,raw):
    with Path(path).open('xb') as stream:stream.write(raw);stream.flush();os.fsync(stream.fileno())
def run(civil_path,go_path,outdir,bindings_path,comparison=None):
    cpu=time.process_time();wall=time.monotonic();binding_raw,bindings=raw_json(bindings_path)
    if bindings.get('schema')!='current-primary-table-summary-bindings/v1' or bindings.get('expected_rows')!=13 or set(bindings.get('sources',{}))!={'civil','go'}:raise ValueError('fixed current-table bindings required')
    rows,hashes=selected_rows(civil_path,go_path,bindings)
    # Generation has no TeX input. The optional comparison file is opened only
    # after the table has been derived and written from public summary fields.
    table=render(rows).encode();out=Path(outdir).resolve()
    if any(out.is_relative_to(Path(p).resolve().parent) for p in (civil_path,go_path)):raise ValueError('fresh output must be outside immutable summary directories')
    out.mkdir(parents=True,exist_ok=False);write_new(out/'generated_primary_table.tex',table)
    compared=None
    if comparison is not None:
        expected_path=Path(comparison)
        if expected_path.is_symlink() or not expected_path.is_file() or expected_path.stat().st_size>65536:raise ValueError('bounded public paper table required')
        expected_raw=expected_path.read_bytes();expected=public_table_numbers(expected_raw.decode());actual=public_table_numbers(table.decode())
        if len(expected)!=13 or actual!=expected:raise ValueError('public paper table numeric or row-order mismatch')
        compared=dict(path=str(expected_path.resolve()),sha256=sha256(expected_raw).hexdigest(),rows_compared=13,numeric_fields_per_row=5,numeric_field_checks=65,all_row_keys_and_numbers_match=True,byte_identical=table==expected_raw,comparison_read_after_generation=True)
    receipt=dict(schema='current-primary-table-public-summary-reproduction/v1',status='PASS_PUBLIC_SUMMARY_RENDER_ONLY',source_summary_sha256=hashes,source_bindings_sha256=sha256(binding_raw).hexdigest(),generated_table_sha256=sha256(table).hexdigest(),row_count=len(rows),denominators=[row['n'] for row in rows],public_rows=rows,upstream_required_fields_missing=[],comparison=compared,no_experimental_values_taken_from_TeX=True,no_rows_errors_wrong_proofs_or_denominators_dropped=True,CSV_or_raw_data_reads=0,experiment_model_Native_calls=0,current_Source192_or_MAST_closed_inputs_read=False,CPU_seconds=time.process_time()-cpu,wall_seconds=time.monotonic()-wall,independent_readiness=False)
    write_new(out/'REPRODUCTION_RECEIPT.json',(json.dumps(receipt,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode())
    return dict(status=receipt['status'],row_count=len(rows),numeric_field_checks=compared['numeric_field_checks'] if compared else 0,byte_identical=compared['byte_identical'] if compared else None,generated_table_sha256=receipt['generated_table_sha256'],CPU_seconds=receipt['CPU_seconds'],wall_seconds=receipt['wall_seconds'],experiment_calls=0)

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--civil-summary',type=Path,required=True);parser.add_argument('--go-summary',type=Path,required=True);parser.add_argument('--outdir',type=Path,required=True);parser.add_argument('--bindings',type=Path,default=ROOT/'SOURCE_BINDINGS.json');parser.add_argument('--compare-table',type=Path);args=parser.parse_args()
    resource.setrlimit(resource.RLIMIT_CPU,(4,5));resource.setrlimit(resource.RLIMIT_AS,(268435456,268435456))
    print(json.dumps(run(args.civil_summary,args.go_summary,args.outdir,args.bindings,args.compare_table),sort_keys=True))
