"""Portable public-summary presentation and old public CSV reconciliation.

No executor, Native consumer, model, source label, rank or raw trace is imported.
The Go narrative is a fixed editorial template with numbers from pinned public
summary fields. Reference TeX is opened only after output generation.
"""
import argparse
from collections import defaultdict
import csv
import json
import math
import sys

from artifact_common import (
    ROOT, checked_json, checked_path, compare_after_generation, digest,
    fresh_output, low_impact_environment, write_json,
)

FIELDS = (
    "n", "correct", "mean_calls_per_support",
    "sticky_or_other_execution_errors", "source_wrong_claim_or_proof_runs",
)


def texint(value):
    return f"{value:,}".replace(",", "{,}")


def summaries():
    civil = checked_json("inputs/public_summaries/FINAL_CONTROL_AND_MECHANISM_SUMMARY.json")
    go = checked_json("inputs/public_summaries/FINAL_GOEMOTIONS_SUMMARY.json")
    if civil["status"] != "complete" or go["status"] != "complete_and_all17120_audited":
        raise ValueError("frozen public summary status differs")
    return civil, go


def render_go(go):
    s = go["summary"]
    methods = ("dual_greedy", "width", "neyman")
    if any(s[m]["primary"]["n"] != 4640 for m in methods):
        raise ValueError("all planned Go primary denominators must remain 4640")
    contrasts = {x["control"]: x for x in go["contrasts"]}
    w, v, mx = (contrasts[m] for m in ("width", "neyman", "max_dg"))
    nodes = [s[m][scope] for m in methods for scope in ("primary", "ranking")]
    nodes.append(s["max_dg"]["summary"])
    total = sum(x["n"] for x in nodes)
    errors = sum(x["sticky_or_other_execution_errors"] for x in nodes)
    wrong = sum(x["source_wrong_claim_or_proof_runs"] for x in nodes)
    if total != go["rows"] or wrong != 0:
        raise ValueError("Go all-unit count/source-wrong status differs")
    words = ("zero one two three four five six seven eight nine ten eleven twelve "
             "thirteen fourteen fifteen sixteen seventeen eighteen nineteen").split()
    error_display = words[errors] if errors < len(words) else str(errors)
    pair = go["scalar_observable_agreement"]
    if pair["observable_mismatches"] != 0:
        raise ValueError("Go observable agreement differs")
    interval_w = ",".join(f"{x:.3f}" for x in w["completion_pp_seed_block_95_percentile"])
    interval_m = ",".join(f"{x:.2f}" for x in mx["completion_pp_seed_block_95_percentile"])
    text = (
        "On independently sourced GoEmotions, DifficultyGreedy completes $"
        + texint(s["dual_greedy"]["primary"]["correct"]) + "/"
        + texint(s["dual_greedy"]["primary"]["n"]) + "$ primary units, WidthGreedy $"
        + texint(s["width"]["primary"]["correct"]) + "$ and VarianceGreedy $"
        + texint(s["neyman"]["primary"]["correct"]) + "$. The width comparison is a near tie: $"
        + f'{w["DG_minus_control_completion_pp"]:+.3f}' + "$ completion points with interval $["
        + interval_w + "]$, and $" + f'{w["DG_normalized_call_reduction_percent"]:.2f}'
        + r"\%$ fewer normalized calls. Against variance allocation the differences are $"
        + f'{v["DG_minus_control_completion_pp"]:+.2f}' + "$ points and $"
        + f'{v["DG_normalized_call_reduction_percent"]:.2f}'
        + r"\%$ fewer calls. Another $" + texint(pair["pairs"])
        + "$ scalar/equivalence pairs agree on the checked observable fields. Summary gain aggregation completes $"
        + texint(s["dual_greedy"]["summary"]["correct"]) + "$ versus MaxDifficulty's $"
        + texint(s["max_dg"]["summary"]["correct"]) + "/" + texint(s["max_dg"]["summary"]["n"])
        + "$ units: $" + f'{mx["DG_minus_control_completion_pp"]:+.2f}'
        + "$ points with interval $[" + interval_m + "]$, and $"
        + f'{mx["DG_normalized_call_reduction_percent"]:.2f}'
        + r"\%$ fewer calls. GoEmotions therefore does not reproduce a clear completion advantage over width or maximum-decision allocation. All $"
        + texint(total) + "$ records reconcile with the independent reference/prefix/proof audit; "
        + error_display + " sticky errors across primary and ranking controls remain, with no source-wrong proof. Secondary ranking completions are $"
        + "/".join(str(s[m]["ranking"]["correct"]) for m in methods)
        + "$ for difficulty/width/variance allocation.\n"
    )
    return text, {"rows": total, "execution_errors": errors, "source_wrong": wrong,
                  "scalar_observable_pairs": pair["pairs"], "new_audit_performed": False}


def render_semantic():
    obj = checked_json("inputs/legacy_semantic/cross_source_reference_agreement.json")
    selected = [r for r in obj["all_fixed_maps_and_cohorts"]
                if r["comment_mention_group"] == "ALL_FROZEN_ROWS"]
    if len(selected) != 4 or any(r["n"] != 30000 for r in selected):
        raise ValueError("four original 30000-row semantic summaries required")
    names = {"toxicity": "Toxicity", "insult": "Insult",
             "identity_attack": "Identity attack", "obscene": "Obscene"}
    lines = [r"\begin{table}[t]", r"\centering",
             r"\caption{Pinned model labels relative to existing thresholded crowd references, all $30{,}000$ rows per predicate. Percentages are descriptive; precision/recall concern the positive class.}",
             r"\label{tab:semanticv2}", r"\small", r"\begin{tabular}{lrrrr}",
             r"\toprule", r"Predicate & Agreement & Precision & Recall & Bal. acc. \\", r"\midrule"]
    metrics = ("agreement_accuracy_relative_crowd", "precision_relative_crowd",
               "recall_relative_crowd", "balanced_accuracy_relative_crowd")
    for pred, label in names.items():
        row = next(r for r in selected if r["predicate"] == pred)
        if any(not math.isfinite(row[k]) or not 0 <= row[k] <= 1 for k in metrics):
            raise ValueError("finite semantic proportion required")
        lines.append(label + " & " + " & ".join(f"{100 * row[k]:.2f}" for k in metrics) + r" \\")
    return "\n".join(lines + [r"\bottomrule", r"\end{tabular}", r"\end{table}"]) + "\n"


def tables(out):
    _, go = summaries()
    narrative, scope = render_go(go)
    semantic = render_semantic()
    out = fresh_output(out)
    (out / "generated_goemotions_results.tex").write_text(narrative)
    (out / "generated_semantic_table.tex").write_text(semantic)
    comparisons = {name: compare_after_generation(out / name, "reference/current_public_artifacts/" + name)
                   for name in ("generated_goemotions_results.tex", "generated_semantic_table.tex")}
    if not all(v["byte_identical"] for v in comparisons.values()):
        raise ValueError("generated public presentation differs from the frozen manuscript")
    receipt = {"schema": "portable-summary-tables-reproduction/v1", "status": "PASS_PUBLIC_SUMMARY_RENDER_ONLY",
               "Go_scope": scope, "semantic_rows": 4, "semantic_metrics_compared": 16,
               "comparisons": comparisons, "values_taken_from_reference_TeX": False,
               "experiment_model_Native_calls": 0, "independent_review_of_new_wrapper": False}
    write_json(out / "REPRODUCTION_RECEIPT.json", receipt)
    return receipt


def reconcile(out):
    civil, go = summaries()
    projection = checked_json("assembly_notes/LEGACY_CSV_PROJECTION_RECEIPT.json")
    groups = defaultdict(list)
    total = 0
    for spec in projection["files"]:
        path = checked_path(spec["candidate_path"])
        with path.open(newline="") as stream:
            rows = list(csv.DictReader(stream))
        if len(rows) != spec["original_rows"] or len(rows) != spec["retained_rows"]:
            raise ValueError("projected shard omitted a planned row")
        dataset = "go" if "goemotions_validation" in spec["source_relative_to_old_04"] else "civil"
        for row in rows:
            groups[dataset, row["source"], row["method"]].append(row)
        total += len(rows)
    checks = []
    for (dataset, source, method), rows in sorted(groups.items()):
        scopes = ("summary",) if method == "max_dg" else ("primary", "summary", "ranking")
        for scope in scopes:
            rr = [r for r in rows if r["kind"] == scope or (scope == "primary" and r["kind"] != "ranking")]
            if not rr:
                raise ValueError("prespecified summary scope has no planned rows")
            expected = (go["summary"] if dataset == "go" else civil["summary"][source])[method][scope]
            actual = {"n": len(rr), "correct": sum(r["correct_complete"] == "True" for r in rr),
                      "mean_calls_per_support": sum(float(r["calls_per_support"]) for r in rr) / len(rr),
                      "sticky_or_other_execution_errors": sum(r["status"] == "execution_error" for r in rr),
                      "source_wrong_claim_or_proof_runs": sum(r["source_error"] == "True" for r in rr)}
            for field in FIELDS:
                if abs(actual[field] - expected[field]) >= 1e-12:
                    raise ValueError(f"public summary mismatch: {dataset}/{source}/{method}/{scope}/{field}")
            checks.append({"dataset": dataset, "source": source, "method": method, "scope": scope, **actual})
    out = fresh_output(out)
    receipt = {"schema": "projected-public-csv-summary-reconciliation/v1", "status": "PASS_OLD_PUBLIC_CSV_TO_SUMMARY_ONLY",
               "input_shards": len(projection["files"]), "all_original_rows_retained": total,
               "summary_rows": len(checks), "numeric_field_comparisons": len(checks) * len(FIELDS),
               "max_numeric_tolerance": 1e-12, "rows": checks, "new_experiment_or_raw_proof_audit": False,
               "model_Native_calls": 0, "independent_review_of_new_wrapper": False}
    write_json(out / "RECONCILIATION_RECEIPT.json", receipt)
    return receipt


if __name__ == "__main__":
    low_impact_environment()
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("mode", choices=("tables", "legacy-summary"))
    p.add_argument("--out", required=True)
    a = p.parse_args()
    result = tables(a.out) if a.mode == "tables" else reconcile(a.out)
    print(json.dumps({k: v for k, v in result.items() if k not in ("rows", "comparisons")}, ensure_ascii=False))
