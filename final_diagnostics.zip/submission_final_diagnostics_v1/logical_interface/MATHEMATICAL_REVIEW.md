# N=100 logical-support integrity: exhaustive finite arithmetic analysis

This analysis extends a saved-point diagnosis into a complete, data-independent characterization of one numerical interface. It does not run a confidence sequence, estimate coverage, rerun any method trajectory, or change an existing result. The study was designed **after the original A outcomes were known**; `DESIGN.json` was frozen before its sole arithmetic enumeration.

## What was inspected

The original binary logical bounds in the pinned `confseq.betting.logical_cs` are

\[
 l_{n,s}=\operatorname{fl}(s/100),\qquad
 u_{n,s}=\operatorname{fl}(1-\operatorname{fl}((n-s)/100)).
\]

The original adapter does not round an ordinary floating-point product. It converts the adjacent outward float to its **exact rational value**, multiplies that rational by 100, and then takes integer ceil/floor. With a nonrestrictive previous domain, its readout of logical bounds is

\[
 a_{n,s}=\max\{s,\lceil100Q(\operatorname{down}(l_{n,s}))\rceil\},\quad
 b_{n,s}=\min\{s+100-n,\lfloor100Q(\operatorname{up}(u_{n,s}))\rfloor\}.
\]

Here `fl` denotes the inspected binary64 arithmetic formula, `Q` the exact rational represented by a binary64 number, and `down/up` one `nextafter` step. The exact logical count support is `[s,s+100-n]`. A hypothetical pre-cap interval `[0,1]` is used to isolate the cap/readout interface; it is guaranteed to contain every feasible population mean. It is not a saved or newly computed statistical interval.

All 5,151 feasible integer `(n,s)` states were retained. Of these, 5,049 have `1<=n<=99`, the prefix range in which the inspected original progressive adapter can use CI readout. The `n=0` state is only a formula extension. The 101 `n=100` states are arithmetic controls: **the actual adapter instead uses its exact-census branch**, so failures of the unused formula at census are not actual CI errors. That branch still checks the preceding sticky domain; it does not erase an earlier exclusion or permit historical backfill.

No NumPy, confseq, Evergreen or other original/corrected method module was imported. The corrected table was read as a literal constant through `ast.literal_eval` and checked against its fixed SHA-256. Thus the result audits the specified arithmetic interface and the literal table, not the complete runtime or the statistical implementation.

## Exhaustive findings

| Nested state domain | States | Original readout loses feasible support | Directed-cap control loses feasible support |
|---|---:|---:|---:|
| All mathematical states, `0<=n<=100` | 5,151 | 101 | 0 |
| CI-prefix range, `1<=n<=99` | 5,049 | 94 | 0 |
| Near-census subset, `n=99` | 100 | 7 | 0 |

These are **cardinalities of deterministic interface states**, not random samples, independent replications or error-rate estimates. The nested rows must not be added. All losses are at the upper endpoint, by exactly one count. The original outward lower readout loses no feasible lower count. The seven empty formula domains occur only at `n=100`, where the real adapter bypasses the formula. There are no empty domains in the 5,049 tested noncensus full-support controls.

The complete affected logical upper-count set is

\[
 \mathcal B=\{7,8,9,10,19,20,21\}.
\]

Every result and failure appears in `ALL_5151_STATES.csv` and `ALL_BASELINE_FAILURE_STATES.csv`; all 100 near-census states are in `ALL_N99_STATES.csv`. Raw rounding inward is a different metric from losing an integer support endpoint: the old raw lower/upper bounds round inward in 2,900/2,630 mathematical states, respectively, but the outward count readout removes all lower losses and leaves only the 101 upper losses above. Reporting raw inward-rounding counts alone would substantially overstate the final count-interface defect.

The independent directed construction matches every one of the frozen correction table's 5,151 pairs. Its two exact enclosure inequalities pass at every state, and the unchanged outward Fraction readout returns the full logical count support in every controlled state. This validates the logical-cap mapping; it does not establish full CI coverage.

## A complete finite characterization, not 5,151 unrelated examples

Let `k=s+100-n` be the logical upper count, and set

\[
 q_k=\operatorname{fl}(1-\operatorname{fl}((100-k)/100)),\qquad
 h_k=\lfloor100Q(\operatorname{up}(q_k))\rfloor.
\]

The upper obstruction depends only on `k`, because `n-s=100-k`. The enumeration establishes, for every `k=0,...,100`, that `h_k=k-1` exactly for `k` in `B`, and otherwise `h_k=k`. Each affected `k` appears in `k+1` mathematical states (`n=100-k,...,100`), of which exactly `k` have `1<=n<=99`. Consequently,

\[
 \sum_{k\in\mathcal B}(k+1)=101,\qquad
 \sum_{k\in\mathcal B}k=94.
\]

This explains the complete state counts rather than treating their frequency as a statistical measurement.

**Upper-obstruction proposition.** Under the inspected binary64 formula and exact-Fraction readout, take any feasible noncensus state whose logical upper count `k` belongs to `B`. If a finite CI upper `U` is clipped to this logical cap, then every normally formed count domain has upper at most `k-1`, irrespective of the pre-cap statistical upper or observation order.

**Proof.** The clip implies `U<=q_k`. One-step upward adjacency is monotone on finite binary64 numbers, and rational multiplication/floor is monotone. Therefore `floor(100 Q(up(U)))<=h_k=k-1`. Intersecting with logical or previous count domains can only reduce this upper bound. If another constraint makes the domain empty, the original adapter raises rather than returning a normal interval; an exception is not an emitted false assertion. The proposition is a conditional interface statement, not proof that every relevant program call returns normally. □

For the original saved point `(100,99,19)`, `k=20` and the original exact-Fraction readout gives upper 19. Ordinary binary64 `floor(100*up(q_20))` instead gives 20. That difference documents why substituting floating multiplication for the actual adapter arithmetic would invalidate the argument; it is not evidence that floating multiplication is a general repair.

## Probability statements require additional premises

For each affected fixed population total `K` in `B`, under a full uniform-without-replacement permutation of 100 fixed binary records,

\[
 E_K=\{S_{99}=K-1\}=\{\text{the last record is positive}\},\qquad
 \Pr(E_K)=K/100.
\]

Let `R` mean that the relevant potential prefix returns a finite logical-clipped CI and normally forms its count domain. The obstruction proves only

\[
 \Pr\{R\text{ and }K\notin D_{99}\}\ge\Pr(E_K\cap R).
\]

If normal return/domain formation on **all** paths of `E_K` were independently established, this would give the lower bound `K/100` for the full-prefix count interface. That premise was not proved or experimentally checked here. In an actual early-stopped execution, the event must additionally intersect `T>=99`; its probability cannot be inferred from the finite-state grid. The previous `K=20` conditional `0.2` argument is one member of this family, not a rate derived from the two outcome-selected A histories. No probability is newly assigned to a fixed saved order.

Count noncoverage and false request assertions are different events. The two retained original A error histories had correct online and final assertions; their historical clean-history credit remains unchanged. This enumeration neither calibrates their request risk nor repairs those histories.

## What the directed correction does prove

For every supported state, let `L_c<=s/100` and `U_c>=(s+100-n)/100` be the checked directed logical enclosures. Suppose the pre-cap interval contains a feasible truth `K/100`, and the previous count domain contains `K`. Since `s<=K<=s+100-n`, intersecting the pre-cap interval with `[L_c,U_c]` still contains `K/100`. Moving its endpoints outward preserves containment; exact-rational multiplication and integer ceil/floor then retain `K`. The remaining logical and previous-domain intersections also retain it. □

This is a conditional preservation invariant: a truthful statistical interval and truthful prior domain cannot lose truth **solely through the corrected logical cap and this count readout**. It does not prove that the preceding grid/betting calculations are truthful or numerically valid. Old traces lack pre-cap bounds, so even zero failures in this controlled audit does not prove that changing the cap would repair either original A path. The correction remains a separately versioned prospective numerical configuration, not a retroactive replacement of the original Native results.

## Scientific significance and limits

The local diagnosis is stronger than two selected examples: the scope is exhaustive at the fixed `N=100`; the affected counts are completely characterized; and a known-valid pre-cap control isolates the logical cap from statistical evidence. The directed intervention removes every defect of that interface while leaving the readout formula unchanged. This is a useful, reproducible numerical integrity result and a concrete reason that proof-cost claims need validated numerical endpoints.

It does **not** close the full paper's principal scientific gaps. For B1, a finite floating-point interface characterization does not add novel optimization depth, exercise the unused generic proof representation, or establish material allocation gains. For B2, 5,151 arithmetic states are not 5,151 benchmark tasks; the MAST comparison remains one request with eight paths. For B3, the analysis isolates this local numerical mechanism, but explains neither Forecast's losses nor wide oracle brackets, budget crossing or a causal online benefit. It supports a narrower and more exact validity discussion, not a Strong Accept judgment. A full revised paper would need a fresh independent scientific assessment after substantive changes.
