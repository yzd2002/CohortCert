# Strict comparisons, confidence-proof families and tolerance: a synthetic boundary example

This is an author-produced mathematical construction and exact finite check, pending independent validation. No real labels, Source-S case, MAST payload, existing CI implementation, Native module or random-number generator was read or invoked. The symbols A, B and X are abstract cohorts, not particular released traces.

## What is established

| Construction | Requested decisions | Certificate family | Charged original records | Type of statement |
|---|---|---|---:|---|
| Original 42-stream family | All 28 comparisons use strict difference >0 | Marginal count LR mean-e region at Γ=840, local consequences and recursively retained affine consequences | 205 | Necessary and constructively sufficient on the specified all-zero population |
| Auxiliary OR construction | The same 28 strict decisions | A direct intersection-union certificate for zero OR count in A and B, nominal whole-vector α=1/20 | 197 | Achievable by the explicitly defined different proof family; not a universal optimum |
| Tolerance construction | All 28 comparisons use difference >5/100 | Declared Beta(1,1) formal predictor and the original local count boxes at Γ=840 | 171 | Constructive upper bound for a different requested contract; not a Full-versus-control gain |

The all-zero population is known to the evaluator of this example, not to its inference rules. No assertion is made that current MAST requests have this population or that the present Source implementation supports multi-label bundles. These numbers are acquisitions of whole records, each revealing fourteen flags; they are not fourteen separately billed observations, wall times, or physical model-forward counts.

## 1. Observation model and confidence event

There are three disjoint cohorts A, B and X, each containing 100 fixed records. A record carries fourteen arbitrary binary flags. Flags within a record may be perfectly dependent. A charged five-record pilot is taken in each cohort; in the construction all fifteen pilot flag vectors are zero. Conditional on the completed pilot, each cohort has a fixed residual population of M=95 records. There are H=3×14=42 marginal flag streams. The original rate denominator is still 100: a formal residual count K contributes K/100 because the observed pilot counts are zero.

At each full-record checkpoint, the cohort-selection policy is determined by completed past information, or by a randomization distribution determined by that past and independent of the next record. Within the chosen cohort, the next unseen record is uniform conditional on the full completed past. This conditional-uniform statement is the needed sampling assumption; correlated or reused permutations that violate it are not covered.

The past may contain identities and all flags of previously completed records. The newly sampled identity and all fourteen current flags enter the filtration in one atomic step. Each stream's normalized predictive probabilities must be fixed before that new identity/current vector is revealed. No inference, new predictor, or allocation is inserted between modes of the same record. Merely using an identity to look up the selected record is allowed; using that current identity as predictive side information while retaining an unconditioned marginal hypergeometric denominator is not justified by this proof.

For stream h, let e_h be the product of its predictable binary likelihood ratios Q_h/P_{K_h}, updated only when its cohort is sampled. Before a draw from a cohort with n previous formal records and s positives in this mode, the true conditional positive probability is (K_h−s)/(M−n). For a normalized predictor q_h fixed before the draw,

E[e_h,new | completed past, chosen cohort] = e_h,old × Σ_{y:p_h(y)>0} q_h(y) ≤ e_h,old.

If a true outcome has zero probability, it cannot occur; the sum over its true support can be below one. Thus every coordinate is a nonnegative supermartingale at full-record checkpoints. The fourteen coordinate updates can be dependent: linearity, not independence, gives the same supermartingale inequality for their sum. Unselected coordinates remain unchanged. Consequently Σ_h e_h starts at H=42, and Ville's inequality gives

Pr[there exists a checkpoint with Σ_h e_h(K_h,true) ≥ Γ] ≤ H/Γ = 42/840 = 1/20.

The wealth threshold Γ is not the acquisition budget. The common all-time event F consists of the strict inequalities Σ_h e_h(K_h,true)<Γ. It implies the corresponding local e_h<Γ statements. It also covers recursively retained target intervals if each is an actual logical consequence of its earlier admissible region.

The feedback architecture considered below can use only deterministic count support, these running local consequences, the current sum cut and affine consequences of earlier regions formed from the same information. The retained region may be an outer approximation of full history. It cannot add an unrelated test, an auxiliary OR confidence bound, known population totals, or unsupported mode relations and still invoke the following lower bound.

## 2. A strict-comparison boundary for that family

The 28 decisions ask, for every mode m, whether p_A,m>p_X,m and whether p_B,m>p_X,m. False means ≤0, including equality. The constructed full population has all flags zero. All observations therefore remain zero under every admissible acquisition schedule.

Suppose A still has at least one unread formal record. Select any mode m, and consider the count vector with K_A,m=1 and every other residual count zero. It is consistent with the known zero pilot and every completed record. For an all-zero binary prefix of length n≤94,

P_1(0^n) = (M−n)/M ≥ 1/M.

Every product of normalized predictive probabilities is at most one. The selected coordinate therefore has e_A,m≤M=95; each of the 41 zero-count coordinates has P_0(0^n)=1 and e_h=Q_h(0^n)≤1. Hence

Σ_h e_h(K_h,alternative) ≤ M+H−1 = 136 < 840.

This strict inclusion holds at every earlier checkpoint at which A was unexhausted, irrespective of how the other cohorts were sampled or how normalized predictors used completed past information. The same candidate survives every scalar local e<Γ box and deterministic support restriction. By induction it also survives every sound historical affine consequence retained by Full: the candidate belonged to the earlier region that justified that consequence. Thus feedback of those consequences cannot remove it.

The candidate has p_A,m−p_X,m=1/100>0. A valid interval proof for the actual false decision cannot be issued while this candidate is retained. The argument for B is identical. Both A and B must exhaust their 95 formal records. Including all fifteen mandated pilot records gives the necessary charged cost

15+95+95 = 205.

The bound is attainable by an ideal valid interval-proof procedure, not a claim about existing optimizer time. Use a fixed A-then-B schedule. Once A and B are fully observed, every one of their mode counts is exactly zero; X has a nonnegative count even though only its pilot was sampled. The upper bounds on all 28 contrasts are then zero, which suffices to certify their false values under the strict >0 contract. This costs 205 records. Exact census knowledge is deterministic and needs no additional error budget.

For the separately declared Beta(1,1) formal predictor, the bound is even visibly conservative as an e-value bound: Q(0^n)=1/(n+1), so e_1(0^n)=M/[(n+1)(M−n)]≤1 for n=0,…,M−1. Nevertheless the general 136 bound is useful because it does not depend on that particular predictor. Its essential assumptions are the certificate family, zero observations in every stream, and the strict target semantics.

This is not an information-theoretic lower bound, a lower bound for any confidence architecture, or a diagnosis of observed real-data completions. In particular it does not follow from observing only one zero mode while other mode histories are arbitrary.

## 3. The same strict contract can use another proof family

For a record from A or B, define Y_OR to be the OR of its fourteen already acquired flags. Computing it has zero additional acquisition cost in this model. Let K_i,OR be the formal positive-OR count in cohort i∈{A,B}.

If the A or B pilot contains a positive OR, the proposed shortcut is disabled and the procedure uses exact full census. Otherwise, after the known-zero pilot, define a per-cohort test process

e_i(n_i) = 1{no positive formal OR has been observed in i} × M/(M−n_i), for n_i<M.

This corresponds to the normalized always-zero predictor. Under any null K_i,OR≥1, conditional on no earlier positive and n_i<M−1,

E[e_i(n_i+1)|past]/e_i(n_i) = (M−n_i−K_i,OR)/(M−n_i−1) ≤1.

At n_i=M−1 a feasible positive null must reveal a positive next, so the conditional expected next value is zero. An all-zero census is impossible under that null and is handled as deterministic zero knowledge. Unselected-cohort steps leave e_i unchanged. Each e_i is therefore a valid nonnegative test supermartingale for its own composite positive-count null under the stated sampling model.

The relevant macro null is a union: K_A,OR≥1 or K_B,OR≥1. Set the macro statistic to min(e_A,e_B), and to zero forever if an A/B positive OR is seen. Under every parameter in this union at least one individual null is true. The macro statistic is pointwise no greater than that true-null supermartingale. It is therefore an anytime-valid e-process for the union null by domination. No claim is made that the minimum itself is a supermartingale under every union-null distribution.

Reject the union null only when the macro statistic reaches 1/α=20. On the all-zero path this requires n_A,n_B≥91, because

95/5 = 19 < 20 < 95/4.

A fixed alternating A/B schedule reaches n_A=n_B=91 after 182 formal records, for total charged cost 15+182=197. The resulting macro certificate states that every A/B mode count is zero. All 28 original strict comparisons are false because X's counts are nonnegative. No formal X records are needed. If a positive is observed, or the shortcut does not certify, full census supplies exact outputs. This fallback adds no error probability.

For any true population, a wrong complete output via this shortcut implies a false macro zero assertion. The domination/Ville argument bounds that probability by α=1/20 conditional on the permitted pilot, and hence unconditionally when integrating over pilots; pilots with positive A/B OR use exact fallback. The guarantee does not assume mode independence.

This can also be expressed as a joint count-confidence region, rather than a weaker correctness-only output promise. Before a shortcut certificate, retain the deterministic feasible count region. At the certificate constrain all A/B mode counts to zero and keep X feasible. On exact fallback use the census point. Exclusion of the true count vector by this stopped region implies the same false macro assertion, so it too has joint anytime error at most α. The region is deliberately coarse before the macro witness; it is not the original 42-stream sum region.

There is also a direct fixed-rule calculation. If exactly one A record has one positive mode and all other flags, including X, are zero, conditioning on a zero A pilot leaves its position uniform among 95 formal records. The shortcut misses it only in the four positions after the first 91. The conditional wrong-vector probability is exactly 4/95<1/20. If the pilot is the first five records of a uniform whole-cohort permutation, its unconditional probability is 4/100=1/25: a pilot positive forces exact fallback, and a miss requires a position in the last four original positions. The same statements hold for B. The exact 1/25 statement requires this uniform-pilot assumption; the main conditional guarantee does not.

For more than one OR-positive record in a true-null cohort the zero-survival probability is no larger. The exact finite ordinal checks are supplementary confirmation of this model calculation, not an empirical error-rate estimate of any existing method.

This supplies a scope counterexample to treating 205 as a universal strict-query bound: a different proof family, with the same nominal global α and the same 28 requested decisions, can certify this population in 197 records. It uses a stronger macro witness rather than the original 42-stream sum region. It is not a measured FullFeedback improvement, a claim of statistical novelty, or broad superiority of the shortcut.

For an illustrative 200-record cap, 197≤200<205 is therefore a pure synthetic architecture crossing. It is not a Source-S crossing, does not meet or replace that study's material-effect gates, and does not support FullFeedback over CheapLinear. In fact the 205 boundary applies to the specified Full family as well.

## 4. Changing the tolerance is another, distinct choice

Keep Γ=840 and choose the declared formal Q=Beta(1,1) predictor, independent of any real method's predictor. Its zero-prefix probability is 1/(n+1). For any feasible K after n zeros,

P_K(0^n) = C(M−K,n)/C(M,n) = C(M−n,K)/C(M,K).

Counts K>M−n are logically infeasible. The exact local count set retains feasible K whose running e-value has not reached Γ. As K increases at fixed n, its zero-prefix likelihood decreases, so rejecting K=6 also rejects all feasible K≥6.

The complete n=0,…,95 and K=0,…,95 enumeration finds the first rejection of K=6 at n=78:

- At n=77, e_6 = 3183545/5304 < 840, so K=6 is retained.
- At n=78, e_6 = 9550635/10744 > 840, and every K≥6 has been excluded.
- The true zero count is retained at every prefix; at census it is the only feasible count.

If the requested predicate changes from difference >0 to difference >5/100, having A/B mode counts ≤5 and X mode counts ≥0 certifies all 28 false values. A schedule taking 78 formal A records and 78 formal B records therefore has a constructive charged upper bound

15+2×78 = 171.

The 34-record difference from 205 changes the requested contract. It is not a speedup of Full over Cheap, an optimum for the tolerant task, or a real-data result. The exact n=78 threshold is for the declared predictor and exact Γ=840; software risk rounding and different predictors are not silently substituted.

## 5. Why bundle atomicity and current-ID restrictions matter

Two fixed records with two flags (0,0) and (1,1) give a minimal counterexample to a weakened proof. Draw one record uniformly. Both first-step marginal flag probabilities are 1/2. If both predictors are fixed to (1/2,1/2) before the draw, their likelihood-ratio updates are both one. If, instead, the first flag is revealed and the second predictor assigns probability one to that observed value, the second update using the old marginal denominator is two with certainty. The expected sum becomes three from initial two. Given the first flag, the true second-flag conditional probability is one, not 1/2. Its predictor may be normalized, but it is not a valid pre-bundle predictor for the retained denominator.

Likewise, if the newly drawn record identity reveals its flag and a predictor uses that identity before the label update, a certain predictor divided by the unconditioned 1/2 denominator gives e=2 with certainty. Conditioning on the identity would require the correct conditional label law. The parent proof instead avoids this problem by freezing predictors before the sampled identity and checking only complete-record checkpoints.

These examples explain restrictions of this derivation. They do not assert that existing Source or MAST implementations violate them.

## 6. Evidence, limitations and reproducibility

The design and clarification were frozen before the unique execution. `PREEXECUTION_FREEZE.json` binds them and the exact source. `OWNED_ENUMERATION_ONCE_CLAIM.json` prevents an in-place repeat. The computation used only Python's standard library, exact integers, Fraction and comb, at nice 10 with numeric thread variables one; it started no children. `RESOURCE_RECEIPT.json` distinguishes measured CPU from conservative startup/author-preparation reserves.

All 9,216 scalar (n,K) rows, all 96 prefix summaries, all 95 strict-alternative bounds, all 9,216 OR count-pair rows, all 4,560 positive-null one-step checks, all 190 conditional and 200 full-permutation one-positive positions, and both two-record assumption examples are retained. No stochastic draws, bootstrap or real inference execution are involved.

This construction supports a concrete explanation of the conditional proof-cost frontier: changing an allocator cannot cross a genuine frontier of its fixed proof family, but changing a certificate family or changing the requested tolerance can. The two choices have different semantics and must remain separate. Its logical structure is elementary finite-support resolution and union-null domination; it does not establish a new statistical theorem's priority. It does not resolve the paper's main novelty/breadth objections or justify Strong Accept. Any use in the manuscript needs a new independent mathematical check and appropriate scope labeling.
