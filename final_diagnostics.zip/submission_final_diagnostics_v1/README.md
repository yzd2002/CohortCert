# Final finite diagnostics for CohortCert

This addendum supplies the finite mathematical examples and numerical-interface state enumeration added to the final manuscript. It also retains the full vector runtime plot moved from the main paper; all 23-execution runtime numbers and adverse outcomes remain in the main text.

## Reproduce the reported finite quantities

Python 3.9 or later is needed for `math.nextafter`; the numerical-interface result assumes binary64 round-to-nearest floats. The released entry point has no external Python dependencies, network access, model calls, CI-library imports, datasets, random seeds or privileged launch requirements.

After extraction, from this directory:

```sh
python3 -B reproduce_diagnostics.py --out reviewer_results_01
```

Use a new output-directory name. The program checks all listed file hashes, recalculates all 9,216 Beta/count states and 5,151 logical-interface states, compares key fields of every saved logical-interface row, and writes `REPRODUCED_SUMMARY.json`. It reproduces **205 / 197 / 171** and **94 of 5,049**. It does not rerun a statistical method, native adapter, original trajectory, model inference or the larger study. The remaining synthetic CSVs preserve the original finite evidence; the portable entry point does not recheck every field of those additional files.

## Read the construction correctly

The synthetic request is `A_m > X_m` and `B_m > X_m` for fourteen modes. The real fixed MAST request is `A_m > B_m` and `A_m > C_m`; their direction structures differ. Three synthetic cohorts each have 100 records and five charged pilot records; one atomic acquisition reveals the identity and all fourteen flags. The population is constructed all zero, and that fact is withheld from inference. Predictors are fixed before the current identity/vector is revealed; conditional within-cohort sampling is uniform. Flag independence is not required.

* 205 is necessary and sufficient only for the stated 42-stream marginal/mean-e/history-consequence proof family.
* 197 is a feasible mathematical cost for a different OR count-confidence family at the same global risk 0.05 and the same synthetic strict request. Validity uses domination by a true-null process; the minimum is not asserted to be a union-null supermartingale.
* 171 is a feasible cost after changing the decision threshold to 0.05, using the declared Beta(1,1) predictor. It changes the requested task.

The 200-record cap is illustrative. Positive pilots disable the OR shortcut. Positive observations trigger full-census fallback if affordable; otherwise the cap returns unresolved. The retained 190/200-position CSVs describe the uncapped fallback rule, as explained in `synthetic/BUDGET_SCOPE.json`. None of these costs is an empirical MAST/FullFeedback gain, a universal lower bound or a guarantee of completion for every population.

## Read the logical audit correctly

The post-hoc numerical diagnostic uses a nonrestrictive [0,1] pre-clip control. It finds 94 feasible-upper-count losses among 5,049 proper-prefix mathematical states (n=1,...,99); directed logical enclosures remove these interface losses. These are state cardinalities, not observed error rates or coverage estimates. The real exact-census branch bypasses the n=100 formula. Correcting this interface does not retroactively repair historical paths or establish full statistical coverage. The original two MAST error histories remain uncredited despite correct online/final answers.

Historical summaries and reports are byte copies and retain their status at capture. `PROVENANCE.json` records their exact source identities and subsequent bounded arithmetic-validation pins. Internal whole-paper scientific reviews and author-specific CMT administration are excluded. The base repository's source, dataset and dependency notices continue to apply; no blanket third-party relicensing is made.
