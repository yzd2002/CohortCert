"""Reproduce the final paper's finite constructions using only Python's stdlib.

No model, statistical CI implementation, external dataset or randomness is used.
The historical per-run evidence remains immutable. This entry point verifies the
selected public member hashes, then recalculates the manuscript quantities.
"""
from pathlib import Path, PurePosixPath
from fractions import Fraction as Q
from math import ceil, floor, comb, nextafter, inf
import argparse
import csv
import hashlib
import json
import sys

HERE = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_members():
    manifest = json.loads((HERE / 'FILES_SHA256.json').read_text())
    for item in manifest['files']:
        rel = PurePosixPath(item['path'])
        if rel.is_absolute() or '..' in rel.parts:
            raise ValueError('Unsafe manifest path')
        path = HERE / rel
        if not path.is_file() or path.is_symlink():
            raise ValueError('Missing or nonregular member: ' + str(rel))
        if path.stat().st_size != item['bytes'] or digest(path) != item['sha256']:
            raise ValueError('Member integrity mismatch: ' + str(rel))
    return len(manifest['files'])


def synthetic_costs():
    M, H, pilot, gamma = 95, 42, 15, Q(840)
    first = None
    running = [True] * (M + 1)
    states = 0
    for n in range(M + 1):
        retained = []
        for K in range(M + 1):
            p = Q(comb(M - K, n), comb(M, n)) if n <= M - K else Q(0)
            q = Q(1, n + 1)
            running[K] = running[K] and bool(p) and q / p < gamma
            if running[K]:
                retained.append(K)
            states += 1
        if 0 not in retained:
            raise AssertionError('Synthetic zero truth was excluded')
        if first is None and max(retained) <= 5:
            first = n
    max_alternative = M + H - 1
    assert max_alternative < gamma and first == 78
    or_n = next(n for n in range(M) if Q(M, M - n) > 20)
    assert or_n == 91
    return {
        'specified_strict_family_exact_records': pilot + 2 * M,
        'different_OR_family_same_strict_contract_feasible_records': pilot + 2 * or_n,
        'changed_5_percentage_point_contract_Beta11_feasible_records': pilot + 2 * first,
        'marginal_mean_e_alternative_sum_upper_bound': max_alternative,
        'wealth_threshold_Gamma': int(gamma),
        'Beta11_n_K_states_recalculated': states,
        'OR_conditional_one_positive_miss_probability': str(Q(M - or_n, M)),
        'OR_zero_path_e_at_stop': str(Q(M, M - or_n)),
        'request': 'A_m>X_m and B_m>X_m, m=1,...,14; separate from MAST',
        'cap_fallback': 'Census if affordable; otherwise stop at cap and return unresolved',
        'not_empirical_method_or_FullFeedback_gain': True,
    }


def directed(q, upward):
    value = float(q)
    if (upward and Q.from_float(value) < q) or (not upward and Q.from_float(value) > q):
        value = nextafter(value, inf if upward else -inf)
    return value


def readout(lower, upper, n, s):
    return (max(s, ceil(100 * Q.from_float(nextafter(lower, -inf)))),
            min(s + 100 - n, floor(100 * Q.from_float(nextafter(upper, inf)))))


def logical_interface():
    assert (sys.float_info.radix, sys.float_info.mant_dig, sys.float_info.max_exp,
            sys.float_info.rounds) == (2, 53, 1024, 1)
    with (HERE / 'logical_interface/ALL_5151_STATES.csv').open(newline='') as f:
        saved = list(csv.DictReader(f))
    index = proper = losses = all_losses = corrected_losses = n99_losses = 0
    affected = set()
    for n in range(101):
        for s in range(n + 1):
            row = saved[index]
            index += 1
            k = s + 100 - n
            l, u = s / 100, 1.0 - ((n - s) / 100)
            lo, hi = readout(l, u, n, s)
            dl, du = directed(Q(s, 100), False), directed(Q(k, 100), True)
            fixed_lo, fixed_hi = readout(dl, du, n, s)
            expected = {'N': 100, 'n': n, 's': s,
                        'logical_count_lower': s, 'logical_count_upper': k,
                        'baseline_lower_hex': l.hex(), 'baseline_upper_hex': u.hex(),
                        'baseline_count_lower': lo, 'baseline_count_upper': hi,
                        'directed_lower_hex': dl.hex(), 'directed_upper_hex': du.hex(),
                        'directed_count_lower': fixed_lo, 'directed_count_upper': fixed_hi}
            for name, value in expected.items():
                assert row[name] == str(value), (n, s, name)
            assert lo == s and fixed_lo == s and fixed_hi == k
            bad = hi < k
            all_losses += bad
            corrected_losses += fixed_lo > s or fixed_hi < k
            if bad:
                affected.add(k)
            if 1 <= n < 100:
                proper += 1
                losses += bad
            if n == 99:
                n99_losses += bad
    assert index == len(saved) == 5151
    assert (proper, losses, all_losses, corrected_losses, n99_losses) == (5049, 94, 101, 0, 7)
    rational_upper = readout(0.0, 1.0 - 80 / 100, 99, 19)[1]
    ordinary_upper = floor(100 * nextafter(1.0 - 80 / 100, inf))
    assert (rational_upper, ordinary_upper) == (19, 20)
    return {'all_formula_states': index, 'proper_prefix_states': proper,
            'proper_prefix_feasible_upper_count_losses': losses,
            'directed_interface_losses': corrected_losses,
            'n99_losses_of_100_states': n99_losses,
            'affected_logical_upper_counts': sorted(affected),
            'known_n99_s19_exact_rational_upper': rational_upper,
            'known_n99_s19_ordinary_float_product_upper': ordinary_upper,
            'scope': 'Nonrestrictive [0,1] pre-clip control; state counts, not coverage or error-rate estimates. No CI/method rerun. n=100 formula states bypassed by the actual exact-census branch.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, help='Optional new output directory; existing paths are rejected')
    args = parser.parse_args()
    if args.out is not None and args.out.exists():
        parser.error('--out must be a new directory')
    result = {'status': 'PASS_FINITE_DIAGNOSTICS', 'verified_members': verify_members(),
              'synthetic': synthetic_costs(), 'logical_interface': logical_interface(),
              'execution_scope': 'Deterministic standard-library arithmetic only; no real data, native CI, model, or RNG calls.'}
    text = json.dumps(result, indent=2, ensure_ascii=False) + '\n'
    if args.out is not None:
        args.out.mkdir(parents=True, exist_ok=False)
        (args.out / 'REPRODUCED_SUMMARY.json').write_text(text)
    print(text, end='')


if __name__ == '__main__':
    main()
