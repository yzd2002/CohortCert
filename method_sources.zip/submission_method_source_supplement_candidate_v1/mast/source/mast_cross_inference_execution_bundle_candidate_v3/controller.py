"""Explicit bound slot table, private workers, no parent result/truth parser."""
from pathlib import Path
import argparse,fcntl,os,resource,shutil,signal,subprocess,time
from administration import closed_metadata,unknown_charge,validate_rows
from fee_adapter import fee_account
from contract import validate_bundle
from gate import ROOT,authorize_actual,authorize_artificial
from io_utils import atomic_json,file_hash,fsync_dir,inventory,load_json,object_hash
from process_control import birth,bound,kill_wait,live_cpu_seconds,spawn_fake,spawn_bound,wait_started

class ControllerBudgetCensor(RuntimeError):pass
class ControllerCPUReserve:
    def __init__(self,soft,*,reserve=10):
        self.threshold=max(1,float(soft)-float(reserve));self.signaled=False;self.active=False
    def exhausted(self,used=None):
        return self.signaled or (time.process_time() if used is None else used)>=self.threshold
    def signal(self,signum,frame):
        self.signaled=True
        if self.active:raise ControllerBudgetCensor('controller softCPU signal; retain active and remaining slots')

def exact_zero():return dict(state='SEALED_EXACT',known_durable_submitted_prefix=0,exact_total=0,exact_tail='KNOWN',events=0,last_chain='0'*64,error_type=None)
def sample_storage(root):
    files=logical=allocated=0
    for p in Path(root).rglob('*'):
        try:
            if p.is_symlink():raise ValueError('symlink in study')
            s=p.stat()
        except FileNotFoundError:continue # Worker can atomically rename sampled files.
        if p.is_file():files+=1;logical+=s.st_size;allocated+=s.st_blocks*512
    return dict(files=files,logical_bytes=logical,allocated_bytes=allocated,free_disk_bytes=shutil.disk_usage(root).free)
class ClosedSlotStorage:
    """Resource totals only; final independent inventory never uses this cache."""
    def __init__(self):self.closed={}
    def seal(self,slot):
        slot=Path(slot).resolve()
        if slot in self.closed:raise ValueError('closed slot cached twice')
        self.closed[slot]=sample_storage(slot)
    def observe(self,root,active=None,active_sample=None):
        root=Path(root).resolve();skip=set(self.closed)
        if active is not None:
            active=Path(active).resolve();skip.add(active)
            if active in self.closed:raise ValueError('active slot already closed')
            if active_sample is None:active_sample=sample_storage(active)
        result=dict(files=0,logical_bytes=0,allocated_bytes=0,free_disk_bytes=shutil.disk_usage(root).free)
        for current,dirs,files in os.walk(root):
            parent=Path(current);kept=[]
            for name in dirs:
                path=parent/name
                if path.is_symlink():raise ValueError('symlink in study storage')
                if path not in skip:kept.append(name)
            dirs[:]=kept
            for name in files:
                path=parent/name
                try:
                    if path.is_symlink():raise ValueError('symlink in study storage')
                    s=path.stat()
                except FileNotFoundError:continue
                if not path.is_file():raise ValueError('nonregular study file')
                result['files']+=1;result['logical_bytes']+=s.st_size;result['allocated_bytes']+=s.st_blocks*512
        for item in list(self.closed.values())+([] if active is None else [active_sample]):
            for key in ('files','logical_bytes','allocated_bytes'):result[key]+=item[key]
        return result

def check_storage(observed,limits,*,study):
    keys=(('files','files'),('logical_bytes','logical_bytes'),('allocated_bytes','allocated_bytes')) if study else (('files','slot_files'),('logical_bytes','slot_logical_bytes'),('allocated_bytes','slot_allocated_bytes'))
    for observed_key,limit_key in keys:
        if observed[observed_key]>limits[limit_key]:raise RuntimeError('storage resource censor')
    if study and observed['free_disk_bytes']<limits['free_disk_floor_bytes']:raise RuntimeError('free disk floor censor')
def loaded_closure(bundle):
    c=ROOT/'CODE_CLOSURE.json'
    if file_hash(c)!=bundle['pins']['controller_closure_sha256']:raise ValueError('controller closure pin')
    for x in load_json(c)['files']:
        if file_hash(ROOT/x['path'])!=x['sha256']:raise ValueError('controller runtime bytes changed')
    for d in bundle['dispatch'].values():
        worker=ROOT/('fake_worker.py' if d['kind']=='FAKE_ONLY' else 'bound_worker.py')
        if d['worker_code_sha256']!=file_hash(worker):raise ValueError('exact dispatched worker code pin')
def run_controller(bundle,study_root,*,mode='artificial',authority_refs=None,scenarios=None,monitor=None,popen=subprocess.Popen,stop_after=None):
    if mode=='artificial':bundle,context,root=authorize_artificial(bundle,study_root)
    elif mode=='actual':
        permit=authorize_actual(authority_refs)
        if bundle is not None and bundle!=permit.bundle:raise ValueError('actual bundle differs from final authority')
        if study_root is not None and Path(study_root).resolve()!=Path(permit.study_root).resolve():raise ValueError('actual study path differs from LaunchReady')
        bundle,context,root=permit.bundle,permit.context,Path(permit.study_root)
        if scenarios or monitor or stop_after is not None or popen is not subprocess.Popen:raise ValueError('test hooks forbidden in actual mode')
    else:raise ValueError('explicit controller mode')
    loaded_closure(bundle)
    root.parent.mkdir(parents=True,exist_ok=True);lockfile=(ROOT/'artificial_runs/GLOBAL_EXCLUSION.lock') if mode=='artificial' else (ROOT.parent/'MAST_BOUND_STUDY_GLOBAL.lock')
    rows=[];handle=None;active_run=None;global_stop=None;launches=0;started=time.monotonic();cpu_start=time.process_time();children_start=resource.getrusage(resource.RUSAGE_CHILDREN)
    with lockfile.open('a+b') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        root.mkdir(exist_ok=False);fsync_dir(root.parent)
        atomic_json(root/'STUDY_CLAIM.json',dict(context=context,no_retry=True,scope=bundle['scope']))
        atomic_json(root/'BOUND_BUNDLE.json',bundle)
        atomic_json(root/'CONTROLLER_STARTED.json',dict(pid=os.getpid(),starttime=birth(os.getpid()),context=context,study_lock_held=True,scope=bundle['scope']))
        old_handler=signal.getsignal(signal.SIGTERM)
        old_cpu_handler=signal.getsignal(signal.SIGXCPU)
        cpu_reserve=ControllerCPUReserve(bundle['controller_limits']['CPU_soft']) if mode=='actual' else None
        storage=ClosedSlotStorage() if mode=='actual' else None
        if cpu_reserve is not None:signal.signal(signal.SIGXCPU,cpu_reserve.signal)
        def interrupted(signum,frame):raise InterruptedError('controller termination retained')
        signal.signal(signal.SIGTERM,interrupted)
        try:
            for run in bundle['runs']:
                if cpu_reserve is not None and cpu_reserve.exhausted():global_stop=global_stop or 'CONTROLLER_CPU_RESERVE'
                row=dict(run=run,context=context,completion_win=False,scientific_adjudication='UNKNOWN',private_results_decoded=False)
                if global_stop:
                    row.update(status='UNRUN_GLOBAL_STOP',reason=global_stop,charge=exact_zero());rows.append(row)
                    atomic_json(root/f'ROW_{run["slot"]:03d}.json',row);continue
                slot=root/'slots'/run['run_id'];active_run=run;handle=None;released=False;row_started=time.monotonic()
                try:
                    slot.mkdir(parents=True,exist_ok=False);fsync_dir(slot.parent)
                    atomic_json(slot/'SLOT_CLAIM.json',dict(context=context,run=run,no_retry=True))
                    limits=bundle['limits'][run['method_id']]
                    admission=dict(scope='ARTIFICIAL_ONLY' if mode=='artificial' else 'actual_bound',context=context,run=run,limits=limits,
                        scenario=(scenarios or {}).get(run['slot'],'normal'),parent_pid=os.getpid(),parent_birth=birth(os.getpid()))
                    kind=bundle['dispatch'][run['method_id']]['kind']
                    handle=spawn_fake(slot,admission,popen=popen) if kind=='FAKE_ONLY' else spawn_bound(slot,admission,bundle['dispatch'][run['method_id']],authority_refs,popen=popen)
                    if cpu_reserve is not None:cpu_reserve.active=True
                    launches+=1
                    wait_started(handle,slot,admission,row_started+limits['wall_seconds']);released=True
                    next_scan=0
                    while handle.process.poll() is None:
                        if cpu_reserve is not None and cpu_reserve.exhausted():raise ControllerBudgetCensor('controller CPU reserve; retain censor and all remaining slots')
                        now=time.monotonic()
                        if now-row_started>limits['wall_seconds'] or now-started>bundle['study_limits']['wall_seconds']:raise TimeoutError('wall resource censor')
                        if now>=next_scan:
                            if monitor:monitor(root,slot,run)
                            active_storage=sample_storage(slot)
                            check_storage(active_storage,limits,study=False)
                            study_storage=storage.observe(root,slot,active_storage) if storage is not None else sample_storage(root)
                            check_storage(study_storage,bundle['study_limits'],study=True)
                            used=resource.getrusage(resource.RUSAGE_CHILDREN)
                            if time.process_time()-cpu_start+used.ru_utime+used.ru_stime-children_start.ru_utime-children_start.ru_stime+live_cpu_seconds(handle)>bundle['study_limits']['CPU_seconds']:raise RuntimeError('aggregate CPU censor')
                            next_scan=now+(1.0 if mode=='actual' else 0.05)
                        time.sleep(0.05 if mode=='actual' else 0.005)
                    row['exitcode']=handle.process.wait()
                    if row['exitcode']==0:row.update(closed_metadata(slot,context,run,bundle['dispatch'][run['method_id']]['kind']))
                    else:row.update(status='CENSORED_UNKNOWN',charge=unknown_charge(fee_account(slot/'FEE_JOURNAL.ndjson',context,run['run_id'],bundle['dispatch'][run['method_id']]['kind'])))
                    if row['status']=='CENSORED_UNKNOWN':global_stop='WORKER_INCOMPLETE'
                except BaseException as exc:
                    if handle is not None:row['exitcode']=kill_wait(handle,'CONTROL_PLANE_ERROR')
                    row['error_type']=type(exc).__name__
                    if isinstance(exc,FileExistsError):
                        row.update(status='CLAIM_CONFLICT_UNKNOWN',charge=unknown_charge(fee_account(slot/'FEE_JOURNAL.ndjson',context,run['run_id'],bundle['dispatch'][run['method_id']]['kind'])))
                    elif handle is None:
                        row.update(status='START_FAILED_UNSUBMITTED',charge=exact_zero())
                    else:
                        row.update(status='CENSORED_UNKNOWN',charge=unknown_charge(fee_account(slot/'FEE_JOURNAL.ndjson',context,run['run_id'],bundle['dispatch'][run['method_id']]['kind'])))
                    global_stop='CONTROLLER_CPU_RESERVE' if isinstance(exc,ControllerBudgetCensor) else 'CONTROL_PLANE_ERROR'
                finally:
                    if cpu_reserve is not None:cpu_reserve.active=False
                    if handle is not None and handle.process.poll() is None:kill_wait(handle,'FINALLY_OWNED_CHILD')
                row['wall_seconds']=time.monotonic()-row_started
                rows.append(row);atomic_json(root/f'ROW_{run["slot"]:03d}.json',row)
                if storage is not None and slot.exists():storage.seal(slot)
                handle=None;active_run=None
                if stop_after is not None and len(rows)>=stop_after:global_stop='ARTIFICIAL_FIXED_EARLY_STOP'
            validate_rows(rows,context,bundle)
            allfiles=inventory(root)
            barrier=dict(schema='planned-slots-terminal-admin-barrier/v2',status='ALL_PLANNED_SLOTS_TERMINAL_ADMIN_ONLY',context=context,bundle_sha256=object_hash(bundle),planned_slot_count=len(bundle['runs']),planned_slots_sha256=object_hash(bundle['runs']),
                rows=rows,inventory=allfiles,scope=bundle['scope'],worker_launches=launches,scientific_success='UNKNOWN',private_results_decoded=False,actual_worker_launches=0 if mode=='artificial' else launches)
            atomic_json(root/'ALL_SLOTS_TERMINAL.json',barrier)
            seal=root.parent/(root.name+'.EXTERNAL_SEAL.json')
            if seal.exists():raise FileExistsError('external seal already claimed')
            atomic_json(seal,dict(schema='planned-slots-external-admin-seal/v2',context=context,planned_slot_count=len(bundle['runs']),planned_slots_sha256=object_hash(bundle['runs']),study_root=str(root),barrier_sha256=file_hash(root/'ALL_SLOTS_TERMINAL.json'),inventory_sha256=object_hash(allfiles),private_results_decoded=False))
            return dict(status='ALL_PLANNED_SLOTS_TERMINAL_ADMIN_ONLY',study_root=str(root),external_seal=str(seal),external_seal_sha256=file_hash(seal),context=context,normal_closed=sum(r['status']=='WORKER_SEALED' for r in rows),worker_launches=launches,actual_worker_launches=0 if mode=='artificial' else launches,private_results_decoded=False)
        finally:
            if handle is not None and handle.process.poll() is None:kill_wait(handle,'CONTROLLER_FINALLY')
            signal.signal(signal.SIGTERM,old_handler)
            if cpu_reserve is not None:signal.signal(signal.SIGXCPU,old_cpu_handler)

def run_artificial(bundle,study_root,**kwargs):return run_controller(bundle,study_root,mode='artificial',**kwargs)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--mode',choices=['artificial','actual'],required=True);p.add_argument('--bundle');p.add_argument('--study-root');p.add_argument('--stop-after',type=int);p.add_argument('--authority-refs');a=p.parse_args()
    if a.mode=='actual':
        refs=__import__('json').loads(a.authority_refs) if a.authority_refs else None
        result=run_controller(None,a.study_root,mode='actual',authority_refs=refs)
    else:result=run_artificial(load_json(a.bundle),a.study_root,stop_after=a.stop_after)
    print(__import__('json').dumps(result,sort_keys=True),flush=True)
