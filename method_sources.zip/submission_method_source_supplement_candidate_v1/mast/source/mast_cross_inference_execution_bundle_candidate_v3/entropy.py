"""Uniform rejection algorithm; this candidate uses injected fake bytes only."""
from math import factorial

def uniform_below(n,random_bytes,attempt_cap=4096):
    if type(n) is not int or n<1 or type(attempt_cap) is not int or not 1<=attempt_cap<=4096:raise ValueError('rejection bounds')
    if n==1:return 0
    bits=(n-1).bit_length();size=(bits+7)//8;mask=(1<<bits)-1
    for _ in range(attempt_cap):
        raw=random_bytes(size)
        if type(raw) is not bytes or len(raw)!=size:raise ValueError('exact uniform-byte callback contract')
        x=int.from_bytes(raw,'big')&mask
        if x<n:return x
    raise RuntimeError('entropy rejection cap; no fallback or rank reused')
def artificial_rank_structure(random_bytes):
    return dict(scope='ARTIFICIAL_INJECTED_RNG_NOT_STUDY_ENTROPY',
        replicates={str(rep):{g:dict(pilot_rank=uniform_below(factorial(100),random_bytes),formal_rank=uniform_below(factorial(95),random_bytes)) for g in 'ABC'} for rep in range(8)})
def _write_all(fd,data,write=None):
    import os
    if type(data) is not bytes:raise TypeError('exact claim bytes required')
    write=os.write if write is None else write
    offset=0;attempts=0
    while offset<len(data):
        attempts+=1
        if attempts>4096:raise OSError('claim write attempt limit; no entropy drawn')
        try:n=write(fd,data[offset:])
        except InterruptedError:continue
        if type(n) is not int or not 0<n<=len(data)-offset:raise OSError('claim write made no valid progress; no entropy drawn')
        offset+=n

def _write_once(output_path,hashes,random_bytes,*,actual):
    """Shared once-only writer; tests use injected bytes with artificial tags."""
    import os
    from pathlib import Path
    from io_utils import atomic_json,file_hash
    output=Path(output_path)
    if output.exists():raise RuntimeError('entropy output already exists; never redraw')
    claim=output.with_name(output.name+'.DRAW_CLAIM.json')
    # Persist the no-redraw claim before any OS study-rank bytes are requested.
    fd=os.open(claim,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    try:
        import json
        _write_all(fd,(json.dumps(dict(no_redraw=True,actual_study=actual,final_protocol_sha256=hashes['final_protocol'],
            core_ready_sha256=hashes['core_ready'],auditor_ready_sha256=hashes['auditor_ready']))+'\n').encode())
        os.fsync(fd)
    finally:os.close(fd)
    parent_fd=os.open(output.parent,os.O_RDONLY|os.O_DIRECTORY)
    try:os.fsync(parent_fd)
    finally:os.close(parent_fd)
    record=artificial_rank_structure(random_bytes)
    record.update(schema='bound-uniform-factoradic-entropy/v1',
        scope='ACTUAL_UNIFORM_EXTERNAL_RANK_PROVENANCE' if actual else 'ARTIFICIAL_INJECTED_RNG_NOT_STUDY_ENTROPY',
        sampling='OS_UNIFORM_BITS_REJECTION' if actual else 'ARTIFICIAL_INJECTED_BYTES',
        before_method_access=True,final_protocol_sha256=hashes['final_protocol'],core_ready_sha256=hashes['core_ready'],
        auditor_ready_sha256=hashes['auditor_ready'],draw_claim_sha256=file_hash(claim))
    atomic_json(output,record)
    return dict(path=str(output),sha256=file_hash(output),draw_claim_sha256=file_hash(claim),
        planned_rank_draws=48,no_redraw=True,actual_study=actual,actual_method_or_payload_access=False)

def draw_actual_study_entropy(*args,**kwargs):
    from authority_v2 import authorize_entropy,require_entropy_permit
    permit=authorize_entropy(*args,**kwargs) # Missing authorities reject before I/O.
    require_entropy_permit(permit)
    import os
    return _write_once(permit.output_path,permit.hashes,os.urandom,actual=True)
