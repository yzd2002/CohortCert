"""Only handles created by this parent can be signalled. No Source lookup."""
from dataclasses import dataclass
from pathlib import Path
import os,resource,signal,subprocess,sys,time
import json
from io_utils import atomic_json,file_hash,load_json

ROOT=Path(__file__).resolve().parent
def birth(pid):
    if type(pid) is not int or pid<=0 or pid==15744:raise ValueError('invalid or protected unrelated PID')
    raw=Path(f'/proc/{pid}/stat').read_text()
    return raw[raw.rfind(')')+2:].split()[19]
def argv_for(pid):
    if pid==15744:raise ValueError('protected unrelated PID')
    return tuple(x.decode() for x in Path(f'/proc/{pid}/cmdline').read_bytes().split(b'\0') if x)
@dataclass
class Handle:
    process:subprocess.Popen
    pid:int
    starttime:str
    argv:tuple
    parent_pid:int
def bound(h):
    if not isinstance(h,Handle) or type(h.process) is not subprocess.Popen or h.parent_pid!=os.getpid() or h.pid!=h.process.pid or h.pid==15744 or tuple(h.process.args)!=h.argv:return False
    try:
        raw=Path(f'/proc/{h.pid}/stat').read_text();parts=raw[raw.rfind(')')+2:].split()
        return parts[19]==h.starttime and int(parts[1])==os.getpid() and argv_for(h.pid)==h.argv
    except (FileNotFoundError,ProcessLookupError):return False
def live_cpu_seconds(h):
    if not bound(h):
        if h.process.poll() is not None:return 0
        # /proc cmdline can empty during exit before waitpid reports completion.
        # Waiting on our Popen cannot signal an unrelated/reused PID.
        try:h.process.wait(timeout=0.05);return 0
        except subprocess.TimeoutExpired:raise ValueError('live CPU identity mismatch')
    try:
        raw=Path(f'/proc/{h.pid}/stat').read_text();parts=raw[raw.rfind(')')+2:].split()
        return (int(parts[11])+int(parts[12]))/os.sysconf('SC_CLK_TCK')
    except FileNotFoundError:return 0
def kill_wait(h,reason):
    if h.parent_pid!=os.getpid() or h.pid!=h.process.pid:raise ValueError('not an owned child')
    if h.process.poll() is not None:return h.process.wait()
    if not bound(h):
        try:return h.process.wait(timeout=0.05)
        except subprocess.TimeoutExpired:raise ValueError('PID/birth/argv mismatch; no signal sent')
    os.kill(h.pid,signal.SIGTERM)
    try:return h.process.wait(timeout=1)
    except subprocess.TimeoutExpired:
        if not bound(h):raise ValueError('PID identity changed; no further signal')
        os.kill(h.pid,signal.SIGKILL);return h.process.wait(timeout=1)
def spawn_fake(slot_dir,admission,*,popen=subprocess.Popen):
    slot_dir=Path(slot_dir);path=slot_dir/'ADMISSION.json';atomic_json(path,admission)
    command=(sys.executable,'-B',str(ROOT/'fake_worker.py'),'--outdir',str(slot_dir),'--admission-sha',file_hash(path))
    limits=admission['limits']
    def hard_limits():
        resource.setrlimit(resource.RLIMIT_CPU,(limits['CPU_soft'],limits['CPU_hard']))
        resource.setrlimit(resource.RLIMIT_AS,(limits['AS_bytes'],limits['AS_bytes']))
        resource.setrlimit(resource.RLIMIT_FSIZE,(limits['packet_bytes'],limits['packet_bytes']))
    with (slot_dir/'ADMIN_STDOUT.log').open('xb') as stdout,(slot_dir/'SANITIZED_STDERR.log').open('xb') as stderr:
        p=popen(command,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,close_fds=True,start_new_session=True,
            env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1'),preexec_fn=hard_limits)
    h=None
    try:
        h=Handle(p,p.pid,birth(p.pid),command,os.getpid())
        atomic_json(slot_dir/'CHILD_IDENTITY.json',dict(pid=h.pid,starttime=h.starttime,argv=list(command),parent_pid=h.parent_pid))
        return h
    except BaseException:
        if h is not None:kill_wait(h,'SPAWN_HANDSHAKE_ERROR_BEFORE_GO')
        elif p.poll() is not None:p.wait()
        else:raise RuntimeError('unbound spawned child; barrier unavailable, external intervention required')
        raise
def spawn_bound(slot_dir,admission,dispatch,authority_refs,*,popen=subprocess.Popen):
    """Only the bound worker can load actual labels, after its own permit."""
    slot_dir=Path(slot_dir);path=slot_dir/'ADMISSION.json';atomic_json(path,admission)
    command=(dispatch['interpreter'],'-B',str(ROOT/'bound_worker.py'),'--mode','actual_bound','--outdir',str(slot_dir),
        '--admission-sha',file_hash(path),'--authority-refs',json.dumps(authority_refs,sort_keys=True,separators=(',',':')))
    limits=admission['limits']
    def hard_limits():
        resource.setrlimit(resource.RLIMIT_CPU,(limits['CPU_soft'],limits['CPU_hard']))
        resource.setrlimit(resource.RLIMIT_AS,(limits['AS_bytes'],limits['AS_bytes']))
        resource.setrlimit(resource.RLIMIT_FSIZE,(limits['packet_bytes'],limits['packet_bytes']))
    with (slot_dir/'ADMIN_STDOUT.log').open('xb') as out,(slot_dir/'SANITIZED_STDERR.log').open('xb') as err:
        p=popen(command,stdin=subprocess.DEVNULL,stdout=out,stderr=err,close_fds=True,start_new_session=True,
            env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1'),preexec_fn=hard_limits)
    h=None
    try:
        h=Handle(p,p.pid,birth(p.pid),command,os.getpid());atomic_json(slot_dir/'CHILD_IDENTITY.json',dict(pid=h.pid,starttime=h.starttime,argv=list(command),parent_pid=h.parent_pid));return h
    except BaseException:
        if h is not None:kill_wait(h,'BOUND_STARTUP_ERROR_BEFORE_GO')
        elif p.poll() is not None:p.wait()
        else:raise RuntimeError('unbound child; no barrier allowed')
        raise
def wait_started(h,slot_dir,admission,deadline):
    p=Path(slot_dir)/'WORKER_STARTED.json'
    while True:
        if h.process.poll() is not None:raise RuntimeError('child exited before startup handshake')
        if p.exists():
            s=load_json(p)
            if not bound(h) or s!=dict(pid=h.pid,starttime=h.starttime,run_id=admission['run']['run_id'],context=admission['context']):raise ValueError('startup PID/context mismatch')
            atomic_json(Path(slot_dir)/'GO.json',dict(context=admission['context'],run_id=admission['run']['run_id'],child_starttime=h.starttime,parent_pid=os.getpid(),parent_birth=birth(os.getpid())))
            return
        if time.monotonic()>deadline:raise TimeoutError('startup wall cap')
        time.sleep(0.003)
