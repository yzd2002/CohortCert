"""New label-free startup and resource-monitor controls, no actual permit."""
from pathlib import Path
import ast,json,os,resource,subprocess,sys,time
resource.setrlimit(resource.RLIMIT_CPU,(8,9))
resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912))
from controller import ControllerCPUReserve,ControllerBudgetCensor,ClosedSlotStorage,sample_storage
P=Path(__file__).resolve().parent;O=P/'startup_monitor_delta_output';O.mkdir(exist_ok=False)
cases=[];start=time.process_time()
def passed(name):cases.append(dict(case=name,status='PASS'))
try:
    # Isolated child: audit hooks persist for its lifetime. This uses fake
    # sibling metadata and never calls run_actual/authorize/provider/entropy.
    code=r'''
from pathlib import Path
import ast,json,resource,time
resource.setrlimit(resource.RLIMIT_CPU,(2,3))
import bound_worker as w
from io_utils import load_json,file_hash
p=Path(w.__file__).resolve().parent
o=p.parent/'ARTIFICIAL_STARTUP_GUARD_V3_ONLY';o.mkdir(exist_ok=False)
slot=o/'claimed';slot.mkdir();outside=o/'OTHER_NOT_ADMITTED.json';outside.write_text('{}')
claim=o/'FAKE_ENTROPY.json.DRAW_CLAIM.json';claim.write_text('{"artificial_only":true}')
for name in ('ADMISSION.json','GO.json','FEE_JOURNAL.ndjson'):(slot/name).write_text('{"artificial_only":true}')
tree=ast.parse(Path(w.__file__).read_text());function=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='run_actual')
expr=next(n.value for n in function.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='objects' for t in n.targets))
compiled=compile(ast.Expression(expr),'<exact bound_worker second-load expression>','eval')
refs={'entropy':{'path':str(o/'FAKE_ENTROPY.json')},'environment_binding':{'path':str(p/'ENVIRONMENT_BINDING_CANDIDATE.json')}}
approved=w.install_guard(slot,refs);assert approved==[False]
assert file_hash(slot/'ADMISSION.json');assert load_json(slot/'GO.json')['artificial_only'];assert file_hash(slot/'FEE_JOURNAL.ndjson')
(slot/'new_output.json').write_text('{}')
assert load_json(claim)['artificial_only']
try:load_json(outside)
except PermissionError:pass
else:raise AssertionError('unlisted sibling read allowed')
objects=eval(compiled,{'load_json':load_json,'refs':{'environment_binding':refs['environment_binding']}})
assert objects['environment_binding']['schema']=='complete-worker-environment-binding/v1'
try:eval(compiled,{'load_json':load_json,'refs':{'protocol_settings':refs['environment_binding']}})
except ValueError:pass
else:raise AssertionError('nonenvironment cap expanded')
print(json.dumps(dict(status='PASS_PRIVATE_STARTUP_GUARD_DELTA',approved_still_false=approved==[False],actual_permit_provider_or_entropy_called=False)))
'''
    child=subprocess.run([sys.executable,'-B','-c',code],cwd=P,env=dict(os.environ,PYTHONPATH=str(P),OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1'),capture_output=True,text=True,timeout=180)
    (O/'GUARD_CHILD_STDOUT.txt').write_text(child.stdout);(O/'GUARD_CHILD_STDERR.txt').write_text(child.stderr)
    assert child.returncode==0,child.stderr
    assert json.loads(child.stdout)['status']=='PASS_PRIVATE_STARTUP_GUARD_DELTA'
    passed('own_claimed_slot_and_exact_draw_claim_readable_but_unlisted_sibling_forbidden')
    passed('exact_worker_second_load_accepts_fixed_environment_only_with_8MiB')
    reserve=ControllerCPUReserve(110);assert not reserve.exhausted(99.99) and reserve.exhausted(100)
    import controller
    original=controller.time.process_time
    try:controller.time.process_time=lambda:103.0;assert reserve.exhausted()
    finally:controller.time.process_time=original
    passed('reserve_includes_absolute_import_and_authority_CPU')
    idle=ControllerCPUReserve(110);idle.signal(None,None);assert idle.exhausted(0)
    active=ControllerCPUReserve(110);active.active=True
    try:active.signal(None,None)
    except ControllerBudgetCensor:pass
    else:raise AssertionError('active SIGXCPU did not enter existing owned-child cleanup exception path')
    passed('idle_CPU_signal_sets_global_stop_and_active_CPU_signal_enters_censor_path')
    root=O/'STORAGE_ONLY';root.mkdir();closed=[]
    for i in range(2):
        slot=root/'slots'/('closed'+str(i));slot.mkdir(parents=True)
        for j in range(5):(slot/(str(j)+'.bin')).write_bytes(b'X'*(1+i*20+j))
        closed.append(slot)
    live=root/'slots/live';live.mkdir();(live/'a.bin').write_bytes(b'x'*5);(root/'metadata.json').write_text('{}')
    tracker=ClosedSlotStorage()
    for slot in closed:tracker.seal(slot)
    def equal_storage(got,want):
        assert {k:got[k] for k in ('files','logical_bytes','allocated_bytes')}=={k:want[k] for k in ('files','logical_bytes','allocated_bytes')}
    equal_storage(tracker.observe(root,live,sample_storage(live)),sample_storage(root))
    (live/'a.bin').write_bytes(b'x'*9000);(live/'b.bin').write_bytes(b'x'*4);(root/'row_001.json').write_text('{"new":true}')
    equal_storage(tracker.observe(root,live,sample_storage(live)),sample_storage(root))
    tracker.seal(live);equal_storage(tracker.observe(root),sample_storage(root))
    passed('cached_closed_totals_match_full_storage_during_active_growth_and_root_metadata_changes')
    try:tracker.seal(live)
    except ValueError:pass
    else:raise AssertionError('closed slot recached')
    try:tracker.observe(root,live)
    except ValueError:pass
    else:raise AssertionError('closed slot reused as active')
    passed('immutable_closed_slot_not_reused_as_active_or_recached')
    report=dict(status='PASS_NEW_STARTUP_AND_MONITOR_DELTAS_ONLY',checks=cases,parent_CPU_before_final_write=time.process_time()-start,child_CPU=resource.getrusage(resource.RUSAGE_CHILDREN).ru_utime+resource.getrusage(resource.RUSAGE_CHILDREN).ru_stime,actual_data_Source_OS_entropy_or_actual_READY=False,scope='Tiny artificial paths/storage and CPU handler. No actual-role permit/body or56/full300 rerun; existing cleanup coverage inherited, not reexecuted.')
except BaseException:
    import traceback
    report=dict(status='FAILED_RETAINED',checks=cases,parent_CPU_before_final_write=time.process_time()-start,traceback=traceback.format_exc(),actual_READY=False)
(O/'RESULTS.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
