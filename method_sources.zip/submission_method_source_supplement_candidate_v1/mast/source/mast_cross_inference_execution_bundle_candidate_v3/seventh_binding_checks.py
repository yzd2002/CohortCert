"""Only new seventh-route/science-resource binding checks; no actual inputs."""
from pathlib import Path
from copy import deepcopy
from dataclasses import replace
import sys, os, json, hashlib, resource, traceback
ROOT=Path(__file__).resolve().parent
sys.dont_write_bytecode=True
os.nice(max(0,10-os.getpriority(os.PRIO_PROCESS,0)))
resource.setrlimit(resource.RLIMIT_CPU,(12,12))
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
from contract import METHODS,validate_bundle
from method_dispatch import route_plan,dispatch,prepare_route
from gate import NotReady
from authority_v2 import authorize_entropy,authorize_controller_launch,authorize_actual_worker
from core import Group,Record,Operator,ArtificialVectorCache
from reference_schema import MODES,request_from_groups

OUT=ROOT/'binding_check_artifacts'
OUT.mkdir(exist_ok=False)
checks=[]
def reject(name,fn,exception):
    try:fn()
    except exception:checks.append({'case':name,'status':'PASS_REJECT'})
    else:raise AssertionError(name+' accepted')
try:
    science_path=ROOT.parent/'mast_56_final_protocol_candidate_v1/SCIENTIFIC_CONTRACT_FINAL.json'
    science_text=science_path.read_text();science=json.loads(science_text)
    assert len(METHODS)==7 and METHODS[-1]=='SSS_Kelly_CommonLogEvidenceGreedy_v1'
    assert [m['id'] for m in science['methods']]==list(METHODS)
    assert route_plan(METHODS[-1])['module']=='sss_common_loggreedy'
    p=prepare_route(METHODS[-1],OUT/'unused_no_native')
    assert p.METHOD_ID==METHODS[-1] and 'native_routes' not in sys.modules
    checks.append({'case':'seventh_preparation_selects_its_pure_module','status':'PASS'})
    worker_sha=hashlib.sha256((ROOT/'bound_worker.py').read_bytes()).hexdigest()
    bundle={'schema':'cross-inference-control-bundle/v2','scope':'FINAL_BOUND_ACTUAL','status':'FINAL_FIXED_PROTOCOL',
        'scientific_plan_json':science_text,'runs':science['runs'],
        'pins':{'scientific_contract_sha256':hashlib.sha256(science_text.encode()).hexdigest(),
            'local_bridge_sha256':'a'*64,'external_bridge_sha256':'b'*64,'controller_closure_sha256':'c'*64,
            'entropy_sha256':'EXTERNAL_AFTER_CORE_READY','data_contract_sha256':'d'*64,'protocol_sha256':'e'*64},
        'dispatch':{m:{'kind':'BOUND_PRIVATE_WORKER','worker_policy':m,'worker_code_sha256':worker_sha,
            'worker_ready_sha256':'f'*64,'interpreter':str(Path(sys.executable).resolve())} for m in METHODS},
        'limits':science['resources']['per_method'],'study_limits':science['resources']['study'],
        'controller_limits':science['resources']['controller']}
    validated,_=validate_bundle(bundle)
    assert len(validated['runs'])==56
    checks.append({'case':'exact56_scientific_resource_table_valid','status':'PASS_PURE_STRUCTURE_ONLY'})
    changed=deepcopy(bundle);changed['limits'][METHODS[0]]['CPU_soft']=299
    reject('valid_range_but_science_mismatched_case_cap',lambda:validate_bundle(changed),ValueError)
    changed=deepcopy(bundle);changed['study_limits']['CPU_seconds']=19999
    reject('valid_range_but_science_mismatched_aggregate_cap',lambda:validate_bundle(changed),ValueError)
    changed=deepcopy(bundle);changed['runs']=changed['runs'][:-1]
    reject('missing_seventh_slot_not_a_complete_allowlist',lambda:validate_bundle(changed),ValueError)
    reject('missing_entropy_authority_before_IO',lambda:authorize_entropy(),NotReady)
    reject('missing_controller_authority_before_IO',lambda:authorize_controller_launch(),NotReady)
    reject('missing_worker_authority_before_IO',lambda:authorize_actual_worker(),NotReady)
    # Entirely synthetic in-memory objects may exercise both scope tags. This
    # never calls an actual loader or creates an ActualPermit.
    op=Operator('artificial-seventh-dispatch','fixed/v1',MODES)
    groups=tuple(Group(g,tuple(Record(f'fixture/{g}/{i}',f'fixture-content-{g}-{i}') for i in range(2))) for g in 'ABC')
    request=request_from_groups(groups,op,budget=6)
    rows=tuple(r for g in groups for r in g.records)
    values={r.rid:((1,)*14 if g.gid=='A' else (0,)*14) for g in groups for r in g.records}
    ranks={phase:dict.fromkeys('ABC',0) for phase in ('pilot','formal')}
    for scope in ('artificial','actual_bound'):
        req=replace(request,scope=scope)
        cache=ArtificialVectorCache(op,rows,lambda rid,content:values[rid],scope=scope,cache_scope='cold_request')
        wrapped=dispatch(req,None,cache,METHODS[-1],ranks,None)
        assert wrapped['authoritative_request_scope']==scope
        assert wrapped['method_id']==METHODS[-1] and wrapped['result']['complete']
        assert wrapped['result']['physical_attempts']==4
        assert all(d['value'] is True for d in wrapped['result']['decisions'])
        assert wrapped['legacy_report_metadata']['scope']==scope
    checks.append({'case':'seventh_dispatch_scope_preserved_on_two_synthetic_tags','status':'PASS_NO_ACTUAL_IO'})
    u=resource.getrusage(resource.RUSAGE_SELF)
    result={'status':'PASS_NEW_SEVENTH_AND_SCIENTIFIC_BINDING_CHECKS','checks':checks,
        'CPU_before_final_write':u.ru_utime+u.ru_stime,'max_RSS_bytes':u.ru_maxrss*1024,
        'old_six_method_or_full300_repeated':False,'actual_data_or_entropy':False,'actual_ready':False}
    (OUT/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'checks':len(checks),'CPU':result['CPU_before_final_write']}))
except BaseException:
    u=resource.getrusage(resource.RUSAGE_SELF)
    (OUT/'FAILURE_RETAINED.json').write_text(json.dumps({'status':'FAILED_RETAINED','checks':checks,
        'traceback':traceback.format_exc(),'CPU_before_final_write':u.ru_utime+u.ru_stime,
        'actual_data_or_entropy':False,'actual_ready':False},indent=2)+'\n')
    raise
