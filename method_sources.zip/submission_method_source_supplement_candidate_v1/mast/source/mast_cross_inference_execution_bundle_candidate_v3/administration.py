"""All planned slots, explicit external seal, metadata and opaque hashing only."""
from pathlib import Path
from fee_adapter import fee_account
from contract import TERMINAL,integer,validate_bundle
from io_utils import file_hash,inventory,load_json,object_hash,safe_file

def unknown_charge(charge):return dict(charge,state='UNSEALED_UNKNOWN_TAIL',exact_total=None,exact_tail='UNKNOWN')
def closed_metadata(slot_dir,context,run,kind='FAKE_ONLY'):
    slot_dir=Path(slot_dir);charge=fee_account(slot_dir/'FEE_JOURNAL.ndjson',context,run['run_id'],kind)
    try:
        s=load_json(slot_dir/'ADMIN_SUMMARY.json',2097152);c=load_json(slot_dir/'WORKER_CLOSED.json')
        expected='fake-worker-admin-summary/v1' if kind=='FAKE_ONLY' else 'bound-worker-admin-summary/v2'
        if s['schema']!=expected or s['run']!=run or c['run']!=run or s['context']!=context or c['context']!=context:raise ValueError('closed identity')
        for obj in (s,c):integer(obj['physical_attempts'],0,300)
        if s['status'] not in ('NORMAL_CLOSED','FAILED_CLOSED') or c['status']!=s['status'] or c['summary_sha256']!=file_hash(slot_dir/'ADMIN_SUMMARY.json'):raise ValueError('closed summary/status hash')
        if s['physical_attempts']!=c['physical_attempts'] or s['fee_chain']!=c['fee_chain'] or charge['state']!='SEALED_EXACT' or charge['exact_total']!=s['physical_attempts'] or charge['last_chain']!=s['fee_chain']:raise ValueError('closed durable fee binding')
        files=[s['packet']] if kind=='FAKE_ONLY' else s['files']
        if type(files) is not list or not files:raise ValueError('private sealed inventory required')
        for entry in files:
            p=safe_file(slot_dir,entry['path'])
            if not entry['path'].startswith('private/') or type(entry['bytes']) is not int or entry['bytes']!=p.stat().st_size or entry['sha256']!=file_hash(p):raise ValueError('private packet binding')
        return dict(status='WORKER_SEALED' if s['status']=='NORMAL_CLOSED' else 'WORKER_FAILED_CLOSED',charge=charge,
            summary_sha256=file_hash(slot_dir/'ADMIN_SUMMARY.json'),closed_sha256=file_hash(slot_dir/'WORKER_CLOSED.json'),private_results_decoded=False)
    except (OSError,ValueError,KeyError,TypeError) as exc:
        return dict(status='CENSORED_UNKNOWN',charge=unknown_charge(charge),closure_error_type=type(exc).__name__,private_results_decoded=False)

def validate_rows(rows,context,bundle):
    runs=bundle['runs']
    if type(rows) is not list or len(rows)!=len(runs):raise ValueError('every explicitly planned terminal row required')
    for row,run in zip(rows,runs):
        if type(row) is not dict or row.get('run')!=run or type(row['run']['slot']) is not int or type(row['run']['replicate_id']) is not int or row.get('context')!=context or row.get('status') not in TERMINAL:raise ValueError('terminal row identity/status')
        if row.get('completion_win') is not False or row.get('scientific_adjudication')!='UNKNOWN' or row.get('private_results_decoded') is not False:raise ValueError('administration cannot grant scientific completion')
        charge=row['charge'];integer(charge['known_durable_submitted_prefix'],0,300)
        if row['status'] in ('WORKER_SEALED','WORKER_FAILED_CLOSED','START_FAILED_UNSUBMITTED','UNRUN_GLOBAL_STOP'):
            if charge['state']!='SEALED_EXACT' or type(charge['exact_total']) is not int or charge['exact_total']!=charge['known_durable_submitted_prefix'] or charge['exact_tail']!='KNOWN':raise ValueError('exact fee schema')
            if row['status'] in ('START_FAILED_UNSUBMITTED','UNRUN_GLOBAL_STOP') and charge['exact_total']!=0:raise ValueError('unstarted fees')
        elif charge['state']!='UNSEALED_UNKNOWN_TAIL' or charge['exact_total'] is not None or charge['exact_tail']!='UNKNOWN':raise ValueError('unknown-tail schema')

def verify_barrier(study_root,external_seal,expected_seal_sha256,bundle,*,authority_refs=None):
    bound,context=validate_bundle(bundle);root=Path(study_root).resolve();external=Path(external_seal).resolve()
    if bound['scope']=='FINAL_BOUND_ACTUAL':
        from authority_v2 import authorize_controller_launch
        permit=authorize_controller_launch(authority_refs)
        if permit.bundle!=bound or Path(permit.study_root).resolve()!=root:raise ValueError('actual barrier launch-authority binding')
        context=permit.context
    if external.is_relative_to(root) or file_hash(external)!=expected_seal_sha256:raise ValueError('explicit external seal SHA required')
    seal=load_json(external);path=root/'ALL_SLOTS_TERMINAL.json'
    if seal.get('schema')!='planned-slots-external-admin-seal/v2' or seal.get('context')!=context or seal.get('planned_slot_count')!=len(bound['runs']) or seal.get('planned_slots_sha256')!=object_hash(bound['runs']) or seal.get('study_root')!=str(root) or seal.get('barrier_sha256')!=file_hash(path):raise ValueError('external barrier full-plan binding')
    b=load_json(path,2097152)
    if b.get('status')!='ALL_PLANNED_SLOTS_TERMINAL_ADMIN_ONLY' or b.get('scope')!=bound['scope'] or b.get('context')!=context or b.get('bundle_sha256')!=object_hash(bound) or b.get('planned_slots_sha256')!=object_hash(bound['runs']) or b.get('planned_slot_count')!=len(bound['runs']) or b.get('scientific_success')!='UNKNOWN' or b.get('private_results_decoded') is not False or (bound['scope']=='FINAL_BOUND_ACTUAL' and b.get('synthetic_assembled') is True):raise ValueError('overall planned barrier status')
    validate_rows(b['rows'],context,bound)
    if b['inventory']!=inventory(root,exclude=('ALL_SLOTS_TERMINAL.json',)) or object_hash(b['inventory'])!=seal.get('inventory_sha256'):raise ValueError('complete opaque inventory mismatch')
    for row in b['rows']:
        if row['status'] in ('WORKER_SEALED','WORKER_FAILED_CLOSED'):
            observed=closed_metadata(root/'slots'/row['run']['run_id'],context,row['run'],bound['dispatch'][row['run']['method_id']]['kind'])
            if observed['status']!=row['status'] or observed['charge']!=row['charge'] or observed['summary_sha256']!=row['summary_sha256'] or observed['closed_sha256']!=row['closed_sha256']:raise ValueError('sealed worker independent recheck')
    return dict(status='VERIFIED_ALL_PLANNED_SLOTS_ADMIN_ONLY',context=context,seal_sha256=expected_seal_sha256,planned_slot_count=len(bound['runs']),private_results_decoded=False,scientific_success='UNKNOWN')

def artificial_postbarrier_callback(study_root,external_seal,expected_seal_sha256,bundle,callback):
    if bundle.get('scope')!='ARTIFICIAL_ONLY':raise PermissionError('private real audit needs separate authority/interface')
    return callback(verify_barrier(study_root,external_seal,expected_seal_sha256,bundle))
