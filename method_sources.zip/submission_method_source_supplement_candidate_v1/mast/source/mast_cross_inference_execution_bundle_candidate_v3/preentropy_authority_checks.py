"""Pure authority objects and injected entropy bytes only, never OS study RNG."""
from pathlib import Path
from copy import deepcopy
import json,sys,os,resource,hashlib,traceback
ROOT=Path(__file__).resolve().parent
sys.dont_write_bytecode=True
os.nice(max(0,10-os.getpriority(os.PRIO_PROCESS,0)))
resource.setrlimit(resource.RLIMIT_CPU,(8,8))
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
from contract import METHODS
from method_dispatch import route_plan
from reference_schema import MODES
from authority_v2 import check_authority_objects,authorize_entropy,BASE,NotReady,validate_entropy
from entropy import _write_once
from io_utils import object_hash,load_json
OUT=ROOT/'preentropy_check_artifacts';OUT.mkdir(exist_ok=False)
checks=[]
def h(name):return hashlib.sha256(name.encode()).hexdigest()
def reject(name,fn,kind):
    try:fn()
    except kind:checks.append({'case':name,'status':'PASS_REJECT'})
    else:raise AssertionError(name+' accepted')
try:
    science_path=ROOT.parent/'mast_56_final_protocol_candidate_v1/SCIENTIFIC_CONTRACT_FINAL.json'
    science_text=science_path.read_text();science=json.loads(science_text)
    keys=BASE+('auditor_ready','entropy','launch_ready')
    hashes={name:h(name) for name in keys}
    settings=dict(schema='fixed-released-vector-study-settings/v2',
        data_contract_sha256='a1ce9ee118c06cd2d72b0cff3cd28c6358f89fdbfeaed4ca5423ba9cc49ed690',
        N=dict(A=100,B=100,C=100),mode_ids=list(MODES),request_alpha='1/20',budgets=[75,150,225,300],
        physical_fee_unit='accepted_whole14_vector_attempt',local_paid_pilot_per_group=5,
        local_prior='1/2 Beta(1,1)+1/2 Beta(1+s_p,6-s_p)',method_specs={m:route_plan(m) for m in METHODS})
    bundle=dict(schema='cross-inference-control-bundle/v2',scope='FINAL_BOUND_ACTUAL',status='FINAL_FIXED_PROTOCOL',
        scientific_plan_json=science_text,runs=science['runs'],
        pins=dict(scientific_contract_sha256=hashlib.sha256(science_text.encode()).hexdigest(),
            local_bridge_sha256='3abdc38ed11ef68613906cbbe1e6c35dae4e8c56cfa4e16d61b02c782ee08699',
            external_bridge_sha256='f546b64b82daec438a2b78a2effc4ede131025023ad17e7796def23bafd62d6e',
            controller_closure_sha256=hashes['code_closure'],entropy_sha256='EXTERNAL_AFTER_CORE_READY',
            data_contract_sha256=settings['data_contract_sha256'],protocol_sha256=hashes['protocol_settings']),
        dispatch={m:dict(kind='BOUND_PRIVATE_WORKER',worker_policy=m,worker_code_sha256=h('worker-code'),
            worker_ready_sha256=hashes['worker_ready'],interpreter=str(Path(sys.executable).resolve())) for m in METHODS},
        limits=science['resources']['per_method'],study_limits=science['resources']['study'],controller_limits=science['resources']['controller'])
    audit_bind=dict(auditor_manifest_sha256=h('auditmanifest'),auditor_closure_sha256=h('auditclosure'),
        audit_policy_sha256='de917731af26699e8a52c6893a16005d6cd9fef6bd3b7b54fb3da1f61ee8203c',
        scientific_contract_sha256=bundle['pins']['scientific_contract_sha256'],native_environment_sha256=hashes['environment_binding'])
    final=dict(schema='final-cross-inference-execution-protocol/v2',status='FINAL_EXECUTION_AUTHORIZED',
        execution_authorized=True,resources_status='FINAL_LABEL_BLIND_REVIEWED',bundle=bundle,
        data_manifest_sha256='f6ee2cb34103bdf4921e5e01d633dd2ce47b5e4477db391167cd104a8f7fbbe7',
        study_root=str(ROOT.parent/'artificial-authority-test-never-an-actual-run'),
        audit_bindings=audit_bind,entropy_output_path=str(OUT/'never_actual_entropy.json'))
    objects={'final_protocol':final,'protocol_settings':settings,
        'worker_ready':dict(status='READY_FOR_BOUND_PRIVATE_WORKER',manifest_sha256=hashes['worker_manifest'],code_closure_sha256=hashes['code_closure']),
        'controller_ready':dict(status='READY_FOR_BOUND_CONTROL_PLANE',manifest_sha256=hashes['controller_manifest'],code_closure_sha256=hashes['code_closure'])}
    bindings={name+'_sha256':hashes[name] for name in ('final_protocol','protocol_settings','worker_ready','controller_ready','worker_manifest','controller_manifest','code_closure','environment_binding')}
    objects['core_ready']=dict(status='READY_FOR_BOUND_CORE_AND_ENTROPY',bindings=bindings,method_access_before_entropy=False)
    objects['auditor_ready']=dict(status='READY_FOR_BOUND_POSTBARRIER_AUDIT',final_protocol_sha256=hashes['final_protocol'],
        manifest_sha256=audit_bind['auditor_manifest_sha256'],code_closure_sha256=audit_bind['auditor_closure_sha256'],
        audit_policy_sha256=audit_bind['audit_policy_sha256'],scientific_contract_sha256=audit_bind['scientific_contract_sha256'],
        native_environment_sha256=audit_bind['native_environment_sha256'])
    result=check_authority_objects(objects,hashes,launch=False)
    assert len(result[0]['runs'])==56 and result[3] is None
    checks.append({'case':'complete_metadata_preentropy_graph_valid_no_capability','status':'PASS_PURE_ONLY'})
    bad=deepcopy(objects);bad['auditor_ready']['audit_policy_sha256']=h('wrong-policy')
    reject('wrong_auditor_policy_blocks_preentropy',lambda:check_authority_objects(bad,hashes,launch=False),NotReady)
    bad=deepcopy(objects);bad['auditor_ready']['final_protocol_sha256']=h('wrong-final')
    reject('wrong_auditor_final_blocks_preentropy',lambda:check_authority_objects(bad,hashes,launch=False),NotReady)
    bad=deepcopy(objects);bad['final_protocol']['audit_bindings']['native_environment_sha256']=h('wrong-env')
    reject('wrong_auditor_env_blocks_preentropy',lambda:check_authority_objects(bad,hashes,launch=False),NotReady)
    refs={k:{'path':'/nonexistent/never-opened.json','sha256':h(k)} for k in BASE}
    reject('missing_auditor_reference_rejects_before_metadata_IO',lambda:authorize_entropy(refs),NotReady)
    calls=[]
    def injected(size):calls.append(size);return bytes(size)
    target=OUT/'ARTIFICIAL_INJECTED_RANKS.json'
    written=_write_once(target,hashes,injected,actual=False)
    assert len(calls)==48 and written['actual_study'] is False
    record=load_json(target)
    reject('artificial_rank_tags_cannot_pass_actual_entropy_validation',lambda:validate_entropy(record,bundle,hashes),NotReady)
    before=len(calls)
    reject('second_write_refuses_before_more_bytes',lambda:_write_once(target,hashes,injected,actual=False),RuntimeError)
    assert len(calls)==before
    claimed=OUT/'CLAIM_ONLY_NO_RECORD.json';claim=claimed.with_name(claimed.name+'.DRAW_CLAIM.json');claim.write_text('{}\n')
    reject('claimed_missing_record_never_redraws',lambda:_write_once(claimed,hashes,injected,actual=False),FileExistsError)
    assert len(calls)==before
    checks.append({'case':'persistent_claim_and48_injected_draws_only','status':'PASS_NO_OS_STUDY_ENTROPY'})
    u=resource.getrusage(resource.RUSAGE_SELF)
    out={'status':'PASS_PREENTROPY_AUDITOR_BINDINGS_AND_ONCE_ONLY_FIXTURES','checks':checks,
         'CPU_before_final_write':u.ru_utime+u.ru_stime,'actual_study_entropy_draws':0,
         'actual_data_or_Source_read':False,'actual_READY_issued':False}
    (OUT/'RESULTS.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({'status':out['status'],'checks':len(checks),'CPU':out['CPU_before_final_write']}))
except BaseException:
    (OUT/'FAILURE_RETAINED.json').write_text(json.dumps({'checks':checks,'error':traceback.format_exc(),
        'CPU_before_final_write':resource.getrusage(resource.RUSAGE_SELF).ru_utime+resource.getrusage(resource.RUSAGE_SELF).ru_stime,
        'actual_study_entropy_draws':0},indent=2)+'\n')
    raise
