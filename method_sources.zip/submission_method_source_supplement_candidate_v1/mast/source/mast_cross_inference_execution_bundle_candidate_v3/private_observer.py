"""Online history stays private; budgets never use already-overspent states."""
from pathlib import Path
from copy import deepcopy
from hashlib import sha256
from codec import Journal,canonical,atomic_json

class PrivateObserver:
    def __init__(self,outdir,run_id,cache):
        self.root=Path(outdir);self.cache=cache;self.tape=Journal(self.root/'private/ONLINE_HISTORY.ndjson',run_id)
        self.last=dict(physical_fees=0,complete=False,decisions=(),state=None);self.snapshots={};self.first=None
    def record(self,stage,state,complete,decisions,checker=None):
        spent=self.cache.spent
        if spent<self.last['physical_fees']:raise ValueError('fee monotonicity')
        for b in (75,150,225,300):
            if b not in self.snapshots and self.last['physical_fees']<=b<spent:self.snapshots[b]=deepcopy(self.last)
        node=dict(stage=stage,physical_fees=spent,complete=bool(complete),decisions=deepcopy(decisions),state=deepcopy(state),checker=deepcopy(checker))
        self.tape.append('ONLINE_COMMITTED_STATE',**node);self.last=node
        if complete and self.first is None:self.first=deepcopy(node)
        for b in (75,150,225,300):
            if spent==b:self.snapshots[b]=deepcopy(node)
    def local(self,stage,state,checker,decisions,gid,rid):self.record(stage,state,checker['complete'],decisions,checker)
    def external(self,stage,state,result):self.record(stage,state,result[0],result[1])
    def finish(self):
        for b in (75,150,225,300):
            if b not in self.snapshots and self.last['physical_fees']<=b:self.snapshots[b]=deepcopy(self.last)
        self.tape.close()
        return dict(budget_snapshots=self.snapshots,first_online_complete=self.first,last=self.last,unknown_tail_not_completed=True)
