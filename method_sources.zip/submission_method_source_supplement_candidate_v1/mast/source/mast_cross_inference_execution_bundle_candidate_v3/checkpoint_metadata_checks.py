from pathlib import Path
from types import SimpleNamespace
import json,resource,time
resource.setrlimit(resource.RLIMIT_CPU,(4,5))
resource.setrlimit(resource.RLIMIT_AS,(1073741824,1073741824))
from private_observer import PrivateObserver
from codec import journal_prefix,encoded
from authority_v2 import _read_references
from io_utils import file_hash
P=Path(__file__).resolve().parent;O=P/'checkpoint_metadata_artifacts';O.mkdir(exist_ok=False)
cases=[];start=time.process_time()
def passed(name):cases.append(dict(case=name,status='PASS'))
try:
 c=SimpleNamespace(spent=75);obs=PrivateObserver(O/'producer','ARTIFICIAL_ONLY',c)
 state={'domains':{'A':[[0,100]]},'counts':{'A':[1,2]}};decisions=[{'bit':True,'nested':[3]}];checker={'complete':True,'nested':{'x':[4]}}
 obs.record('early',state,True,decisions,checker)
 state['domains']['A'][0][0]=99;state['counts']['A'][0]=77;decisions[0]['nested'][0]=88;checker['nested']['x'][0]=66
 assert obs.last['state']['domains']['A']==[[0,100]] and obs.last['state']['counts']['A']==[1,2]
 assert obs.last['decisions'][0]['nested']==[3] and obs.last['checker']['nested']['x']==[4]
 passed('producer_mutation_does_not_rewrite_committed_nested_state_decisions_checker')
 c.spent=150;obs.record('late',state,True,decisions,checker);out=obs.finish()
 rows,err=journal_prefix(O/'producer/private/ONLINE_HISTORY.ndjson');assert err is None
 assert encoded(out['budget_snapshots'][75])==rows[0]['data']
 assert encoded(out['first_online_complete'])==rows[0]['data']
 assert encoded(out['budget_snapshots'][150])==rows[1]['data']
 out['last']['state']['counts']['A'][0]=12345
 assert out['budget_snapshots'][150]['state']['counts']['A'][0]==77
 passed('budget_and_first_snapshots_equal_their_historical_journal_nodes_and_are_detached')
 c=SimpleNamespace(spent=74);obs=PrivateObserver(O/'cross','ARTIFICIAL_ONLY',c);s={'domains':{'A':[0,2]}}
 obs.record('before',s,False,[]);s['domains']['A'][0]=1;c.spent=76;obs.record('after',s,False,[]);r=obs.finish()
 assert r['budget_snapshots'][75]['physical_fees']==74 and r['budget_snapshots'][75]['state']['domains']['A']==[0,2]
 passed('budget_crossing_retains_previous_committed_affordable_state')
 env=P/'ENVIRONMENT_BINDING_CANDIDATE.json';assert 2097152<env.stat().st_size<8388608
 ref={'path':str(env),'sha256':file_hash(env)};objects,hashes=_read_references({'environment_binding':ref},('environment_binding',))
 assert objects['environment_binding']['schema']=='complete-worker-environment-binding/v1' and hashes['environment_binding']==ref['sha256']
 passed('fixed_code_only_environment_binding_parses_with_8MiB_bound')
 try:_read_references({'protocol_settings':ref},('protocol_settings',))
 except ValueError:passed('nonenvironment_metadata_remains_2MiB_bounded')
 else:raise AssertionError('other metadata cap unexpectedly expanded')
 result=dict(status='PASS_LIMITED_CHECKPOINT_AND_METADATA_REPAIRS',checks=cases,CPU_before_final_write=time.process_time()-start,actual_data_Source_or_OS_study_entropy=False,actual_READY_issued=False)
except BaseException:
 import traceback
 result=dict(status='FAILED_RETAINED',checks=cases,traceback=traceback.format_exc(),CPU_before_final_write=time.process_time()-start,actual_READY_issued=False)
(O/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
