"""Separate procedural audit admission. Scientific validators remain explicit."""
from dataclasses import dataclass
from pathlib import Path
from administration import verify_barrier
from authority_v2 import authorize_controller_launch
from gate import NotReady
from io_utils import load_json,object_hash

@dataclass(frozen=True)
class AuditAdmission:
    context:str
    external_seal_sha256:str
    planned_slots_sha256:str
    private_results_opened:bool=False

def admit_audit(study_root,seal,seal_sha,bundle,*,authority_refs=None):
    receipt=verify_barrier(study_root,seal,seal_sha,bundle,authority_refs=authority_refs)
    return AuditAdmission(receipt['context'],seal_sha,object_hash(bundle['runs']))

def audit_administrative_costs(study_root,seal,seal_sha,bundle,*,authority_refs=None):
    admission=admit_audit(study_root,seal,seal_sha,bundle,authority_refs=authority_refs)
    rows=load_json(Path(study_root)/'ALL_SLOTS_TERMINAL.json',2097152)['rows']
    return dict(status='POSTBARRIER_ADMIN_COSTS_ONLY',context=admission.context,
        rows=[dict(run=r['run'],status=r['status'],charge=r['charge'],online_completion_credit=False,scientific_correctness='UNKNOWN') for r in rows],
        private_results_opened=False,truth_opened=False,no_offline_promotion=True)

def audit_truth_online_history_and_certificates(*args,**kwargs):
    # No payload/history/truth read occurs while this interface is incomplete.
    raise NotReady('NOT_READY: separately frozen six/seven method-specific online-prefix replay, strict whole-request truth, sticky anytime-error and checkpoint/cost validators must be supplied; administrative seals alone cannot grant a win')
