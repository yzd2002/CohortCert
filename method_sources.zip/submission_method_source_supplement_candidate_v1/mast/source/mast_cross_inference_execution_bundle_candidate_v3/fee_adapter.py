"""Administrative shape only; inherited physical fee rules are unchanged."""
from pathlib import Path
from charges import accounting
def fee_account(path,context,run_id,kind):
    if kind=='FAKE_ONLY':return accounting(path,context,run_id)
    if kind!='BOUND_PRIVATE_WORKER':raise ValueError('unknown fee backend authority')
    from codec import fee_accounting
    x=fee_accounting(Path(path));sealed=x['charge_state']=='SEALED_EXACT'
    if x.get('run_id') not in (None,run_id):return dict(state='UNSEALED_UNKNOWN_TAIL',known_durable_submitted_prefix=0,exact_total=None,exact_tail='UNKNOWN',events=x.get('journal_records',0),last_chain='0'*64,error_type='RunBindingMismatch',fee_backend='INHERITED_PREPAID_VECTOR_V1')
    return dict(state='SEALED_EXACT' if sealed else 'UNSEALED_UNKNOWN_TAIL',known_durable_submitted_prefix=x['known_durable_submitted_prefix'],exact_total=x['exact_total'] if sealed else None,
        exact_tail='KNOWN' if sealed else 'UNKNOWN',events=x.get('journal_records',0),last_chain=x.get('last_chain_hash','0'*64),error_type=x.get('error_type'),fee_backend='INHERITED_PREPAID_VECTOR_V1')
