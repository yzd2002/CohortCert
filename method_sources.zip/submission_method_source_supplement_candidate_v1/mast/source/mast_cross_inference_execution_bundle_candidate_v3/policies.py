"""ProtocolV3 observed-only group policies. No records, maps or ranks accepted."""
from fractions import Fraction as Q
from math import sqrt
from core import Choice,Linear

NAMES=('VectorRoundRobinABC_v1','VectorWidthSumGain_v1','VectorDifficultyWeightedWidthGain_v1')

class VectorPolicy:
    __slots__=('name','modes','targets')
    def __init__(self,name,modes):
        if name not in NAMES:raise ValueError('unknown fixed policy')
        self.name=name;self.modes=tuple(modes)
        self.targets=tuple(Linear.make({('A',m):Q(1,100),(r,m):Q(-1,100)}) for m in self.modes for r in ('B','C'))
    def __call__(self,state):
        if not state.formal_inference_frozen:raise ValueError('formal policy before paid pilot freeze')
        groups={g.gid:g for g in state.groups}
        if set(groups)!={'A','B','C'}:raise ValueError('fixed three-group policy')
        for gid in ('A','B','C'):
            if groups[gid].n==0 and groups[gid].residual_N>0:return Choice(gid,1)
        index={e:i for i,e in enumerate(state.expressions)};open_targets=[]
        for e in self.targets:
            if e not in index:raise ValueError('policy target binding mismatch')
            b=state.contrast_bounds[index[e]]
            if b is None:raise ValueError('unavailable count CS')
            if not (b[0]>0 or b[1]<=0):open_targets.append((e,b))
        eligible=[g for g in state.groups if g.n<g.residual_N and any(any(k[0]==g.gid for k,_ in e.terms) for e,_ in open_targets)]
        if not eligible:return None
        fallback=min(eligible,key=lambda g:(g.n,g.gid))
        if self.name==NAMES[0]:return Choice(fallback.gid,1)
        cur=0.0
        for _,(lo,hi) in open_targets:
            width=float(hi-lo);gap=max(abs(float((lo+hi)/2)),1e-4)
            cur+=width if self.name==NAMES[1] else width/(2*gap)
        best=None
        for g in sorted(eligible,key=lambda g:g.gid):
            rho=1.0 if g.n==0 else 0.0 if g.n+1>=g.residual_N else sqrt(g.n*(g.residual_N-g.n-1)/((g.n+1)*(g.residual_N-g.n)))
            pred=0.0
            for e,(lo,hi) in open_targets:
                change=0.0
                for (gid,m),coefficient in e.terms:
                    if gid!=g.gid:continue
                    interval=g.count_intervals[self.modes.index(m)]
                    if interval is None:raise ValueError('empty group CS')
                    change+=float(abs(coefficient)*(interval[1]-interval[0]))*(1-rho)
                width=float(hi-lo)-change;gap=max(abs(float((lo+hi)/2)),1e-4)
                pred+=width if self.name==NAMES[1] else width/(2*gap)
            gain=cur-pred
            if best is None or gain>best[0]:best=(gain,g.gid)
        return Choice(best[1] if best and best[0]>0 else fallback.gid,1)

class CensusProfilePolicy:
    """Artificial scale control only; not an additional study allocation arm."""
    __slots__=()
    def __call__(self,state):
        gs=[g for g in state.groups if g.n<g.residual_N and any(g.active_modes)]
        return Choice(min(gs,key=lambda g:(g.n,g.gid)).gid,1) if gs else None
