"""Injected syscall outcomes only; no actual study RNG or data accesses."""
from pathlib import Path
import resource,os,sys,json,hashlib,traceback
ROOT=Path(__file__).resolve().parent
sys.dont_write_bytecode=True
os.nice(max(0,10-os.getpriority(os.PRIO_PROCESS,0)))
resource.setrlimit(resource.RLIMIT_CPU,(3,3))
from entropy import _write_all
import entropy
OUT=ROOT/'short_write_artifacts';OUT.mkdir(exist_ok=False)
checks=[]
try:
    data=b'fixed-claim-bytes-for-complete-durable-write'
    seen=[]
    def short(fd,value):
        n=min(3,len(value));seen.append(value[:n]);return n
    _write_all(-1,data,short)
    assert b''.join(seen)==data
    checks.append({'case':'short_writes_preserve_every_byte_in_order','status':'PASS'})
    seen=[];calls=[0]
    def interrupted(fd,value):
        calls[0]+=1
        if calls[0] in (1,3):raise InterruptedError('injected EINTR')
        n=min(4,len(value));seen.append(value[:n]);return n
    _write_all(-1,data,interrupted)
    assert b''.join(seen)==data
    checks.append({'case':'interruption_retries_without_duplicates','status':'PASS'})
    for bad in (0,-1,True,len(data)+1):
        try:_write_all(-1,data,lambda fd,value,bad=bad:bad)
        except OSError:pass
        else:raise AssertionError('invalid write progress accepted')
    checks.append({'case':'zero_negative_bool_oversize_progress_rejected','status':'PASS'})
    original=entropy._write_all;bytes_calls=[]
    def fail_write(*args,**kwargs):raise OSError('injected no durable full claim')
    try:
        entropy._write_all=fail_write
        h={name:hashlib.sha256(name.encode()).hexdigest() for name in ('final_protocol','core_ready','auditor_ready')}
        target=OUT/'ARTIFICIAL_NEVER_DRAWN.json'
        try:entropy._write_once(target,h,lambda n:bytes_calls.append(n) or bytes(n),actual=False)
        except OSError:pass
        else:raise AssertionError('incomplete claim did not stop')
        assert not bytes_calls and not target.exists()
        assert target.with_name(target.name+'.DRAW_CLAIM.json').exists()
    finally:entropy._write_all=original
    checks.append({'case':'claim_write_failure_before_any_injected_rank_bytes','status':'PASS'})
    u=resource.getrusage(resource.RUSAGE_SELF)
    result={'status':'PASS_LIMITED_SHORT_WRITE_REPAIR','checks':checks,'CPU_before_final_write':u.ru_utime+u.ru_stime,
        'actual_data_or_OS_study_entropy':False,'actual_ready':False}
    (OUT/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'checks':len(checks),'CPU':result['CPU_before_final_write']}))
except BaseException:
    (OUT/'FAILURE_RETAINED.json').write_text(json.dumps({'checks':checks,'error':traceback.format_exc(),'actual_study_entropy':False},indent=2)+'\n')
    raise
