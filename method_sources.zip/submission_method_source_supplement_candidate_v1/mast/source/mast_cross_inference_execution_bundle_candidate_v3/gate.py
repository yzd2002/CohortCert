"""New authority only; old24 and external actual entry are never called."""
from pathlib import Path
from contract import validate_bundle
ROOT=Path(__file__).resolve().parent
class NotReady(PermissionError):pass
def authorize_actual(*args,**kwargs):
    from authority_v2 import authorize_controller_launch
    return authorize_controller_launch(*args,**kwargs)
def authorize_artificial(bundle,study_root):
    bound,context=validate_bundle(bundle)
    if bound['scope']!='ARTIFICIAL_ONLY' or any(d['kind']!='FAKE_ONLY' for d in bound['dispatch'].values()):raise NotReady('only fake artificial dispatch')
    root=Path(study_root).resolve()
    if not root.is_relative_to(ROOT/'artificial_runs') or root==ROOT/'artificial_runs':raise ValueError('artificial root only')
    return bound,context,root
