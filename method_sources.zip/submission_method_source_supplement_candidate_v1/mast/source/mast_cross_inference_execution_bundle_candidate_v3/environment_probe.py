"""Code/import/environment inventory only; never reads labels or runs methods."""
from pathlib import Path
import sys, os, resource, time, signal, json, hashlib, sysconfig
ROOT=Path(__file__).resolve().parent
sys.dont_write_bytecode=True
sys.path.insert(0,str(ROOT))
os.nice(max(0,10-os.getpriority(os.PRIO_PROCESS,0)))
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[key]='1'
resource.setrlimit(resource.RLIMIT_CPU,(60,60))
resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,)*2)
resource.setrlimit(resource.RLIMIT_FSIZE,(10*1024**2,)*2)
START=time.monotonic()
signal.signal(signal.SIGALRM,lambda *_:(_ for _ in ()).throw(TimeoutError('code-only environment wall1800')))
signal.alarm(1800)
OUT=ROOT/'environment_probe_artifacts'
OUT.mkdir(exist_ok=False)

# A cold import exercises configuration, not provider execution or data loading.
from contract import METHODS
from method_dispatch import prepare_route,route_plan
import authority_v2, bound_worker, policies, private_loader, private_observer
import durable_cache, codec, fee_adapter, entropy, administration, process_control
for method in METHODS:
    prepare_route(method,OUT/'slot')
from evergreen.common.constants import CACHE_DIR_ROOT
assert Path(CACHE_DIR_ROOT).resolve()==(OUT/'slot/private/native_cache').resolve()

def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as handle:
        for chunk in iter(lambda:handle.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()

files=set()
# Bind all code in this interpreter's installed dependency tree, including lazy
# submodules. This deliberately exceeds only the modules imported by the probe.
paths=sysconfig.get_paths()
site_dirs={Path(paths[key]).resolve() for key in ('purelib','platlib')}
suffixes={'.py','.pyc','.pyo','.so','.pyd','.dll','.dylib'}
for base in site_dirs:
    if base.is_dir():
        for p in base.rglob('*'):
            if p.is_file() and (p.suffix in suffixes or '.so.' in p.name):files.add(p.resolve())
stdlib=Path(paths['stdlib']).resolve()
for p in stdlib.rglob('*.py'):
    if p.is_file() and not any(p.resolve().is_relative_to(s) for s in site_dirs):files.add(p.resolve())
upstream=ROOT.parent/'evergreen_contract_adapter_candidate/upstream/src'
files.update(p.resolve() for p in upstream.rglob('*.py') if p.is_file())
# Also bind currently mapped external shared code (e.g. libm) and imported
# module files outside the dependency directory without exposing environment vars.
for line in Path('/proc/self/maps').read_text().splitlines():
    value=line.split(maxsplit=5)
    if len(value)==6 and value[5].startswith('/') and ('x' in value[1] or '.so' in value[5]):
        p=Path(value[5])
        if p.is_file():files.add(p.resolve())
imported=[]
for name,module in sorted(sys.modules.items()):
    path=getattr(module,'__file__',None)
    if path:
        p=Path(path).resolve()
        if p.is_file():files.add(p);imported.append({'module':name,'path':str(p)})
# Production sources have their own code closure; keep the import probe out of
# that closure without allowing it to masquerade as a bound actual worker.
files={p for p in files if not p.is_relative_to(ROOT)}
rows=[{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(files)]
executable=Path(sys.executable).resolve()
binding={'schema':'complete-worker-environment-binding/v1','complete_loaded_code_allowlist':True,
    'interpreters':[{'path':str(executable),'sha256':sha(executable),'version':sys.version}],
    'files':rows,'inventory_scope':'All installed dependency code files, stdlib Python, upstream SDK source, imported modules and mapped external shared code. Production research code has a separate closure.',
    'numeric_threads':1,'cache_policy':'Native constant configured to the private slot before import; cold semantic cache per actual run; no OS cache flush.',
    'actual_data_or_entropy_accessed':False,'method_or_model_execution':False}
(ROOT/'ENVIRONMENT_BINDING_CANDIDATE.json').write_text(json.dumps(binding,indent=2)+'\n')
u=resource.getrusage(resource.RUSAGE_SELF)
result={'status':'CODE_ONLY_COLD_IMPORT_AND_INVENTORY_COMPLETE','methods_registered':list(METHODS),
    'method_specs':{m:route_plan(m) for m in METHODS},'native_cache_confined':True,
    'dependency_code_files':len(rows),'dependency_code_bytes':sum(x['bytes'] for x in rows),
    'loaded_module_paths':imported,'resources':{'CPU_before_final_write':u.ru_utime+u.ru_stime,
    'wall':time.monotonic()-START,'max_RSS_bytes':u.ru_maxrss*1024},
    'actual_payload_Raw_Source_or_entropy':False,'actual_ready':False}
(OUT/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
signal.alarm(0)
print(json.dumps({'status':result['status'],'dependency_files':len(rows),
                  'CPU':result['resources']['CPU_before_final_write'],'actual_ready':False}))
