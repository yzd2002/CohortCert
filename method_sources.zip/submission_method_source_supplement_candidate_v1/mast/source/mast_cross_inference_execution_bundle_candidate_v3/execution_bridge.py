"""Artificial N300 integration only. Actual admission is unavailable.

The external routes retain their distinct inference/sampling laws. This module
owns typed public row order, durable physical charging, and private observations.
It is not the missing cross-method study controller or a real-data loader.
"""
from dataclasses import replace
from hashlib import sha256
from pathlib import Path
from fractions import Fraction as Q
import os,time,resource
import core as v
from codec import Journal,canonical,atomic_json,digest,fee_accounting
from durable_cache import DurableVectorCache
from authority import METHODS,actual_entry

BUDGETS=(75,150,225,300)


def compose_rho(request,ranks):
    """Pure metadata unranking; caller supplies independent uniform provenance.

    Deterministic profile ranks have no randomization/coverage claim. No label
    values or permutation search are used here.
    """
    if set(ranks)!={'pilot','formal'}:raise ValueError('rank phases')
    if any(set(x)!={g.gid for g in request.groups} for x in ranks.values()):raise ValueError('rank groups')
    groups=[]
    for g in request.groups:
        pilot=v.permutation_from_rank(g.records,ranks['pilot'][g.gid])[:5]
        used={r.rid for r in pilot}
        residual=tuple(r for r in g.records if r.rid not in used)
        rho=pilot+v.permutation_from_rank(residual,ranks['formal'][g.gid])
        if len(rho)!=len(g.records) or {r.rid for r in rho}!={r.rid for r in g.records}:raise ValueError('rho frame')
        groups.append(v.Group(g.gid,rho))
    return replace(request,groups=tuple(groups))


class NativePhysicalFacade:
    """Logical scalar projections reuse an already-paid complete vector.

    Every *fresh* native projection is a serial singleton physical dispatch via
    the inherited durable backend. A hit is not a physical dispatch, sample in
    another cohort, or new label. Native input/accumulator advancement alone
    controls statistical sample inclusion. Logical projections are in the
    native private trace; physical receipts remain in the shared fee journal.
    """
    def __init__(self,backend):
        self.backend=backend;self.projections=0;self.projection_hits=0
    def __getattr__(self,key):return getattr(self.backend,key)
    def fetch_batch(self,records,phase):
        if len(records)!=1:raise ValueError('native serial physical singleton contract')
        r=records[0];k=self.backend._key(r)
        self.projections+=1
        if k in self.backend._cache:
            if self.backend._session is None:raise ValueError('projection outside active session')
            self.projection_hits+=1
            return v.BatchResult(((r.rid,self.backend._cache[k]),),False,0,-1)
        return self.backend.fetch_batch(records,phase)
    def finish(self):
        cost=self.backend.finish()
        cost['native_logical_projections']=self.projections
        cost['native_projection_cache_hits']=self.projection_hits
        cost['physical_dispatch']='serial singleton first-RID vector acquisitions'
        cost['logical_tail_submitted_to_physical_backend']=False
        return cost


def small_decisions(decisions):
    return tuple(dict(name=d['name'],value=d.get('value'),selected=d.get('selected')) for d in decisions)


class PrivateObserver:
    def __init__(self,root,run_id,request,cache):
        self.root=Path(root);self.cache=cache;self.events=Journal(self.root/'private'/'ONLINE_OBSERVATIONS.ndjson',run_id)
        self.initial=dict(physical_submitted=0,complete=False,decisions=tuple(dict(name=n,value=None,selected=None) for n in v.compile_request(request).names),state_sha256=None,observation_kind='initial')
        self.last=self.initial;self.snapshots={};self.first_complete=None;self.count=0
    def __call__(self,event,state,result):
        complete,decisions=result;spent=self.cache.spent
        if spent<self.last['physical_submitted']:raise ValueError('nonmonotone physical fees')
        for b in BUDGETS:
            if b not in self.snapshots and self.last['physical_submitted']<=b<spent:self.snapshots[b]=dict(self.last)
        node=dict(physical_submitted=spent,complete=bool(complete),decisions=small_decisions(decisions),state_sha256=sha256(canonical(state)).hexdigest(),observation_kind=event)
        self.events.append('ONLINE_OUTPUT',**node)
        self.last=node;self.count+=1
        if node['complete'] and self.first_complete is None:self.first_complete=dict(node)
        for b in BUDGETS:
            if spent==b:self.snapshots[b]=dict(node)
    def finish(self):
        for b in BUDGETS:
            if b not in self.snapshots and self.last['physical_submitted']<=b:self.snapshots[b]=dict(self.last)
        self.events.close()
        return dict(observation_events=self.count,budget_snapshots=self.snapshots,first_online_complete=self.first_complete,profile_only=True,performance_metric=False)
    def close(self):self.events.close()


def claim_run(root,run_id):
    root=Path(root);root.mkdir(parents=True,exist_ok=False)
    fd=os.open(root/'RUN_STARTED.json',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    try:os.write(fd,canonical(dict(run_id=run_id,pid=os.getpid(),scope='artificial',actual_authorized=False)));os.fsync(fd)
    finally:os.close(fd)
    return root


def resource_now(start_cpu,start_wall):
    r=resource.getrusage(resource.RUSAGE_SELF)
    return dict(cpu_seconds=time.process_time()-start_cpu,wall_seconds=time.monotonic()-start_wall,max_RSS_bytes=r.ru_maxrss*1024)


def run_artificial_route(request,provider,route_id,outdir,*,force_full_profile=False):
    """One cold request. Physical rows must already be in the public rho order.

    Public production entry is deliberately absent. Using the pure typed
    schema is not permission to load an actual vector map. The generic Boolean
    compiler/checker is shared, including strict negative and TopK semantics.
    """
    if request.scope!='artificial':actual_entry()
    if route_id not in METHODS:raise ValueError('frozen external route')
    if len(request.groups)!=3 or any(len(g.records)!=100 for g in request.groups) or len(request.operator.modes)!=14 or len(v.compile_request(request).names)!=28:raise ValueError('this bridge requires the complete N300/M14/28 shape')
    root=claim_run(outdir,route_id);start_cpu=time.process_time();start_wall=time.monotonic()
    rows=tuple(r for g in request.groups for r in g.records)
    backend=DurableVectorCache(request.operator,rows,provider,root,route_id)
    cache=backend if route_id.startswith('SSS_') else NativePhysicalFacade(backend)
    observer=PrivateObserver(root,route_id,request,backend)
    try:
        if route_id=='SSS_Kelly_FiniteUpperNullCover_RR_v1':
            from sss_routes import run
            result=run(request,cache,batch_size=1,stop_on_complete=not force_full_profile,profile='kelly_wor_plugin',observer=observer)
            # The full vector tape and committed online decisions are durable.
            # Avoid duplicating all growing atom-summary histories in the packet.
            result.pop('output_history',None)
        elif route_id=='Evergreen_NativeExactVector_v1':
            from native_routes import NativeExactVector
            result=NativeExactVector().run(request,cache,seed=101,batch=2,observer=observer)
        else:
            from native_routes import ProgressiveNativeVector
            result=ProgressiveNativeVector().run(request,cache,group_seeds={'A':101,'B':102,'C':103},batch=2,observer=observer,force_full_profile=force_full_profile)
        # Route exceptions swallowed by the legacy route remain visible. A
        # completed bookkeeping seal does not grant statistical completeness.
        error=result.get('error') or result.get('failure')
        if backend._session is not None:
            result['forced_session_close']=backend.finish()
        cost=backend.seal_cost()
        observations=observer.finish()
        packet=dict(schema='mast-external-artificial-run/v1',route=route_id,scope='artificial',force_full_profile=force_full_profile,profile_not_benchmark=True,result=result,observations=observations,fees=cost,resources=resource_now(start_cpu,start_wall),actual_ready=False)
        atomic_json(root/'private'/'RUN_PACKET.json',packet)
        backend.close()
        files={str(p.relative_to(root)):dict(bytes=p.stat().st_size,sha256=digest(p)) for p in root.rglob('*') if p.is_file() and p.name not in ('ADMIN_SUMMARY.json','WORKER_CLOSED.json')}
        admin=dict(schema='mast-external-admin/v1',run_id=route_id,status='FAILED_RETAINED' if error else 'NORMAL_CLOSED',fees=cost,resources=resource_now(start_cpu,start_wall),files=files,scope='artificial',actual_ready=False)
        atomic_json(root/'ADMIN_SUMMARY.json',admin)
        atomic_json(root/'WORKER_CLOSED.json',dict(run_id=route_id,status=admin['status'],admin_sha256=digest(root/'ADMIN_SUMMARY.json')))
        return admin
    except BaseException as exc:
        # Never seal a killed/censored active session or promote a durable
        # prefix to exact total. Offline proof discovery cannot upgrade it.
        observer.close();backend.close()
        account=fee_accounting(root/'FEE_JOURNAL.ndjson')
        retained=dict(schema='mast-external-censor/v1',run_id=route_id,status='CENSORED_OR_FAILED',type=type(exc).__name__,message=str(exc),fees=account,resources=resource_now(start_cpu,start_wall),actual_ready=False)
        atomic_json(root/'CENSOR_RETAINED.json',retained)
        raise
