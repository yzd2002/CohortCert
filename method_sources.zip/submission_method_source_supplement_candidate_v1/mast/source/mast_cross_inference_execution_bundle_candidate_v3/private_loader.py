"""Only a private ActualPermit can reach the two fixed saved-reference files."""
from pathlib import Path
from authority_v2 import DATA_CONTRACT,DATA_MANIFEST,require_actual_permit
from gate import ROOT,NotReady
from io_utils import file_hash,load_json

def load_actual_inputs(permit):
    require_actual_permit(permit) # Before resolving/statting/hashing data paths.
    contract_path=ROOT/'inputs/DATA_CONTRACT.json'
    if file_hash(contract_path)!=DATA_CONTRACT:raise NotReady('fixed a1ce contract changed')
    contract=load_json(contract_path)
    data=ROOT.parent/'mast_release_key_request_v1/data_construction_review_v1'
    if file_hash(data/'DELIVERY_MANIFEST.json')!=DATA_MANIFEST:raise NotReady('fixed f6ee data manifest changed')
    objects=[]
    for field in ('locked_vector_artifact','record_identity_artifact'):
        item=contract[field];path=(data/item['path']).resolve()
        if not path.is_relative_to(data.resolve()) or path.is_symlink() or path.stat().st_size!=item['bytes'] or file_hash(path)!=item['sha256']:raise NotReady('fixed approved reference identity changed')
        objects.append(load_json(path,1048576))
    from reference_schema import decode_reference_objects,request_from_groups,fixed_config
    groups,operator,provider=decode_reference_objects(objects[0],objects[1],contract)
    ranks=permit.ranks[str(permit.run['replicate_id'])]
    cfg=fixed_config({g:ranks[g]['pilot_rank'] for g in 'ABC'},{g:ranks[g]['formal_rank'] for g in 'ABC'})
    return request_from_groups(groups,operator,scope='actual_bound'),cfg,provider
