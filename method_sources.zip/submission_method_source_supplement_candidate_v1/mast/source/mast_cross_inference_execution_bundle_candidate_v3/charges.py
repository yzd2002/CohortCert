"""Fsynced whole-batch submissions; only sealed totals are exact."""
from pathlib import Path
import json,os
from io_utils import canonical,object_hash
from contract import integer

class FeeJournal:
    def __init__(self,path,context,run_id):
        self.path=Path(path);self.file=self.path.open('xb');self.context=context;self.run_id=run_id
        self.seq=0;self.chain='0'*64;self.total=0;self.sealed=False
    def append(self,kind,units=0):
        if self.sealed:raise ValueError('fee journal already sealed')
        integer(units,0,300)
        if kind not in ('SUBMITTED','RETURNED','FAILED','COST_SEALED'):raise ValueError('fee event')
        if kind=='SUBMITTED':integer(units,1,5)
        elif units!=0:raise ValueError('non-submission has no new fee')
        if self.total+units>300:raise ValueError('unsubmitted physical fee limit')
        row=dict(context=self.context,run_id=self.run_id,seq=self.seq,previous=self.chain,event=kind,units=units)
        row['hash']=object_hash(row);self.file.write(canonical(row));self.file.flush();os.fsync(self.file.fileno())
        self.chain=row['hash'];self.seq+=1
        if kind=='SUBMITTED':self.total+=units
        if self.total>300:raise ValueError('physical fee limit exceeded')
        if kind=='COST_SEALED':self.sealed=True
    def acquire(self,count,provider):
        self.append('SUBMITTED',count) # Whole accepted batch is durable before any backend.
        out=[]
        for i in range(count):
            try:out.append(provider(i));self.append('RETURNED')
            except Exception:self.append('FAILED');return out,False
        return out,True
    def seal(self):self.append('COST_SEALED');self.file.close()

def accounting(path,context,run_id):
    prefix=0;seq=0;chain='0'*64;sealed=False;error=None
    try:
        with Path(path).open('rb') as f:
            for line in f:
                if len(line)>8192 or not line.endswith(b'\n'):raise ValueError('partial/oversize fee event')
                row=json.loads(line)
                if type(row) is not dict or set(row)!={'context','run_id','seq','previous','event','units','hash'}:raise ValueError('fee fields')
                if sealed or row['context']!=context or row['run_id']!=run_id or type(row['seq']) is not int or row['seq']!=seq or row['previous']!=chain:raise ValueError('fee identity/chain')
                claimed=row.pop('hash')
                if object_hash(row)!=claimed:raise ValueError('fee event digest')
                units=integer(row['units'],0,300);event=row['event']
                if event=='SUBMITTED':prefix+=integer(units,1,5)
                elif event in ('RETURNED','FAILED','COST_SEALED') and units==0:sealed=event=='COST_SEALED'
                else:raise ValueError('unknown fee event')
                if prefix>300:raise ValueError('fee cap')
                seq+=1;chain=claimed
    except (OSError,ValueError,KeyError,TypeError) as exc:error=type(exc).__name__
    return dict(state='SEALED_EXACT' if sealed and error is None else 'UNSEALED_UNKNOWN_TAIL',known_durable_submitted_prefix=prefix,
        exact_total=prefix if sealed and error is None else None,exact_tail='KNOWN' if sealed and error is None else 'UNKNOWN',events=seq,last_chain=chain,error_type=error)
