"""Artificial native Evergreen vector backend and explicit output adapters.

No upstream file/statistical kernel or private Shuffle permutation is modified.
The imported physical_vector module supplies pure contracts/cache only; its PPR
class, sampler and executor are never called by these routes.
"""
from __future__ import annotations
from fractions import Fraction as Q
from pathlib import Path
from math import nextafter, inf, ceil, floor, isfinite
from hashlib import sha256
import os,re,sys,random
import external_contract as v

ROOT=Path(__file__).resolve().parent
UP=ROOT.parent/'evergreen_contract_adapter_candidate/upstream/src'
sys.dont_write_bytecode=True
sys.path.insert(0,str(UP))
os.environ['EVERGREEN_CACHE_DIR_ROOT']=str(ROOT/'native_cache_unused')
from evergreen import SessionContext,col,prompt,proportion,count_if
from evergreen.catalog.schema import Schema,Field
from evergreen.storage.row import Row
from evergreen.model.language_model import LanguageModel,LanguageModelMetrics
from evergreen.model.embedding_model import EmbeddingModel
from evergreen.model.config import ModelConfig
from evergreen.estimator import ConfSeqEstimator


class CommonPrefixUnsupported(ValueError):pass


def confidence(alpha,groups=1):
    """Only outward float parameter rounding; native group split stays native."""
    c=nextafter(1.0-float(alpha),1.0)
    while 0<c<1:
        effective=Q.from_float(1.0-float(1.0-(1.0-c)/groups))*groups
        if effective<=alpha:return c
        c=nextafter(c,1.0)
    raise ValueError('native float risk unavailable')


def count_domain(lower,upper,N,s,n,previous):
    # Same one-ULP API readout as pinned scalar adapter, no kernel replacement.
    if not isfinite(lower) or not isfinite(upper):raise ValueError('nonfinite native CI')
    lo=max(s,previous[0],ceil(Q.from_float(nextafter(float(lower),-inf))*N))
    hi=min(s+N-n,previous[1],floor(Q.from_float(nextafter(float(upper),inf))*N))
    if lo>hi:raise ValueError('empty sticky native count domain')
    return lo,hi


def transport_reference(operator):
    return sha256(repr((operator.snapshot,operator.version,operator.modes)).encode()).hexdigest()


def _field(p,name):
    body=p.rsplit('<field_values>',1)[1].split('</field_values>',1)[0]
    found=re.findall(r'<'+name+r'(?:\s[^>]*)?>\n(.*?)\n</'+name+r'>',body,re.S)
    if len(found)!=1:raise ValueError('native mock transport binding')
    return found[0]


class VectorProjectionModel(LanguageModel):
    def __init__(self,cache,query):
        super().__init__('fixed-artificial-vector',None)
        self.cache=cache;self.query=query;self.events=[];self._metrics=LanguageModelMetrics('fixed-artificial-vector')
    def metrics(self):return (self._metrics.copy(),)
    def clear_metrics(self):self._metrics.clear()
    def _project(self,p,mode=None):
        instructions=p.rsplit('<field_values>',1)[0]
        refs=re.findall(r'FIXED_REF=([A-Za-z0-9_-]+)',instructions)
        ms=re.findall(r'VECTOR_MODE=(\d+)',instructions)
        if not refs or set(refs)!={transport_reference(self.cache.operator)} or not ms:raise ValueError('operator/mode prompt binding')
        if mode is None:
            if len(set(ms))!=1:raise ValueError('ambiguous mode projection')
            mode=int(ms[0])
        if not 0<=mode<len(self.cache.operator.modes):raise ValueError('mode schema mismatch')
        rid,content,logical=(_field(p,k) for k in ('rid','text','logical_id'))
        batch=self.cache.fetch_batch([v.Record(rid,content)],'formal')
        if batch.failed or len(batch.vectors)!=1:raise ValueError('vector backend failure')
        value=batch.vectors[0][1][mode]
        self.events.append({'query':self.query,'mode':mode,'rid':rid,'logical_id':logical,'physical_new_attempts':batch.new_attempts,'cache_hit':batch.new_attempts==0})
        self._metrics.prompt_count+=1;self._metrics.prompt_cache_hit_count+=int(batch.new_attempts==0)
        return bool(value)
    def prompt(self,prompt_strs,return_type,schema=None,json_schema=None):
        if return_type is not bool:raise ValueError('binary projections only')
        # Sequential physical vector submissions: unsubmitted tail is not charged.
        return [self._project(p) for p in prompt_strs]
    def fused_prompt(self,prompt_strs,return_types,schema=None,json_schema=None):
        if any(t is not bool for t in return_types):raise ValueError('binary fusion only')
        out=[]
        for p in prompt_strs:
            modes=[int(x) for x in re.findall(r'VECTOR_MODE=(\d+)',p.rsplit('<field_values>',1)[0])]
            if len(modes)!=len(return_types):raise ValueError('fused mode/schema mismatch')
            out.append(tuple(self._project(p,m) for m in modes))
        return out
    def prompt_with_schema(self,*a,**k):raise RuntimeError('model/API disabled')
    def prompt_without_schema(self,*a,**k):raise RuntimeError('model/API disabled')


class NoEmbedding(EmbeddingModel):
    def __init__(self):super().__init__('disabled-vector-scope',None)
    def metrics(self):return ()
    def clear_metrics(self):pass
    def embed(self,*a,**k):raise RuntimeError('embedding disabled')
    def embed_batch(self,*a,**k):raise RuntimeError('embedding disabled')


class ModelConfigAdapter(ModelConfig):
    def __init__(self,model):self.model=model
    def create_language_model(self,cache_dir):return self.model
    def create_embedding_model(self,cache_dir):return NoEmbedding()
    def create_optimizer_language_model(self,cache_dir):return self.model


def context(cache,query,seed,alpha,batch,group_count=1):
    model=VectorProjectionModel(cache,query);ctx=SessionContext()
    ctx.enable_batching(batch);ctx.enable_fusion();ctx.enable_minimal_provenance();ctx.enable_early_stop()
    ctx.enable_estimation(confidence_level=confidence(alpha,group_count),relative_error=0.05,random_seed=seed)
    ctx.enable_cache('artificial-vector-no-pickle');ctx.register_model_config(ModelConfigAdapter(model))
    return ctx,model


def walk(plan):
    yield plan
    for p in plan.inputs():yield from walk(p)


def plan(ctx,rows,schema,mode,grouped,reference):
    p=f'FIXED_REF={reference}; VECTOR_MODE={mode}; record {{rid}}, content {{text}}, tuple {{logical_id}}. Return this component of the fixed vector.'
    df=ctx.read_rows(rows,schema).map(prompt(p,bool).alias('label'))
    df=df.aggregate([count_if(col('label')).alias('count')],group_by=[col('cohort')]) if grouped else df.aggregate([proportion(col('label')).alias('rate')])
    st=ctx.session_state();logical=st.optimize_logical_plan(df.logical_plan());physical=st.create_physical_plan(logical)
    return df,physical,list(walk(physical))


def shuffle_order(nodes):
    sh=[p for p in nodes if type(p).__name__=='Shuffle']
    if len(sh)!=1 or sh[0]._shuffled_rows is None:raise CommonPrefixUnsupported('one materialized native Shuffle required')
    obj=sh[0];idx=obj.schema().index_of('rid')
    return tuple(str(r[idx]) for r in obj._shuffled_rows)


def require_common_permutations(orders):
    if not orders or len(set(orders))!=1:raise CommonPrefixUnsupported('native mode permutations differ; no private order replacement allowed')
    return orders[0]


def output(req,compiled,domains):
    bounds={}
    for i,e in enumerate(compiled.expressions):
        lo=hi=e.beta
        for k,a in e.terms:
            L,U=domains[k];lo+=a*(L if a>=0 else U);hi+=a*(U if a>=0 else L)
        bounds[i]=(lo,hi)
    checked=v.evaluate(compiled.family,bounds);v.verify(compiled.family,bounds,checked)
    sets=dict(compiled.rank_sets);decisions=[]
    for name,d in zip(compiled.names,checked['decisions']):
        d=dict(d);d['name']=name
        if compiled.family.decision_types[d['decision']]=='topk':d['selected']=sets.get(d['positive_certificate']) if d['value'] is True else None
        decisions.append(d)
    return checked['complete'],decisions


def _begin(req,cache):
    compiled=v.compile_request(req);rows=tuple(r for g in req.groups for r in g.records)
    cache.begin(req.operator,rows,req.budget)
    domains={k:(0,len(next(g for g in req.groups if g.gid==k[0]).records)) for k in compiled.active}
    return compiled,domains


class NativeExactVector:
    """Unchanged native grouped aggregate; wrapper is explicitly new/exact."""
    def run(self,req,cache,*,seed=101,batch=2,observer=None):
        compiled,domains=_begin(req,cache);traces=[];error=None
        modes=[m for m in req.operator.modes if any(k[1]==m for k in compiled.active)]
        schema=Schema((Field('logical_id',str),Field('rid',str),Field('text',str),Field('cohort',str)),('logical_id',))
        try:
            for mode_name in modes:
                mode=req.operator.modes.index(mode_name);gs=[g for g in req.groups if (g.gid,mode_name) in compiled.active]
                ctx,model=context(cache,'exact:'+mode_name,seed,req.alpha/len(modes),batch,len(gs))
                rows=[Row((r.rid,r.rid,r.content,g.gid)) for g in gs for r in g.records]
                df,p,nodes=plan(ctx,rows,schema,mode,True,transport_reference(req.operator));native=[]
                try:
                    p.open()
                    while (row:=p.next()) is not None:native.append(row)
                    for row in native:
                        gid=str(row[df.schema().index_of('cohort')]);count=row[df.schema().index_of('count')]
                        if type(count) is not int:raise ValueError('native exact aggregate must emit integer counts')
                        domains[(gid,mode_name)]=(count,count)
                    if len(native)!=len(gs):raise ValueError('incomplete native grouped output')
                    actual=Q.from_float(1.0-p._accumulators[0]._confidence_level)
                    if p._count_provider is None or p._count_provider.group_count(group_prefix=(),group_key_length=1)!=len(gs) or actual*len(gs)>req.alpha/len(modes):raise ValueError('native grouped allocation unavailable/overspent')
                    order=shuffle_order(nodes)
                    traces.append({'mode':mode_name,'plan_types':[type(x).__name__ for x in nodes],'permutation':order,'projections':model.events,'exact_group_counts':{str(row[df.schema().index_of('cohort')]):row[df.schema().index_of('count')] for row in native},'native_operator_confidence':p._confidence_level,'actual_group_alpha':str(Q.from_float(1.0-p._accumulators[0]._confidence_level))})
                    if observer is not None:observer('native_exact_mode',{'counts':domains,'mode_queries_completed':len(traces)},output(req,compiled,domains))
                finally:p.close()
            # Canonical full scans also retain, rather than assume, mode coupling.
            for g in req.groups:
                orders=[tuple(r for r in t['permutation'] if r in {x.rid for x in g.records}) for t in traces if (g.gid,t['mode']) in compiled.active]
                if orders:require_common_permutations(orders)
        except Exception as exc:error={'type':type(exc).__name__,'message':str(exc)}
        complete,decisions=output(req,compiled,domains)
        actual_sum=sum((Q(t['actual_group_alpha'])*len(t['exact_group_counts']) for t in traces),Q(0))
        if actual_sum>req.alpha:error={'type':'RiskOverspend','message':'actual native group risk sum above request'}
        return {'actual_native_risk_sum':str(actual_sum),'scope':'artificial','route':'unchanged_native_exact_aggregates_with_complete_output_wrapper','canonical_native_aggregate_execution':True,'progressive':False,'eligible_complete':complete and error is None,'decisions':decisions,'error':error,'traces':traces,'cost':cache.finish(),'statistical_early_stopping_used':False,'real_benchmark_ready':False}


class Cursor:
    def __init__(self,req,cache,g,mode,alpha,seed,batch):
        self.g=g;self.mode=mode;self.mode_name=req.operator.modes[mode];self.cache=cache;self.N=len(g.records);self.n=0;self.domain=(0,self.N);self.cs_calls=[];self.seed=seed
        self.ctx,self.model=context(cache,g.gid+':'+self.mode_name,seed,alpha,batch);self.ctx._vector_ref=req.operator.version
        schema=Schema((Field('logical_id',str),Field('rid',str),Field('text',str)),('logical_id',))
        rows=[Row((r.rid,r.rid,r.content)) for r in g.records]
        _,self.p,self.nodes=plan(self.ctx,rows,schema,mode,False,transport_reference(req.operator))
        if type(self.p).__name__!='StreamAggregate':raise CommonPrefixUnsupported('native root not StreamAggregate')
        self.opened=False;self.alpha=alpha
    def prime(self):
        self.p.open();self.opened=True;self.pending=self.p._input.next()
        self.p._accumulators=self.p._create_accumulators()
        if len(self.p._accumulators)!=1:raise ValueError('one native accumulator per group/mode')
        self.a=self.p._accumulators[0]
        if self.a._precomputed_total!=self.N or self.a._confidence_level is None:raise ValueError('native known-N/risk unavailable')
        self.actual_alpha=Q.from_float(1.0-self.a._confidence_level)
        if self.actual_alpha>self.alpha:raise ValueError('native effective risk overspend')
        self.order=shuffle_order(self.nodes)
        if len(self.order)!=self.N or set(self.order)!={r.rid for r in self.g.records}:raise CommonPrefixUnsupported('invalid actual native permutation')
        expected=[r.rid for r in self.g.records];random.Random(self.seed).shuffle(expected)
        if self.order!=tuple(expected):raise CommonPrefixUnsupported('public input order not preserved through native seeded Shuffle; uniform-composition premise UNKNOWN')
        self.public_seed_order_verified=True
    def advance(self):
        row=self.pending if self.n==0 else self.p._input.next()
        if row is None or str(row[self.p._input.schema().index_of('rid')])!=self.order[self.n]:raise CommonPrefixUnsupported('not native common prefix')
        self.p._update_accumulators(row);self.n+=1
        if self.n==self.N:
            lo=hi=self.a._count
            if not self.domain[0]<=lo<=self.domain[1]:raise ValueError('census conflicts with previous native interval')
            self.domain=(lo,hi)
        else:
            ci=ConfSeqEstimator.estimate_mean(self.a._observations,self.a._confidence_level,self.a._relative_error,self.N)
            self.domain=count_domain(ci.lower,ci.upper,self.N,self.a._count,self.n,self.domain)
            self.cs_calls.append({'n':self.n,'native_ci':(ci.lower,ci.upper),'domain':self.domain,'actual_alpha':str(self.actual_alpha),'grid':ConfSeqEstimator._BREAKS})
        expected=[bool(self.cache._cache[self.cache._key(next(r for r in self.g.records if r.rid==rid))][self.mode]) for rid in self.order[:self.n]]
        if self.a._observations!=expected:raise CommonPrefixUnsupported('native accumulator observation order mismatch')
    def close(self):
        if self.opened:self.p.close()
    def audit(self):
        return {'group':self.g.gid,'mode':self.mode_name,'n':self.n,'native_permutation':getattr(self,'order',None),'public_input_order':tuple(r.rid for r in self.g.records),'public_seed':self.seed,'public_seed_order_verified':getattr(self,'public_seed_order_verified',False),'native_observations':list(getattr(self,'a',object())._observations) if hasattr(self,'a') else [],'actual_alpha':str(self.actual_alpha) if hasattr(self,'actual_alpha') else None,'projections':self.model.events,'cs_calls':self.cs_calls,'domain':self.domain,'plan_types':[type(x).__name__ for x in self.nodes]}


class ProgressiveNativeVector:
    """New lockstep wrapper around unchanged native Shuffle/input/CS/accumulators."""
    def run(self,req,cache,*,group_seeds=None,batch=2,observer=None,force_full_profile=False):
        compiled,domains=_begin(req,cache);cursors=[];error=None;history=[];risk=Q(0)
        seeds=dict(group_seeds or ((g.gid,101+i) for i,g in enumerate(req.groups)))
        try:
            if set(seeds)!={g.gid for g in req.groups}:raise ValueError('one frozen native seed per physical group')
            assigned=req.alpha/max(1,len(compiled.active))
            for g in req.groups:
                gs=[]
                for mi,m in enumerate(req.operator.modes):
                    if (g.gid,m) not in compiled.active:continue
                    c=Cursor(req,cache,g,mi,assigned,seeds[g.gid],batch);cursors.append(c);gs.append(c);c.prime()
                if gs:require_common_permutations([c.order for c in gs])
            risk=sum((c.actual_alpha for c in cursors),Q(0))
            if risk>req.alpha:raise ValueError('actual active-stream float risk sum overspends request')
            complete,_=output(req,compiled,domains)
            while force_full_profile or not complete:
                advanced=False
                for g in req.groups:
                    gs=[c for c in cursors if c.g.gid==g.gid]
                    if not gs or gs[0].n==gs[0].N:continue
                    for c in gs:c.advance();domains[(g.gid,c.mode_name)]=c.domain
                    if len({c.n for c in gs})!=1:raise CommonPrefixUnsupported('mode statistical prefixes differ')
                    advanced=True;complete,_=output(req,compiled,domains);history.append({'group':g.gid,'common_prefix':gs[0].n,'mode_prefixes':tuple(c.n for c in gs)})
                    if observer is not None:observer('native_common_prefix',{'groups':tuple((g.gid,tuple(c.n for c in cursors if c.g.gid==g.gid)) for g in req.groups),'domains':domains,'actual_risk_sum':risk},output(req,compiled,domains))
                    if complete and not force_full_profile:break
                if not advanced:break
        except Exception as exc:error={'type':type(exc).__name__,'message':str(exc)}
        finally:
            for c in cursors:c.close()
        complete,decisions=output(req,compiled,domains)
        return {'scope':'artificial','route':'progressive_native_common_physical_prefix_adapter','canonical_native_aggregate_execution':False,'native_kernel_and_shuffle_unchanged':True,'native_private_permutation_replaced':False,'eligible_complete':complete and error is None,'decisions':decisions,'error':error,'traces':[c.audit() for c in cursors],'history':history,'active_streams':len(compiled.active),'actual_native_risk_sum':str(risk),'request_alpha':str(req.alpha),'cost':cache.finish(),'real_benchmark_ready':False}
