"""Typed N300 contract from pinned common bridge; no new statistical kernel."""
from core import *
