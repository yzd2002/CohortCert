"""Tiny lifecycle fake, not a local/native/SSS implementation or data loader."""
from pathlib import Path
import argparse,os,time
from charges import FeeJournal
from io_utils import atomic_json,file_hash,fsync_dir,load_json
ROOT=Path(__file__).resolve().parent
def birth(pid):
    if type(pid) is not int or pid<=0 or pid==15744:raise ValueError('invalid or protected PID')
    raw=Path(f'/proc/{pid}/stat').read_text();return raw[raw.rfind(')')+2:].split()[19]

def run(outdir,admission_sha):
    outdir=Path(outdir).resolve()
    if not outdir.is_relative_to(ROOT/'artificial_runs'):raise ValueError('fake output only')
    if file_hash(outdir/'ADMISSION.json')!=admission_sha:raise ValueError('admission hash')
    a=load_json(outdir/'ADMISSION.json');run=a['run'];context=a['context'];start=birth(os.getpid())
    if a['scope']!='ARTIFICIAL_ONLY':raise ValueError('fake never accepts actual data')
    atomic_json(outdir/'WORKER_STARTED.json',dict(pid=os.getpid(),starttime=start,run_id=run['run_id'],context=context))
    deadline=time.monotonic()+a['limits']['wall_seconds']
    while not (outdir/'GO.json').exists():
        if time.monotonic()>deadline:raise TimeoutError('unreleased fake startup')
        time.sleep(0.003)
    go=load_json(outdir/'GO.json')
    if go!=dict(context=context,run_id=run['run_id'],child_starttime=start,parent_pid=a['parent_pid'],parent_birth=a['parent_birth']) or birth(a['parent_pid'])!=a['parent_birth']:raise ValueError('GO owner mismatch')
    fee=FeeJournal(outdir/'FEE_JOURNAL.ndjson',context,run['run_id']);scenario=a['scenario']
    if scenario=='hang_after5':
        fee.append('SUBMITTED',5)
        while True:time.sleep(0.05)
    failed=scenario=='closed_failure'
    def provider(i):
        if failed:raise RuntimeError('artificial backend failure')
        return b'artificial whole vector, no labels or inference'
    fee.acquire(5 if failed else 1,provider);fee.seal()
    private=outdir/'private';private.mkdir()
    packet=private/'OPAQUE.bin'
    with packet.open('xb') as f:
        f.write(b'FAKE_PRIVATE_RESULT_NOT_A_METHOD_ANSWER\n');f.flush();os.fsync(f.fileno())
    fsync_dir(private)
    status='FAILED_CLOSED' if failed else 'NORMAL_CLOSED'
    summary=dict(schema='fake-worker-admin-summary/v1',context=context,run=run,status=status,physical_attempts=fee.total,
        fee_chain=fee.chain,packet=dict(path='private/OPAQUE.bin',bytes=packet.stat().st_size,sha256=file_hash(packet)),scientific_success='UNKNOWN')
    if scenario=='partial_summary':
        with (outdir/'ADMIN_SUMMARY.json').open('xb') as f:f.write(b'{partial');f.flush();os.fsync(f.fileno())
    else:atomic_json(outdir/'ADMIN_SUMMARY.json',summary)
    atomic_json(outdir/'WORKER_CLOSED.json',dict(context=context,run=run,status=status,physical_attempts=fee.total,fee_chain=fee.chain,summary_sha256=file_hash(outdir/'ADMIN_SUMMARY.json')))
    print('{"administrative_state":"FAKE_WORKER_EXIT","private_results_decoded":false}',flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--outdir',required=True);p.add_argument('--admission-sha',required=True);args=p.parse_args();run(args.outdir,args.admission_sha)
