"""Authority/accounting wrapper around the seven frozen pure algorithms."""
from hashlib import sha256
from io_utils import object_hash
from contract import METHODS

def route_plan(method):
    if method not in METHODS:raise ValueError('selector not separately registered/frozen')
    if method in METHODS[:3]:return dict(module='core',call='execute',policy=method,physical='pilot prepaid5/formal1',prior='exact_paid_pilot',risk='42x1/840')
    if method==METHODS[3]:return dict(module='native_routes',call='NativeExactVector.run',seed=101,batch=2,physical='serial singleton fresh vector dispatch')
    if method==METHODS[4]:return dict(module='native_routes',call='ProgressiveNativeVector.run',group_seeds=dict(A=101,B=102,C=103),batch=2,physical='serial singleton fresh vector dispatch')
    if method==METHODS[5]:return dict(module='sss_routes',call='run',profile='kelly_wor_plugin',batch_size=1,selector='round_robin',physical='original fullN rho; no discarded pilot')
    return dict(module='sss_common_loggreedy',call='run',profile='kelly_wor_plugin',batch_size=1,
        selector='common_log_evidence_greedy',log_floor=-64,initialization='ABC_one_each',
        predictor='Beta(1+s,1+n-s)',physical='original fullN rho; no discarded pilot')

def prepare_route(method,outdir):
    """Import code before actual map I/O, with native cache confined to the slot.

    Evergreen's cache constant is read at import. Configure it before the
    unchanged native wrapper imports Evergreen; no estimator is patched.
    """
    route_plan(method)
    import importlib,os,sys
    from pathlib import Path
    if method in METHODS[:3]:return importlib.import_module('core')
    if method==METHODS[5]:return importlib.import_module('sss_routes')
    if method==METHODS[6]:return importlib.import_module('sss_common_loggreedy')
    root=Path(__file__).resolve().parent
    cache=Path(outdir)/'private/native_cache';cache.mkdir(parents=True,exist_ok=True)
    os.environ['EVERGREEN_CACHE_DIR_ROOT']=str(cache)
    upstream=root.parent/'evergreen_contract_adapter_candidate/upstream/src'
    if str(upstream) not in sys.path:sys.path.insert(0,str(upstream))
    importlib.import_module('evergreen')
    module=importlib.import_module('native_routes')
    os.environ['EVERGREEN_CACHE_DIR_ROOT']=str(cache)
    from evergreen.common.constants import CACHE_DIR_ROOT
    if Path(CACHE_DIR_ROOT).resolve()!=cache.resolve():raise ValueError('native cache constant not confined to current cold slot')
    return module

def dispatch(request,config,cache,method,ranks,observer):
    """No input loading, no scope coercion, no algorithm monkeypatching."""
    spec=route_plan(method)
    if request.scope not in ('artificial','actual_bound'):raise ValueError('explicit request scope')
    if method in METHODS[:3]:
        import core
        from policies import VectorPolicy
        result=core.execute(request,config,cache,VectorPolicy(method,request.operator.modes),observer)
    else:
        from execution_bridge import compose_rho,NativePhysicalFacade
        ordered=compose_rho(request,ranks)
        if ordered.scope!=request.scope:raise AssertionError('scope changed while composing rho')
        if method==METHODS[3]:
            from native_routes import NativeExactVector
            result=NativeExactVector().run(ordered,NativePhysicalFacade(cache),seed=101,batch=2,observer=observer)
        elif method==METHODS[4]:
            from native_routes import ProgressiveNativeVector
            result=ProgressiveNativeVector().run(ordered,NativePhysicalFacade(cache),group_seeds={'A':101,'B':102,'C':103},batch=2,observer=observer)
        elif method==METHODS[5]:
            from sss_routes import run
            result=run(ordered,cache,batch_size=1,stop_on_complete=True,profile='kelly_wor_plugin',observer=observer)
        else:
            from sss_common_loggreedy import run
            result=run(ordered,cache,stop_on_complete=True,observer=observer)
    # Legacy producer reports are metadata, never an authority/scope conversion.
    legacy={k:result[k] for k in ('scope','real_bridge_ready','real_benchmark_ready','production_bridge_ready','proof_cost_optimizer_ready') if k in result}
    result={k:v for k,v in result.items() if k not in legacy}
    return dict(authoritative_request_scope=request.scope,method_id=method,route_spec=spec,result=result,legacy_report_metadata=legacy,
        authority_note='Outer admitted scope governs. Unchanged pure modules retain historical report literals; no actual Request became artificial.')
