"""Cold-vector charging with durable batches and private returned-vector tape."""
from core import ArtificialVectorCache,BatchResult
from codec import Journal,fee_accounting

class DurableVectorCache(ArtificialVectorCache):
    def __init__(self,operator,records,vector_operator,outdir,run_id,*,scope='artificial',cache_scope='cold_request'):
        super().__init__(operator,records,vector_operator,scope=scope,cache_scope=cache_scope)
        self.fee=Journal(outdir/'FEE_JOURNAL.ndjson',run_id)
        self.observed=Journal(outdir/'private'/'RETURNED_VECTORS.ndjson',run_id)
        self.run_id=run_id;self.cost_sealed=False
    @property
    def spent(self):return self._session['spent'] if self._session else self.totals()['physical_attempts']
    def fetch_batch(self,records,phase):
        if self._session is None:raise ValueError('no active request')
        if phase not in ('pilot','prefetch','formal','census','materialization'):raise ValueError('unknown phase')
        if len({r.rid for r in records})!=len(records):raise ValueError('duplicate batch RID')
        keys=[self._key(r) for r in records];fresh=[k not in self._cache for k in keys];cost=sum(fresh)
        if cost>self.remaining:raise ValueError('unsubmitted batch exceeds budget')
        ei=len(self.events)
        self.fee.append('SUBMITTED_BATCH',batch=ei,session=self._session['id'],phase=phase,
            rids=[r.rid for r in records],fresh=fresh,physical_attempts=cost,
            operator_snapshot=self.operator.snapshot,operator_version=self.operator.version,ordered_modes=self.operator.modes)
        self._session['spent']+=cost
        event=dict(session=self._session['id'],phase=phase,rids=tuple(r.rid for r in records),submitted_physical_attempts=cost,
            cache_hits=len(records)-cost,statuses=['SUBMITTED' if f else 'CACHE_HIT_PENDING' for f in fresh])
        self.events.append(event);vectors=[];failed=False
        for i,(r,k) in enumerate(zip(records,keys)):
            if failed:
                event['statuses'][i]='UNEXECUTED_CHARGED' if fresh[i] else 'UNCONSUMED_CACHE_HIT';continue
            try:
                if fresh[i]:
                    raw=self._fn(r.rid,r.content)
                    if type(raw) is not tuple or len(raw)!=len(self.operator.modes) or any(type(y) is not int or y not in (0,1) for y in raw):raise ValueError('invalid complete vector')
                    self._cache[k]=raw
                value=self._cache[k]
                self.observed.append('OBSERVED_VECTOR',rid=r.rid,content_identity=r.content,ordered_modes=self.operator.modes,values=value)
                self.fee.append('RETURNED_VECTOR',batch=ei,rid=r.rid,cache_hit=not fresh[i],private_observation_seq=self.observed.seq-1)
                vectors.append((r.rid,value));event['statuses'][i]='SUCCESS' if fresh[i] else 'CACHE_HIT'
            except Exception as exc:
                event['statuses'][i]='FAILED';event['error_type']=type(exc).__name__;failed=True
                self.fee.append('FAILED_VECTOR',batch=ei,rid=r.rid,error_type=type(exc).__name__)
        event['failed']=failed
        self.fee.append('BATCH_CLOSED',batch=ei,statuses=event['statuses'],failed=failed)
        return BatchResult(tuple(vectors),failed,cost,ei)
    def finish(self):
        result=super().finish()
        self.fee.append('SESSION_CLOSED',physical_attempts=result['spent'])
        return result
    def seal_cost(self):
        if self._session is not None:raise ValueError('active cache session cannot seal')
        self.fee.append('COST_SEALED',physical_attempts=self.totals()['physical_attempts'])
        self.cost_sealed=True
        return fee_accounting(self.fee.path)
    def close(self):self.fee.close();self.observed.close()
