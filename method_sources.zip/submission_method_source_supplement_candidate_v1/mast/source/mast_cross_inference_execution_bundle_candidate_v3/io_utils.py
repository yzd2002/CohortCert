"""Bounded administrative I/O. Never interprets private result bytes."""
from hashlib import sha256
from pathlib import Path
import json,os,stat

def canonical(x):return (json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()
def object_hash(x):return sha256(canonical(x)).hexdigest()
def fsync_dir(path):
    fd=os.open(path,os.O_RDONLY|os.O_DIRECTORY)
    try:os.fsync(fd)
    finally:os.close(fd)
def atomic_json(path,x):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_name(path.name+'.partial')
    with tmp.open('xb') as f:f.write(canonical(x));f.flush();os.fsync(f.fileno())
    os.replace(tmp,path);fsync_dir(path.parent)
def load_json(path,cap=262144):
    with Path(path).open('rb') as f:
        b=f.read(cap+1)
    if len(b)>cap:raise ValueError('administrative JSON cap')
    return json.loads(b)
def file_hash(path):
    p=Path(path)
    if p.is_symlink() or not p.is_file():raise ValueError('regular nonsymlink file required')
    h=sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(65536),b''):h.update(b)
    return h.hexdigest()
def inventory(root,exclude=()):
    root=Path(root);out=[]
    for p in sorted(root.rglob('*')):
        rel=p.relative_to(root).as_posix()
        if rel in exclude:continue
        try:s=p.lstat()
        except FileNotFoundError:continue
        if stat.S_ISLNK(s.st_mode):raise ValueError('symlink in archive')
        if stat.S_ISDIR(s.st_mode):continue
        if not stat.S_ISREG(s.st_mode):raise ValueError('nonregular archive entry')
        try:out.append(dict(path=rel,bytes=s.st_size,sha256=file_hash(p)))
        except FileNotFoundError:continue
    return out
def safe_file(root,relative):
    if type(relative) is not str or not relative:raise ValueError('relative file identity')
    root=Path(root).resolve();p=root/relative
    if p.is_symlink() or not p.resolve().is_relative_to(root) or p.relative_to(root).as_posix()!=relative:raise ValueError('archive path escapes root')
    return p
