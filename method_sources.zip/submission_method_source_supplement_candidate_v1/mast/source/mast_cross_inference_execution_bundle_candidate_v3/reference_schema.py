"""Pure saved-vector schema validation. File access belongs to gated worker only."""
from fractions import Fraction as Q
from hashlib import sha256
from types import MappingProxyType
from codec import canonical
from core import Operator,Record,Group,Linear,greater,Request,Config

MODES=('1.1','1.2','1.3','1.4','1.5','2.1','2.2','2.3','2.4','2.5','2.6','3.1','3.2','3.3')
COHORTS=(('A','MetaGPT_ProgramDev2_GPT4o','MetaGPT','GPT-4o'),('B','MetaGPT_ProgramDev2_Claude','MetaGPT','Claude'),('C','ChatDev_ProgramDev2_GPT4o','ChatDev','GPT-4o'))
SOURCE_RECORD_COUNT=1642
COHORT_RECORD_COUNT=100

def _object(x,field):
    if type(x) is not dict:raise ValueError(field+' must be a JSON object')
    return x

def _array(x,field):
    if type(x) is not list:raise ValueError(field+' must be a JSON array')
    return x

def _string(x,field):
    if type(x) is not str or not x:raise ValueError(field+' must be a nonempty string')
    return x

def _digest(x,field):
    _string(x,field)
    if len(x)!=64 or any(c not in '0123456789abcdef' for c in x):raise ValueError(field+' must be a canonical SHA256')
    return x

def _integer(x,lo,hi,field):
    # JSON bool/float values must never alias an integer address or be coerced.
    if type(x) is not int or not lo<=x<hi:raise ValueError(field+' integer type/range')
    return x

def _address(x,field):
    _object(x,field)
    return (_integer(x['trace_index'],0,COHORT_RECORD_COUNT,field+'.trace_index'),
        _integer(x['original_trace_id'],0,COHORT_RECORD_COUNT,field+'.original_trace_id'))

class PrivateProvider:
    __slots__=('__values','__content')
    def __init__(self,values,content):self.__values=MappingProxyType(dict(values));self.__content=MappingProxyType(dict(content))
    def __call__(self,rid,content):
        if self.__content.get(rid)!=content:raise ValueError('provider RID/content binding mismatch')
        return self.__values[rid]

def request_from_groups(groups,operator,budget=300,scope='artificial'):
    decisions=tuple((f'{m}:A>{right}',greater(Linear.make({('A',m):Q(1,100),(right,m):Q(-1,100)}))) for m in MODES for right in ('B','C'))
    return Request(operator,tuple(groups),decisions,Q(1,20),budget,scope=scope)

def fixed_config(pilot_ranks,formal_ranks,*,stop_on_complete=True):
    return Config(tuple((g,5) for g in ('A','B','C')),tuple(sorted(pilot_ranks.items())),tuple(sorted(formal_ranks.items())),
        tuple(((g,m),Q(1,840)) for g in ('A','B','C') for m in MODES),'exact_paid_pilot',(),0,Q(1,2),1,'cold_request',stop_on_complete)

def decode_reference_objects(payload,metadata,contract):
    """No I/O; callers may test this with artificial objects, never actual mode."""
    _object(payload,'payload');_object(metadata,'metadata');_object(contract,'contract')
    for field in ('construction_plan_sha256','source_sha256'):_digest(contract[field],'contract.'+field)
    _string(contract['source_revision'],'contract.source_revision')
    source_bytes=_integer(contract['source_bytes'],1,1<<63,'contract.source_bytes')
    for field in ('locked_vector_artifact','record_identity_artifact'):
        _digest(_object(contract[field],'contract.'+field)['sha256'],'contract.'+field+'.sha256')
    for obj,field in ((payload,'payload'),(metadata,'metadata')):
        _string(obj['schema'],field+'.schema')
        _digest(obj['construction_plan_sha256'],field+'.construction_plan_sha256')
    dataset=_object(payload['dataset'],'payload.dataset')
    _string(dataset['revision'],'payload.dataset.revision');_digest(dataset['sha256'],'payload.dataset.sha256')
    _integer(dataset['bytes'],1,1<<63,'payload.dataset.bytes')
    _digest(metadata['dataset_sha256'],'metadata.dataset_sha256');_digest(payload['metadata_sha256'],'payload.metadata_sha256')
    mode_ids=_array(payload['mode_ids'],'payload.mode_ids')
    for mode in mode_ids:_string(mode,'payload.mode_ids entry')
    frames=_object(metadata['frames'],'metadata.frames')
    for gid in frames:_string(gid,'metadata.frames key')
    payload_groups=_array(payload['groups'],'payload.groups')
    for g in payload_groups:
        _object(g,'payload.groups entry');_string(g['id'],'payload group id');_string(g['exact_trace_key'],'payload group key')
    if payload.get('schema')!='fixed-release-whole-vector-labelmap/v1' or metadata.get('schema')!='fixed-release-independent-record-identities/v1':raise ValueError('reference schema')
    if payload['construction_plan_sha256']!=contract['construction_plan_sha256'] or metadata['construction_plan_sha256']!=contract['construction_plan_sha256']:raise ValueError('construction binding')
    if tuple(payload['mode_ids'])!=MODES or payload['dataset']!=dict(revision=contract['source_revision'],sha256=contract['source_sha256'],bytes=contract['source_bytes']):raise ValueError('snapshot or ordered mode schema')
    if metadata['dataset_sha256']!=contract['source_sha256'] or set(metadata['frames'])!={'A','B','C'}:raise ValueError('record metadata binding')
    if payload['metadata_sha256']!=contract['record_identity_artifact']['sha256']:raise ValueError('independent record file digest binding')
    if [g['id'] for g in payload['groups']]!=['A','B','C']:raise ValueError('cohort order')
    values={};content={};groups=[];seen_source=set()
    for gid,key,mas,llm in COHORTS:
        g=next(g for g in payload['groups'] if g['id']==gid);rows=_array(g['rows'],'vector rows');mr=_array(metadata['frames'][gid],'metadata rows')
        if g['exact_trace_key']!=key or len(rows)!=100 or len(mr)!=100:raise ValueError('complete exact namespace required')
        byaddr={}
        for x in mr:
            a=_address(x,'metadata row')
            _string(x['exact_trace_key'],'metadata row key')
            raw=_object(x['metadata'],'metadata raw header')
            for field in ('mas_name','llm_name','benchmark_name'):_string(raw[field],'metadata raw header.'+field)
            if x['metadata']!=dict(mas_name=mas,llm_name=llm,benchmark_name='ProgramDev') or x['exact_trace_key']!=key:raise ValueError('raw header mismatch')
            _integer(x['source_array_index'],0,SOURCE_RECORD_COUNT,'metadata source_array_index')
            if type(x['trace_index_type']) is not str or x['trace_index_type']!='int' or type(x['trace_id_type']) is not str or x['trace_id_type']!='int':raise ValueError('metadata ordinal type tag')
            start=_integer(x['source_start_byte'],0,source_bytes,'metadata source_start_byte')
            _integer(x['source_end_byte'],start+1,source_bytes+1,'metadata source_end_byte')
            if a in byaddr or x['source_array_index'] in seen_source:raise ValueError('duplicate record identity')
            _digest(x['whole_record_sha256'],'metadata whole_record_sha256')
            byaddr[a]=x;seen_source.add(x['source_array_index'])
        if len({x['trace_index'] for x in mr})!=100 or len({x['original_trace_id'] for x in mr})!=100:raise ValueError('nonunique ordinals within key')
        records=[];seen=set()
        for x in rows:
            a=_address(x,'vector row')
            if a in seen or a not in byaddr:raise ValueError('vector address mismatch')
            seen.add(a);bits=x['values']
            if type(bits) is not list or len(bits)!=14 or any(type(v) is not int or v not in (0,1) for v in bits):raise ValueError('whole binary vector required')
            source=byaddr[a]
            identity=dict(dataset=contract['source_sha256'],key=key,index=a[0],trace_id=a[1],source_index=source['source_array_index'])
            rid=sha256(canonical(identity)).hexdigest();ct=sha256(canonical(dict(identity,source_record=source['whole_record_sha256']))).hexdigest()
            if rid in values:raise ValueError('global physical RID collision')
            values[rid]=tuple(bits);content[rid]=ct;records.append((a,Record(rid,ct)))
        groups.append(Group(gid,tuple(r for _,r in sorted(records))))
    if len(values)!=300:raise ValueError('whole300 record frame required')
    op=Operator(contract['source_sha256']+'|'+contract['locked_vector_artifact']['sha256']+'|'+contract['record_identity_artifact']['sha256'],'fixed-released-judge-vector/v1',MODES)
    return tuple(groups),op,PrivateProvider(values,content)
