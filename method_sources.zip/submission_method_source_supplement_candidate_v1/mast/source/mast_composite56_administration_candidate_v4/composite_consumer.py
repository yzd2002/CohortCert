"""Recursive public/opaque gate; original source rows are never relabelled.

Copy this file, composite_primitives.py, isolated_c3.py, frozen_bindings.py and
codec.py into the auditor closure. Canonical C3 is called only in a clean process;
no actual entropy reader, scientific decoder, method, or launch operation exists.
"""
from pathlib import Path
from hashlib import sha256
from copy import deepcopy
import json,shutil,stat
import composite_primitives as retained

BASE=Path(__file__).resolve().parent.parent
from frozen_bindings import PLAN_SHA,PROOF_SHA,RETAINED_REFS_SHA,RETAINED_CONSUMER_SHA
SCIENCE_SHA=retained.SCIENCE_SHA
ENTROPY_SHA=retained.ENTROPY_SHA
COMMON_REFS=('composite_protocol','composite_ready','implementation_manifest','implementation_closure',
             'retained_composite_refs','new_source_permission','new_source_external_seal','new_source_launch_ready')
CONSUMER_REFS=COMMON_REFS+('composite_external_seal','composite_admin_permission')
IMPL_KEYS=retained.IMPL_KEYS
STAT_FILES=retained.STAT_FILES
PROTECTED_NEW17=STAT_FILES+('private_observer.py','private_loader.py','charges.py','external_contract.py')
NotReady=retained.NotReady
EvidenceUnknown=retained.EvidenceUnknown
canonical=retained.canonical
digest=retained.digest
hash_file=retained.hash_file
sha=retained.sha
integer=retained.integer
equal=retained.equal
public_path=retained.public_path
load_public=retained.load_public
read_ref=retained.read_ref
complete_refs=retained.complete_refs
path_inside=retained.path_inside
check_implementation=retained.check_implementation
check_public_closure=retained.check_public_closure
opaque_inventory=retained.opaque_inventory
sample_tree=retained.sample_tree
composite_inventory=retained.composite_inventory

def continuation_bindings(plan):
    old=plan['retained_composite']
    return dict(continuation_plan_sha256=PLAN_SHA,unclaimed_proof_sha256=PROOF_SHA,
        scientific_all56_slots_sha256=digest(plan['all56_runs']),execution_slots_sha256=digest(plan['execution_runs']),
        retained_source_external_seal_sha256=old['external_seal_ref']['sha256'],
        retained_source_admin_permission_sha256=old['admin_permission_ref']['sha256'])

def read_fixed_plan():
    p=BASE/'mast_unclaimed6_continuation_design_v1/CONTINUATION_PLAN.json'
    if hash_file(p)!=PLAN_SHA:raise NotReady('fixed suffix6 design changed')
    plan=load_public(p)
    if plan.get('original_science_sha256')!=SCIENCE_SHA or sha256(plan['original_science_json'].encode()).hexdigest()!=SCIENCE_SHA:raise NotReady('original science bytes changed')
    if plan['unclaimed_proof']['sha256']!=PROOF_SHA or sha256(plan['unclaimed_proof']['public_raw_json'].encode()).hexdigest()!=PROOF_SHA:raise NotReady('independent suffix6 proof changed')
    if not equal(plan['retained_slots'],list(range(50))) or not equal(plan['execution_slots'],list(range(50,56))) or not equal(plan['execution_runs'],plan['all56_runs'][50:]):raise NotReady('fixed50+6 wholecase partition required')
    if digest(plan['all56_runs'])!='8f644a8d7c6c400dd459ab0aecc518f79bb3998ec74fb39c003a750d2ce81305':raise NotReady('literal original56 scientific frame differs')
    for key,value in [('new_execution_root','mast_bound56_unclaimed6_study_v1'),('composite_root','mast_bound56_composite_v3'),('current_authority_root','mast_bound56_unclaimed6_authority_v1')]:
        if plan.get(key)!=str(BASE/value):raise NotReady('canonical suffix6 roots required')
    old=plan['retained_composite']
    if old['root']!=str(BASE/'mast_bound56_composite_v2') or old['consumer_refs']['sha256']!=RETAINED_REFS_SHA or not equal(old['selected_slots'],list(range(50))) or old['no_source_row_or_context_rewrite'] is not True or len(old['whole_case_pointers'])!=50:raise NotReady('exact immutable C3 wholecase prefix50 required')
    entropy=plan['entropy']
    if entropy.get('sha256')!=ENTROPY_SHA or entropy.get('new_OS_study_draws')!=0 or entropy.get('original48_draws_unchanged') is not True or plan.get('new_study_entropy_draws')!=0 or plan.get('original_zero_start_exception_reused') is not False:raise NotReady('original rank identity and no redraw required')
    if plan.get('execution_mode')!='CONTINUATION_UNCLAIMED_SUFFIX6_ORIGINAL_RANKS' or entropy.get('binding_mode')!=plan['execution_mode']:raise NotReady('explicit original-rank suffix6 continuation required')
    if plan.get('started_slots0_to49_never_retry') is not True or plan.get('global49_censor_and_unknown_tail_permanent') is not True or plan.get('historical_all_unrun_rows_preserved') is not True or plan.get('original_entropy_record_copy_resign_or_redraw_allowed') is not False or plan.get('immediate_unclaimed_recheck_under_original_global_lock_required') is not True:raise NotReady('first-execution-only prefix preservation changed')
    validate_storage_scope(plan)
    return plan

def pointer_templates(plan):
    out=deepcopy(plan['retained_composite']['whole_case_pointers'])
    root=Path(plan['new_execution_root'])
    for run in plan['execution_runs']:
        out.append(dict(run=run,source_id='new6',source_root=str(root),slot_root=str(root/'slots'/run['run_id']),row_path=str(root/f'ROW_{run["slot"]:03d}.json'),source_context='LATE_DERIVED_NEW6_CONTEXT',row_sha256='LATE_EXACT_SOURCE_ROW_SHA',whole_case=True))
    return out

def validate_protocol(protocol,ready,plan,hashes):
    if protocol.get('schema')!='fixed56-disjoint-composite-protocol/v2' or protocol.get('status')!='FROZEN_BEFORE_UNCLAIMED6_EXECUTION' or protocol.get('scope')!='ACTUAL_FIXED_RECURSIVE_DISJOINT56':raise NotReady('prospective recursive6 protocol required')
    wanted=continuation_bindings(plan)
    if protocol.get('currentstudy_root')!=plan['new_execution_root'] or 'study_root' in protocol or protocol.get('composite_root')!=plan['composite_root'] or not equal(protocol.get('continuation_bindings'),wanted):raise NotReady('recursive roots/continuation pins differ')
    if protocol.get('final_protocol_sha256')!=protocol.get('current_final_protocol',{}).get('sha256'):raise NotReady('current Final pin required')
    impl=protocol.get('implementation_bindings')
    if type(impl) is not dict or set(impl)!=IMPL_KEYS:raise NotReady('complete recursive implementation bindings required')
    for value in impl.values():sha(value)
    if impl['collector_manifest_sha256']!=hashes['implementation_manifest'] or impl['composite_admin_manifest_sha256']!=hashes['implementation_manifest'] or impl['collector_closure_sha256']!=hashes['implementation_closure'] or impl['composite_admin_closure_sha256']!=hashes['implementation_closure']:raise NotReady('reviewed recursive package differs')
    if ready.get('status')!='READY_FOR_BOUND_DISJOINT56_COMPOSITE' or ready.get('final_protocol_sha256')!=protocol['final_protocol_sha256'] or ready.get('composite_protocol_sha256')!=hashes['composite_protocol'] or not equal(ready.get('continuation_bindings'),wanted) or not equal(ready.get('implementation_bindings'),impl):raise NotReady('independent recursive CompositeReady graph missing')
    if not equal(protocol.get('retained_composite'),plan['retained_composite']):raise NotReady('retained composite/pointers may not be replaced')
    specs=protocol.get('source_specs')
    if type(specs) is not dict or set(specs)!={'new6'}:raise NotReady('new6 is the only direct source specification')
    new=specs['new6'];auth=Path(plan['current_authority_root'])
    if new['root']!=plan['new_execution_root'] or not equal(new['selected_slots'],plan['execution_slots']) or not equal(new['final_protocol_ref'],protocol['current_final_protocol']) or new['context_policy']!='DERIVE_FROM_BOUND_NEW6_LAUNCH_READY':raise NotReady('new6 source/frame/context policy differs')
    if new['external_seal_path']!=plan['new_execution_root']+'.EXTERNAL_SEAL.json' or new['admin_permission_path']!=str(auth/'ALL6_ADMIN_PERMISSION.json') or new['launch_ready_path']!=str(auth/'LAUNCH_READY.json') or protocol['current_final_protocol']['path']!=str(auth/'FINAL_PROTOCOL.json'):raise NotReady('canonical new6 authority/source paths required')
    if not equal(protocol.get('pointer_templates'),pointer_templates(plan)):raise NotReady('retained wholecase or prospective6 pointer changed')
    if not equal(protocol.get('resources'),plan['resource_accounting']):raise NotReady('original cumulative resource policy changed')

def load_retained_composite(ref,plan):
    """Invoke canonical C3 in a clean owned process, never import its consumer."""
    if not equal(ref,plan['retained_composite']['consumer_refs']) or ref['sha256']!=RETAINED_REFS_SHA:raise NotReady('exact frozen C3 ten-ref file required')
    refs=read_ref(ref);complete_refs(refs,CONSUMER_REFS)
    old=plan['retained_composite']
    for key,pinkey in [('composite_external_seal','external_seal_ref'),('composite_admin_permission','admin_permission_ref'),('implementation_manifest','consumer_manifest_ref'),('implementation_closure','consumer_closure_ref')]:
        if not equal(refs[key],old[pinkey]):raise NotReady('canonical retained C3 reference provenance differs')
    from isolated_c3 import load_verified_old
    result=load_verified_old(refs)
    index=read_ref(old['index_ref'])
    if result['composite_root']!=old['root'] or not equal(result['cases'],index['cases']) or not equal(result['sources'],index['sources']) or set(result['sources'])!={'retained','new52','new51'}:raise NotReady('canonical C3 complete source registry differs')
    if len(result['cases'])!=56 or not equal(result['cases'][:50],old['whole_case_pointers']):raise NotReady('any retained wholecase/context/row changed')
    flags=result['source_scientific_credit_allowed']
    if type(flags) is not dict or set(flags)!={'retained','new52','new51'} or any(type(x) is not bool for x in flags.values()):raise NotReady('retained exact per-source eligibility flags required')
    for i in (3,4,49):
        row=result['cases'][i]['source_row'];charge=row['charge']
        if row['status']!='CENSORED_UNKNOWN' or charge.get('exact_total') is not None or charge.get('exact_tail')!='UNKNOWN':raise NotReady('all three original operational censors remain UNKNOWN')
    for case,run in zip(result['cases'][50:],plan['execution_runs']):
        slot=Path(case['slot_root'])
        if not equal(case['run'],run) or case['source_row']['status']!='UNRUN_GLOBAL_STOP' or slot.exists() or slot.is_symlink():raise NotReady('only the original unstarted suffix6 may be replaced')
    return result

def verify_new_source(spec,seal_ref,permission_ref,plan,expected_context):
    """Check all6 public rows and source gates before authorized opaque hashes."""
    root=Path(spec['root']).resolve();seal=read_ref(seal_ref);permission=read_ref(permission_ref);barrier_path=root/'ALL_SLOTS_TERMINAL.json'
    if Path(seal_ref['path']).resolve()!=root.parent/(root.name+'.EXTERNAL_SEAL.json'):raise EvidenceUnknown('canonical external new6 seal required')
    barrier_sha=hash_file(barrier_path);context=seal.get('context')
    if seal.get('schema')!='planned-slots-external-admin-seal/v2' or seal.get('study_root')!=str(root) or seal.get('barrier_sha256')!=barrier_sha or seal.get('private_results_decoded') is not False or context!=expected_context:raise EvidenceUnknown('new6 seal identity/context differs')
    barrier=load_public(barrier_path);runs=plan['execution_runs'];cb=continuation_bindings(plan)
    if barrier.get('schema')!='planned-slots-terminal-admin-barrier/v2' or barrier.get('status')!='ALL_PLANNED_SLOTS_TERMINAL_ADMIN_ONLY' or barrier.get('scope')!='FINAL_BOUND_ACTUAL' or barrier.get('context')!=context or barrier.get('synthetic_assembled') is True or barrier.get('private_results_decoded') is not False or barrier.get('scientific_success')!='UNKNOWN':raise EvidenceUnknown('genuine6 terminal barrier required')
    for obj in (seal,barrier,permission):
        integer(obj['planned_slot_count'],6,6)
        if obj['planned_slots_sha256']!=digest(runs) or not equal(obj.get('continuation_bindings'),cb):raise EvidenceUnknown('new6 complete literal table/continuation binding differs')
    if permission.get('status')!='VERIFIED_ALL_FINAL_6_SLOTS_ADMIN_ONLY' or permission.get('study_root')!=str(root) or permission.get('context')!=context or permission.get('barrier_sha256')!=barrier_sha or permission.get('private_results_decoded') is not False or permission.get('scientific_success')!='UNKNOWN':raise EvidenceUnknown('independent new6 permission required')
    if permission['bindings']['external_seal_sha256']!=seal_ref['sha256'] or permission['bindings']['final_protocol_sha256']!=spec['final_protocol_ref']['sha256'] or permission['bindings']['entropy_sha256']!=ENTROPY_SHA:raise EvidenceUnknown('new6 permission bindings differ')
    final=read_ref(spec['final_protocol_ref']);closure=check_public_closure(spec['worker_manifest_ref'],spec['worker_closure_ref'])
    admin_ready=read_ref(spec['admin_verifier_ready_ref']);check_public_closure(spec['admin_verifier_manifest_ref'],spec['admin_verifier_closure_ref'])
    if admin_ready.get('status')!='READY_FOR_BOUND_INDEPENDENT_ADMIN_VERIFIER' or admin_ready.get('manifest_sha256')!=spec['admin_verifier_manifest_ref']['sha256'] or admin_ready.get('code_closure_sha256')!=spec['admin_verifier_closure_ref']['sha256'] or permission['bindings'].get('admin_verifier_manifest_sha256')!=spec['admin_verifier_manifest_ref']['sha256'] or permission['bindings'].get('admin_verifier_ready_sha256')!=spec['admin_verifier_ready_ref']['sha256']:raise EvidenceUnknown('new6 independent verifier code/Ready differs')
    if final.get('study_root')!=str(root) or final.get('schema')!='final-cross-inference-execution-protocol/v2' or final.get('status')!='FINAL_EXECUTION_AUTHORIZED' or final.get('execution_authorized') is not True or final.get('composite_root')!=plan['composite_root']:raise EvidenceUnknown('fixed new6 Final missing')
    bundle=final['bundle']
    if not equal(bundle['runs'],runs) or not equal(bundle.get('scientific_runs'),plan['all56_runs']) or barrier.get('bundle_sha256')!=digest(bundle) or sha256(bundle['scientific_plan_json'].encode()).hexdigest()!=SCIENCE_SHA or bundle['pins']['scientific_contract_sha256']!=SCIENCE_SHA or bundle['pins']['controller_closure_sha256']!=spec['worker_closure_ref']['sha256']:raise EvidenceUnknown('new6 science/runs/code closure differs')
    if bundle['pins'].get('entropy_sha256')!=ENTROPY_SHA or final.get('entropy_output_path')!=plan['entropy']['path']:raise EvidenceUnknown('unchanged original entropy file identity required')
    if final.get('data_manifest_sha256')!='f6ee2cb34103bdf4921e5e01d633dd2ce47b5e4477db391167cd104a8f7fbbe7' or bundle['pins']['data_contract_sha256']!='a1ce9ee118c06cd2d72b0cff3cd28c6358f89fdbfeaed4ca5423ba9cc49ed690':raise EvidenceUnknown('same fixed dataset/frame required')
    resources=plan['resource_accounting']
    if not equal(bundle['limits'],resources['per_case']) or not equal(bundle['controller_limits'],resources['controller_effective']) or not equal(bundle['study_limits'],resources['original_global']):raise EvidenceUnknown('original resource caps differ')
    if final.get('entropy_binding_mode')!=plan['entropy']['binding_mode'] or bundle.get('execution_mode')!=plan['entropy']['binding_mode'] or not equal(final.get('continuation_bindings'),cb) or not equal(bundle.get('continuation_bindings'),cb):raise EvidenceUnknown('new6 original entropy origin/continuation mode differs')
    rs=permission.get('resource_status');credit=permission.get('source_scientific_credit_allowed')
    if rs not in ('WITHIN_CUMULATIVE_FINAL_ADMIN_ONLY','OVER_LIMIT_RETAINED_ADMIN_ONLY') or type(credit) is not bool or credit!=(rs=='WITHIN_CUMULATIVE_FINAL_ADMIN_ONLY') or permission.get('eligibility_is_not_scientific_success') is not True:raise EvidenceUnknown('new6 final cumulative resource flag differs')
    if type(barrier.get('rows')) is not list or len(barrier['rows'])!=6:raise EvidenceUnknown('all6 source rows required')
    rows={};rowrefs={}
    for row,run in zip(barrier['rows'],runs):
        slot=root/'slots'/run['run_id'];retained.validate_terminal_row(row,run,context,slot)
        rp=root/f'ROW_{run["slot"]:03d}.json'
        if not equal(load_public(rp),row):raise EvidenceUnknown('new6 canonicalROW differs')
        rows[run['slot']]=row;rowrefs[run['slot']]=dict(path=str(rp),sha256=hash_file(rp))
    inventory=opaque_inventory(root)
    if not equal(inventory,barrier['inventory']) or digest(inventory)!=seal['inventory_sha256'] or digest(inventory)!=permission['inventory_sha256']:raise EvidenceUnknown('new6 complete opaque inventory differs')
    registry=dict(source_id='new6',root=str(root),context=context,selected_slots=plan['execution_slots'],planned_slot_count=6,planned_slots_sha256=digest(runs),final_protocol_ref=spec['final_protocol_ref'],worker_manifest_ref=spec['worker_manifest_ref'],worker_closure_ref=spec['worker_closure_ref'],external_seal_ref=seal_ref,admin_permission_ref=permission_ref,barrier_ref=dict(path=str(barrier_path),sha256=barrier_sha),inventory_sha256=digest(inventory),entropy_sha256=ENTROPY_SHA,scientific_contract_sha256=SCIENCE_SHA,continuation_bindings=cb)
    return dict(registry=registry,rows=rows,rowrefs=rowrefs,closure=closure,final=final,permission=permission,barrier=barrier)

def expected_cases(plan,old,new):
    cases=deepcopy(old['cases'][:50]);reg=new['registry']
    for run in plan['execution_runs']:
        rr=new['rowrefs'][run['slot']]
        cases.append(dict(run=run,source_id='new6',source_root=reg['root'],slot_root=str(Path(reg['root'])/'slots'/run['run_id']),row_path=rr['path'],row_sha256=rr['sha256'],source_context=reg['context'],source_final_protocol_sha256=reg['final_protocol_ref']['sha256'],source_worker_manifest_sha256=reg['worker_manifest_ref']['sha256'],source_worker_closure_sha256=reg['worker_closure_ref']['sha256'],source_external_seal_sha256=reg['external_seal_ref']['sha256'],source_admin_permission_sha256=reg['admin_permission_ref']['sha256'],source_row=deepcopy(new['rows'][run['slot']]),whole_case=True,no_postmortem_promotion=True))
    if len(cases)!=56 or not equal([x['run'] for x in cases],plan['all56_runs']):raise EvidenceUnknown('complete unique recursive56 table required')
    return cases

def load_source_authority(refs):
    complete_refs(refs,COMMON_REFS)
    objects={k:read_ref(v) for k,v in refs.items()};hashes={k:v['sha256'] for k,v in refs.items()}
    plan=read_fixed_plan();protocol=objects['composite_protocol'];validate_protocol(protocol,objects['composite_ready'],plan,hashes);check_implementation(refs,objects)
    spec=protocol['source_specs']['new6']
    if refs['new_source_permission']['path']!=spec['admin_permission_path'] or refs['new_source_external_seal']['path']!=spec['external_seal_path'] or refs['new_source_launch_ready']['path']!=spec['launch_ready_path']:raise NotReady('canonical new6 public gate locations required')
    lp=objects['new_source_launch_ready'];b=lp.get('bindings',{})
    if lp.get('status')!='READY_FOR_BOUND_ACTUAL_LAUNCH' or lp.get('actual_launch_authorized') is not True or lp.get('study_root')!=plan['new_execution_root'] or b.get('final_protocol_sha256')!=protocol['final_protocol_sha256'] or b.get('composite_protocol_sha256')!=hashes['composite_protocol'] or b.get('composite_ready_sha256')!=hashes['composite_ready'] or b.get('entropy_sha256')!=ENTROPY_SHA:raise NotReady('new6 pre-method composite launch graph required')
    if b.get('worker_manifest_sha256')!=spec['worker_manifest_ref']['sha256'] or b.get('controller_manifest_sha256')!=spec['worker_manifest_ref']['sha256'] or b.get('code_closure_sha256')!=spec['worker_closure_ref']['sha256'] or lp.get('planned_slots_sha256')!=digest(plan['execution_runs']):raise NotReady('new6 launch code/frame differs')
    old=load_retained_composite(refs['retained_composite_refs'],plan)
    newfinal=read_ref(protocol['current_final_protocol']);newcontext=digest(dict(bundle_sha256=digest(newfinal['bundle']),launch_ready_sha256=refs['new_source_launch_ready']['sha256'],entropy_sha256=ENTROPY_SHA))
    new=verify_new_source(spec,refs['new_source_external_seal'],refs['new_source_permission'],plan,newcontext)
    newmap={x['path']:x['sha256'] for x in new['closure']['files']}
    for sid in ('retained','new52','new51'):
        reg=old['sources'][sid];cl=read_ref(reg['worker_closure_ref']);oldmap={x['path']:x['sha256'] for x in cl['files']}
        if any(name not in oldmap or name not in newmap or oldmap[name]!=newmap[name] for name in STAT_FILES):raise EvidenceUnknown('statistical/dispatch/fee framework changed across contexts')
        if sid=='new51' and any(name not in oldmap or name not in newmap or oldmap[name]!=newmap[name] for name in PROTECTED_NEW17):raise EvidenceUnknown('all17 P6-to-P7 protected modules must remain byte-identical')
        oldfinal=read_ref(reg['final_protocol_ref'])
        if newfinal['bundle']['pins']['protocol_sha256']!=oldfinal['bundle']['pins']['protocol_sha256']:raise EvidenceUnknown('original method/request settings changed')
    registries=deepcopy(old['sources']);registries['new6']=new['registry']
    if set(registries)!={'retained','new52','new51','new6'}:raise EvidenceUnknown('exact four original/new registries required')
    return dict(plan=plan,protocol=protocol,objects=objects,authority_hashes=hashes,retained=old,new_source=new,sources=registries,cases=expected_cases(plan,old,new))

def _add_file(totals,path,required):
    p=Path(path)
    if not p.exists() and not p.is_symlink():
        if required:raise EvidenceUnknown('canonical operational sibling absent')
        return
    s=p.lstat()
    if not stat.S_ISREG(s.st_mode):raise EvidenceUnknown('operational sibling must be regular nonsymlink')
    totals['files']+=1;totals['logical_bytes']+=s.st_size;totals['allocated_bytes']+=s.st_blocks*512

def validate_storage_scope(plan):
    """Freeze disjoint historical trees and sibling files; stat-only at runtime."""
    policy=plan['resource_accounting'];scope=policy['historical_storage_scope']
    if type(scope) is not dict or set(scope)!={'tree_roots','sibling_files'}:raise EvidenceUnknown('complete frozen historical storage scope required')
    roots=scope['tree_roots'];files=scope['sibling_files']
    if type(roots) is not list or type(files) is not list or len(roots)!=len(set(roots)) or len(files)!=len(set(files)):raise EvidenceUnknown('unique storage scope lists required')
    paths=[Path(x) for x in roots];siblings=[Path(x) for x in files]
    for p in paths+siblings:
        if not p.is_absolute() or '..' in p.parts or str(p)!=str(p.resolve()) or not p.is_relative_to(BASE):raise EvidenceUnknown('canonical local historical storage scope required')
    for current in (Path(plan['new_execution_root']),Path(plan['composite_root'])):
        if any(current.is_relative_to(p) or p.is_relative_to(current) for p in paths+siblings):raise EvidenceUnknown('historical and new resource scopes overlap')
    historical_studies=['mast_bound56_actual_study_v1','mast_bound56_actual_study_recovered_v1','mast_bound56_unclaimed52_study_v1','mast_bound56_unclaimed51_study_v1']
    historical_composites=['mast_bound56_composite_v1','mast_bound56_composite_v2']
    required_trees=[BASE/x for x in historical_studies+historical_composites]
    if any(not any(p==root or p.is_relative_to(root) for root in paths) for p in required_trees):raise EvidenceUnknown('all four old studies and both old composites must remain charged')
    required_files=[BASE/(x+'.'+suf) for x in historical_studies for suf in ('ADMIN_CONTROLLER.log','CONTROLLER_STDERR.log','EXTERNAL_SEAL.json','LAUNCH_CLAIM.json','LAUNCH_RECEIPT.json')]+[BASE/(x+'.'+suf) for x in historical_composites for suf in ('EXTERNAL_SEAL.json','ADMIN_PERMISSION.json')]
    if any(p not in siblings and not any(p.is_relative_to(root) for root in paths) for p in required_files):raise EvidenceUnknown('all old canonical operational siblings must remain charged')
    return paths,siblings

def validate_old_storage_snapshot(snapshot,policy,roots,siblings):
    members=snapshot.get('members')
    if type(members) is not list or len(members)!=snapshot['files']:raise EvidenceUnknown('complete old storage snapshot members required')
    seen=set();totals=dict(files=0,logical_bytes=0,allocated_bytes=0)
    for member in members:
        name=member.get('path');p=Path(name) if type(name) is str else Path('.')
        if type(name) is not str or not p.is_absolute() or '..' in p.parts or name in seen or (p not in siblings and not any(p.is_relative_to(root) for root in roots)):raise EvidenceUnknown('snapshot member escapes exact historical scope')
        seen.add(name);item=p.lstat()
        if not stat.S_ISREG(item.st_mode) or item.st_size<integer(member['logical_bytes'],0,2**40) or item.st_blocks*512<integer(member['allocated_bytes'],0,2**40):raise EvidenceUnknown('historical snapshot member missing/type/size changed')
        totals['files']+=1;totals['logical_bytes']+=member['logical_bytes'];totals['allocated_bytes']+=integer(member['allocated_bytes'],0,2**40)
    if totals!=policy['old_storage_debit'] or any(snapshot[k]!=totals[k] for k in totals):raise EvidenceUnknown('historical snapshot/debit totals differ')

def sample_historical_scope(roots,siblings):
    """Count each canonical regular file once, including overlapping declarations."""
    totals=dict(files=0,logical_bytes=0,allocated_bytes=0);seen=set()
    def add(path):
        p=Path(path);name=str(p)
        if name in seen:return
        item=p.lstat()
        if not stat.S_ISREG(item.st_mode):raise EvidenceUnknown('historical member must be regular nonsymlink')
        seen.add(name);totals['files']+=1;totals['logical_bytes']+=item.st_size;totals['allocated_bytes']+=item.st_blocks*512
    for root in roots:
        if not root.is_dir() or root.is_symlink():raise EvidenceUnknown('historical storage tree absent or unsafe')
        for path in root.rglob('*'):
            item=path.lstat()
            if stat.S_ISDIR(item.st_mode):continue
            add(path)
    for p in siblings:add(p)
    return totals

def resource_receipt(authority):
    """Stat-only cumulative full history census; private contents stay opaque."""
    plan=authority['plan'];policy=plan['resource_accounting'];old=authority['retained']
    roots,siblings=validate_storage_scope(plan);snapshot=read_ref(policy['old_storage_snapshot'])
    validate_old_storage_snapshot(snapshot,policy,roots,siblings)
    oldtot=sample_historical_scope(roots,siblings)
    newroot=Path(plan['new_execution_root']);newtot=sample_tree(newroot)
    for suffix in ('ADMIN_CONTROLLER.log','CONTROLLER_STDERR.log','EXTERNAL_SEAL.json','LAUNCH_CLAIM.json','LAUNCH_RECEIPT.json'):_add_file(newtot,newroot.parent/(newroot.name+'.'+suffix),False)
    root=Path(plan['composite_root']);comp=sample_tree(root)
    for suffix in ('EXTERNAL_SEAL.json','ADMIN_PERMISSION.json'):_add_file(comp,root.parent/(root.name+'.'+suffix),False)
    oldcharged={k:max(oldtot[k],policy['old_storage_debit'][k]) for k in oldtot}
    total={k:oldcharged[k]+newtot[k]+comp[k] for k in oldtot};caps=policy['original_global'];reserve=policy['composite_reserve']
    violations=[k for k in total if total[k]>caps[k]]+['composite_'+k for k in comp if comp[k]>reserve[k]]
    free=shutil.disk_usage(root.parent).free
    if free<caps['free_disk_floor_bytes']:violations.append('free_disk_floor_bytes')
    flags=deepcopy(old['source_scientific_credit_allowed']);source_credit=authority['new_source']['permission'].get('source_scientific_credit_allowed')
    if type(source_credit) is not bool:raise EvidenceUnknown('new6 resource credit must be a plain boolean')
    flags['new6']=source_credit and not violations
    return dict(old_actual_storage=oldtot,old_charged_storage=oldcharged,new6_actual_storage=newtot,composite_actual_storage=comp,cumulative_storage=total,free_disk_bytes=free,violations=violations,resource_status='WITHIN_FIXED_CUMULATIVE_STORAGE_CAPS' if not violations and source_credit else 'OVER_LIMIT_RETAINED_ADMIN_ONLY',scientific_credit_allowed=all(flags.values()),source_scientific_credit_allowed=flags,CPU_cap_based_debit=policy['CPU_cap_based_debit'],CPU_remaining=policy['CPU_remaining'],actual_total_CPU='UNKNOWN_UNLESS_SEPARATELY_RECORDED',wall_absolute_deadline_utc_ns=policy['wall_absolute_deadline_utc_ns'],CPU_debit_is_not_measurement=True)

def verify_index_and_seal(authority,seal_ref):
    plan=authority['plan'];protocol=authority['protocol'];root=Path(plan['composite_root']);seal=read_ref(seal_ref)
    if Path(seal_ref['path']).resolve()!=root.parent/(root.name+'.EXTERNAL_SEAL.json'):raise NotReady('canonical recursive composite seal required')
    path=root/'COMPOSITE_INDEX.json';index=load_public(path)
    if seal.get('schema')!='disjoint56-composite-external-admin-seal/v2' or seal.get('composite_root')!=str(root) or seal.get('composite_protocol_sha256')!=authority['authority_hashes']['composite_protocol'] or seal.get('final_protocol_sha256')!=protocol['final_protocol_sha256'] or seal.get('index_sha256')!=hash_file(path) or seal.get('private_results_decoded') is not False:raise NotReady('recursive composite seal binding differs')
    for obj in (seal,index):
        integer(obj['planned_slot_count'],56,56)
        if obj['planned_slots_sha256']!=digest(plan['all56_runs']) or not equal(obj['continuation_bindings'],continuation_bindings(plan)):raise NotReady('recursive whole56 table changed')
    if index.get('schema')!='disjoint56-composite-admin-index/v2' or index.get('status')!='ALL56_COMPOSITE_POINTERS_ADMIN_ONLY' or index.get('scope')!='ACTUAL_FIXED_RECURSIVE_DISJOINT56' or index.get('composite_root')!=str(root) or index.get('composite_protocol_sha256')!=authority['authority_hashes']['composite_protocol'] or index.get('final_protocol_sha256')!=protocol['final_protocol_sha256'] or index.get('private_results_decoded') is not False or index.get('scientific_success')!='UNKNOWN':raise NotReady('recursive composite index status/scope differs')
    if not equal(index.get('cases'),authority['cases']) or not equal(index.get('sources'),authority['sources']) or not equal(index.get('authority_bindings'),authority['authority_hashes']):raise NotReady('wholecase/source registry provenance differs')
    source_bindings={sid:digest(v) for sid,v in authority['sources'].items()}
    if not equal(seal.get('source_bindings'),source_bindings) or seal.get('inventory_sha256')!=digest(composite_inventory(root)):raise NotReady('recursive complete opaque inventory changed')
    return index,seal,source_bindings

def load_verified_composite(refs):
    complete_refs(refs,CONSUMER_REFS)
    authority=load_source_authority({k:refs[k] for k in COMMON_REFS})
    index,seal,source_bindings=verify_index_and_seal(authority,refs['composite_external_seal']);permission=read_ref(refs['composite_admin_permission'])
    hashes={k:v['sha256'] for k,v in refs.items()};wanted={k+'_sha256':v for k,v in hashes.items() if k!='composite_admin_permission'};wanted['final_protocol_sha256']=authority['protocol']['final_protocol_sha256']
    if permission.get('schema')!='disjoint56-composite-admin-permission/v2' or permission.get('status')!='VERIFIED_COMPOSITE_56_SLOTS_ADMIN_ONLY' or not equal(permission.get('bindings'),wanted) or permission.get('composite_root')!=authority['plan']['composite_root'] or permission.get('index_sha256')!=seal['index_sha256'] or permission.get('inventory_sha256')!=seal['inventory_sha256'] or permission.get('private_results_decoded') is not False or permission.get('scientific_success')!='UNKNOWN':raise NotReady('independent recursive permission missing or changed')
    if not equal(permission.get('continuation_bindings'),continuation_bindings(authority['plan'])) or not equal(permission.get('source_bindings'),source_bindings) or type(permission.get('planned_slot_count')) is not int or permission['planned_slot_count']!=56 or permission.get('planned_slots_sha256')!=digest(authority['plan']['all56_runs']):raise NotReady('recursive permission table/source graph differs')
    resources=resource_receipt(authority)
    if permission.get('scientific_credit_allowed') is not resources['scientific_credit_allowed'] or not equal(permission.get('source_scientific_credit_allowed'),resources['source_scientific_credit_allowed']) or permission.get('resource_status')!=resources['resource_status']:raise NotReady('recursive per-source resource credit changed')
    return dict(cases=index['cases'],sources=index['sources'],protocol=authority['protocol'],authority_hashes=hashes,composite_root=authority['plan']['composite_root'],scientific_credit_allowed=resources['scientific_credit_allowed'],source_scientific_credit_allowed=resources['source_scientific_credit_allowed'],resource_status=resources['resource_status'])
