"""Owned bounded pipe to canonical C3. Never import old consumers in this process."""
from pathlib import Path
from hashlib import sha256
import json,os,subprocess,sys
ROOT=Path(__file__).resolve().parent
CANONICAL_ROOT=ROOT.parent/'mast_composite56_administration_candidate_v3'
CANONICAL_CONSUMER_SHA='56ea7610dc402dce969d3a7db95de67be2cecf292cdf536fe89ba0e76b99adbb'
CANONICAL_MANIFEST_SHA='7f59a5468fb76d078f028b9af3a5faf908022a4ba64e7a3d6d5e518024f21e78'
CANONICAL_CLOSURE_SHA='c31db3b8ec1a6dceecb1763350674fbc0d26fbe13930dc9fedbc43a50db738ec'
MAX_REQUEST=64*1024
MAX_RESPONSE=4*1024**2

def _canonical(x):return (json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()
def _run_owned_request(command,request):
    """Internal transport; only load_verified_old constructs production command."""
    raw=_canonical(request)
    if len(raw)>MAX_REQUEST:raise ValueError('retained verifier request exceeds cap')
    env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
    result=subprocess.run(command,input=raw,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,timeout=3600,check=False,close_fds=True,env=env)
    if result.returncode!=0 or len(result.stdout)>MAX_RESPONSE:raise ValueError('canonical retained verifier failed; no retained metadata logged')
    reply=json.loads(result.stdout)
    if type(reply) is not dict or set(reply)!={'ok','canonical_consumer_sha256','payload'} or reply['ok'] is not True or reply['canonical_consumer_sha256']!=CANONICAL_CONSUMER_SHA or type(reply['payload']) is not dict:raise ValueError('invalid owned retained verifier response')
    return reply['payload']

def load_verified_old(refs):
    from composite_primitives import complete_refs,NotReady
    names=('composite_protocol','composite_ready','implementation_manifest','implementation_closure','retained_composite_refs','new_source_permission','new_source_external_seal','new_source_launch_ready','composite_external_seal','composite_admin_permission')
    complete_refs(refs,names)
    if refs['implementation_manifest']!={'path':str(CANONICAL_ROOT/'DELIVERY_MANIFEST.json'),'sha256':CANONICAL_MANIFEST_SHA} or refs['implementation_closure']!={'path':str(CANONICAL_ROOT/'CODE_CLOSURE.json'),'sha256':CANONICAL_CLOSURE_SHA}:raise NotReady('only exact canonical reviewed C3 may be invoked')
    try:return _run_owned_request((sys.executable,'-I','-B',str(ROOT/'isolated_c3.py'),'--canonical-child'),dict(refs=refs))
    except Exception as exc:raise NotReady('isolated canonical C3 verification failed: '+type(exc).__name__) from None

def _child():
    # Child has no imports from C4/Aud9. It loads only pinned C3 and its own closure.
    import contextlib,importlib,resource,stat
    resource.setrlimit(resource.RLIMIT_CPU,(20,25));resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912));resource.setrlimit(resource.RLIMIT_FSIZE,(MAX_RESPONSE,MAX_RESPONSE))
    raw=sys.stdin.buffer.read(MAX_REQUEST+1)
    if len(raw)>MAX_REQUEST:raise ValueError('bounded request')
    request=json.loads(raw)
    if type(request) is not dict or set(request)!={'refs'}:raise ValueError('canonical request shape')
    path=CANONICAL_ROOT/'composite_consumer.py'
    if path.is_symlink() or not path.is_file() or sha256(path.read_bytes()).hexdigest()!=CANONICAL_CONSUMER_SHA:raise ValueError('canonical C3 consumer changed')
    for name,wanted in [('DELIVERY_MANIFEST.json',CANONICAL_MANIFEST_SHA),('CODE_CLOSURE.json',CANONICAL_CLOSURE_SHA)]:
        p=CANONICAL_ROOT/name
        if p.is_symlink() or not p.is_file() or sha256(p.read_bytes()).hexdigest()!=wanted:raise ValueError('canonical C3 closure changed')
    # Validate every frozen dependency before Python can import any C3 code.
    if CANONICAL_ROOT.resolve()!=CANONICAL_ROOT:raise ValueError('canonical C3 root must not contain symlinks')
    closure=json.loads((CANONICAL_ROOT/'CODE_CLOSURE.json').read_bytes())
    members=closure.get('files');runtime=closure.get('runtime_files')
    if type(members) is not list or not members or type(runtime) is not list:raise ValueError('canonical C3 complete closure required')
    seen=set()
    for row in members:
        if type(row) is not dict or type(row.get('path')) is not str or not row['path']:raise ValueError('canonical closure path type')
        relative=Path(row['path'])
        if relative.is_absolute() or '..' in relative.parts or '.' in relative.parts or relative.as_posix()!=row['path'] or row['path'] in seen:raise ValueError('canonical relative closure member required')
        seen.add(row['path']);member=CANONICAL_ROOT
        for part in relative.parts:
            member=member/part
            if member.is_symlink():raise ValueError('canonical closure member must not contain symlinks')
        if not member.resolve().is_relative_to(CANONICAL_ROOT):raise ValueError('canonical closure member escapes root')
        info=member.lstat()
        if not stat.S_ISREG(info.st_mode) or type(row.get('bytes')) is not int or row['bytes']<0 or info.st_size!=row['bytes']:raise ValueError('canonical closure member type or size changed')
        if sha256(member.read_bytes()).hexdigest()!=row.get('sha256'):raise ValueError('canonical closure member SHA changed')
    for name in runtime:
        if type(name) is not str or not name:raise ValueError('canonical C3 runtime name type')
        relative=Path(name)
        if relative.is_absolute() or '..' in relative.parts or '.' in relative.parts or relative.as_posix()!=name:raise ValueError('canonical relative runtime member required')
    declared=set(runtime);python_members={name for name in seen if name.endswith('.py')}
    if len(runtime)!=len(declared) or not declared.issubset(seen) or declared!=python_members or not {'composite_consumer.py','retained_composite_consumer.py','codec.py'}.issubset(declared):raise ValueError('canonical C3 runtime file set incomplete')
    sys.path.insert(0,str(CANONICAL_ROOT))
    with open(os.devnull,'w') as hidden,contextlib.redirect_stdout(hidden),contextlib.redirect_stderr(hidden):
        old=importlib.import_module('composite_consumer')
        if Path(old.__file__).resolve()!=path:raise ValueError('canonical module identity')
        data=old.load_verified_composite(request['refs'])
    reply=_canonical(dict(ok=True,canonical_consumer_sha256=CANONICAL_CONSUMER_SHA,payload=data))
    if len(reply)>MAX_RESPONSE:raise ValueError('bounded retained result')
    sys.stdout.buffer.write(reply);sys.stdout.buffer.flush()

if __name__=='__main__':
    if sys.argv[1:]!=['--canonical-child']:raise SystemExit(4)
    try:_child()
    except BaseException:raise SystemExit(4) from None
