"""Build public recursive protocol after CurrentFinal, before new6 methods."""
from pathlib import Path
from copy import deepcopy
import argparse,json
from composite_consumer import (read_fixed_plan,complete_refs,read_ref,continuation_bindings,
    pointer_templates,equal,NotReady,load_public,hash_file)
from composite_io import write_new

BUILD_REFS=('current_final_protocol','new_worker_manifest','new_worker_closure',
    'new_admin_manifest','new_admin_closure','new_admin_ready','implementation_manifest','implementation_closure')

def make_protocol(refs=None):
    complete_refs(refs,BUILD_REFS);plan=read_fixed_plan();objects={k:read_ref(v) for k,v in refs.items()}
    final=objects['current_final_protocol'];auth=Path(plan['current_authority_root'])
    if refs['current_final_protocol']['path']!=str(auth/'FINAL_PROTOCOL.json') or final.get('study_root')!=plan['new_execution_root'] or final.get('composite_root')!=plan['composite_root'] or not equal(final.get('continuation_bindings'),continuation_bindings(plan)):raise NotReady('fixed current6 Final required first')
    if not equal(final['bundle']['runs'],plan['execution_runs']) or not equal(final['bundle'].get('scientific_runs'),plan['all56_runs']) or final['bundle']['pins']['controller_closure_sha256']!=refs['new_worker_closure']['sha256']:raise NotReady('new6 worker/frame differs')
    if 'composite_protocol_sha256' in final or 'composite_ready_sha256' in final:raise NotReady('CurrentFinal cannot bind its future recursive protocol')
    new=dict(root=plan['new_execution_root'],selected_slots=plan['execution_slots'],context_policy='DERIVE_FROM_BOUND_NEW6_LAUNCH_READY',final_protocol_ref=refs['current_final_protocol'],worker_manifest_ref=refs['new_worker_manifest'],worker_closure_ref=refs['new_worker_closure'],admin_verifier_manifest_ref=refs['new_admin_manifest'],admin_verifier_closure_ref=refs['new_admin_closure'],admin_verifier_ready_ref=refs['new_admin_ready'],external_seal_path=plan['new_execution_root']+'.EXTERNAL_SEAL.json',admin_permission_path=str(auth/'ALL6_ADMIN_PERMISSION.json'),launch_ready_path=str(auth/'LAUNCH_READY.json'))
    impl=dict(collector_manifest_sha256=refs['implementation_manifest']['sha256'],collector_closure_sha256=refs['implementation_closure']['sha256'],composite_admin_manifest_sha256=refs['implementation_manifest']['sha256'],composite_admin_closure_sha256=refs['implementation_closure']['sha256'])
    return dict(schema='fixed56-disjoint-composite-protocol/v2',status='FROZEN_BEFORE_UNCLAIMED6_EXECUTION',scope='ACTUAL_FIXED_RECURSIVE_DISJOINT56',final_protocol_sha256=refs['current_final_protocol']['sha256'],currentstudy_root=plan['new_execution_root'],composite_root=plan['composite_root'],continuation_bindings=continuation_bindings(plan),implementation_bindings=impl,current_final_protocol=refs['current_final_protocol'],retained_composite=deepcopy(plan['retained_composite']),source_specs=dict(new6=new),pointer_templates=pointer_templates(plan),resources=deepcopy(plan['resource_accounting']))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--refs',required=True);p.add_argument('--output',required=True);a=p.parse_args()
    protocol=make_protocol(load_public(a.refs));write_new(a.output,protocol)
    print(json.dumps(dict(status=protocol['status'],path=str(Path(a.output).resolve()),sha256=hash_file(a.output),method_or_private_or_rank_access=False)),flush=True)
