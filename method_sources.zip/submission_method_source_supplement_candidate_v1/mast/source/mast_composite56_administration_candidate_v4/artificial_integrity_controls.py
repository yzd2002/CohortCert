"""One bounded artificial integrity suite. Never calls actual collect/audit/C3."""
from pathlib import Path
from copy import deepcopy
from hashlib import sha256
import argparse,contextlib,io,json,os,resource,signal,subprocess,sys,time
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
import composite_consumer as cc
import build_protocol as bp
import isolated_c3 as bridge
from composite_io import write_new

def expect_raises(kind,fn):
    try:fn()
    except kind:return
    raise AssertionError('expected rejection')

def run(out):
    start=time.process_time();wall=time.monotonic();out=Path(out).resolve();out.mkdir(exist_ok=False)
    fixture=out/'owned_fixture';fixture.mkdir();checks=[]
    def ok(label):checks.append(label)
    runs=[dict(slot=i,run_id='artificial_run_%02d'%i,replicate_id=i//7,method_id='artificial_method_%d'%(i%7)) for i in range(56)]
    sources={k:dict(root=str(fixture/k),context='artificial_context_'+k) for k in ('retained','new52','new51','new6')}
    def case(run,sid):
        row=dict(run=deepcopy(run),context=sources[sid]['context'],status='CENSORED_UNKNOWN' if run['slot'] in (3,4,49) else 'WORKER_SEALED',charge=dict(known_durable_submitted_prefix=0 if run['slot'] in (3,4) else 17,exact_total=None if run['slot'] in (3,4,49) else 17,exact_tail='UNKNOWN' if run['slot'] in (3,4,49) else 'KNOWN'))
        root=Path(sources[sid]['root'])
        return dict(run=deepcopy(run),source_id=sid,source_root=str(root),slot_root=str(root/'slots'/run['run_id']),row_path=str(root/('ROW_%03d.json'%run['slot'])),row_sha256='a'*64,source_context=row['context'],source_row=row,whole_case=True,no_postmortem_promotion=True)
    oldcases=[case(run,'retained' if run['slot']<4 else ('new52' if run['slot']==4 else 'new51')) for run in runs]
    allcases=deepcopy(oldcases[:50])+[case(run,'new6') for run in runs[50:]]
    # Load only Aud9 admission in this interpreter. Its composite helpers are the
    # same C4 code; no retained consumer or numerical executor is imported.
    audroot=ROOT.parent/'mast_postbarrier_scientific_auditor_candidate_v9';sys.path.insert(0,str(audroot))
    import admission
    admission.validate_case_map(allcases,runs,sources);ok('four_source_complete56_case_map_accepts_artificial_frame')
    damaged=deepcopy(allcases);damaged[49]['source_row']['status']='WORKER_SEALED'
    expect_raises(admission.NotReady,lambda:admission.validate_case_map(damaged,runs,sources));ok('global49_promotion_rejected')
    damaged=deepcopy(allcases);damaged[50]['source_id']='new51'
    expect_raises(admission.NotReady,lambda:admission.validate_case_map(damaged,runs,sources));ok('suffix6_source_reassignment_rejected')
    damaged=deepcopy(allcases);damaged[20]['source_row']['context']='rewritten'
    expect_raises(admission.NotReady,lambda:admission.validate_case_map(damaged,runs,sources));ok('retained_context_rewrite_rejected')
    refs18={k:dict(path=str(fixture/(k+'.json')),sha256='a'*64) for k in admission.REFS}
    assert len(refs18)==18;admission.complete_references(refs18)
    del refs18['entropy'];expect_raises(admission.NotReady,lambda:admission.complete_references(refs18));ok('exact18_refs_required_before_IO')
    expect_raises(admission.NotReady,lambda:admission.public_metadata(str(fixture/'LOCKED_LABEL_VECTORS.json')));ok('locked_label_metadata_role_rejected')
    expect_raises(cc.NotReady,lambda:bridge.load_verified_old({}));ok('incomplete_C3_refs_rejected_without_subprocess')
    assert bridge._canonical({})==b'{}\n';ok('transport_canonical_LF')
    canary='ARTIFICIAL_NESTED_COST_CANARY_NOT_CONSOLE'
    toy=fixture/'toy.py';toy.write_text('import json,sys\nr=json.loads(sys.stdin.buffer.read())\nprint(json.dumps({"ok":True,"canonical_consumer_sha256":'+repr(bridge.CANONICAL_CONSUMER_SHA)+',"payload":{"marker":r["marker"]}}))\n')
    console=io.StringIO()
    with contextlib.redirect_stdout(console):payload=bridge._run_owned_request((sys.executable,'-I','-B',str(toy)),dict(marker=canary))
    assert payload==dict(marker=canary) and console.getvalue()=='';ok('owned_pipe_transports_canary_without_console_output')
    bad=fixture/'bad.py';bad.write_text('print("{invalid")\n')
    expect_raises(ValueError,lambda:bridge._run_owned_request((sys.executable,'-I','-B',str(bad)),{}));ok('owned_pipe_malformed_response_rejected')
    bad.write_text('raise SystemExit(3)\n')
    expect_raises(ValueError,lambda:bridge._run_owned_request((sys.executable,'-I','-B',str(bad)),{}));ok('owned_pipe_failed_child_rejected')
    # Check prospective protocol and wholecase constructor using exclusively
    # fixture files and fake authority hashes. No actual source is collected.
    auth=fixture/'authority';auth.mkdir();newroot=fixture/'new6';comp=fixture/'composite'
    plan=dict(current_authority_root=str(auth),new_execution_root=str(newroot),composite_root=str(comp),all56_runs=runs,execution_runs=runs[50:],execution_slots=list(range(50,56)),retained_composite=dict(whole_case_pointers=deepcopy(oldcases[:50]),external_seal_ref=dict(path='/artificial/old_seal',sha256='b'*64),admin_permission_ref=dict(path='/artificial/old_permission',sha256='c'*64)),resource_accounting={})
    refs={}
    for key in bp.BUILD_REFS:
        p=auth/('FINAL_PROTOCOL.json' if key=='current_final_protocol' else key+'.json');obj={}
        if key=='current_final_protocol':obj=dict(study_root=str(newroot),composite_root=str(comp),continuation_bindings=cc.continuation_bindings(plan),bundle=dict(runs=runs[50:],scientific_runs=runs,pins=dict(controller_closure_sha256='PLACEHOLDER')))
        p.write_text(json.dumps(obj)+'\n');refs[key]=dict(path=str(p),sha256=sha256(p.read_bytes()).hexdigest())
    p=Path(refs['current_final_protocol']['path']);obj=json.loads(p.read_text());obj['bundle']['pins']['controller_closure_sha256']=refs['new_worker_closure']['sha256'];p.write_text(json.dumps(obj)+'\n');refs['current_final_protocol']['sha256']=sha256(p.read_bytes()).hexdigest()
    saved=bp.read_fixed_plan;bp.read_fixed_plan=lambda:plan
    try:protocol=bp.make_protocol(refs)
    finally:bp.read_fixed_plan=saved
    assert set(refs)==set(bp.BUILD_REFS) and len(refs)==8 and protocol['pointer_templates'][:50]==oldcases[:50] and set(protocol['source_specs'])=={'new6'};ok('eight_buildrefs_and_exact_prefix50_protocol')
    hs=dict(implementation_manifest=refs['implementation_manifest']['sha256'],implementation_closure=refs['implementation_closure']['sha256'],composite_protocol=cc.digest(protocol))
    ready=dict(status='READY_FOR_BOUND_DISJOINT56_COMPOSITE',final_protocol_sha256=protocol['final_protocol_sha256'],composite_protocol_sha256=hs['composite_protocol'],continuation_bindings=cc.continuation_bindings(plan),implementation_bindings=protocol['implementation_bindings'])
    cc.validate_protocol(protocol,ready,plan,hs);ok('prospective_protocol_ready_graph_accepts_artificial_frame')
    broken=deepcopy(ready);broken['composite_protocol_sha256']='f'*64
    expect_raises(cc.NotReady,lambda:cc.validate_protocol(protocol,broken,plan,hs));ok('wrong_ready_graph_rejected')
    reg=dict(root=str(newroot),context='artificial_context_new6',final_protocol_ref={'sha256':'a'*64},worker_manifest_ref={'sha256':'b'*64},worker_closure_ref={'sha256':'c'*64},external_seal_ref={'sha256':'d'*64},admin_permission_ref={'sha256':'e'*64})
    new=dict(registry=reg,rowrefs={i:dict(path=str(newroot/('ROW_%03d.json'%i)),sha256='a'*64) for i in range(50,56)},rows={run['slot']:dict(run=run,context=reg['context'],status='WORKER_SEALED') for run in runs[50:]})
    built=cc.expected_cases(plan,dict(cases=oldcases),new)
    assert cc.canonical(built[:50])==cc.canonical(oldcases[:50]) and all(x['source_id']=='new6' for x in built[50:]) and len(built)==56;ok('wholecase_prefix50_byte_equivalence_and_suffix6_exact')
    # Stat-only budget helpers against six artificial historical trees and
    # 24 fake operational sibling files. No real storage scope is touched.
    hist=fixture/'historical';hist.mkdir();studies=['mast_bound56_actual_study_v1','mast_bound56_actual_study_recovered_v1','mast_bound56_unclaimed52_study_v1','mast_bound56_unclaimed51_study_v1'];comps=['mast_bound56_composite_v1','mast_bound56_composite_v2']
    roots=[];siblings=[]
    for name in studies+comps:
        d=hist/name;d.mkdir();(d/'SENTINEL.txt').write_bytes(b'x');roots.append(d)
        for suffix in (('ADMIN_CONTROLLER.log','CONTROLLER_STDERR.log','EXTERNAL_SEAL.json','LAUNCH_CLAIM.json','LAUNCH_RECEIPT.json') if name in studies else ('EXTERNAL_SEAL.json','ADMIN_PERMISSION.json')):
            p=hist/(name+'.'+suffix);p.write_bytes(b'x');siblings.append(p)
    totals=cc.sample_historical_scope(roots,siblings)
    assert cc.sample_historical_scope(roots+[roots[0]],siblings+[roots[0]/'SENTINEL.txt'])==totals;ok('historical_scope_stat_deduplication')
    members=[]
    for p in [d/'SENTINEL.txt' for d in roots]+siblings:
        st=p.stat();members.append(dict(path=str(p),logical_bytes=st.st_size,allocated_bytes=st.st_blocks*512))
    snapshot=dict(members=members,**totals)
    policy=dict(old_storage_debit=totals)
    cc.validate_old_storage_snapshot(snapshot,policy,roots,siblings)
    grown=roots[0]/'SENTINEL.txt';grown.write_bytes(b'xxxx');cc.validate_old_storage_snapshot(snapshot,policy,roots,siblings)
    assert cc.sample_historical_scope(roots,siblings)['logical_bytes']>totals['logical_bytes'];ok('historical_growth_counted_without_refund')
    grown.write_bytes(b'');expect_raises(cc.EvidenceUnknown,lambda:cc.validate_old_storage_snapshot(snapshot,policy,roots,siblings));ok('historical_shrink_rejected')
    grown.write_bytes(b'xxxx');savedbase=cc.BASE;cc.BASE=hist
    try:
        scopeplan=dict(new_execution_root=str(hist/'mast_bound56_unclaimed6_study_v1'),composite_root=str(hist/'mast_bound56_composite_v3'),resource_accounting=dict(historical_storage_scope=dict(tree_roots=[str(p) for p in roots],sibling_files=[str(p) for p in siblings])))
        cc.validate_storage_scope(scopeplan);ok('complete_artificial_historical_scope_required')
        badscope=deepcopy(scopeplan);badscope['resource_accounting']['historical_storage_scope']['tree_roots'].pop()
        expect_raises(cc.EvidenceUnknown,lambda:cc.validate_storage_scope(badscope));ok('missing_historical_composite_scope_rejected')
    finally:cc.BASE=savedbase
    mathfiles=['audit_io.py','bound_entropy_origin.py','bounded_codec.py','bounded_replay_math.py','codec.py','expected_reference.py','independent_fees.py','independent_local.py','native_expected.py','registered_native_ci.py','run_audit.py','sss_expected.py','uits.py','inputs/AUDIT_POLICY.json','inputs/DATA_CONTRACT.json','inputs/SCIENTIFIC_CONTRACT_FINAL.json']
    audold=ROOT.parent/'mast_postbarrier_scientific_auditor_candidate_v8'
    assert all(sha256((audroot/f).read_bytes()).hexdigest()==sha256((audold/f).read_bytes()).hexdigest() for f in mathfiles);ok('all16_inherited_numerical_policy_inputs_byte_identical_Aud8')
    result=dict(schema='C4-Aud9-single-artificial-integrity-test/v1',status='PASS',checks=checks,check_count=len(checks),CPU_seconds=time.process_time()-start,wall_seconds=time.monotonic()-wall,actual_collect_or_audit_calls=0,canonical_C3_runtime_calls=0,actual_storage_scope_reads=0,actual_labels_ranks_private_or_Native_access=False,production_authority_created=False)
    write_new(out/'RESULT.json',result)
    print(json.dumps({k:result[k] for k in ('status','check_count','CPU_seconds','wall_seconds','actual_collect_or_audit_calls','canonical_C3_runtime_calls')},sort_keys=True))

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--outdir',required=True);args=parser.parse_args()
    resource.setrlimit(resource.RLIMIT_CPU,(4,5));resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912))
    signal.signal(signal.SIGALRM,lambda *_:(_ for _ in ()).throw(TimeoutError('artificial integrity wall cap')));signal.alarm(30)
    run(args.outdir)
