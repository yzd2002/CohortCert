"""Collect verified recursive prefix50 plus sealed new6; never mutate sources."""
from pathlib import Path
import argparse,json,resource,signal
from composite_consumer import (load_source_authority,continuation_bindings,resource_receipt,
    composite_inventory,digest,hash_file,load_public)
from composite_io import write_new

def collect(refs=None):
    authority=load_source_authority(refs)
    root=Path(authority['plan']['composite_root']);sealpath=root.parent/(root.name+'.EXTERNAL_SEAL.json')
    if root.exists() or sealpath.exists():raise FileExistsError('fixed recursive composite already claimed')
    root.mkdir(mode=0o700);plan=authority['plan'];protocol=authority['protocol'];hs=authority['authority_hashes']
    write_new(root/'COLLECTION_CLAIM.json',dict(schema='disjoint56-composite-collection-claim/v2',composite_protocol_sha256=hs['composite_protocol'],final_protocol_sha256=protocol['final_protocol_sha256'],no_source_mutation=True,no_method_execution=True,no_retained_case_rewrite=True))
    index=dict(schema='disjoint56-composite-admin-index/v2',status='ALL56_COMPOSITE_POINTERS_ADMIN_ONLY',scope='ACTUAL_FIXED_RECURSIVE_DISJOINT56',composite_root=str(root),composite_protocol_sha256=hs['composite_protocol'],final_protocol_sha256=protocol['final_protocol_sha256'],continuation_bindings=continuation_bindings(plan),authority_bindings=hs,sources=authority['sources'],cases=authority['cases'],planned_slot_count=56,planned_slots_sha256=digest(plan['all56_runs']),private_results_decoded=False,scientific_success='UNKNOWN')
    write_new(root/'COMPOSITE_INDEX.json',index)
    resources=resource_receipt(authority);resources['phase']='BEFORE_FINAL_RECEIPT_CLOSURE_AND_EXTERNAL_SEAL'
    write_new(root/'RESOURCE_RECEIPT.json',resources)
    write_new(root/'COMPOSITE_CLOSED.json',dict(schema='disjoint56-composite-collector-closure/v2',composite_protocol_sha256=hs['composite_protocol'],index_sha256=hash_file(root/'COMPOSITE_INDEX.json'),planned_slot_count=56,private_results_decoded=False,scientific_success='UNKNOWN'))
    inventory=composite_inventory(root)
    seal=dict(schema='disjoint56-composite-external-admin-seal/v2',composite_root=str(root),composite_protocol_sha256=hs['composite_protocol'],final_protocol_sha256=protocol['final_protocol_sha256'],continuation_bindings=continuation_bindings(plan),planned_slot_count=56,planned_slots_sha256=digest(plan['all56_runs']),index_sha256=hash_file(root/'COMPOSITE_INDEX.json'),inventory_sha256=digest(inventory),source_bindings={sid:digest(v) for sid,v in authority['sources'].items()},private_results_decoded=False)
    write_new(sealpath,seal)
    return dict(status='ALL56_COMPOSITE_POINTERS_SEALED_ADMIN_ONLY',composite_root=str(root),external_seal=str(sealpath),external_seal_sha256=hash_file(sealpath),private_results_decoded=False,scientific_success='UNKNOWN')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--refs',required=True);a=p.parse_args()
    resource.setrlimit(resource.RLIMIT_CPU,(20,25));resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912))
    signal.signal(signal.SIGALRM,lambda *_:(_ for _ in ()).throw(TimeoutError('recursive collection wall budget')));signal.alarm(3600)
    print(json.dumps(collect(load_public(a.refs)),sort_keys=True),flush=True)
