"""One explicit zero-worker recovery of the original uniform ranks; no draws."""
from hashlib import sha256
from pathlib import Path
import json

MODE='RECOVERY_REUSE_ZERO_START'
SCIENCE='2aa107395b7b8689707abaec4e5228318db1371a0b02c9fbac76610e19732624'
ATTESTATION='a2aeb541538eee44f93a0ae3fa4045d284b4848aae08d0a2c82a0368b09f16b0'
DESIGN='35fb1de060407744803ecb8bf986ed3106a6e562c5f1586a4086f53891d0eeb6'
ORIGIN=dict(
 original_final_protocol_sha256='ff7b7dd9731e8838e4128bd8e778c214831ea5641e09dd21842ca4ee86fb7840',
 original_core_ready_sha256='9e450689ff8f023fd06d316e4e7b84766947342ceb4e7eaf411e473a02126b53',
 original_auditor_ready_sha256='3bf40272e455ea49c74a274079eab39411931dfab25dd1bf30f52bed9f2f095f',
 original_launch_ready_sha256='d2ec6c2200ef25a8d475d02c6908ff0d729db319f0490872d3a2aec80b074846',
 original_entropy_sha256='0d4c760d5cf8fed33ad73a502cc7c5d7bb3d0de232161b166629b8a9a25360ff',
 original_draw_claim_sha256='337b0095c7bb1ce8a08c31a5f6600ba80c45736126541793fd9bd31933f39ad2',
 original_entropy_path=str(Path(__file__).resolve().parent.parent/'mast_bound56_final_authority_v1/ACTUAL_ENTROPY_RANKS.json'))

def _plain(x,value):return type(x) is int and x==value

def origin_hashes(final,current_hashes):
    """Pure public-metadata validation. No paths, ranks or label files opened."""
    mode=final.get('entropy_binding_mode','FRESH_OS_DRAW')
    if mode=='FRESH_OS_DRAW':
        if 'zero_start_recovery' in final:raise ValueError('recovery origin cannot silently use fresh mode')
        return {k:current_hashes[k] for k in ('final_protocol','core_ready','auditor_ready')}
    if mode!=MODE:raise ValueError('unknown explicit entropy binding mode')
    recovery=final.get('zero_start_recovery')
    fields={'schema','origin','zero_start_attestation_json','zero_start_attestation_sha256','recovery_design_sha256'}
    if type(recovery) is not dict or set(recovery)!=fields or recovery['schema']!='same-ranks-zero-start-recovery-authority/v1' or recovery['origin']!=ORIGIN or recovery['zero_start_attestation_sha256']!=ATTESTATION or recovery['recovery_design_sha256']!=DESIGN:
        raise ValueError('only the exact original all56 zero-start recovery is allowed')
    raw=recovery['zero_start_attestation_json']
    if type(raw) is not str or len(raw.encode())>65536 or sha256(raw.encode()).hexdigest()!=ATTESTATION:raise ValueError('independent original zero-start proof changed')
    proof=json.loads(raw)
    fixed=dict(schema='independent-first56-zero-start-attestation/v1',status='VERIFIED_ZERO_METHOD_START_ZERO_FEE_ALL56',
        context='7c1cada5f828aff011ae2dd8410d94aa5a27cc6eeac414fbf84f296bce4a5af9',
        external_seal_sha256='b0b0e640c4a99ed7f020c5780c3234ae630f9a115f18c3113fc7f0ce85b193b3',
        barrier_sha256='2d249d26e07422b8195edbd8da35919f8bd5ee8f624ff5c5caf4a637a6274eb5',
        inventory_sha256='4a5228460ec3a7aafe798b74134f45d395260576231efde23853ad93787f6e60',
        planned_slots_sha256='8f644a8d7c6c400dd459ab0aecc518f79bb3998ec74fb39c003a750d2ce81305',scientific_contract_sha256=SCIENCE)
    if any(proof.get(k)!=v for k,v in fixed.items()):raise ValueError('original sealed study identity differs')
    if not _plain(proof.get('planned_slots'),56) or any(not _plain(proof.get(k),0) for k in ('worker_launches','method_start_markers','fee_journals','physical_fee_total','private_directories_or_files')):
        raise ValueError('any started/acquired/paid/unknown original slot forbids recovery')
    if proof.get('terminal_status_counts')!={'START_FAILED_UNSUBMITTED':1,'UNRUN_GLOBAL_STOP':55} or proof.get('original_controller',{}).get('same_process_live') is not False or proof.get('actual_truth_private_or_Source_read') is not False:
        raise ValueError('zero-start proof not exclusively original preexec failure')
    prior=proof['entropy_origin']
    for short in ('final_protocol','core_ready','auditor_ready'):
        if prior.get('original_'+short+'_sha256')!=ORIGIN['original_'+short+'_sha256']:raise ValueError('original entropy readiness chain differs')
    if prior.get('entropy_sha256')!=ORIGIN['original_entropy_sha256'] or prior.get('draw_claim_sha256')!=ORIGIN['original_draw_claim_sha256'] or prior.get('actual_rank_values_decoded') is not False:
        raise ValueError('original unchanged rank provenance differs')
    bundle=final['bundle'];runs=bundle['runs']
    canonical=(json.dumps(runs,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()
    if sha256(canonical).hexdigest()!=fixed['planned_slots_sha256'] or sha256(bundle['scientific_plan_json'].encode()).hexdigest()!=SCIENCE:
        raise ValueError('all56 original identities and statistical science must remain unchanged')
    if final.get('entropy_output_path')!=ORIGIN['original_entropy_path'] or ('entropy' in current_hashes and current_hashes['entropy']!=ORIGIN['original_entropy_sha256']):
        raise ValueError('recovery cannot replace or redraw the original rank record')
    return {k:ORIGIN['original_'+k+'_sha256'] for k in ('final_protocol','core_ready','auditor_ready')}

def claim_context(final,current_hashes):
    origin=origin_hashes(final,current_hashes)
    return dict(no_redraw=True,actual_study=True,**{k+'_sha256':v for k,v in origin.items()})

def forbid_recovery_draw(final):
    if final.get('entropy_binding_mode','FRESH_OS_DRAW')!='FRESH_OS_DRAW' or 'zero_start_recovery' in final:
        raise ValueError('zero-start recovery reuses the immutable original ranks; new draws forbidden')
