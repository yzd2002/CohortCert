"""Shared new8CPU scope: only synthetic authority metadata, no rank-file decode."""
from pathlib import Path
from copy import deepcopy
import json,sys,time,resource,importlib.util
resource.setrlimit(resource.RLIMIT_CPU,(4,5))
resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912))
import bound_entropy_origin as origin
import authority_v2 as worker
P=Path(__file__).resolve().parent;R=P.parent;O=P/'recovery_origin_delta_output';O.mkdir(exist_ok=False)
cases=[];start=time.process_time()
def passed(name):cases.append(dict(case=name,status='PASS'))
def rejects(name,fn):
    try:fn()
    except (ValueError,PermissionError):passed(name)
    else:raise AssertionError('expected rejection: '+name)
try:
    science_path=R/'mast_56_final_protocol_candidate_v1/SCIENTIFIC_CONTRACT_FINAL.json'
    science=json.loads(science_path.read_text())
    proof=(R/'bound56_zero_start_recovery_independent_review_v1/ZERO_START_ATTESTATION.json').read_text()
    recovery=dict(schema='same-ranks-zero-start-recovery-authority/v1',origin=deepcopy(origin.ORIGIN),zero_start_attestation_json=proof,zero_start_attestation_sha256=origin.ATTESTATION,recovery_design_sha256=origin.DESIGN)
    final=dict(entropy_binding_mode=origin.MODE,zero_start_recovery=recovery,entropy_output_path=origin.ORIGIN['original_entropy_path'],bundle=dict(runs=science['runs'],scientific_plan_json=science_path.read_text()))
    current=dict(final_protocol='a'*64,core_ready='b'*64,auditor_ready='c'*64,entropy=origin.ORIGIN['original_entropy_sha256'])
    expected={k:origin.ORIGIN['original_'+k+'_sha256'] for k in ('final_protocol','core_ready','auditor_ready')}
    assert origin.origin_hashes(final,current)==expected
    passed('exact_zero_start_proof_all56_same_science_returns_explicit_original_origin')
    bad=deepcopy(final);bad['zero_start_recovery']['origin']['original_entropy_sha256']='d'*64
    rejects('different_rank_record_no_fallback',lambda:origin.origin_hashes(bad,current))
    bad=deepcopy(final);bad['zero_start_recovery']['zero_start_attestation_json']=proof+' '
    rejects('changed_or_started_proof_cannot_reuse_fixed_attestation_hash',lambda:origin.origin_hashes(bad,current))
    bad=deepcopy(final);bad.pop('entropy_binding_mode')
    rejects('recovery_fields_without_explicit_mode',lambda:origin.origin_hashes(bad,current))
    bad=deepcopy(final);bad['bundle']['runs']=bad['bundle']['runs'][:-1]
    rejects('no_selected_subset_of55_slots',lambda:origin.origin_hashes(bad,current))
    bad=deepcopy(final);bad['bundle']['scientific_plan_json']+=' '
    rejects('no_changed_statistical_science',lambda:origin.origin_hashes(bad,current))
    rejects('recovery_draw_entry_pure_gate_forbids_new_bytes',lambda:origin.forbid_recovery_draw(final))
    assert origin.origin_hashes({},current)=={k:current[k] for k in expected};origin.forbid_recovery_draw({})
    passed('fresh_mode_keeps_current_authority_semantics')
    # Deliberately artificial zero rank values. The real OS record is never
    # opened here; this pure validator cannot issue any process-bound permit.
    record=dict(schema='bound-uniform-factoradic-entropy/v1',scope='ACTUAL_UNIFORM_EXTERNAL_RANK_PROVENANCE',sampling='OS_UNIFORM_BITS_REJECTION',before_method_access=True,draw_claim_sha256=origin.ORIGIN['original_draw_claim_sha256'],replicates={str(i):{g:dict(pilot_rank=0,formal_rank=0) for g in 'ABC'} for i in range(8)},**{k+'_sha256':v for k,v in expected.items()})
    assert len(worker.validate_entropy(record,final['bundle'],current,final=final))==8
    rejects('recovery_record_never_accepted_as_fresh_current_draw',lambda:worker.validate_entropy(record,final['bundle'],current,final={}))
    sys.path.insert(0,str(R/'mast_postbarrier_scientific_auditor_candidate_v3'))
    spec=importlib.util.spec_from_file_location('recovery_auditor_admission',R/'mast_postbarrier_scientific_auditor_candidate_v3/admission.py');admission=importlib.util.module_from_spec(spec);sys.modules[spec.name]=admission;spec.loader.exec_module(admission)
    claim=origin.claim_context(final,current);admission.validate_entropy_metadata(record,claim,current,final=final)
    wrong=deepcopy(claim);wrong['final_protocol_sha256']=current['final_protocol']
    rejects('auditor_requires_original_claim_not_forged_current_claim',lambda:admission.validate_entropy_metadata(record,wrong,current,final=final))
    passed('worker_and_auditor_explicit_recovery_origin_agree_without_real_rank_read')
    # Three role copies must stay byte-identical; statistical modules unchanged
    # are pinned by the later exact closure/delta review, not reexecuted here.
    from hashlib import sha256
    data=(P/'bound_entropy_origin.py').read_bytes()
    assert all((R/name/'bound_entropy_origin.py').read_bytes()==data for name in ('mast_independent_admin_verifier_candidate_v3','mast_postbarrier_scientific_auditor_candidate_v3'))
    passed('worker_admin_auditor_origin_helper_byte_identity')
    report=dict(status='PASS_NEW_ZERO_START_ORIGIN_METADATA_CONTROLS_ONLY',checks=cases,CPU_before_final_write=time.process_time()-start,actual_rank_file_decoded=False,new_OS_study_bytes=0,method_or_Source_or_actual_READY=False,original_fresh_suites_or_full300_repeated=False)
except BaseException:
    import traceback
    report=dict(status='FAILED_RETAINED',checks=cases,CPU_before_final_write=time.process_time()-start,traceback=traceback.format_exc(),new_OS_study_bytes=0,actual_READY=False)
(O/'RESULTS.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
