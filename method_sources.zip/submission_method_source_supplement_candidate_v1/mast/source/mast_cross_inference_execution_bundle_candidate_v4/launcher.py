"""Artificial-only detached handshake. Never invokes a real worker/gate."""
from pathlib import Path
import os,subprocess,sys,time,json,resource
from contract import validate_bundle
from gate import ROOT,authorize_actual,authorize_artificial
from io_utils import atomic_json,file_hash,load_json
from process_control import Handle,birth,bound,kill_wait
from limit_inheritance import controller_preexec

def launch_artificial(bundle_file,study_root,*,stop_after=None):
    bundle=load_json(bundle_file);bundle,context,root=authorize_artificial(bundle,study_root)
    root.parent.mkdir(parents=True,exist_ok=True)
    if root.exists() or (root.parent/(root.name+'.LAUNCH_CLAIM.json')).exists():raise FileExistsError('detached launch is no-retry')
    atomic_json(root.parent/(root.name+'.LAUNCH_CLAIM.json'),dict(context=context,study_root=str(root),no_retry=True,scope='ARTIFICIAL_ONLY'))
    command=[sys.executable,'-B',str(ROOT/'controller.py'),'--mode','artificial','--bundle',str(Path(bundle_file).resolve()),'--study-root',str(root)]
    if stop_after is not None:command+=['--stop-after',str(stop_after)]
    with (root.parent/(root.name+'.ADMIN_CONTROLLER.log')).open('xb') as out,(root.parent/(root.name+'.CONTROLLER_STDERR.log')).open('xb') as err:
        p=subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=out,stderr=err,close_fds=True,start_new_session=True,
            env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1'))
    h=Handle(p,p.pid,birth(p.pid),tuple(command),os.getpid());deadline=time.monotonic()+5
    try:
        while True:
            path=root/'CONTROLLER_STARTED.json'
            if path.exists():
                s=load_json(path)
                if s.get('pid')!=h.pid or s.get('starttime')!=h.starttime or s.get('context')!=context or s.get('study_lock_held') is not True:raise ValueError('detached startup binding')
                if p.poll() is None and (not bound(h) or os.getsid(h.pid)!=h.pid):raise ValueError('detached session identity')
                receipt=dict(status='ARTIFICIAL_DETACHED_STARTED' if p.poll() is None else 'ARTIFICIAL_COMPLETED_EARLY',pid=h.pid,starttime=h.starttime,
                    context=context,scope='ARTIFICIAL_ONLY',actual_authorized=False,controller_start_sha256=file_hash(path))
                atomic_json(root.parent/(root.name+'.LAUNCH_RECEIPT.json'),receipt)
                return h,receipt
            if p.poll() is not None:raise RuntimeError('detached controller failed before handshake')
            if time.monotonic()>deadline:raise TimeoutError('detached startup timeout')
            time.sleep(0.003)
    except BaseException:
        kill_wait(h,'LAUNCH_HANDSHAKE_FAILED');raise

def launch_actual(authority_refs=None):
    permit=authorize_actual(authority_refs) # Missing authorities reject before I/O.
    root=Path(permit.study_root);root.parent.mkdir(parents=True,exist_ok=True)
    claim=root.parent/(root.name+'.LAUNCH_CLAIM.json')
    if root.exists() or claim.exists():raise FileExistsError('bound launch is no-retry')
    atomic_json(claim,dict(context=permit.context,study_root=str(root),no_retry=True,scope='actual_bound',authority_bindings=permit.hashes))
    command=[sys.executable,'-B',str(ROOT/'controller.py'),'--mode','actual','--study-root',str(root),'--authority-refs',json.dumps(authority_refs,sort_keys=True,separators=(',',':'))]
    limits=permit.bundle['controller_limits']
    prepare_controller=controller_preexec(limits,permit.bundle['limits'])
    with (root.parent/(root.name+'.ADMIN_CONTROLLER.log')).open('xb') as out,(root.parent/(root.name+'.CONTROLLER_STDERR.log')).open('xb') as err:
        p=subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=out,stderr=err,close_fds=True,start_new_session=True,preexec_fn=prepare_controller,
            env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1'))
    h=Handle(p,p.pid,birth(p.pid),tuple(command),os.getpid());deadline=time.monotonic()+limits['wall_seconds']
    try:
        while True:
            path=root/'CONTROLLER_STARTED.json'
            if path.exists():
                s=load_json(path)
                if s.get('pid')!=h.pid or s.get('starttime')!=h.starttime or s.get('context')!=permit.context or s.get('study_lock_held') is not True:raise ValueError('bound detached startup identity')
                if p.poll() is None and (not bound(h) or os.getsid(h.pid)!=h.pid):raise ValueError('bound detached session identity')
                receipt=dict(status='BOUND_DETACHED_STARTED' if p.poll() is None else 'BOUND_COMPLETED_EARLY',pid=h.pid,starttime=h.starttime,context=permit.context,authority_bindings=permit.hashes,controller_start_sha256=file_hash(path),private_results_decoded=False)
                atomic_json(root.parent/(root.name+'.LAUNCH_RECEIPT.json'),receipt);return h,receipt
            if p.poll() is not None:raise RuntimeError('bound controller exited before handshake')
            if time.monotonic()>deadline:raise TimeoutError('bound detached startup wall')
            time.sleep(.003)
    except BaseException:
        kill_wait(h,'BOUND_LAUNCH_HANDSHAKE_FAILURE');raise
