"""Controller-only soft limits and a noninherited process-CPU stop timer.

No data, entropy, process discovery, authority bypass or launch entry point.
Use the factory only from the bound trusted single-threaded launcher, after its
unchanged authority gate. The broader hard rlimits are inheritance ceilings;
the controller's effective CPU stop is a default-action ITIMER_PROF signal.
"""
from dataclasses import dataclass
import math,resource,signal,sys,threading,time

def _positive_integer(value,name):
    if type(value) is not int or value<=0:raise ValueError(name+' positive plain integer required')
    return value

@dataclass(frozen=True)
class ControllerEnvelope:
    cpu_soft:int
    cpu_inherited_hard:int
    cpu_effective_stop:float
    as_soft:int
    as_inherited_hard:int
    file_soft:int
    file_inherited_hard:int

    def validate(self):
        for name in ('cpu_soft','cpu_inherited_hard','as_soft','as_inherited_hard','file_soft','file_inherited_hard'):_positive_integer(getattr(self,name),name)
        if type(self.cpu_effective_stop) not in (int,float) or not math.isfinite(self.cpu_effective_stop) or not 0<self.cpu_effective_stop<=self.cpu_inherited_hard:raise ValueError('finite positive effective CPU stop within inherited ceiling')
        if self.cpu_soft>self.cpu_inherited_hard or self.as_soft>self.as_inherited_hard or self.file_soft>self.file_inherited_hard:raise ValueError('controller soft limit exceeds inheritance ceiling')

def derive_envelope(controller_limits,method_limits):
    """Derive only OS ceilings. Externally fixed scientific caps stay literal."""
    if type(controller_limits) is not dict or type(method_limits) is not dict or not method_limits:raise ValueError('bound controller and nonempty exact method table required')
    def values(limits):
        if type(limits) is not dict:raise ValueError('bound limits object')
        soft=_positive_integer(limits['CPU_soft'],'CPU_soft');hard=_positive_integer(limits['CPU_hard'],'CPU_hard')
        memory=_positive_integer(limits['AS_bytes'],'AS_bytes');packet=_positive_integer(limits['packet_bytes'],'packet_bytes')
        if soft>hard:raise ValueError('CPU soft exceeds fixed effective hard target')
        return soft,hard,memory,packet
    soft,stop,memory,packet=values(controller_limits)
    workers=[values(limits) for limits in method_limits.values()]
    answer=ControllerEnvelope(soft,max([stop]+[x[1] for x in workers]),stop,memory,max([memory]+[x[2] for x in workers]),packet,max([packet]+[x[3] for x in workers]))
    answer.validate();return answer

def check_parent_capacity(envelope):
    """Fail clearly before fork rather than fail inside a worker's preexec."""
    envelope.validate()
    for which,needed in ((resource.RLIMIT_CPU,envelope.cpu_inherited_hard),(resource.RLIMIT_AS,envelope.as_inherited_hard),(resource.RLIMIT_FSIZE,envelope.file_inherited_hard)):
        current_hard=resource.getrlimit(which)[1]
        if current_hard!=resource.RLIM_INFINITY and current_hard<needed:raise PermissionError('launch parent hard rlimit is below required worker inheritance ceiling')

def apply_controller_envelope(envelope):
    """Run in the new controller between fork and exec; never in its parent."""
    if not sys.platform.startswith('linux'):raise RuntimeError('Linux fork/exec timer contract required')
    envelope.validate()
    # The fork child starts without interval timers. Refuse unexpected reuse.
    if signal.getitimer(signal.ITIMER_PROF)!=(0.0,0.0):raise RuntimeError('unexpected preexisting controller profiling timer')
    signal.signal(signal.SIGPROF,signal.SIG_DFL)
    signal.signal(signal.SIGXCPU,signal.SIG_DFL)
    # Dispositions alone do not clear an inherited signal mask across exec.
    signal.pthread_sigmask(signal.SIG_UNBLOCK,{signal.SIGPROF,signal.SIGXCPU})
    resource.setrlimit(resource.RLIMIT_CPU,(envelope.cpu_soft,envelope.cpu_inherited_hard))
    resource.setrlimit(resource.RLIMIT_AS,(envelope.as_soft,envelope.as_inherited_hard))
    resource.setrlimit(resource.RLIMIT_FSIZE,(envelope.file_soft,envelope.file_inherited_hard))
    remaining=float(envelope.cpu_effective_stop)-time.process_time()
    if remaining<=0:raise TimeoutError('controller effective CPU budget exhausted before exec')
    # Linux preserves this one-shot timer through exec but does not copy it
    # into later forked workers. No periodic rearm and no caught SIGPROF.
    signal.setitimer(signal.ITIMER_PROF,remaining,0.0)

def controller_preexec(controller_limits,method_limits):
    """Production factory: no artificial timer override or scientific retuning."""
    if threading.active_count()!=1:raise RuntimeError('controller preexec requires the trusted single-threaded launcher')
    envelope=derive_envelope(controller_limits,method_limits);check_parent_capacity(envelope)
    def prepare():apply_controller_envelope(envelope)
    return prepare
