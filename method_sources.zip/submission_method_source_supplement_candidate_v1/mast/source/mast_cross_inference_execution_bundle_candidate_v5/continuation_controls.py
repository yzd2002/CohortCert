"""Only new52 table/provenance/cumulative-resource controls; no real input."""
from pathlib import Path
from copy import deepcopy
import sys,os,json,time,resource,traceback
ROOT=Path(__file__).resolve().parent
resource.setrlimit(resource.RLIMIT_CPU,(12,320)) # Preserve fake-worker inheritance ceiling.
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,2*1024**3))
def protect(event,args):
    if event=='open' and args and isinstance(args[0],(str,bytes,os.PathLike)):
        p=Path(os.fsdecode(args[0])).resolve()
        if p.is_relative_to(ROOT.parent) and not p.is_relative_to(ROOT):raise PermissionError('P5 control only own public/artificial material')
sys.addaudithook(protect)
from continuation_contract import *
from contract import validate_bundle,METHODS
from io_utils import file_hash,atomic_json,load_json
from authority_v2 import require_complete_references,LAUNCH,check_authority_objects
from controller import run_artificial,exact_zero,check_storage
from administration import validate_rows
from process_control import wait_started

def expect(exc,fn):
    try:fn()
    except exc:return
    raise AssertionError('expected '+str(exc))
def make_bundle(d):
    return dict(schema='cross-inference-control-bundle/v2',scope='ARTIFICIAL_ONLY',scientific_plan_json=d['original_science_json'],scientific_runs=d['all56_runs'],execution_mode=MODE,continuation_bindings=bindings(d),runs=d['execution_runs'],
        pins=dict(scientific_contract_sha256=SCIENCE,local_bridge_sha256='3abdc38ed11ef68613906cbbe1e6c35dae4e8c56cfa4e16d61b02c782ee08699',external_bridge_sha256='f546b64b82daec438a2b78a2effc4ede131025023ad17e7796def23bafd62d6e',controller_closure_sha256=file_hash(ROOT/'CODE_CLOSURE.json'),entropy_sha256=ENTROPY,data_contract_sha256='a1ce9ee118c06cd2d72b0cff3cd28c6358f89fdbfeaed4ca5423ba9cc49ed690',protocol_sha256='a'*64),
        dispatch={m:dict(kind='FAKE_ONLY',worker_policy=m,worker_code_sha256=file_hash(ROOT/'fake_worker.py'),worker_ready_sha256='b'*64,interpreter=sys.executable) for m in METHODS},limits=d['resource_accounting']['per_case'],study_limits=d['resource_accounting']['original_global'],controller_limits=d['resource_accounting']['controller_effective'])
def main(out):
    d=load_design();bundle=make_bundle(d);bound,ctx=validate_bundle(bundle)
    assert len(bound['runs'])==52 and len(json.loads(bound['scientific_plan_json'])['runs'])==56 and bound['runs'][0]['slot']==4 and bound['runs'][-1]['slot']==55
    for slot in range(4):expect(PermissionError,lambda slot=slot:require_worker_run(d['all56_runs'][slot],d))
    for mutation in ('oldslot','missing','duplicate','boolslot','changedproof','wrongmode','wrongscience'):
        bad=deepcopy(bundle)
        if mutation=='oldslot':bad['runs'][0]=deepcopy(d['all56_runs'][0])
        elif mutation=='missing':bad['runs'].pop()
        elif mutation=='duplicate':bad['runs'][-1]=bad['runs'][0]
        elif mutation=='boolslot':bad['runs'][0]['slot']=True
        elif mutation=='changedproof':bad['continuation_bindings']['unclaimed_proof_sha256']='0'*64
        elif mutation=='wrongmode':bad['execution_mode']='RECOVERY_REUSE_ZERO_START'
        else:bad['scientific_plan_json']+=' '
        expect((ValueError,PermissionError),lambda bad=bad:validate_bundle(bad))
    final=dict(bundle=bundle,entropy_binding_mode=MODE,continuation_bindings=bindings(d),study_root=d['new_execution_root'],composite_root=d['composite_root'],entropy_output_path=d['entropy']['path'])
    hs=dict(continuation_plan=DESIGN,unclaimed_proof=PROOF,entropy=ENTROPY,final_protocol='a'*64,core_ready='b'*64,auditor_ready='c'*64)
    assert origin_hashes(final,hs)==ORIGIN and claim_context(final,hs)==dict(no_redraw=True,actual_study=True,**{k+'_sha256':v for k,v in ORIGIN.items()})
    for mutation in ('oldzero','resign','replaceentropy'):
        f=deepcopy(final);h=dict(hs)
        if mutation=='oldzero':f['entropy_binding_mode']='RECOVERY_REUSE_ZERO_START';f['zero_start_recovery']={}
        elif mutation=='resign':f['entropy_output_path']='/tmp/NEW_ENTROPY_NOT_ALLOWED'
        else:h['entropy']='d'*64
        expect(ValueError,lambda:origin_hashes(f,h))
    expect(PermissionError,lambda:forbid_recovery_draw(final));expect(PermissionError,lambda:forbid_recovery_draw({}))
    impl={k:'e'*64 for k in ('collector_manifest_sha256','collector_closure_sha256','composite_admin_manifest_sha256','composite_admin_closure_sha256')}
    cp=dict(schema='fixed56-disjoint-composite-protocol/v1',status='FROZEN_BEFORE_UNCLAIMED52_EXECUTION',final_protocol_sha256=hs['final_protocol'],currentstudy_root=d['new_execution_root'],composite_root=d['composite_root'],continuation_bindings=bindings(d),implementation_bindings=impl)
    ch=dict(hs,composite_protocol='f'*64)
    ready=dict(status='READY_FOR_BOUND_DISJOINT56_COMPOSITE',final_protocol_sha256=hs['final_protocol'],composite_protocol_sha256=ch['composite_protocol'],continuation_bindings=bindings(d),implementation_bindings=impl)
    validate_composite(cp,ready,ch,d)
    wrong=deepcopy(ready);wrong['implementation_bindings']=dict(impl,collector_manifest_sha256='0'*64)
    expect(ValueError,lambda:validate_composite(cp,wrong,ch,d))
    expect(PermissionError,lambda:require_complete_references({},LAUNCH))
    assert {'continuation_plan','unclaimed_proof','composite_protocol','composite_ready'}<=set(LAUNCH)
    # Three small resource cases only: CPU reservation, cumulative storage,
    # and original monotonic deadline before an already-present startup/GO.
    assert cumulative_cpu(120,18000,238,d)==20000 and cumulative_cpu(120,18000,239,d)>20000
    limits=d['resource_accounting']['original_global'];new=dict(files=limits['files']-181-256,logical_bytes=limits['logical_bytes']-14053928-4194304,allocated_bytes=limits['allocated_bytes']-14618624-16777216,free_disk_bytes=limits['free_disk_floor_bytes'])
    check_storage(cumulative_storage(new,d),limits,study=True)
    bad=dict(new,files=new['files']+1);expect(RuntimeError,lambda:check_storage(cumulative_storage(bad,d),limits,study=True))
    stop=d['resource_accounting']['wall_absolute_deadline_utc_ns'];clock=GlobalClock(d,utc_ns=stop-5*10**9,monotonic_ns=10**12)
    assert clock.remaining(10**12)==5 and clock.remaining(10**12+5*10**9)==0
    restored=GlobalClock.from_record(clock.record,d,utc_ns=stop-4*10**9,monotonic_ns=10**12+10**9);assert restored.record==clock.record
    wrong=dict(clock.record,deadline_monotonic_ns=clock.record['deadline_monotonic_ns']+1);expect(ValueError,lambda:GlobalClock.from_record(wrong,d,utc_ns=stop-4*10**9,monotonic_ns=10**12+10**9))
    class Expired:
        def require(self):raise TimeoutError('synthetic original deadline expired before GO')
    stage=out/'deadline_stage';stage.mkdir();atomic_json(stage/'WORKER_STARTED.json',dict(artificial=True))
    expect(TimeoutError,lambda:wait_started(None,stage,{},time.monotonic()+1,clock=Expired()));assert not (stage/'GO.json').exists()
    rows=[dict(run=r,context=ctx,status='UNRUN_GLOBAL_STOP',charge=exact_zero(),completion_win=False,scientific_adjudication='UNKNOWN',private_results_decoded=False) for r in bundle['runs']]
    validate_rows(rows,ctx,bundle)
    wrong=deepcopy(rows);wrong[0]['run']=d['all56_runs'][0];expect(ValueError,lambda:validate_rows(wrong,ctx,bundle))
    # One new fake slot4 lifecycle, then51 explicitly unrun rows. No algorithm.
    study=ROOT/'artificial_runs/continuation52_one_fake_slot4';study.parent.mkdir(exist_ok=True)
    result=run_artificial(bundle,study,stop_after=1)
    barrier=load_json(study/'ALL_SLOTS_TERMINAL.json',2097152)
    assert result['worker_launches']==1 and barrier['planned_slot_count']==52 and len(barrier['rows'])==52 and barrier['rows'][0]['run']['slot']==4 and barrier['scientific_planned_slot_count']==56
    assert not any((study/f'ROW_{i:03d}.json').exists() for i in range(4)) and all((study/f'ROW_{i:03d}.json').is_file() for i in range(4,56))
    return dict(status='PASS_FOCUSED_UNCLAIMED52_CONTROLS',scope='ARTIFICIAL_METADATA_AND_ONE_FAKE_WORKER_NOT_ACTUAL_AUTHORITY',table_and_provenance_mutations=10,three_resource_cases=['CPUdebit1642','storageolddebit+compositereserve','originaldeadline-beforeGO'],synthetic_terminal_rows=52,real_fake_workers=1,actual_methods_or_inputs_or_RNG_or_Source=0,no_old_passed_or_full300_rerun=True,CPU_seconds=time.process_time())
if __name__=='__main__':
    out=ROOT/'continuation_attempt_01';out.mkdir(exist_ok=False)
    try:r=main(out)
    except BaseException as exc:
        atomic_json(out/'RESULTS.json',dict(status='FAIL_RETAINED',error_type=type(exc).__name__,message=str(exc),traceback=traceback.format_exc(),CPU_seconds=time.process_time()));raise
    atomic_json(out/'RESULTS.json',r);print(json.dumps(r,sort_keys=True),flush=True)
