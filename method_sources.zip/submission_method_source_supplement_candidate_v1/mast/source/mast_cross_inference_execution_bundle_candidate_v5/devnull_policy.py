"""Narrow Linux standard-descriptor exception; no persistent output path."""
import os,stat,sys

def fixed_devnull_standard_io(path,mode,flags):
    if not sys.platform.startswith('linux') or type(flags) is not int:return False
    try:literal=os.fsdecode(os.fspath(path))
    except (TypeError,ValueError):return False
    # Do not let a different pathname/symlink inherit the device exception.
    if literal!='/dev/null':return False
    if mode is not None and mode not in ('r','rb','r+','rb+','r+b','w','wb','w+','wb+','w+b'):return False
    allowed=os.O_ACCMODE|os.O_CREAT|os.O_TRUNC|getattr(os,'O_CLOEXEC',0)|getattr(os,'O_LARGEFILE',0)
    if flags&~allowed or flags&os.O_ACCMODE not in (os.O_RDONLY,os.O_WRONLY,os.O_RDWR):return False
    if flags&(os.O_CREAT|os.O_TRUNC) and flags&os.O_ACCMODE==os.O_RDONLY:return False
    try:info=os.stat('/dev/null',follow_symlinks=False)
    except OSError:return False
    # On trusted Linux/dev, create/truncate flags on this existing character
    # device do not create a persistent regular file. No hostile-FS claim.
    return stat.S_ISCHR(info.st_mode) and os.major(info.st_rdev)==1 and os.minor(info.st_rdev)==3
