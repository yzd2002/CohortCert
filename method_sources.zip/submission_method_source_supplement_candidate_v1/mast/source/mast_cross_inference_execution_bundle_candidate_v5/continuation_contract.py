"""Exact public continuation contract, original entropy and cumulative limits.

No reference payload, rank record, old private file or Source reader is here.
This file is copied byte-for-byte into the separate administrative verifier.
"""
from pathlib import Path
from hashlib import sha256
import json,math,os,time
MODE='CONTINUATION_UNCLAIMED_SUFFIX52_ORIGINAL_RANKS'
DESIGN='bd097a5af9195daf799fd8c5fe2d0a6ad1a7533773ad683424f051f2b880aa2a'
PROOF='edc181681a7697e0ab40ac621bc0f4a2e7a02ececddec82d1ebde0f8bdf53aec'
SCIENCE='2aa107395b7b8689707abaec4e5228318db1371a0b02c9fbac76610e19732624'
ENTROPY='0d4c760d5cf8fed33ad73a502cc7c5d7bb3d0de232161b166629b8a9a25360ff'
CLAIM='337b0095c7bb1ce8a08c31a5f6600ba80c45736126541793fd9bd31933f39ad2'
SOURCE_SEAL='a06b6fadee5c7d2502db3a28efc99335d69b64a7cb12c0b0f3481cd576f71398'
SOURCE_ADMIN='07a10599e61210074a28693600af5865c827b1859cc24d52e9b1587d074a09c1'
ORIGIN=dict(final_protocol='ff7b7dd9731e8838e4128bd8e778c214831ea5641e09dd21842ca4ee86fb7840',core_ready='9e450689ff8f023fd06d316e4e7b84766947342ceb4e7eaf411e473a02126b53',auditor_ready='3bf40272e455ea49c74a274079eab39411931dfab25dd1bf30f52bed9f2f095f')
ROOT=Path(__file__).resolve().parent
AUTHORITY_ROOT=ROOT.parent/'mast_bound56_unclaimed52_authority_v1'
CURRENT_PATHS={name:str(AUTHORITY_ROOT/filename) for name,filename in [('final_protocol','FINAL_PROTOCOL.json'),('core_ready','CORE_READY.json'),('auditor_ready','AUDITOR_READY.json'),('launch_ready','LAUNCH_READY.json')]}
def canonical(x):return (json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()
def digest(x):return sha256(canonical(x)).hexdigest()
def strict(a,b):
    if type(a) is not type(b):return False
    if type(b) is dict:return set(a)==set(b) and all(strict(a[k],v) for k,v in b.items())
    if type(b) is list:return len(a)==len(b) and all(strict(x,y) for x,y in zip(a,b))
    return a==b
def integer(x,low,high):
    if type(x) is not int or not low<=x<=high:raise ValueError('plain continuation integer range')
    return x
def parse_design(raw):
    if type(raw) is str:raw=raw.encode()
    if type(raw) is not bytes or len(raw)>2097152 or sha256(raw).hexdigest()!=DESIGN:raise ValueError('complete fixed continuation plan bytes required')
    d=json.loads(raw);s=json.loads(d['original_science_json']);proof_raw=d['unclaimed_proof']['public_raw_json']
    if sha256(d['original_science_json'].encode()).hexdigest()!=SCIENCE or d['original_science_sha256']!=SCIENCE or sha256(proof_raw.encode()).hexdigest()!=PROOF or d['unclaimed_proof']['sha256']!=PROOF:raise ValueError('original full science or independent52 proof changed')
    p=json.loads(proof_raw);runs=s['runs']
    if len(runs)!=56 or not strict(d['all56_runs'],runs) or not strict(d['execution_runs'],runs[4:]) or d['retained_slots']!=list(range(4)) or d['execution_slots']!=list(range(4,56)):raise ValueError('exact56 scientific frame and disjoint52 execution required')
    for i,row in enumerate(runs):
        integer(row['slot'],0,55);integer(row['replicate_id'],0,7)
        if row['slot']!=i:raise ValueError('global ordinal changed')
    if p['schema']!='independent-bound56-unclaimed-suffix52-attestation/v1' or p['status']!='VERIFIED_RETAINED_PREFIX4_AND_UNCLAIMED_SUFFIX52' or p['eligible_slots']!=list(range(4,56)) or p['retained_slots']!=list(range(4)) or p['eligible_unclaimed_first_execution_count']!=52 or p['not_all_zero_start'] is not True or p['private_content_decoded'] is not False or p['actual_rank_values_or_label_payload_or_Source_touched'] is not False:raise ValueError('independent eligibility scope differs')
    if p['source_terminal_status_counts']!={'WORKER_SEALED':3,'CENSORED_UNKNOWN':1,'UNRUN_GLOBAL_STOP':52} or p['slot3_unknown_exact_tail_preserved'] is not True or p['source_controller']['same_process_live'] is not False:raise ValueError('retained started cases may never be retried')
    if len(p['eligible_cases'])!=52:raise ValueError('every unclaimed case needs evidence')
    for e,run in zip(p['eligible_cases'],runs[4:]):
        if not strict(e['run'],run) or type(e['slot']) is not int or e['slot']!=run['slot'] or e['original_status']!='UNRUN_GLOBAL_STOP' or any(e[k] is not True for k in ('all_claim_child_GO_fee_private_markers_absent','eligible_for_first_execution_only','slot_directory_absent')):raise ValueError('only exact unclaimed first executions')
    retained=d['retained_source']
    if retained['external_seal_sha256']!=SOURCE_SEAL or retained['admin_permission_sha256']!=SOURCE_ADMIN or p['source_external_seal_sha256']!=SOURCE_SEAL or p['source_admin_permission_sha256']!=SOURCE_ADMIN or p['original_entropy_sha256']!=ENTROPY:raise ValueError('exact sealed old source provenance')
    e=d['entropy']
    if e['binding_mode']!=MODE or e['sha256']!=ENTROPY or e['draw_claim_sha256']!=CLAIM or e['new_OS_study_draws']!=0 or e['original48_draws_unchanged'] is not True or any(e['original_'+k+'_sha256']!=v for k,v in ORIGIN.items()):raise ValueError('original entropy origin required; no redraw/re-sign')
    a=d['resource_accounting']
    if not strict(a['original_global'],s['resources']['study']) or not strict(a['per_case'],s['resources']['per_method']) or not strict(a['controller_effective'],s['resources']['controller']):raise ValueError('scientific resource ceilings changed')
    if a['CPU_cap_based_debit']!=1642 or a['CPU_remaining']!=18358 or a['CPU_remaining']+a['CPU_cap_based_debit']!=a['original_global']['CPU_seconds']:raise ValueError('cumulative CPU reservation differs')
    if a['wall_absolute_deadline_utc_ns']!=a['wall_anchor_mtime_ns']+172800*10**9:raise ValueError('no fresh study wall allowance')
    if {k:a['old_storage_debit'][k] for k in ('files','logical_bytes','allocated_bytes')}!={'files':181,'logical_bytes':14053928,'allocated_bytes':14618624} or a['composite_reserve']!={'files':256,'logical_bytes':4194304,'allocated_bytes':16777216}:raise ValueError('fixed storage debit/reserve changed')
    return d
def load_design():
    p=ROOT/'inputs/CONTINUATION_PLAN.json'
    if p.is_symlink() or p.stat().st_size>2097152:raise ValueError('fixed local public plan required')
    return parse_design(p.read_bytes())
def bindings(d=None):
    d=load_design() if d is None else d
    return dict(continuation_plan_sha256=DESIGN,unclaimed_proof_sha256=PROOF,scientific_all56_slots_sha256=digest(d['all56_runs']),execution_slots_sha256=digest(d['execution_runs']),retained_source_external_seal_sha256=SOURCE_SEAL,retained_source_admin_permission_sha256=SOURCE_ADMIN)
def validate_execution(bundle,d=None):
    d=load_design() if d is None else d
    if bundle.get('execution_mode')!=MODE or not strict(bundle.get('continuation_bindings'),bindings(d)) or bundle.get('scientific_plan_json')!=d['original_science_json'] or not strict(bundle.get('scientific_runs'),d['all56_runs']) or not strict(bundle.get('runs'),d['execution_runs']):raise ValueError('exact52 control table distinct from original56 science')
    if bundle.get('scope')=='FINAL_BOUND_ACTUAL' and bundle.get('pins',{}).get('entropy_sha256')!=ENTROPY:raise ValueError('continuation bundle pins literal original entropy, never a fresh placeholder')
    for row in bundle['runs']:require_worker_run(row,d)
    return d
def validate_final(final,hashes=None,d=None):
    d=validate_execution(final['bundle'],d)
    if final.get('entropy_binding_mode')!=MODE or 'zero_start_recovery' in final or not strict(final.get('continuation_bindings'),bindings(d)) or final.get('study_root')!=d['new_execution_root'] or final.get('composite_root')!=d['composite_root'] or final.get('entropy_output_path')!=d['entropy']['path']:raise ValueError('exact continuation roots/origin, never consumed zero-start exception')
    if hashes is not None:
        if hashes.get('continuation_plan')!=DESIGN or hashes.get('unclaimed_proof')!=PROOF:raise ValueError('externally expected complete BD/EDC references required')
        if 'entropy' in hashes and hashes['entropy']!=ENTROPY:raise ValueError('original entropy file cannot be replaced')
    return d
def require_worker_run(run,d=None):
    d=load_design() if d is None else d
    if type(run) is not dict or type(run.get('slot')) is not int or not 4<=run['slot']<=55 or not strict(run,d['execution_runs'][run['slot']-4]):raise PermissionError('P5 only permits first execution of original global slots4..55;0..3 forbidden')
def origin_hashes(final,current_hashes):validate_final(final,current_hashes);return dict(ORIGIN)
def claim_context(final,current_hashes):return dict(no_redraw=True,actual_study=True,**{k+'_sha256':v for k,v in origin_hashes(final,current_hashes).items()})
def forbid_recovery_draw(final):raise PermissionError('P5 continuation always reuses original ranks; all actual entropy generation forbidden')
def validate_composite(protocol,ready,hashes,d=None):
    d=load_design() if d is None else d;expected=bindings(d)
    if protocol.get('schema')!='fixed56-disjoint-composite-protocol/v1' or protocol.get('status')!='FROZEN_BEFORE_UNCLAIMED52_EXECUTION' or protocol.get('final_protocol_sha256')!=hashes['final_protocol'] or protocol.get('currentstudy_root')!=d['new_execution_root'] or protocol.get('composite_root')!=d['composite_root'] or not strict(protocol.get('continuation_bindings'),expected):raise ValueError('pre-execution disjoint composite protocol required')
    keys={'collector_manifest_sha256','collector_closure_sha256','composite_admin_manifest_sha256','composite_admin_closure_sha256'}
    impl=ready.get('implementation_bindings')
    if ready.get('status')!='READY_FOR_BOUND_DISJOINT56_COMPOSITE' or ready.get('final_protocol_sha256')!=hashes['final_protocol'] or ready.get('composite_protocol_sha256')!=hashes['composite_protocol'] or not strict(ready.get('continuation_bindings'),expected) or type(impl) is not dict or set(impl)!=keys:raise ValueError('independent composite implementation/protocol readiness required')
    for value in impl.values():
        if type(value) is not str or len(value)!=64 or any(c not in '0123456789abcdef' for c in value):raise ValueError('composite implementation SHA')
    if protocol.get('implementation_bindings')!=impl:raise ValueError('composite protocol/code readiness differs')
    return expected
class GlobalClock:
    def __init__(self,d=None,*,utc_ns=None,monotonic_ns=None):
        d=load_design() if d is None else d
        utc=time.time_ns() if utc_ns is None else utc_ns;mono=time.monotonic_ns() if monotonic_ns is None else monotonic_ns
        self.record=dict(schema='fixed-continuation-global-wall-clock/v1',deadline_utc_ns=d['resource_accounting']['wall_absolute_deadline_utc_ns'],anchor_utc_ns=utc,anchor_monotonic_ns=mono,deadline_monotonic_ns=mono+max(0,d['resource_accounting']['wall_absolute_deadline_utc_ns']-utc))
    @classmethod
    def from_record(cls,record,d=None,*,utc_ns=None,monotonic_ns=None):
        d=load_design() if d is None else d;expected_keys={'schema','deadline_utc_ns','anchor_utc_ns','anchor_monotonic_ns','deadline_monotonic_ns'}
        if type(record) is not dict or set(record)!=expected_keys or record['schema']!='fixed-continuation-global-wall-clock/v1':raise ValueError('complete global wall context')
        for k in expected_keys-{'schema'}:integer(record[k],0,1<<64)
        if record['deadline_utc_ns']!=d['resource_accounting']['wall_absolute_deadline_utc_ns'] or record['deadline_monotonic_ns']!=record['anchor_monotonic_ns']+max(0,record['deadline_utc_ns']-record['anchor_utc_ns']):raise ValueError('original absolute deadline relation')
        utc=time.time_ns() if utc_ns is None else utc_ns;mono=time.monotonic_ns() if monotonic_ns is None else monotonic_ns
        if record['anchor_monotonic_ns']>mono or abs((utc-record['anchor_utc_ns'])-(mono-record['anchor_monotonic_ns']))>10**9:raise ValueError('inconsistent or future monotonic clock anchor')
        answer=object.__new__(cls);answer.record=dict(record);return answer
    def remaining(self,monotonic_ns=None):return max(0.0,(self.record['deadline_monotonic_ns']-(time.monotonic_ns() if monotonic_ns is None else monotonic_ns))/10**9)
    def require(self,monotonic_ns=None):
        if self.remaining(monotonic_ns)<=0:raise TimeoutError('original cumulative study wall deadline reached')
    def deadline(self):return self.record['deadline_monotonic_ns']/10**9
def cumulative_cpu(controller,children,live,d=None):
    d=load_design() if d is None else d
    if any(type(v) not in (int,float) or not math.isfinite(v) or v<0 for v in (controller,children,live)):raise ValueError('nonnegative measured CPU only')
    return d['resource_accounting']['CPU_cap_based_debit']+controller+children+live
def cumulative_storage(new,d=None):
    d=load_design() if d is None else d;a=d['resource_accounting'];out={}
    for k in ('files','logical_bytes','allocated_bytes'):out[k]=integer(new[k],0,1<<50)+a['old_storage_debit'][k]+a['composite_reserve'][k]
    out['free_disk_bytes']=integer(new['free_disk_bytes'],0,1<<64);return out
def include_sibling_storage(root,observed):
    root=Path(root);answer=dict(observed)
    for suffix in ('.LAUNCH_CLAIM.json','.LAUNCH_RECEIPT.json','.ADMIN_CONTROLLER.log','.CONTROLLER_STDERR.log','.EXTERNAL_SEAL.json'):
        for tail in ('','.partial'):
            p=root.parent/(root.name+suffix+tail)
            if p.is_symlink():raise ValueError('symlink in canonical study sibling storage')
            try:s=p.stat()
            except FileNotFoundError:continue
            if not p.is_file():raise ValueError('nonregular study sibling')
            answer['files']+=1;answer['logical_bytes']+=s.st_size;answer['allocated_bytes']+=s.st_blocks*512
    return answer
def barrier_fields(bundle,d=None):
    d=validate_execution(bundle,d)
    return dict(execution_mode=MODE,continuation_bindings=bindings(d),scientific_planned_slot_count=56,execution_global_slots=list(range(4,56)))
