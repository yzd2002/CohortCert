"""Two new bounded control children; never runs any actual scope or method."""
from pathlib import Path
import os,resource,subprocess,time,json,sys
ROOT=Path(__file__).resolve().parent;ADMIN=ROOT.parent/'mast_independent_admin52_verifier_candidate_v1'
resource.setrlimit(resource.RLIMIT_CPU,(5,320)) # Childfake needs320 inheritance ceiling.
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,2*1024**3))
if (ROOT/'CONTROLS_RESOURCE.json').exists():raise FileExistsError('one explicit newcontrol attempt only')
env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1');records=[]
for role,base,script in [('P5',ROOT,'continuation_controls.py'),('Admin52',ADMIN,'continuation_admin_controls.py')]:
    before=resource.getrusage(resource.RUSAGE_CHILDREN);start=time.monotonic()
    with (base/'CONTROLS_ATTEMPT_01.log').open('xb') as f:
        p=subprocess.Popen(['nice','-n','10','/root/miniconda3/envs/cohortcert/bin/python','-B',str(base/script)],cwd=base,env=env,stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT,close_fds=True)
        try:rc=p.wait(timeout=180)
        except subprocess.TimeoutExpired:p.kill();rc=p.wait()
    after=resource.getrusage(resource.RUSAGE_CHILDREN);used=after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime
    records.append(dict(role=role,returncode=rc,waited=True,child_and_descendant_CPU_seconds=used,wall_seconds=time.monotonic()-start,child_peak_RSS_bytes=after.ru_maxrss*1024))
    if rc:break
record=dict(records=records,aggregate_child_CPU_seconds=sum(x['child_and_descendant_CPU_seconds'] for x in records),wrapper_CPU_seconds=time.process_time(),new_scope_total_CPU_cap=40,static_reserved=5,completion_reserved=5,actual_methods_or_RNG_or_Source_actions=0)
(ROOT/'CONTROLS_RESOURCE.json').write_text(json.dumps(record,sort_keys=True,indent=2)+'\n');print(json.dumps(record,sort_keys=True),flush=True)
assert record['aggregate_child_CPU_seconds']<=30
raise SystemExit(0 if len(records)==2 and all(x['returncode']==0 for x in records) else 1)
