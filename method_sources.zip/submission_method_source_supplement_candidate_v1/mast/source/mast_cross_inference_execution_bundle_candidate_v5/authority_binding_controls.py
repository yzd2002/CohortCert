"""Pure new52 authority graph, synthetic header/rank objects, no capability."""
from pathlib import Path
from hashlib import sha256
from copy import deepcopy
import os,sys,json,time,resource,traceback
ROOT=Path(__file__).resolve().parent
resource.setrlimit(resource.RLIMIT_CPU,(3,4));resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2))
def protect(event,args):
    if event=='open' and args and isinstance(args[0],(str,bytes,os.PathLike)):
        p=Path(os.fsdecode(args[0])).resolve()
        if p.is_relative_to(ROOT.parent) and not p.is_relative_to(ROOT):raise PermissionError('synthetic authority fixture only')
sys.addaudithook(protect)
from continuation_contract import *
from authority_v2 import check_authority_objects,DATA_CONTRACT,DATA_MANIFEST,LOCAL,EXTERNAL
from method_dispatch import route_plan
from reference_schema import MODES
from io_utils import atomic_json
def main():
    d=load_design();roles=('final_protocol','protocol_settings','core_ready','worker_ready','controller_ready','worker_manifest','controller_manifest','code_closure','environment_binding','entropy','launch_ready','auditor_ready','continuation_plan','unclaimed_proof','composite_protocol','composite_ready')
    hs={k:sha256(('ARTIFICIAL_ONLY/'+k).encode()).hexdigest() for k in roles};hs.update(continuation_plan=DESIGN,unclaimed_proof=PROOF,entropy=ENTROPY)
    methods=[m['id'] for m in json.loads(d['original_science_json'])['methods']]
    settings=dict(schema='fixed-released-vector-study-settings/v2',data_contract_sha256=DATA_CONTRACT,N=dict(A=100,B=100,C=100),mode_ids=list(MODES),request_alpha='1/20',budgets=[75,150,225,300],physical_fee_unit='accepted_whole14_vector_attempt',local_paid_pilot_per_group=5,local_prior='1/2 Beta(1,1)+1/2 Beta(1+s_p,6-s_p)',method_specs={m:route_plan(m) for m in methods})
    b=dict(schema='cross-inference-control-bundle/v2',scope='FINAL_BOUND_ACTUAL',status='FINAL_FIXED_PROTOCOL',execution_mode=MODE,continuation_bindings=bindings(d),scientific_plan_json=d['original_science_json'],scientific_runs=d['all56_runs'],runs=d['execution_runs'],pins=dict(scientific_contract_sha256=SCIENCE,local_bridge_sha256=LOCAL,external_bridge_sha256=EXTERNAL,controller_closure_sha256=hs['code_closure'],entropy_sha256=ENTROPY,data_contract_sha256=DATA_CONTRACT,protocol_sha256=hs['protocol_settings']),limits=d['resource_accounting']['per_case'],study_limits=d['resource_accounting']['original_global'],controller_limits=d['resource_accounting']['controller_effective'],dispatch={m:dict(kind='BOUND_PRIVATE_WORKER',worker_policy=m,worker_code_sha256='a'*64,worker_ready_sha256=hs['worker_ready'],interpreter='/ARTIFICIAL_INTERPRETER_NOT_EXECUTED') for m in methods})
    ab=dict(auditor_manifest_sha256='b'*64,auditor_closure_sha256='c'*64,audit_policy_sha256='d'*64,scientific_contract_sha256=SCIENCE,native_environment_sha256=hs['environment_binding'])
    final=dict(schema='final-cross-inference-execution-protocol/v2',status='FINAL_EXECUTION_AUTHORIZED',execution_authorized=True,bundle=b,resources_status='FINAL_LABEL_BLIND_REVIEWED',data_manifest_sha256=DATA_MANIFEST,study_root=d['new_execution_root'],composite_root=d['composite_root'],entropy_binding_mode=MODE,entropy_output_path=d['entropy']['path'],continuation_bindings=bindings(d),audit_bindings=ab)
    base={k+'_sha256':hs[k] for k in ('final_protocol','protocol_settings','worker_ready','controller_ready','worker_manifest','controller_manifest','code_closure','environment_binding')}
    impl={k:'e'*64 for k in ('collector_manifest_sha256','collector_closure_sha256','composite_admin_manifest_sha256','composite_admin_closure_sha256')}
    objects=dict(final_protocol=final,protocol_settings=settings,continuation_plan=d,unclaimed_proof=json.loads(d['unclaimed_proof']['public_raw_json']),worker_ready=dict(status='READY_FOR_BOUND_PRIVATE_WORKER',manifest_sha256=hs['worker_manifest'],code_closure_sha256=hs['code_closure']),controller_ready=dict(status='READY_FOR_BOUND_CONTROL_PLANE',manifest_sha256=hs['controller_manifest'],code_closure_sha256=hs['code_closure']),core_ready=dict(status='READY_FOR_BOUND_CORE_AND_ENTROPY',bindings=base,method_access_before_entropy=False),auditor_ready=dict(status='READY_FOR_BOUND_POSTBARRIER_AUDIT',final_protocol_sha256=hs['final_protocol'],manifest_sha256=ab['auditor_manifest_sha256'],code_closure_sha256=ab['auditor_closure_sha256'],audit_policy_sha256=ab['audit_policy_sha256'],scientific_contract_sha256=SCIENCE,native_environment_sha256=hs['environment_binding'],composite_protocol_sha256=hs['composite_protocol'],composite_ready_sha256=hs['composite_ready'],continuation_bindings=bindings(d)),composite_protocol=dict(schema='fixed56-disjoint-composite-protocol/v1',status='FROZEN_BEFORE_UNCLAIMED52_EXECUTION',final_protocol_sha256=hs['final_protocol'],currentstudy_root=d['new_execution_root'],composite_root=d['composite_root'],continuation_bindings=bindings(d),implementation_bindings=impl),composite_ready=dict(status='READY_FOR_BOUND_DISJOINT56_COMPOSITE',final_protocol_sha256=hs['final_protocol'],composite_protocol_sha256=hs['composite_protocol'],continuation_bindings=bindings(d),implementation_bindings=impl),entropy=dict(schema='bound-uniform-factoradic-entropy/v1',scope='ACTUAL_UNIFORM_EXTERNAL_RANK_PROVENANCE',sampling='OS_UNIFORM_BITS_REJECTION',before_method_access=True,**{k+'_sha256':v for k,v in ORIGIN.items()},draw_claim_sha256=CLAIM,replicates={str(i):{g:dict(pilot_rank=0,formal_rank=0) for g in 'ABC'} for i in range(8)}))
    wanted=dict(base,core_ready_sha256=hs['core_ready'],entropy_sha256=ENTROPY,auditor_ready_sha256=hs['auditor_ready'],composite_protocol_sha256=hs['composite_protocol'],composite_ready_sha256=hs['composite_ready'])
    objects['launch_ready']=dict(status='READY_FOR_BOUND_ACTUAL_LAUNCH',actual_launch_authorized=True,bindings=wanted,study_root=d['new_execution_root'],planned_slots_sha256=digest(b['runs']),resources_sha256=digest({k:b[k] for k in ('limits','study_limits','controller_limits')}))
    result=check_authority_objects(objects,hs,launch=True);assert len(result[0]['runs'])==52 and result[2]==d['new_execution_root']
    for kind in ('wrongCP','wrongAuditComposite','oldEntropyPlaceholder'):
        bad=deepcopy(objects)
        if kind=='wrongCP':bad['composite_protocol']['currentstudy_root']='/ARTIFICIAL_WRONG_ROOT'
        elif kind=='wrongAuditComposite':bad['auditor_ready']['composite_ready_sha256']='f'*64
        else:bad['final_protocol']['bundle']['pins']['entropy_sha256']='EXTERNAL_AFTER_CORE_READY'
        try:check_authority_objects(bad,hs,launch=True)
        except (ValueError,PermissionError):pass
        else:raise AssertionError('new authority binding mutation accepted:'+kind)
    return dict(status='PASS_NEW52_PURE_AUTHORITY_GRAPH',fixture='ARTIFICIAL_HEADERS_AND_ZERO_RANK_VALUES_NOT_ACTUAL_AUTHORITY',positive_and_three_new_mutations=True,ActualPermit_or_EntropyPermit_created=0,actual_rank_file_reads_or_OS_draws=0,actual_methods_or_Source_actions=0,CPU_seconds=time.process_time())
if __name__=='__main__':
    out=ROOT/'authority_binding_attempt_01';out.mkdir(exist_ok=False)
    try:r=main()
    except BaseException as exc:
        atomic_json(out/'RESULTS.json',dict(status='FAIL_RETAINED',error_type=type(exc).__name__,message=str(exc),traceback=traceback.format_exc(),CPU_seconds=time.process_time()));raise
    atomic_json(out/'RESULTS.json',r);print(json.dumps(r,sort_keys=True),flush=True)
