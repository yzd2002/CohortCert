"""Two-stage prospective authority; missing evidence rejects before file I/O."""
from dataclasses import dataclass
from bound_entropy_origin import origin_hashes,claim_context,forbid_recovery_draw
from pathlib import Path
from math import factorial
import os,sys
from contract import METHODS,digest,validate_bundle
from gate import ROOT,NotReady
from io_utils import file_hash,load_json,object_hash
from continuation_contract import validate_final,validate_composite,bindings as continuation_bindings,strict,require_worker_run,GlobalClock,CURRENT_PATHS

DATA_MANIFEST='f6ee2cb34103bdf4921e5e01d633dd2ce47b5e4477db391167cd104a8f7fbbe7'
DATA_CONTRACT='a1ce9ee118c06cd2d72b0cff3cd28c6358f89fdbfeaed4ca5423ba9cc49ed690'
LOCAL='3abdc38ed11ef68613906cbbe1e6c35dae4e8c56cfa4e16d61b02c782ee08699'
EXTERNAL='f546b64b82daec438a2b78a2effc4ede131025023ad17e7796def23bafd62d6e'
BASE=('final_protocol','protocol_settings','core_ready','worker_ready','controller_ready','worker_manifest','controller_manifest','code_closure','environment_binding','continuation_plan','unclaimed_proof')
ENTROPY=BASE+('auditor_ready',)
LAUNCH=BASE+('entropy','launch_ready','auditor_ready','composite_protocol','composite_ready')
_CAP=object()

def require_complete_references(refs,keys):
    # No resolve/exists/hash/open occurs before every external reference is given.
    if type(refs) is not dict or set(refs)!=set(keys):raise NotReady('all final external authority paths and expected hashes are required before IO')
    for name in keys:
        item=refs[name]
        if type(item) is not dict or set(item)!={'path','sha256'} or type(item['path']) is not str or not item['path'].startswith('/'):raise NotReady('explicit external reference missing')
        if name in CURRENT_PATHS and item['path']!=CURRENT_PATHS[name]:raise NotReady('current continuation authority canonical path required')
        try:digest(item['sha256'])
        except ValueError:raise NotReady('external expected SHA missing')

def _read_references(refs,keys):
    require_complete_references(refs,keys)
    observed={};objects={}
    for name in keys:
        path=Path(refs[name]['path'])
        if file_hash(path)!=refs[name]['sha256']:raise NotReady('external metadata hash mismatch: '+name)
        observed[name]=refs[name]['sha256'];objects[name]=load_json(path,8388608 if name=='environment_binding' else 2097152)
    return objects,observed

def validate_entropy(record,bound,hashes,*,final=None):
    origin=origin_hashes({} if final is None else final,hashes)
    if record.get('schema')!='bound-uniform-factoradic-entropy/v1' or record.get('scope')!='ACTUAL_UNIFORM_EXTERNAL_RANK_PROVENANCE' or record.get('sampling')!='OS_UNIFORM_BITS_REJECTION' or record.get('before_method_access') is not True or record.get('final_protocol_sha256')!=origin['final_protocol'] or record.get('core_ready_sha256')!=origin['core_ready'] or record.get('auditor_ready_sha256')!=origin['auditor_ready']:raise NotReady('entropy stage/provenance binding')
    try:digest(record.get('draw_claim_sha256'))
    except ValueError:raise NotReady('persistent entropy draw claim binding required')
    reps=record.get('replicates')
    if type(reps) is not dict or set(reps)!={str(i) for i in range(8)}:raise NotReady('all8 entropy replicates')
    for groups in reps.values():
        if type(groups) is not dict or set(groups)!=set('ABC'):raise NotReady('entropy group identity')
        for row in groups.values():
            if type(row) is not dict or set(row)!={'pilot_rank','formal_rank'}:raise NotReady('entropy phases')
            for key,N in [('pilot_rank',100),('formal_rank',95)]:
                if type(row[key]) is not int or not 0<=row[key]<factorial(N):raise NotReady('strict uniform-rank range/type')
    return reps

def check_authority_objects(objects,hashes,*,launch):
    """Pure checks usable on synthetic objects; creates no actual capability."""
    final=objects['final_protocol']
    if final.get('schema')!='final-cross-inference-execution-protocol/v2' or final.get('status')!='FINAL_EXECUTION_AUTHORIZED' or final.get('execution_authorized') is not True:raise NotReady('draft is not final execution protocol')
    bundle,context=validate_bundle(final['bundle'])
    continuation=validate_final(final,hashes)
    if not strict(objects['continuation_plan'],continuation) or not strict(objects['unclaimed_proof'],__import__('json').loads(continuation['unclaimed_proof']['public_raw_json'])):raise NotReady('current full BD/EDC public metadata differs')
    from contract import parse_bound_plan
    science,_=parse_bound_plan(bundle)
    if bundle['scope']!='FINAL_BOUND_ACTUAL' or final.get('resources_status')!='FINAL_LABEL_BLIND_REVIEWED':raise NotReady('actual resources not final')
    from method_dispatch import route_plan
    from reference_schema import MODES
    expected_settings=dict(schema='fixed-released-vector-study-settings/v2',data_contract_sha256=DATA_CONTRACT,N=dict(A=100,B=100,C=100),mode_ids=list(MODES),
        request_alpha='1/20',budgets=[75,150,225,300],physical_fee_unit='accepted_whole14_vector_attempt',
        local_paid_pilot_per_group=5,local_prior='1/2 Beta(1,1)+1/2 Beta(1+s_p,6-s_p)',method_specs={m:route_plan(m) for m in METHODS})
    if objects['protocol_settings']!=expected_settings or any(type(n) is not int for n in objects['protocol_settings'].get('N',{}).values()) or type(objects['protocol_settings'].get('local_paid_pilot_per_group')) is not int:raise NotReady('frozen request/method settings differ from implemented seven routes')
    expected_components=[dict(false_includes_ties=True,left='A',mode_id=m,operator='>',right=r,threshold='0 exact') for m in MODES for r in ('B','C')]
    if science.get('N')!=expected_settings['N'] or any(type(n) is not int for n in science['N'].values()) or science.get('modes')!=list(MODES) or science.get('components')!=expected_components or science.get('primary',{}).get('budgets')!=expected_settings['budgets']:raise NotReady('scientific request differs from fixed complete28 implementation')
    if any(c.get('false_includes_ties') is not True for c in science['components']):raise NotReady('strict comparison tie semantics changed')
    if bundle['pins']['local_bridge_sha256']!=LOCAL or bundle['pins']['external_bridge_sha256']!=EXTERNAL or bundle['pins']['data_contract_sha256']!=DATA_CONTRACT or bundle['pins']['protocol_sha256']!=hashes['protocol_settings'] or bundle['pins']['controller_closure_sha256']!=hashes['code_closure'] or bundle['pins']['entropy_sha256']!='0d4c760d5cf8fed33ad73a502cc7c5d7bb3d0de232161b166629b8a9a25360ff':raise NotReady('fixed code/data/protocol or two-stage entropy pin')
    if final.get('data_manifest_sha256')!=DATA_MANIFEST:raise NotReady('fixed f6ee data identity')
    for name,status,manifest in [('worker_ready','READY_FOR_BOUND_PRIVATE_WORKER','worker_manifest'),('controller_ready','READY_FOR_BOUND_CONTROL_PLANE','controller_manifest')]:
        ready=objects[name]
        if ready.get('status')!=status or ready.get('manifest_sha256')!=hashes[manifest] or ready.get('code_closure_sha256')!=hashes['code_closure']:raise NotReady('independent implementation readiness')
    for method,d in bundle['dispatch'].items():
        if method not in METHODS:raise NotReady('additional selector not independently registered in this code version')
        if d['kind']!='BOUND_PRIVATE_WORKER' or d['worker_ready_sha256']!=hashes['worker_ready']:raise NotReady('worker authority/kind mismatch')
    bindings={name+'_sha256':hashes[name] for name in ('final_protocol','protocol_settings','worker_ready','controller_ready','worker_manifest','controller_manifest','code_closure','environment_binding')}
    core=objects['core_ready']
    if core.get('status')!='READY_FOR_BOUND_CORE_AND_ENTROPY' or core.get('bindings')!=bindings or core.get('method_access_before_entropy') is not False:raise NotReady('pre-entropy CoreReady bindings')
    study=final.get('study_root')
    if type(study) is not str or not study.startswith('/') or Path(study).is_relative_to(ROOT/'artificial_runs'):raise NotReady('fixed actual study identity')
    audit=objects['auditor_ready']
    if audit.get('status')!='READY_FOR_BOUND_POSTBARRIER_AUDIT' or audit.get('final_protocol_sha256')!=hashes['final_protocol']:raise NotReady('independent gated auditor absent')
    audit_bindings=final.get('audit_bindings')
    fields={'auditor_manifest_sha256','auditor_closure_sha256','audit_policy_sha256','scientific_contract_sha256','native_environment_sha256'}
    if type(audit_bindings) is not dict or set(audit_bindings)!=fields:raise NotReady('complete fixed auditor implementation/policy bindings required')
    for value in audit_bindings.values():
        try:digest(value)
        except ValueError:raise NotReady('canonical auditor binding hash required')
    expected_audit=dict(manifest_sha256=audit_bindings['auditor_manifest_sha256'],
        code_closure_sha256=audit_bindings['auditor_closure_sha256'],
        audit_policy_sha256=audit_bindings['audit_policy_sha256'],
        scientific_contract_sha256=audit_bindings['scientific_contract_sha256'],
        native_environment_sha256=audit_bindings['native_environment_sha256'])
    if any(audit.get(key)!=value for key,value in expected_audit.items()) or audit_bindings['scientific_contract_sha256']!=bundle['pins']['scientific_contract_sha256'] or audit_bindings['native_environment_sha256']!=hashes['environment_binding']:raise NotReady('auditor code/policy/scientific/environment binding mismatch')
    origin_hashes(final,hashes) # explicit recovery never falls back to current provenance
    if not launch:return bundle,context,study,None
    validate_composite(objects['composite_protocol'],objects['composite_ready'],hashes,continuation)
    if audit.get('composite_protocol_sha256')!=hashes['composite_protocol'] or audit.get('composite_ready_sha256')!=hashes['composite_ready'] or audit.get('continuation_bindings')!=continuation_bindings(continuation):raise NotReady('current composite-aware scientific auditor required before case4')
    ranks=validate_entropy(objects['entropy'],bundle,hashes,final=final)
    wanted=dict(bindings,core_ready_sha256=hashes['core_ready'],entropy_sha256=hashes['entropy'],auditor_ready_sha256=hashes['auditor_ready'],composite_protocol_sha256=hashes['composite_protocol'],composite_ready_sha256=hashes['composite_ready'])
    ready=objects['launch_ready']
    if ready.get('status')!='READY_FOR_BOUND_ACTUAL_LAUNCH' or ready.get('actual_launch_authorized') is not True or ready.get('bindings')!=wanted or ready.get('study_root')!=study or ready.get('planned_slots_sha256')!=object_hash(bundle['runs']) or ready.get('resources_sha256')!=object_hash(dict(limits=bundle['limits'],study_limits=bundle['study_limits'],controller_limits=bundle['controller_limits'])):raise NotReady('LaunchReady fullplan/resources/entropy binding')
    return bundle,object_hash(dict(bundle_sha256=context,launch_ready_sha256=hashes['launch_ready'],entropy_sha256=hashes['entropy'])),study,ranks

def verify_runtime(refs,objects):
    expected={'worker_manifest':ROOT/'DELIVERY_MANIFEST.json','controller_manifest':ROOT/'DELIVERY_MANIFEST.json','code_closure':ROOT/'CODE_CLOSURE.json'}
    for name,path in expected.items():
        if Path(refs[name]['path']).resolve()!=path.resolve():raise NotReady('runtime artifact path differs from frozen implementation')
    allowed={}
    for row in objects['code_closure']['files']:
        p=(ROOT/row['path']).resolve()
        if not p.is_relative_to(ROOT) or file_hash(p)!=row['sha256']:raise NotReady('worker/controller closure changed')
        allowed[str(p)]=row['sha256']
    worker_hash=file_hash(ROOT/'bound_worker.py')
    for mapping in objects['final_protocol']['bundle']['dispatch'].values():
        if mapping['worker_code_sha256']!=worker_hash:raise NotReady('dispatch worker bytes differ from the bound worker')
    env=objects['environment_binding']
    if env.get('schema')!='complete-worker-environment-binding/v1' or env.get('complete_loaded_code_allowlist') is not True:raise NotReady('complete frozen environment binding required')
    interpreters=env.get('interpreters')
    if type(interpreters) is not list or not interpreters:raise NotReady('explicit interpreter byte identities required')
    executable=Path(sys.executable).resolve();matched=False
    for item in interpreters:
        p=Path(item['path']).resolve()
        if file_hash(p)!=item['sha256']:raise NotReady('interpreter bytes changed')
        if p==executable:matched=True
    if not matched:raise NotReady('current interpreter not externally bound')
    for row in env['files']:
        p=Path(row['path']).resolve()
        if file_hash(p)!=row['sha256']:raise NotReady('environment code changed')
        allowed[str(p)]=row['sha256']
    for module in tuple(sys.modules.values()):
        name=getattr(module,'__file__',None)
        if not name:continue
        p=Path(name).resolve()
        if p.is_relative_to(ROOT.parent) and str(p) not in allowed:raise NotReady('loaded unbound research/environment code')
    if 'entropy' in objects:
        output=Path(objects['final_protocol']['entropy_output_path'])
        if Path(refs['entropy']['path']).resolve()!=output.resolve():raise NotReady('entropy file is not the fixed external output')
        claim=output.with_name(output.name+'.DRAW_CLAIM.json')
        if file_hash(claim)!=objects['entropy']['draw_claim_sha256']:raise NotReady('entropy no-redraw claim bytes changed')
        record=load_json(claim,4096)
        if record!=claim_context(objects['final_protocol'],{name:item['sha256'] for name,item in refs.items()}):raise NotReady('entropy no-redraw claim authority changed')
    return allowed

@dataclass(frozen=True)
class EntropyPermit:
    capability:object; hashes:dict; bundle:dict; output_path:str
@dataclass(frozen=True)
class ControllerPermit:
    capability:object; hashes:dict; bundle:dict; context:str; study_root:str; ranks:dict
@dataclass(frozen=True)
class ActualPermit:
    capability:object; hashes:dict; bundle:dict; context:str; study_root:str; run:dict; ranks:dict; process_pid:int; refs:dict; global_clock:dict
def authorize_entropy(refs=None):
    objects,hashes=_read_references(refs,ENTROPY)
    forbid_recovery_draw(objects['final_protocol'])
    bundle,context,study,_=check_authority_objects(objects,hashes,launch=False);verify_runtime(refs,objects)
    output=objects['final_protocol'].get('entropy_output_path')
    if type(output) is not str or not output.startswith('/') or Path(output).is_relative_to(Path(study)):raise NotReady('fixed external entropy output path required')
    return EntropyPermit(_CAP,hashes,bundle,output)
def authorize_controller_launch(refs=None):
    objects,hashes=_read_references(refs,LAUNCH);bundle,context,study,ranks=check_authority_objects(objects,hashes,launch=True);verify_runtime(refs,objects)
    return ControllerPermit(_CAP,hashes,bundle,context,study,ranks)
def authorize_actual_worker(refs=None,*,run_id=None,outdir=None,admission=None):
    require_complete_references(refs,LAUNCH)
    if type(run_id) is not str or type(outdir) is not str or type(admission) is not dict or admission.get('scope')!='actual_bound' or Path(sys.argv[0]).resolve()!=ROOT/'bound_worker.py':raise NotReady('private actual worker role/admission required')
    require_worker_run(admission.get('run'))
    wall=GlobalClock.from_record(admission.get('global_clock'));wall.require()
    parent=os.getppid()
    if parent==15744 or admission.get('parent_pid')!=parent:raise NotReady('worker parent identity')
    from process_control import birth
    if admission.get('parent_birth')!=birth(parent):raise NotReady('worker parent birth')
    p=authorize_controller_launch(refs);matches=[r for r in p.bundle['runs'] if r['run_id']==run_id]
    if len(matches)!=1 or Path(outdir).resolve()!=Path(p.study_root)/'slots'/run_id or admission.get('run')!=matches[0] or admission.get('context')!=p.context:raise NotReady('exact planned private slot')
    require_worker_run(matches[0]);wall.require()
    return ActualPermit(_CAP,p.hashes,p.bundle,p.context,p.study_root,matches[0],p.ranks,os.getpid(),refs,dict(admission['global_clock']))
def require_actual_permit(permit):
    if type(permit) is not ActualPermit or permit.capability is not _CAP or permit.process_pid!=os.getpid():raise NotReady('private bound actual permit required before data IO')
    require_worker_run(permit.run);GlobalClock.from_record(permit.global_clock).require()
def require_entropy_permit(permit):
    if type(permit) is not EntropyPermit or permit.capability is not _CAP:raise NotReady('pre-entropy authority required before OS draws')
