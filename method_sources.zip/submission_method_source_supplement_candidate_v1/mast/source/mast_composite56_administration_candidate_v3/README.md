# Recursive composite administration candidate C3

This package implements the administrative composition of five immutable whole
cases from the genuine prior composite and the first executions of global
identities 5 through 55. It is an author implementation awaiting independent
review. It grants no ActualLaunch permission and makes no scientific decision.

The exact interface is frozen in `CONSUMER_INTERFACE_V3.json`. The current Final
comes first; the recursive CompositeProtocol binds that Final and this reviewed
collector/admin package; independent CompositeReady, AuditorReady and
LaunchReady follow. CurrentFinal cannot bind the hash of its future protocol.
Protocol schema is `fixed56-disjoint-composite-protocol/v2`, status
`FROZEN_BEFORE_UNCLAIMED51_EXECUTION`, scope
`ACTUAL_FIXED_RECURSIVE_DISJOINT56`, with `currentstudy_root` (not `study_root`).

`build_protocol.py` uses eight explicit public refs: current Final, new worker
manifest/closure, new admin manifest/closure/Ready, and implementation
manifest/closure. It reads metadata only. No future source seal or outcome is
required to construct this prospective protocol. Its retained-composite object
is exactly the frozen design object; its direct `source_specs` is exactly
`{new51}`. The first five pointer templates are the original complete dicts.

`collector.py` accepts the exact eight COMMON_REFS in the interface. It first
loads the externally pinned retained ten-ref file
`a1d47e52b743ff514ddd662542eeb5b323e42b734367104092ff649cab362f92`
and calls every gate in `retained_composite_consumer.py`. That file is a
byte-identical local copy of the prior reviewed consumer
`d64287536a64ca33a372af35a83f9501dd0cceef31d7856a4a8f8ce6018134d1`.
The old composite, original source inventories, code/Ready authorities, fee
metadata, source rows, resource flags and external seal/permission are verified
by that unchanged implementation. C3 cannot substitute a summary for this call.

The new 51-slot barrier, external seal, independent permission, current Final,
worker/admin code closure and LaunchReady must then pass their complete public
gates. Only after these gates may private source files be hashed opaquely for
integrity; no private JSON is decoded. Public path denial precedes file hashing.
There is no actual entropy/rank file reader or OS randomness entry point.

The collector creates only a new composite tree and its canonical external
seal. `COMPOSITE_INDEX.json` schema `disjoint56-composite-admin-index/v2`
contains all 56 cases in the original order. Cases 0--4 retain their original
source ids, contexts, rows, roots, fee histories and provenance. New cases 5--55
have source id `new51`. Source registries are exactly `retained`, `new52` and
`new51`; the two old registries are unchanged. Both retained Native startup
censors keep exact total `null` and tail `UNKNOWN`; no retry, promotion, source
relabeling or prefix splicing exists.

`composite_verifier.py` accepts COMMON_REFS plus `composite_external_seal` and
independently repeats the recursive gates, full index/pointer comparison and
complete opaque inventory. It writes a canonical external permission with
schema `disjoint56-composite-admin-permission/v2` and status
`VERIFIED_COMPOSITE_56_SLOTS_ADMIN_ONLY`. `load_verified_composite` additionally
requires this permission as the tenth exact external ref, repeats all gates,
and returns the original per-source case pointers for the scientific auditor.

The scientific auditor must copy **both consumer files and the original
codec.py** into its own independently reviewed code closure. The outer consumer
imports only the standard library and the local retained consumer; the latter
imports only the standard library and local codec. Do not import a research
module from the old package. The returned `cases` and `sources` fields preserve
the prior API. `source_scientific_credit_allowed` has three plain boolean flags.
The first two come from the recursive gate; new51 resource ineligibility does
not erase either old flag. Administrative eligibility is never a scientific win.

## Cumulative resources and preserved history

The exact public design is
`ab04747f91d2cb5bfa6f634a484762b406b7b336ed9149e361e0ac51c523910c`.
Its science, proof, 56/51 literal run tables, roots and full resource object are
pinned without modification. The original global CPU cap remains 20,000 s;
2,084 s is the fixed cap-based reservation, leaving 17,916 s. This reservation
is not measured runtime or a universal timer-delay bound. The original absolute
deadline remains 2026-11-06 00:46:50.943372 UTC. There is no new wall allowance.

The final administrative gate counts current file count, logical bytes and
allocated bytes in the three old study roots, their canonical log/launch/seal
siblings, the old genuine composite with its external seal/permission, new51
with its canonical siblings, and the new composite with external metadata.
Every member of the fixed old operational snapshot must still exist with its
original logical size. Current allocated storage is reported separately; the
charged old storage never drops below its fixed debit of 253 files, 14,302,381
logical bytes and 15,106,048 allocated bytes. Extra old files are counted too.
The new composite must fit its original reserve (256 files, 4 MiB logical,
16 MiB allocated), and original global caps/free-disk floor remain enforced.

The unchanged nested C2 gate also rechecks the current free-disk floor. If a
later disk shortage invalidates its fixed permission, it fails closed; C3 does
not bypass this stricter old gate or rewrite its flags. Any later inventory or
resource change that invalidates a permission similarly blocks admission.

## Validation and limits

The new finite controls use owned artificial metadata only. Seventeen recursive
component controls passed in 0.240776303 measured CPU s before the final
stat-only snapshot-preservation guard was added. Their exact executed driver is
preserved in `history/`; the instrumented retained-gate callback was invoked five
times. These controls exercise the new recursive integration without rerunning
the already passed C2 suite. The production retained consumer bytes are checked
exactly; its original full-gate validation evidence is inherited, not re-created
by the callback. The driver now includes the additional required snapshot
inventory for a future independent run; that updated driver has not been rerun.

Five additional finite controls passed for the added snapshot guard: complete
inventory, omitted inventory, changed logical size, escaped path, and deleted
old file. Its reported in-body CPU increment was 0.0 at clock resolution; that
is not a zero-runtime-cost claim (the child had a 5 s hard CPU limit).
No old completed control suite was repeated. The 40 s author-work ceiling,
including 5 s static/hash, at most 30 s new controls and 5 s reserve, remains the
declared scope. Interpreter startup and preparation are not silently assigned
zero cost or charged as new online scientific evidence.

No actual collector, verifier, study, scientific auditor, Native method, model,
rank draw or Source process was run for implementation. No real private
packet, label vector, rank value, source map, worker log or scientific result
was decoded. Input copies are public design/refs/storage metadata only.
Independent review, concrete current authorities and all late genuine source
gates remain required. There is no self-signed implementation Ready or claim of
acceptance, coverage, method superiority or scientific success.
