"""New finite recursive-component fixtures only; no old suite or method runs.

The retained full gate is an instrumented artificial callback here. Its source
identity is checked by production code; the already passed C2 tests are not
rerun. Every runtime data path is under this script's new owned fixture root.
"""
from pathlib import Path
from copy import deepcopy
from hashlib import sha256
import json,resource,time
import composite_consumer as C
import build_protocol as B
import collector as K
import composite_verifier as V
from composite_io import write_new

def run():
    start=time.process_time();r=Path(__file__).resolve().parent/'artificial_recursive_attempt_01'
    r.mkdir(mode=0o700);receipts=[]
    def note(name,fn):fn();receipts.append(dict(control=name,status='PASS'))
    def reject(fn):
        try:fn()
        except (C.NotReady,C.EvidenceUnknown,KeyError,FileNotFoundError):return
        raise AssertionError('finite negative control was accepted')
    def put(path,value):
        path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(C.canonical(value));return dict(path=str(path),sha256=C.hash_file(path))
    def h(value):return sha256(value.encode()).hexdigest()
    def bundle_code(name):
        root=r/name;root.mkdir();files=[]
        for n in C.STAT_FILES:
            p=root/n;p.write_text('artificial protected framework sentinel\n');files.append(dict(path=n,bytes=p.stat().st_size,sha256=C.hash_file(p)))
        return put(root/'DELIVERY_MANIFEST.json',dict(schema='ARTIFICIAL_MANIFEST')),put(root/'CODE_CLOSURE.json',dict(files=files))
    worker_m,worker_c=bundle_code('worker');admin_m,admin_c=bundle_code('admin');impl_m,impl_c=bundle_code('implementation')
    allruns=[dict(slot=i,run_id='ARTIFICIAL_CASE_%03d'%i,method_id='ARTIFICIAL_METHOD_%d'%(i%7),replicate_id=i//7) for i in range(56)]
    oldroots=[r/'mast_bound56_actual_study_v1',r/'retained_source',r/'new52_source'];oldcomp=r/'old_composite';newroot=r/'new51_source';comproot=r/'new_composite';auth=r/'authority'
    for p in oldroots+[oldcomp,newroot,auth]:p.mkdir()
    for p in oldroots:
        put(p/'OLD_PUBLIC_SENTINEL.json',dict(artificial=True))
        for suffix in ('ADMIN_CONTROLLER.log','CONTROLLER_STDERR.log','EXTERNAL_SEAL.json','LAUNCH_CLAIM.json','LAUNCH_RECEIPT.json'):put(p.parent/(p.name+'.'+suffix),dict(artificial=True))
    for suffix in ('EXTERNAL_SEAL.json','ADMIN_PERMISSION.json'):put(oldcomp.parent/(oldcomp.name+'.'+suffix),dict(artificial=True))
    def old_registry(sid,root):
        return dict(source_id=sid,root=str(root),context='ARTIFICIAL_'+sid,selected_slots=list(range(4)) if sid=='retained' else list(range(4,56)),final_protocol_ref=put(r/(sid+'_final.json'),dict(bundle=dict(pins=dict(protocol_sha256='7'*64)))),worker_manifest_ref=worker_m,worker_closure_ref=worker_c)
    registries=dict(retained=old_registry('retained',oldroots[1]),new52=old_registry('new52',oldroots[2]));oldcases=[]
    for run in allruns:
        i=run['slot'];sid='retained' if i<4 else 'new52';reg=registries[sid]
        charge=dict(exact_total=None,exact_tail='UNKNOWN',known_durable_submitted_prefix=0)
        oldcases.append(dict(run=run,source_id=sid,source_root=reg['root'],slot_root=str(Path(reg['root'])/'slots'/run['run_id']),row_path=str(Path(reg['root'])/f'ROW_{i:03d}.json'),row_sha256=h('oldrow'+str(i)),source_context=reg['context'],source_final_protocol_sha256=reg['final_protocol_ref']['sha256'],source_worker_manifest_sha256=worker_m['sha256'],source_worker_closure_sha256=worker_c['sha256'],source_external_seal_sha256='a'*64,source_admin_permission_sha256='b'*64,source_row=dict(run=run,status='CENSORED_UNKNOWN' if i in (3,4) else 'UNRUN_GLOBAL_STOP',charge=charge,context=reg['context']),whole_case=True,no_postmortem_promotion=True))
    oldindex=put(oldcomp/'COMPOSITE_INDEX.json',dict(cases=oldcases,sources=registries))
    oldrefs={n:put(r/'oldrefs'/(n+'.json'),dict(artificial=True,key=n)) for n in C.retained.CONSUMER_REFS}
    oldrefs['composite_external_seal']=dict(path=str(oldcomp)+'.EXTERNAL_SEAL.json',sha256=C.hash_file(str(oldcomp)+'.EXTERNAL_SEAL.json'))
    oldrefs['composite_admin_permission']=dict(path=str(oldcomp)+'.ADMIN_PERMISSION.json',sha256=C.hash_file(str(oldcomp)+'.ADMIN_PERMISSION.json'))
    retained_ref=put(r/'RETAINED_REFS.json',oldrefs)
    old=dict(root=str(oldcomp),external_seal_ref=oldrefs['composite_external_seal'],admin_permission_ref=oldrefs['composite_admin_permission'],index_ref=oldindex,consumer_refs=retained_ref,consumer_manifest_ref=oldrefs['implementation_manifest'],consumer_closure_ref=oldrefs['implementation_closure'],selected_slots=list(range(5)),whole_case_pointers=deepcopy(oldcases[:5]),no_source_row_or_context_rewrite=True)
    oldtot=dict(files=0,logical_bytes=0,allocated_bytes=0)
    for p in oldroots+[oldcomp]:
        s=C.sample_tree(p)
        for k in oldtot:oldtot[k]+=s[k]
    for p in oldroots:
        for suffix in ('ADMIN_CONTROLLER.log','CONTROLLER_STDERR.log','EXTERNAL_SEAL.json','LAUNCH_CLAIM.json','LAUNCH_RECEIPT.json'):C._add_file(oldtot,p.parent/(p.name+'.'+suffix),True)
    for suffix in ('EXTERNAL_SEAL.json','ADMIN_PERMISSION.json'):C._add_file(oldtot,oldcomp.parent/(oldcomp.name+'.'+suffix),True)
    members=[]
    paths=[q for root in oldroots+[oldcomp] for q in root.rglob('*') if q.is_file()]
    paths.extend(p.parent/(p.name+'.'+suffix) for p in oldroots for suffix in ('ADMIN_CONTROLLER.log','CONTROLLER_STDERR.log','EXTERNAL_SEAL.json','LAUNCH_CLAIM.json','LAUNCH_RECEIPT.json'))
    paths.extend(oldcomp.parent/(oldcomp.name+'.'+suffix) for suffix in ('EXTERNAL_SEAL.json','ADMIN_PERMISSION.json'))
    for path in sorted(paths):
        s=path.stat();members.append(dict(path=str(path),logical_bytes=s.st_size,allocated_bytes=s.st_blocks*512))
    snap=put(r/'OLD_STORAGE.json',dict(oldtot,members=members))
    policy=dict(original_global=dict(files=100000,logical_bytes=2**30,allocated_bytes=2**31,free_disk_floor_bytes=0,CPU_seconds=20000,wall_seconds=172800),per_case=dict(artificial='no method'),controller_effective=dict(artificial='no controller'),old_storage_debit=oldtot,old_storage_snapshot=snap,composite_reserve=dict(files=256,logical_bytes=4194304,allocated_bytes=16777216),wall_anchor_path=str(oldroots[0])+'.LAUNCH_CLAIM.json',CPU_cap_based_debit=2084,CPU_remaining=17916,wall_absolute_deadline_utc_ns=1793926010943372110)
    plan=dict(new_execution_root=str(newroot),composite_root=str(comproot),current_authority_root=str(auth),all56_runs=allruns,execution_runs=allruns[5:],retained_slots=list(range(5)),execution_slots=list(range(5,56)),retained_composite=old,resource_accounting=policy,entropy=dict(binding_mode='ARTIFICIAL_ORIGINAL_RANKS_METADATA_ONLY'))
    C.PLAN_SHA='c'*64;C.PROOF_SHA='d'*64;C.RETAINED_REFS_SHA=retained_ref['sha256'];C.SCIENCE_SHA=h('{}\n');C.ENTROPY_SHA='e'*64
    C.read_fixed_plan=lambda:deepcopy(plan);B.read_fixed_plan=C.read_fixed_plan
    old_verified=dict(cases=oldcases,sources=registries,composite_root=str(oldcomp),source_scientific_credit_allowed=dict(retained=True,new52=False))
    calls=[]
    def fake_retained(refs):
        assert C.equal(refs,oldrefs);calls.append('FULL_RETAINED_GATE_CALLBACK');return deepcopy(old_verified)
    C.retained.load_verified_composite=fake_retained
    # The only old consumer execution is the callback above. This child cannot
    # discover real roots through either reader's BASE or fixed-plan function.
    C.BASE=r;C.retained.BASE=r
    admin_ready=put(r/'ADMIN_READY.json',dict(status='READY_FOR_BOUND_INDEPENDENT_ADMIN_VERIFIER',manifest_sha256=admin_m['sha256'],code_closure_sha256=admin_c['sha256']))
    bundle=dict(runs=allruns[5:],scientific_runs=allruns,scientific_plan_json='{}\n',pins=dict(scientific_contract_sha256=C.SCIENCE_SHA,controller_closure_sha256=worker_c['sha256'],data_contract_sha256='a1ce9ee118c06cd2d72b0cff3cd28c6358f89fdbfeaed4ca5423ba9cc49ed690',protocol_sha256='7'*64),limits=policy['per_case'],controller_limits=policy['controller_effective'],study_limits=policy['original_global'],execution_mode=plan['entropy']['binding_mode'],continuation_bindings=C.continuation_bindings(plan))
    final=put(auth/'FINAL_PROTOCOL.json',dict(schema='final-cross-inference-execution-protocol/v2',status='FINAL_EXECUTION_AUTHORIZED',execution_authorized=True,study_root=str(newroot),composite_root=str(comproot),continuation_bindings=C.continuation_bindings(plan),entropy_binding_mode=plan['entropy']['binding_mode'],data_manifest_sha256='f6ee2cb34103bdf4921e5e01d633dd2ce47b5e4477db391167cd104a8f7fbbe7',bundle=bundle))
    buildrefs=dict(current_final_protocol=final,new_worker_manifest=worker_m,new_worker_closure=worker_c,new_admin_manifest=admin_m,new_admin_closure=admin_c,new_admin_ready=admin_ready,implementation_manifest=impl_m,implementation_closure=impl_c)
    protocol=B.make_protocol(buildrefs);cp=put(auth/'COMPOSITE_PROTOCOL.json',protocol)
    ready=put(auth/'COMPOSITE_READY.json',dict(status='READY_FOR_BOUND_DISJOINT56_COMPOSITE',final_protocol_sha256=final['sha256'],composite_protocol_sha256=cp['sha256'],continuation_bindings=C.continuation_bindings(plan),implementation_bindings=protocol['implementation_bindings']))
    lp=put(auth/'LAUNCH_READY.json',dict(status='READY_FOR_BOUND_ACTUAL_LAUNCH',actual_launch_authorized=True,study_root=str(newroot),planned_slots_sha256=C.digest(plan['execution_runs']),bindings=dict(final_protocol_sha256=final['sha256'],composite_protocol_sha256=cp['sha256'],composite_ready_sha256=ready['sha256'],entropy_sha256=C.ENTROPY_SHA,worker_manifest_sha256=worker_m['sha256'],controller_manifest_sha256=worker_m['sha256'],code_closure_sha256=worker_c['sha256'])))
    context=C.digest(dict(bundle_sha256=C.digest(bundle),launch_ready_sha256=lp['sha256'],entropy_sha256=C.ENTROPY_SHA));rows=[]
    for run in plan['execution_runs']:
        row=dict(run=run,context=context,status='UNRUN_GLOBAL_STOP',completion_win=False,scientific_adjudication='UNKNOWN',private_results_decoded=False,charge=dict(state='SEALED_EXACT',exact_total=0,exact_tail='KNOWN',known_durable_submitted_prefix=0))
        put(newroot/f'ROW_{run["slot"]:03d}.json',row);rows.append(row)
    inv=C.opaque_inventory(newroot);cb=C.continuation_bindings(plan)
    barrier=put(newroot/'ALL_SLOTS_TERMINAL.json',dict(schema='planned-slots-terminal-admin-barrier/v2',status='ALL_PLANNED_SLOTS_TERMINAL_ADMIN_ONLY',scope='FINAL_BOUND_ACTUAL',context=context,private_results_decoded=False,scientific_success='UNKNOWN',planned_slot_count=51,planned_slots_sha256=C.digest(plan['execution_runs']),continuation_bindings=cb,bundle_sha256=C.digest(bundle),rows=rows,inventory=inv))
    ns=put(str(newroot)+'.EXTERNAL_SEAL.json',dict(schema='planned-slots-external-admin-seal/v2',study_root=str(newroot),barrier_sha256=barrier['sha256'],context=context,private_results_decoded=False,planned_slot_count=51,planned_slots_sha256=C.digest(plan['execution_runs']),continuation_bindings=cb,inventory_sha256=C.digest(inv)))
    np=put(auth/'ALL51_ADMIN_PERMISSION.json',dict(status='VERIFIED_ALL_FINAL_51_SLOTS_ADMIN_ONLY',study_root=str(newroot),context=context,barrier_sha256=barrier['sha256'],private_results_decoded=False,scientific_success='UNKNOWN',planned_slot_count=51,planned_slots_sha256=C.digest(plan['execution_runs']),continuation_bindings=cb,bindings=dict(external_seal_sha256=ns['sha256'],final_protocol_sha256=final['sha256'],entropy_sha256=C.ENTROPY_SHA,admin_verifier_manifest_sha256=admin_m['sha256'],admin_verifier_ready_sha256=admin_ready['sha256']),inventory_sha256=C.digest(inv),resource_status='WITHIN_CUMULATIVE_FINAL_ADMIN_ONLY',source_scientific_credit_allowed=True,eligibility_is_not_scientific_success=True))
    refs=dict(composite_protocol=cp,composite_ready=ready,implementation_manifest=impl_m,implementation_closure=impl_c,retained_composite_refs=retained_ref,new_source_permission=np,new_source_external_seal=ns,new_source_launch_ready=lp)
    def protocol_positive():
        hs={k:v['sha256'] for k,v in refs.items()};C.validate_protocol(protocol,C.read_ref(ready),plan,hs)
        assert C.equal(protocol['pointer_templates'][:5],oldcases[:5]) and set(protocol['source_specs'])=={'new51'}
    note('builder_matches_frozen_recursive_interface',protocol_positive)
    note('missing_nested_ref_rejected_before_source_io',lambda:reject(lambda:C.load_source_authority({k:v for k,v in refs.items() if k!='retained_composite_refs'})))
    def bad_protocol():
        v=deepcopy(protocol);v['pointer_templates'][4]['source_id']='new51';reject(lambda:C.validate_protocol(v,C.read_ref(ready),plan,{k:x['sha256'] for k,x in refs.items()}))
    note('retained_native_case_cannot_be_reassigned',bad_protocol)
    authority=C.load_source_authority(refs)
    def exact_three():
        assert calls and C.equal(authority['cases'][:5],oldcases[:5]);assert set(authority['sources'])=={'retained','new52','new51'}
        assert C.equal(authority['sources']['retained'],registries['retained']) and C.equal(authority['sources']['new52'],registries['new52'])
        assert len(authority['cases'])==56 and [x['run']['slot'] for x in authority['cases']]==list(range(56))
    note('recursive_gate_called_and_original_five_two_registries_preserved',exact_three)
    def alias_control():
        result=C.expected_cases(plan,old_verified,authority['new_source']);result[0]['source_row']['context']='CORRUPT';result[5]['source_row']['context']='CORRUPT'
        assert oldcases[0]['source_row']['context']!='CORRUPT' and authority['new_source']['rows'][5]['context']!='CORRUPT'
    note('wholecase_snapshots_do_not_alias_sources',alias_control)
    def nested_badpin():
        v=deepcopy(retained_ref);v['sha256']='0'*64;before=len(calls);reject(lambda:C.load_retained_composite(v,plan));assert len(calls)==before
    note('nested_reference_pin_rejected_before_callback',nested_badpin)
    note('new51_context_mismatch_rejected',lambda:reject(lambda:C.verify_new_source(protocol['source_specs']['new51'],ns,np,plan,'WRONG_CONTEXT')))
    def source_badseal():
        v=deepcopy(ns);v['sha256']='0'*64;reject(lambda:C.verify_new_source(protocol['source_specs']['new51'],v,np,plan,context))
    note('new51_bad_external_seal_rejected',source_badseal)
    def both_censors():
        for i in (3,4):assert authority['cases'][i]['source_row']['charge']['exact_total'] is None and authority['cases'][i]['source_row']['charge']['exact_tail']=='UNKNOWN'
    note('both_retained_censor_expense_tails_remain_unknown',both_censors)
    def flags():
        a=deepcopy(authority);a['new_source']['permission']['source_scientific_credit_allowed']=False
        rr=C.resource_receipt(a);assert rr['source_scientific_credit_allowed']==dict(retained=True,new52=False,new51=False)
        assert authority['retained']['source_scientific_credit_allowed']==dict(retained=True,new52=False)
    note('new51_resource_ineligibility_does_not_erase_old_flags',flags)
    for key in ('files','logical_bytes','allocated_bytes'):
        def limit_control(key=key):
            a=deepcopy(authority);a['plan']['resource_accounting']['original_global'][key]=0
            rr=C.resource_receipt(a);assert key in rr['violations'] and rr['source_scientific_credit_allowed']==dict(retained=True,new52=False,new51=False)
        note('cumulative_actual_'+key+'_overrun_retains_old_flags',limit_control)
    def reserve_control():
        comproot.mkdir();put(comproot/'ARTIFICIAL_RESERVE_SENTINEL.json',dict(artificial=True))
        a=deepcopy(authority);a['plan']['resource_accounting']['composite_reserve']['logical_bytes']=0
        rr=C.resource_receipt(a);assert 'composite_logical_bytes' in rr['violations'];(comproot/'ARTIFICIAL_RESERVE_SENTINEL.json').unlink();comproot.rmdir()
    note('actual_composite_reserve_overrun_rejected_for_new51_credit',reserve_control)
    def refs_before_hash():
        original=C.retained.hash_file;opened=[]
        def spy(path):opened.append(str(path));return original(path)
        C.retained.hash_file=spy
        try:
            for name in ('ACTUAL_ENTROPY_RANKS.json','RUN_PACKET.json','private/SENTINEL.json'):
                before=len(opened);reject(lambda name=name:C.read_ref(dict(path=str(r/name),sha256='1'*64)));assert len(opened)==before
        finally:C.retained.hash_file=original
    note('forbidden_public_ref_denied_before_any_hash',refs_before_hash)
    result=K.collect(refs);sealref=dict(path=result['external_seal'],sha256=result['external_seal_sha256'])
    permission=V.verify(dict(refs,composite_external_seal=sealref));pref=put(str(comproot)+'.ADMIN_PERMISSION.json',permission)
    verified=C.load_verified_composite(dict(refs,composite_external_seal=sealref,composite_admin_permission=pref))
    def final_gate():
        assert len(verified['cases'])==56 and C.equal(verified['cases'][:5],oldcases[:5]);assert verified['source_scientific_credit_allowed']==dict(retained=True,new52=False,new51=True)
        assert verified['scientific_credit_allowed'] is False and verified['sources']['retained']['context']!=verified['sources']['new51']['context']
    note('new_recursive_collector_independent_verifier_consumer_complete_path',final_gate)
    def bad_composite_seal():
        v=deepcopy(sealref);v['sha256']='0'*64;reject(lambda:C.load_verified_composite(dict(refs,composite_external_seal=v,composite_admin_permission=pref)))
    note('bad_recursive_composite_seal_cannot_mint_admission',bad_composite_seal)
    elapsed=time.process_time()-start
    result=dict(schema='new-recursive-composite-finite-controls/v1',status='PASS',controls=receipts,control_count=len(receipts),CPU_seconds=elapsed,retained_gate_callback_calls=len(calls),old_passed_suite_rerun=False,actual_or_scientific_or_entropy_or_method_access=False,scope='owned artificial metadata only; instrumented retained gate, exact d642 bytes checked',self_signed_independent_Ready=False)
    put(r/'RESULTS.json',result);print(json.dumps(result,indent=2))

if __name__=='__main__':
    resource.setrlimit(resource.RLIMIT_CPU,(25,30));resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912));run()
