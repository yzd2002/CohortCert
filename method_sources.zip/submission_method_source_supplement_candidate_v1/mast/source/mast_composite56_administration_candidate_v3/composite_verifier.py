"""Independent-process recursive administrative recheck, no scientific score."""
from pathlib import Path
import argparse,json,resource,signal
from composite_consumer import (COMMON_REFS,complete_refs,load_source_authority,verify_index_and_seal,
    continuation_bindings,resource_receipt,digest,hash_file,load_public,NotReady)
from composite_io import write_new

def verify(refs=None):
    complete_refs(refs,COMMON_REFS+('composite_external_seal',))
    authority=load_source_authority({k:refs[k] for k in COMMON_REFS})
    index,seal,source_bindings=verify_index_and_seal(authority,refs['composite_external_seal'])
    resources=resource_receipt(authority);plan=authority['plan']
    bindings={k+'_sha256':v['sha256'] for k,v in refs.items()};bindings['final_protocol_sha256']=authority['protocol']['final_protocol_sha256']
    return dict(schema='disjoint56-composite-admin-permission/v2',status='VERIFIED_COMPOSITE_56_SLOTS_ADMIN_ONLY',composite_root=plan['composite_root'],bindings=bindings,continuation_bindings=continuation_bindings(plan),planned_slot_count=56,planned_slots_sha256=digest(plan['all56_runs']),index_sha256=seal['index_sha256'],inventory_sha256=seal['inventory_sha256'],source_bindings=source_bindings,private_results_decoded=False,scientific_success='UNKNOWN',resource_status=resources['resource_status'],scientific_credit_allowed=resources['scientific_credit_allowed'],source_scientific_credit_allowed=resources['source_scientific_credit_allowed'],cumulative_storage_at_verification=resources['cumulative_storage'],eligibility_is_not_scientific_success=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--refs',required=True);p.add_argument('--output',required=True);a=p.parse_args()
    resource.setrlimit(resource.RLIMIT_CPU,(20,25));resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912))
    signal.signal(signal.SIGALRM,lambda *_:(_ for _ in ()).throw(TimeoutError('recursive verification wall budget')));signal.alarm(3600)
    permission=verify(load_public(a.refs));root=Path(permission['composite_root']);out=root.parent/(root.name+'.ADMIN_PERMISSION.json')
    if Path(a.output).resolve()!=out:raise NotReady('canonical recursive permission output required')
    write_new(out,permission)
    print(json.dumps(dict(status=permission['status'],path=str(out),sha256=hash_file(out),resource_status=permission['resource_status'],source_scientific_credit_allowed=permission['source_scientific_credit_allowed'],private_results_decoded=False)),flush=True)
