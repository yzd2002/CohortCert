"""Copyable public/opaque composite gate; no inference or private JSON reader.

Imports only stdlib and the already frozen local codec.fee_accounting. The
scientific auditor may copy this source into its own reviewed code closure.
"""
from pathlib import Path
from hashlib import sha256
import json,math,os,shutil,stat
from codec import fee_accounting

BASE=Path(__file__).resolve().parent.parent
PLAN_SHA='bd097a5af9195daf799fd8c5fe2d0a6ad1a7533773ad683424f051f2b880aa2a'
SCIENCE_SHA='2aa107395b7b8689707abaec4e5228318db1371a0b02c9fbac76610e19732624'
ENTROPY_SHA='0d4c760d5cf8fed33ad73a502cc7c5d7bb3d0de232161b166629b8a9a25360ff'
PROOF_SHA='edc181681a7697e0ab40ac621bc0f4a2e7a02ececddec82d1ebde0f8bdf53aec'
COMMON_REFS=('composite_protocol','composite_ready','implementation_manifest','implementation_closure',
             'retained_source_permission','new_source_permission','new_source_external_seal','new_source_launch_ready')
CONSUMER_REFS=COMMON_REFS+('composite_external_seal','composite_admin_permission')
IMPL_KEYS={'collector_manifest_sha256','collector_closure_sha256','composite_admin_manifest_sha256','composite_admin_closure_sha256'}
TERMINAL={'WORKER_SEALED','WORKER_FAILED_CLOSED','CENSORED_UNKNOWN','START_FAILED_UNSUBMITTED','UNRUN_GLOBAL_STOP','CLAIM_CONFLICT_UNKNOWN'}
STAT_FILES=('core.py','policies.py','native_routes.py','sss_routes.py','sss_common_loggreedy.py','uits.py',
            'vendor_dual_certificate.py','execution_bridge.py','durable_cache.py','codec.py','reference_schema.py','method_dispatch.py','fee_adapter.py')

class NotReady(PermissionError):pass
class EvidenceUnknown(ValueError):pass

def canonical(x):return (json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()
def digest(x):return sha256(canonical(x)).hexdigest()
def hash_file(path):
    p=Path(path)
    if p.is_symlink() or not p.is_file():raise EvidenceUnknown('regular nonsymlink file required')
    h=sha256()
    with p.open('rb') as f:
        for block in iter(lambda:f.read(65536),b''):h.update(block)
    return h.hexdigest()
def sha(value):
    if type(value) is not str or len(value)!=64 or any(c not in '0123456789abcdef' for c in value):raise EvidenceUnknown('external64hex SHA required')
    return value
def integer(value,lo,hi):
    if type(value) is not int or not lo<=value<=hi:raise EvidenceUnknown('plain integer range')
    return value
def equal(a,b):
    if type(a) is not type(b):return False
    if type(b) is dict:return set(a)==set(b) and all(equal(a[k],v) for k,v in b.items())
    if type(b) is list:return len(a)==len(b) and all(equal(x,y) for x,y in zip(a,b))
    return a==b
def _pairs(rows):
    out={}
    for k,v in rows:
        if k in out:raise EvidenceUnknown('duplicate public JSON key')
        out[k]=v
    return out
def public_path(path):
    """Pure lexical role check before any file hash/open/stat operation."""
    p=Path(path)
    if '..' in p.parts or 'private' in p.parts or p.name in ('LOCKED_LABEL_VECTORS.json','RECORD_IDENTITIES.json','ACTUAL_ENTROPY_RANKS.json','RUN_PACKET.json','MAD_full_dataset.json'):
        raise NotReady('private/result/rank content is outside this reader')
    return p
def load_public(path,cap=16*1024**2):
    p=public_path(path)
    if p.is_symlink() or not p.is_file():raise EvidenceUnknown('public metadata must be regular nonsymlink')
    with p.open('rb') as f:raw=f.read(cap+1)
    if len(raw)>cap:raise EvidenceUnknown('public metadata byte bound')
    obj=json.loads(raw,object_pairs_hook=_pairs,parse_constant=lambda _:(_ for _ in ()).throw(EvidenceUnknown('nonfinite metadata')))
    todo=[(obj,0)];nodes=0
    while todo:
        x,depth=todo.pop();nodes+=1
        if nodes>2000000 or depth>64:raise EvidenceUnknown('public metadata shape bound')
        if type(x) is float and not math.isfinite(x):raise EvidenceUnknown('nonfinite metadata')
        if type(x) is dict:todo.extend((v,depth+1) for v in x.values())
        elif type(x) is list:todo.extend((v,depth+1) for v in x)
    return obj
def reference(item):
    if type(item) is not dict or set(item)!={'path','sha256'} or type(item['path']) is not str or not item['path'].startswith('/'):raise NotReady('absolute public reference and expectedSHA required')
    sha(item['sha256']);return item
def read_ref(item):
    reference(item)
    public_path(item['path'])
    if hash_file(item['path'])!=item['sha256']:raise NotReady('externally pinned public metadata changed')
    return load_public(item['path'])
def complete_refs(refs,names):
    if type(refs) is not dict or set(refs)!=set(names):raise NotReady('all composite external references required before source I/O')
    for item in refs.values():reference(item)
def path_inside(root,relative):
    if type(relative) is not str or not relative or relative.startswith('/'):raise EvidenceUnknown('canonical relative source path')
    root=Path(root).resolve();p=root/relative
    if p.is_symlink() or not p.resolve().is_relative_to(root) or p.relative_to(root).as_posix()!=relative:raise EvidenceUnknown('escaping source path')
    return p

def continuation_bindings(plan):
    return dict(continuation_plan_sha256=PLAN_SHA,unclaimed_proof_sha256=PROOF_SHA,
        scientific_all56_slots_sha256=digest(plan['all56_runs']),execution_slots_sha256=digest(plan['execution_runs']),
        retained_source_external_seal_sha256=plan['retained_source']['external_seal_sha256'],
        retained_source_admin_permission_sha256=plan['retained_source']['admin_permission_sha256'])

def read_fixed_plan():
    path=BASE/'mast_unclaimed52_continuation_design_v1/CONTINUATION_PLAN.json'
    if hash_file(path)!=PLAN_SHA:raise NotReady('fixedBD continuation design changed')
    plan=load_public(path)
    if plan['original_science_sha256']!=SCIENCE_SHA or sha256(plan['original_science_json'].encode()).hexdigest()!=SCIENCE_SHA:raise NotReady('fixed original scientific bytes')
    if sha256(plan['unclaimed_proof']['public_raw_json'].encode()).hexdigest()!=PROOF_SHA:raise NotReady('fixed independent unclaimed proof bytes')
    if plan['retained_slots']!=list(range(4)) or plan['execution_slots']!=list(range(4,56)) or not equal(plan['execution_runs'],plan['all56_runs'][4:]):raise NotReady('fixed disjoint full56 partition')
    return plan

def validate_protocol(protocol,ready,plan,hashes):
    if protocol.get('schema')!='fixed56-disjoint-composite-protocol/v1' or protocol.get('status')!='FROZEN_BEFORE_UNCLAIMED52_EXECUTION' or protocol.get('scope')!='ACTUAL_FIXED_DISJOINT56':raise NotReady('prospectively frozen actual composite protocol required')
    wanted=continuation_bindings(plan)
    if not equal(protocol.get('continuation_bindings'),wanted) or protocol.get('currentstudy_root')!=plan['new_execution_root'] or 'study_root' in protocol or protocol.get('composite_root')!=plan['composite_root']:raise NotReady('composite roots/continuation pins differ')
    if protocol.get('final_protocol_sha256')!=protocol.get('current_final_protocol',{}).get('sha256'):raise NotReady('current final protocol pin')
    impl=protocol.get('implementation_bindings')
    if type(impl) is not dict or set(impl)!=IMPL_KEYS:raise NotReady('complete collector/admin implementation bindings')
    for value in impl.values():sha(value)
    if impl['collector_manifest_sha256']!=hashes['implementation_manifest'] or impl['composite_admin_manifest_sha256']!=hashes['implementation_manifest'] or impl['collector_closure_sha256']!=hashes['implementation_closure'] or impl['composite_admin_closure_sha256']!=hashes['implementation_closure']:raise NotReady('reviewed common package differs')
    if ready.get('status')!='READY_FOR_BOUND_DISJOINT56_COMPOSITE' or ready.get('final_protocol_sha256')!=protocol['final_protocol_sha256'] or ready.get('composite_protocol_sha256')!=hashes['composite_protocol'] or not equal(ready.get('continuation_bindings'),wanted) or not equal(ready.get('implementation_bindings'),impl):raise NotReady('independent compositeReady graph missing')
    specs=protocol['source_specs']
    if type(specs) is not dict or set(specs)!={'retained','new52'}:raise NotReady('exactly two immutable source registries')
    old=plan['retained_source'];retained=specs['retained'];new=specs['new52']
    if retained['root']!=old['root'] or retained['selected_slots']!=list(range(4)) or retained['context']!=old['context'] or retained['final_protocol_ref']['sha256']!=old['final_protocol_sha256'] or retained['worker_manifest_ref']['sha256']!=old['worker_manifest_sha256'] or retained['worker_closure_ref']['sha256']!=old['worker_closure_sha256'] or retained['external_seal_ref']['sha256']!=old['external_seal_sha256'] or retained['admin_permission_path']!=old['admin_permission_path'] or retained['admin_permission_sha256']!=old['admin_permission_sha256']:raise NotReady('old source4 cannot be replaced')
    if new['root']!=plan['new_execution_root'] or new['selected_slots']!=list(range(4,56)) or not equal(new['final_protocol_ref'],protocol['current_final_protocol']) or new['context_policy']!='DERIVE_FROM_BOUND_NEW52_LAUNCH_READY':raise NotReady('new52 source fixed before methods')
    templates=protocol['pointer_templates']
    if type(templates) is not list or len(templates)!=56:raise NotReady('all56 prospective pointers required')
    proof=json.loads(plan['unclaimed_proof']['public_raw_json']);oldrows={x['slot']:x for x in proof['whole_row_bindings']}
    for i,(template,run) in enumerate(zip(templates,plan['all56_runs'])):
        sid='retained' if i<4 else 'new52';spec=specs[sid]
        expected=dict(run=run,source_id=sid,source_root=spec['root'],slot_root=str(Path(spec['root'])/'slots'/run['run_id']),row_path=str(Path(spec['root'])/f'ROW_{i:03d}.json'),source_context=old['context'] if i<4 else 'LATE_DERIVED_NEW52_CONTEXT',row_sha256=oldrows[i]['sha256'] if i<4 else 'LATE_EXACT_SOURCE_ROW_SHA',whole_case=True)
        if not equal(template,expected):raise NotReady('prospective pointer partition/context/identity changed')
    if not equal(protocol['resources'],plan['resource_accounting']):raise NotReady('composite cumulative resource policy changed')

def check_implementation(refs,objects):
    root=Path(refs['implementation_manifest']['path']).resolve().parent
    closure=objects['implementation_closure']
    if Path(refs['implementation_closure']['path']).resolve()!=root/'CODE_CLOSURE.json':raise NotReady('implementation closure path')
    for row in closure['files']:
        p=path_inside(root,row['path'])
        if p.stat().st_size!=row['bytes'] or hash_file(p)!=row['sha256']:raise NotReady('collector/admin code closure changed')

def check_public_closure(manifest_ref,closure_ref):
    read_ref(manifest_ref);closure=read_ref(closure_ref)
    root=Path(manifest_ref['path']).resolve().parent
    for row in closure['files']:
        p=path_inside(root,row['path'])
        if type(row['bytes']) is not int or p.stat().st_size!=row['bytes'] or hash_file(p)!=row['sha256']:raise EvidenceUnknown('bound source implementation changed')
    return closure

def opaque_inventory(root):
    root=Path(root).resolve();out=[]
    for p in sorted(root.rglob('*')):
        if p==root/'ALL_SLOTS_TERMINAL.json':continue
        s=p.lstat()
        if stat.S_ISLNK(s.st_mode):raise EvidenceUnknown('symlink in sealed source')
        if stat.S_ISDIR(s.st_mode):continue
        if not stat.S_ISREG(s.st_mode):raise EvidenceUnknown('nonregular source member')
        out.append(dict(path=p.relative_to(root).as_posix(),bytes=s.st_size,sha256=hash_file(p)))
    return out

def validate_terminal_row(row,run,context,slot):
    if not equal(row.get('run'),run) or row.get('context')!=context or row.get('status') not in TERMINAL or row.get('completion_win') is not False or row.get('scientific_adjudication')!='UNKNOWN' or row.get('private_results_decoded') is not False:raise EvidenceUnknown('source row identity/terminal/admin-only contract')
    integer(run['slot'],0,55);integer(run['replicate_id'],0,7);charge=row['charge'];known=integer(charge['known_durable_submitted_prefix'],0,300)
    if row['status'] in ('START_FAILED_UNSUBMITTED','UNRUN_GLOBAL_STOP'):
        for name in ('FEE_JOURNAL.ndjson','WORKER_STARTED.json','GO.json','ACTUAL_STARTUP_ONCE','private'):
            if (slot/name).exists() or (slot/name).is_symlink():raise EvidenceUnknown('unstarted exact0 conflicts with existing fee/start evidence')
        if charge['state']!='SEALED_EXACT' or type(charge['exact_total']) is not int or charge['exact_total']!=0 or known!=0 or charge['exact_tail']!='KNOWN':raise EvidenceUnknown('unstarted exact0 mismatch')
        return
    fee=fee_accounting(slot/'FEE_JOURNAL.ndjson')
    if fee['run_id'] not in (None,run['run_id']) or fee['known_durable_submitted_prefix']!=known or fee['last_chain_hash']!=charge['last_chain']:raise EvidenceUnknown('independent fee prefix/run/chain differs')
    if row['status'] in ('WORKER_SEALED','WORKER_FAILED_CLOSED'):
        if charge['state']!='SEALED_EXACT' or type(charge['exact_total']) is not int or charge['exact_total']!=known or charge['exact_tail']!='KNOWN' or fee['charge_state']!='SEALED_EXACT' or fee['exact_total']!=known:raise EvidenceUnknown('sealed exact fee mismatch')
        summary=load_public(slot/'ADMIN_SUMMARY.json');closed=load_public(slot/'WORKER_CLOSED.json');expected='NORMAL_CLOSED' if row['status']=='WORKER_SEALED' else 'FAILED_CLOSED'
        if summary.get('schema')!='bound-worker-admin-summary/v2' or summary.get('scope')!='actual_bound' or summary.get('scientific_success')!='UNKNOWN':raise EvidenceUnknown('source worker summary schema/scope')
        for obj in (summary,closed):
            if not equal(obj.get('run'),run) or obj.get('context')!=context or obj.get('status')!=expected or type(obj.get('physical_attempts')) is not int or obj['physical_attempts']!=known or obj.get('fee_chain')!=charge['last_chain']:raise EvidenceUnknown('worker closure identity/fee')
        if hash_file(slot/'ADMIN_SUMMARY.json')!=row['summary_sha256'] or hash_file(slot/'WORKER_CLOSED.json')!=row['closed_sha256'] or closed['summary_sha256']!=row['summary_sha256']:raise EvidenceUnknown('source closure hashes')
        if type(summary.get('files')) is not list or not summary['files']:raise EvidenceUnknown('private opaque inventory absent')
        for item in summary['files']:
            if not item['path'].startswith('private/'):raise EvidenceUnknown('worker private inventory path')
            p=path_inside(slot,item['path'])
            if type(item['bytes']) is not int or p.stat().st_size!=item['bytes'] or hash_file(p)!=item['sha256']:raise EvidenceUnknown('private source bytes changed')
    elif charge.get('state')!='UNSEALED_UNKNOWN_TAIL' or charge.get('exact_total') is not None or charge.get('exact_tail')!='UNKNOWN':raise EvidenceUnknown('censor unknown fee tail erased')

def verify_source(sid,spec,seal_ref,permission_ref,plan,*,expected_context=None):
    """Public metadata and opaque hashing only; caller has both source gates."""
    root=Path(spec['root']).resolve();seal=read_ref(seal_ref);permission=read_ref(permission_ref);barrier_path=root/'ALL_SLOTS_TERMINAL.json'
    if Path(seal_ref['path']).resolve().is_relative_to(root):raise EvidenceUnknown('source seal must be external')
    barrier_sha=hash_file(barrier_path)
    if seal.get('schema')!='planned-slots-external-admin-seal/v2' or seal.get('study_root')!=str(root) or seal.get('barrier_sha256')!=barrier_sha or seal.get('private_results_decoded') is not False:raise EvidenceUnknown('source external seal identity')
    barrier=load_public(barrier_path);expected_runs=plan['all56_runs'] if sid=='retained' else plan['execution_runs'];count=len(expected_runs);context=seal['context']
    if expected_context is not None and context!=expected_context:raise EvidenceUnknown('source context derivation differs')
    if barrier.get('schema')!='planned-slots-terminal-admin-barrier/v2' or barrier.get('status')!='ALL_PLANNED_SLOTS_TERMINAL_ADMIN_ONLY' or barrier.get('scope')!='FINAL_BOUND_ACTUAL' or barrier.get('context')!=context or barrier.get('synthetic_assembled') is True or barrier.get('private_results_decoded') is not False or barrier.get('scientific_success')!='UNKNOWN':raise EvidenceUnknown('genuine source terminal barrier required')
    for obj in (seal,barrier,permission):
        integer(obj['planned_slot_count'],count,count)
        if obj['planned_slots_sha256']!=digest(expected_runs):raise EvidenceUnknown('source complete literal planned table')
    wanted_status='VERIFIED_ALL_FINAL_56_SLOTS_ADMIN_ONLY' if sid=='retained' else 'VERIFIED_ALL_FINAL_52_SLOTS_ADMIN_ONLY'
    if permission.get('status')!=wanted_status or permission.get('study_root')!=str(root) or permission.get('context')!=context or permission.get('barrier_sha256')!=barrier_sha or permission.get('private_results_decoded') is not False or permission.get('scientific_success')!='UNKNOWN':raise EvidenceUnknown('independent source administrative permission missing')
    if permission['bindings']['external_seal_sha256']!=seal_ref['sha256'] or permission['bindings']['final_protocol_sha256']!=spec['final_protocol_ref']['sha256'] or permission['bindings']['entropy_sha256']!=ENTROPY_SHA:raise EvidenceUnknown('source permission public bindings')
    final=read_ref(spec['final_protocol_ref']);closure=check_public_closure(spec['worker_manifest_ref'],spec['worker_closure_ref'])
    admin_ready=read_ref(spec['admin_verifier_ready_ref'])
    check_public_closure(spec['admin_verifier_manifest_ref'],spec['admin_verifier_closure_ref'])
    if admin_ready.get('status')!='READY_FOR_BOUND_INDEPENDENT_ADMIN_VERIFIER' or admin_ready.get('manifest_sha256')!=spec['admin_verifier_manifest_ref']['sha256'] or admin_ready.get('code_closure_sha256')!=spec['admin_verifier_closure_ref']['sha256'] or permission['bindings'].get('admin_verifier_manifest_sha256')!=spec['admin_verifier_manifest_ref']['sha256'] or permission['bindings'].get('admin_verifier_ready_sha256')!=spec['admin_verifier_ready_ref']['sha256']:raise EvidenceUnknown('independent source verifier code/Ready differs')
    if final.get('study_root')!=str(root) or final.get('schema')!='final-cross-inference-execution-protocol/v2' or final.get('status')!='FINAL_EXECUTION_AUTHORIZED' or final.get('execution_authorized') is not True:raise EvidenceUnknown('source final protocol not fixed/authorized')
    bundle=final['bundle']
    if not equal(bundle['runs'],expected_runs) or barrier.get('bundle_sha256')!=digest(bundle) or sha256(bundle['scientific_plan_json'].encode()).hexdigest()!=SCIENCE_SHA or bundle['pins']['scientific_contract_sha256']!=SCIENCE_SHA or bundle['pins']['controller_closure_sha256']!=spec['worker_closure_ref']['sha256']:raise EvidenceUnknown('source final science/runs/code closure differs')
    if final.get('data_manifest_sha256')!='f6ee2cb34103bdf4921e5e01d633dd2ce47b5e4477db391167cd104a8f7fbbe7' or bundle['pins']['data_contract_sha256']!='a1ce9ee118c06cd2d72b0cff3cd28c6358f89fdbfeaed4ca5423ba9cc49ed690':raise EvidenceUnknown('same fixed dataset/frame required')
    if not equal(bundle['limits'],plan['resource_accounting']['per_case']) or not equal(bundle['controller_limits'],plan['resource_accounting']['controller_effective']) or not equal(bundle['study_limits'],plan['resource_accounting']['original_global']):raise EvidenceUnknown('original resource caps differ')
    if sid=='new52':
        cb=continuation_bindings(plan)
        if final.get('entropy_binding_mode')!=plan['entropy']['binding_mode'] or not equal(final.get('continuation_bindings'),cb) or not equal(bundle.get('continuation_bindings'),cb) or not equal(bundle.get('scientific_runs'),plan['all56_runs']) or any(not equal(obj.get('continuation_bindings'),cb) for obj in (seal,barrier,permission)):raise EvidenceUnknown('new52 continuation/frame/source binding differs')
        if bundle.get('execution_mode')!=plan['entropy']['binding_mode'] or final.get('composite_root')!=plan['composite_root']:raise EvidenceUnknown('new52 execution/composite scope')
        rs=permission.get('resource_status');credit=permission.get('source_scientific_credit_allowed')
        if rs not in ('WITHIN_CUMULATIVE_FINAL_ADMIN_ONLY','OVER_LIMIT_RETAINED_ADMIN_ONLY') or type(credit) is not bool or credit!=(rs=='WITHIN_CUMULATIVE_FINAL_ADMIN_ONLY') or permission.get('eligibility_is_not_scientific_success') is not True:raise EvidenceUnknown('new52 final cumulative resource/credit flag')
    if type(barrier.get('rows')) is not list or len(barrier['rows'])!=count:raise EvidenceUnknown('all source rows required')
    rows={};rowrefs={}
    for row,run in zip(barrier['rows'],expected_runs):
        slot=root/'slots'/run['run_id'];validate_terminal_row(row,run,context,slot)
        rp=root/f'ROW_{run["slot"]:03d}.json'
        if not equal(load_public(rp),row):raise EvidenceUnknown('source canonicalROW differs from terminal record')
        rows[run['slot']]=row;rowrefs[run['slot']]=dict(path=str(rp),sha256=hash_file(rp))
    if sid=='retained':
        proof=json.loads(plan['unclaimed_proof']['public_raw_json']);bound={x['slot']:x for x in proof['whole_row_bindings']}
        for i in range(56):
            if rowrefs[i]['sha256']!=bound[i]['sha256']:raise EvidenceUnknown('any original source row/history changed')
        censor=rows[3]
        if censor['status']!='CENSORED_UNKNOWN' or censor['charge']['exact_total'] is not None or censor['charge']['exact_tail']!='UNKNOWN':raise EvidenceUnknown('old Native censor cannot be promoted')
    inventory=opaque_inventory(root)
    if not equal(inventory,barrier['inventory']) or digest(inventory)!=seal['inventory_sha256'] or digest(inventory)!=permission['inventory_sha256']:raise EvidenceUnknown('complete opaque source inventory differs')
    registry=dict(source_id=sid,root=str(root),context=context,selected_slots=spec['selected_slots'],planned_slot_count=count,planned_slots_sha256=digest(expected_runs),final_protocol_ref=spec['final_protocol_ref'],worker_manifest_ref=spec['worker_manifest_ref'],worker_closure_ref=spec['worker_closure_ref'],external_seal_ref=seal_ref,admin_permission_ref=permission_ref,barrier_ref=dict(path=str(barrier_path),sha256=barrier_sha),inventory_sha256=digest(inventory),entropy_sha256=ENTROPY_SHA,scientific_contract_sha256=SCIENCE_SHA,continuation_bindings=permission.get('continuation_bindings'))
    return dict(registry=registry,rows=rows,rowrefs=rowrefs,closure=closure,final=final,permission=permission,barrier=barrier)

def expected_cases(plan,sources):
    cases=[]
    for run in plan['all56_runs']:
        sid='retained' if run['slot']<4 else 'new52';data=sources[sid];reg=data['registry'];rr=data['rowrefs'][run['slot']]
        cases.append(dict(run=run,source_id=sid,source_root=reg['root'],slot_root=str(Path(reg['root'])/'slots'/run['run_id']),row_path=rr['path'],row_sha256=rr['sha256'],source_context=reg['context'],source_final_protocol_sha256=reg['final_protocol_ref']['sha256'],source_worker_manifest_sha256=reg['worker_manifest_ref']['sha256'],source_worker_closure_sha256=reg['worker_closure_ref']['sha256'],source_external_seal_sha256=reg['external_seal_ref']['sha256'],source_admin_permission_sha256=reg['admin_permission_ref']['sha256'],source_row=data['rows'][run['slot']],whole_case=True,no_postmortem_promotion=True))
    return cases

def load_source_authority(refs):
    """Late source gate used by collector/verifier; never reads actual ranks."""
    complete_refs(refs,COMMON_REFS);objects={k:read_ref(v) for k,v in refs.items()};hashes={k:v['sha256'] for k,v in refs.items()}
    plan=read_fixed_plan();protocol=objects['composite_protocol'];validate_protocol(protocol,objects['composite_ready'],plan,hashes);check_implementation(refs,objects)
    specs=protocol['source_specs'];old=plan['retained_source']
    if not equal(refs['retained_source_permission'],dict(path=old['admin_permission_path'],sha256=old['admin_permission_sha256'])) or refs['new_source_permission']['path']!=specs['new52']['admin_permission_path'] or refs['new_source_external_seal']['path']!=specs['new52']['external_seal_path'] or refs['new_source_launch_ready']['path']!=specs['new52']['launch_ready_path']:raise NotReady('exact source public-gate locations required')
    lp=objects['new_source_launch_ready'];b=lp.get('bindings',{})
    if lp.get('status')!='READY_FOR_BOUND_ACTUAL_LAUNCH' or lp.get('actual_launch_authorized') is not True or lp.get('study_root')!=plan['new_execution_root'] or b.get('final_protocol_sha256')!=protocol['final_protocol_sha256'] or b.get('composite_protocol_sha256')!=hashes['composite_protocol'] or b.get('composite_ready_sha256')!=hashes['composite_ready'] or b.get('entropy_sha256')!=ENTROPY_SHA:raise NotReady('new source launch graph did not bind composite before methods')
    if b.get('worker_manifest_sha256')!=specs['new52']['worker_manifest_ref']['sha256'] or b.get('controller_manifest_sha256')!=specs['new52']['worker_manifest_ref']['sha256'] or b.get('code_closure_sha256')!=specs['new52']['worker_closure_ref']['sha256'] or lp.get('planned_slots_sha256')!=digest(plan['execution_runs']):raise NotReady('new source launch code/52-frame provenance differs')
    newfinal=read_ref(protocol['current_final_protocol']);newcontext=digest(dict(bundle_sha256=digest(newfinal['bundle']),launch_ready_sha256=refs['new_source_launch_ready']['sha256'],entropy_sha256=ENTROPY_SHA))
    sources={}
    sources['retained']=verify_source('retained',specs['retained'],specs['retained']['external_seal_ref'],refs['retained_source_permission'],plan,expected_context=old['context'])
    sources['new52']=verify_source('new52',specs['new52'],refs['new_source_external_seal'],refs['new_source_permission'],plan,expected_context=newcontext)
    # Independent input-row order/statistical framework remains fixed, while
    # role/guard/continuation plumbing is deliberately allowed to differ.
    maps=[{x['path']:x['sha256'] for x in sources[s]['closure']['files']} for s in ('retained','new52')]
    if any(maps[0].get(n)!=maps[1].get(n) or n not in maps[0] for n in STAT_FILES):raise EvidenceUnknown('statistical/dispatch/fee framework source bytes differ')
    for sid in ('retained','new52'):
        bundle=sources[sid]['final']['bundle']
        if bundle['pins']['protocol_sha256']!=sources['retained']['final']['bundle']['pins']['protocol_sha256']:raise EvidenceUnknown('fixed method/request protocol settings changed')
    return dict(plan=plan,protocol=protocol,objects=objects,authority_hashes=hashes,sources=sources,cases=expected_cases(plan,sources))

def sample_tree(root):
    root=Path(root);totals=dict(files=0,logical_bytes=0,allocated_bytes=0)
    if not root.exists():return totals
    for p in root.rglob('*'):
        s=p.lstat()
        if stat.S_ISLNK(s.st_mode):raise EvidenceUnknown('symlink in cumulative storage scope')
        if stat.S_ISDIR(s.st_mode):continue
        if not stat.S_ISREG(s.st_mode):raise EvidenceUnknown('nonregular storage member')
        totals['files']+=1;totals['logical_bytes']+=s.st_size;totals['allocated_bytes']+=s.st_blocks*512
    return totals

def resource_receipt(plan,composite_root,new_source_permission):
    """Actual storage census; CPU cap debit is reservation, not measured CPU."""
    initial=Path(plan['resource_accounting']['wall_anchor_path']).with_name('mast_bound56_actual_study_v1')
    roots=[initial,Path(plan['retained_source']['root']),Path(plan['new_execution_root'])];old=dict(files=0,logical_bytes=0,allocated_bytes=0)
    for root in roots[:2]:
        item=sample_tree(root)
        for k in old:old[k]+=item[k]
        for suffix in ('ADMIN_CONTROLLER.log','CONTROLLER_STDERR.log','EXTERNAL_SEAL.json','LAUNCH_CLAIM.json','LAUNCH_RECEIPT.json'):
            p=root.parent/(root.name+'.'+suffix)
            if not p.is_file() or p.is_symlink():raise EvidenceUnknown('old canonical sibling metadata absent')
            s=p.stat();old['files']+=1;old['logical_bytes']+=s.st_size;old['allocated_bytes']+=s.st_blocks*512
    new=sample_tree(roots[2])
    for suffix in ('ADMIN_CONTROLLER.log','CONTROLLER_STDERR.log','EXTERNAL_SEAL.json','LAUNCH_CLAIM.json','LAUNCH_RECEIPT.json'):
        p=roots[2].parent/(roots[2].name+'.'+suffix)
        if p.exists():
            if p.is_symlink() or not p.is_file():raise EvidenceUnknown('new canonical sibling metadata type')
            s=p.stat();new['files']+=1;new['logical_bytes']+=s.st_size;new['allocated_bytes']+=s.st_blocks*512
    comp=sample_tree(composite_root);total={k:old[k]+new[k]+comp[k] for k in old};caps=plan['resource_accounting']['original_global'];reserve=plan['resource_accounting']['composite_reserve']
    violations=[k for k in total if total[k]>caps[k]]+[('composite_'+k) for k in comp if comp[k]>reserve[k]]
    free=shutil.disk_usage(Path(composite_root).parent).free
    if free<caps['free_disk_floor_bytes']:violations.append('free_disk_floor_bytes')
    # The actual writer/verifier adds canonical external metadata too. The
    # source4's eligibility is never erased by a later new52 resource censor.
    for suffix in ('EXTERNAL_SEAL.json','ADMIN_PERMISSION.json'):
        p=Path(composite_root).parent/(Path(composite_root).name+'.'+suffix)
        if p.exists():
            if p.is_symlink() or not p.is_file():raise EvidenceUnknown('composite canonical sibling type')
            s=p.stat();comp['files']+=1;comp['logical_bytes']+=s.st_size;comp['allocated_bytes']+=s.st_blocks*512
    total={k:old[k]+new[k]+comp[k] for k in old}
    violations=[k for k in total if total[k]>caps[k]]+[('composite_'+k) for k in comp if comp[k]>reserve[k]]
    if free<caps['free_disk_floor_bytes']:violations.append('free_disk_floor_bytes')
    source_credit=new_source_permission.get('source_scientific_credit_allowed')
    if type(source_credit) is not bool:raise EvidenceUnknown('source credit flag must be plain boolean')
    eligible=not violations and source_credit
    return dict(old_actual_storage=old,new52_actual_storage=new,composite_actual_storage=comp,cumulative_storage=total,free_disk_bytes=free,violations=violations,resource_status='OVER_LIMIT_RETAINED_ADMIN_ONLY' if not eligible else 'WITHIN_FIXED_CUMULATIVE_STORAGE_CAPS',scientific_credit_allowed=eligible,source_scientific_credit_allowed=dict(retained=True,new52=eligible),CPU_cap_based_debit=plan['resource_accounting']['CPU_cap_based_debit'],CPU_remaining=plan['resource_accounting']['CPU_remaining'],actual_total_CPU='UNKNOWN_UNLESS_SEPARATELY_RECORDED',wall_absolute_deadline_utc_ns=plan['resource_accounting']['wall_absolute_deadline_utc_ns'],CPU_debit_is_not_measurement=True)

def composite_inventory(root):
    # Every file is public metadata. The external seal lives outside this tree.
    root=Path(root).resolve();rows=[]
    for p in sorted(root.rglob('*')):
        s=p.lstat()
        if stat.S_ISLNK(s.st_mode):raise EvidenceUnknown('symlink in composite artifact')
        if stat.S_ISDIR(s.st_mode):continue
        if not stat.S_ISREG(s.st_mode):raise EvidenceUnknown('nonregular composite artifact')
        rows.append(dict(path=p.relative_to(root).as_posix(),bytes=s.st_size,sha256=hash_file(p)))
    return rows

def verify_index_and_seal(authority,seal_ref):
    plan=authority['plan'];protocol=authority['protocol'];root=Path(plan['composite_root']);seal=read_ref(seal_ref)
    if Path(seal_ref['path']).resolve()!=root.parent/(root.name+'.EXTERNAL_SEAL.json'):raise NotReady('fixed external composite seal location')
    path=root/'COMPOSITE_INDEX.json';index=load_public(path)
    if seal.get('schema')!='disjoint56-composite-external-admin-seal/v1' or seal.get('composite_root')!=str(root) or seal.get('composite_protocol_sha256')!=authority['authority_hashes']['composite_protocol'] or seal.get('final_protocol_sha256')!=protocol['final_protocol_sha256'] or seal.get('index_sha256')!=hash_file(path) or seal.get('private_results_decoded') is not False:raise NotReady('external composite seal binding')
    for obj in (seal,index):
        integer(obj['planned_slot_count'],56,56)
        if obj['planned_slots_sha256']!=digest(plan['all56_runs']) or not equal(obj['continuation_bindings'],continuation_bindings(plan)):raise NotReady('full56 partition binding')
    if index.get('schema')!='disjoint56-composite-admin-index/v1' or index.get('status')!='ALL56_COMPOSITE_POINTERS_ADMIN_ONLY' or index.get('scope')!='ACTUAL_FIXED_DISJOINT56' or index.get('composite_root')!=str(root) or index.get('composite_protocol_sha256')!=authority['authority_hashes']['composite_protocol'] or index.get('final_protocol_sha256')!=protocol['final_protocol_sha256'] or index.get('private_results_decoded') is not False or index.get('scientific_success')!='UNKNOWN':raise NotReady('composite index status/scope')
    registries={sid:x['registry'] for sid,x in authority['sources'].items()}
    if not equal(index['cases'],authority['cases']) or not equal(index['sources'],registries) or not equal(index['authority_bindings'],authority['authority_hashes']):raise NotReady('wholecase pointer/context/source provenance differs')
    source_bindings={sid:digest(v) for sid,v in registries.items()}
    if not equal(seal['source_bindings'],source_bindings) or seal['inventory_sha256']!=digest(composite_inventory(root)):raise NotReady('composite complete opaque inventory changed')
    return index,seal,source_bindings

def load_verified_composite(refs):
    """Metadata-only API copied into auditor closure; returns original rows."""
    complete_refs(refs,CONSUMER_REFS)
    common={k:refs[k] for k in COMMON_REFS};authority=load_source_authority(common)
    index,seal,source_bindings=verify_index_and_seal(authority,refs['composite_external_seal']);permission=read_ref(refs['composite_admin_permission'])
    hashes={k:v['sha256'] for k,v in refs.items()};wanted={k+'_sha256':v for k,v in hashes.items() if k!='composite_admin_permission'};wanted['final_protocol_sha256']=authority['protocol']['final_protocol_sha256']
    if permission.get('schema')!='disjoint56-composite-admin-permission/v1' or permission.get('status')!='VERIFIED_COMPOSITE_56_SLOTS_ADMIN_ONLY' or permission.get('bindings')!=wanted or permission.get('composite_root')!=authority['plan']['composite_root'] or permission.get('index_sha256')!=seal['index_sha256'] or permission.get('inventory_sha256')!=seal['inventory_sha256'] or permission.get('private_results_decoded') is not False or permission.get('scientific_success')!='UNKNOWN':raise NotReady('independent composite permission absent or changed')
    if not equal(permission.get('continuation_bindings'),continuation_bindings(authority['plan'])) or not equal(permission.get('source_bindings'),source_bindings) or type(permission.get('planned_slot_count')) is not int or permission['planned_slot_count']!=56 or permission.get('planned_slots_sha256')!=digest(authority['plan']['all56_runs']):raise NotReady('composite permission table/source graph')
    current_resources=resource_receipt(authority['plan'],authority['plan']['composite_root'],authority['sources']['new52']['permission'])
    if permission.get('scientific_credit_allowed') is not current_resources['scientific_credit_allowed']:raise NotReady('resource credit eligibility changed')
    if not equal(permission.get('source_scientific_credit_allowed'),current_resources['source_scientific_credit_allowed']):raise NotReady('per-source credit eligibility differs')
    return dict(cases=index['cases'],sources=index['sources'],protocol=authority['protocol'],authority_hashes=hashes,composite_root=authority['plan']['composite_root'],scientific_credit_allowed=current_resources['scientific_credit_allowed'],source_scientific_credit_allowed=current_resources['source_scientific_credit_allowed'],resource_status=current_resources['resource_status'])
