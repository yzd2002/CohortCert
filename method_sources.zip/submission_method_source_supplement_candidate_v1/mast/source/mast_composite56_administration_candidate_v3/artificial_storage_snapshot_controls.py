"""Only the newly added stat-only old-snapshot guard, owned fixtures only."""
from pathlib import Path
from copy import deepcopy
import json,resource,time
import composite_consumer as C

def run():
    start=time.process_time();root=Path(__file__).resolve().parent/'artificial_storage_guard_attempt_01';root.mkdir(mode=0o700)
    oldroots=[root/'initial',root/'retained',root/'new52'];comp=root/'oldcomp'
    for p in oldroots+[comp]:p.mkdir()
    owned=oldroots[0]/'PUBLIC_SENTINEL.json';owned.write_text('{"artificial":true}\n');s=owned.stat()
    member=dict(path=str(owned),logical_bytes=s.st_size,allocated_bytes=s.st_blocks*512)
    debit=dict(files=1,logical_bytes=s.st_size,allocated_bytes=s.st_blocks*512);snapshot=dict(debit,members=[member]);policy=dict(old_storage_debit=debit)
    receipts=[]
    def reject(value):
        try:C.validate_old_storage_snapshot(value,policy,oldroots,comp)
        except (C.EvidenceUnknown,FileNotFoundError):return
        raise AssertionError('new snapshot negative guard accepted')
    C.validate_old_storage_snapshot(snapshot,policy,oldroots,comp);receipts.append('owned_complete_snapshot_accepted')
    bad=deepcopy(snapshot);bad['members']=[];reject(bad);receipts.append('missing_snapshot_member_inventory_rejected')
    bad=deepcopy(snapshot);bad['members'][0]['logical_bytes']+=1;reject(bad);receipts.append('retained_logical_size_change_rejected')
    bad=deepcopy(snapshot);bad['members'][0]['path']=str(root/'OUTSIDE_SCOPE.json');reject(bad);receipts.append('scope_escape_rejected_before_stat')
    owned.unlink();reject(snapshot);receipts.append('retained_file_deletion_cannot_refund_debit')
    result=dict(schema='new-old-storage-snapshot-finite-guards/v1',status='PASS',controls=receipts,control_count=len(receipts),CPU_seconds=time.process_time()-start,old17_completed_controls_rerun=False,actual_data_or_source_or_rank_or_method_access=False)
    (root/'RESULTS.json').write_bytes(C.canonical(result));print(json.dumps(result,indent=2))

if __name__=='__main__':
    resource.setrlimit(resource.RLIMIT_CPU,(3,5));resource.setrlimit(resource.RLIMIT_AS,(536870912,536870912));run()
