"""New public-only metadata writes; never modify a study or private source."""
from pathlib import Path
import os
from composite_consumer import canonical,EvidenceUnknown

def write_new(path,obj):
    path=Path(path);raw=canonical(obj)
    if len(raw)>4*1024**2:raise EvidenceUnknown('composite public metadata reserve')
    fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    try:
        view=memoryview(raw)
        while view:
            n=os.write(fd,view)
            if n<=0:raise OSError('incomplete composite metadata write')
            view=view[n:]
        os.fsync(fd)
    finally:os.close(fd)
    d=os.open(path.parent,os.O_RDONLY|os.O_DIRECTORY)
    try:os.fsync(d)
    finally:os.close(d)
