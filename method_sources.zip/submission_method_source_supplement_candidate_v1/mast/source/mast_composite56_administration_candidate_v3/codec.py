"""Exact JSON, atomic metadata and opaque file hashes; no import IO."""
from dataclasses import fields,is_dataclass
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
import json
import os

class ResourceCensor(BaseException):pass
_OUTPUT_ROOT=None
_OUTPUT_CAP=None
def set_output_budget(root,cap):
    global _OUTPUT_ROOT,_OUTPUT_CAP
    _OUTPUT_ROOT=Path(root).resolve();_OUTPUT_CAP=cap
def check_output(path,additional,replaced=0):
    if _OUTPUT_ROOT is None or not Path(path).resolve().is_relative_to(_OUTPUT_ROOT):return
    total=0
    for p in _OUTPUT_ROOT.rglob('*'):
        try:
            if p.is_file():total+=p.stat().st_size
        except FileNotFoundError:continue
    if total-replaced+additional>_OUTPUT_CAP-32768:raise ResourceCensor('packet output cap; administrative reserve retained')
def encoded(x):
    if isinstance(x,Fraction):return {'$fraction':[x.numerator,x.denominator]}
    if is_dataclass(x):return {f.name:encoded(getattr(x,f.name)) for f in fields(x)}
    if isinstance(x,dict):return {str(k):encoded(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [encoded(v) for v in x]
    if isinstance(x,(set,frozenset)):return [encoded(v) for v in sorted(x)]
    return x
def canonical(x):return (json.dumps(encoded(x),sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)+'\n').encode()
def digest(p):
    h=sha256()
    with Path(p).open('rb') as f:
        for block in iter(lambda:f.read(65536),b''):h.update(block)
    return h.hexdigest()
def fsync_dir(p):
    fd=os.open(str(p),os.O_DIRECTORY|os.O_RDONLY)
    try:os.fsync(fd)
    finally:os.close(fd)
def atomic_json(p,value,mode=0o600):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);data=canonical(value)
    if p.name!='CENSOR_RETAINED.json':check_output(p,len(data),p.stat().st_size if p.exists() else 0)
    tmp=p.with_name(p.name+'.partial')
    fd=os.open(str(tmp),os.O_WRONLY|os.O_CREAT|os.O_TRUNC,mode)
    try:
        view=memoryview(data)
        while view:
            n=os.write(fd,view)
            if n<=0:raise OSError('incomplete atomic metadata write')
            view=view[n:]
        os.fsync(fd)
    finally:os.close(fd)
    os.chmod(tmp,mode);os.replace(tmp,p);fsync_dir(p.parent)
def strict_pairs(rows):
    d={}
    for k,v in rows:
        if k in d:raise ValueError('duplicate JSON key')
        d[k]=v
    return d
def load_json(p,max_bytes=1048576):
    p=Path(p)
    if p.stat().st_size>max_bytes:raise ValueError('bounded JSON size exceeded')
    raw=p.read_bytes()
    return json.loads(raw,object_pairs_hook=strict_pairs,parse_constant=lambda _:(_ for _ in ()).throw(ValueError('nonfinite JSON')))

class Journal:
    def __init__(self,path,run_id):
        self.path=Path(path);self.run_id=run_id;self.seq=0;self.previous='0'*64
        self.path.parent.mkdir(parents=True,exist_ok=True)
        self.fd=os.open(str(self.path),os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600);self.closed=False
        fsync_dir(self.path.parent)
    def append(self,event,**data):
        if self.closed:raise ValueError('closed journal')
        body=dict(run_id=self.run_id,seq=self.seq,previous=self.previous,event=event,data=data)
        h=sha256(canonical(body)).hexdigest();raw=canonical(dict(body,hash=h))
        check_output(self.path,len(raw))
        view=memoryview(raw)
        while view:
            n=os.write(self.fd,view)
            if n<=0:raise OSError('short durable journal write')
            view=view[n:]
        os.fsync(self.fd);self.seq+=1;self.previous=h
        return h
    def close(self):
        if not self.closed:os.close(self.fd);self.closed=True

def journal_prefix(path):
    rows=[];previous='0'*64;error=None
    try:
        with Path(path).open('rb') as f:
            for line in f:
                if not line.endswith(b'\n'):raise ValueError('partial journal line')
                if len(line)>1048576:raise ValueError('journal line too large')
                row=json.loads(line,object_pairs_hook=strict_pairs)
                h=row.pop('hash')
                if row['seq']!=len(rows) or row['previous']!=previous or sha256(canonical(row)).hexdigest()!=h:raise ValueError('journal chain mismatch')
                row['hash']=h;rows.append(row);previous=h
    except Exception as exc:error=type(exc).__name__
    return rows,error

def fee_accounting(path):
    rows,error=journal_prefix(path);known=0;returned=0;batches={};closed=set();sealed=False;run_id=None;processed={};failed_at={};binding=None;session_accounted=0
    try:
        for r in rows:
            if run_id is None:run_id=r['run_id']
            if r['run_id']!=run_id:raise ValueError('run mismatch')
            d=r['data'];kind=r['event']
            if sealed:raise ValueError('data after cost seal')
            if kind=='SUBMITTED_BATCH':
                b=d['batch'];cost=d['physical_attempts']
                if b in batches or type(cost) is not int or cost<0 or len(d['rids'])!=len(set(d['rids'])) or len(d['fresh'])!=len(d['rids']) or any(type(v) is not bool for v in d['fresh']) or sum(d['fresh'])!=cost:raise ValueError('submission schema')
                current=(d['operator_snapshot'],d['operator_version'],tuple(d['ordered_modes']))
                if binding is None:binding=current
                if binding!=current:raise ValueError('operator binding changed')
                batches[b]=d;processed[b]=[];known+=cost
            elif kind=='RETURNED_VECTOR':
                b=d['batch'];i=len(processed.get(b,[]))
                if b not in batches or b in closed or b in failed_at or i>=len(batches[b]['rids']) or d['rid']!=batches[b]['rids'][i] or d['cache_hit']!=(not batches[b]['fresh'][i]) or d['private_observation_seq']!=returned:raise ValueError('return prefix mismatch')
                processed[b].append(d['rid']);returned+=1
            elif kind=='FAILED_VECTOR':
                b=d['batch'];i=len(processed.get(b,[]))
                if b not in batches or b in closed or b in failed_at or i>=len(batches[b]['rids']) or d['rid']!=batches[b]['rids'][i]:raise ValueError('failed vector prefix mismatch')
                failed_at[b]=i
            elif kind=='BATCH_CLOSED':
                b=d['batch']
                if b not in batches or b in closed or len(d['statuses'])!=len(batches[b]['rids']):raise ValueError('batch closure schema')
                if any(s not in ('SUCCESS','CACHE_HIT','FAILED','UNEXECUTED_CHARGED','UNCONSUMED_CACHE_HIT') for s in d['statuses']):raise ValueError('batch status')
                expected=[]
                for i,fresh in enumerate(batches[b]['fresh']):
                    if i<len(processed[b]):expected.append('SUCCESS' if fresh else 'CACHE_HIT')
                    elif b in failed_at and i==failed_at[b]:expected.append('FAILED')
                    elif b in failed_at:expected.append('UNEXECUTED_CHARGED' if fresh else 'UNCONSUMED_CACHE_HIT')
                    else:raise ValueError('unclosed vector in batch')
                if d['statuses']!=expected or d['failed']!=(b in failed_at):raise ValueError('batch result mismatch')
                closed.add(b)
            elif kind=='COST_SEALED':
                if type(d['physical_attempts']) is not int or d['physical_attempts']!=known or set(batches)!=closed or session_accounted!=known:raise ValueError('cost seal mismatch')
                sealed=True
            elif kind=='SESSION_CLOSED':
                if type(d['physical_attempts']) is not int or d['physical_attempts']!=known-session_accounted or set(batches)!=closed:raise ValueError('session cost closure mismatch')
                session_accounted=known
            else:raise ValueError('unknown fee journal event')
        if error:sealed=False
    except Exception as exc:error=type(exc).__name__;sealed=False
    return dict(run_id=run_id,known_durable_submitted_prefix=known,exact_total=known if sealed and error is None else None,
        charge_state='SEALED_EXACT' if sealed and error is None else 'UNSEALED_UNKNOWN_TAIL',
        returned_vectors=returned,journal_records=len(rows),last_chain_hash=rows[-1]['hash'] if rows else '0'*64,error_type=error)
