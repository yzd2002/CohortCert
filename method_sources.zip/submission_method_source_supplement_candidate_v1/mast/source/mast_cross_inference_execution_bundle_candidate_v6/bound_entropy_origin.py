"""Only exact unclaimed51 continuation; original entropy never re-created."""
from continuation_contract import MODE,SCIENCE,ORIGIN,origin_hashes,claim_context,forbid_recovery_draw
