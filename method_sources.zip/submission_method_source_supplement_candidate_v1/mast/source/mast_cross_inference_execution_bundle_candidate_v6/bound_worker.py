"""New private actual-bound worker authority; task never invokes actual mode."""
from pathlib import Path
import argparse,json,os,resource,signal,sys,time
from gate import ROOT,NotReady
from io_utils import atomic_json,file_hash,inventory,load_json,object_hash
from process_control import birth
from authority_v2 import authorize_actual_worker,verify_runtime
from continuation_contract import GlobalClock,require_worker_run
from devnull_policy import fixed_devnull_standard_io

class WorkerCensor(BaseException):pass
def install_guard(outdir,refs):
    approved=[False];outdir=Path(outdir).resolve();data=ROOT.parent/'mast_release_key_request_v1/data_construction_review_v1'
    protected={(data/'attempt_01/LOCKED_LABEL_VECTORS.json').resolve(),(data/'attempt_01/RECORD_IDENTITIES.json').resolve()}
    metadata={Path(x['path']).resolve() for x in (refs or {}).values() if type(x) is dict and type(x.get('path')) is str}
    if type((refs or {}).get('entropy')) is dict and type(refs['entropy'].get('path')) is str:
        entropy_path=Path(refs['entropy']['path']).resolve()
        metadata.add(entropy_path.with_name(entropy_path.name+'.DRAW_CLAIM.json'))
    native=ROOT.parent/'evergreen_contract_adapter_candidate'
    def guard(event,args):
        if event=='socket.connect':raise PermissionError('worker network disabled')
        if event!='open' or not isinstance(args[0],(str,bytes,os.PathLike)):return
        p=Path(os.fsdecode(args[0])).resolve();mode,flags=args[1:3]
        writing=(isinstance(mode,str) and any(c in mode for c in 'wax+')) or bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC))
        if p in protected and not approved[0]:raise NotReady('actual reference access before private permit')
        if fixed_devnull_standard_io(args[0],mode,flags):return
        if writing and not p.is_relative_to(outdir):raise PermissionError('worker write outside claimed slot')
        if not writing and p.is_relative_to(ROOT.parent) and not p.is_relative_to(ROOT) and not p.is_relative_to(outdir) and p not in metadata and not p.is_relative_to(native) and not (approved[0] and (p in protected or p==data/'DELIVERY_MANIFEST.json')):raise PermissionError('worker read outside bound metadata/code/input closure')
    sys.addaudithook(guard);return approved

def configure_slot_runtime_tmp(outdir):
    """Use standard TMPDIR before first tempfile initialization; never warm it."""
    root=Path(outdir).resolve()
    if not root.is_dir():raise NotReady('claimed output root must exist before temporary-directory configuration')
    module=sys.modules.get('tempfile')
    cached=None if module is None else getattr(module,'tempdir',None)
    initial=dict(schema='claimed-slot-tempdir-initial-state/v1',
                 tempfile_module_already_loaded=module is not None,
                 tempfile_tempdir_is_none=cached is None,
                 tempfile_tempdir_type='MODULE_NOT_LOADED' if module is None else type(cached).__name__,
                 tempfile_tempdir_repr=None if module is None else repr(cached),
                 gettempdir_called_before_configuration=False)
    atomic_json(root/'RUNTIME_TMPDIR_INITIAL.json',initial)
    # Do not silently reuse or reset a preinitialized global directory. A new
    # supported configuration for that state requires a separate review.
    if cached is not None:raise NotReady('tempfile.tempdir was cached before claimed-slot TMPDIR configuration')
    private=root/'private'
    if private.is_symlink() or (private.exists() and not private.is_dir()):raise NotReady('claimed private directory must be a nonsymlink directory')
    private.mkdir(mode=0o700,exist_ok=True)
    target=private/'runtime_tmp'
    if target.is_symlink() or target.exists():raise NotReady('cold claimed runtime_tmp must not preexist')
    target.mkdir(mode=0o700)
    if target.resolve()!=root/'private/runtime_tmp':raise NotReady('claimed runtime_tmp escaped the output root')
    os.environ['TMPDIR']=str(target)
    atomic_json(root/'RUNTIME_TMPDIR_CONFIGURED.json',dict(schema='claimed-slot-tempdir-configured/v1',TMPDIR=str(target),
                standard_environment_configuration_only=True,global_tempfile_cache_reset=False))
    return target


def confirm_slot_runtime_tmp(outdir,target):
    """After route import, verify normal stdlib selection stays in this slot."""
    import tempfile
    root=Path(outdir).resolve();target=Path(target)
    if target!=root/'private/runtime_tmp' or not target.is_dir() or target.is_symlink():raise NotReady('exact claimed runtime_tmp required after import')
    selected=Path(tempfile.gettempdir()).resolve()
    if selected!=target or not selected.is_relative_to(root):raise NotReady('stdlib temporary directory is not the claimed slot runtime_tmp')
    atomic_json(root/'RUNTIME_TMPDIR_CONFIRMED.json',dict(schema='claimed-slot-tempdir-confirmed/v1',
                selected_tmpdir=str(selected),within_claimed_output=True,global_tempfile_cache_reset=False))
    return selected

def run_actual(outdir,admission_sha,refs):
    # Missing LaunchReady/entropy/final references refuse before any path I/O.
    from authority_v2 import require_complete_references,LAUNCH
    require_complete_references(refs,LAUNCH)
    root=Path(outdir).resolve();approved=install_guard(root,refs)
    if file_hash(root/'ADMISSION.json')!=admission_sha:raise NotReady('controller admission hash')
    a=load_json(root/'ADMISSION.json');require_worker_run(a.get('run'));wall=GlobalClock.from_record(a.get('global_clock'));wall.require()
    permit=authorize_actual_worker(refs,run_id=a['run']['run_id'],outdir=str(root),admission=a)
    limits=permit.bundle['limits'][permit.run['method_id']]
    if resource.getrlimit(resource.RLIMIT_CPU)!=(limits['CPU_soft'],limits['CPU_hard']) or resource.getrlimit(resource.RLIMIT_AS)!=(limits['AS_bytes'],limits['AS_bytes']) or resource.getrlimit(resource.RLIMIT_FSIZE)!=(limits['packet_bytes'],limits['packet_bytes']):raise NotReady('hard worker limits not installed by bound parent')
    if signal.getitimer(signal.ITIMER_PROF)!=(0.0,0.0):raise NotReady('worker inherited an unexpected controller profiling timer')
    runtime_tmp=configure_slot_runtime_tmp(root)
    from method_dispatch import prepare_route,dispatch
    wall.require();prepare_route(permit.run['method_id'],root);wall.require()
    confirm_slot_runtime_tmp(root,runtime_tmp)
    objects={name:load_json(item['path'],8388608 if name=='environment_binding' else 2097152) for name,item in refs.items()}
    verify_runtime(refs,objects) # After imports, still before reference map opens.
    wall.require()
    atomic_json(root/'WORKER_STARTED.json',dict(pid=os.getpid(),starttime=birth(os.getpid()),run_id=permit.run['run_id'],context=permit.context))
    deadline=min(time.monotonic()+limits['wall_seconds'],wall.deadline())
    while not (root/'GO.json').exists():
        wall.require()
        if time.monotonic()>deadline:raise WorkerCensor('startup not released')
        time.sleep(.003)
    wall.require();go=load_json(root/'GO.json')
    if go!=dict(context=permit.context,run_id=permit.run['run_id'],child_starttime=birth(os.getpid()),parent_pid=a['parent_pid'],parent_birth=a['parent_birth']):raise NotReady('private worker GO mismatch')
    wall.require()
    fd=os.open(root/'ACTUAL_STARTUP_ONCE',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600);os.fsync(fd);os.close(fd)
    approved[0]=True
    from private_loader import load_actual_inputs
    req,cfg,provider=load_actual_inputs(permit)
    if req.scope!='actual_bound':raise AssertionError('actual Request scope changed')
    rr=permit.ranks[str(permit.run['replicate_id'])]
    ranks=dict(pilot={g:rr[g]['pilot_rank'] for g in 'ABC'},formal={g:rr[g]['formal_rank'] for g in 'ABC'})
    return execute_private_request(req,cfg,provider,permit.run['method_id'],root,permit.run,permit.context,ranks,limits,permit.hashes,permit=permit)


def execute_private_request(req,cfg,provider,method,root,run,context,ranks,limits,authority_hashes,*,permit=None):
    """Shared private body; actual scope still requires a private ActualPermit."""
    root=Path(root).resolve()
    from method_dispatch import dispatch
    if req.scope=='actual_bound':
        from authority_v2 import require_actual_permit
        from reference_schema import request_from_groups,fixed_config
        require_actual_permit(permit)
        rr=permit.ranks[str(permit.run['replicate_id'])]
        wanted=dict(pilot={g:rr[g]['pilot_rank'] for g in 'ABC'},formal={g:rr[g]['formal_rank'] for g in 'ABC'})
        if run!=permit.run or context!=permit.context or method!=run['method_id'] or authority_hashes!=permit.hashes or root!=Path(permit.study_root)/'slots'/run['run_id'] or ranks!=wanted or cfg!=fixed_config(wanted['pilot'],wanted['formal']) or req!=request_from_groups(req.groups,req.operator,scope='actual_bound'):raise NotReady('private execution inputs differ from the admitted request/config/ranks')
    elif req.scope!='artificial' or not root.is_relative_to(ROOT/'artificial_runs'):
        raise NotReady('unadmitted execution scope/path')
    from durable_cache import DurableVectorCache
    from private_observer import PrivateObserver
    from codec import atomic_json as private_json,set_output_budget,fee_accounting
    from fee_adapter import fee_account
    set_output_budget(root,limits['slot_logical_bytes'])
    cache=DurableVectorCache(req.operator,tuple(r for g in req.groups for r in g.records),provider,root,run['run_id'],scope=req.scope,cache_scope='cold_request')
    observer=PrivateObserver(root,run['run_id'],cache)
    try:
        wrapped=dispatch(req,cfg,cache,method,ranks,observer.local if method.startswith('Vector') else observer.external)
        result=wrapped['result'];failed=bool(result.get('failure') or result.get('error'))
        if cache._session is not None:raise WorkerCensor('algorithm left active request')
        observations=observer.finish();wrapped['result']={k:v for k,v in result.items() if k not in ('history','output_history')}
        private_json(root/'private/RUN_PACKET.json',dict(schema='bound-private-online-packet/v2',scope=req.scope,context=context,run=run,
            authority_bindings=authority_hashes,config=cfg,method=wrapped,observations=observations,no_postmortem_completion_credit=True))
        cost=cache.seal_cost();cache.close();account=fee_account(root/'FEE_JOURNAL.ndjson',context,run['run_id'],'BOUND_PRIVATE_WORKER')
        if account['state']!='SEALED_EXACT':raise WorkerCensor('unsealed physical account')
        files=inventory(root/'private');files=[dict(x,path='private/'+x['path']) for x in files]
        status='FAILED_CLOSED' if failed else 'NORMAL_CLOSED'
        if req.scope=='actual_bound':require_actual_permit(permit)
        summary=dict(schema='bound-worker-admin-summary/v2',context=context,run=run,status=status,physical_attempts=account['exact_total'],fee_chain=account['last_chain'],files=files,scientific_success='UNKNOWN',scope=req.scope)
        atomic_json(root/'ADMIN_SUMMARY.json',summary)
        atomic_json(root/'WORKER_CLOSED.json',dict(context=context,run=run,status=status,physical_attempts=account['exact_total'],fee_chain=account['last_chain'],summary_sha256=file_hash(root/'ADMIN_SUMMARY.json')))
        return dict(administrative_state=status,scope=req.scope,physical_attempts=account['exact_total'],private_results_decoded=False)
    except BaseException as exc:
        try:observer.tape.close();cache.close()
        finally:
            account=fee_account(root/'FEE_JOURNAL.ndjson',context,run['run_id'],'BOUND_PRIVATE_WORKER');account.update(state='UNSEALED_UNKNOWN_TAIL',exact_total=None,exact_tail='UNKNOWN')
            atomic_json(root/'CENSOR_RETAINED.json',dict(context=context,run=run,error_type=type(exc).__name__,charge=account,no_offline_promotion=True))
        return dict(administrative_state='CENSORED_UNKNOWN',known_durable_submitted_prefix=account['known_durable_submitted_prefix'],exact_total=None,private_results_decoded=False)

def main():
    p=argparse.ArgumentParser();p.add_argument('--mode',choices=['actual_bound'],required=True);p.add_argument('--outdir');p.add_argument('--admission-sha');p.add_argument('--authority-refs');a=p.parse_args()
    if not a.authority_refs:raise NotReady('all current actual requests lack final external authorities; refusing before IO')
    refs=json.loads(a.authority_refs)
    signal.signal(signal.SIGTERM,lambda *_:(_ for _ in ()).throw(WorkerCensor('parent termination')))
    signal.signal(signal.SIGXCPU,lambda *_:(_ for _ in ()).throw(WorkerCensor('CPU')))
    result=run_actual(a.outdir,a.admission_sha,refs);print(json.dumps(result,sort_keys=True),flush=True)
    return 3 if result['administrative_state']=='CENSORED_UNKNOWN' else 0
if __name__=='__main__':
    try:raise SystemExit(main())
    except BaseException as exc:
        if isinstance(exc,SystemExit):raise
        print(json.dumps(dict(administrative_state='NOT_READY_OR_STARTUP_CENSOR',error_type=type(exc).__name__,private_results_decoded=False)),flush=True);raise SystemExit(4)
