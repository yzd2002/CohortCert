"""Explicit control-only P5->P6 edits; never changes any statistical module."""
from pathlib import Path
import shutil

P=Path(__file__).resolve().parent
A=P.parent/'mast_independent_admin51_verifier_candidate_v1'

def change(path,pairs):
    text=path.read_text()
    for old,new in pairs:
        if old not in text:raise ValueError((path.name,old))
        text=text.replace(old,new)
    path.write_text(text)

def main():
    change(P/'contract.py',[('P5 only permits explicit unclaimed52 continuation','P6 only permits explicit unclaimed51 continuation')])
    change(P/'authority_v2.py',[('required before case4','required before case5')])
    change(P/'controller.py',[('UNKNOWN_CAP_BASED_RESERVATION_1642','UNKNOWN_CAP_BASED_RESERVATION_2084')])
    for root in (P,A):
        change(root/'bound_entropy_origin.py',[('unclaimed52','unclaimed51')])
    shutil.copyfile(P/'continuation_contract.py',A/'continuation_contract.py')
    change(A/'admin_verifier.py',[
      ('continuation52','continuation51'),("expected['runs'][4:]","expected['runs'][5:]"),
      ("len(bundle['runs'])!=52","len(bundle['runs'])!=51"),('exact52','exact51'),
      ('52 source continuation','51 source continuation'),("get('planned_slot_count')!=52","get('planned_slot_count')!=51"),
      ('external all56 seal identity','external all51 seal identity'),('len(rows)!=52','len(rows)!=51'),
      ('all52 terminal','all51 terminal'),("integer(run['slot'],4,55)","integer(run['slot'],5,55)"),
      ('range(4,56)','range(5,56)'),('source52 contains','source51 contains'),
      ('VERIFIED_ALL_FINAL_52_SLOTS_ADMIN_ONLY','VERIFIED_ALL_FINAL_51_SLOTS_ADMIN_ONLY'),
      ('planned_slot_count=52','planned_slot_count=51'),('ALL52_ADMIN_PERMISSION.json','ALL51_ADMIN_PERMISSION.json'),
      ('fixed external52permission','fixed external51permission')])

if __name__=='__main__':main()
