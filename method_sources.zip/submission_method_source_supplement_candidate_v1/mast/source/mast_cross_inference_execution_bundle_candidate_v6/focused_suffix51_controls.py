"""New51 scope and accounting checks; one new fake child, no algorithms."""
from pathlib import Path
from copy import deepcopy
import json,os,sys,resource,time,traceback
ROOT=Path(__file__).resolve().parent
resource.setrlimit(resource.RLIMIT_CPU,(3,4))
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2))
def protect(event,args):
    if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
        p=Path(os.fsdecode(args[0])).resolve()
        if p.is_relative_to(ROOT.parent) and not p.is_relative_to(ROOT):raise PermissionError('new51 controls own code/public/artificial files only')
sys.addaudithook(protect)
from continuation_contract import load_design,bindings,require_worker_run,MODE,DESIGN,PROOF,SCIENCE,ENTROPY,ORIGIN,origin_hashes,forbid_recovery_draw,validate_composite,cumulative_cpu,cumulative_storage,GlobalClock
from contract import validate_bundle,METHODS
from controller import run_artificial,check_storage
from io_utils import file_hash,load_json,atomic_json
from authority_v2 import require_complete_references,LAUNCH

def expect(exc,fn):
    try:fn()
    except exc:return
    raise AssertionError('expected rejection')

def make_bundle(d):
    # Small fake resources are confined to ARTIFICIAL_ONLY. The original
    # scientific resources remain unchanged and are tested from the fixed plan.
    limits=deepcopy(d['resource_accounting']['per_case'])
    for value in limits.values():value.update(CPU_soft=1,CPU_hard=2,wall_seconds=3,AS_bytes=128*1024**2)
    return dict(schema='cross-inference-control-bundle/v2',scope='ARTIFICIAL_ONLY',scientific_plan_json=d['original_science_json'],scientific_runs=d['all56_runs'],execution_mode=MODE,continuation_bindings=bindings(d),runs=deepcopy(d['execution_runs']),
        pins=dict(scientific_contract_sha256=SCIENCE,local_bridge_sha256='3abdc38ed11ef68613906cbbe1e6c35dae4e8c56cfa4e16d61b02c782ee08699',external_bridge_sha256='f546b64b82daec438a2b78a2effc4ede131025023ad17e7796def23bafd62d6e',controller_closure_sha256=file_hash(ROOT/'CODE_CLOSURE.json'),entropy_sha256=ENTROPY,data_contract_sha256='a1ce9ee118c06cd2d72b0cff3cd28c6358f89fdbfeaed4ca5423ba9cc49ed690',protocol_sha256='a'*64),
        dispatch={m:dict(kind='FAKE_ONLY',worker_policy=m,worker_code_sha256=file_hash(ROOT/'fake_worker.py'),worker_ready_sha256='b'*64,interpreter=sys.executable) for m in METHODS},
        limits=limits,study_limits=d['resource_accounting']['original_global'],controller_limits=d['resource_accounting']['controller_effective'])

def main(out):
    d=load_design();bundle=make_bundle(d);bound,_=validate_bundle(bundle)
    assert len(bound['runs'])==51 and bound['runs']==d['all56_runs'][5:] and len(bound['scientific_runs'])==56
    for slot in range(5):expect(PermissionError,lambda slot=slot:require_worker_run(d['all56_runs'][slot],d))
    bad=deepcopy(d['execution_runs'][0]);bad['slot']=5.0;expect(PermissionError,lambda:require_worker_run(bad,d))
    for kind in ('retained4','missing51','wrongproof','old52mode'):
        b=deepcopy(bundle)
        if kind=='retained4':b['runs'][0]=deepcopy(d['all56_runs'][4])
        elif kind=='missing51':b['runs'].pop()
        elif kind=='wrongproof':b['continuation_bindings']['unclaimed_proof_sha256']='0'*64
        else:b['execution_mode']='CONTINUATION_UNCLAIMED_SUFFIX52_ORIGINAL_RANKS'
        expect((ValueError,PermissionError),lambda b=b:validate_bundle(b))
    final=dict(bundle=bundle,entropy_binding_mode=MODE,continuation_bindings=bindings(d),study_root=d['new_execution_root'],composite_root=d['composite_root'],entropy_output_path=d['entropy']['path'])
    hs=dict(continuation_plan=DESIGN,unclaimed_proof=PROOF,entropy=ENTROPY,final_protocol='a'*64,core_ready='b'*64,auditor_ready='c'*64,composite_protocol='d'*64)
    assert origin_hashes(final,hs)==ORIGIN
    old=deepcopy(final);old['zero_start_recovery']={};expect(ValueError,lambda:origin_hashes(old,hs))
    expect(PermissionError,lambda:forbid_recovery_draw(final));expect(PermissionError,lambda:require_complete_references({},LAUNCH))
    impl={k:'e'*64 for k in ('collector_manifest_sha256','collector_closure_sha256','composite_admin_manifest_sha256','composite_admin_closure_sha256')}
    cp=dict(schema='fixed56-disjoint-composite-protocol/v2',status='FROZEN_BEFORE_UNCLAIMED51_EXECUTION',scope='ACTUAL_FIXED_RECURSIVE_DISJOINT56',currentstudy_root=d['new_execution_root'],composite_root=d['composite_root'],final_protocol_sha256=hs['final_protocol'],continuation_bindings=bindings(d),implementation_bindings=impl)
    ready=dict(status='READY_FOR_BOUND_DISJOINT56_COMPOSITE',final_protocol_sha256=hs['final_protocol'],composite_protocol_sha256=hs['composite_protocol'],continuation_bindings=bindings(d),implementation_bindings=impl)
    validate_composite(cp,ready,hs,d)
    wrong=deepcopy(cp);wrong['schema']='fixed56-disjoint-composite-protocol/v1';expect(ValueError,lambda:validate_composite(wrong,ready,hs,d))
    wrong=deepcopy(cp);wrong['scope']='ACTUAL_FIXED_DISJOINT56';expect(ValueError,lambda:validate_composite(wrong,ready,hs,d))
    # New numeric debit, boundary storage and original deadline only.
    assert cumulative_cpu(120,17796,0,d)==20000 and cumulative_cpu(120,17796,1,d)>20000
    caps=d['resource_accounting']['original_global'];debit=d['resource_accounting']['old_storage_debit'];reserve=d['resource_accounting']['composite_reserve']
    observed={k:caps[k]-debit[k]-reserve[k] for k in ('files','logical_bytes','allocated_bytes')};observed['free_disk_bytes']=caps['free_disk_floor_bytes']
    check_storage(cumulative_storage(observed,d),caps,study=True)
    bad=dict(observed,files=observed['files']+1);expect(RuntimeError,lambda:check_storage(cumulative_storage(bad,d),caps,study=True))
    deadline=d['resource_accounting']['wall_absolute_deadline_utc_ns'];clock=GlobalClock(d,utc_ns=deadline,monotonic_ns=12345)
    assert clock.remaining(12345)==0;expect(TimeoutError,lambda:clock.require(12345))
    study=ROOT/'artificial_runs/suffix51_one_fake_global5';study.parent.mkdir(exist_ok=True)
    result=run_artificial(bundle,study,stop_after=1)
    barrier=load_json(study/'ALL_SLOTS_TERMINAL.json',2097152)
    assert result['worker_launches']==1 and len(barrier['rows'])==51 and barrier['planned_slot_count']==51
    assert barrier['rows'][0]['run']['slot']==5 and barrier['scientific_planned_slot_count']==56
    assert all((study/f'ROW_{i:03d}.json').is_file() for i in range(5,56))
    assert not any((study/f'ROW_{i:03d}.json').exists() for i in range(5))
    assert all(row['status']=='UNRUN_GLOBAL_STOP' for row in barrier['rows'][1:])
    assert not Path(d['current_authority_root']).exists()
    return dict(status='PASS_NEW_SUFFIX51_CONTROLS',scope='ARTIFICIAL_ONLY_CODE_METADATA_AND_ONE_FAKE_WORKER',execution51=True,scientific56=True,rejected_retained0to4=True,
        new_CPU_debit=2084,new_storage_debit=debit,original_deadline_unchanged=True,old52_CP_rejected=True,
        fake_children_created=1,unrun_rows=50,fake_limits_only=dict(CPU_soft=1,CPU_hard=2,wall_seconds=3,AS_bytes=128*1024**2),
        actual_method_or_import_or_RNG_or_Source_or_authority_actions=0,CPU=time.process_time())

if __name__=='__main__':
    out=ROOT/'suffix51_attempt_01';out.mkdir(exist_ok=False)
    try:r=main(out)
    except BaseException as e:
        atomic_json(out/'RESULTS.json',dict(status='FAILED_RETAINED',error_type=type(e).__name__,message=str(e),traceback=traceback.format_exc(),CPU=time.process_time()));raise
    atomic_json(out/'RESULTS.json',r);print(json.dumps(r,sort_keys=True))
