"""Complete externally hashed plan, capacity64; a count is never an allowlist."""
import copy,json
from hashlib import sha256
from io_utils import object_hash
from continuation_contract import MODE,validate_execution
METHODS=('VectorRoundRobinABC_v1','VectorWidthSumGain_v1','VectorDifficultyWeightedWidthGain_v1','Evergreen_NativeExactVector_v1','Evergreen_ProgressiveNativeVector_RR_v1','SSS_Kelly_FiniteUpperNullCover_RR_v1','SSS_Kelly_CommonLogEvidenceGreedy_v1')
TERMINAL=('WORKER_SEALED','WORKER_FAILED_CLOSED','CENSORED_UNKNOWN','START_FAILED_UNSUBMITTED','UNRUN_GLOBAL_STOP','CLAIM_CONFLICT_UNKNOWN')
def integer(x,low,high):
    if type(x) is not int or not low<=x<=high:raise ValueError('plain integer identity/resource range')
    return x
def digest(x):
    if type(x) is not str or len(x)!=64 or any(c not in '0123456789abcdef' for c in x):raise ValueError('canonical SHA256 required')
    return x
def validate_limits(x,*,max_files=100000):
    fields={'CPU_soft','CPU_hard','wall_seconds','AS_bytes','packet_bytes','slot_files','slot_logical_bytes','slot_allocated_bytes'}
    if type(x) is not dict or set(x)!=fields:raise ValueError('complete fixed method resources')
    soft=integer(x['CPU_soft'],1,86400);integer(x['CPU_hard'],soft,86460);integer(x['wall_seconds'],1,172800)
    integer(x['AS_bytes'],67108864,34359738368);packet=integer(x['packet_bytes'],1024,268435456)
    integer(x['slot_files'],8,max_files);integer(x['slot_logical_bytes'],packet,1<<40);integer(x['slot_allocated_bytes'],packet,1<<41)
def parse_bound_plan(bundle):
    text=bundle.get('scientific_plan_json')
    if type(text) is not str or len(text.encode())>131072:raise ValueError('bounded exact scientific-plan bytes')
    if sha256(text.encode()).hexdigest()!=bundle['pins']['scientific_contract_sha256']:raise ValueError('scientific raw-byte pin mismatch')
    plan=json.loads(text)
    if type(plan) is not dict or type(plan.get('methods')) is not list or type(plan.get('runs')) is not list or type(plan.get('repeats')) is not int or plan['repeats']!=8:raise ValueError('complete scientific method/repeat/run table')
    ids=[m['id'] for m in plan['methods']]
    if any(type(m) is not str or not m or '/' in m or '__' in m for m in ids) or len(set(ids))!=len(ids) or not set(METHODS)<=set(ids) or not 6<=len(ids)<=8:raise ValueError('complete preserved seven-method allowlist plus explicit additions')
    runs=plan['runs'];integer(len(runs),1,64)
    if len(runs)!=8*len(ids):raise ValueError('one full method set per replicate; no missing slots')
    seen=set()
    for slot,row in enumerate(runs):
        if type(row) is not dict or set(row)!={'slot','replicate_id','method_id','run_id'}:raise ValueError('run row fields')
        integer(row['slot'],0,63);integer(row['replicate_id'],0,7)
        if row['slot']!=slot or type(row['method_id']) is not str or row['method_id'] not in ids or type(row['run_id']) is not str or row['run_id']!=f'rep{row["replicate_id"]:02d}__{row["method_id"]}':raise ValueError('literal canonical ordered identity')
        pair=(row['replicate_id'],row['method_id'])
        if pair in seen:raise ValueError('duplicate planned identity')
        seen.add(pair)
    if seen!={(r,m) for r in range(8) for m in ids}:raise ValueError('incomplete repeat/method Cartesian frame')
    if bundle.get('execution_mode')==MODE:validate_execution(bundle)
    elif bundle.get('scope')=='FINAL_BOUND_ACTUAL':raise ValueError('P6 only permits explicit unclaimed51 continuation')
    elif bundle.get('runs')!=runs:raise ValueError('control table differs from bound external plan')
    for row in bundle['runs']:
        if type(row.get('slot')) is not int or type(row.get('replicate_id')) is not int:raise ValueError('control-side ordinal aliases forbidden')
    return plan,tuple(ids)
def validate_bundle(bundle):
    if type(bundle) is not dict or bundle.get('schema')!='cross-inference-control-bundle/v2' or bundle.get('scope') not in ('ARTIFICIAL_ONLY','FINAL_BOUND_ACTUAL'):raise ValueError('explicit v2 bundle/scope')
    pins=bundle.get('pins');required={'scientific_contract_sha256','local_bridge_sha256','external_bridge_sha256','controller_closure_sha256','entropy_sha256','data_contract_sha256','protocol_sha256'}
    if type(pins) is not dict or set(pins)!=required:raise ValueError('complete external pins')
    for key,x in pins.items():
        digest(x)
    plan,methods=parse_bound_plan(bundle)
    if bundle['scope']=='FINAL_BOUND_ACTUAL' and (bundle.get('status')!='FINAL_FIXED_PROTOCOL' or plan.get('execution_authorized') is not True or plan.get('status')!='FINAL_FIXED_SCIENTIFIC_CONTRACT'):raise ValueError('draft is not actual protocol')
    if bundle['scope']=='FINAL_BOUND_ACTUAL':validate_limits(bundle.get('controller_limits'),max_files=1000000)
    dispatch=bundle.get('dispatch');limits=bundle.get('limits')
    if type(dispatch) is not dict or set(dispatch)!=set(methods) or type(limits) is not dict or set(limits)!=set(methods):raise ValueError('every explicit method requires dispatch/resources')
    for method in methods:
        d=dispatch[method]
        if type(d) is not dict or set(d)!={'kind','worker_policy','worker_code_sha256','worker_ready_sha256','interpreter'}:raise ValueError('complete dispatch fields')
        if d['kind'] not in ('FAKE_ONLY','BOUND_PRIVATE_WORKER') or type(d['worker_policy']) is not str or d['worker_policy']!=method or type(d['interpreter']) is not str or not d['interpreter'].startswith('/'):raise ValueError('literal dispatch mapping')
        digest(d['worker_code_sha256']);digest(d['worker_ready_sha256']);validate_limits(limits[method])
    if bundle['scope']=='FINAL_BOUND_ACTUAL':
        resources=plan.get('resources')
        if type(resources) is not dict or resources.get('status')!='PROSPECTIVELY_FIXED_FROM_ARTIFICIAL_PROFILES_NO_ACTUAL_LAUNCH_AUTHORITY':raise ValueError('prospective scientific resource policy missing')
        if limits!=resources.get('per_method') or bundle['controller_limits']!=resources.get('controller') or bundle.get('study_limits')!=resources.get('study'):raise ValueError('runtime resources differ from the frozen scientific policy')
    study=bundle.get('study_limits')
    if type(study) is not dict or set(study)!={'files','logical_bytes','allocated_bytes','free_disk_floor_bytes','CPU_seconds','wall_seconds'}:raise ValueError('fixed study resources')
    integer(study['files'],64,1000000);integer(study['logical_bytes'],65536,1<<44);integer(study['allocated_bytes'],65536,1<<45)
    integer(study['free_disk_floor_bytes'],0,1<<44);integer(study['CPU_seconds'],1,1<<24);integer(study['wall_seconds'],1,1<<25)
    return copy.deepcopy(bundle),object_hash(bundle)
