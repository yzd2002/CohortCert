"""Freeze only this new amendment candidate; never runs a scientific audit."""
from pathlib import Path
from hashlib import sha256
from decimal import Decimal,ROUND_FLOOR
import ast,json,resource,time
from environment_bootstrap import ROOT,bindings,h,load,put,verify_auditor,require

resource.setrlimit(resource.RLIMIT_CPU,(4,5))
def write(path,obj):path.write_text(json.dumps(obj,indent=2,sort_keys=True,ensure_ascii=False)+'\n')
def main():
    b=bindings();raw,refs=verify_auditor(b)
    require(h(b['native_environment_ref']['path'])==b['native_environment_ref']['sha256'],'E675_METADATA_CHANGED')
    env=load(b['native_environment_ref']['path']);source_members=load(b['auditor_closure_ref']['path'])['files']
    preflight=ROOT/'code_import_attempt_01';receipt=load(preflight/'TERMINAL_RECEIPT.json');imp=load(preflight/'IMPORT_RESULT.json')
    require(receipt['status']=='PASS_CODE_ONLY_IMPORT_PREFLIGHT' and receipt['import_result_sha256']==h(preflight/'IMPORT_RESULT.json'),'EXACT_PREFLIGHT_RECEIPT_REQUIRED')
    require(imp['actual_CI_query_method_model_profile_or_input_operations']==0 and imp['blocked_CI_query_calls']==[] and imp['grid']==100,'CODE_ONLY_IMPORT_BOUNDARY')
    require(all(imp['package_versions'][name]==meta['version'] for name,meta in b['packages'].items()),'ORIGINAL_PACKAGE_VERSIONS')
    require(imp['sys_executable']==b['original_interpreter']['path'] and imp['PYTHONPATH']==b['native_site_packages'],'ORIGINAL_INTERPRETER_AND_FIXED_IMPORT_CONTEXT')
    owned=load(ROOT/'OWNED_COMPARISON_ACCEPTANCE.json');require(owned['status']=='PASS_OWNED_METADATA_COMPARISON_ONLY' and owned['Native_CI_or_method_or_actual_audit_operations']==0,'OWNED_METADATA_TEST_SCOPE')
    cap=int((Decimal(7200)-Decimal(b['old_CPU_debit'])-Decimal(45)-Decimal(10)).to_integral_value(rounding=ROUND_FLOOR))
    require(cap==b['new_auditor_CPU_hard']==7043 and b['new_auditor_CPU_soft']==6843,'NO_CPU_ALLOWANCE_RESET')
    require(b['original_absolute_deadline_utc_ns']==b['original_claim_mtime_ns']+172800*10**9,'NO_WALL_RESET')
    write(ROOT/'ORIGINAL_PRESERVATION.json',dict(status='ORIGINAL_AUD9_22_AND_18REF_BYTES_UNCHANGED',auditor_manifest_ref=b['auditor_manifest_ref'],auditor_closure_ref=b['auditor_closure_ref'],original22_members=source_members,original_authority_refs_ref=b['authority_refs_ref'],original18_role_names=list(refs),native_environment_ref=b['native_environment_ref'],original_execution_claim_ref=b['original_execution_claim_ref'],original_claim_mtime_ns=b['original_claim_mtime_ns'],original_terminal_receipt_ref=b['original_terminal_receipt_ref'],old_audit_summary_closed_refs=dict(root=b['base_audit_root'],summary_sha256=b['base_summary_sha256'],closed_sha256=b['base_closed_sha256']),actual_original_inputs_opened_by_this_check=False))
    write(ROOT/'STATIC_ENVIRONMENT_EVIDENCE.json',dict(status='PINNED_NATIVE_IMPORT_CONTEXT_AVAILABLE_WITHOUT_INSTALLATION',environment_ref=b['native_environment_ref'],code_files_bound=len(env['files']),original_interpreter=b['original_interpreter'],venv_interpreter=b['venv_interpreter'],same_resolved_binary=True,exact_site_packages=b['native_site_packages'],packages={name:dict(version=meta['version'],pinned_files=len(meta['all_pinned_files']),entry_pin=meta['entry'],version_pin=meta['version_file']) for name,meta in b['packages'].items()},original_estimator_signature=imp['estimator_signature'],original_grid=100,preflight_receipt_sha256=h(preflight/'TERMINAL_RECEIPT.json'),preflight_import_result_sha256=h(preflight/'IMPORT_RESULT.json'),no_Native_CI_or_query_or_profile_executed=True,no_package_install_or_upgrade=True,actual_revalidation_runs=0))
    # Static control review: the audit child executes original entry, not bootstrap.
    text=(ROOT/'revalidate_supervisor.py').read_text();tree=ast.parse(text)
    require("str(Path(b['auditor_root'])/'auditor.py')" in text and "'--authority-refs',raw.decode()" in text and 'preexec_fn=child_limits' in text,'DIRECT_ORIGINAL_AUD9_ENTRY_AND_REFS')
    require('compare_closed(b)' in text and 'window=remaining(b)' in text,'FULL56_COMPARISON_AND_OLD_DEADLINE')
    for path in ROOT.glob('*.py'):compile(path.read_bytes(),str(path),'exec')
    runtime=['environment_bootstrap.py','revalidate_supervisor.py','compare_audits.py','FROZEN_BINDINGS.json','AMENDMENT.json']
    closure=dict(schema='same-original-Aud9-native-context-repair-runtime/v1',status='CANDIDATE_NOT_INDEPENDENT_READY',actual_execution_authorized=False,files=[dict(path=name,bytes=(ROOT/name).stat().st_size,sha256=h(ROOT/name)) for name in runtime])
    write(ROOT/'CODE_CLOSURE.json',closure)
    common=['candidate_manifest_sha256','candidate_closure_sha256','amendment_sha256','original_authority_refs_sha256','native_environment_sha256','original_summary_sha256','original_closed_sha256','new_audit_root','original_absolute_deadline_utc_ns','new_CPU_soft','new_CPU_hard','no_method_or_rank_retry','no_best_version_selection']
    interface=dict(schema='same-original-Aud9-native-context-amendment-interface/v1',status='CANDIDATE_NO_ACTUAL_PERMISSION',supervisor=str(ROOT/'revalidate_supervisor.py'),exact_original_auditor_entry=str(Path(b['auditor_root'])/'auditor.py'),original18_ref_file=b['authority_refs_ref'],original22_closure=b['auditor_closure_ref'],environment_ref=b['native_environment_ref'],environment_change=dict(PYTHONPATH=b['native_site_packages'],same_original_interpreter=b['original_interpreter']['path'],no_bootstrap_module_in_Aud9=True,no_admission_or_guard_patch=True,no_package_install_upgrade=True),implementation_ready_status='READY_FOR_SAME_ORIGINAL_AUD9_NATIVE_CONTEXT_AMENDMENT',one_time_permission_status='AUTHORIZED_ONCE_DETERMINISTIC_AUD9_ENV_REVALIDATION',common_required_fields=common,ready_extra_fields=['code_import_preflight_receipt_sha256'],permission_extra_fields=['implementation_ready_sha256'],one_time_permission_path=str(ROOT.parent/'mast_native_ci_environment_revalidation_request_v1/EXECUTION_PERMISSION.json'),new_audit_root=b['new_audit_root'],claim_and_terminal_under=str(ROOT.parent/'mast_native_ci_environment_revalidation_request_v1'),mandatory_result_gate='AMENDED_AUD9_CLOSED_AND_FULL56_COMPARISON_PASSED terminal receipt plus exact56 comparison; raw new SUMMARY/CLOSED alone is not amendment admission',fixed_complete_set_count=45,fixed_target_slots=b['target_normal_unavailable_slots'],fixed_permanent_censors=b['permanent_censor_slots'],allow_target_VERIFIED_INCOMPLETE_ERROR_or_UNKNOWN=True,no_case_splice_or_best_version_choice=True,old_UNKNOWN_history_immutable=True,actual_execution_authorized=False)
    write(ROOT/'CONSUMER_INTERFACE.json',interface)
    write(ROOT/'RESOURCE_SUMMARY.json',dict(scope='POSTSEAL_DETERMINISTIC_VERIFICATION_AMENDMENT_AND_DISCLOSED_PREPARATION',old_supervisor_CPU='0.328101608',old_waited_subtree_CPU='101.517266',old_cumulative_debit=b['old_CPU_debit'],original7200_remaining_floor=7098,preflight_reserved_CPU=45,preflight_actual_supervisor_CPU=receipt['supervisor_CPU_seconds'],preflight_actual_waited_import_aux_CPU=receipt['waited_import_and_auxiliary_subtree_CPU_seconds'],preflight_wall_seconds=receipt['wall_seconds'],no_reservation_refund=True,new_supervisor_reserved_CPU=10,new_child_CPU_soft_hard=[6843,7043],supervisor_inherited_CPU_hard=7200,supervisor_effective_CPU_timer=10,bridge_child_CPU_soft_hard=[20,25],aggregate7200_hard_claimed=False,final_observed_cumulative_soft_check=True,original_deadline_utc_ns=b['original_absolute_deadline_utc_ns'],AS_bytes=2147483648,nice=10,threads=1,owned_metadata_comparison_CPU=owned['CPU_seconds'],other_static_code_preparation_CPU_not_exhaustively_profiled=True,freeze_CPU_sample=time.process_time(),actual_CI_method_model_profile_or_audit_runs=0,source192_raw_or_map_reads=0))
    write(ROOT/'READINESS.json',dict(status='NOT_READY_REQUIRES_NON_AUTHOR_AMENDMENT_AND_IMPLEMENTATION_REVIEW',independent_ready_issued_by_author=False,actual_revalidation_permission_issued=False,actual_revalidation_runs=0,code_only_import_preflight_passed=True,owned_metadata_comparison_passed=True,original_Aud9_22_and_18refs_preserved=True,original_math_params_and_rows_immutable=True,requires=['Independent review of the disclosed posthoc plan/resource amendment','Independent code/supervisor/environment/result-gate review','Distinct exact one-time permission before deterministic second verification','After execution admit the entire amended audit only through full56 comparison and terminal receipt; retain all adverse targets and all old artifacts']))
    report='''Native CI环境加载修正候选（作者交付，非独立Ready）

已静态确认原e675闭包包含multiprocess0.70.18及44文件、dill0.4.1及46文件，所有14762代码文件在唯一代码导入预检中核过原hash；无需安装或升级。原解释器与.venv/bin/python均解析到同一已冻结Python二进制。仅加入原site-packages导入上下文即可成功导入原evergreen.estimator，其classmethod签名和默认grid100与原load_same_kernel ABI吻合。

唯一code-only import通过，监督器CPU0.134679568、等待import/准许uname子树CPU10.317613，wall60.002447965秒。没有调用CI、构造真实query、运行方法/model/profile/实际audit或读取实际输入，未打开原rank/label/private proof/Source192。保留45CPU预留，不据成功退回。小型owned元数据比较验收另为0.108270251CPU，仅检查全56版本比较策略，不是实际结果或补验。

AMENDMENT明确：原单次审计计划已发生环境可用性缺项；若未来获准，将执行第2次确定性验证，同原56不可变轨迹、同原18refs字节和同Aud9全部22文件。原数学、参数、阈值、风险、grid与原方法执行完全不变，不增加统计试验或数据/模型/随机秩。该事后第二次验证必须公开披露，不能冒称原单次计划本已允许，也不能在两版之间择优。

新监督器只在自身进程构造环境，直接执行原auditor.py；不向Aud9 sys.modules注入包装模块，不伪装__main__，不改或绕过原admission、CI consumer或allowlist。先验证原22文件及e675代码闭包，再以原解释器和原18ref原字节启动。当前候选没有实际许可，也未运行真实审计或CI。

未来新目录必须一次完整复核56，并严格比较：原45complete及4censor的49份CASE字节完全相同；仅七个固定正常-unavailable行可依法形成VERIFIED_COMPLETE/INCOMPLETE、ERROR或UNKNOWN，原源身份与物理费用不变。summary权威/真值/范围/来源不变，所有方法各8路径及四预算完整重算。任何非目标变化或资源/墙时超限使新验证整体不准入，保留全部输出；目标ERROR等不利结果也必须保留，不能用七行拼接或择优版本。原23ac/6bc7与七UNKNOWN永久留档，censor3/4/49/55不晋升或重试。

资源明确扣旧101.845367608，保留preflight45及新supervisor10，故新Aud9软6843/硬7043，均低于6898/7098上限。父监督器继承hard7200以便子进程装限，但自身以CPU timer10有效停止；bridge原20/25另列，非aggregate7200硬保证。最终还检查已观测累计debit+waitedCPU<7200。原claim mtime+48h deadline1794021106834398524不延长；AS2GiB、nice10、线程1不变。所有旧日志、失败和新准备开销保留，未测全的静态代码准备CPU不冒称零。

本候选仍需非作者对修正计划、代码、资源和准入策略审查，并由Root另发精确一次执行许可。代码导入成功不证明七行数值验证必过，也不是实际科学结果/论文grade授权。
'''
    (ROOT/'AUTHOR_REPORT.txt').write_text(report)
    files=[]
    for path in sorted(ROOT.rglob('*')):
        if path.is_file() and path!=ROOT/'DELIVERY_MANIFEST.json' and '__pycache__' not in path.parts:
            files.append(dict(path=path.relative_to(ROOT).as_posix(),bytes=path.stat().st_size,sha256=h(path)))
    write(ROOT/'DELIVERY_MANIFEST.json',dict(schema='same-original-Aud9-native-context-amendment-candidate/v1',status='CANDIDATE_NOT_INDEPENDENT_READY_NO_ACTUAL_PERMISSION',amendment_sha256=h(ROOT/'AMENDMENT.json'),code_closure_sha256=h(ROOT/'CODE_CLOSURE.json'),native_environment_sha256=b['native_environment_ref']['sha256'],original_Aud9_manifest_sha256=b['auditor_manifest_ref']['sha256'],original18_refs_sha256=b['authority_refs_ref']['sha256'],files=files))
    print(json.dumps(dict(status='FROZEN_REPAIR_AND_AMENDMENT_CANDIDATE_ONLY',manifest_sha256=h(ROOT/'DELIVERY_MANIFEST.json'),closure_sha256=h(ROOT/'CODE_CLOSURE.json'),amendment_sha256=h(ROOT/'AMENDMENT.json'),supervisor_sha256=h(ROOT/'revalidate_supervisor.py'),preflight_receipt_sha256=h(preflight/'TERMINAL_RECEIPT.json'),actual_revalidation_runs=0),sort_keys=True))

if __name__=='__main__':main()
