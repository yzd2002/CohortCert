"""Candidate second deterministic Aud9 verification; requires separate permission."""
from pathlib import Path
from decimal import Decimal
import argparse,json,os,resource,signal,subprocess,sys,time
from environment_bootstrap import ROOT,bindings,h,load,put,require,verify_auditor,verify_environment,child_environment,child_limits,remaining,supervisor_limits
from compare_audits import compare_closed

def read_public_ref(text):
    ref=json.loads(text);require(set(ref)=={'path','sha256'},'EXTERNAL_PUBLIC_REF_REQUIRED')
    p=Path(ref['path']);require(p.is_absolute() and 'private' not in p.parts and p.name not in ['ACTUAL_ENTROPY_RANKS.json','LOCKED_LABEL_VECTORS.json','RECORD_IDENTITIES.json'],'PUBLIC_IMPLEMENTATION_AUTHORITY_ONLY')
    require(h(p)==ref['sha256'],'IMPLEMENTATION_AUTHORITY_SHA_CHANGED');return ref,load(p)

def main():
    b=bindings();supervisor_limits(10,8)
    ap=argparse.ArgumentParser();ap.add_argument('--implementation-ready-ref',required=True);ap.add_argument('--revalidation-permission-ref',required=True);args=ap.parse_args()
    require(sys.executable==b['original_interpreter']['path'],'EXACT_ORIGINAL_INTERPRETER_PATH')
    ready_ref,ready=read_public_ref(args.implementation_ready_ref);permission_ref,permission=read_public_ref(args.revalidation_permission_ref)
    manifest=h(ROOT/'DELIVERY_MANIFEST.json');closure=h(ROOT/'CODE_CLOSURE.json');amendment=h(ROOT/'AMENDMENT.json')
    common=dict(candidate_manifest_sha256=manifest,candidate_closure_sha256=closure,amendment_sha256=amendment,original_authority_refs_sha256=b['authority_refs_ref']['sha256'],native_environment_sha256=b['native_environment_ref']['sha256'],original_summary_sha256=b['base_summary_sha256'],original_closed_sha256=b['base_closed_sha256'],new_audit_root=b['new_audit_root'],original_absolute_deadline_utc_ns=b['original_absolute_deadline_utc_ns'],new_CPU_soft=b['new_auditor_CPU_soft'],new_CPU_hard=b['new_auditor_CPU_hard'],no_method_or_rank_retry=True,no_best_version_selection=True)
    require(ready.get('status')=='READY_FOR_SAME_ORIGINAL_AUD9_NATIVE_CONTEXT_AMENDMENT' and all(ready.get(k)==v for k,v in common.items()),'INDEPENDENT_AMENDMENT_IMPLEMENTATION_READY_REQUIRED')
    require(permission.get('status')=='AUTHORIZED_ONCE_DETERMINISTIC_AUD9_ENV_REVALIDATION' and permission.get('implementation_ready_sha256')==ready_ref['sha256'] and all(permission.get(k)==v for k,v in common.items()),'DISTINCT_ONE_TIME_REVALIDATION_PERMISSION_REQUIRED')
    request=ROOT.parent/'mast_native_ci_environment_revalidation_request_v1'
    require(Path(permission_ref['path']).resolve()==request/'EXECUTION_PERMISSION.json' and request.is_dir() and request.resolve()==request,'CANONICAL_NEW_REVALIDATION_PERMISSION')
    for row in load(ROOT/'CODE_CLOSURE.json')['files']:
        p=ROOT/row['path'];require(not p.is_symlink() and p.resolve().is_relative_to(ROOT) and p.stat().st_size==row['bytes'] and h(p)==row['sha256'],'REPAIR_CODE_CLOSURE_CHANGED')
    preflight=ROOT/'code_import_attempt_01/TERMINAL_RECEIPT.json';receipt=load(preflight)
    require(receipt['status']=='PASS_CODE_ONLY_IMPORT_PREFLIGHT' and ready.get('code_import_preflight_receipt_sha256')==h(preflight),'EXACT_APPROVED_IMPORT_PREFLIGHT_REQUIRED')
    raw,refs=verify_auditor(b)
    verify_environment(b) # Validate the exact code directory before child startup.
    out=Path(b['new_audit_root']);require(not out.exists() and not out.is_symlink() and out.parent==ROOT.parent,'NEW_AUDIT_OUTPUT_ONLY')
    window=remaining(b);require(window>0,'ORIGINAL48H_AUDIT_WINDOW_EXPIRED')
    put(request/'REVALIDATION_EXECUTION_CLAIM.json',dict(once=True,verification_run_number=2,explicit_posthoc_availability_amendment=True,implementation_ready_ref=ready_ref,execution_permission_ref=permission_ref,bindings=common,old_CPU_debit=b['old_CPU_debit'],preflight_reservation=45,new_supervisor_reservation=10,bridge_CPU_soft_hard=[20,25],aggregate_hard7200_claimed=False,old48h_window_not_reset=True))
    c0=resource.getrusage(resource.RUSAGE_CHILDREN);p=None;code=None;error=None;cleanup=None;comparison=None;start=time.monotonic()
    try:
        with (request/'STDOUT.log').open('xb') as stdout,(request/'STDERR.log').open('xb') as stderr:
            # Original entry file,original interpreter and original18ref bytes.
            # Only the already pinned import directory is added in the environment.
            p=subprocess.Popen([b['original_interpreter']['path'],'-B',str(Path(b['auditor_root'])/'auditor.py'),'--authority-refs',raw.decode(),'--outdir',str(out)],stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,close_fds=True,start_new_session=True,preexec_fn=child_limits(b['new_auditor_CPU_soft'],b['new_auditor_CPU_hard'],window),env=child_environment(b))
            put(request/'PROCESS_STARTED.json',dict(pid=p.pid,supervisor_pid=os.getpid(),new_audit_root=str(out),same_original_auditor_entry=True,no_bootstrap_module_in_auditor_process=True))
            code=p.wait(timeout=window)
        if code==0:
            require(remaining(b)>0,'ORIGINAL48H_WINDOW_EXPIRED_BEFORE_COMPARISON')
            checked=compare_closed(b)
            verify_auditor(b)  # No original package/request/claim changes during the run.
            require(remaining(b)>0,'ORIGINAL48H_WINDOW_EXPIRED_DURING_COMPARISON')
            comparison=checked;put(request/'FULL56_COMPARISON.json',comparison)
    except BaseException as exc:
        error=type(exc).__name__
        if p is not None:
            try:
                if p.poll() is None:p.kill() # This original owned Popen only.
                code=p.wait()
            except BaseException as e:cleanup=type(e).__name__
    c1=resource.getrusage(resource.RUSAGE_CHILDREN)
    waited=c1.ru_utime+c1.ru_stime-c0.ru_utime-c0.ru_stime
    cumulative=Decimal(b['old_CPU_debit'])+Decimal(45)+max(Decimal(10),Decimal(str(time.process_time())))+Decimal(str(waited))
    if cumulative>=Decimal(7200) or remaining(b)<=0:
        error=error or 'CUMULATIVE_VERIFICATION_RESOURCE_OR_ORIGINAL_WALL_EXCEEDED'
    passed=comparison is not None and comparison['status']=='PASS_FULL56_DETERMINISTIC_AMENDMENT_COMPARISON' and error is None and code==0
    terminal=dict(status='AMENDED_AUD9_CLOSED_AND_FULL56_COMPARISON_PASSED' if passed else 'REVALIDATION_INCOMPLETE_OR_INCONSISTENT_RETAIN_ALL_NO_RETRY',verification_run_number=2,exit_code=code,error_type=error,cleanup_error_type=cleanup,old_CPU_debit=b['old_CPU_debit'],preflight_cap_reservation=45,new_supervisor_cap_reservation=10,supervisor_CPU_seconds=time.process_time(),waited_auditor_and_reaped_bridge_CPU_seconds=waited,cumulative_cap_debit_plus_observed_waited_CPU=str(cumulative),final_observed_cumulative_below7200=cumulative<Decimal(7200),wall_seconds=time.monotonic()-start,original_absolute_deadline_utc_ns=b['original_absolute_deadline_utc_ns'],new_CPU_soft_hard=[b['new_auditor_CPU_soft'],b['new_auditor_CPU_hard']],bridge_child_CPU_soft_hard=[20,25],aggregate_hard7200_claimed=False,original_audit_unchanged=True,original7_UNKNOWN_and4_censors_retained_as_history=True,no_result_or_version_selection=True,no_new_method_model_data_or_study_RNG=True,unreaped_or_surviving_descendants_are_UNKNOWN=True)
    if passed:terminal.update(new_summary_sha256=comparison['new_summary_sha256'],new_closed_sha256=comparison['new_closed_sha256'])
    put(request/'TERMINAL_RECEIPT.json',terminal)
    signal.setitimer(signal.ITIMER_PROF,0,0)
    print(json.dumps({k:terminal[k] for k in ['status','verification_run_number','error_type','aggregate_hard7200_claimed']},sort_keys=True))

if __name__=='__main__':main()
