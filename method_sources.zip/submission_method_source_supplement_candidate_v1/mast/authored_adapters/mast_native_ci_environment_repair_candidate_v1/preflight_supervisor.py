"""Exactly one bounded Native code-import preflight; no audit or CI invocation."""
from pathlib import Path
import os,resource,subprocess,sys,time
from environment_bootstrap import ROOT,bindings,child_environment,child_limits,remaining,supervisor_limits,put,h,load,require

def main():
    b=bindings();supervisor_limits(5,4)
    require(sys.executable==b['original_interpreter']['path'],'ORIGINAL_INTERPRETER_PATH_REQUIRED')
    window=min(180,remaining(b));require(window>0,'ORIGINAL_AUDIT_DEADLINE_EXPIRED')
    out=ROOT/'code_import_attempt_01';out.mkdir(exist_ok=False)
    put(out/'PREFLIGHT_CLAIM.json',dict(once=True,plan_sha256=h(ROOT/'PREFLIGHT_RESOURCE_PLAN.json'),amendment_sha256=h(ROOT/'AMENDMENT.json'),preflight_code_sha256=h(ROOT/'code_import_preflight.py'),bootstrap_code_sha256=h(ROOT/'environment_bootstrap.py'),native_environment_ref=b['native_environment_ref'],CPU_reservation=45,deadline_utc_ns=b['original_absolute_deadline_utc_ns'],actual_CI_or_audit_allowed=False))
    c0=resource.getrusage(resource.RUSAGE_CHILDREN);child=None;code=None;error=None;cleanup=None;start=time.monotonic()
    try:
        with (out/'STDOUT.log').open('xb') as stdout,(out/'STDERR.log').open('xb') as stderr:
            child=subprocess.Popen([b['original_interpreter']['path'],'-B',str(ROOT/'code_import_preflight.py')],cwd=out,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,close_fds=True,start_new_session=True,preexec_fn=child_limits(18,20,window),env=child_environment(b,out/'native_cache'))
            code=child.wait(timeout=window)
    except BaseException as exc:
        error=type(exc).__name__
        if child is not None:
            try:
                if child.poll() is None:child.kill()
                code=child.wait()
            except BaseException as e:cleanup=type(e).__name__
    c1=resource.getrusage(resource.RUSAGE_CHILDREN)
    passed=code==0 and error is None and (out/'IMPORT_RESULT.json').is_file() and load(out/'IMPORT_RESULT.json').get('status')=='PASS_STRICT_CODE_ONLY_NATIVE_IMPORT'
    receipt=dict(status='PASS_CODE_ONLY_IMPORT_PREFLIGHT' if passed else 'PREFLIGHT_UNKNOWN_OR_FAILED_RETAIN_NO_RETRY',exit_code=code,error_type=error,cleanup_error_type=cleanup,supervisor_CPU_seconds=time.process_time(),waited_import_and_auxiliary_subtree_CPU_seconds=c1.ru_utime+c1.ru_stime-c0.ru_utime-c0.ru_stime,wall_seconds=time.monotonic()-start,cap_reservation=45,no_refund=True,actual_CI_query_or_audit_operations=0,original_absolute_deadline_utc_ns=b['original_absolute_deadline_utc_ns'],resource_scope='Supervisor CPU timer effective5 with inherited hard7200; import child self hard20 and at most1 pinned uname child inherited hard20. Not an aggregate hard45 guarantee; timer/blocking/unreaped boundaries retained.')
    if passed:receipt['import_result_sha256']=h(out/'IMPORT_RESULT.json')
    put(out/'TERMINAL_RECEIPT.json',receipt);print(__import__('json').dumps(receipt,sort_keys=True))

if __name__=='__main__':main()
