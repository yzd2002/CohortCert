"""Whole-version comparison; never recompute CI,methods or primary statistics."""
from pathlib import Path
import json
from environment_bootstrap import h,load,require

BUDGETS=('75','150','225','300')
TARGETS={10,16,22,28,41,47,53}
CENSORS={3,4,49,55}
def canonical(x):return (json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)+'\n').encode()

def load_closed(root,summary_sha=None,closed_sha=None):
    root=Path(root);cp=root/'AUDIT_CLOSED.json';sp=root/'SUMMARY.json'
    if closed_sha is not None:require(h(cp)==closed_sha,'EXTERNAL_CLOSED_SHA_CHANGED')
    closed=load(cp);observed=h(sp)
    require(closed['summary_sha256']==observed and (summary_sha is None or observed==summary_sha),'CLOSED_SUMMARY_BINDING')
    files={}
    for row in closed['files']:
        name=row['path'];rel=Path(name)
        require(not rel.is_absolute() and '..' not in rel.parts and rel.as_posix()==name and name not in files,'CANONICAL_UNIQUE_AUDIT_MEMBER')
        p=root
        for part in rel.parts:
            p=p/part;require(not p.is_symlink(),'AUDIT_SYMLINK')
        require(p.is_file() and p.stat().st_size==row['bytes'] and h(p)==row['sha256'],'AUDIT_MEMBER_CHANGED')
        files[name]=row
    require({n for n in files if Path(n).name.startswith('CASE_') and Path(n).suffix=='.json'}=={f'CASE_{i:03d}.json' for i in range(56)},'COMPLETE56_CLOSED_CASES_REQUIRED')
    require('SUMMARY.json' in files and files['SUMMARY.json']['sha256']==observed,'CLOSED_SUMMARY_INVENTORY')
    summary=load(sp);require(summary['context']==closed['context'] and summary['planned_rows']==56,'FULL56_AUDIT_CONTEXT')
    cases=[load(root/f'CASE_{i:03d}.json') for i in range(56)]
    return summary,cases,dict(summary_sha256=observed,closed_sha256=h(cp),members=files)

def compare_metadata(old_summary,old_cases,new_summary,new_cases):
    require(len(old_cases)==len(new_cases)==56,'ALL56_CASES_REQUIRED')
    old_complete={i for i,x in enumerate(old_cases) if x['scientific_status']=='VERIFIED_ONLINE_COMPLETE'}
    require(old_complete==set(range(56))-TARGETS-CENSORS and len(old_complete)==45,'BASE45_COMPLETE_SET_CHANGED')
    require(canonical({k:v for k,v in old_summary.items() if k not in ['methods','resources']})==canonical({k:v for k,v in new_summary.items() if k not in ['methods','resources']}),'SUMMARY_AUTHORITY_TRUTH_SCOPE_OR_SOURCE_CHANGED')
    discovered={}
    for i,(old,new) in enumerate(zip(old_cases,new_cases)):
        require(old['run']['slot']==new['run']['slot']==i and canonical(old['run'])==canonical(new['run']),'ORIGINAL_CASE_IDENTITY_CHANGED')
        if i not in TARGETS:
            require(canonical(old)==canonical(new),'NON_TARGET_CASE_MUTATED_OR_REGRESSED')
        else:
            require(old['status']==new['status']=='WORKER_SEALED' and old['scientific_status']=='UNKNOWN','TARGET_WAS_NOT_OLD_NORMAL_UNAVAILABLE')
            require(new['scientific_status'] in ['VERIFIED_ONLINE_COMPLETE','VERIFIED_INCOMPLETE','ERROR','UNKNOWN'],'TARGET_RESULT_SCHEMA')
            for key in ['status','source_case','source_scientific_credit_allowed','actual_reference_scope','no_offline_promotion','private_result_opened']:
                require(canonical(old.get(key))==canonical(new.get(key)),'TARGET_ORIGINAL_PROVENANCE_OR_PIPELINE_CHANGED')
            for key in ['known_durable_submitted_prefix','exact_total','exact_tail']:
                require(canonical(old['charge'].get(key))==canonical(new['charge'].get(key)),'TARGET_PHYSICAL_FEE_CHANGED')
            discovered[str(i)]=new['scientific_status']
        if i in CENSORS:
            require(new['status']=='CENSORED_UNKNOWN' and new['scientific_status']=='UNKNOWN' and new['charge']['exact_total'] is None and new['charge']['exact_tail']=='UNKNOWN' and not any(new['whole28_primary'].values()),'PERMANENT_CENSOR_PROMOTED')
        primary=new['whole28_primary'];require(set(primary)==set(BUDGETS) and all(type(v) is bool for v in primary.values()),'FOUR_PRIMARY_FLAGS_REQUIRED')
        if any(primary.values()):
            fee=new['charge']['exact_total']
            require(new['status']=='WORKER_SEALED' and new['scientific_status']=='VERIFIED_ONLINE_COMPLETE' and new['source_scientific_credit_allowed'] is True and type(fee) is int and new['charge']['exact_tail']=='KNOWN' and new.get('issues')==[] and new.get('sticky_errors')==[] and all(not primary[k] or fee<=int(k) for k in BUDGETS),'PRIMARY_CREDIT_RULE_CHANGED')
    require(set(new_summary['methods'])==set(old_summary['methods']),'ALL_ORIGINAL_METHODS_REQUIRED')
    for method,block in new_summary['methods'].items():
        rows=[x for x in new_cases if x['run']['method_id']==method]
        require(len(rows)==8 and block['planned_replicates']==8,'ORIGINAL8_DENOMINATOR_CHANGED')
        points=block['points'];require(len(points)==8 and {x['replicate_id'] for x in points}==set(range(8)),'ALL8_SUMMARY_PATHS_REQUIRED')
        for row in rows:
            point=next(x for x in points if x['replicate_id']==row['run']['replicate_id'])
            require(point['scientific_status']==row['scientific_status'] and canonical(point['primary'])==canonical(row['whole28_primary']) and canonical(point['charge'])==canonical(row.get('charge')),'SUMMARY_POINT_DIFFERS_FROM_CASE')
        for budget in BUDGETS:
            entry=block['whole28_correct_complete'][budget]
            require(type(entry['denominator']) is int and entry['denominator']==8 and type(entry['successes']) is int and entry['successes']==sum(x['whole28_primary'][budget] for x in rows),'FULL56_AGGREGATION_CHANGED')
    return dict(status='PASS_FULL56_DETERMINISTIC_AMENDMENT_COMPARISON',unchanged_original_complete_cases=45,permanent_unknown_censors=sorted(CENSORS),target_scientific_statuses=discovered,adverse_target_results_retained=True,no_case_or_best_version_selection=True)

def compare_closed(b):
    old,oc,ob=load_closed(b['base_audit_root'],b['base_summary_sha256'],b['base_closed_sha256'])
    new,nc,nb=load_closed(b['new_audit_root'])
    result=compare_metadata(old,oc,new,nc)
    for i in set(range(56))-TARGETS:
        name=f'CASE_{i:03d}.json';require(ob['members'][name]['sha256']==nb['members'][name]['sha256'],'NON_TARGET_CASE_BYTES_CHANGED')
    result.update(old_summary_sha256=ob['summary_sha256'],old_closed_sha256=ob['closed_sha256'],new_summary_sha256=nb['summary_sha256'],new_closed_sha256=nb['closed_sha256'],all49_non_target_CASE_bytes_identical=True)
    return result
