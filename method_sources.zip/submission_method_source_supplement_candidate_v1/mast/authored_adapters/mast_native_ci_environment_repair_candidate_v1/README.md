This is a proposed post-result audit-availability amendment and a new external
supervisor candidate. It is not actual revalidation permission or an
independently issued Ready. No original Aud9 file, mathematical routine,
parameter,threshold,grid,18-ref input,method output or original audit is changed.

The first audit completed with a missing native import consumer because
multiprocess was unavailable in that process's Python import context. The
approved e675 environment already contains multiprocess0.70.18,dill0.4.1 and
their pinned source. No installation,upgrade or statistical substitution is
proposed. The exact .venv site-packages is added through external PYTHONPATH;
the same original interpreter directly executes the same original auditor.py.
The environment builder stays in the supervisor process and is not imported
or disguised inside Aud9. Original admission and loaded-module checks remain.

AMENDMENT.json explicitly changes the original single-verification plan for
this disclosed availability defect. The proposed second verification consumes
the same immutable56 trajectories and original18-ref bytes deterministically;
it does not run the original methods/models,add observations,draw study ranks,
change risks or repeat a statistical experiment. This is still an additional
posthoc verification run and must be disclosed as such. The original closed
23ac/6bc7 audit and sevenUNKNOWN remain permanently as history.

Before any real second verification, non-author plan/code review and a
separate single-use permission are required. The candidate directly invokes
the unmodified22-member Aud9 closure into one new audit directory,without a
seven-case filter or schema change. It then checks the entire new version.
All45 original VERIFIED_ONLINE_COMPLETE CASE files and all4 censor CASE files
must remain byte-identical. Only the fixed7 originally normal-unavailable rows
may acquire independently established verification,ERROR or UNKNOWN; physical
fees,pipeline identity and original provenance remain fixed. All unfavourable
target outcomes are retained. Any other regression invalidates the new version
as a whole. There is no best-of-two choice or favorable row-level splice.

The cumulative budget retains original supervisorCPU0.328101608 plus waited
subtreeCPU101.517266, debit101.845367608. Before any import,45CPU was reserved
for the single code-import preflight (effective supervisor5,import child20,
and at most one pinned uname metadata helper inheriting20). That reservation
is not refunded. Another10CPU is reserved for the new supervisor's effective
CPU stop. The future audit child is therefore limited to soft6843/hard7043,
below the requested maxima6898/7098. Supervisors preserve inheritance hard7200
so children can install their limits; dedicated process-CPU timers enforce
their declared5/10 effective stops. The unchanged C3 bridge retains20/25CPU
separately. This is not an aggregate7200 hard guarantee; timer delivery,
blocking and surviving/unreaped descendants remain explicit UNKNOWN limits.

The original wall anchor is AUD9_EXECUTION_CLAIM.mtime1793848306834398524 ns,
with deadline1794021106834398524 ns. No new48-hour window is created. Original
AS2GiB,nonoptimized Python,nice10 and one numerical thread are retained. All
old operational failures and receipts remain,with new preparation/import costs
reported separately. No unused reservation is reclaimed based on outcomes.

One strict code-only import preflight was run after the resource/amendment
files were written. It hashes the complete e675 code closure,imports only the
original estimator and approved dependencies,records paths/versions/hashes,
and blocks actual CI/query functions,query construction,network and unapproved
processes/inputs. The sole allowed auxiliary is the already pinned uname -p.
Only the new owned preflight directory may be written. This proves import and
ABI availability,not numerical CI correctness. Normal library import runtime
state is not used as study randomness and no original rank/entropy record is
opened,created or changed. No actual CI,method,Native profile or audit has run.

The small owned comparison check uses synthetic public metadata only. It
checks preservation,adverse ERROR retention and rejection of fee,source,truth,
denominator,censor and missing-case mutations. It is not actual revalidation
and does not predict the seven eventual outcomes. Source192,old4raw and their
maps remain excluded. Full independent review is still required.
