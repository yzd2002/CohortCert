"""External environment construction only; never imported into the Aud9 child."""
from pathlib import Path
from hashlib import sha256
import json,os,resource,signal,stat,sys,time

ROOT=Path(__file__).resolve().parent
def h(path):
    p=Path(path);digest=sha256()
    with p.open('rb') as f:
        for block in iter(lambda:f.read(1024**2),b''):digest.update(block)
    return digest.hexdigest()
def load(path):return json.loads(Path(path).read_bytes())
def bindings():return load(ROOT/'FROZEN_BINDINGS.json')
def require(ok,code):
    if not ok:raise RuntimeError(code)
def verify_environment(b):
    ref=b['native_environment_ref'];require(h(ref['path'])==ref['sha256'],'E675_ENVIRONMENT_CHANGED')
    env=load(ref['path']);require(env['schema']=='complete-worker-environment-binding/v1' and env['complete_loaded_code_allowlist'] is True,'ORIGINAL_COMPLETE_ENVIRONMENT_REQUIRED')
    allowed={}
    for row in env['files']:
        p=Path(row['path']).resolve();s=p.stat()
        require(stat.S_ISREG(s.st_mode) and s.st_size==row['bytes'] and h(p)==row['sha256'],'PINNED_NATIVE_CODE_CHANGED')
        require(str(p) not in allowed or allowed[str(p)]==row['sha256'],'CONFLICTING_CODE_PIN')
        allowed[str(p)]=row['sha256']
    interpreter=b['original_interpreter'];p=Path(interpreter['path']).resolve()
    require(h(p)==interpreter['sha256'] and env['interpreters']==[interpreter],'ORIGINAL_INTERPRETER_CHANGED')
    require(Path(b['venv_interpreter']).resolve()==p,'VENV_INTERPRETER_BINARY_CHANGED')
    site=Path(b['native_site_packages']);require(site.is_dir() and not site.is_symlink() and site.resolve()==site,'CANONICAL_FROZEN_SITE_PACKAGES_REQUIRED')
    for name,meta in b['packages'].items():
        require(all(allowed[str(Path(x['path']).resolve())]==x['sha256'] for x in meta['all_pinned_files']),'NATIVE_PACKAGE_CLOSURE_CHANGED')
    return env,allowed
def verify_auditor(b):
    for key in ['auditor_manifest_ref','auditor_closure_ref','authority_refs_ref','original_execution_claim_ref','original_terminal_receipt_ref']:
        ref=b[key];require(h(ref['path'])==ref['sha256'],'FROZEN_AUDIT_OR_REQUEST_METADATA_CHANGED')
    require(Path(b['original_execution_claim_ref']['path']).stat().st_mtime_ns==b['original_claim_mtime_ns'],'ORIGINAL_WALL_ANCHOR_CHANGED')
    members=load(b['auditor_closure_ref']['path'])['files'];require(len(members)==22,'ORIGINAL22_AUD9_MEMBERS_REQUIRED')
    root=Path(b['auditor_root'])
    for row in members:
        rel=Path(row['path']);require(not rel.is_absolute() and '..' not in rel.parts and rel.as_posix()==row['path'],'CANONICAL_AUDITOR_MEMBER_REQUIRED')
        p=root
        for part in rel.parts:
            p=p/part;require(not p.is_symlink(),'AUDITOR_MEMBER_SYMLINK')
        require(p.stat().st_size==row['bytes'] and h(p)==row['sha256'],'ORIGINAL_AUD9_BYTES_CHANGED')
    raw=Path(b['authority_refs_ref']['path']).read_bytes();refs=json.loads(raw)
    require(len(refs)==18 and refs['native_environment']==b['native_environment_ref'],'ORIGINAL18REFS_REQUIRED')
    return raw,refs
def child_environment(b,cache=None):
    env=dict(os.environ,PYTHONPATH=b['native_site_packages'],PYTHONNOUSERSITE='1',PYTHONOPTIMIZE='0',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
    env.pop('PYTHONHOME',None)
    if cache is not None:env['EVERGREEN_CACHE_DIR_ROOT']=str(cache)
    return env
def remaining(b):return max(0,(b['original_absolute_deadline_utc_ns']-time.time_ns())/10**9)
def supervisor_limits(effective,soft):
    require(sys.flags.optimize==0 and os.getpriority(os.PRIO_PROCESS,0)==10,'TRUSTED_NONOPTIMIZED_NICE10_REQUIRED')
    resource.setrlimit(resource.RLIMIT_CPU,(soft,7200))
    resource.setrlimit(resource.RLIMIT_AS,(256*1024**2,2147483648))
    def interrupted(*_):raise InterruptedError('SUPERVISOR_RESOURCE_OR_TERMINATION')
    signal.signal(signal.SIGXCPU,interrupted);signal.signal(signal.SIGTERM,interrupted)
    signal.signal(signal.SIGPROF,signal.SIG_DFL)
    signal.pthread_sigmask(signal.SIG_UNBLOCK,{signal.SIGPROF,signal.SIGXCPU})
    left=effective-time.process_time();require(left>0,'SUPERVISOR_CPU_RESERVE_EXHAUSTED')
    signal.setitimer(signal.ITIMER_PROF,left,0)
def child_limits(soft,hard,wall):
    def install():
        for sig in [signal.SIGXCPU,signal.SIGPROF,signal.SIGALRM,signal.SIGTERM]:signal.signal(sig,signal.SIG_DFL)
        signal.setitimer(signal.ITIMER_PROF,0,0)
        resource.setrlimit(resource.RLIMIT_CPU,(soft,hard));resource.setrlimit(resource.RLIMIT_AS,(2147483648,2147483648))
        signal.alarm(max(1,int(wall)+1))
    return install
def put(path,obj):
    raw=(json.dumps(obj,indent=2,sort_keys=True,ensure_ascii=False)+'\n').encode()
    with Path(path).open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
    fd=os.open(Path(path).parent,os.O_RDONLY|os.O_DIRECTORY)
    try:os.fsync(fd)
    finally:os.close(fd)
