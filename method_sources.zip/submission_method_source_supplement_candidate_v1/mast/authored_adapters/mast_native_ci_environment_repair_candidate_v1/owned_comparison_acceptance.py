"""Small owned metadata checks only; never imports Native or reads a real audit."""
from copy import deepcopy
from pathlib import Path
import json,resource,sys,time
resource.setrlimit(resource.RLIMIT_CPU,(2,3));resource.setrlimit(resource.RLIMIT_AS,(128*1024**2,128*1024**2))
from compare_audits import compare_metadata,TARGETS,CENSORS,BUDGETS
ROOT=Path(__file__).resolve().parent
METHODS=('VectorRoundRobinABC_v1','VectorWidthSumGain_v1','VectorDifficultyWeightedWidthGain_v1','Evergreen_NativeExactVector_v1','Evergreen_ProgressiveNativeVector_RR_v1','SSS_Kelly_FiniteUpperNullCover_RR_v1','SSS_Kelly_CommonLogEvidenceGreedy_v1')
def expect(fn):
    try:fn()
    except RuntimeError:return
    raise AssertionError('regression or selective revalidation must be rejected')
def summary(cases):
    methods={}
    for method in METHODS:
        rows=[c for c in cases if c['run']['method_id']==method]
        methods[method]=dict(planned_replicates=8,points=[dict(replicate_id=c['run']['replicate_id'],scientific_status=c['scientific_status'],primary=c['whole28_primary'],charge=c['charge']) for c in rows],whole28_correct_complete={k:dict(successes=sum(c['whole28_primary'][k] for c in rows),denominator=8) for k in BUDGETS})
    return dict(context='OWNED_FIXTURE',truth28={'fixture':True},methods=methods,resources={'owned':True})
def main():
    old=[]
    for rep in range(8):
        order=METHODS[rep%7:]+METHODS[:rep%7]
        for method in order:
            i=len(old);state='UNKNOWN' if i in TARGETS|CENSORS else 'VERIFIED_ONLINE_COMPLETE'
            old.append(dict(run=dict(slot=i,method_id=method,replicate_id=rep),status='CENSORED_UNKNOWN' if i in CENSORS else 'WORKER_SEALED',scientific_status=state,charge=dict(known_durable_submitted_prefix=17 if i in CENSORS else 300,exact_total=None if i in CENSORS else 300,exact_tail='UNKNOWN' if i in CENSORS else 'KNOWN'),source_case={'owned':i},source_scientific_credit_allowed=True,actual_reference_scope='OWNED',no_offline_promotion=True,private_result_opened=True,issues=[],sticky_errors=[],whole28_primary={k:state=='VERIFIED_ONLINE_COMPLETE' and k=='300' for k in BUDGETS}))
    new=deepcopy(old);new[10]['scientific_status']='VERIFIED_ONLINE_COMPLETE';new[10]['whole28_primary']['300']=True
    new[16]['scientific_status']='ERROR';new[16]['sticky_errors']=[{'kind':'OWNED_ADVERSE_FIXTURE'}]
    result=compare_metadata(summary(old),old,summary(new),new)
    assert result['status']=='PASS_FULL56_DETERMINISTIC_AMENDMENT_COMPARISON' and result['target_scientific_statuses']['16']=='ERROR'
    changed=deepcopy(new);changed[0]['charge']['exact_total']=299;expect(lambda:compare_metadata(summary(old),old,summary(changed),changed))
    changed=deepcopy(new);changed[49]['scientific_status']='VERIFIED_ONLINE_COMPLETE';expect(lambda:compare_metadata(summary(old),old,summary(changed),changed))
    changed=deepcopy(new);changed[53]['source_case']={'changed':True};expect(lambda:compare_metadata(summary(old),old,summary(changed),changed))
    changed=deepcopy(new);changed[47]['charge']['known_durable_submitted_prefix']=299;expect(lambda:compare_metadata(summary(old),old,summary(changed),changed))
    ns=summary(new);ns['truth28']={'fixture':False};expect(lambda:compare_metadata(summary(old),old,ns,new))
    ns=summary(new);ns['methods'][METHODS[0]]['whole28_correct_complete']['300']['denominator']=7;expect(lambda:compare_metadata(summary(old),old,ns,new))
    expect(lambda:compare_metadata(summary(old),old,summary(new),new[:-1]))
    assert not any(x in sys.modules for x in ['evergreen','confseq','admission','auditor','run_audit'])
    return dict(status='PASS_OWNED_METADATA_COMPARISON_ONLY',original45_unchanged_required=True,all4_censors_immutable=True,target_ERROR_retained_without_best_version_selection=True,source_fee_truth_denominator_and_missing_case_mutations_rejected=True,Native_CI_or_method_or_actual_audit_operations=0,actual_inputs_read=0,CPU_seconds=time.process_time())
if __name__=='__main__':
    path=ROOT/'OWNED_COMPARISON_ACCEPTANCE.json'
    with path.open('x') as f:
        result=main();json.dump(result,f,indent=2,sort_keys=True);f.write('\n')
    print(json.dumps(result,sort_keys=True))
