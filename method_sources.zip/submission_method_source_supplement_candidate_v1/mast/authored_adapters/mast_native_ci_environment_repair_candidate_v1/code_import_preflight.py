"""One strict code-only import. Never calls CI,Native queries or admission."""
from pathlib import Path
import importlib,inspect,json,os,resource,sys,time
from environment_bootstrap import ROOT,bindings,verify_environment,h,put,require

def main():
    started=time.process_time();b=bindings();out=ROOT/'code_import_attempt_01'
    require(out.is_dir(),'OWNED_PREFLIGHT_DIRECTORY_REQUIRED')
    env,allowed=verify_environment(b)
    require(sys.executable==b['original_interpreter']['path'] and h(Path(sys.executable).resolve())==b['original_interpreter']['sha256'],'EXACT_ORIGINAL_EXECUTABLE_REQUIRED')
    require(all(os.environ.get(k)=='1' for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','PYTHONDONTWRITEBYTECODE']),'THREAD_AND_BYTECODE_POLICY')
    aux=env['permitted_readonly_auxiliary'];require(len(aux)==1 and aux[0]['argv']==['uname','-p'] and h(aux[0]['executable'])==aux[0]['sha256'],'ONLY_APPROVED_METADATA_HELPER')
    os.environ['PATH']='/usr/bin:/bin';aux_calls=[0];blocked_calls=[]
    own_code={str(ROOT/'code_import_preflight.py'),str(ROOT/'environment_bootstrap.py')}
    allowed_meta={str(ROOT/'FROZEN_BINDINGS.json'),str(Path(b['native_environment_ref']['path']).resolve())}
    def protect(event,args):
        if event=='socket.connect':raise PermissionError('CODE_IMPORT_NETWORK_FORBIDDEN')
        if event=='subprocess.Popen':
            exe,argv=args[:2]
            require(list(argv)==['uname','-p'] and str(exe) in ['uname',aux[0]['executable']] and aux_calls[0]==0,'ONLY_ONE_PINNED_UNAME_METADATA_HELPER')
            aux_calls[0]+=1
        if event in ['os.system','os.fork','os.forkpty']:raise PermissionError('NO_QUERY_OR_METHOD_PROCESS')
        if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
            p=Path(os.fsdecode(args[0])).resolve();mode,flags=args[1:3]
            writing=(isinstance(mode,str) and any(c in mode for c in 'wax+')) or bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC))
            if p==Path(os.devnull):return
            if writing:
                if not p.is_relative_to(out):raise PermissionError('PREFLIGHT_WRITES_ONLY_OWNED_OUTPUT')
            elif str(p) not in allowed and str(p) not in own_code and str(p) not in allowed_meta and not p.is_relative_to(out):raise PermissionError('ONLY_FROZEN_CODE_READS_NO_INPUTS')
        if event in ['os.mkdir','os.remove','os.rmdir'] and isinstance(args[0],(str,bytes,os.PathLike)):
            if not Path(os.fsdecode(args[0])).resolve().is_relative_to(out):raise PermissionError('NO_MUTATIONS_OUTSIDE_OWNED_PREFLIGHT')
        if event in ['os.rename','os.replace']:
            if any(not Path(os.fsdecode(x)).resolve().is_relative_to(out) for x in args[:2]):raise PermissionError('NO_MUTATIONS_OUTSIDE_OWNED_PREFLIGHT')
    def no_math(frame,event,arg):
        if event!='call':return
        code=frame.f_code
        if code.co_name not in ['estimate_mean','betting_cs','execute_query','evaluate_query','run_query','__init__']:return
        path=Path(code.co_filename)
        if code.co_name in ['estimate_mean','betting_cs','execute_query','evaluate_query','run_query'] and (path.is_relative_to(Path(b['native_upstream_src'])) or 'confseq' in path.parts):
            blocked_calls.append(code.co_name);raise PermissionError('CI_OR_QUERY_CALL_FORBIDDEN_IN_CODE_IMPORT')
        if code.co_name=='__init__' and 'self' in frame.f_locals and type(frame.f_locals['self']).__name__ in ['DataFrame','SessionContext','Query'] and path.is_relative_to(Path(b['native_upstream_src'])):
            blocked_calls.append(type(frame.f_locals['self']).__name__);raise PermissionError('REAL_QUERY_CONSTRUCTION_FORBIDDEN')
    sys.addaudithook(protect);sys.setprofile(no_math)
    sys.path.insert(0,b['native_upstream_src'])
    module=importlib.import_module('evergreen.estimator')
    require(Path(module.__file__).resolve()==Path(b['native_upstream_src'])/'evergreen/estimator.py' and module.ConfSeqEstimator._BREAKS==100,'ORIGINAL_ESTIMATOR_GRID_BINDING')
    for name in ['numpy','scipy']:
        numeric=sys.modules.get(name);expected=Path(b['native_site_packages'])/name/'__init__.py'
        require(numeric is not None and Path(numeric.__file__).resolve()==expected and h(expected)==allowed[str(expected)],'ORIGINAL_PINNED_NUMERIC_IMPORT_CONTEXT_REQUIRED')
    signature=str(inspect.signature(module.ConfSeqEstimator.estimate_mean))
    modules=[]
    for name,m in tuple(sys.modules.items()):
        f=getattr(m,'__file__',None)
        if not f:continue
        p=Path(f).resolve()
        if p.is_relative_to(ROOT):
            require(str(p) in own_code,'PREFLIGHT_ADMIN_MODULE_SET_CHANGED');continue
        if p.is_relative_to(ROOT.parent):
            require(str(p) in allowed and h(p)==allowed[str(p)],'LOADED_UNBOUND_NATIVE_CODE')
            modules.append(dict(module=name,path=str(p),sha256=allowed[str(p)]))
    versions={}
    for name,meta in b['packages'].items():
        m=sys.modules.get(name);require(m is not None and Path(m.__file__).resolve()==Path(meta['entry']['path']) and m.__version__==meta['version'],'ORIGINAL_NATIVE_PACKAGE_VERSION_CHANGED')
        versions[name]=m.__version__
    sys.setprofile(None)
    result=dict(status='PASS_STRICT_CODE_ONLY_NATIVE_IMPORT',native_environment_sha256=b['native_environment_ref']['sha256'],sys_executable=sys.executable,resolved_executable=str(Path(sys.executable).resolve()),sys_prefix=sys.prefix,sys_base_prefix=sys.base_prefix,venv_interpreter_resolves_to_same_binary=True,PYTHONPATH=os.environ['PYTHONPATH'],package_versions=versions,estimator_signature=signature,grid=100,loaded_research_code_modules=modules,approved_uname_calls=aux_calls[0],blocked_CI_query_calls=blocked_calls,actual_CI_query_method_model_profile_or_input_operations=0,new_study_rank_or_entropy_draws=0,CPU_seconds=time.process_time(),CPU_since_main_seconds=time.process_time()-started,waited_auxiliary_CPU_seconds=resource.getrusage(resource.RUSAGE_CHILDREN).ru_utime+resource.getrusage(resource.RUSAGE_CHILDREN).ru_stime)
    put(out/'IMPORT_RESULT.json',result)
    print(json.dumps(dict(status=result['status'],package_versions=versions,actual_CI_query_method_model_profile_or_input_operations=0),sort_keys=True))

if __name__=='__main__':
    try:main()
    except BaseException as exc:
        sys.setprofile(None)
        out=ROOT/'code_import_attempt_01'
        if out.is_dir() and not (out/'IMPORT_FAILURE.json').exists():put(out/'IMPORT_FAILURE.json',dict(status='CODE_IMPORT_FAILED_RETAINED_NO_RETRY',error_type=type(exc).__name__,CPU_seconds=time.process_time(),actual_CI_or_query_authorized=False))
        raise
