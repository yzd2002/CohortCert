"""Separate exact replay against external fixed expected history.

Does not call producer update/Kernel.evaluate/plugin_q or trust cached maxima.
Statistical profile/monotone reduction are inherited antecedents, not new theory.
"""
from fractions import Fraction as Q
from itertools import product
from math import prod,isqrt
import uits


def _q(past):
    if not past:mean,sd=Q(1,2),Q(1,4)
    else:
        mean=sum(past,Q(0))/len(past)
        if len(past)==1:sd=Q(1,4)
        else:
            variance=sum(((z-mean)**2 for z in past),Q(0))/(len(past)-1)
            sd=Q(isqrt((variance.numerator*10**12)//variance.denominator),10**6)
    return min(Q(9,10),max(Q(1,10),mean-sd))


def boundary(spec):
    N=tuple(spec['sizes']);u=tuple(map(Q,spec['upper']));budget=Q(spec['cut'])*sum(N)
    j=max(range(len(N)),key=lambda h:N[h]);hs=tuple(h for h in range(len(N)) if h!=j)
    if prod(N[h]+1 for h in hs)>4096:raise ValueError('verifier boundary resource limit')
    out=set()
    for prefix in product(*(range(N[h]+1) for h in hs)):
        x=[0]*len(N)
        for h,k in zip(hs,prefix):x[h]=k
        rest=budget-sum((u[h]*x[h] for h in hs),Q(0))
        if rest<0:continue
        x[j]=min(N[j],int(rest//u[j]))
        amount=sum((a*k for a,k in zip(u,x)),Q(0))
        if any(x[h]<N[h] and amount+u[h]<=budget for h in range(len(N))):continue
        out.add(tuple(x))
    return out


def first_crossing(spec,counts,expected_history,through):
    N=tuple(spec['sizes']);u=tuple(map(Q,spec['upper']));eta=tuple(a*k/n for a,k,n in zip(u,counts,N));tau=Q(spec['tau']);threshold=1/tau
    streams=spec['streams'];past=[[] for _ in N];S=[Q(0)]*len(N);wealth=Q(1)
    for t,(_,g,vec) in enumerate(expected_history[:through],1):
        h=next((h for h,s in enumerate(streams) if s['group']==g),None)
        if h is None:continue
        st=streams[h];a,c=Q(st['a']),Q(st['c']);x=(a*vec[st['mode']]+max(-a,Q(0)))/c
        r=N[h]-len(past[h])
        if r<=0:raise ValueError('expected history overdraws a physical group')
        m=(N[h]*eta[h]-S[h])/r
        if m<0 or S[h]+x>N[h]*eta[h]:
            return {'kind':'OBSERVED_COUNT_CONTRADICTION','physical_prefix':t,'stratum':h,'sum_after':str(S[h]+x),'null_total':str(N[h]*eta[h])}
        if spec['profile']=='kelly_wor_plugin':
            U=u[h];proposal=(Q(3,2)*U+S[h])/(2+len(past[h]))
            if m<=0 or m>=U or proposal<=m:magnitude=Q(0)
            else:magnitude=min(Q(9,10)/m,(proposal-m)/(m*(U-m)))
        else:
            magnitude=_q(past[h])/eta[h] if eta[h] else Q(0)
            if m>0:magnitude=min(magnitude,Q(9,10)/m)
        factor=1+magnitude*(x-m)
        if factor<0 or magnitude<0 or (m>0 and magnitude*m>1):raise ValueError('invalid replay factor')
        wealth*=factor
        if wealth>=threshold:return {'kind':'HISTORICAL_CROSSING','physical_prefix':t,'wealth':str(wealth)}
        past[h].append(x);S[h]+=x
    return None


def verify_rejection(spec,certificate,expected_history):
    if spec['profile'] not in ('clipped_author_inverse','kelly_wor_plugin') or Q(spec['clip'])!=Q(9,10):raise ValueError('profile changed')
    if certificate is None or certificate['schema']!='sss-incremental-finite-threshold-v1':raise ValueError('missing threshold certificate')
    if spec['profile']=='kelly_wor_plugin' and spec.get('null_test')!='FINITE_MAXIMAL_UPPER_NULL_COVER_IUT':raise ValueError('Kelly cover/domain label missing')
    t=certificate['issued_physical_prefix']
    if type(t) is not int or not 0<=t<=len(expected_history):raise ValueError('missing expected evidence prefix')
    if certificate['spec_sha256']!=uits.digest(spec) or certificate['tau']!=str(Q(spec['tau'])):raise ValueError('changed frozen spec/risk')
    if certificate['expected_history_prefix_sha256']!=uits.digest(tuple(expected_history[:t])):raise ValueError('expected history binding mismatch')
    expected=boundary(spec);rows=certificate['points']
    keys=[tuple(p['counts']) for p in rows]
    if len(keys)!=len(set(keys)) or set(keys)!=expected:raise ValueError('incomplete/duplicate/fabricated maximal-null cover')
    latest=0
    for p in rows:
        counts=tuple(p['counts']);eta=tuple(Q(u)*k/n for u,k,n in zip(spec['upper'],counts,spec['sizes']))
        if tuple(map(Q,p['eta']))!=eta:raise ValueError('candidate mean/count changed')
        got=first_crossing(spec,counts,expected_history,t)
        if got is None or got!=p['witness']:raise ValueError('unverified first crossing/contradiction')
        latest=max(latest,got['physical_prefix'])
    if t!=latest:raise ValueError('false first global rejection prefix')
    return {'threshold_rejection_verified':True,'maximal_null_points':len(rows),'expected_history_prefix':t,'independent_of_incremental_cache':True,'exact_p_value':None}
