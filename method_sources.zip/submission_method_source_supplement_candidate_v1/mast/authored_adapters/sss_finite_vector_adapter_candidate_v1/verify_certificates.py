"""Separate proof traversal; no optimizer or external/source I/O is used."""
from fractions import Fraction as Q
from itertools import product
from math import prod
from uits import digest, fq, ge, qs


def verify_continuous(kernel, cut, alpha, result):
    cut, alpha = fq(cut), fq(alpha)
    assert 0 < alpha < 1
    threshold = 1/alpha
    proof = result["proof"]
    assert proof["schema"] == "sss-wor-continuous-cover-v1"
    assert proof["domain"] in ("CONTINUOUS_UNIT_BOX", "CONTINUOUS_KNOWN_SUPPORT_BOX")
    upper = tuple(Q(1) for _ in kernel.sizes) if proof["domain"] == "CONTINUOUS_UNIT_BOX" else kernel.upper
    assert result["domain"] == proof["domain"]
    assert proof["input_sha256"] == digest({"kernel": kernel.payload(), "cut": cut, "alpha": alpha, "upper": upper})
    assert proof["threshold"] == str(threshold) and proof["cut"] == str(cut) and proof["alpha"] == str(alpha)
    w = tuple(Q(n, sum(kernel.sizes)) for n in kernel.sizes)
    def dot(x):
        return sum((a*b for a, b in zip(w, x)), Q(0))
    checked, opened = 0, 0
    def walk(node, lo, hi):
        nonlocal checked, opened
        checked += 1
        impossible = any(a > b for a, b in zip(lo, hi)) or dot(lo) > cut
        if impossible:
            assert node["kind"] == "INFEASIBLE"
            return
        high = tuple(min(b, (cut-sum((w[j]*lo[j] for j in range(len(w)) if j != h), Q(0)))/w[h])
                     for h, b in enumerate(hi))
        assert all(a <= b for a, b in zip(lo, high))
        kind = node["kind"]
        if kind == "OPEN":
            opened += 1
        elif kind == "REJECT_BOX":
            assert tuple(map(Q, node["at_upper"])) == high
            ev = kernel.box_lower(lo, high, stop_at=threshold)
            assert ge(ev["value"], threshold)
            assert node["witness_prefix"] == ev["witness_prefix"]
            assert node["lower_wealth"] == qs(ev["value"])
            assert node["bound_rule"] == ev["bound_rule"]
        elif kind == "SPLIT":
            h, mid = node["h"], Q(node["mid"])
            assert type(h) is int and 0 <= h < len(lo) and lo[h] < mid < high[h]
            left_hi, right_lo = list(high), list(lo)
            left_hi[h], right_lo[h] = mid, mid
            walk(node["left"], lo, tuple(left_hi))
            walk(node["right"], tuple(right_lo), high)
        else:
            raise AssertionError("Unexpected proof node / false infeasibility")
    empirical = tuple(s/n for s, n in zip(kernel.sums(), kernel.sizes))
    # Eta below this coordinatewise empirical lower bound is certainly false at
    # an observed prefix. Its omission is not a numerical feasibility shortcut.
    walk(proof["root"], empirical, upper)
    status = result["status"]
    if status == "REJECT_CERTIFIED":
        assert opened == 0 and result["complete_global_certificate"] is True
        assert result["nonrejection_witness"] is None
    elif status == "NOT_REJECTED_WITNESS":
        witness = result["nonrejection_witness"]
        eta = tuple(map(Q, witness["eta"]))
        assert len(eta) == len(w) and all(0 <= e <= u for e, u in zip(eta, upper)) and dot(eta) <= cut
        ev = kernel.evaluate(eta)
        assert ev["value"] is not None and ev["value"] < threshold
        assert witness["historical_wealth"] == str(ev["value"])
        assert witness["witness_prefix"] == ev["witness_prefix"]
        assert result["complete_global_certificate"] is False
    elif status == "UNKNOWN":
        assert opened > 0 and result["complete_global_certificate"] is False
        assert result["nonrejection_witness"] is None
    else:
        raise AssertionError("Unrecognized certificate status")
    def proof_lower(node):
        if node['kind'] == 'INFEASIBLE':
            return None
        if node['kind'] == 'OPEN':
            return Q(1)
        if node['kind'] == 'REJECT_BOX':
            return None if node['lower_wealth'] == 'INF' else Q(node['lower_wealth'])
        left, right = proof_lower(node['left']), proof_lower(node['right'])
        return right if left is None else left if right is None else min(left, right)
    lb = proof_lower(proof['root'])
    ub = Q(result['nonrejection_witness']['historical_wealth']) if result['nonrejection_witness'] else None
    assert result['wealth_bounds'] == {'lower': qs(lb), 'upper': qs(ub)}
    assert result['sequential_p_bounds'] == {'lower': str(Q(0) if ub is None else 1/ub), 'upper': str(Q(0) if lb is None else 1/lb)}
    return {"verified": True, "status": status, "proof_nodes": checked, "open_leaves": opened}


def verify_finite(kernel, cut, alpha, result, max_points=100000):
    assert result["domain"] == "FINITE_BINARY_COUNT_NULL"
    assert all(x in (0, kernel.upper[h]) for h, x in kernel.events)
    assert prod(n+1 for n in kernel.sizes) <= max_points
    best, at, count = None, None, 0
    cut, alpha = fq(cut), fq(alpha)
    for counts in product(*(range(n+1) for n in kernel.sizes)):
        eta = tuple(u*k/n for u, k, n in zip(kernel.upper, counts, kernel.sizes))
        if sum((Q(n, sum(kernel.sizes))*e for n, e in zip(kernel.sizes, eta)), Q(0)) > cut:
            continue
        ev = kernel.evaluate(eta)["value"]
        count += 1
        if at is None or (best is None and ev is not None) or (best is not None and ev is not None and ev < best):
            best, at = ev, eta
    expected = "REJECT_EXHAUSTIVE" if at is None or ge(best, 1/alpha) else "NOT_REJECTED_EXHAUSTIVE"
    assert result["complete_global_certificate"] is True and result["status"] == expected
    assert result["exact_infimum"] == qs(best)
    if result['search_reduction'] == 'FULL_ATTAINABLE_NULL_NONMONOTONE':
        assert result["evaluated_null_points"] == count
    else:
        assert result['search_reduction'] == 'EXACT_MONOTONE_MAXIMAL_BOUNDARY' and kernel.family != 'kelly_wor_plugin'
    assert result['exact_sequential_p'] == str(Q(0) if best is None else 1/best)
    if at is None:
        assert result['argmin'] is None
    else:
        candidate = tuple(map(Q, result['argmin']))
        assert all(0 <= e <= u and (e*n/u).denominator == 1 for e, u, n in zip(candidate, kernel.upper, kernel.sizes))
        assert sum((Q(n, sum(kernel.sizes))*e for n, e in zip(kernel.sizes, candidate)), Q(0)) <= cut
        assert kernel.evaluate(candidate)['value'] == best
    return {"verified": True, "status": expected, "full_null_points": count,
            "verified_minimum_against_full_lattice": True}
