from pathlib import Path
import json,unittest,io,traceback,time
from dataclasses import is_dataclass,asdict
from fractions import Fraction
P=Path(__file__).resolve().parent;buf=io.StringIO();success=False;scale=None;tests=0;returns={}
def encode(x):
    if isinstance(x,Fraction):return str(x)
    if is_dataclass(x):return encode(asdict(x))
    if isinstance(x,dict):return {str(k):encode(y) for k,y in x.items()}
    if isinstance(x,(tuple,list)):return [encode(y) for y in x]
    return x
try:
    import test_kelly as test_small
    result=unittest.TextTestRunner(stream=buf,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(test_small));tests=result.testsRun;returns=test_small.RETURNS
    if result.wasSuccessful():
        if time.process_time()<6:scale=test_small.scale100()
        else:scale={'status':'UNKNOWN','reason':'reserved remaining CPU budget; fixed scale not run'}
        success=True
except BaseException:buf.write(traceback.format_exc())
(P/'LATEST_CHECKS.log').write_text(buf.getvalue())
(P/'LATEST_RETURNS.json').write_text(json.dumps(encode(returns),indent=2)+'\n')
(P/'LATEST_RESULT.json').write_text(json.dumps(encode({'scope':'artificial','pass':success,'unit_groups':tests,'scale100':scale,'cpu_process_at_checks_finish':time.process_time(),'no_old_matrix_rerun':True,'real_bridge_ready':False,'new_statistical_principle':False}),indent=2)+'\n')
print(buf.getvalue());print('CHECKS',success,'CPU',time.process_time())
raise SystemExit(0 if success else 1)
