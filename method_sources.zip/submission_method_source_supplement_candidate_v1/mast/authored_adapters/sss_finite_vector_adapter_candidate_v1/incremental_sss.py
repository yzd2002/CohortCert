"""Artificial vector SSS finite UI threshold adapter. No data IO on import."""
from dataclasses import dataclass
from fractions import Fraction as Q
from itertools import product
from math import prod
import uits
import physical_vector as v


def maximal_boundary(sizes,upper,cut,max_prefix_points=4096):
    """Enumerate maximal binary null vectors; inverse equality versus Kelly cover.

    Kelly uses these as upper-intersection-null cover points, not as an exact
    minimizer reduction of its nonmonotone raw full-null statistic.
    """
    last=max(range(len(sizes)),key=lambda h:sizes[h]);others=tuple(h for h in range(len(sizes)) if h!=last)
    bound=prod(sizes[h]+1 for h in others)
    if bound>max_prefix_points:raise uits.ResourceLimit('finite maximal-boundary prefix budget')
    out=[];B=cut*sum(sizes)
    for ks in product(*(range(sizes[h]+1) for h in others)):
        x=[0]*len(sizes)
        for h,k in zip(others,ks):x[h]=k
        left=B-sum((upper[h]*x[h] for h in others),Q(0))
        if left<0:continue
        x[last]=min(sizes[last],int(left//upper[last]))
        gap=B-sum((u*k for u,k in zip(upper,x)),Q(0))
        if any(k<n and u<=gap for u,k,n in zip(upper,x,sizes)):continue
        out.append(tuple(x))
    return tuple(out),bound


@dataclass
class Point:
    counts: tuple
    eta: tuple
    current: Q = Q(1)
    maximum: Q = Q(1)
    witness: dict | None = None


class IncrementalDirection:
    def __init__(self,tr,cut,tau,group_names,mode_by_global_h,*,profile="kelly_wor_plugin",max_prefix_points=4096,max_bits=200000):
        self.tr=tr;self.cut=Q(cut);self.tau=Q(tau);self.threshold=1/self.tau;self.max_bits=max_bits
        if profile not in ("kelly_wor_plugin","clipped_author_inverse"):raise ValueError("fixed supported profile required")
        self.profile=profile;self.profile_kernel=uits.Kernel(tr.sizes,(),tr.upper,profile)
        if not 0<self.tau<1:raise ValueError('classification tau in (0,1)')
        self.group_names=tuple(group_names);self.streams=tuple((self.group_names[h],mode_by_global_h[h]) for h in tr.active)
        counts,self.enumeration_bound=maximal_boundary(tr.sizes,tr.upper,self.cut,max_prefix_points)
        self.points=[Point(x,tuple(u*k/n for u,k,n in zip(tr.upper,x,tr.sizes))) for x in counts]
        self.past=[[] for _ in tr.sizes];self.sums=[Q(0)]*len(tr.sizes);self.failed=None
        self.rejected_at=0 if not self.points else None
        self.payload={'sizes':tr.sizes,'upper':tr.upper,'cut':self.cut,'tau':self.tau,'profile':self.profile,'clip':Q(9,10),'streams':tuple({'group':self.group_names[h],'mode':mode_by_global_h[h],'a':tr.contrast.a[h],'c':tr.c} for h in tr.active)}
        if profile=='kelly_wor_plugin':self.payload['null_test']='FINITE_MAXIMAL_UPPER_NULL_COVER_IUT'
    def update(self,gid,vec,physical_prefix):
        if self.failed or self.rejected_at is not None:return
        local=next((h for h,(g,_) in enumerate(self.streams) if g==gid),None)
        if local is None:return
        h=local;mode=self.streams[h][1];x=self.tr.z(h,vec[mode]);N=self.tr.sizes[h];n=len(self.past[h]);S=self.sums[h]
        if n>=N:raise ValueError('physical stratum exhausted')
        q=uits.plugin_q(self.past[h]) if self.profile=="clipped_author_inverse" else None;r=N-n
        for p in self.points:
            if p.witness is not None:continue
            m=(N*p.eta[h]-S)/r
            if m<0 or S+x>N*p.eta[h]:
                p.witness={'kind':'OBSERVED_COUNT_CONTRADICTION','physical_prefix':physical_prefix,'stratum':h,'sum_after':str(S+x),'null_total':str(N*p.eta[h])}
                continue
            if self.profile=="kelly_wor_plugin":lam=self.profile_kernel._kelly_lambda(m,self.past[h],self.tr.upper[h])
            else:
                lam=q/p.eta[h] if p.eta[h] else Q(0)
                if m:lam=min(lam,Q(9,10)/m)
            factor=1+lam*(x-m)
            if lam<0 or (m>0 and lam*m>1) or factor<0:raise AssertionError('illegal clipped WOR factor')
            p.current*=factor;p.maximum=max(p.maximum,p.current)
            if p.current.numerator.bit_length()+p.current.denominator.bit_length()>self.max_bits:self.failed='EXACT_BIT_BUDGET';break
            if p.maximum>=self.threshold:
                p.witness={'kind':'HISTORICAL_CROSSING','physical_prefix':physical_prefix,'wealth':str(p.current)}
        self.past[h].append(x);self.sums[h]+=x
        if not self.failed and all(p.witness is not None for p in self.points):self.rejected_at=physical_prefix
    def summary(self):
        return {'status':'UNKNOWN' if self.failed else 'REJECT_CERTIFIED_THRESHOLD' if self.rejected_at is not None else 'NOT_REJECTED_WITNESS','boundary_points':len(self.points),'enumeration_prefix_bound':self.enumeration_bound,'alive_points':sum(p.witness is None for p in self.points),'first_rejection_prefix':self.rejected_at,'exact_p_value':None,'reason':self.failed,'profile':self.profile,'null_interpretation':'MAXIMAL_UPPER_NULL_COVER_IUT_NOT_RAW_FULLNULL_INF' if self.profile=='kelly_wor_plugin' else 'EXACT_MONOTONE_BOUNDARY_THRESHOLD'}
    def certificate(self,expected_history):
        if self.rejected_at is None or self.failed:return None
        t=self.rejected_at
        if len(expected_history)<t:raise ValueError('missing expected history')
        return {'schema':'sss-incremental-finite-threshold-v1','spec_sha256':uits.digest(self.payload),'expected_history_prefix_sha256':uits.digest(tuple(expected_history[:t])),'issued_physical_prefix':t,'tau':str(self.tau),'points':tuple({'counts':p.counts,'eta':tuple(map(str,p.eta)),'witness':p.witness} for p in self.points),'interpretation':'complete maximal upper-null threshold cover; not raw full-null exact UI statistic or p-value'}


class AtomState:
    def __init__(self,expr,sizes,group_names,mode_names,tau,profile):
        self.expr=expr;self.sizes=sizes;self.groups=group_names;self.mode_by_h={}
        bygroup={}
        for (g,m),a in expr.terms:bygroup.setdefault(g,[]).append((m,a))
        if any(len(xs)>1 for xs in bygroup.values()):raise ValueError('correlated modes in one physical group')
        coefs=[]
        for h,g in enumerate(group_names):
            ma=bygroup.get(g,[])
            coefs.append(ma[0][1] if ma else Q(0))
            if ma:self.mode_by_h[h]=mode_names.index(ma[0][0])
        self.lower=expr.beta+sum((min(Q(0),a*n) for a,n in zip(coefs,sizes)),Q(0))
        self.upper=expr.beta+sum((max(Q(0),a*n) for a,n in zip(coefs,sizes)),Q(0))
        self.deterministic=True if self.lower>0 else False if self.upper<=0 else None
        self.tau=tau;self.directions={};self.spec=None
        if self.deterministic is None:
            contrast=uits.Contrast('compiled_atom',expr.beta,tuple(coefs));self.spec=uits.LowerAtom('atom',contrast,Q(0)).directions(sizes)
            for side in ('true','false'):
                tr,cut=self.spec[side]
                self.directions[side]=IncrementalDirection(tr,cut,tau,group_names,self.mode_by_h,profile=profile)
    def update(self,gid,vec,prefix):
        for d in self.directions.values():d.update(gid,vec,prefix)
    def value(self):
        if self.deterministic is not None:return self.deterministic
        a=self.directions['true'].rejected_at is not None;b=self.directions['false'].rejected_at is not None
        if any(x.failed for x in self.directions.values()):return None
        return True if a and not b else False if b and not a else None
    def bounds(self):
        value=self.value()
        if self.deterministic is not None:return self.lower,self.upper
        if value is True:return self.spec['upper'],self.upper
        if value is False:return self.lower,self.spec['lower']
        if all(d.rejected_at is not None for d in self.directions.values()):return None
        return self.lower,self.upper
    def report(self):
        return {'value':self.value(),'deterministic':self.deterministic,'classification_tau':str(self.tau if self.deterministic is None else 0),'directions':{s:d.summary() for s,d in self.directions.items()},'conflict':bool(self.directions) and all(d.rejected_at is not None for d in self.directions.values())}


class VectorWorkload:
    def __init__(self,request,profile="kelly_wor_plugin"):
        if profile not in ("kelly_wor_plugin","clipped_author_inverse"):raise ValueError("unsupported frozen profile")
        self.profile=profile;self.request=request;self.compiled=v.compile_request(request);self.groups=tuple(g.gid for g in request.groups);self.sizes=tuple(len(g.records) for g in request.groups);self.history=[];self.outputs=[];self.applicability=None
        for e in self.compiled.expressions:
            by={}
            for (g,m),a in e.terms:by.setdefault(g,set()).add(m)
            if any(len(ms)>1 for ms in by.values()):self.applicability='APPLICABILITY_UNKNOWN: one atom mixes modes in one physical group'
        deterministic=[]
        for e in self.compiled.expressions:
            lo=e.beta+sum((min(Q(0),a*self.sizes[self.groups.index(g)]) for (g,m),a in e.terms),Q(0));hi=e.beta+sum((max(Q(0),a*self.sizes[self.groups.index(g)]) for (g,m),a in e.terms),Q(0))
            deterministic.append(lo>0 or hi<=0)
        self.atom_count=sum(not b for b in deterministic);self.tau=request.alpha/self.atom_count if self.atom_count else Q(0)
        self.atoms=[]
        if not self.applicability:
            try:self.atoms=[AtomState(e,self.sizes,self.groups,request.operator.modes,self.tau if not isdet else Q(0),profile) for e,isdet in zip(self.compiled.expressions,deterministic)]
            except uits.ResourceLimit as exc:self.applicability='RESOURCE_UNKNOWN: '+str(exc)
        self.plan={'operator':{'snapshot':request.operator.snapshot,'version':request.operator.version,'modes':request.operator.modes},'groups':tuple((g.gid,tuple((r.rid,r.content) for r in g.records)) for g in request.groups),'atoms':tuple({'beta':e.beta,'a':e.terms} for e in self.compiled.expressions),'alpha':request.alpha,'classification_tau':self.tau,'atom_count':self.atom_count,'family':{'certificates':self.compiled.family.certificates,'owners':self.compiled.family.certificate_decisions,'types':self.compiled.family.decision_types,'names':self.compiled.names},'profile':profile,'null_domain':'finite_binary_maximal_upper_null_cover_iut' if profile=='kelly_wor_plugin' else 'finite_binary_exact_monotone_boundary'}
        self.plan_sha256=uits.digest(self.plan)
    def ingest(self,rid,gid,vec):
        if self.applicability:raise ValueError('request not applicable')
        if any(rid==x[0] for x in self.history):raise ValueError('duplicate physical record')
        group=next(g for g in self.request.groups if g.gid==gid)
        if rid not in {r.rid for r in group.records} or type(vec) is not tuple or len(vec)!=len(self.request.operator.modes) or any(type(y) is not int or y not in (0,1) for y in vec):raise ValueError('invalid physical vector')
        if sum(x[1]==gid for x in self.history)>=len(group.records):raise ValueError('physical group exhausted')
        self.history.append((rid,gid,vec))
        for a in self.atoms:a.update(gid,vec,len(self.history))
        out=self.checkpoint();self.outputs.append({'physical_prefix':len(self.history),'decisions':out['decisions'],'atoms':tuple(a.report() for a in self.atoms)})
        return out
    def checkpoint(self):
        if self.applicability:return {'complete':False,'status':'APPLICABILITY_UNKNOWN','reason':self.applicability,'decisions':tuple({'name':n,'value':None,'selected':None} for n in self.compiled.names),'classification_atom_count':self.atom_count,'classification_tau':str(self.tau)}
        bounds={i:a.bounds() for i,a in enumerate(self.atoms)};checked=v.evaluate(self.compiled.family,bounds);v.verify(self.compiled.family,bounds,checked);sets=dict(self.compiled.rank_sets);out=[]
        for name,d in zip(self.compiled.names,checked['decisions']):
            x=dict(d);x['name']=name
            if self.compiled.family.decision_types[d['decision']]=='topk':x['selected']=sets.get(d['positive_certificate']) if d['value'] is True else None
            out.append(x)
        return {'complete':checked['complete'],'status':'COMPLETE' if checked['complete'] else 'UNRESOLVED','decisions':tuple(out),'atoms':tuple(a.report() for a in self.atoms),'classification_atom_count':self.atom_count,'classification_tau':str(self.tau),'risk_sum':str(self.tau*self.atom_count),'simultaneous_band_claim':False}
    def certificates(self):
        return tuple({'atom':i,'side':s,'spec':d.payload,'certificate':d.certificate(self.history)} for i,a in enumerate(self.atoms) for s,d in a.directions.items() if d.rejected_at is not None and not d.failed)


@dataclass(frozen=True)
class ObservedState:
    groups: tuple  # gid, originalN, n, all mode-positive counts
    decisions: tuple
    remaining_physical_attempts: int


def round_robin(state):
    available=[g for g in state.groups if g[2]<g[1]]
    return min(available,key=lambda g:(g[2],g[0]))[0] if available else None


def run(request,cache,*,pilot_sizes=None,pilot_ranks=None,formal_ranks=None,batch_size=1,stop_on_complete=True,policy=round_robin,profile="kelly_wor_plugin"):
    workload=VectorWorkload(request,profile)
    if workload.applicability:
        result=workload.checkpoint();result.update(scope='artificial',physical_attempts=0,history=(),certificates=(),real_bridge_ready=False);return result
    if type(batch_size) is not int or batch_size<1:raise ValueError('positive physical batch')
    groups={g.gid:g for g in request.groups};p={g:0 for g in groups};p.update(pilot_sizes or {});pr={g:0 for g in groups};pr.update(pilot_ranks or {});fr={g:0 for g in groups};fr.update(formal_ranks or {})
    if any(set(x)!=set(groups) for x in (p,pr,fr)):raise ValueError('unknown sampling group')
    order={};pilot={}
    for gid,g in groups.items():
        if type(p[gid]) is not int or not 0<=p[gid]<=len(g.records):raise ValueError('invalid pilot size')
        pilot[gid]=v.permutation_from_rank(g.records,pr[gid])[:p[gid]]
        used={r.rid for r in pilot[gid]};rest=[r for r in g.records if r.rid not in used]
        order[gid]=pilot[gid]+v.permutation_from_rank(rest,fr[gid])
    cache.begin(request.operator,tuple(r for g in request.groups for r in g.records),request.budget)
    seen={g:0 for g in groups};positive={g:[0]*len(request.operator.modes) for g in groups};failure=None;reason=None
    def acquire(gid,rows,phase):
        nonlocal failure,reason
        rows=cache.affordable_prefix(rows)
        if not rows:reason='PHYSICAL_BUDGET';return False
        res=cache.fetch_batch(rows,phase)
        for rid,vec in res.vectors:
            if rid!=order[gid][seen[gid]].rid:raise ValueError('not one shared physical prefix')
            seen[gid]+=1
            for m,y in enumerate(vec):positive[gid][m]+=y
            out=workload.ingest(rid,gid,vec)
            if out['complete'] and stop_on_complete and not res.failed:break
        if res.failed:failure='VECTOR_READ_FAILURE';reason=failure;return False
        return True
    try:
        out=workload.checkpoint()
        if not (out['complete'] and stop_on_complete):
            for gid in groups:
                if pilot[gid] and not acquire(gid,pilot[gid],'pilot'):break
                if stop_on_complete and workload.checkpoint()['complete']:break
            while failure is None and reason is None and not (stop_on_complete and workload.checkpoint()['complete']):
                st=ObservedState(tuple((g,len(groups[g].records),seen[g],tuple(positive[g])) for g in groups),tuple((x['name'],x['value']) for x in workload.checkpoint()['decisions']),cache.remaining)
                gid=policy(st)
                if gid is None:reason='ALL_AVAILABLE_PREFIXES_EXHAUSTED';break
                if gid not in groups or seen[gid]>=len(order[gid]):raise ValueError('invalid physical group choice')
                rows=order[gid][seen[gid]:seen[gid]+batch_size]
                if not acquire(gid,rows,'census' if seen[gid]+len(rows)==len(order[gid]) and not stop_on_complete else 'prefetch' if len(rows)>1 else 'formal'):break
    except Exception as exc:failure=type(exc).__name__+': '+str(exc);reason='FRAMEWORK_FAILURE'
    out=workload.checkpoint();cost=cache.finish()
    return {'scope':'artificial','complete':out['complete'] and failure is None,'status':'FAILED' if failure else out['status'],'stop_reason':reason or 'CERTIFIED','decisions':out['decisions'],'checkpoint':out,'physical_attempts':cost['spent'],'cost':cost,'history':tuple(workload.history),'output_history':tuple(workload.outputs),'certificates':workload.certificates(),'plan_sha256':workload.plan_sha256,'sampling_config':{'pilot_sizes':p,'pilot_ranks':pr,'formal_ranks':fr,'batch_size':batch_size,'stop_on_complete':stop_on_complete},'pilot_interpretation':'first observations of original full-N UI process, no discard/no Beta update','failure':failure,'real_bridge_ready':False,'native_author_allocator':False}
