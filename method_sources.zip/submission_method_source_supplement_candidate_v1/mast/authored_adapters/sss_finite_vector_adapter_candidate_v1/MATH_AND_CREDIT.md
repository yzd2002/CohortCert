# Primary Kelly construction, scope and credit

The original DESIGN de6cf1ee... fixed clipped inverse bets. Its first artificial run completed before the primary-literature steering arrived. It is retained as an inverse control with exact code snapshots and ATTEMPT_01. AMENDMENT_01_PRIMARY_KELLY.json was pinned **before any Kelly result** and selects predictable Kelly as the primary comparator for literature reasons, not observed real outcomes. No original design or run record was rewritten.

SSS v5 already discusses binary boundary enumeration (§3.2.1, §5, Appendix D.1). Its footnote3 describes lifting boundary selections/bets to dominated interior points; it does not justify claiming equality for the *unmodified raw Kelly formula evaluated independently at every interior eta*. Section6/Fig4 reports inverse bets relatively weak near the global null, and §7 recommends a common selection sequence with approximately greedy Kelly bets. We credit all these antecedents. Our round robin is a transparent predictable comparison, not the author's optimized selector or the strongest configuration. No statistical novelty or real-workload superiority follows from this adapter.

## Kelly finite upper-null cover, not raw-fullnull exact minimization

For transformed binary support {0,u_h}, let C be all attainable count vectors satisfying `sum u_h*k_h <= cut*sum N_h`. Let B be the maximal members of C under coordinatewise order. Every k in C is dominated by at least one b in B. Test each upper-intersection null `H_b: mu_h <= u_h*b_h/N_h for every h` using its own product I-TSM and historical maximum. Reject the global null only when **every** H_b has crossed `1/tau`.

For any true global-null population k, choose one fixed dominating b. That H_b is true. Global rejection implies this particular true H_b has crossed, whose anytime probability is at most tau by Ville. There is no multiple-testing penalty over boundary points for this IUT, and no monotonicity assumption on raw Kelly wealth is used. This is the classical upper-null cover/union–intersection logic related to the paper's finite-boundary strategy, not a new principle.

The operational statistic is `min_b max_history M_t(eta_b)` for this finite upper-null COVER. It is **not asserted equal** to `min over every raw full-null eta max_history M_t(eta)` when every interior uses its own eta-dependent Kelly formula. The small diagnostic happens to give equal values at its twelve checked prefixes; that finite coincidence establishes no general equivalence. N100 raw Cartesian null (10,201 points) is not evaluated. Clipped inverse remains separately labelled: its proven componentwise monotonicity supports the previous exact maximal-boundary reduction.

## Existing predictable Kelly WOR profile

The primary uses the previously reviewed v1 `kelly_wor_plugin` literally. With u the known stratum upper support, n past observations and S their sum, proposal is `v=(3u/2+S)/(2+n)`, corresponding to two prior observations at .75u. For pre-observation remaining null mean `m=(N*eta-S)/(N-n)`, lambda is zero if `m<=0`, `m>=u`, or `v<=m`; otherwise

`lambda = min((9/10)/m, (v-m)/(m*(u-m)))`.

Observed sum above N*eta deterministically excludes that null first. At m=0,x=0 the factor is1. In a true H_b, the actual conditional remaining mean is <=m, so nonnegative predictable lambda gives expected factor <=1 and clipping preserves nonnegative factors. A common predictable physical selector yields the product I-TSM. Only one mode from any physical group enters an atom: related modes are never product-combined as independent strata.

## Classification, history and certificates

For each non-deterministic atom theta>0, its rational lattice partitions every attainable population into `theta<=l` or `theta>=u`, where l is the last lattice point <=0 and u the next. Exactly one directional null is true for a fixed population. Each atom gets tau=alpha/A, shared by its two classification directions. Union over A atoms covers all Boolean outputs and positive strict-top-k witnesses; it is not a simultaneous two-sided confidence band. Metadata-deterministic atoms cost no risk. Separately compiled redundant predicates can conservatively spend extra risk.

Each boundary point maintains current capital and historical max, then freezes its first crossing or count contradiction. Once all points have witnesses, a threshold-cover certificate is available; subsequent current-capital drops do not erase it. Because later exact maxima are not computed for frozen points, the result deliberately gives **no exact p-value**. Opposite-direction rejection can create conflict later, including at census; None/conflict does not erase earlier wrong outputs from the retained history.

`replay_certificate.py` separately reconstructs the boundary and first crossing/contradiction arithmetic. It does not call the incremental cache, producer update, Kernel.evaluate or plugin_q. The consumer supplies a frozen expected spec and vector history; trusting a returned producer dictionary as independent provenance is insufficient. check_expected_context.py verified all28 saved Kelly certificates against externally literal metadata, directions, tau and expected vector order. This is a finite arithmetic review, not an authenticated production ledger or a new proof engine/theorem.

The full-N process consumes an optional paid public pilot as the first observations of each group's valid full prefix. It does not discard pilot labels, substitute N=95, or impose a Beta prior. Uniform pilot subset/order plus independent uniform residual order can form that prefix, but actual entropy, availability, selector, budget and cross-method bridge still require a separately fixed protocol.
