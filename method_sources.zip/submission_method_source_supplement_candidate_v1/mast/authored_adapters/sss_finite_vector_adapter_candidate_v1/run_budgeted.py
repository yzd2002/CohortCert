#!/usr/bin/env python3
from pathlib import Path
import subprocess,resource,time,json,os,math,shutil,re
P=Path(__file__).resolve().parent;previous=sorted(p for p in P.glob('ATTEMPT_*.json') if re.fullmatch(r'ATTEMPT_\d{2}\.json',p.name));spent=sum(json.loads(p.read_text())['cpu_supervisor_and_children'] for p in previous);remaining=10-spent
if remaining<1:raise SystemExit('less than1s CPU remains; no run authorized')
def limit():
    cpu=max(1,math.floor(remaining-0.3));resource.setrlimit(resource.RLIMIT_CPU,(cpu,cpu))
env=os.environ.copy();env.update({k:'1' for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']});env['PYTHONDONTWRITEBYTECODE']='1'
before=resource.getrusage(resource.RUSAGE_CHILDREN);wall=time.monotonic()
r=subprocess.run(['nice','-n','10',os.sys.executable,str(P/'check_worker.py')],cwd=P,env=env,preexec_fn=limit,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
after=resource.getrusage(resource.RUSAGE_CHILDREN);cpu=after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime+time.process_time();i=len(previous)+1
for n in ['LATEST_CHECKS.log','LATEST_RETURNS.json','LATEST_RESULT.json']:
 if (P/n).exists():shutil.copy2(P/n,P/(f'ATTEMPT_{i:02}_'+n.removeprefix('LATEST_')))
record={'attempt':i,'exit_code':r.returncode,'cpu_supervisor_and_children':cpu,'prior_cpu':spent,'cumulative_cpu':spent+cpu,'wall_seconds':time.monotonic()-wall,'cpu_limit_total':10,'scope':'artificial','all_failures_retained':True}
(P/(f'ATTEMPT_{i:02}.json')).write_text(json.dumps(record,indent=2)+'\n');(P/(f'ATTEMPT_{i:02}.log')).write_text(r.stdout)
print(json.dumps(record,indent=2));print(r.stdout[-5000:]);raise SystemExit(r.returncode if r.returncode>=0 else 1)
