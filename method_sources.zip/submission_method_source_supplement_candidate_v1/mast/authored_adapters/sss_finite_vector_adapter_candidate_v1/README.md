# SSS finite vector comparator candidate — artificial only

Primary is **SSS-v5 finite binary upper-null COVER IUT with predictable Kelly**, per the pre-Kelly AMENDMENT_01_PRIMARY_KELLY.json. The original clipped-inverse DESIGN/run is retained as a control. This is a WOR adaptation of established SSS ideas and a bounded execution prototype, not unmodified author WR code, a new statistical principle, a strongest-allocator claim or an executed real baseline.

`incremental_sss.py` implements pointwise incremental product/history state, first threshold witnesses, complete signed Boolean/DNF and strict positive-top-k output, and one shared physical vector prefix/cost loop. `replay_certificate.py` independently replays each witness against a supplied frozen expected history/spec. Original `uits.py` and `verify_certificates.py` are byte-identical read-bound antecedents; no old20-test suite, old independent6-group matrix, native suite or LP matrix was rerun. Public primary source credit and the nonmonotone Kelly domain distinction are in MATH_AND_CREDIT.md.

The operational artificial loop retains64-row/16-mode limits. One vector returns all M bits for one physical fee. Every atom must use at most one mode per physical group; a violating atom makes the **whole request APPLICABILITY_UNKNOWN**, preserving every declared obligation and spending zero labels. Each actual non-deterministic atom gets alpha/A; its two classification directions share tau. No local42-stream prior/risk scheme or capital product across related modes is imposed. Round robin is transparent and predictable; approximately greedy Kelly allocation remains missing.

## Finite results, separately scoped

Two native-free processes passed six new small control groups each: first inverse control, then primary Kelly. CPU including supervisors and children was respectively0.914638132 and1.225187645 seconds (sum2.139825777). Saved-context verification imported only standard-library/pure code, used no new labels/execution loop and recorded0.120816789 process CPU seconds. Measured statistical/certificate verification is2.260642566 seconds. A subsequent packaging/helper extraction smoke had a1.9023-second wall upper bound, not a repeated statistical suite. Combined with that conservative additional CPU bound, validation remains below10 seconds. All attempts and pre-amendment code are retained; neither statistical run failed. No dependencies/model/API or actual data were used.

| Fixture | N / modes | Atom tau and threshold | Events and interpretation |
|---|---|---|---|
| Primary Kelly full28 | 3 physical groups, N=2 each; M=14 | 28 atoms, tau=1/560, threshold560 | Complete all28 values after6 physical **vectors**, each charged once; strict ties false |
| Inverse control full28 | Same six artificial records/M14 | tau=1/560, threshold560 | Same complete-vector/census control, retained as control only |
| Primary Kelly standalone scale | H=2, N_A=N_B=100; **one mode/one atom** | tau=1/20, threshold20 |16 fixed alternating **scalar/vector** observations from all-A-one/all-B-zero toy; positive upper-null cover first rejects at prefix6, not at tau1/560 |
| Inverse standalone scale | Same N100 one-mode fixed shape | tau=1/20, threshold20 |16 observations; positive monotone-boundary threshold first rejects at prefix7; not a workload comparison |
| Literal/finite-null diagnostic | H2, sizes(3,2), signed nonuniform support | tau=1/20, threshold20 |12 direction/prefix diagnostics and76 Kelly true-null conditional-factor nodes; no generic raw-Kelly fullnull equivalence inferred |
| Early-error/conflict control | H1, N=6 | tau=4/5, threshold5/4 | A retained early wrong declaration becomes conflict/None by census; the earlier error is not erased |

The N100 **Kelly scale** has101 maximal positive-null points and100 negative-null points, not10,201 raw Cartesian points. Its eta=(1/2,1/2) witness at prefix6 has wealth `1334025/65536` (about20.36), exceeding20 and far below560. This explicitly distinguishes it from the M14/28-atom fixture. It tests one favorable artificial statistical shape, not a real N100 data bridge, rate or strategy advantage. Raw Kelly fullnull is not evaluated or reported as exact. The negative-direction cover remains not rejected.

All28 primary certificates were checked again against literal externally expected direction specs/tau and vector order, rather than merely passing producer-returned history back as trusted input. Returned p-values are None: first-crossing caches certify a threshold cover only. For the nonmonotone primary, the domain is labelled `FINITE_MAXIMAL_UPPER_NULL_COVER_IUT`. See the proof/credit distinction in MATH_AND_CREDIT.md.

Other controls retain mixed DNF truth/false outputs, strict open-band boundaries, positive top-k identification with ties unresolved, one true null direction per fixed lattice value, m=0/x=0 factor1, observed-count contradiction, whole-request rejection of multi-mode/group atoms, original-full-N pilot ingestion, fees on failed batches and budget cutoff, and tampered/missing/foreign-history certificates.

## Files and execution boundary

- `ATTEMPT_01*` plus `inverse_control_snapshot/`: original inverse-control code/logs/returns and its initial DESIGN interpretation.
- `ATTEMPT_02*`: primary Kelly controls and the single fixed N100 shape. `LATEST_*` are identical current copies.
- `EXPECTED_CONTEXT_READ_CHECK.json`:28 independently replayed saved certificates with literal expected context.
- `DESIGN.json` stays unchanged; amendment07026b... records the public-literature primary change before Kelly testing.
- `test_kelly.py`, `check_worker.py`, `run_budgeted.py`: current small validation entrypoints. Re-running adds evidence and requires a new manifest, not writes into this frozen delivery.
- `artificial_fixtures.py` is the unchanged pure fixture function extracted after validation; PACKAGING_NOTE records the harmless import-only packaging change and smoke. Old inverse test sources remain archived, not accidentally discovered as current-primary tests.

Expected specs/history, task parameters and in-memory counters still need trusted caller/provenance. Actual N100/M14 data ingestion, common pilot and entropy, complete physical ledger/availability/censor certification, allocator tuning, real benchmark and independent integration review are **not ready**. No SourceS/SourceFull/StageE authorization, gate change or new paper rating follows. No real payload/raw/maps/Source outputs/labels/ledgers were read, and no frozen predecessor/native/manuscript/job settings were modified.
