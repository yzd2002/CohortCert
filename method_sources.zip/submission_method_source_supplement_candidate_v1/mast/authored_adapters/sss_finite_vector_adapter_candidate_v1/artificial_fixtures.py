"""Pure fixed toy fixture builder, extracted unchanged after final checks."""
from fractions import Fraction as Q
import physical_vector as v

def fixture(data,decisions,*,alpha=Q(1,20),topk=(),budget=None):
    M=len(next(iter(data.values()))[0]);op=v.Operator('artificial_sss_vector_v1','fixed_mock_vector_v1',tuple('m'+str(i) for i in range(M)))
    gs=tuple(v.Group(g,tuple(v.Record(g+'_'+str(i),'mock '+g+' '+str(i)) for i in range(len(xs)))) for g,xs in data.items())
    req=v.Request(op,gs,tuple(decisions),alpha,sum(len(g.records) for g in gs) if budget is None else budget,tuple(topk))
    labels={g+'_'+str(i):tuple(row) for g,xs in data.items() for i,row in enumerate(xs)}
    cache=v.ArtificialVectorCache(op,tuple(r for g in gs for r in g.records),lambda rid,text:labels[rid],cache_scope='cold_request')
    return req,cache
