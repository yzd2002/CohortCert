"""Primary Kelly upper-null COVER checks; no raw-fullnull equivalence claim."""
from fractions import Fraction as Q
from itertools import product
from copy import deepcopy
import unittest
import uits
import physical_vector as v
from incremental_sss import IncrementalDirection,VectorWorkload,run
from replay_certificate import verify_rejection
from artificial_fixtures import fixture

RETURNS={}

def direction(a=(Q(1),Q(-3,5)),sizes=(3,2),tau=Q(1,20),side='true'):
    tr,cut=uits.LowerAtom('x',uits.Contrast('x',0,tuple(a)),0).directions(sizes)[side]
    return IncrementalDirection(tr,cut,tau,tuple('g'+str(i) for i in range(len(sizes))),{i:0 for i in range(len(sizes))},profile='kelly_wor_plugin')


class KellyTests(unittest.TestCase):
    def test_primary_full28(self):
        a0=tuple(1 if m%2==0 else 0 for m in range(14));a1=(1,)*14;b=tuple(0 if m%2==0 else 1 for m in range(14));ds=[]
        for m in range(14):
            for other in ('b','c'):ds.append((str(m)+other,v.greater(v.Linear.make({('a','m'+str(m)):Q(1,2),(other,'m'+str(m)):Q(-1,2)}))))
        req,cache=fixture({'a':[a0,a1],'b':[b,b],'c':[a0,b]},ds);out=run(req,cache)
        self.assertTrue(out['complete']);self.assertEqual(out['physical_attempts'],6)
        self.assertEqual([d['value'] for d in out['decisions']],[m%2==0 for m in range(14) for _ in range(2)])
        self.assertEqual(out['checkpoint']['classification_tau'],'1/560');self.assertEqual(out['checkpoint']['classification_atom_count'],28)
        for row in out['certificates']:
            self.assertEqual(row['spec']['profile'],'kelly_wor_plugin');verify_rejection(row['spec'],row['certificate'],out['history'])
        RETURNS['primary_full28']=out

    def test_strict_ties_risk_and_correlated_mode_guard(self):
        e=v.Linear.make({('a','m0'):Q(1,2),('b','m0'):Q(-1,2)})
        ds=(('tie',v.greater(e)),('band_boundary',v.strict_band(e.shifted(Q(1,4)),Q(-1,4),Q(1,4))),('mixed',v.any_of(v.greater(e),v.negate(v.greater(e)))))
        top=v.TopK('top',(('a',v.Linear.make({('a','m0'):Q(1,2)})),('b',v.Linear.make({('b','m0'):Q(1,2)}))),1)
        req,cache=fixture({'a':[(1,1),(0,0)],'b':[(1,0),(0,1)]},ds,topk=(top,));out=run(req,cache,stop_on_complete=False)
        self.assertFalse(out['complete']);self.assertEqual([d['value'] for d in out['decisions'][:3]],[False,False,True]);self.assertIsNone(out['decisions'][-1]['value'])
        w=VectorWorkload(req)
        for a in w.atoms:
            if a.deterministic is not None:continue
            for ks in product(*(range(n+1) for n in w.sizes)):
                theta=a.spec['true'][0].contrast.value(ks)
                self.assertEqual(int(theta<=a.spec['lower'])+int(theta>=a.spec['upper']),1)
        bad=v.Linear.make({('g','m0'):1,('g','m1'):-1})
        req,cache=fixture({'g':[(1,1),(0,0)]},(('unsupported',v.greater(bad)),('other',v.greater(v.Linear.make({('g','m0'):1})))))
        unknown=run(req,cache);self.assertEqual(unknown['status'],'APPLICABILITY_UNKNOWN');self.assertEqual(unknown['physical_attempts'],0);self.assertTrue(all(d['value'] is None for d in unknown['decisions']))
        RETURNS['strict_and_applicability']={'strict':out,'whole_request_unknown':unknown}

    def test_boundary_literal_cover_and_small_fullnull(self):
        events=[('g0',(1,)),('g1',(0,)),('g0',(0,)),('g1',(1,)),('g0',(1,))];rows=[];conditional_nodes=0
        for side in ('true','false'):
            d=direction(side=side);hist=[]
            for t in range(len(events)+1):
                if t:
                    g,vec=events[t-1];hist.append((str(t),g,vec));d.update(g,vec,t)
                phys=tuple((int(g[-1]),vec[0]) for _,g,vec in hist)
                kernel=uits.Kernel(d.tr.sizes,d.tr.observed(phys),d.tr.upper,'kelly_wor_plugin')
                boundary_values=[kernel.evaluate(p.eta)['value'] for p in d.points]
                reject=all(x is None or x>=d.threshold for x in boundary_values)
                self.assertEqual(reject,d.rejected_at is not None)
                full=[];cover=[]
                for ks in product(*(range(n+1) for n in d.tr.sizes)):
                    eta=tuple(u*k/n for u,k,n in zip(d.tr.upper,ks,d.tr.sizes))
                    if sum((Q(n,sum(d.tr.sizes))*e for n,e in zip(d.tr.sizes,eta)),Q(0))>d.cut:continue
                    dominating=[p for p in d.points if all(a<=b for a,b in zip(ks,p.counts))]
                    self.assertTrue(dominating);full.append(kernel.evaluate(eta)['value']);cover.append(ks)
                for p in d.points:
                    ev=kernel.evaluate(p.eta)
                    if p.witness is None:self.assertEqual(p.maximum,ev['value'])
                    else:self.assertTrue(ev['value'] is None or ev['value']>=d.threshold)
                if d.rejected_at is not None:verify_rejection(d.payload,d.certificate(hist),hist)
                def mn(xs):
                    a=[x for x in xs if x is not None];return str(min(a)) if a else 'INF'
                rows.append({'side':side,'prefix':t,'boundary_points':len(d.points),'full_raw_null_points':len(full),'boundary_cover_min_max':mn(boundary_values),'raw_fullnull_min_max_diagnostic':mn(full),'equality_to_raw_fullnull_asserted':False,'cover_rejected':reject})
            # All attainable true null counts are dominated by at least one tested H_b.
            for true_counts in cover:
                p=next(p for p in d.points if all(a<=b for a,b in zip(true_counts,p.counts)))
                for h,(N,U,K) in enumerate(zip(d.tr.sizes,d.tr.upper,true_counts)):
                    for n in range(N):
                        for s in range(n+1):
                            if not s<=K<=s+N-n:continue
                            past=[U]*s+[Q(0)]*(n-s);S=U*s;m=(N*p.eta[h]-S)/(N-n)
                            lam=kernel._kelly_lambda(m,past,U);prob=Q(K-s,N-n)
                            f0=1-lam*m;f1=1+lam*(U-m)
                            self.assertGreaterEqual(f0,0);self.assertGreaterEqual(f1,0)
                            self.assertLessEqual((1-prob)*f0+prob*f1,1);conditional_nodes+=1
        RETURNS['literal_boundary_fullnull_diagnostics']={'rows':rows,'conditional_true_null_nodes_checked':conditional_nodes,'raw_fullnull_equivalence_claim':False}

    def test_frozen_first_crossing_expected_history_and_conflict(self):
        tr,cut=uits.LowerAtom('x',uits.Contrast('x',0,(1,)),3).directions((6,))['true']
        d=IncrementalDirection(tr,cut,Q(4,5),('g',),{0:0});hist=[]
        for t,y in enumerate((1,0,0),1):hist.append((str(t),'g',(y,)));d.update('g',(y,),t)
        self.assertEqual(d.rejected_at,1);self.assertEqual(d.points[0].witness['wealth'],'3/2')
        kernel=uits.Kernel((6,),((0,Q(1)),(0,Q(0)),(0,Q(0))),(Q(1),),'kelly_wor_plugin')
        literal=kernel.evaluate((Q(1,2),),details=True);self.assertLess(literal['history'][-1],Q(3,2));cert=d.certificate(hist);verify_rejection(d.payload,cert,hist)
        bad=deepcopy(cert);bad['points']=()
        with self.assertRaises(ValueError):verify_rejection(d.payload,bad,hist)
        with self.assertRaises(ValueError):verify_rejection(d.payload,cert,[('foreign','g',(0,))]+hist[1:])
        bad=deepcopy(d.payload);bad.pop('null_test')
        with self.assertRaises(ValueError):verify_rejection(bad,cert,hist)
        req,cache=fixture({'g':[(1,),(0,),(0,),(0,),(1,),(1,)]},(('wrong_then_conflict',v.greater(v.Linear.make({('g','m0'):1},-3))),),alpha=Q(4,5));out=run(req,cache,stop_on_complete=False)
        self.assertTrue(out['output_history'][0]['decisions'][0]['value']);self.assertIsNone(out['decisions'][0]['value']);self.assertTrue(out['checkpoint']['atoms'][0]['conflict']);self.assertFalse(out['complete'])
        for row in out['certificates']:verify_rejection(row['spec'],row['certificate'],out['history'])
        RETURNS['retained_early_error_census_conflict']={'run':out,'first_certificate':cert,'later_unfrozen_current':str(literal['history'][-1])}

    def test_fullN_pilot_budget_failure(self):
        e=v.Linear.make({('a','m0'):Q(1,3),('b','m0'):Q(-1,2)});data={'a':[(1,1),(1,0),(0,1)],'b':[(0,1),(0,0)]}
        req,cache=fixture(data,(('x',v.greater(e)),));out=run(req,cache,pilot_sizes={'a':1,'b':1},stop_on_complete=False);w=VectorWorkload(req)
        for rid,g,vec in out['history']:w.ingest(rid,g,vec)
        self.assertEqual([d['value'] for d in out['decisions']],[d['value'] for d in w.checkpoint()['decisions']]);self.assertEqual(out['physical_attempts'],5)
        self.assertTrue(all(row['spec']['sizes'] in ((3,2),[3,2]) for row in out['certificates']));self.assertEqual(sum(e['submitted_physical_attempts'] for e in cache.events if e['phase']=='pilot'),2)
        req,cache=fixture(data,(('x',v.greater(e)),),budget=1);cap=run(req,cache);self.assertEqual(cap['physical_attempts'],1);self.assertFalse(cap['complete'])
        req,cache=fixture(data,(('x',v.greater(e)),));cache._fn=lambda rid,text: (_ for _ in ()).throw(RuntimeError('fixed artificial failure'));failure=run(req,cache,batch_size=2);self.assertEqual(failure['physical_attempts'],2);self.assertFalse(failure['complete'])
        RETURNS['fullN_pilot_cap_failure']={'pilot':out,'cap':cap,'failure':failure}

    def test_zero_remaining_mean_zero_label_and_domain(self):
        d=direction(a=(Q(1),),sizes=(2,));d.update('g0',(0,),1);self.assertEqual(d.points[0].current,1);self.assertIsNone(d.points[0].witness)
        d.update('g0',(1,),2);self.assertEqual(d.points[0].witness['kind'],'OBSERVED_COUNT_CONTRADICTION')
        hist=(('0','g0',(0,)),('1','g0',(1,)));verified=verify_rejection(d.payload,d.certificate(hist),hist)
        self.assertEqual(d.payload['null_test'],'FINITE_MAXIMAL_UPPER_NULL_COVER_IUT');RETURNS['m0_zero_and_contradiction']=verified


def scale100():
    hist=[];ds=[direction((Q(1,100),Q(-1,100)),(100,100),Q(1,20),s) for s in ('true','false')]
    for t in range(16):
        g='g'+str(t%2);vec=(1 if t%2==0 else 0,);hist.append((str(t),g,vec))
        for d in ds:d.update(g,vec,t+1)
    rows=[]
    for d in ds:
        kernel=uits.Kernel(d.tr.sizes,d.tr.observed(tuple((int(g[-1]),vec[0]) for _,g,vec in hist)),d.tr.upper,'kelly_wor_plugin')
        vals=[kernel.evaluate(p.eta)['value'] for p in d.points];literal_reject=all(x is None or x>=d.threshold for x in vals)
        assert literal_reject==(d.rejected_at is not None)
        cert=d.certificate(hist);verified=verify_rejection(d.payload,cert,hist) if cert else None
        rows.append({'summary':d.summary(),'literal_boundary_rejection':literal_reject,'raw_fullnull_statistic_evaluated':False,'total_cartesian_points_not_evaluated':10201,'certificate':cert,'verified':verified})
    assert len(ds[0].points)==101 and len(ds[1].points)==100
    return {'scope':'one fixed N100/H2 single-mode artificial upper-null COVER shape; not operational bridge','observations':16,'directions':rows,'raw_Kelly_fullnull_equivalence_claim':False}
