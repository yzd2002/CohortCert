"""Artificial-only SSS-v5 WOR UI-TS prototype, using exact rational arithmetic.

This module has no source loader, file reader, network access, or population oracle.
Infinity is represented by None. It is only used after a null is certainly false.
The public method is a product I-TSM with min outside its historical maximum.
"""
from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction as Q
from functools import reduce
from hashlib import sha256
from itertools import product
from math import gcd, isqrt, lcm, prod
import json
import time


class ResourceLimit(Exception):
    pass


SUPPORTED_FAMILIES = ('clipped_author_inverse', 'constant_remaining', 'plugin_remaining',
                      'fixed_oblivious', 'kelly_wor_plugin')


def fq(x):
    if isinstance(x, float):
        raise TypeError("Exact inputs must be integers, strings or Fractions")
    return Q(x)


def qs(x):
    return "INF" if x is None else str(x)


def ge(x, y):
    return x is None or (y is not None and x >= y)


def smaller(x, y):
    if x is None:
        return y
    if y is None:
        return x
    return min(x, y)


def canonical(x):
    if isinstance(x, Q):
        return str(x)
    if isinstance(x, tuple):
        return [canonical(v) for v in x]
    if isinstance(x, list):
        return [canonical(v) for v in x]
    if isinstance(x, dict):
        return {k: canonical(v) for k, v in sorted(x.items())}
    return x


def digest(x):
    return sha256(json.dumps(canonical(x), sort_keys=True, separators=(",", ":")).encode()).hexdigest()


@dataclass(frozen=True)
class Contrast:
    name: str
    beta: Q
    a: tuple[Q, ...]

    def __post_init__(self):
        object.__setattr__(self, "beta", fq(self.beta))
        object.__setattr__(self, "a", tuple(map(fq, self.a)))

    def negate(self):
        return Contrast("-" + self.name, -self.beta, tuple(-a for a in self.a))

    def value(self, counts):
        if len(counts) != len(self.a):
            raise ValueError("Contrast/count dimension mismatch")
        return self.beta + sum((a * k for a, k in zip(self.a, counts)), Q(0))

    def grid(self):
        """A known containing grid, not a claim that every grid point is attainable."""
        active = [abs(a) for a in self.a if a]
        if not active:
            return Q(0)
        d = lcm(*(a.denominator for a in active))
        return Q(reduce(gcd, (int(a*d) for a in active)), d)

    def floor_grid(self, x):
        g = self.grid()
        if not g:
            raise ValueError("Deterministic contrast has no nonzero grid")
        return self.beta + ((fq(x)-self.beta)//g)*g

    def transform(self, sizes):
        if len(sizes) != len(self.a) or any(type(n) is not int or n < 0 for n in sizes):
            raise ValueError("Need known nonnegative integer residual stratum sizes")
        active = tuple(h for h, (a, n) in enumerate(zip(self.a, sizes)) if a and n)
        if not active:
            return None
        c = max(abs(self.a[h]) for h in active)
        ns = tuple(sizes[h] for h in active)
        minus = sum((sizes[h]*max(-self.a[h], Q(0)) for h in active), Q(0))
        return Transform(self, active, ns, c, minus)


@dataclass(frozen=True)
class Transform:
    contrast: Contrast
    active: tuple[int, ...]
    sizes: tuple[int, ...]
    c: Q
    minus: Q

    @property
    def upper(self):
        return tuple(abs(self.contrast.a[h])/self.c for h in self.active)

    @property
    def weights(self):
        total = sum(self.sizes)
        return tuple(Q(n, total) for n in self.sizes)

    def z(self, local_h, label):
        if label not in (0, 1):
            raise ValueError("Binary label required")
        a = self.contrast.a[self.active[local_h]]
        return (a*label + max(-a, Q(0)))/self.c

    def mean_cut(self, theta_cut):
        return (fq(theta_cut)-self.contrast.beta+self.minus)/(sum(self.sizes)*self.c)

    def observed(self, physical_events):
        inverse = {h: k for k, h in enumerate(self.active)}
        return tuple((inverse[h], self.z(inverse[h], y)) for h, y in physical_events if h in inverse)


def _sqrt_floor(q, scale=10**6):
    if q < 0:
        raise ValueError("Negative variance")
    return Q(isqrt(q.numerator*scale*scale//q.denominator), scale)


def plugin_q(past):
    """Predictable author lag-mean-minus-SD rule, rational SD rounded down to 1e-6.

    This documented rational approximation is not bit-identical to Welford floats.
    """
    if not past:
        mean, sd = Q(1, 2), Q(1, 4)
    else:
        mean = sum(past, Q(0))/len(past)
        if len(past) == 1:
            sd = Q(1, 4)
        else:
            var = sum(((x-mean)**2 for x in past), Q(0))/(len(past)-1)
            sd = _sqrt_floor(var)
    return max(Q(1, 10), min(Q(9, 10), mean-sd))


@dataclass(frozen=True)
class Kernel:
    sizes: tuple[int, ...]
    events: tuple[tuple[int, Q], ...]
    upper: tuple[Q, ...]
    family: str = "clipped_author_inverse"
    q_constant: Q = Q(3, 4)
    clip: Q = Q(9, 10)

    def __post_init__(self):
        object.__setattr__(self, "sizes", tuple(self.sizes))
        object.__setattr__(self, "upper", tuple(map(fq, self.upper)))
        object.__setattr__(self, "events", tuple((h, fq(x)) for h, x in self.events))
        object.__setattr__(self, "q_constant", fq(self.q_constant))
        object.__setattr__(self, "clip", fq(self.clip))
        if not self.sizes or len(self.sizes) != len(self.upper):
            raise ValueError("Invalid strata")
        if any(type(n) is not int or n <= 0 for n in self.sizes):
            raise ValueError("Positive finite integer sizes required")
        if any(u <= 0 or u > 1 for u in self.upper):
            raise ValueError("Bounds must lie in (0,1]")
        if self.family not in SUPPORTED_FAMILIES:
            raise ValueError("No global bound certificate for this betting family")
        if not 0 < self.q_constant < 1 or not 0 < self.clip < 1:
            raise ValueError("Strict interior fractions required")
        seen = [0]*len(self.sizes)
        for h, x in self.events:
            if type(h) is not int or not 0 <= h < len(seen) or not 0 <= x <= self.upper[h]:
                raise ValueError("Invalid transformed observation")
            seen[h] += 1
            if seen[h] > self.sizes[h]:
                raise ValueError("WOR stratum exhausted")

    @property
    def weights(self):
        return tuple(Q(n, sum(self.sizes)) for n in self.sizes)

    def payload(self):
        return {"sizes": self.sizes, "events": self.events, "upper": self.upper,
                "family": self.family, "q_constant": self.q_constant, "clip": self.clip}

    def sums(self):
        s = [Q(0)]*len(self.sizes)
        for h, x in self.events:
            s[h] += x
        return tuple(s)

    def _kelly_lambda(self, m, past, upper):
        # A fixed two-observation prior at 3*upper/4, then observed data only.
        # No population oracle and no outcome from the draw being bet on.
        proposal = (Q(3, 2)*upper+sum(past, Q(0)))/(2+len(past))
        if m <= 0 or m >= upper or proposal <= m:
            return Q(0)
        return min(self.clip/m, (proposal-m)/(m*(upper-m)))

    def box_lower(self, lo, hi, *, stop_at=None, max_bits=200000):
        """Lower bound for max-history on an entire box, not a feasible point.

        Monotone families attain their box minimum at the upper corner. The
        nonmonotone predictable Kelly family uses rational interval bounds on
        each factor, then products and historical max. This can be very loose.
        """
        if self.family != "kelly_wor_plugin":
            out = self.evaluate(hi, stop_at=stop_at, max_bits=max_bits)
            out["bound_rule"] = "COMPONENTWISE_MONOTONE_UPPER_CORNER"
            return out
        past = [[] for _ in self.sizes]
        sums = [Q(0)]*len(self.sizes)
        wealth, best, witness = Q(1), Q(1), 0
        for j, (h, x) in enumerate(self.events, 1):
            N, s, r = self.sizes[h], sums[h], self.sizes[h]-len(past[h])
            ml, mu = (N*lo[h]-s)/r, (N*hi[h]-s)/r
            assert 0 <= ml <= mu
            if not mu:
                assert x == 0
                factor = Q(1)
            else:
                lam_lo = self._kelly_lambda(mu, past[h], self.upper[h])
                margin_lo = x-mu
                if margin_lo >= 0:
                    factor = 1+lam_lo*margin_lo
                else:
                    universal = 1-self.clip+self.clip*x/mu
                    # Kelly lambda decreases on (0, proposal) and is zero above.
                    if ml > 0:
                        lam_hi = self._kelly_lambda(ml, past[h], self.upper[h])
                        factor = max(universal, 1+lam_hi*margin_lo)
                    else:
                        factor = universal
            assert factor >= 0
            wealth *= factor
            if wealth.numerator.bit_length()+wealth.denominator.bit_length() > max_bits:
                raise ResourceLimit("Exact interval bit budget exhausted")
            if wealth > best:
                best, witness = wealth, j
            past[h].append(x)
            sums[h] += x
            if stop_at is not None and best >= stop_at:
                break
        return {"value": best, "witness_prefix": witness, "bound_rule": "RATIONAL_KELLY_FACTOR_INTERVALS"}

    def evaluate(self, eta, *, stop_at=None, max_bits=200000, details=False):
        """Exact F(eta)=max_{0<=j<=t} product I-TSM, or early crossing witness.

        The null is mu_h <= eta_h. Eta above a past feasible population upper mean
        must NOT be dropped: an inequality null there can still be true.
        """
        eta = tuple(map(fq, eta))
        if len(eta) != len(self.sizes) or any(e < 0 for e in eta):
            raise ValueError("Invalid null parameter")
        past = [[] for _ in self.sizes]
        sums = [Q(0)]*len(self.sizes)
        wealth, best, witness = Q(1), Q(1), 0
        history, bets = [Q(1)], []
        for j, (h, x) in enumerate(self.events, 1):
            n, s, N = len(past[h]), sums[h], self.sizes[h]
            r = N-n
            m = (N*eta[h]-s)/r
            # This null is certainly false on the observed history.
            if m < 0 or s+x > N*eta[h]:
                if details:
                    history.extend([None]*(len(self.events)-j+1))
                return {"value": None, "p_value": Q(0), "witness_prefix": j, "history": history, "bets": bets}
            q = (self.q_constant if self.family in ("constant_remaining", "fixed_oblivious") else plugin_q(past[h]))
            if self.family == "kelly_wor_plugin":
                lam = self._kelly_lambda(m, past[h], self.upper[h])
            elif self.family == "fixed_oblivious":
                # Eta-oblivious and legal for every eta in the full unit box.
                lam = q*r/(N-s)
            elif self.family == "clipped_author_inverse":
                lam = q/eta[h] if eta[h] else Q(0)
                if m:
                    lam = min(lam, self.clip/m)
            else:
                lam = q/m if m else Q(0)
            if lam < 0 or (m > 0 and lam*m > 1):
                raise AssertionError("Illegal WOR bet")
            factor = 1+lam*(x-m)
            if factor < 0:
                raise AssertionError("Negative betting factor")
            wealth *= factor
            if wealth.numerator.bit_length()+wealth.denominator.bit_length() > max_bits:
                raise ResourceLimit("Exact rational bit budget exhausted")
            if wealth > best:
                best, witness = wealth, j
            if details:
                history.append(wealth)
                bets.append((h, m, lam, q))
            past[h].append(x)
            sums[h] += x
            if stop_at is not None and best >= stop_at:
                return {"value": best, "p_value": 1/best, "witness_prefix": witness, "history": history, "bets": bets}
        return {"value": best, "p_value": 1/best, "witness_prefix": witness, "history": history, "bets": bets}


def _dot(w, x):
    return sum((a*b for a, b in zip(w, x)), Q(0))


def _normalize(lo, hi, w, cut):
    """Remove only portions impossible under the weighted-null constraint."""
    if any(a > b for a, b in zip(lo, hi)) or _dot(w, lo) > cut:
        return None
    base = _dot(w, lo)
    hi = tuple(min(b, a+(cut-base)/weight) for a, b, weight in zip(lo, hi, w))
    return tuple(lo), hi


def _point(lo, hi, w, cut):
    space = _dot(w, tuple(b-a for a, b in zip(lo, hi)))
    rho = min(Q(1), (cut-_dot(w, lo))/space) if space else Q(0)
    return tuple(a+rho*(b-a) for a, b in zip(lo, hi))


def continuous_cover(kernel, cut, alpha, *, max_nodes=1000, max_depth=80, seconds=5, max_bits=200000, unit_box=False):
    """Conservative, exact global threshold algorithm. A feasible minimum is never assumed.

    REJECT_CERTIFIED requires a complete covering proof. NOT_REJECTED_WITNESS
    proves only that the UI-TS at this prefix is below threshold. Any incomplete
    search, timeout, exact-bit failure, or unresolved equality becomes UNKNOWN.
    """
    cut, alpha = fq(cut), fq(alpha)
    if not 0 < alpha < 1:
        raise ValueError("alpha must lie in (0,1)")
    if max_nodes < 1 or max_depth < 0 or seconds < 0 or max_bits < 1:
        raise ValueError("Invalid conservative resource budgets")
    upper = tuple(Q(1) for _ in kernel.sizes) if unit_box else kernel.upper
    empirical = tuple(s/n for s, n in zip(kernel.sums(), kernel.sizes))
    threshold = 1/alpha
    started = time.monotonic()
    state = {"nodes": 0, "reason": None, "witness": None}
    binding = {"kernel": kernel.payload(), "cut": cut, "alpha": alpha, "upper": upper}
    proof = {"schema": "sss-wor-continuous-cover-v1", "input_sha256": digest(binding),
             "domain": "CONTINUOUS_UNIT_BOX" if unit_box else "CONTINUOUS_KNOWN_SUPPORT_BOX",
             "threshold": str(threshold), "cut": str(cut), "alpha": str(alpha)}

    def visit(lo, hi, depth):
        normalized = _normalize(lo, hi, kernel.weights, cut)
        if normalized is None:
            return {"kind": "INFEASIBLE"}
        lo, hi = normalized
        if state["witness"] is not None:
            return {"kind": "OPEN", "reason": "nonrejection witness already found"}
        if state["nodes"] >= max_nodes or depth > max_depth or time.monotonic()-started > seconds:
            state["reason"] = state["reason"] or "node/depth/time budget exhausted"
            return {"kind": "OPEN", "reason": state["reason"]}
        state["nodes"] += 1
        try:
            lower_eval = kernel.box_lower(lo, hi, stop_at=threshold, max_bits=max_bits)
            if ge(lower_eval["value"], threshold):
                return {"kind": "REJECT_BOX", "at_upper": list(map(str, hi)),
                        "witness_prefix": lower_eval["witness_prefix"], "lower_wealth": qs(lower_eval["value"]),
                        "bound_rule": lower_eval["bound_rule"]}
            eta = _point(lo, hi, kernel.weights, cut)
            candidate = kernel.evaluate(eta, stop_at=threshold, max_bits=max_bits)
            if candidate["value"] is not None and candidate["value"] < threshold:
                state["witness"] = {"eta": list(map(str, eta)), "historical_wealth": str(candidate["value"]),
                                    "witness_prefix": candidate["witness_prefix"]}
                return {"kind": "OPEN", "reason": "feasible nonrejection witness"}
        except ResourceLimit as exc:
            state["reason"] = str(exc)
            return {"kind": "OPEN", "reason": str(exc)}
        spans = [w*(b-a) for a, b, w in zip(lo, hi, kernel.weights)]
        h = max(range(len(spans)), key=lambda k: spans[k])
        if not spans[h]:
            state["reason"] = "unresolved singleton"
            return {"kind": "OPEN", "reason": state["reason"]}
        mid = (lo[h]+hi[h])/2
        hi_l, lo_r = list(hi), list(lo)
        hi_l[h], lo_r[h] = mid, mid
        return {"kind": "SPLIT", "h": h, "mid": str(mid),
                "left": visit(lo, tuple(hi_l), depth+1),
                "right": visit(tuple(lo_r), hi, depth+1)}

    proof["root"] = visit(empirical, upper, 0)
    def complete(node):
        return node["kind"] in ("REJECT_BOX", "INFEASIBLE") or (node["kind"] == "SPLIT" and complete(node["left"]) and complete(node["right"]))
    status = ("NOT_REJECTED_WITNESS" if state["witness"] is not None else
              "REJECT_CERTIFIED" if complete(proof["root"]) else "UNKNOWN")
    def lower_bound(node):
        if node["kind"] == "INFEASIBLE":
            return None
        if node["kind"] == "OPEN":
            return Q(1)  # M_0=1 is part of the historical maximum.
        if node["kind"] == "REJECT_BOX":
            return None if node["lower_wealth"] == "INF" else Q(node["lower_wealth"])
        return smaller(lower_bound(node["left"]), lower_bound(node["right"]))
    wealth_lo = lower_bound(proof["root"])
    wealth_hi = Q(state["witness"]["historical_wealth"]) if state["witness"] is not None else None
    p_lo, p_hi = (Q(0) if wealth_hi is None else 1/wealth_hi), (Q(0) if wealth_lo is None else 1/wealth_lo)
    return {"status": status, "complete_global_certificate": status == "REJECT_CERTIFIED",
            "domain": proof["domain"], "nodes": state["nodes"], "elapsed_seconds": time.monotonic()-started,
            "reason": state["reason"], "nonrejection_witness": state["witness"], "proof": proof,
            "statistic": "inf_eta max_history product_I_TSM",
            "wealth_bounds": {"lower": qs(wealth_lo), "upper": qs(wealth_hi)},
            "sequential_p_bounds": {"lower": str(p_lo), "upper": str(p_hi)},
            "p_interpretation": "bounds on min(1,1/inf_eta max_history M_j); never a numerical point estimate"}


def finite_count_exhaustive(kernel, cut, alpha, *, max_points=100000, max_bits=200000, seconds=10):
    """Full attainable binary-support null, not a discretization of the continuous box.

    Caller must have established each stratum's support is exactly {0, upper_h}.
    Kernel permits bounded observations for continuous mode; here reject any other
    observed support value so this exact discrete-domain assertion cannot be hidden.
    """
    cut, alpha = fq(cut), fq(alpha)
    if not 0 < alpha < 1 or max_points < 1 or seconds < 0:
        raise ValueError("Invalid risk/resource budget")
    if any(x not in (0, kernel.upper[h]) for h, x in kernel.events):
        raise ValueError("Finite-count mode requires declared binary transformed support")
    start = time.monotonic()
    total_grid = prod(n+1 for n in kernel.sizes)
    monotone = kernel.family != 'kelly_wor_plugin'
    last = max(range(len(kernel.sizes)), key=lambda h: kernel.sizes[h])
    prefix_h = tuple(h for h in range(len(kernel.sizes)) if h != last)
    enumeration_bound = prod(kernel.sizes[h]+1 for h in prefix_h) if monotone else total_grid
    result = {"domain": "FINITE_BINARY_COUNT_NULL", "total_cartesian_points": total_grid,
              "search_reduction": "EXACT_MONOTONE_MAXIMAL_BOUNDARY" if monotone else "FULL_ATTAINABLE_NULL_NONMONOTONE",
              "enumeration_prefix_bound": enumeration_bound,
              "evaluated_null_points": 0, "complete_global_certificate": False,
              "status": "UNKNOWN", "reason": None, "exact_infimum": None, "exact_sequential_p": None, "argmin": None}
    if enumeration_bound > max_points:
        result["reason"] = "Exact lattice/boundary enumeration exceeds prespecified point budget"
        return result
    def candidates():
        if not monotone:
            yield from product(*(range(n+1) for n in kernel.sizes))
            return
        # Each maximal feasible vector must have its last coordinate as large as
        # the null permits. Enumerate every prefix, derive that coordinate, and
        # check maximality in all coordinates. No numerical boundary grid.
        for prefix in product(*(range(kernel.sizes[h]+1) for h in prefix_h)):
            if time.monotonic()-start > seconds:
                raise ResourceLimit("Finite boundary enumeration time budget exhausted")
            counts = [0]*len(kernel.sizes)
            for h, k in zip(prefix_h, prefix):
                counts[h] = k
            available = cut*sum(kernel.sizes)-sum((kernel.upper[h]*counts[h] for h in prefix_h), Q(0))
            if available < 0:
                continue
            counts[last] = min(kernel.sizes[last], int(available//kernel.upper[last]))
            gap = cut*sum(kernel.sizes)-sum((u*k for u, k in zip(kernel.upper, counts)), Q(0))
            if any(k < n and u <= gap for u, k, n in zip(kernel.upper, counts, kernel.sizes)):
                continue
            yield tuple(counts)
    best, argmin, any_null = None, None, False
    try:
        for counts in candidates():
            if time.monotonic()-start > seconds:
                raise ResourceLimit("Finite exhaustive time budget exhausted")
            eta = tuple(u*k/n for u, k, n in zip(kernel.upper, counts, kernel.sizes))
            if _dot(kernel.weights, eta) > cut:
                continue
            any_null = True
            ev = kernel.evaluate(eta, max_bits=max_bits)
            result["evaluated_null_points"] += 1
            if argmin is None or (best is None and ev["value"] is not None) or (best is not None and ev["value"] is not None and ev["value"] < best):
                best, argmin = ev["value"], eta
        result.update(status="REJECT_EXHAUSTIVE" if (not any_null or ge(best, 1/alpha)) else "NOT_REJECTED_EXHAUSTIVE",
                      complete_global_certificate=True, exact_infimum=qs(best),
                      exact_sequential_p=str(Q(0) if best is None else 1/best),
                      argmin=None if argmin is None else list(map(str, argmin)))
    except ResourceLimit as exc:
        result["reason"] = str(exc)
    result["elapsed_seconds"] = time.monotonic()-start
    return result


@dataclass(frozen=True)
class LowerAtom:
    """The strict predicate contrast > cut; upper predicates use negation."""
    name: str
    contrast: Contrast
    cut: Q

    def __post_init__(self):
        object.__setattr__(self, "cut", fq(self.cut))

    def directions(self, sizes):
        # Zero-size cells add no uncertain count and must not consume grid risk.
        effective = Contrast(self.contrast.name, self.contrast.beta,
                             tuple(a if n else Q(0) for a, n in zip(self.contrast.a, sizes)))
        g = effective.grid()
        if not g:
            return {"deterministic": effective.beta > self.cut}
        lower = effective.floor_grid(self.cut)
        upper = lower+g
        positive = effective.transform(sizes)
        negative = effective.negate().transform(sizes)
        return {"deterministic": None, "grid": g, "lower": lower, "upper": upper,
                "true": (positive, positive.mean_cut(lower)),
                "false": (negative, negative.mean_cut(-upper))}


class BooleanWorkload:
    """Full vector of arbitrary finite DNF decisions with exact request risk.

    Both directions of an atom share alpha_atom. Only one of their nulls is true
    for any fixed binary population, so the error bound is alpha_atom, not 2x.
    """
    def __init__(self, sizes, atoms, formulas, alpha=Q(1, 20), family="clipped_author_inverse", null_domain="continuous"):
        self.sizes = tuple(sizes)
        if not self.sizes or any(type(n) is not int or n < 0 for n in self.sizes):
            raise ValueError("Known nonnegative integer physical stratum sizes required")
        self.atoms = tuple(atoms)
        self.formulas = {name: tuple(tuple((literal, True) if isinstance(literal, str) else (literal[0], literal[1])
                                          for literal in clause) for clause in dnf) for name, dnf in formulas.items()}
        self.alpha = fq(alpha)
        self.family = family
        if family not in SUPPORTED_FAMILIES:
            raise ValueError('Betting family must have a fixed global bound implementation')
        if null_domain not in ('continuous', 'finite'):
            raise ValueError('Null domain must be fixed before observations')
        self.null_domain = null_domain
        if len({a.name for a in self.atoms}) != len(self.atoms) or not 0 < self.alpha < 1:
            raise ValueError("Unique atom names / valid request risk required")
        if any(len(a.contrast.a) != len(self.sizes) for a in self.atoms):
            raise ValueError("Atom/stratum dimensions differ")
        self.specs = {a.name: a.directions(self.sizes) for a in self.atoms}
        if any(name not in self.specs or type(sign) is not bool for dnf in self.formulas.values() for clause in dnf for name, sign in clause):
            raise ValueError("Formula references an absent atom")
        uncertain = sum(s["deterministic"] is None for s in self.specs.values())
        self.atom_alpha = self.alpha/uncertain if uncertain else Q(0)
        self.physical_events = []
        self.submissions = []
        self.seen_ids = set()
        self.first_available = {}
        self.rejected_directions = {}
        self.checkpoint_log = []
        self.plan_sha256 = digest(self._design_payload())

    def _design_payload(self):
        compiled = {}
        for name, spec in self.specs.items():
            compiled[name] = {'deterministic': spec['deterministic']}
            if spec['deterministic'] is None:
                compiled[name].update({key: spec[key] for key in ('grid','lower','upper')})
                for side in ('true', 'false'):
                    tr, cut = spec[side]
                    compiled[name][side] = {'active': tr.active, 'sizes': tr.sizes, 'c': tr.c, 'minus': tr.minus,
                                            'beta': tr.contrast.beta, 'a': tr.contrast.a, 'cut': cut}
        return {'sizes': self.sizes, 'atoms': [{'name': a.name, 'beta': a.contrast.beta, 'a': a.contrast.a, 'cut': a.cut} for a in self.atoms],
                'formulas': self.formulas, 'alpha': self.alpha, 'atom_alpha': self.atom_alpha, 'family': self.family,
                'null_domain': self.null_domain, 'compiled': compiled}

    def _require_frozen_design(self):
        if digest(self._design_payload()) != self.plan_sha256:
            raise ValueError('Task/risk/betting/domain plan changed after construction')

    def ingest_batch(self, records):
        """records=(unique_id,h,label_or_None); all are charged before availability.

        Failed records cannot silently be retried as fresh draws. Sampling after a
        failure is a backend/protocol issue: this prototype retains the charge and
        marks the session incomplete rather than making an inference across it.
        """
        self._require_frozen_design()
        records = list(records)
        ids = [r[0] for r in records]
        if len(ids) != len(set(ids)) or self.seen_ids.intersection(ids):
            raise ValueError("Duplicate physical submission")
        counts = [0]*len(self.sizes)
        for _, h, _ in self.submissions:
            counts[h] += 1
        for _, h, y in records:
            if type(h) is not int or not 0 <= h < len(counts) or not (y is None or (type(y) in (int, bool) and y in (0, 1))):
                raise ValueError("Invalid record")
            counts[h] += 1
            if counts[h] > self.sizes[h]:
                raise ValueError("Physical stratum exhausted")
        self.seen_ids.update(ids)
        self.submissions.extend(records)
        self.physical_events.extend((h, y) for _, h, y in records if y is not None)

    def observed_state(self):
        counts, sums = [0]*len(self.sizes), [0]*len(self.sizes)
        for h, y in self.physical_events:
            counts[h] += 1
            sums[h] += y
        return {"sizes": self.sizes, "counts": tuple(counts), "sums": tuple(sums),
                "submitted": len(self.submissions), "observed": len(self.physical_events)}

    def checkpoint(self, mode=None, **budgets):
        self._require_frozen_design()
        mode = self.null_domain if mode is None else mode
        if mode != self.null_domain:
            raise ValueError("Null domain cannot be changed within a frozen workload")
        if any(y is None for _, _, y in self.submissions):
            return {"complete": False, "reason": "failed physical submission; no inference across unknown observation",
                    "charged_calls": len(self.submissions), "atoms": {}, "decisions": {n: None for n in self.formulas}}
        results, values = {}, {}
        for atom in self.atoms:
            spec = self.specs[atom.name]
            if spec["deterministic"] is not None:
                results[atom.name] = {"value": spec["deterministic"], "deterministic": True, "risk": "0"}
                values[atom.name] = spec["deterministic"]
                continue
            dirs = {}
            for side in ("true", "false"):
                tr, cut = spec[side]
                key = (mode, atom.name, side)
                if key in self.rejected_directions:
                    dirs[side] = dict(self.rejected_directions[key])
                    dirs[side]["retained_historical_rejection"] = True
                else:
                    kernel = Kernel(tr.sizes, tr.observed(self.physical_events), tr.upper, self.family)
                    dirs[side] = (continuous_cover(kernel, cut, self.atom_alpha, **budgets) if mode == "continuous" else
                                  finite_count_exhaustive(kernel, cut, self.atom_alpha, **budgets))
                    dirs[side]["evidence_physical_prefix"] = len(self.physical_events)
                    dirs[side]["evidence_charged_calls"] = len(self.submissions)
                    if dirs[side]["status"] in ("REJECT_CERTIFIED", "REJECT_EXHAUSTIVE"):
                        self.rejected_directions[key] = dict(dirs[side])
            rejected = {s: r["status"] in ("REJECT_CERTIFIED", "REJECT_EXHAUSTIVE") for s, r in dirs.items()}
            value = True if rejected["true"] and not rejected["false"] else False if rejected["false"] and not rejected["true"] else None
            values[atom.name] = value
            results[atom.name] = {"value": value, "risk": str(self.atom_alpha), "directions": dirs,
                                  "conflict": rejected["true"] and rejected["false"],
                                  "strict_cut": str(atom.cut), "closed_grid_lower": str(spec["lower"]), "closed_grid_upper": str(spec["upper"])}
        decisions, witnesses = {}, {}
        for name, dnf in self.formulas.items():
            true_clause = next((c for c in dnf if all(values[a] is sign for a, sign in c)), None)
            false_hits = [next(((a, sign) for a, sign in c if values[a] is not None and values[a] is not sign), None) for c in dnf]
            value = True if true_clause is not None else False if all(a is not None for a in false_hits) else None
            decisions[name] = value
            witnesses[name] = {"true_clause": true_clause, "false_atom_per_clause": false_hits if value is False else None}
            if value is not None and name not in self.first_available:
                self.first_available[name] = {"charged_calls": len(self.submissions), "observed_records": len(self.physical_events), "value": value}
        self.checkpoint_log.append({"charged_calls": len(self.submissions), "observed_records": len(self.physical_events), "mode": mode})
        return {"complete": all(v is not None for v in decisions.values()), "charged_calls": len(self.submissions),
                "observed_records": len(self.physical_events), "atoms": results, "decisions": decisions,
                "witnesses": witnesses, "first_available": dict(self.first_available),
                "risk_total": str(self.atom_alpha*sum(s["deterministic"] is None for s in self.specs.values())),
                "request_risk": str(self.alpha), "domain": mode, "plan_sha256": self.plan_sha256, "checkpoint_log": list(self.checkpoint_log),
                "availability_basis": "first evaluated checkpoint; operational caller must evaluate initial and every prescribed batch checkpoint"}


def select_physical(state, rule="round_robin"):
    """Only immutable public sizes and observed prefix summaries are accepted.

    Same choice is used for every target and every null parameter. No future
    labels, population counts or null-specific free physical traces are accepted.
    """
    if state.get("submitted", 0) != state.get("observed", 0):
        raise ValueError("Cannot select across an unobserved failed submission")
    sizes, counts, sums = state["sizes"], state["counts"], state["sums"]
    available = [h for h, n in enumerate(sizes) if counts[h] < n]
    if not available:
        return None
    if rule == "round_robin":
        return min(available, key=lambda h: (counts[h], h))
    if rule == "predictable_variance":
        def score(h):
            mean = Q(sums[h]+1, counts[h]+2)
            return (sizes[h]-counts[h])*(mean*(1-mean)+Q(1, 4))
        return max(available, key=lambda h: (score(h), -h))
    raise ValueError("Unregistered selector")
