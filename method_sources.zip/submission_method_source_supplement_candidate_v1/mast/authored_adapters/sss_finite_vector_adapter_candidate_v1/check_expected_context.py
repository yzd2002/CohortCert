"""Replay saved Kelly full28 certificates against literal external toy context.

Does not trust producer-returned history/spec as the verifier's expected input.
No execution loop, kernel matrix, model, native dependency or actual data call.
"""
from pathlib import Path
from fractions import Fraction as Q
import json,time
import uits
from replay_certificate import verify_rejection
P=Path(__file__).resolve().parent
out=json.loads((P/'ATTEMPT_02_RETURNS.json').read_text())['primary_full28']
a0=tuple(1 if m%2==0 else 0 for m in range(14));a1=(1,)*14;b=tuple(0 if m%2==0 else 1 for m in range(14))
expected=(('a_0','a',a0),('b_0','b',b),('c_0','c',a0),('a_1','a',a1),('b_1','b',b),('c_1','c',b))
assert uits.digest(out['history'])==uits.digest(expected)
checked=[]
for row in out['certificates']:
    i=row['atom'];m=i//2;other='b' if i%2==0 else 'c';side=row['side']
    expected_spec={'sizes':(2,2),'upper':(Q(1),Q(1)),'cut':Q(1,2) if side=='true' else Q(1,4),'tau':Q(1,560),'profile':'kelly_wor_plugin','clip':Q(9,10),'streams':({'group':'a','mode':m,'a':Q(1,2) if side=='true' else Q(-1,2),'c':Q(1,2)},{'group':other,'mode':m,'a':Q(-1,2) if side=='true' else Q(1,2),'c':Q(1,2)}),'null_test':'FINITE_MAXIMAL_UPPER_NULL_COVER_IUT'}
    assert uits.digest(row['spec'])==uits.digest(expected_spec)
    checked.append(verify_rejection(expected_spec,row['certificate'],expected))
assert len(checked)==28
result={'scope':'saved artificial full28 only, externally literal expected history and direction specifications','expected_history_sha256':uits.digest(expected),'certificates_verified':len(checked),'individual_results':checked,'new_execution_loops':0,'actual_data_or_label_calls':0,'old_matrix_reruns':0,'cpu_process_including_imports':time.process_time()}
(P/'EXPECTED_CONTEXT_READ_CHECK.json').write_text(json.dumps(result,indent=2)+'\n');print('External-context certificates',len(checked),'CPU',time.process_time())
