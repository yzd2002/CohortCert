"""Small artificial discriminators; no native imports, real labels or entropy."""
from pathlib import Path
import os
import sys
import resource
import signal
import json
import copy

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'runtime'))
os.nice(max(0, 10 - os.getpriority(os.PRIO_PROCESS, 0)))
sys.dont_write_bytecode = True
resource.setrlimit(resource.RLIMIT_CPU, (8, 8))
resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2,) * 2)
from fractions import Fraction as Q
from core import Group, Record, Operator, ArtificialVectorCache
from reference_schema import MODES, request_from_groups
from sss_routes import VectorWorkload
import uits
import sss_common_loggreedy as greedy

results = []
op = Operator('artificial-loggreedy-small', 'fixed/v1', MODES)
groups = tuple(Group(g, tuple(Record(f'small/{g}/{i}', f'content-{g}-{i}') for i in range(2)))
               for g in ('A', 'B', 'C'))
request = request_from_groups(groups, op, budget=6)
all_rows = tuple(r for g in groups for r in g.records)
vectors = {r.rid: ((1,) * 14 if g.gid == 'A' else (0,) * 14)
           for g in groups for r in g.records}

def engine():
    w = VectorWorkload(request)
    for g in groups:
        r = g.records[0]
        w.ingest(r.rid, g.gid, vectors[r.rid])
    return w

def fingerprint(w):
    return uits.digest((tuple(w.history), tuple((tuple(d.past), tuple(d.sums), d.failed,
        d.rejected_at, tuple((p.counts, p.eta, p.current, p.maximum, p.witness) for p in d.points))
        for a in w.atoms for d in a.directions.values())))

w = engine()
before = fingerprint(w)
choice, diagnostic = greedy.CommonLogEvidenceGreedy(w).choose()
assert choice in ('A', 'B', 'C') and diagnostic['reason'] == 'COMMON_LOG_EVIDENCE_GREEDY'
assert fingerprint(w) == before
assert w.tau == Q(1,560) and len(w.atoms) == 28
results.append({'case':'past_only_choice_and_bank_immutability_risk', 'status':'PASS'})

# Compare a read-only preview with the unchanged inherited updater, including
# physical-bit transforms for both directions and an irrelevant cohort.
checked = 0
for bank in w.atoms[0].directions.values():
    for gid in ('A', 'B', 'C'):
        forecast = greedy._bank_preview_pair(bank, gid)
        for bit in (0, 1):
            independent_copy = copy.deepcopy(bank)
            independent_copy.update(gid, (bit,) * 14, 4)
            observed = greedy._bank_progress(independent_copy)
            assert abs(observed - forecast[bit]) < 1e-12
            checked += 1
assert fingerprint(w) == before
results.append({'case':'two_direction_transforms_and_exact_producer_preview', 'comparisons':checked, 'status':'PASS'})

original_preview = greedy._bank_preview_pair
try:
    greedy._bank_preview_pair = lambda bank, gid: (greedy._bank_progress(bank),) * 2
    first, _ = greedy.CommonLogEvidenceGreedy(w).choose()
    assert first == 'A'
    wa = copy.deepcopy(w)
    wa.ingest(groups[0].records[1].rid, 'A', vectors[groups[0].records[1].rid])
    # This fixture becomes complete after A2. Use a separate valid mixed-bit
    # prefix for the unequal-count tie instead of pretending it is unresolved.
    wt = VectorWorkload(request)
    for g in groups:
        wt.ingest(g.records[0].rid, g.gid, (0,) * 14)
    wt.ingest(groups[0].records[1].rid, 'A', (0,) * 14)
    if not wt.checkpoint()['complete']:
        selected, _ = greedy.CommonLogEvidenceGreedy(wt).choose()
        assert selected in ('B','C')
    results.append({'case':'exact_score_ties_use_count_then_ABC', 'status':'PASS'})
finally:
    greedy._bank_preview_pair = original_preview

original_log = greedy._relative_log
try:
    def bad_numeric(*args):
        raise ArithmeticError('injected heuristic-only numeric failure')
    greedy._relative_log = bad_numeric
    selected, diag = greedy.CommonLogEvidenceGreedy(w).choose()
    assert selected == 'A' and diag['reason'] == 'HEURISTIC_NUMERIC_RR_FALLBACK'
finally:
    greedy._relative_log = original_log
bad = engine()
bad.atoms[0].directions['true'].failed = 'EXACT_BIT_BUDGET'
try:
    greedy.CommonLogEvidenceGreedy(bad).choose()
except greedy.InferenceStateUnknown:
    pass
else:
    raise AssertionError('statistical failure hidden by heuristic fallback')
results.append({'case':'heuristic_fallback_separate_from_statistical_UNKNOWN', 'status':'PASS'})

calls = []
def provider(rid, content):
    calls.append(rid)
    return vectors[rid]

cache = ArtificialVectorCache(op, all_rows, provider)
normal = greedy.run(request, cache)
assert normal['complete'] and normal['physical_attempts'] == 4
assert len(normal['history']) == 4 and len(calls) == 4
assert all(d['value'] is True for d in normal['decisions'])
assert all(x['reason']=='ABC_INITIALIZATION' for x in normal['selector_diagnostics'][:3])
assert normal['checkpoint']['classification_atom_count'] == 28
assert normal['checkpoint']['classification_tau'] == '1/560'
assert len(normal['certificates']) == 28
results.append({'case':'correlated14_fields_whole28_normal_stop_at4', 'status':'PASS'})

calls.clear()
profile_cache = ArtificialVectorCache(op, all_rows, provider)
full = greedy.run(request, profile_cache, stop_on_complete=False)
assert full['complete'] and full['physical_attempts'] == 6 and len(calls) == 6
assert any(x['reason']=='PROFILE_CONTINUATION_AFTER_COMPLETE' for x in full['selector_diagnostics'])
assert len(full['history']) == 6
results.append({'case':'explicit_profile_continuation_keeps_all6_fees', 'status':'PASS'})

paid = []
def failing_provider(rid, content):
    paid.append(rid)
    if len(paid) == 4:
        raise RuntimeError('fixed artificial fourth physical read fails')
    return vectors[rid]
failed = greedy.run(request, ArtificialVectorCache(op, all_rows, failing_provider))
assert not failed['complete'] and failed['failure'] == 'VECTOR_READ_FAILURE'
assert failed['physical_attempts'] == 4 and len(failed['history']) == 3
results.append({'case':'failed_singleton_read_preserves_paid_attempt', 'status':'PASS'})

u = resource.getrusage(resource.RUSAGE_SELF)
out = {'status':'PASS_SMALL_ARTIFICIAL_SELECTOR_CHECKS', 'results':results,
       'CPU_measured_before_final_write':u.ru_utime+u.ru_stime, 'RSS_bytes':u.ru_maxrss*1024,
       'actual_data_or_entropy':False, 'native_or_old_SSS_suites_repeated':False,
       'full300_greedy_profile_completed':False, 'actual_ready':False}
(ROOT/'SMALL_CHECK_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':out['status'], 'groups':len(results), 'CPU':out['CPU_measured_before_final_write']}))
