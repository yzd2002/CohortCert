"""Only previously unexecuted route checks, plus a genuine unequal-count tie."""
from pathlib import Path
import sys, os, resource, json, traceback
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'runtime'))
sys.dont_write_bytecode=True
os.nice(max(0,10-os.getpriority(os.PRIO_PROCESS,0)))
resource.setrlimit(resource.RLIMIT_CPU,(4,4))
resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,)*2)
from core import Group,Record,Operator,ArtificialVectorCache
from reference_schema import MODES,request_from_groups
from sss_routes import VectorWorkload
import sss_common_loggreedy as greedy

results=[]
def save(status,error=None):
    u=resource.getrusage(resource.RUSAGE_SELF)
    out={'status':status,'results':results,'error':error,'CPU_measured_before_write':u.ru_utime+u.ru_stime,
         'RSS_bytes':u.ru_maxrss*1024,'actual_data_Source_entropy':False,'actual_ready':False}
    (ROOT/'PENDING_CHECK_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n')

try:
    op=Operator('artificial-loggreedy-small','fixed/v1',MODES)
    groups=tuple(Group(g,tuple(Record(f'small/{g}/{i}',f'content-{g}-{i}') for i in range(2))) for g in ('A','B','C'))
    request=request_from_groups(groups,op,budget=6)
    rows=tuple(r for g in groups for r in g.records)
    values={r.rid:((1,)*14 if g.gid=='A' else (0,)*14) for g in groups for r in g.records}
    calls=[]
    def provider(rid,content):calls.append(rid);return values[rid]
    normal=greedy.run(request,ArtificialVectorCache(op,rows,provider,cache_scope='cold_request'))
    assert normal['complete'] and normal['physical_attempts']==4 and len(calls)==4
    assert len(normal['history'])==4 and all(d['value'] is True for d in normal['decisions'])
    assert normal['checkpoint']['classification_tau']=='1/560' and len(normal['certificates'])==28
    assert all(x['reason']=='ABC_INITIALIZATION' for x in normal['selector_diagnostics'][:3])
    results.append({'case':'correlated14_whole28_normal4_physical_fees','status':'PASS'});save('PARTIAL')
    calls.clear()
    full=greedy.run(request,ArtificialVectorCache(op,rows,provider,cache_scope='cold_request'),stop_on_complete=False)
    assert full['complete'] and full['physical_attempts']==6 and len(calls)==6 and len(full['history'])==6
    assert any(x['reason']=='PROFILE_CONTINUATION_AFTER_COMPLETE' for x in full['selector_diagnostics'])
    results.append({'case':'explicit_full6_profile_retains_extra_paid_reads','status':'PASS'});save('PARTIAL')
    failed_calls=[]
    def failing(rid,content):
        failed_calls.append(rid)
        if len(failed_calls)==4:raise RuntimeError('fixed fourth physical failure')
        return values[rid]
    failed=greedy.run(request,ArtificialVectorCache(op,rows,failing,cache_scope='cold_request'))
    assert not failed['complete'] and failed['failure']=='VECTOR_READ_FAILURE'
    assert failed['physical_attempts']==4 and len(failed['history'])==3
    results.append({'case':'fourth_read_failure_keeps4paid_3observed','status':'PASS'});save('PARTIAL')
    groups3=tuple(Group(g,tuple(Record(f'tie3/{g}/{i}',f'tiecontent-{g}-{i}') for i in range(3))) for g in ('A','B','C'))
    w=VectorWorkload(request_from_groups(groups3,op,budget=9))
    for g in groups3:w.ingest(g.records[0].rid,g.gid,(0,)*14)
    w.ingest(groups3[0].records[1].rid,'A',(0,)*14)
    assert not w.checkpoint()['complete']
    original=greedy._bank_preview_pair
    try:
        greedy._bank_preview_pair=lambda bank,gid:(greedy._bank_progress(bank),)*2
        choice,diag=greedy.CommonLogEvidenceGreedy(w).choose()
        assert choice=='B' and diag['n']==dict(A=2,B=1,C=1)
        assert set(diag['scores'].values())=={0.0}
    finally:greedy._bank_preview_pair=original
    results.append({'case':'newN3_unequal_count_exact_tie_selectsB','status':'PASS'})
    save('PASS_FOUR_PENDING_AND_NEW_DISCRIMINATORS')
    print(json.dumps({'status':'PASS_FOUR_PENDING_AND_NEW_DISCRIMINATORS','checks':len(results)}))
except BaseException:
    save('FAILED_RETAINED',traceback.format_exc())
    raise
