"""Common predictable lookahead selector; exact SSS inference is inherited.

This module has no data loader or actual-execution authority. A separately
authorized caller supplies a typed request and cold vector cache. The public
artificial front end must reject actual scope before doing any file IO.
"""
from fractions import Fraction as Q
import math
from sss_routes import VectorWorkload

METHOD_ID = 'SSS_Kelly_CommonLogEvidenceGreedy_v1'
LOG_FLOOR = -64.0


class InferenceStateUnknown(RuntimeError):
    pass


def _relative_log(value, threshold):
    if value <= 0 or threshold <= 0:
        raise InferenceStateUnknown('nonpositive exact capital or threshold')
    answer = (math.log(value.numerator) - math.log(value.denominator)
              - math.log(threshold.numerator) + math.log(threshold.denominator))
    if not math.isfinite(answer):
        raise ArithmeticError('nonfinite heuristic log')
    return max(LOG_FLOOR, min(0.0, answer))


def _validate_bank(bank):
    if bank.failed:
        raise InferenceStateUnknown('inherited statistical failure: ' + str(bank.failed))
    if bank.profile != 'kelly_wor_plugin':
        raise InferenceStateUnknown('common selector requires the frozen Kelly profile')


def _bank_progress(bank):
    _validate_bank(bank)
    if bank.rejected_at is not None:
        return 0.0
    logs = []
    for point in bank.points:
        if point.witness is None:
            if point.maximum >= bank.threshold:
                raise InferenceStateUnknown('missing historical witness')
            logs.append(_relative_log(point.current, bank.threshold))
    if not logs:
        raise InferenceStateUnknown('unmarked complete null cover')
    return min(logs)


def _bank_preview_pair(bank, gid):
    """Return progress for physical bit0/1, without updating any bank object."""
    _validate_bank(bank)
    base = _bank_progress(bank)
    if bank.rejected_at is not None:
        return 0.0, 0.0
    local = next((h for h, (g, _) in enumerate(bank.streams) if g == gid), None)
    if local is None:
        return base, base
    h = local
    size = bank.tr.sizes[h]
    n, total = len(bank.past[h]), bank.sums[h]
    if n >= size:
        raise InferenceStateUnknown('preview of exhausted statistical stream')
    remaining = size - n
    upper = bank.tr.upper[h]
    proposal = (Q(3, 2) * upper + total) / (2 + n)
    values = (bank.tr.z(h, 0), bank.tr.z(h, 1))
    logs = [[], []]
    for point in bank.points:
        if point.witness is not None:
            continue
        null_total = size * point.eta[h]
        null_mean = (null_total - total) / remaining
        # This is the unchanged producer's observed-count contradiction rule.
        if null_mean < 0:
            logs[0].append(0.0)
            logs[1].append(0.0)
            continue
        magnitude = (Q(0) if null_mean <= 0 or null_mean >= upper or proposal <= null_mean
                     else min(Q(9, 10) / null_mean,
                              (proposal - null_mean) / (null_mean * (upper - null_mean))))
        for bit, value in enumerate(values):
            if total + value > null_total:
                logs[bit].append(0.0)
                continue
            factor = 1 + magnitude * (value - null_mean)
            if magnitude < 0 or (null_mean > 0 and magnitude * null_mean > 1) or factor <= 0:
                raise InferenceStateUnknown('invalid inherited Kelly preview factor')
            future = point.current * factor
            logs[bit].append(0.0 if max(point.maximum, future) >= bank.threshold
                             else _relative_log(future, bank.threshold))
    if not logs[0] or not logs[1]:
        raise InferenceStateUnknown('missing active preview null points')
    return min(logs[0]), min(logs[1])


class CommonLogEvidenceGreedy:
    """Read only committed workload state; never receives a provider or cache."""
    def __init__(self, workload):
        self.workload = workload
        if tuple(workload.groups) != ('A', 'B', 'C'):
            raise ValueError('fixed A/B/C physical group order required')
        if workload.profile != 'kelly_wor_plugin':
            raise ValueError('frozen Kelly-WOR profile required')

    def choose(self):
        w = self.workload
        if w.applicability:
            raise InferenceStateUnknown(w.applicability)
        n = {g: 0 for g in w.groups}
        successes = {g: [0] * len(w.request.operator.modes) for g in w.groups}
        for _, gid, vector in w.history:
            n[gid] += 1
            for m, bit in enumerate(vector):
                successes[gid][m] += bit
        sizes = dict(zip(w.groups, w.sizes))
        unresolved = []
        relevant = set()
        for atom in w.atoms:
            for bank in atom.directions.values():
                _validate_bank(bank)
            if atom.directions and all(bank.rejected_at is not None for bank in atom.directions.values()):
                raise InferenceStateUnknown('inherited two-direction classification conflict')
            if atom.value() is not None:
                continue
            modes = {mode for (_, mode), _ in atom.expr.terms}
            if len(modes) != 1:
                raise InferenceStateUnknown('fixed comparison atom must use one physical mode')
            mode = w.request.operator.modes.index(next(iter(modes)))
            unresolved.append((atom, mode))
            relevant.update(g for (g, _), _ in atom.expr.terms)
        eligible = [g for g in w.groups if n[g] < sizes[g] and g in relevant]
        if not eligible:
            return None, {'reason': 'NO_ELIGIBLE_UNRESOLVED_PREFIX', 'scores': {}, 'n': n}
        # The fixed initialization checks completion after each actual read.
        for g in w.groups:
            if g in eligible and n[g] == 0:
                return g, {'reason': 'ABC_INITIALIZATION', 'scores': {}, 'n': n}
        try:
            base = {id(atom): max(_bank_progress(bank) for bank in atom.directions.values())
                    for atom, _ in unresolved}
            scores = {}
            for gid in eligible:
                increments = []
                for atom, mode in unresolved:
                    previews = [_bank_preview_pair(bank, gid) for bank in atom.directions.values()]
                    future0 = max(x[0] for x in previews)
                    future1 = max(x[1] for x in previews)
                    probability = (1 + successes[gid][mode]) / (2 + n[gid])
                    increments.append(probability * future1 + (1 - probability) * future0 - base[id(atom)])
                scores[gid] = math.fsum(increments)
            if not all(math.isfinite(x) for x in scores.values()):
                raise ArithmeticError('nonfinite group score')
            selected = min(eligible, key=lambda g: (-scores[g], n[g], w.groups.index(g)))
            return selected, {'reason': 'COMMON_LOG_EVIDENCE_GREEDY', 'scores': scores, 'n': n}
        except (ArithmeticError, OverflowError) as exc:
            selected = min(eligible, key=lambda g: (n[g], w.groups.index(g)))
            return selected, {'reason': 'HEURISTIC_NUMERIC_RR_FALLBACK', 'scores': {}, 'n': n,
                              'error_type': type(exc).__name__}


def run(request, cache, *, stop_on_complete=True, observer=None):
    """Pure supplied-input route; actual file admission belongs to its caller."""
    w = VectorWorkload(request, profile='kelly_wor_plugin')
    if w.applicability:
        out = w.checkpoint()
        return {'scope': request.scope, 'complete': False, 'status': out['status'],
                'decisions': out['decisions'], 'history': (), 'certificates': (),
                'failure': w.applicability, 'real_bridge_ready': False}
    picker = CommonLogEvidenceGreedy(w)
    groups = {g.gid: g for g in request.groups}
    seen = {g: 0 for g in groups}
    diagnostics = []
    failure = None
    reason = None
    cache.begin(request.operator, tuple(r for g in request.groups for r in g.records), request.budget)
    try:
        while not (stop_on_complete and w.checkpoint()['complete']):
            gid, diagnostic = picker.choose()
            if gid is None and not stop_on_complete:
                # Explicit artificial resource profiling can continue after the
                # real method would stop. These extra paid reads are retained.
                remaining = [g for g in groups if seen[g] < len(groups[g].records)]
                if remaining:
                    gid = min(remaining, key=lambda g: (seen[g], tuple(groups).index(g)))
                    diagnostic = {'reason': 'PROFILE_CONTINUATION_AFTER_COMPLETE',
                                  'scores': {}, 'n': dict(seen)}
            diagnostics.append({'physical_prefix': len(w.history), 'selected': gid, **diagnostic})
            if gid is None:
                reason = 'ALL_ELIGIBLE_PREFIXES_EXHAUSTED'
                break
            rows = cache.affordable_prefix((groups[gid].records[seen[gid]],))
            if not rows:
                reason = 'PHYSICAL_BUDGET'
                break
            returned = cache.fetch_batch(rows, 'formal')
            for rid, vector in returned.vectors:
                if rid != groups[gid].records[seen[gid]].rid:
                    raise ValueError('not one common physical rho prefix')
                seen[gid] += 1
                out = w.ingest(rid, gid, vector)
                if observer is not None:
                    observer('sss_common_loggreedy_atomic_vector',
                             {'groups': tuple((g, len(groups[g].records), seen[g]) for g in groups),
                              'atom_summaries': out.get('atoms', ())},
                             (out['complete'], out['decisions']))
            if returned.failed:
                failure = 'VECTOR_READ_FAILURE'
                reason = failure
                break
    except Exception as exc:
        failure = type(exc).__name__ + ': ' + str(exc)
        reason = 'INHERITED_EVIDENCE_UNKNOWN' if isinstance(exc, InferenceStateUnknown) else 'FRAMEWORK_FAILURE'
    out = w.checkpoint()
    cost = cache.finish()
    return {'scope': request.scope, 'method_id': METHOD_ID,
            'complete': out['complete'] and failure is None,
            'status': 'UNKNOWN' if failure else out['status'],
            'stop_reason': reason or 'CERTIFIED', 'decisions': out['decisions'],
            'checkpoint': out, 'physical_attempts': cost['spent'], 'cost': cost,
            'history': tuple(w.history), 'output_history': tuple(w.outputs),
            'certificates': w.certificates(), 'selector_diagnostics': tuple(diagnostics),
            'plan_sha256': w.plan_sha256, 'sampling_config': {'pilot_sizes':dict.fromkeys(groups,0),
                'batch_size':1, 'group_order':'supplied common rho', 'stop_on_complete':stop_on_complete},
            'failure': failure, 'real_bridge_ready': False, 'native_author_allocator':False}
