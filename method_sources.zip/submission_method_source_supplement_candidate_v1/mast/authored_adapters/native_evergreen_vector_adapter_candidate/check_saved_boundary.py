"""Exact wrapper-only boundary check on already returned native integer counts.

No native import, new label call, kernel replay or experiment is performed.
"""
from pathlib import Path
from fractions import Fraction as Q
import json,time,hashlib
import physical_vector as v
P=Path(__file__).resolve().parent
raw=(P/'CONTROL_RETURNS.json').read_bytes();data=json.loads(raw)
tie=next(x['return']['canonical'] for x in data if x['control']=='strict_ties')
counts={}
for t in tie['traces']:
 for gid,k in t['exact_group_counts'].items():counts[(gid,t['mode'])]=k
expr=v.Linear.make({('a','m0'):Q(1,2),('b','m0'):Q(-1,2)},Q(1,4))
op=v.Operator('artificial_vector_snapshot_v1','vector_fixed_v1',('m0','m1'))
groups=tuple(v.Group(g,tuple(v.Record(g+'_'+str(i),'unused public metadata') for i in range(2))) for g in ('a','b'))
req=v.Request(op,groups,(('upper_boundary',v.strict_band(expr,Q(-1,4),Q(1,4))),),Q(1,20),0)
c=v.compile_request(req);bounds={i:(e.exact(counts),e.exact(counts)) for i,e in enumerate(c.expressions)}
out=v.evaluate(c.family,bounds);v.verify(c.family,bounds,out)
assert counts[('a','m0')]==counts[('b','m0')]==1 and expr.exact(counts)==Q(1,4)
assert out['complete'] and out['decisions'][0]['value'] is False
r={'scope':'exact output-wrapper only, using saved native integer counts','saved_control_return_sha256':hashlib.sha256(raw).hexdigest(),'native_counts':{str(k):x for k,x in counts.items()},'score':'1/4','strict_band':'(-1/4,1/4)','value':False,'native_imports_or_kernel_replays':0,'new_physical_attempts':0,'process_cpu_including_stdlib_imports':time.process_time(),'machine_kernel_rounding_certified':False}
(P/'SAVED_BOUNDARY_CHECK.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
