"""Six new vector integration controls; never calls old37 or actual datasets."""
from pathlib import Path
from dataclasses import replace,is_dataclass,asdict
from fractions import Fraction as Q
import time,json,sys,hashlib,inspect,os,socket
P=Path(__file__).resolve().parent
# Nothing in the artificial operator may make a network connection.
def deny_connect(*a,**k):raise RuntimeError('network/API forbidden in artificial scope')
socket.socket.connect=deny_connect
start=time.process_time()
import vector_native_adapter as n
v=n.v
RESULTS=[]

def encode(x):
    if isinstance(x,Q):return str(x)
    if is_dataclass(x):return encode(asdict(x))
    if isinstance(x,dict):return {str(k):encode(y) for k,y in x.items()}
    if isinstance(x,(list,tuple)):return [encode(y) for y in x]
    return x

def save():
    (P/'CONTROL_RETURNS.json').write_text(json.dumps(encode(RESULTS),indent=2)+'\n')

def fixture(data,decisions,*,budget=None,topk=(),shared=False):
    M=len(next(iter(data.values()))[0]);op=v.Operator('artificial_vector_snapshot_v1','vector_fixed_v1',tuple('m'+str(i) for i in range(M)))
    groups=tuple(v.Group(g,tuple(v.Record(g+'_'+str(i),'mock '+g+' '+str(i)) for i in range(len(rows)))) for g,rows in data.items())
    req=v.Request(op,groups,tuple(decisions),Q(1,20),sum(len(g.records) for g in groups) if budget is None else budget,tuple(topk))
    labels={g+'_'+str(i):tuple(y) for g,rows in data.items() for i,y in enumerate(rows)}
    cache=v.ArtificialVectorCache(op,tuple(r for g in groups for r in g.records),lambda rid,text:labels[rid],cache_scope='shared_requests' if shared else 'cold_request')
    return req,cache

def wide_fixture():
    a0=tuple(1 if m%2==0 else 0 for m in range(14));a1=(1,)*14
    b0=tuple(0 if m%2==0 else 1 for m in range(14));c0=a0;c1=b0
    ds=[]
    for m in range(14):
        for other in ('b','c'):
            e=v.Linear.make({('a','m'+str(m)):Q(1,2),(other,'m'+str(m)):Q(-1,2)})
            ds.append((str(m)+'_a_'+other,v.greater(e)))
    return fixture({'a':[a0,a1],'b':[b0,b0],'c':[c0,c1]},ds)


def canonical_wide():
    req,cache=wide_fixture();out=n.NativeExactVector().run(req,cache)
    assert out['error'] is None,out
    assert out['eligible_complete'] and len(out['decisions'])==28
    assert [x['value'] for x in out['decisions']]==[m%2==0 for m in range(14) for _ in range(2)]
    assert out['cost']['spent']==6 and len(out['traces'])==14
    assert sum(len(t['projections']) for t in out['traces'])==84
    assert Q(out['actual_native_risk_sum'])<=req.alpha
    return out


def progressive_wide():
    req,cache=wide_fixture();out=n.ProgressiveNativeVector().run(req,cache)
    assert out['error'] is None,out
    assert out['eligible_complete'] and len(out['decisions'])==28 and out['active_streams']==42
    assert [x['value'] for x in out['decisions']]==[m%2==0 for m in range(14) for _ in range(2)]
    assert out['cost']['spent']==6 and Q(out['actual_native_risk_sum'])<=req.alpha
    for g in ('a','b','c'):
        ts=[t for t in out['traces'] if t['group']==g]
        assert len(ts)==14 and len({tuple(t['native_permutation']) for t in ts})==1
        assert len({t['n'] for t in ts})==1
    assert sum(len(t['cs_calls']) for t in out['traces'])>0
    assert all(len(set(h['mode_prefixes']))==1 for h in out['history'])
    return out


def identities():
    req,cache=wide_fixture();rows=tuple(r for g in req.groups for r in g.records)
    rejected=[]
    for op in [replace(req.operator,snapshot='wrong'),replace(req.operator,version='wrong'),replace(req.operator,modes=tuple(reversed(req.operator.modes)))]:
        try:cache.begin(op,rows,6)
        except ValueError:rejected.append(True)
        else:raise AssertionError('binding not rejected')
    try:cache._key(v.Record(rows[0].rid,'changed content'))
    except ValueError:rejected.append(True)
    else:raise AssertionError('content not rejected')
    assert len(rejected)==4 and cache.totals()['physical_attempts']==0
    return {'rejections':4,'physical_attempts':0}


def prefetch_cap_shared():
    ds=(('x',v.greater(v.Linear.make({('g','m0'):1}))),('y',v.greater(v.Linear.make({('g','m1'):1}))))
    req,cache=fixture({'g':[(1,1)]*4},ds,shared=True)
    a=n.ProgressiveNativeVector().run(req,cache,batch=4)
    assert a['error'] is None and a['eligible_complete'] and a['cost']['spent']==4
    assert {t['n'] for t in a['traces']}=={1}
    assert all(len(t['projections'])==4 for t in a['traces'])
    b=n.ProgressiveNativeVector().run(replace(req,budget=0),cache,batch=4)
    assert b['error'] is None and b['eligible_complete'] and b['cost']['spent']==0
    assert b['cost']['cumulative_including_materialization']['physical_attempts']==4
    assert {t['n'] for t in b['traces']}=={1}
    req,capped=fixture({'g':[(1,1)]*4},ds,budget=2)
    c=n.ProgressiveNativeVector().run(req,capped,batch=4)
    assert c['error'] is not None and not c['eligible_complete'] and c['cost']['spent']==2
    return {'cold_prefetch':a,'declared_shared_second':b,'cap_unknown':c}


def strict_ties():
    e=v.Linear.make({('a','m0'):Q(1,2),('b','m0'):Q(-1,2)})
    ds=(('tie_false',v.greater(e)),('band_true',v.strict_band(e,Q(-1,4),Q(1,4))),('nested',v.any_of(v.greater(e),v.negate(v.greater(e)))))
    top=v.TopK('rank',(('a',v.Linear.make({('a','m0'):Q(1,2)})),('b',v.Linear.make({('b','m0'):Q(1,2)}))),1)
    req,cache=fixture({'a':[(1,0),(0,1)],'b':[(1,0),(0,1)]},ds,topk=(top,))
    a=n.NativeExactVector().run(req,cache);req,cache=fixture({'a':[(1,0),(0,1)],'b':[(1,0),(0,1)]},ds,topk=(top,));b=n.ProgressiveNativeVector().run(req,cache)
    for out in (a,b):
        assert out['error'] is None and not out['eligible_complete']
        assert [x['value'] for x in out['decisions'][:3]]==[False,True,True]
        assert out['decisions'][-1]['value'] is None and out['decisions'][-1]['selected'] is None
    return {'canonical':a,'progressive':b}


def common_prefix_guard():
    a=n.require_common_permutations([('r0','r1'),('r0','r1')]);rejected=False
    try:n.require_common_permutations([('r0','r1'),('r1','r0')])
    except n.CommonPrefixUnsupported:rejected=True
    assert rejected
    # One-ULP native readout, retained separately from native kernel arithmetic.
    assert n.count_domain(float(Q(1,5)),float(Q(1,5)),5,1,1,(0,5))==(1,1)
    return {'unequal_mode_permutations_rejected':rejected,'private_permutation_mutation':False,'one_ulp_count1_boundary':True}

for name,test in [('canonical_M14',canonical_wide),('progressive_M14',progressive_wide),('identity',identities),('prefetch_cap_shared',prefetch_cap_shared),('strict_ties',strict_ties),('prefix_guard',common_prefix_guard)]:
    try:
        out=test();RESULTS.append({'control':name,'status':'PASS','return':out,'process_cpu_after':time.process_time()});save()
        print(name,'PASS',flush=True)
    except Exception as exc:
        import traceback
        RESULTS.append({'control':name,'status':'FAILED','type':type(exc).__name__,'error':str(exc),'traceback':traceback.format_exc(),'process_cpu_after':time.process_time()});save()
        print(name,'FAILED',type(exc).__name__,str(exc)[:800],flush=True)
        raise
modules=['evergreen','evergreen.planner.physical.plan','evergreen.planner.physical.accumulator','evergreen.estimator','confseq.betting','confseq.betting_strategies','numpy._core._multiarray_umath']
identity=[]
for module in modules:
    mod=sys.modules[module];p=Path(mod.__file__);identity.append({'module':module,'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(P/'ACTUAL_NATIVE_IMPORT_BINDING.json').write_text(json.dumps({'python':sys.executable,'native_commit':'41fd08fe74ce54db21701d03b15b3ce79fc13bba','modules':identity,'grid_breaks':n.ConfSeqEstimator._BREAKS,'native_kernel_parameters_replaced':False,'process_cpu_including_imports':time.process_time(),'controls':6,'no_model_API':True},indent=2)+'\n')
print('ALL6 PASS',time.process_time(),flush=True)
