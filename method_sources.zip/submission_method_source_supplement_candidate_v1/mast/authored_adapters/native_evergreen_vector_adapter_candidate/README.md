# Native Evergreen vector adapter candidate — artificial only

This candidate keeps two routes separate. `NativeExactVector` executes unchanged native grouped count aggregates per active mode, then an exact complete-output wrapper. `ProgressiveNativeVector` is an explicit common-physical-prefix adapter: it advances native physical inputs, native accumulator creation/update and the unchanged `ConfSeqEstimator`, with a new round-robin group schedule and exact signed/Boolean/ranking wrapper. It is not canonical whole-query progressive execution and not CohortCert's sampler/PPR/prior. The original files are not modified.

The full-vector mock backend/cache is shared by all mode queries within a request. The first uncached RID returns all M binary bits for one physical fee; later mode projections are cache hits. It binds snapshot, operator version, ordered mode schema, RID and content. Scalar native prompt/projection metrics remain distinct from physical-vector attempts; neither is asserted to be a real model forward/token/dollar. Cold runs use new caches; explicitly shared runs report both incremental and cumulative fees.

## Frozen design and actual results

`DESIGN.json` was frozen before implementation; `INPUT_PINS.json` binds parent Evergreen 4744a688..., its independent review af9a0c7b..., and physical-vector 443f237a.... No actual MAST/Source metadata, labels, raw, traces or ledgers were needed or read. No old 37-test suite or 30-order coverage calculation was rerun.

One new native process completed six controls on the first attempt, including actual dependencies/imports. The supervisor measured **6.139376342 CPU seconds including itself and children**. A subsequent pure exact boundary check on saved native integer counts took a recorded 0.110831064 process CPU seconds; it imported no native modules, replayed no kernel and submitted no labels. Total recorded validation CPU is 6.250207406 seconds, below 10. No packages/models were downloaded or installed. All outputs and logs are preserved; there were no native failed attempts.

| New control | Actual bounded result |
|---|---|
| Native exact M14, 3 groups ×2 records, full28 Boolean | 14 unchanged grouped queries; 84 scalar projections; **6** physical vector fees; all 28 values correct, including false ties |
| Progressive same M14/full28 | 42 unchanged native group-mode streams; each group's 14 actual Shuffle permutations identical; every statistical checkpoint advances all14 together; 42 native CS calls; **6** fees |
| Cache identity | Snapshot, operator, mode-order and content mismatch rejected before spending |
| Prefetch/cap/shared cache | Cold prefetch charges4 although every stream consumes prefix1; declared second request pays0, cumulative remains4; cap2 returns UNKNOWN and retains2 actual submissions |
| Strict outputs | Direct equality false, open-band interior true, nested Boolean complete; top-k boundary tie does not identify a set, for both routes |
| Prefix/readout guard | Unequal mode permutations rejected, no private permutation replacement; one-ULP Count1 readout retained |

`SAVED_BOUNDARY_CHECK.json` additionally checks an exact open-band upper-boundary equality as False using saved native counts (A=B=1, N=2). It does not extend the native numerical/kernel certification.

The actual effective native alpha sums are:

- Native exact grouped-query allocations: `56294995342131/1125899906842624 <= 1/20` (the completed outputs are exact counts, without statistical early stopping).
- Progressive active streams: `225179981368503/4503599627370496 <= 1/20` over42 streams.

`CONTROL_RETURNS.json` retains all permutations, native observation sequences, CS endpoints/default grid, logical projection/cache events, physical costs, failures/UNKNOWN, and complete outputs. `ACTUAL_NATIVE_IMPORT_BINDING.json` identifies actual Evergreen, vendored confseq and compiled NumPy imports. No statistics stubs or native sampler patches are used.

## Canonical versus adapter boundary

Canonical uses the original planner and `StreamAggregate.next()` until native grouped count output. Complete-vector and strict-identification interpretation is an exact wrapper. Queries may be separate per mode; vector-cache reuse means this costs6, not84 or0, in the cold six-record control. Fusion remains enabled within each native plan; cross-mode fused/multi-aggregate plans and the full optimizer are not claimed validated. The old stacked-map KeyError issue is not rerun, repaired or adjudicated here.

Progressive obtains all mode orders through native `Shuffle` and the native seed API, with the same public input-row order and group seed for each mode. It reads and compares actual `_shuffled_rows`; it never assigns that field, changes `_index`, or transplants a private permutation. Only after agreement does the wrapper advance mode accumulators in lockstep. A discrepancy raises `CommonPrefixUnsupported` and cannot earn valid completion. The retained native RNG/Shuffle assumptions remain external statistical conditions; a fixed artificial seed is not a coverage experiment. This adapter does not substitute the factoradic rank sampler from the copied physical prototype.

Risk is assigned before labels to actual active streams for the progressive wrapper, with the native internal allocation retained. Canonical mode-query budgets retain native group division. Only float confidence is moved outward enough to avoid actual alpha overspend; actual accumulator risks are rechecked as exact Fractions. No pilot, Beta prior or PPR region is imposed. The native grid100 outer interval and one-ULP readout are retained; arbitrary machine-level kernel rounding remains UNKNOWN. Invalid/unavailable intervals cannot count as completion or a baseline loss.

Native batching can prefetch labels beyond a statistical prefix; their physical fees remain paid. The mock backend submits vectors sequentially within a native projection batch, so a cap stops before an unaffordable new vector: unsubmitted tail is not billed. Cache hits update native evidence only at their proper common prefix. Extra deterministic tightening from cached labels outside the prefix is not implemented here; that missing optimization cannot be used as a comparative win.

## Limits and review

Scope remains artificial with the inherited64-row/16-mode/64-active-stream guard. Real N100 construction, physical operator bridge, uniform randomization provenance, authenticated/concurrent/recoverable ledger, full benchmark, strongest allocation tuning and performance comparisons remain unready. The native scalar output/kernel integration does not authorize actual MAST, SourceFull, a SourceS gate, StageE, manuscript replacement or a new rating.

Review `NATIVE_BOUNDARY.md`, actual returns, source and manifest. Running `run_budgeted.py` again would exceed the remaining budget for another heavy import in ordinary conditions; do not rerun this author suite to obtain a better result. Independent review should use its own separately authorized finite scope and fresh output directory. Runtime `.venv`, upstream packages and native reference papers are linked/pinned, not copied into the artifact.
