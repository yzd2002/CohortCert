#!/usr/bin/env python3
"""Standard-library supervisor captures child/import/failure CPU; no repeats."""
from pathlib import Path
import subprocess,os,resource,json,time,math
P=Path(__file__).resolve().parent
prior=list(P.glob('RUN_ATTEMPT_*.json'))
spent=sum(json.loads(p.read_text())['cpu_total_including_supervisor_and_children'] for p in prior)
remaining=10-spent
if remaining<1:raise SystemExit('CPU budget exhausted; no rerun authorized')
venv=P.parent/'evergreen_contract_adapter_candidate/.venv/bin/python'
env=os.environ.copy();env.update({k:'1' for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','VECLIB_MAXIMUM_THREADS']});env['PYTHONDONTWRITEBYTECODE']='1';env['TMPDIR']=str(P/'tmp');(P/'tmp').mkdir(exist_ok=True)
def limit():
    # Reserve supervisor/serialization overhead; OS limit covers child imports.
    cpu=max(1,math.floor(remaining-0.3));resource.setrlimit(resource.RLIMIT_CPU,(cpu,cpu))
t0=resource.getrusage(resource.RUSAGE_CHILDREN);wall=time.monotonic()
r=subprocess.run(['nice','-n','10',str(venv),str(P/'check_controls.py')],cwd=P,env=env,preexec_fn=limit,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
t1=resource.getrusage(resource.RUSAGE_CHILDREN);cpu=(t1.ru_utime+t1.ru_stime)-(t0.ru_utime+t0.ru_stime)+time.process_time()
i=len(prior)+1;(P/(f'RUN_ATTEMPT_{i:02}.log')).write_text(r.stdout)
out={'attempt':i,'exit_code':r.returncode,'cpu_total_including_supervisor_and_children':cpu,'prior_cpu':spent,'cumulative_cpu':spent+cpu,'wall_seconds':time.monotonic()-wall,'budget_seconds':10,'old_tests_rerun':False,'new_controls_target':6,'scope':'artificial; actual outcomes/labels never read','no_installs':True}
(P/(f'RUN_ATTEMPT_{i:02}.json')).write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2));print(r.stdout[-5000:]);raise SystemExit(r.returncode if r.returncode>=0 else 1)
