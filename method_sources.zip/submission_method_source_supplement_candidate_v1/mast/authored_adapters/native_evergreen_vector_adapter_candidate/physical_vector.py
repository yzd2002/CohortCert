"""Artificial-only physical vector WOR execution. Standard library; no import IO.

Counts/risk/intervals use exact arithmetic. Component e-values are never multiplied.
The unchanged v3 pure dual checker is the only borrowed runtime module.
"""
from __future__ import annotations
from dataclasses import dataclass
from fractions import Fraction as Q
from hashlib import sha256
from itertools import combinations, product
from math import lcm, prod, factorial
from typing import Callable
from vendor_dual_certificate import evaluate, verify


def rat(x):
    if isinstance(x, Q): return x
    if type(x) not in (int, str): raise TypeError('exact int/string/Fraction required')
    return Q(x)


def integer(x, minimum=0):
    if type(x) is not int or x < minimum: raise ValueError('invalid integer')
    return x


@dataclass(frozen=True)
class Record:
    rid: str
    content: str
    def __post_init__(self):
        if not self.rid or not isinstance(self.rid, str) or not isinstance(self.content, str):
            raise ValueError('public RID and content strings required')


@dataclass(frozen=True)
class Group:
    gid: str
    records: tuple[Record, ...]
    def __post_init__(self):
        object.__setattr__(self,'records',tuple(self.records))
        if not isinstance(self.gid,str) or any(type(r) is not Record for r in self.records):raise ValueError('immutable public group required')


@dataclass(frozen=True)
class Operator:
    snapshot: str
    version: str
    modes: tuple[str, ...]
    def __post_init__(self):
        object.__setattr__(self,'modes',tuple(self.modes))
        if any(not isinstance(m,str) or not m for m in self.modes):raise ValueError('named modes required')
        if not self.snapshot or not self.version or not self.modes or len(set(self.modes)) != len(self.modes):
            raise ValueError('fixed snapshot/operator/unique ordered mode schema required')
        if len(self.modes) > 16: raise ValueError('artificial mode limit')


@dataclass(frozen=True)
class Linear:
    terms: tuple[tuple[tuple[str, str], Q], ...] = ()
    beta: Q = Q(0)
    def __post_init__(self):
        merged = {}
        for key, val in self.terms:
            if type(key) is not tuple or len(key) != 2: raise ValueError('stream=(group,mode) required')
            merged[key] = merged.get(key, Q(0)) + rat(val)
        object.__setattr__(self, 'terms', tuple(sorted((k,v) for k,v in merged.items() if v)))
        object.__setattr__(self, 'beta', rat(self.beta))
    @classmethod
    def make(cls, terms=None, beta=0): return cls(tuple((terms or {}).items()), rat(beta))
    def minus(self, other): return Linear(self.terms + tuple((k,-v) for k,v in other.terms), self.beta-other.beta)
    def shifted(self, x): return Linear(self.terms, self.beta+rat(x))
    def negated(self): return Linear(tuple((k,-v) for k,v in self.terms),-self.beta)
    def complement(self):
        # D*score is integer; NOT(score>0) iff (1/D-score)>0, including ties.
        D = lcm(self.beta.denominator, *(a.denominator for _,a in self.terms))
        return self.negated().shifted(Q(1,D))
    def exact(self, counts): return self.beta+sum((a*counts[k] for k,a in self.terms),Q(0))


@dataclass(frozen=True)
class Claim:
    op: str
    expr: Linear | None = None
    children: tuple[Claim, ...] = ()
    value: bool | None = None
    def __post_init__(self):object.__setattr__(self,'children',tuple(self.children))


def greater(expr, threshold=0): return Claim('gt',expr.shifted(-rat(threshold)))
def all_of(*x): return Claim('all',children=tuple(x))
def any_of(*x): return Claim('any',children=tuple(x))
def negate(x): return Claim('not',children=(x,))
def strict_band(expr, low, high):
    if rat(low)>=rat(high): raise ValueError('invalid strict band')
    return all_of(greater(expr,low),greater(expr.negated(),-rat(high)))


@dataclass(frozen=True)
class TopK:
    name: str
    scores: tuple[tuple[str, Linear], ...]
    k: int
    def __post_init__(self):object.__setattr__(self,'scores',tuple(tuple(x) for x in self.scores))


@dataclass(frozen=True)
class Request:
    operator: Operator
    groups: tuple[Group, ...]
    decisions: tuple[tuple[str, Claim], ...]
    alpha: Q
    budget: int
    topk: tuple[TopK, ...] = ()
    scope: str = 'artificial'
    def __post_init__(self):
        object.__setattr__(self,'groups',tuple(self.groups))
        object.__setattr__(self,'decisions',tuple(tuple(x) for x in self.decisions))
        object.__setattr__(self,'topk',tuple(self.topk))
        if self.scope!='artificial': raise ValueError('only artificial scope authorized')
        object.__setattr__(self,'alpha',rat(self.alpha));integer(self.budget)
        if not 0<self.alpha<1: raise ValueError('request risk outside (0,1)')
        if not self.groups or len({g.gid for g in self.groups})!=len(self.groups): raise ValueError('unique public groups required')
        rows=[r for g in self.groups for r in g.records]
        if not rows or len(rows)>64 or len({r.rid for r in rows})!=len(rows): raise ValueError('disjoint physical RIDs, <=64 artificial rows required')
        if any(not g.gid or not g.records for g in self.groups): raise ValueError('nonempty public groups')
        names=[n for n,_ in self.decisions]+[t.name for t in self.topk]
        if not names or len(set(names))!=len(names): raise ValueError('unique complete decision names required')


@dataclass(frozen=True)
class Config:
    pilot_sizes: tuple[tuple[str, int], ...]
    pilot_seeds: tuple[tuple[str, int], ...]
    formal_seeds: tuple[tuple[str, int], ...]
    risks: tuple[tuple[tuple[str, str], Q], ...]
    prior_mode: str  # fixed_beta or pilot_smoothed
    fixed_beta: tuple[tuple[tuple[str, str], tuple[int,int]], ...]
    strength: int
    mixture: Q
    batch_size: int
    cache_scope: str
    stop_on_complete: bool = True
    def __post_init__(self):
        for name in ('pilot_sizes','pilot_seeds','formal_seeds','risks','fixed_beta'):
            object.__setattr__(self,name,tuple(tuple(x) for x in getattr(self,name)))


@dataclass(frozen=True)
class _Atom:
    index: int
    kind: str = 'lower'
    threshold: Q = Q(0)


@dataclass(frozen=True)
class Family:
    atoms: tuple[_Atom, ...]
    certificates: tuple[tuple[int, ...], ...]
    certificate_decisions: tuple[int, ...]
    decision_types: tuple[str, ...]
    def decision_indices(self): return tuple(range(len(self.decision_types)))


@dataclass(frozen=True)
class Compiled:
    expressions: tuple[Linear, ...]
    family: Family
    names: tuple[str, ...]
    rank_sets: tuple[tuple[int, tuple[str, ...]], ...]
    active: tuple[tuple[str,str], ...]


def compile_request(req):
    expressions=[];ids={};certs=[];owners=[];types=[];names=[];rank_sets=[]
    allowed={(g.gid,m) for g in req.groups for m in req.operator.modes}
    def atom(expr):
        if any(k not in allowed for k,_ in expr.terms): raise ValueError('unknown public stream')
        if expr not in ids:
            ids[expr]=len(expressions);expressions.append(expr)
        return ids[expr]
    def dnf(c, neg=False):
        if c.op=='gt': return [(atom(c.expr.complement() if neg else c.expr),)]
        if c.op=='const':
            if type(c.value) is not bool: raise ValueError('literal Boolean required')
            return [()] if c.value != neg else []
        if c.op=='not':
            if len(c.children)!=1: raise ValueError('not arity')
            return dnf(c.children[0],not neg)
        if c.op not in ('all','any'): raise ValueError('unknown Boolean operator')
        kind=('any' if c.op=='all' else 'all') if neg else c.op
        rows=[dnf(x,neg) for x in c.children]
        if kind=='any': out=[v for r in rows for v in r]
        else:
            size=prod(len(r) for r in rows)
            if size>4096: raise ValueError('artificial DNF resource bound')
            out=[tuple(dict.fromkeys(v for t in ts for v in t)) for ts in product(*rows)]
        if len(out)>4096: raise ValueError('artificial DNF resource bound')
        return out
    def add(name,claim,kind):
        di=len(names);names.append(name);types.append(kind)
        for c in dnf(claim): certs.append(c);owners.append(di)
    for name,claim in req.decisions: add(name,claim,'boolean')
    for t in req.topk:
        ns=[n for n,_ in t.scores]
        if not ns or len(set(ns))!=len(ns) or type(t.k) is not int or not 1<=t.k<=len(ns): raise ValueError('invalid strict top-k')
        di=len(names);names.append(t.name);types.append('topk')
        for selected in combinations(ns,t.k):
            sc=dict(t.scores);w=all_of(*(greater(sc[a].minus(sc[b])) for a in selected for b in ns if b not in selected))
            for c in dnf(w):
                rank_sets.append((len(certs),tuple(sorted(selected))));certs.append(c);owners.append(di)
    active=tuple(sorted({k for e in expressions for k,a in e.terms if a}))
    if len(active)>64: raise ValueError('artificial stream resource bound')
    return Compiled(tuple(expressions),Family(tuple(_Atom(i) for i in range(len(expressions))),tuple(certs),tuple(owners),tuple(types)),tuple(names),tuple(rank_sets),active)


def _rising(a,n): return prod(range(a,a+n))
def _falling(a,n): return prod(range(a-n+1,a+1)) if a>=n else 0

def ordered_q(n,s,a,b,mixture):
    base=Q(_rising(1,s)*_rising(1,n-s),_rising(2,n))
    proxy=Q(_rising(a,s)*_rising(b,n-s),_rising(a+b,n))
    return (1-mixture)*base+mixture*proxy


class ExactPPR:
    """Exact finite-count inversion; intersects at every individual vector."""
    def __init__(self,N,tau,a,b,mixture):
        self.N=integer(N)
        if self.N>64:raise ValueError('artificial count population limit64')
        self.tau=rat(tau);self.a=integer(a,1);self.b=integer(b,1);self.mixture=rat(mixture)
        if not 0<self.tau<1 or not 0<=self.mixture<=1: raise ValueError('invalid risk/mixture')
        self.n=0;self.s=0;self.bounds=(0,N);self.inconsistent=False
    def update(self,y):
        if type(y) is not int or y not in (0,1) or self.n>=self.N: raise ValueError('invalid binary prefix update')
        self.n+=1;self.s+=y
        if self.inconsistent:return None
        q=ordered_q(self.n,self.s,self.a,self.b,self.mixture)
        valid=[]
        for K in range(self.s,self.N-self.n+self.s+1):
            p=Q(_falling(K,self.s)*_falling(self.N-K,self.n-self.s),_falling(self.N,self.n))
            if q*self.tau<p:valid.append(K)
        if not valid:self.inconsistent=True;self.bounds=None;return None
        lo=max(self.bounds[0],min(valid));hi=min(self.bounds[1],max(valid))
        if lo>hi:self.inconsistent=True;self.bounds=None
        else:self.bounds=(lo,hi)
        return self.bounds


@dataclass(frozen=True)
class BatchResult:
    vectors: tuple[tuple[str, tuple[int,...]], ...]
    failed: bool
    new_attempts: int
    receipt_index: int


class ArtificialVectorCache:
    def __init__(self,operator,records,vector_operator,*,scope='artificial',cache_scope):
        if scope!='artificial':raise ValueError('actual data bridge unavailable')
        if cache_scope not in ('cold_request','shared_requests'):raise ValueError('declare cache scenario')
        if not 0<len(records)<=64:raise ValueError('artificial provider record limit64')
        self._operator=operator;self.cache_scope=cache_scope;self._fn=vector_operator
        self._catalog={r.rid:r.content for r in records}
        if len(self._catalog)!=len(records):raise ValueError('duplicate cache catalog RID')
        self._cache={};self.events=[];self._session=None;self._sessions=0
    @property
    def operator(self):return self._operator
    def _key(self,r):
        if self._catalog.get(r.rid)!=r.content:raise ValueError('RID/content binding mismatch')
        return (self.operator.snapshot,self.operator.version,self.operator.modes,r.rid,sha256(r.content.encode()).hexdigest())
    def known(self,r):return self._key(r) in self._cache
    def begin(self,operator,records,budget):
        if self._session is not None:raise ValueError('session already active')
        if operator!=self.operator or {r.rid:r.content for r in records}!=self._catalog:raise ValueError('snapshot/operator/schema/catalog mismatch')
        if self.cache_scope=='cold_request' and (self._sessions or self.events):raise ValueError('cold cache must be fresh')
        integer(budget);self._sessions+=1
        self._session={'budget':budget,'spent':0,'entry':self.totals(),'id':self._sessions}
        return dict(self._session)
    @property
    def remaining(self):return self._session['budget']-self._session['spent']
    def affordable_prefix(self,records):
        cost=0;out=[]
        for r in records:
            cost+=int(not self.known(r))
            if cost>self.remaining:break
            out.append(r)
        return out
    def fetch_batch(self,records,phase):
        if self._session is None:raise ValueError('no active request')
        if phase not in ('pilot','prefetch','formal','census','materialization'):raise ValueError('unknown charge phase')
        if len({r.rid for r in records})!=len(records):raise ValueError('duplicate batch RID')
        keys=[self._key(r) for r in records];fresh=[k not in self._cache for k in keys]
        cost=sum(fresh)
        if cost>self.remaining:raise ValueError('unsubmitted batch exceeds physical budget')
        self._session['spent']+=cost
        event={'session':self._session['id'],'phase':phase,'rids':tuple(r.rid for r in records),'submitted_physical_attempts':cost,'cache_hits':len(records)-cost,'statuses':['SUBMITTED' if f else 'CACHE_HIT_PENDING' for f in fresh]}
        ei=len(self.events);self.events.append(event);vectors=[];failed=False
        for i,(r,k) in enumerate(zip(records,keys)):
            if failed:
                event['statuses'][i]='UNEXECUTED_CHARGED' if fresh[i] else 'UNCONSUMED_CACHE_HIT';continue
            try:
                if fresh[i]:
                    raw=self._fn(r.rid,r.content)
                    if type(raw) is not tuple or len(raw)!=len(self.operator.modes) or any(type(y) is not int or y not in (0,1) for y in raw):raise ValueError('incomplete/nonbinary vector')
                    self._cache[k]=raw
                value=self._cache[k];vectors.append((r.rid,value));event['statuses'][i]='SUCCESS' if fresh[i] else 'CACHE_HIT'
            except Exception as exc:
                event['statuses'][i]='FAILED';event['error_type']=type(exc).__name__;failed=True
        event['failed']=failed
        return BatchResult(tuple(vectors),failed,cost,ei)
    def totals(self):
        return {'physical_attempts':sum(e['submitted_physical_attempts'] for e in self.events),'cache_hits':sum(e['cache_hits'] for e in self.events),'cached_vectors':len(self._cache),'failed_batches':sum(bool(e.get('failed')) for e in self.events)}
    def finish(self):
        end=self.totals();s=self._session
        out={'cache_scope':self.cache_scope,'request_incremental':{k:end[k]-s['entry'][k] for k in end},'cumulative_including_materialization':end,'physical_cap':s['budget'],'spent':s['spent'],'automatic_amortization':False}
        self._session=None;return out
    def materialize_all(self,budget):
        if self.cache_scope!='shared_requests':raise ValueError('materialization needs declared shared cache')
        rows=tuple(Record(rid,content) for rid,content in self._catalog.items())
        self.begin(self.operator,rows,budget)
        try:
            out=self.fetch_batch(rows,'materialization');return out,self.finish()
        except Exception:
            self.finish();raise


@dataclass(frozen=True)
class GroupView:
    gid: str
    original_N: int
    pilot_n: int
    pilot_positives: tuple[int, ...]
    residual_N: int
    n: int
    positives: tuple[int, ...]
    count_intervals: tuple[tuple[int,int] | None, ...]
    priors: tuple[tuple[int,int] | None, ...]
    risks: tuple[Q, ...]
    active_modes: tuple[bool, ...]


@dataclass(frozen=True)
class PolicyState:
    groups: tuple[GroupView, ...]
    contrast_bounds: tuple[tuple[Q,Q] | None, ...]
    expressions: tuple[Linear, ...]
    residual_betas: tuple[Q, ...]
    formal_inference_frozen: bool
    remaining_physical_attempts: int
    step: int
    batch_size: int


@dataclass(frozen=True)
class Choice:
    group_id: str
    batch: int


class RoundRobin:
    def __call__(self,state):
        gs=[g for g in state.groups if g.n<g.residual_N and any(g.active_modes)]
        if not gs:return None
        return Choice(gs[state.step%len(gs)].gid,state.batch_size)


def require_shared_prefix(mode_prefixes):
    """Validate a proposed physical option; no freely chosen component prefix."""
    if not mode_prefixes or any(type(n) is not int or n<0 for n in mode_prefixes):raise ValueError('invalid prefix')
    if len(set(mode_prefixes))!=1:raise ValueError('all modes must share one physical prefix')
    return mode_prefixes[0]


def _config(req,cfg,compiled):
    gs={g.gid for g in req.groups}
    def mapping(rows,keys,name):
        if len(dict(rows))!=len(rows) or set(dict(rows))!=keys:raise ValueError('exact '+name+' keys required')
        return dict(rows)
    ps=mapping(cfg.pilot_sizes,gs,'pilot sizes');pseed=mapping(cfg.pilot_seeds,gs,'pilot seeds');fseed=mapping(cfg.formal_seeds,gs,'formal seeds')
    for g in req.groups:
        integer(ps[g.gid]);integer(pseed[g.gid]);integer(fseed[g.gid])
        if ps[g.gid]>len(g.records):raise ValueError('pilot larger than physical group')
        if pseed[g.gid]>=factorial(len(g.records)) or fseed[g.gid]>=factorial(len(g.records)-ps[g.gid]):raise ValueError('seed must be an exact permutation rank in [0,N!)')
    risks={k:rat(v) for k,v in mapping(cfg.risks,set(compiled.active),'stream risks').items()}
    if any(not 0<x<1 for x in risks.values()) or sum(risks.values(),Q(0))>req.alpha:raise ValueError('exact request risk overspend')
    if cfg.prior_mode not in ('fixed_beta','pilot_smoothed'):raise ValueError('explicit prior mode required')
    fixed=mapping(cfg.fixed_beta,set(compiled.active),'fixed beta') if cfg.prior_mode=='fixed_beta' else {}
    if cfg.prior_mode=='pilot_smoothed' and cfg.fixed_beta:raise ValueError('unused fixed priors forbidden')
    for a,b in fixed.values():integer(a,1);integer(b,1)
    integer(cfg.strength);integer(cfg.batch_size,1)
    mix=rat(cfg.mixture)
    if not 0<=mix<=1 or cfg.cache_scope not in ('cold_request','shared_requests') or type(cfg.stop_on_complete) is not bool:raise ValueError('invalid frozen execution config')
    return ps,pseed,fseed,risks,fixed,mix


def permutation_from_rank(records,rank):
    """Bijection [0,N!) -> permutations; externally uniform ranks give exact WOR.

    Rank/seed provenance and independence are caller obligations. A fixed rank
    is one replay, not itself a random experiment. No PRNG modulo approximation.
    """
    records=list(records);integer(rank)
    if rank>=factorial(len(records)):raise ValueError('permutation rank out of range')
    out=[]
    while records:
        size=factorial(len(records)-1);j,rank=divmod(rank,size);out.append(records.pop(j))
    return out


def execute(req,config,cache,policy):
    """Run one complete artificial vector request; no source loader/data bridge."""
    compiled=compile_request(req);ps,pseed,fseed,risks,fixed,mix=_config(req,config,compiled)
    if cache.cache_scope!=config.cache_scope:raise ValueError('cache scenario changed')
    records=tuple(r for g in req.groups for r in g.records);cache.begin(req.operator,records,req.budget)
    modes=req.operator.modes;groups={g.gid:g for g in req.groups};active=set(compiled.active)
    pilot_s={g.gid:[0]*len(modes) for g in req.groups};pilot_n={g.gid:0 for g in req.groups}
    n={g.gid:0 for g in req.groups};s={g.gid:[0]*len(modes) for g in req.groups}
    residual={g.gid:list(g.records) for g in req.groups};cs={};prior={};hist=[];failure=None;frozen=False
    beta=[e.beta for e in compiled.expressions]
    def current_bounds():
        if any(c.inconsistent for c in cs.values()):return tuple(None for _ in compiled.expressions)
        out=[]
        for e,b in zip(compiled.expressions,beta):
            lo=hi=b
            for key,a in e.terms:
                if frozen:
                    L,U=cs[key].bounds
                else:
                    gid,_=key;L,U=0,len(groups[gid].records)
                lo+=a*(L if a>=0 else U);hi+=a*(U if a>=0 else L)
            out.append((lo,hi))
        return tuple(out)
    def decisions():
        bounds=current_bounds();raw=evaluate(compiled.family,dict(enumerate(bounds)));verify(compiled.family,dict(enumerate(bounds)),raw)
        ranks=dict(compiled.rank_sets)
        out=[]
        for d,name in zip(raw['decisions'],compiled.names):
            val=dict(d);val['name']=name
            if compiled.family.decision_types[d['decision']]=='topk':
                val['selected']=ranks.get(d['positive_certificate']) if d['value'] is True else None
            out.append(val)
        return raw,out
    def snapshot(step):
        views=[]
        for g in req.groups:
            intervals=[];priors=[];taus=[];flags=[]
            for j,m in enumerate(modes):
                key=(g.gid,m);a=key in active;flags.append(a);priors.append(prior.get(key));taus.append(risks.get(key,Q(0)))
                intervals.append(cs[key].bounds if a and frozen else (s[g.gid][j],len(residual[g.gid])-n[g.gid]+s[g.gid][j]))
            views.append(GroupView(g.gid,len(g.records),pilot_n[g.gid],tuple(pilot_s[g.gid]),len(residual[g.gid]) if frozen else len(g.records)-pilot_n[g.gid],n[g.gid],tuple(s[g.gid]),tuple(intervals),tuple(priors),tuple(taus),tuple(flags)))
        return PolicyState(tuple(views),current_bounds(),compiled.expressions,tuple(beta),frozen,cache.remaining,step,config.batch_size)
    def result(reason,step):
        raw,output=decisions()
        return {'scope':'artificial','status':'COMPLETE' if raw['complete'] and failure is None else 'FAILED' if failure else 'UNRESOLVED','stop_reason':reason,'complete':raw['complete'] and failure is None,'decisions':output,'checker':raw,'final_state':snapshot(step),'pilot_counts':tuple((g.gid,pilot_n[g.gid],tuple(pilot_s[g.gid])) for g in req.groups),'residual_betas':tuple(beta),'history':tuple(hist),'cost':cache.finish(),'failure':failure,'frozen_active_streams':compiled.active,'exact_risk_sum':sum(risks.values(),Q(0)),'production_bridge_ready':False,'proof_cost_optimizer_ready':False}
    try:
        raw,_=decisions()
        if raw['complete'] and config.stop_on_complete:return result('STRUCTURAL',0)
        for g in req.groups:
            order=permutation_from_rank(g.records,pseed[g.gid])
            pilot=order[:ps[g.gid]]
            affordable=cache.affordable_prefix(pilot)
            if len(affordable)!=len(pilot):return result('PILOT_BUDGET',0)
            if pilot:
                batch=cache.fetch_batch(pilot,'pilot')
                for _,vec in batch.vectors:
                    pilot_n[g.gid]+=1
                    for j,y in enumerate(vec):pilot_s[g.gid][j]+=y
                if batch.failed:failure='PILOT_VECTOR_READ_FAILURE';return result(failure,0)
            used={r.rid for r in pilot};residual[g.gid]=[r for r in g.records if r.rid not in used]
        for i,e in enumerate(compiled.expressions):
            beta[i]+=sum((a*pilot_s[g][modes.index(m)] for (g,m),a in e.terms),Q(0))
        for gid,m in compiled.active:
            if config.prior_mode=='fixed_beta':a,b=fixed[(gid,m)]
            else:
                p=Q(2*pilot_s[gid][modes.index(m)]+1,2*(pilot_n[gid]+1));k=(config.strength*p).numerator//(config.strength*p).denominator
                a,b=1+k,1+config.strength-k
            prior[(gid,m)]=(a,b);cs[(gid,m)]=ExactPPR(len(residual[gid]),risks[(gid,m)],a,b,mix)
        for gid in residual:residual[gid]=permutation_from_rank(residual[gid],fseed[gid])
        frozen=True;step=0
        while True:
            raw,_=decisions()
            if any(c.inconsistent for c in cs.values()):failure='STICKY_COUNT_CS_FAILURE';return result(failure,step)
            if raw['complete'] and config.stop_on_complete:return result('CERTIFIED',step)
            st=snapshot(step);choice=policy(st)
            if choice is None:return result('NO_PHYSICAL_GROUP_CHOICE',step)
            if type(choice) is not Choice or choice.group_id not in groups or type(choice.batch) is not int or choice.batch<1:raise ValueError('policy must choose one public group and a positive physical batch')
            gid=choice.group_id
            if not any((gid,m) in active for m in modes):raise ValueError('choice of inactive physical group')
            remaining=residual[gid][n[gid]:]
            if not remaining:raise ValueError('exhausted group choice')
            selected=cache.affordable_prefix(remaining[:choice.batch])
            if not selected:return result('PHYSICAL_BUDGET',step)
            phase='census' if len(selected)==len(remaining) and not config.stop_on_complete else 'prefetch' if len(selected)>1 else 'formal'
            batch=cache.fetch_batch(selected,phase)
            for rid,vec in batch.vectors:
                expected=residual[gid][n[gid]].rid
                if rid!=expected:raise ValueError('not a shared physical prefix')
                n[gid]+=1
                for j,y in enumerate(vec):
                    s[gid][j]+=y
                    if (gid,modes[j]) in cs:cs[(gid,modes[j])].update(y)
                raw,_=decisions();hist.append((gid,n[gid],tuple(s[gid]),current_bounds(),raw))
                if any(c.inconsistent for c in cs.values()):break
                if raw['complete'] and config.stop_on_complete and not batch.failed:break
            step+=1
            if batch.failed:failure='VECTOR_READ_FAILURE';return result(failure,step)
    except Exception as exc:
        # Public contract/policy exceptions are retained; no silent retries.
        failure='FRAMEWORK_'+type(exc).__name__
        out=result(failure,0);out['error']=str(exc);return out
