"""Hand-designed labels; no external or Source dataset imports."""
from fractions import Fraction as F
from contract import Record, Linear, TopK, greater, strict_band


def overlap_request():
    from cohort_adapter import CohortRequest
    records = tuple(Record(f"toy_{i}", f"Artificial record {i}") for i in range(12))
    bits = [True, True, False, True, False, False, False, True, False, True, True, False]
    labels = {r.rid: y for r, y in zip(records, bits)}
    cohorts = (("A", tuple(f"toy_{i}" for i in range(6))),
               ("B", tuple(f"toy_{i}" for i in range(3, 9))),
               ("C", tuple(f"toy_{i}" for i in range(9, 12))))
    a, b, c = (Linear.make({name: F(1, n)}) for name, n in [("A", 6), ("B", 6), ("C", 3)])
    gap = a.minus(b)
    request = CohortRequest(records, cohorts,
        (("positive_gap", greater(gap)),
         ("strict_equal_boundary", greater(gap, F(1, 6))),
         ("inside_band", strict_band(gap, 0, F(1, 3))),
         ("equal_lower_boundary", strict_band(gap, F(1, 6), F(1, 3))),
         ("equal_upper_boundary", strict_band(gap, 0, F(1, 6)))),
        topk=TopK((("A", a), ("B", b), ("C", c)), 1), batch_size=4, monitor_every=4, seed=917)
    expected = {"positive_gap": True, "strict_equal_boundary": False, "inside_band": True,
                "equal_lower_boundary": False, "equal_upper_boundary": False}
    return request, labels, expected


def tied_request(k=1):
    from cohort_adapter import CohortRequest
    records = tuple(Record(f"tie_{i}", f"Artificial tie record {i}") for i in range(10))
    labels = {r.rid: i in {0, 1, 4, 5} for i, r in enumerate(records)}
    cohorts = (("A", tuple(f"tie_{i}" for i in range(4))),
               ("B", tuple(f"tie_{i}" for i in range(4, 8))),
               ("C", tuple(f"tie_{i}" for i in range(8, 10))))
    scores = tuple((n, Linear.make({n: F(1, len(m))})) for n, m in cohorts)
    request = CohortRequest(records, cohorts, (), topk=TopK(scores, k), batch_size=2, monitor_every=2, seed=113)
    return request, labels
