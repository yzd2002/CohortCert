"""Finite artificial verification and auditable native return-value capture."""
from pathlib import Path
from fractions import Fraction
from hashlib import sha256
import importlib
import importlib.metadata
import inspect
import json
import os
import socket
import sys
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent


def bound_module(name):
    module = importlib.import_module(name)
    path = Path(module.__file__).resolve()
    return {"module":name,"path":str(path),"sha256":sha256(path.read_bytes()).hexdigest()}


if __name__ == "__main__":
    # Real libraries and pinned native modules are imported; only the model
    # transport is a mock, never the numerical kernel.
    import native_bridge
    from canonical_bridge import NativeExactCanonicalBridge
    from cohort_adapter import CohortNativeIntervalAdapter
    from evergreen import SessionContext
    from evergreen.estimator import ConfSeqEstimator
    from evergreen.common.cache import FileCache
    from confseq.betting import betting_cs

    modules = ["evergreen","evergreen.estimator","evergreen.planner.logical.optimizer",
               "evergreen.planner.physical.planner","evergreen.planner.physical.plan",
               "evergreen.planner.physical.accumulator","confseq","confseq.betting",
               "confseq.betting_strategies","confseq.misc","confseq.predmix","confseq.types",
               "numpy","scipy","scipy.optimize"]
    imported = [bound_module(name) for name in modules]
    for row in imported:
        if row["module"].startswith(("evergreen","confseq")):
            assert Path(row["path"]).is_relative_to(ROOT/"upstream/src")
    alpha_checks = []
    for alpha, cohorts in [(Fraction(1,20),3),(Fraction(1,10),7),(Fraction(1,1000),3)]:
        confidence = native_bridge.conservative_confidence(alpha/cohorts)
        actual = Fraction.from_float(1.0-confidence)
        alpha_checks.append({"request_alpha":str(alpha),"cohorts":cohorts,"confidence_hex":confidence.hex(),
                             "actual_per_cohort":str(actual),"actual_sum":str(actual*cohorts),
                             "sum_le_request":actual*cohorts <= alpha})
    assert all(row["sum_le_request"] for row in alpha_checks)
    binding = {"python":sys.version,"executable":sys.executable,
               "process_nice":os.getpriority(os.PRIO_PROCESS,0),
               "thread_environment":{k:os.environ.get(k) for k in ["OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS"]},
               "actual_imports":imported,
               "installed_distributions":sorted({d.metadata["Name"]:d.version for d in importlib.metadata.distributions()}.items()),
               "betting_cs_defaults":{name:repr(p.default) for name,p in inspect.signature(betting_cs).parameters.items()},
               "native_grid_breaks":ConfSeqEstimator._BREAKS,
               "alpha_fraction_checks":alpha_checks,"statistics_stubs_used":False,
               "confseq_origin_release":"UNKNOWN: vendored README does not record it"}
    (ROOT/"ACTUAL_ENVIRONMENT_READ_BINDING.json").write_text(json.dumps(binding,indent=2)+"\n")

    returns = []
    originals = []
    for cls in [NativeExactCanonicalBridge,CohortNativeIntervalAdapter]:
        original = cls.run
        originals.append((cls,original))
        def capture(self,request,_original=original,_name=cls.__name__):
            answer = _original(self,request)
            returns.append({"interface":_name,"artificial_record_count":len(request.records),
                            "support_mode":request.support_mode,"result":answer})
            return answer
        cls.run = capture
    def forbidden(*args,**kwargs):
        raise AssertionError("external network/API or pickle input is outside artificial validation")
    try:
        with patch.object(socket.socket,"connect",side_effect=forbidden), \
             patch.object(SessionContext,"read_pickle",side_effect=forbidden), \
             patch.object(FileCache,"__getitem__",side_effect=forbidden):
            suite = unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(name)
                                       for name in ["test_contract","test_cohort_projection","test_native_integration"])
            result = unittest.TextTestRunner(verbosity=2).run(suite)
    finally:
        for cls,original in originals: cls.run = original
        (ROOT/"ARTIFICIAL_NATIVE_RETURNS.json").write_text(json.dumps(returns,indent=2)+"\n")
    summary = {"scope":"artificial_only","status":"PASS" if result.wasSuccessful() else "FAIL",
               "tests_run":result.testsRun,"failures":len(result.failures),"errors":len(result.errors),
               "captured_interface_returns":len(returns),"statistics_stubs_used":False,
               "model_or_api_calls":False,"actual_source_access":False,
               "real_workload_performance_established":False,"source_s_gate_assessed":False,
               "machine_level_native_coverage_certification":"UNKNOWN; upstream kernel not independently recertified"}
    (ROOT/"ARTIFICIAL_VALIDATION.json").write_text(json.dumps(summary,indent=2)+"\n")
    raise SystemExit(0 if result.wasSuccessful() else 1)
