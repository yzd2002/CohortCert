"""Bounded CPU-wheel recovery, preserving failure logs and Source disk headroom."""
from pathlib import Path
import importlib.metadata
import json
import shutil
import subprocess
import zipfile

from fetch_public_wheels import fetch

ROOT = Path(__file__).resolve().parent
CAP = 320 * 2**20


def resident():
    return int(subprocess.check_output(["du", "-s", "--block-size=1", str(ROOT)]).split()[0])


if __name__ == "__main__":
    plan = json.loads((ROOT/"PUBLIC_CPU_WHEEL_PLAN_06.json").read_text())
    assert all(x["status"] == "HASH_BOUND" for x in plan)
    assert sum(x["size"] for x in plan) < 32*2**20
    assert not any(any(s in x["name"] for s in ["torch", "cuda", "nvidia", "tensorflow"]) for x in plan)
    results = []
    try:
        for item in sorted(plan, key=lambda x: -x["size"]):
            try:
                if importlib.metadata.version(item["name"]) == item["version"]:
                    results.append({"name":item["name"],"version":item["version"],"status":"ALREADY_INSTALLED"})
                    continue
            except importlib.metadata.PackageNotFoundError:
                pass
            if resident()+2*item["size"] > CAP:
                raise RuntimeError("candidate 320MiB resident cap would be exceeded during transfer")
            result = fetch(item, workers=1)
            wheel = ROOT/"wheels"/item["filename"]
            # Successful range chunks are redundant after whole-wheel SHA check.
            ranges = ROOT/"wheel_ranges"/item["filename"]
            if ranges.exists(): shutil.rmtree(ranges)
            with zipfile.ZipFile(wheel) as archive:
                expanded = sum(x.file_size for x in archive.infolist())
            if resident()+expanded > CAP:
                raise RuntimeError("candidate 320MiB resident cap would be exceeded by CPU dependency")
            log = ROOT/("OFFLINE_INSTALL_"+item["name"]+".log")
            with log.open("w") as out:
                completed = subprocess.run([str(ROOT/".venv/bin/python"),"-m","pip","install",
                    "--no-index","--no-deps","--no-compile","--no-cache-dir",str(wheel)],stdout=out,stderr=subprocess.STDOUT)
            if completed.returncode:
                raise RuntimeError("offline install failed: "+item["name"])
            wheel.unlink()
            results.append({"name":item["name"],"version":item["version"],"status":"INSTALLED_HASH_VERIFIED_CPU_WHEEL",
                            "sha256":item["sha256"],"compressed_bytes":item["size"],"uncompressed_bytes":expanded,
                            "resident_bytes_after":resident(),"transfer_copies_reclaimed":True})
            (ROOT/"CPU_DEPENDENCY_RECOVERY_PROGRESS.json").write_text(json.dumps(results,indent=2)+"\n")
    except Exception as exc:
        (ROOT/"CPU_DEPENDENCY_RECOVERY_STOP.json").write_text(json.dumps({"error":str(exc),"results":results,"resident_bytes":resident()},indent=2)+"\n")
        raise
    (ROOT/"CPU_DEPENDENCY_RECOVERY_COMPLETE.json").write_text(json.dumps(results,indent=2)+"\n")
    print(json.dumps({"status":"COMPLETE","distributions":len(results),"resident_bytes":resident()}))
