"""Resume public PyPI wheel downloads and verify PyPI SHA256 before installation.

This downloads ordinary declared dependencies only; it does not import/install
them or execute an external script. Failed transfers and partial ranges remain
inside this candidate. Run with nice 10 and single-threaded BLAS environment.
"""
from concurrent.futures import ThreadPoolExecutor, as_completed
from hashlib import sha256
from pathlib import Path
import argparse
import json
import time
import urllib.request

ROOT = Path(__file__).resolve().parent


def fetch(wheel, workers=1):
    url, size, digest = wheel["url"], wheel["size"], wheel["sha256"]
    name = url.rsplit("/", 1)[1]
    if not name.endswith(".whl") or not url.startswith("https://files.pythonhosted.org/"):
        raise ValueError("only hash-bound official PyPI wheel files are permitted")
    destination = ROOT / "wheels" / name
    destination.parent.mkdir(exist_ok=True)
    if destination.exists() and sha256(destination.read_bytes()).hexdigest() == digest:
        return {"file": name, "status": "ALREADY_VERIFIED", "bytes": size, "sha256": digest}
    pieces = ROOT / "wheel_ranges" / name
    pieces.mkdir(parents=True, exist_ok=True)
    chunk = 131072
    failures = []

    def part(index):
        start, end = index*chunk, min(size, (index+1)*chunk)-1
        target = pieces / str(index)
        if target.is_file() and target.stat().st_size == end-start+1:
            return
        for attempt in range(4):
            try:
                request = urllib.request.Request(url, headers={"Range": f"bytes={start}-{end}"})
                with urllib.request.urlopen(request, timeout=25) as response:
                    data = response.read()
                    if response.status != 206 or response.headers.get("Content-Range") != f"bytes {start}-{end}/{size}" or len(data) != end-start+1:
                        raise ValueError("range response mismatch")
                target.write_bytes(data)
                return
            except Exception as exc:
                failures.append({"part": index, "attempt": attempt+1, "error": str(exc)})
                if attempt < 3:
                    time.sleep(min(2**attempt, 4))
        raise RuntimeError("range failed: " + str(index))

    error = None
    try:
        with ThreadPoolExecutor(max_workers=workers) as pool:
            for future in as_completed([pool.submit(part, i) for i in range((size+chunk-1)//chunk)]):
                future.result()
        h = sha256()
        with destination.open("wb") as out:
            for i in range((size+chunk-1)//chunk):
                data = (pieces/str(i)).read_bytes()
                h.update(data)
                out.write(data)
        if h.hexdigest() != digest:
            raise RuntimeError("assembled wheel does not match PyPI SHA256")
    except Exception as exc:
        error = str(exc)
    result = {"file": name, "url": url, "status": "VERIFIED" if error is None else "FAILED",
              "bytes": size, "sha256": digest, "error": error, "failed_transfers": failures}
    (ROOT / ("WHEEL_FETCH_"+name+".json")).write_text(json.dumps(result, indent=2)+"\n")
    if error: raise RuntimeError(error)
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("metadata")
    parser.add_argument("--workers", type=int, default=1)
    args = parser.parse_args()
    metadata = json.loads(Path(args.metadata).read_text())
    print(json.dumps([fetch(x, args.workers) for x in metadata]))
