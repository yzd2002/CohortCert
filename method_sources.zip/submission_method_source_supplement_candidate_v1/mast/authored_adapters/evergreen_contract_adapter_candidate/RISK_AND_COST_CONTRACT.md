# Risk, observation and cost contract

## Fixed target and native components

The target is one immutable binary predicate reference on fixed records. Compilation sees only IDs, content bindings, cohort membership and exact rational coefficients. A predicate answer is requested only through the mock provider; source maps, model calls, natural-language claim generation and external API access are absent. Different model/prompt references cannot share a label-cache entry.

The primary progressive adapter creates a native proportion query for each unique, used cohort. The unchanged native logical optimizer inserts its Shuffle/CountScan/projection path. The adapter initializes accumulators with the native `_create_accumulators()` at the same point as `_next_without_group_by()`, and each consumed tuple is passed to native `_update_accumulators()`. Native `ConfSeqEstimator.estimate_mean()` obtains the interval from the original betting CS with finite N and its original grid padding. The adapter never substitutes a mean-e factor, coefficient-cell sampler, count dual or joint feedback region.

The new part is explicit: the wrapper drives the physical input incrementally and exposes cohort prefix intervals; the unchanged `StreamAggregate.next()` does not do this. Cohort scheduling is predeclared round-robin or block order, not CohortCert's allocator. Exact affine interval projection, Boolean logic, strict top-k and standard running intersection are wrapper operations. Identical public cohort sets are shared and common score terms cancel algebraically. Arbitrary overlaps do not become independent observations.

## Anytime request-level guarantee

Let the unique used cohort streams be g=1,...,G. Before reading any labels, assign alpha_g with sum alpha_g <= request alpha. Each native query receives alpha_g; its original operator/accumulator/group risk splitting remains enabled. For the single-aggregate, single-cohort queries used here this reduces to the same alpha_g. The float confidence parameter is rounded conservatively, and the effective native risk is checked against its rational allocation.

For each cohort, define E_g to be the event that its native CS contains that cohort's true fixed population mean at **every** prefix of its native uniform WOR permutation. Assuming the upstream CS guarantee, P(E_g^c) <= alpha_g. Hence P(intersection_g E_g) >= 1 - sum_g alpha_g without any independence assumption across overlapping cohorts.

On this joint event, integer count domains obtained from the native intervals contain the true counts. The interface first rounds native float endpoints outward by one ULP, preventing the readout from rounding a logical bound such as float(1/5) inward to two positives when N=5. This protects the conversion itself and does not recertify numerical work inside the original kernel. Rational signed projection contains every true requested contrast. An inequality is True only if its lower bound is strictly above zero, and False only if its upper bound is at most zero. A strict band uses both original strict inequalities; equality at either edge is False. All Boolean decisions are correct on the same event. A strict top-k set is identified only if every inside/outside difference has positive lower bound. Boundary ties are returned explicitly when certified; internal ties do not invalidate a strict external boundary. No arbitrary tie breaking is used.

Truth resolution and strict identification are separate result fields. A certified boundary tie returns `status="TIED"` and `eligible_full_request_completion=false`, even when all Boolean truth components are known. It is never counted as a strict identification completion. An unfinished/invalid interval returns UNKNOWN, not a tie or baseline loss.

This implication holds simultaneously over all wrapper stopping times, monitored prefixes and requested decisions. No additional per-decision split is needed when all reuse the same cohort coverage event. Changing scheduling or selecting a favorable policy after inspecting labels is outside this contract. Running several policies with their own full alpha and then selecting an answer is not automatically a single-alpha procedure.

The probability statement assumes the original random-sampling model. Artificial fixed seeds provide reproducible test traces, not an empirical or adversarial guarantee about every deterministic PRNG seed. Future comparisons must predeclare/generate sampling randomness independently of labels and outcomes. The candidate does not independently recertify floating-point arithmetic inside the upstream CS or establish empirical coverage.

## Cache hits, cross-query information and prefetch

Each cohort has a full native permutation fixed independently of its unseen labels. Its statistical sequence contains only the prefix actually consumed by that cohort's native accumulator. A cache hit contributes the binary value at that tuple's native position; it is not a new physical label. No cached value outside the prefix is preloaded into a CS.

Already charged labels outside a cohort's prefix may separately tighten its deterministic support: K lies between the number of known positives and that number plus the number of still unknown member labels. This can complete an entirely warm request without rerunning statistical samples. It is explicitly cache-aware wrapper logic, not an extra native observation or a changed statistical kernel. Its bounds are pathwise valid, and earlier materialization remains in the cumulative account.

Other queries or native batch prefetch may reveal future physical labels. This extra information does not alter the already defined local permutations or the all-prefix events E_g. The global return can only be wrong outside their joint event. This is a simultaneous-coverage argument; the adapter does not falsely claim that the local betting process remains a martingale under every enlarged filtration revealing future values.

Every provider call and each consumed accumulator position are separately traced. Native batching can pay for more labels than the final statistical prefix contains. All such submitted mock labels retain their charge; unused prefetch is never refunded. A budget-exhausted next call is not submitted, and the existing charged prefix is retained. Failure/unfinished work is UNKNOWN, not a False verdict or a baseline loss.

## Cold and shared-request scenarios

- `cold_request`: a new record cache for the entire request. Every native claim/cohort within the request shares it. A second request on that cache is rejected, preventing an undeclared warm start. Each baseline arm receives its own fresh cache for a cold comparison.
- `shared_requests`: explicitly declared before running a request sequence. All requests use the same fixed predicate reference and record bindings. Each result reports labels known at entry, that request's incremental cost, and cumulative cost including earlier materialization. No automatic amortization or removal of initial materialization cost occurs. Request order must be declared before outcomes are inspected.

Charges in this candidate are artificial physical-label-attempt units. They are not dollars, tokens or real model forwards. Native logical observations, prompt/cache metrics, unique successful labels, charged failed attempts and prefetched labels are not interchangeable quantities. A future economic comparison needs an audited mapping to its actual backend ledger.

## Scope limit

The canonical control preserves native whole-query aggregate execution; the final strict output vector is an explicit exact wrapper. It remains a legitimate completion even if it scans the full relation, and budget-exhausted UNKNOWN must be retained. The progressive wrapper demonstrates a stronger reasonable interface, not the strongest possible Evergreen optimizer or a validated real-data performance baseline. The LCM route is only a separate artificial control. None changes the frozen SourceS protocol or supplies an acceptance-grade claim.
