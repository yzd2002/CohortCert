# Independent review scope

Review the frozen source/evidence manifest first. Do not inspect actual Source maps, raw traces, run directories, label/charge ledgers, source loaders or models. Do not install new dependencies or rerun a large matrix. The existing `.venv` is a local verification environment, not a bundled public artifact.

Suggested small distinguishing checks using nice 10 and BLAS/OMP/MKL threads one:

1. Read the actual imported `confseq`/Evergreen paths and hashes, the default grid expansion and Theorem 4 assumptions; verify a between-grid finite count and the separate conservative alpha/readout layers.
2. Select the overlapping strict-boundary fixture under exact native and progressive modes. Check complete Boolean vectors and actual alpha sum; identify the explicit private progressive interface boundary.
3. Select shared support with original n=6/native Nsubset=3. Check every removed-RID coefficient vector and unchanged denominator/beta; confirm no outside-support label is requested.
4. Inspect the N=80 artificial trace showing prefix 9 versus paid prefetch 16, and the declared shared-request trace retaining the earlier 12-label materialization in cumulative cost.
5. Read the original 35/36 log and the constructed stacked-map KeyError. Confirm the final Filter→Map control is a separate, narrow component validation, not an upstream fix or full-optimizer claim. Check TIED and capped UNKNOWN are not eligible completions.

Actual performance, empirical coverage, the frozen SourceS gate and any paper grade are outside this review. Unresolved issues should remain UNKNOWN; no requested scientific gate may be relaxed.
