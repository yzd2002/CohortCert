"""Fixed-reference artificial predicate and shared physical-label accounting."""
from __future__ import annotations

from hashlib import sha256
from threading import RLock
from contract import Record


class MockLabelBudgetExhausted(RuntimeError):
    pass


class SharedLabelCache:
    def __init__(self, reference: str, records: tuple[Record, ...], predicate, scope="artificial", cache_scope="cold_request", label_attempt_limit=None):
        if scope != "artificial":
            raise ValueError("actual-source providers are not authorized")
        if not reference:
            raise ValueError("a fixed predicate reference is required")
        if cache_scope not in {"cold_request", "shared_requests"}:
            raise ValueError("cache lifecycle must be declared")
        self._reference = reference
        self.cache_scope = cache_scope
        self._request_count = 0
        self._current_request = None
        if label_attempt_limit is not None and (type(label_attempt_limit) is not int or label_attempt_limit < 0):
            raise ValueError("label attempt limit must be nonnegative")
        self.label_attempt_limit = label_attempt_limit
        self._request_attempts = 0
        self._public = {r.rid: r.text for r in records}
        self._digests = {rid: sha256(text.encode()).hexdigest() for rid, text in self._public.items()}
        if len(self._public) != len(records):
            raise ValueError("duplicate record identity")
        self._predicate = predicate
        self._values: dict[str, bool] = {}
        self.events: list[dict] = []
        self._lock = RLock()

    @property
    def reference(self):
        return self._reference

    def fetch(self, reference, rid, text, query_id, logical_id):
        if reference != self.reference or self._public.get(rid) != text:
            raise ValueError("fixed predicate/reference/content binding mismatch")
        with self._lock:
            hit = rid in self._values
            if not hit and self.label_attempt_limit is not None and self._request_attempts >= self.label_attempt_limit:
                raise MockLabelBudgetExhausted("next mock label was not submitted: request budget exhausted")
            event = {"request_id": self._current_request, "query_id": query_id, "logical_id": logical_id, "rid": rid,
                     "reference": reference, "content_sha256": self._digests[rid],
                     "cache_hit": hit, "physical_label_attempts": 0 if hit else 1,
                     "mock_label_fee_units": 0 if hit else 1, "status": "PENDING"}
            self.events.append(event)
            if not hit:
                self._request_attempts += 1
                try:
                    value = self._predicate(rid, text)
                    if type(value) is not bool:
                        raise ValueError("fixed binary predicate must return bool")
                except Exception as exc:
                    event.update(status="FAILED", error_type=type(exc).__name__)
                    raise
                self._values[rid] = value
            event["status"] = "SUCCESS"
            return self._values[rid]

    def begin_request(self):
        if self._current_request is not None:
            raise ValueError("cache already has an active request")
        if self.cache_scope == "cold_request" and (self._request_count or self.events):
            raise ValueError("cold-request cache must be fresh; declare shared_requests to reuse")
        self._request_count += 1
        self._current_request = "mock_request_" + str(self._request_count)
        self._request_attempts = 0
        return {"request_id": self._current_request, "entry_totals": self.totals(),
                "labels_known_at_entry": len(self._values), "event_offset": len(self.events)}

    def finish_request(self, start):
        totals = self.totals()
        result = {"cache_scope": self.cache_scope, "request_id": start["request_id"],
                  "label_attempt_limit": self.label_attempt_limit,
                  "labels_known_at_entry": start["labels_known_at_entry"],
                  "this_request": {k: totals[k]-start["entry_totals"][k] for k in totals},
                  "cumulative_including_prior_materialization": totals,
                  "automatic_amortization_applied": False}
        self._current_request = None
        return result

    def exact_after_census(self, required_rids):
        required = set(required_rids)
        if not required <= self._values.keys():
            raise ValueError("census incomplete; unobserved cache values cannot be read")
        return {rid: self._values[rid] for rid in required}

    def known_member_bounds(self, members):
        """Exact logic from already charged labels; never an extra CS sample."""
        members = tuple(members)
        if not set(members) <= self._public.keys():
            raise ValueError("unknown public cache member")
        observed = [self._values[rid] for rid in members if rid in self._values]
        positives = sum(observed)
        return positives, positives+len(members)-len(observed), len(observed)

    def totals(self):
        return {"logical_predicate_evaluations": len(self.events),
                "physical_label_attempts": sum(e["physical_label_attempts"] for e in self.events),
                "mock_label_fee_units": sum(e["mock_label_fee_units"] for e in self.events),
                "cache_hits": sum(e["cache_hit"] for e in self.events),
                "successful_unique_labels": len(self._values),
                "failed_attempts": sum(e["status"] == "FAILED" for e in self.events)}
