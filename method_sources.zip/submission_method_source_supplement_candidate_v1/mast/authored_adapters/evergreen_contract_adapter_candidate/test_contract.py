from fractions import Fraction as F
from itertools import product
import unittest

from contract import (Claim, Linear, Record, Request, TopK, compile_request,
                      exact_truth, greater, strict_band, all_of, any_of, negate)
from mock_provider import SharedLabelCache


class PublicContractTests(unittest.TestCase):
    def setUp(self):
        self.records = tuple(Record("toy_"+str(i), "Artificial item "+str(i)) for i in range(3))

    def test_signed_replication_control_matches_original_rational_expression(self):
        # Independent finite enumeration checks the original rational sum against
        # integer relational counts, including both strict boundary directions.
        count = 0
        for coefficients in product([F(-2, 3), F(0), F(5, 7)], repeat=3):
            for intercept in [F(-5, 6), F(0), F(1, 7)]:
                expression = Linear.make({r.rid: a for r, a in zip(self.records, coefficients)}, intercept)
                request = Request(self.records, (("decision", greater(expression)),))
                compiled = compile_request(request)
                for bits in product([False, True], repeat=3):
                    labels = dict(zip([r.rid for r in self.records], bits))
                    expected = intercept + sum(a * int(y) for a, y in zip(coefficients, bits)) > 0
                    answers = {key: sum((int(labels[rid]) if w > 0 else 1-int(labels[rid]))*abs(w)
                                        for rid, w in atom.weights) > atom.threshold
                               for key, atom in compiled.atoms.items()}
                    self.assertEqual(compiled.decisions[0][1].resolve(answers), expected)
                    count += 1
        self.assertEqual(count, 648)

    def test_strict_band_boundary_equality_is_false(self):
        score = Linear.make({"toy_0": 1})
        for y in [False, True]:
            request = Request(self.records, (("strict", strict_band(score, 0, 1)),))
            self.assertFalse(exact_truth(request, {r.rid: y for r in self.records})[0]["strict"])

    def test_boolean_short_circuit_preserves_full_vector(self):
        a = greater(Linear.make({"toy_0": 1}), 0)
        b = greater(Linear.make({"toy_1": 1}), 0)
        req = Request(self.records, (("and", all_of(a, b)), ("or", any_of(a, b)), ("not", negate(a))))
        cp = compile_request(req)
        first = cp.decisions[0][1].children[0].key
        answers = {first: False}
        self.assertIs(cp.decisions[0][1].resolve(answers), False)
        self.assertIs(cp.decisions[2][1].resolve(answers), True)
        self.assertEqual(len(cp.needed(answers)), 1)

    def test_risk_budget_shared_atoms(self):
        a = greater(Linear.make({"toy_0": F(2, 3)}))
        b = greater(Linear.make({"toy_0": F(4, 3)}))
        cp = compile_request(Request(self.records, (("a", a), ("b", b))))
        self.assertEqual(len(cp.atoms), 1)
        self.assertEqual(sum(x.alpha for x in cp.atoms.values()), F(1, 20))

    def test_lcm_control_fallback_is_explicit(self):
        expression = Linear.make({"toy_0": F(1, 1009), "toy_1": F(-1, 1013)})
        cp = compile_request(Request(self.records, (("x", greater(expression)),), expansion_limit=20))
        self.assertEqual(cp.mode, "explicit_exact_census_fallback")

    def test_direct_duplicate_coefficients_normalize(self):
        self.assertEqual(Linear((("toy_0", F(1)), ("toy_0", F(-1)))), Linear())

    def test_actual_scope_is_rejected(self):
        with self.assertRaises(ValueError): Request(self.records, (), scope="actual")
        with self.assertRaises(ValueError): SharedLabelCache("ref", self.records, lambda *_: True, scope="actual")


class CacheTests(unittest.TestCase):
    def setUp(self):
        self.records = (Record("toy_a", "Artificial alpha"), Record("toy_b", "Artificial beta"))

    def test_within_request_cache_and_physical_cost(self):
        c = SharedLabelCache("fixed", self.records, lambda rid, _: rid == "toy_a")
        start = c.begin_request()
        self.assertTrue(c.fetch("fixed", "toy_a", self.records[0].text, "q1", "v0"))
        self.assertTrue(c.fetch("fixed", "toy_a", self.records[0].text, "q2", "v1"))
        report = c.finish_request(start)
        self.assertEqual(report["this_request"]["logical_predicate_evaluations"], 2)
        self.assertEqual(report["this_request"]["physical_label_attempts"], 1)
        self.assertEqual(report["this_request"]["cache_hits"], 1)
        with self.assertRaises(ValueError): c.begin_request()

    def test_shared_requests_keep_materialization_in_cumulative_account(self):
        c = SharedLabelCache("fixed", self.records, lambda *_: False, cache_scope="shared_requests")
        start = c.begin_request()
        c.fetch("fixed", "toy_a", self.records[0].text, "materialization", "v0")
        first = c.finish_request(start)
        start = c.begin_request()
        c.fetch("fixed", "toy_a", self.records[0].text, "q2", "v1")
        second = c.finish_request(start)
        self.assertEqual(first["this_request"]["physical_label_attempts"], 1)
        self.assertEqual(second["this_request"]["physical_label_attempts"], 0)
        self.assertEqual(second["labels_known_at_entry"], 1)
        self.assertEqual(second["cumulative_including_prior_materialization"]["physical_label_attempts"], 1)
        self.assertFalse(second["automatic_amortization_applied"])

    def test_binding_and_census_read_guard(self):
        c = SharedLabelCache("fixed", self.records, lambda *_: True)
        with self.assertRaises(ValueError): c.fetch("other", "toy_a", self.records[0].text, "q", "v")
        with self.assertRaises(ValueError): c.fetch("fixed", "toy_a", "changed", "q", "v")
        with self.assertRaises(ValueError): c.exact_after_census(["toy_a"])
        self.assertEqual(c.totals()["physical_label_attempts"], 0)

    def test_failed_label_attempt_is_not_free_or_false(self):
        def fail(*_): raise RuntimeError("artificial failure")
        c = SharedLabelCache("fixed", self.records, fail)
        with self.assertRaises(RuntimeError): c.fetch("fixed", "toy_a", self.records[0].text, "q", "v")
        self.assertEqual(c.totals()["physical_label_attempts"], 1)
        self.assertEqual(c.totals()["failed_attempts"], 1)
        self.assertEqual(c.totals()["successful_unique_labels"], 0)


if __name__ == "__main__": unittest.main()
