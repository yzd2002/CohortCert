"""Adapter around the byte-bound, unchanged Evergreen planner and executor.

Only this module imports upstream. It never creates a Snowflake/Cortex session,
loads a pickle, reads a source file, or performs a network/API request.
"""
from __future__ import annotations

from fractions import Fraction
from pathlib import Path
import hashlib
import logging
import math
import os
import re
import sys

from contract import Atom, Compiled, Request, compile_request, exact_truth
from mock_provider import SharedLabelCache

ROOT = Path(__file__).resolve().parent
UPSTREAM = ROOT / "upstream" / "src"
if str(UPSTREAM) not in sys.path:
    sys.path.insert(0, str(UPSTREAM))
# Upstream requires this variable at import. This fresh task-local directory is
# not used to read existing caches; the mock provider uses only an in-memory cache.
os.environ["EVERGREEN_CACHE_DIR_ROOT"] = str(ROOT / "mock_cache_unused")

from evergreen import SessionContext, col, count_if, prompt
from evergreen.catalog.schema import Field, Schema
from evergreen.common.types import Interval
from evergreen.model.config import ModelConfig
from evergreen.model.embedding_model import EmbeddingModel
from evergreen.model.language_model import LanguageModel, LanguageModelMetrics
from evergreen.storage.row import Row


def conservative_confidence(alpha: Fraction) -> float:
    alpha = Fraction(alpha)
    confidence = math.nextafter(1.0 - float(alpha), 1.0)
    if not 0 < confidence < 1 or Fraction.from_float(1.0 - confidence) > alpha:
        raise ValueError("risk is too small for native float confidence parameter")
    return confidence


def _field(formatted: str, name: str) -> str:
    # Match within the final field_values block, not example/schema instructions.
    body = formatted.rsplit("<field_values>", 1)[1].split("</field_values>", 1)[0]
    values = re.findall(r"<" + re.escape(name) + r"(?:\s[^>]*)?>\n(.*?)\n</" + re.escape(name) + r">", body, re.S)
    if len(values) != 1:
        raise ValueError("mock transport field missing or ambiguous: " + name)
    return values[0]


class FixedMockLanguageModel(LanguageModel):
    def __init__(self, cache, query_id):
        super().__init__("fixed-artificial-predicate", None)
        self.cache = cache
        self.query_id = query_id
        self._metrics = LanguageModelMetrics("fixed-artificial-predicate")
        self.fused_invocations = 0
        self.batch_invocations = 0

    def metrics(self):
        return (self._metrics.copy(),)

    def clear_metrics(self):
        self._metrics.clear()

    def _label(self, formatted):
        instructions = formatted.rsplit("<field_values>", 1)[0]
        references = re.findall(r"FIXED_REF=([A-Za-z0-9_-]+)", instructions)
        if not references or set(references) != {self.cache.reference}:
            raise ValueError("mock query changed the fixed predicate reference")
        self._metrics.prompt_count += 1
        rid, text, logical = (_field(formatted, name) for name in ["rid", "text", "logical_id"])
        before = self.cache.totals()["cache_hits"]
        value = self.cache.fetch(self.cache.reference, rid, text, self.query_id, logical)
        self._metrics.prompt_cache_hit_count += self.cache.totals()["cache_hits"] - before
        return value

    def prompt(self, prompt_strs, return_type, schema=None, json_schema=None):
        if return_type is not bool:
            raise ValueError("only fixed binary predicate is authorized")
        self.batch_invocations += 1
        return [self._label(p) for p in prompt_strs]

    def fused_prompt(self, prompt_strs, return_types, schema=None, json_schema=None):
        if any(t is not bool for t in return_types):
            raise ValueError("only fixed binary predicates may be fused")
        self.fused_invocations += 1
        self.batch_invocations += 1
        # Each instruction must be exactly the same fixed reference. The native
        # fused operator still runs; one physical label supplies these identical
        # predicate outputs, with no simulated semantic model quality claim.
        if any(p.count("FIXED_REF=" + self.cache.reference) != len(return_types) for p in prompt_strs):
            raise ValueError("fusion would change the fixed predicate target")
        return [tuple([self._label(p)] * len(return_types)) for p in prompt_strs]

    def prompt_with_schema(self, *args, **kwargs):
        raise RuntimeError("optimizer/model-generated requests are not authorized")

    def prompt_without_schema(self, *args, **kwargs):
        raise RuntimeError("optimizer/model-generated requests are not authorized")


class NoEmbedding(EmbeddingModel):
    def __init__(self):
        super().__init__("not-used-artificial-scope", None)

    def metrics(self): return ()
    def clear_metrics(self): pass
    def embed(self, *args, **kwargs): raise RuntimeError("embedding/API access is not authorized")
    def embed_batch(self, *args, **kwargs): raise RuntimeError("embedding/API access is not authorized")


class MockConfig(ModelConfig):
    def __init__(self, model): self.model = model
    def create_language_model(self, cache_dir): return self.model
    def create_embedding_model(self, cache_dir): return NoEmbedding()
    def create_optimizer_language_model(self, cache_dir): return self.model


class EstimatorTrace(logging.Handler):
    def __init__(self):
        super().__init__(logging.DEBUG)
        self.calls = []

    def emit(self, record):
        if record.msg.startswith("Mean estimate:"):
            interval, observations, population = record.args
            self.calls.append({"observations": observations, "population_size": population,
                               "lower": interval.lower, "upper": interval.upper,
                               "effective_alpha": 1.0 - interval.confidence_level})


def _walk(plan):
    yield plan
    for child in plan.inputs():
        yield from _walk(child)


class ExpandedControlBridge:
    """Artificial existence/control adapter, not the recommended main baseline.

    The integer-LCM relational expansion can be expensive and its census fallback
    must not stand in for stronger reasonable cohort-native interval capability.
    """
    def __init__(self, cache: SharedLabelCache):
        self.cache = cache
        self.query_traces = []

    def _context(self, query_id, seed, alpha, batch_size):
        model = FixedMockLanguageModel(self.cache, query_id)
        ctx = SessionContext()
        ctx.enable_batching(batch_size)
        ctx.enable_fusion()
        ctx.enable_minimal_provenance()
        ctx.enable_early_stop()
        if alpha is not None:
            # Native API carries its own seed; no replacement sampler is used.
            ctx.enable_estimation(confidence_level=conservative_confidence(alpha),
                                  relative_error=0.05, random_seed=seed)
        ctx.enable_cache("artificial-mock-no-pickle")
        ctx.register_model_config(MockConfig(model))
        return ctx, model

    def _execute(self, df, model, query_id, alpha):
        state = df._session_state
        logical = state.optimize_logical_plan(df.logical_plan())
        physical = state.create_physical_plan(logical)
        nodes = list(_walk(physical))
        log = logging.getLogger("evergreen.estimator")
        handler = EstimatorTrace()
        old_level = log.level
        log.setLevel(logging.DEBUG)
        log.addHandler(handler)
        start = len(self.cache.events)
        rows = []
        trace = {"query_id": query_id, "native_plan_types": [type(n).__name__ for n in nodes],
                 "optimized_logical_plan": logical.display(), "assigned_alpha": None if alpha is None else str(alpha),
                 "canonical_kernel_unchanged": True, "native_shuffle": [], "native_accumulators": [],
                 "status": "PENDING"}
        try:
            physical.open()
            while (row := physical.next()) is not None:
                rows.append(row)
            trace["status"] = "SUCCESS"
        except Exception as exc:
            trace.update(status="UNKNOWN", error_type=type(exc).__name__, error=str(exc))
            raise
        finally:
            physical.close()
            log.removeHandler(handler)
            log.setLevel(old_level)
            trace["cs_calls"] = handler.calls
            trace["fused_invocations"] = model.fused_invocations
            trace["batch_invocations"] = model.batch_invocations
            events = self.cache.events[start:]
            trace["provider_events"] = list(events)
            for n in nodes:
                if type(n).__name__ == "Shuffle":
                    shuffled = n._shuffled_rows or []
                    idx = n.schema().index_of("logical_id")
                    trace["native_shuffle"].append([str(row[idx]) for row in shuffled])
                if type(n).__name__ == "StreamAggregate":
                    for a in n._accumulators:
                        obs = getattr(a, "_observations", [])
                        ci = getattr(a, "_confidence_interval", None)
                        trace["native_accumulators"].append({"type": type(a).__name__,
                            "population_size": getattr(a, "_precomputed_total", None),
                            "statistical_observations": len(obs),
                            "observed_values": list(obs),
                            "effective_alpha": None if a._confidence_level is None else 1.0 - a._confidence_level,
                            "used_cs_to_stop": ci is not None})
            # Provider calls may include charged prefetch beyond the accumulator
            # prefix. Both quantities are retained; no unused labels are refunded.
            trace["physical_label_attempts"] = sum(e["physical_label_attempts"] for e in events)
            trace["cache_hits"] = sum(e["cache_hit"] for e in events)
            self.query_traces.append(trace)
        return rows, trace

    def count_claim(self, request: Request, atom: Atom):
        records = {r.rid: r.text for r in request.records}
        expanded = atom.expanded()
        ctx, model = self._context(atom.key, atom.seed, atom.alpha, request.batch_size)
        schema = Schema((Field("logical_id", str), Field("rid", str), Field("text", str), Field("flip", bool)), ("logical_id",))
        rows = [Row((logical, rid, records[rid], flip)) for logical, rid, flip in expanded]
        p = f"FIXED_REF={self.cache.reference}; record {{rid}}, content {{text}}, tuple {{logical_id}}. Return the fixed binary predicate."
        df = (ctx.read_rows(rows, schema).map(prompt(p, bool).alias("label"))
              .aggregate([count_if(col("label").ne(col("flip"))).alias("n")])
              .check(col("n") > atom.threshold))
        result, trace = self._execute(df, model, atom.key, atom.alpha)
        if len(result) != 1 or type(result[0][-1]) is not bool:
            raise ValueError("native query did not return one Boolean verdict")
        trace.update(coverage=atom.coverage, expanded_population=atom.population,
                     normalized_threshold=atom.threshold, verdict=result[0][-1])
        # The unchanged native stream must have a WOR permutation and consume a
        # prefix; caching cannot silently insert an arbitrary observation order.
        if not trace["native_shuffle"]:
            raise ValueError("native estimation query has no shuffle")
        order = trace["native_shuffle"][0]
        if len(order) != len(expanded) or set(order) != {x[0] for x in expanded}:
            raise ValueError("native shuffle is not a permutation of logical tuples")
        provider_order = [e["logical_id"] for e in trace["provider_events"]]
        if provider_order != order[:len(provider_order)]:
            raise ValueError("provider calls are not a native random prefix")
        if trace["cs_calls"] and any(Fraction.from_float(x["effective_alpha"]) > atom.alpha for x in trace["cs_calls"]):
            raise ValueError("native effective risk exceeds preassigned query budget")
        return result[0][-1]

    def exact_census(self, request: Request):
        query_id = "explicit_exact_census"
        ctx, model = self._context(query_id, request.seed, None, request.batch_size)
        schema = Schema((Field("logical_id", str), Field("rid", str), Field("text", str)), ("logical_id",))
        rows = [Row((f"c{i}", r.rid, r.text)) for i, r in enumerate(request.records)]
        p = f"FIXED_REF={self.cache.reference}; record {{rid}}, content {{text}}, tuple {{logical_id}}. Return the fixed binary predicate."
        df = ctx.read_rows(rows, schema).map(prompt(p, bool).alias("label"))
        result, trace = self._execute(df, model, query_id, None)
        if len(result) != len(rows):
            raise ValueError("native census incomplete")
        trace["coverage"] = "explicit_exact_census_fallback"
        return self.cache.exact_after_census(r.rid for r in request.records)

    def run(self, request: Request):
        if set(self.cache._public.items()) != {(r.rid, r.text) for r in request.records}:
            raise ValueError("request/cache public record mismatch")
        compiled = compile_request(request)
        start = self.cache.begin_request()
        self.query_traces = []
        answers = {}
        error = None
        if compiled.mode == "explicit_exact_census_fallback":
            try:
                labels = self.exact_census(request)
                decisions, top = exact_truth(request, labels)
            except Exception as exc:
                decisions = {name: None for name, _ in request.decisions}
                top = None if request.topk is None else {"status": "UNKNOWN", "selected": None, "boundary_tie": None}
                error = {"type": type(exc).__name__, "message": str(exc)}
        else:
            while needed := compiled.needed(answers):
                key = needed[0]
                try:
                    answers[key] = self.count_claim(request, compiled.atoms[key])
                except Exception as exc:
                    error = {"type": type(exc).__name__, "message": str(exc)}
                    break
            decisions = {name: node.resolve(answers) for name, node in compiled.decisions}
            top = compiled.topk_result(answers)
        complete = all(v is not None for v in decisions.values()) and (top is None or top["status"] in {"IDENTIFIED", "TIED"})
        eligible = complete and error is None and (top is None or top["status"] == "IDENTIFIED")
        status = "COMPLETE" if eligible else "TIED" if complete and error is None and top is not None and top["status"] == "TIED" else "UNKNOWN"
        return {"scope": "artificial", "status": status,
                "eligible_full_request_completion": eligible,
                "mode": compiled.mode, "decisions": decisions, "topk": top, "error": error,
                "potential_native_claim_count": len(compiled.atoms), "executed_native_claim_count": len(answers),
                "risk_budget": {"request_alpha": str(request.alpha), "assigned_sum": str(sum((a.alpha for a in compiled.atoms.values()), Fraction(0))),
                                "native_internal_fwer_preserved": True, "assumption": "upstream native CS coverage under each predeclared uniform random permutation"},
                "costs": self.cache.finish_request(start), "queries": self.query_traces,
                "real_workload_performance_established": False, "source_s_gate_assessed": False}
