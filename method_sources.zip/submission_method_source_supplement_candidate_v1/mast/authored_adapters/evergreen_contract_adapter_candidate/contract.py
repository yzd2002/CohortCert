"""Exact public contract compiler; no source, model, filesystem, or label access."""
from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from hashlib import sha256
from itertools import combinations
from math import floor, gcd, lcm
import json


def rat(value: int | str | Fraction | float) -> Fraction:
    # A float denotes its exact binary value, not its displayed decimal.
    if isinstance(value, bool):
        raise TypeError("boolean is not a rational coefficient")
    return Fraction(value)


@dataclass(frozen=True)
class Record:
    rid: str
    text: str

    def __post_init__(self):
        if not self.rid or any(c not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-" for c in self.rid):
            raise ValueError("record IDs must be nonempty public ASCII identifiers")
        if any(s in self.text for s in ["<rid>", "</rid>", "<logical_id>", "</logical_id>", "<field_values>", "</field_values>"]):
            raise ValueError("artificial record text contains reserved transport tags")


@dataclass(frozen=True)
class Linear:
    terms: tuple[tuple[str, Fraction], ...] = ()
    intercept: Fraction = Fraction(0)

    def __post_init__(self):
        merged = {}
        for rid, a in self.terms:
            merged[rid] = merged.get(rid, Fraction(0)) + rat(a)
        object.__setattr__(self, "terms", tuple(sorted((rid, a) for rid, a in merged.items() if a)))
        object.__setattr__(self, "intercept", rat(self.intercept))

    @classmethod
    def make(cls, terms: dict[str, int | str | Fraction | float], intercept=0):
        return cls(tuple(sorted((rid, rat(a)) for rid, a in terms.items() if rat(a))), rat(intercept))

    def shifted(self, amount):
        return Linear(self.terms, self.intercept + rat(amount))

    def negated(self):
        return Linear(tuple((rid, -a) for rid, a in self.terms), -self.intercept)

    def minus(self, other: Linear):
        terms = dict(self.terms)
        for rid, a in other.terms:
            terms[rid] = terms.get(rid, Fraction(0)) - a
        return Linear.make(terms, self.intercept - other.intercept)

    def exact(self, labels: dict[str, bool]) -> Fraction:
        return self.intercept + sum((a * int(labels[rid]) for rid, a in self.terms), Fraction(0))


@dataclass(frozen=True)
class Claim:
    op: str
    expression: Linear | None = None
    children: tuple[Claim, ...] = ()
    value: bool | None = None


def greater(score: Linear, threshold=0) -> Claim:
    return Claim("gt0", score.shifted(-rat(threshold)))


def strict_band(score: Linear, lower, upper) -> Claim:
    if rat(lower) >= rat(upper):
        raise ValueError("strict band needs lower < upper")
    return Claim("all", children=(greater(score, lower), greater(score.negated(), -rat(upper))))


def all_of(*claims: Claim) -> Claim:
    return Claim("all", children=tuple(claims))


def any_of(*claims: Claim) -> Claim:
    return Claim("any", children=tuple(claims))


def negate(claim: Claim) -> Claim:
    return Claim("not", children=(claim,))


@dataclass(frozen=True)
class TopK:
    scores: tuple[tuple[str, Linear], ...]
    k: int

    def __post_init__(self):
        if not 1 <= self.k <= len(self.scores):
            raise ValueError("k must be within score count")
        if len({name for name, _ in self.scores}) != len(self.scores):
            raise ValueError("duplicate score identifiers")


@dataclass(frozen=True)
class Request:
    records: tuple[Record, ...]
    decisions: tuple[tuple[str, Claim], ...]
    alpha: Fraction = Fraction(1, 20)
    topk: TopK | None = None
    expansion_limit: int = 10000
    batch_size: int = 8
    seed: int = 101
    scope: str = "artificial"

    def __post_init__(self):
        object.__setattr__(self, "alpha", rat(self.alpha))
        if self.scope != "artificial":
            raise ValueError("only artificial scope is authorized in this candidate")
        if not 0 < self.alpha < 1:
            raise ValueError("alpha must be within (0,1)")
        if not 0 < len(self.records) <= 10000:
            raise ValueError("artificial record size limit")
        if self.expansion_limit <= 0 or self.batch_size <= 0:
            raise ValueError("resource policy must be positive")
        if len({r.rid for r in self.records}) != len(self.records):
            raise ValueError("record IDs must be unique")
        if len({name for name, _ in self.decisions}) != len(self.decisions):
            raise ValueError("decision IDs must be unique")


@dataclass(frozen=True)
class Atom:
    key: str
    weights: tuple[tuple[str, int], ...]
    threshold: int
    population: int
    seed: int
    alpha: Fraction = Fraction(0)
    coverage: str = "signed_affine_relational_adapter"

    def expanded(self):
        if self.population > 100000:
            raise ValueError("expanded materialization safety limit")
        return tuple((f"v{i}_{copy}", rid, weight < 0) for i, (rid, weight) in enumerate(self.weights) for copy in range(abs(weight)))


@dataclass(frozen=True)
class Node:
    op: str
    key: str | None = None
    children: tuple[Node, ...] = ()
    value: bool | None = None

    def resolve(self, answers: dict[str, bool]) -> bool | None:
        if self.op == "literal":
            return self.value
        if self.op == "atom":
            return answers.get(self.key)
        values = [c.resolve(answers) for c in self.children]
        if self.op == "all":
            return False if False in values else True if all(v is True for v in values) else None
        if self.op == "any":
            return True if True in values else False if all(v is False for v in values) else None
        if self.op == "not":
            return None if values[0] is None else not values[0]
        raise ValueError("unknown Boolean operation")

    def needed(self, answers: dict[str, bool]) -> list[str]:
        if self.resolve(answers) is not None:
            return []
        if self.op == "atom":
            return [self.key]
        return list(dict.fromkeys(k for c in self.children for k in c.needed(answers)))


@dataclass
class Compiled:
    request: Request
    atoms: dict[str, Atom]
    decisions: tuple[tuple[str, Node], ...]
    top_pairs: dict[tuple[str, str], Node]
    mode: str

    def topk_result(self, answers: dict[str, bool]):
        topk = self.request.topk
        if topk is None:
            return None
        names = tuple(name for name, _ in topk.scores)
        if topk.k == len(names):
            return {"status": "IDENTIFIED", "selected": sorted(names), "boundary_tie": False}
        relation = {(a, b): node.resolve(answers) for (a, b), node in self.top_pairs.items()}
        for selected in combinations(names, topk.k):
            inside = set(selected)
            if all(relation[a, b] is True for a in inside for b in names if b not in inside):
                return {"status": "IDENTIFIED", "selected": sorted(inside), "boundary_tie": False}
        if any(v is None for v in relation.values()):
            return {"status": "UNKNOWN", "selected": None, "boundary_tie": None}
        # A strict weak ordering is required. Rare inconsistent certificates are
        # surfaced rather than resolved with an arbitrary deterministic tie break.
        for a in names:
            for b in names:
                if a != b and relation[a, b] and relation[b, a]:
                    return {"status": "INCONSISTENT", "selected": None, "boundary_tie": None}
        for a in names:
            for b in names:
                for c in names:
                    if len({a, b, c}) == 3 and relation[a, b] and relation[b, c] and not relation[a, c]:
                        return {"status": "INCONSISTENT", "selected": None, "boundary_tie": None}
                    if len({a, b, c}) == 3 and not relation[a, b] and not relation[b, a] and not relation[b, c] and not relation[c, b] and (relation[a, c] or relation[c, a]):
                        return {"status": "INCONSISTENT", "selected": None, "boundary_tie": None}
        ranks = {a: 1 + sum(relation[b, a] for b in names if a != b) for a in names}
        possible = [a for a in names if ranks[a] <= topk.k]
        if len(possible) > topk.k:
            return {"status": "TIED", "selected": None, "boundary_tie": True}
        return {"status": "INCONSISTENT", "selected": None, "boundary_tie": None}

    def needed(self, answers: dict[str, bool]):
        needed = [key for _, node in self.decisions for key in node.needed(answers)]
        top = self.topk_result(answers)
        if top is not None and top["status"] == "UNKNOWN":
            needed.extend(key for node in self.top_pairs.values() for key in node.needed(answers))
        return list(dict.fromkeys(needed))


def compile_request(request: Request) -> Compiled:
    allowed = {r.rid for r in request.records}
    atoms: dict[str, Atom] = {}

    def node_for(claim: Claim) -> Node:
        if claim.op == "gt0":
            expr = claim.expression
            if expr is None or len(dict(expr.terms)) != len(expr.terms):
                raise ValueError("invalid linear expression")
            if any(rid not in allowed for rid, _ in expr.terms):
                raise ValueError("unknown record in score")
            if not expr.terms:
                return Node("literal", value=expr.intercept > 0)
            denominator = lcm(*(a.denominator for _, a in expr.terms))
            ws = [(rid, int(a * denominator)) for rid, a in expr.terms]
            divisor = gcd(*(abs(w) for _, w in ws))
            ws = tuple((rid, w // divisor) for rid, w in ws if w)
            scale = Fraction(denominator, divisor)
            offset = sum(-w for _, w in ws if w < 0)
            threshold = floor(offset - scale * expr.intercept)
            population = sum(abs(w) for _, w in ws)
            if threshold < 0 or threshold >= population:
                return Node("literal", value=threshold < 0)
            payload = json.dumps([ws, threshold], separators=(",", ":"))
            key = sha256(payload.encode()).hexdigest()[:24]
            seed = int.from_bytes(sha256((str(request.seed) + ":" + key).encode()).digest()[:8], "big")
            coverage = "native_original_relation_count_subset" if all(w == 1 for _, w in ws) else "signed_affine_relational_adapter"
            atoms.setdefault(key, Atom(key, ws, threshold, population, seed, coverage=coverage))
            return Node("atom", key=key)
        if claim.op == "literal":
            if type(claim.value) is not bool:
                raise ValueError("literal must be Boolean")
            return Node("literal", value=claim.value)
        if claim.op not in {"all", "any", "not"} or (claim.op == "not" and len(claim.children) != 1):
            raise ValueError("invalid Boolean claim")
        return Node(claim.op, children=tuple(node_for(c) for c in claim.children))

    decisions = tuple((name, node_for(claim)) for name, claim in request.decisions)
    top_pairs = {}
    if request.topk is not None and request.topk.k < len(request.topk.scores):
        for a, score_a in request.topk.scores:
            for b, score_b in request.topk.scores:
                if a != b:
                    top_pairs[a, b] = node_for(greater(score_a.minus(score_b)))
    assigned = request.alpha / max(1, len(atoms))
    atoms = {k: Atom(a.key, a.weights, a.threshold, a.population, a.seed, assigned, a.coverage) for k, a in atoms.items()}
    mode = "native_multi_query_adapter" if all(a.population <= request.expansion_limit for a in atoms.values()) else "explicit_exact_census_fallback"
    return Compiled(request, atoms, decisions, top_pairs, mode)


def exact_truth(request: Request, labels: dict[str, bool]):
    """Artificial test oracle only; never called by public compilation."""
    def truth(c):
        if c.op == "gt0": return c.expression.exact(labels) > 0
        if c.op == "literal": return c.value
        if c.op == "all": return all(truth(x) for x in c.children)
        if c.op == "any": return any(truth(x) for x in c.children)
        if c.op == "not": return not truth(c.children[0])
        raise ValueError(c.op)
    decisions = {name: truth(c) for name, c in request.decisions}
    top = None
    if request.topk is not None:
        scores = sorted(((s.exact(labels), name) for name, s in request.topk.scores), reverse=True)
        k = request.topk.k
        tie = k < len(scores) and scores[k-1][0] == scores[k][0]
        top = {"status": "TIED" if tie else "IDENTIFIED", "selected": None if tie else sorted(name for _, name in scores[:k]), "boundary_tie": tie}
    return decisions, top
