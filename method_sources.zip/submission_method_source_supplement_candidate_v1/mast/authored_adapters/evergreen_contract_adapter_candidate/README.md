# Evergreen full-contract adapter candidate

**Scope: artificial data and a pure fixed mock predicate only. Strong real-workload baseline verification remains unfinished.** No actual Source data, loader, model, API key or API request is authorized or used. No paper, frozen experiment, arm, risk, quota or SourceS gate is changed.

Upstream is byte-bound to [brown-db/evergreen `41fd08fe74ce54db21701d03b15b3ce79fc13bba`](https://github.com/brown-db/evergreen/tree/41fd08fe74ce54db21701d03b15b3ce79fc13bba), 2026-08-26, corresponding primary paper [arXiv v2](https://arxiv.org/html/2604.26180v2), 2026-07-02. The repository snapshot is not claimed to be exactly the paper's original experiment release.

## What is implemented

| Route | Native behavior retained | Public wrapper / limitation |
|---|---|---|
| `NativeExactCanonicalBridge` | Unchanged native planner and complete grouped count execution; native shuffle, optimizer flags and cache-capable mock interface. | Public cohort membership expansion, shared fixed-reference physical cache, exact rational Boolean vector and strict top-k wrapper. Native completion is legitimate; cap exhaustion is UNKNOWN. |
| `CohortNativeIntervalAdapter` | Native per-cohort Shuffle/WOR physical input, native accumulator construction/update/risk allocation, unchanged finite-N betting CS. Fusion and batching remain enabled. | Explicit progressive prefix exposure and predeclared cohort schedule; shared intervals for all exact affine comparisons/bands/strict top-k. This is not unchanged canonical whole-query execution. Membership expansion is at most one tuple per RID per cohort; there is no LCM expansion. |
| `ExpandedControlBridge` | Native count-threshold query on a constructed relation. | LCM signed replication and exact-census fallback, retained only as an artificial existence/control route. It is not the main fair baseline. |

The precise native AST/early-stop boundary is documented in [NATIVE_CAPABILITY_PATHS.md](NATIVE_CAPABILITY_PATHS.md). Native terminal column-to-column comparison is supported. Its lack of an existing progressive hint is not evidence of an empirical advantage for CohortCert.

## Interface

`CohortRequest` contains public `Record`s, named cohort RID sets, exact rational `Linear` scores, Boolean `Claim`s and optional `TopK`. Terms in a cohort score refer to positive counts; a rate uses coefficient `Fraction(1, cohort_size)`. A difference `rate_A - rate_B - delta` is projected directly, without a large common-denominator relation. Strict bands are constructed with `strict_band(score, lower, upper)`.

`SharedLabelCache` binds a fixed predicate reference, RID and content digest. One cold cache serves every query in a request; it is not cleared per claim. Cross-request sharing must be declared as `cache_scope="shared_requests"`. Reports retain incremental and cumulative materialization charges. See [RISK_AND_COST_CONTRACT.md](RISK_AND_COST_CONTRACT.md) for the all-prefix risk argument, cache-side-information treatment and prefetch accounting.

Optional `support_mode="shared_vector_zero"` checks the **complete target vector** before labels are read and uses the same certified support for the native exact and progressive interfaces. Native population sizes become |G intersect support|, while all rate denominators remain the original cohort sizes. Default `native_full` stays separate. See [SUPPORT_COMPILER.md](SUPPORT_COMPILER.md). A certified top-k boundary tie has status TIED and does not count as a strict identification completion.

All execution entry points reject `scope != "artificial"`. The candidate does not contain an actual-source extraction bridge. The mock transport raises on optimizer-generated model requests or embedding access. Native source files are not patched, and no pickle input is used.

## Validation status

The final bounded scope passed **37 checks**: 21 contract/cache/projection checks and 16 real native integration checks, using actual pinned native modules and real numerical dependencies. They cover exact execution, progressive CS, strict boundaries/ties, cache/prefetch/budget accounting, common support and default grid outer readout. [ARTIFICIAL_VALIDATION.json](ARTIFICIAL_VALIDATION.json) and [ARTIFICIAL_NATIVE_RETURNS.json](ARTIFICIAL_NATIVE_RETURNS.json) preserve the results and native traces. Dependency checking also passes.

The first scope was **35/36 with one failure**, retained in [NATIVE_TEST_ATTEMPT_01.log](NATIVE_TEST_ATTEMPT_01.log). The constructed stacked-map fusion path triggered native KeyError; attribution remains UNKNOWN and upstream is unchanged. The final Filter→Map control establishes only that documented minimal fusion path, not stacked-map repair or full-optimizer coverage. See [FAILED_ATTEMPTS.md](FAILED_ATTEMPTS.md). Mathematical coverage relies on the native assumptions; machine-level kernel rounding certification remains UNKNOWN, as documented in [CONFSEQ_THEORY_AND_GRID.md](CONFSEQ_THEORY_AND_GRID.md).

Dependency installation is isolated in `.venv`. Failed public downloads remain in `DEPENDENCY_INSTALL_ATTEMPT_*` logs. Dependency and test commands use `nice -n 10`, with BLAS/OMP/MKL threads set to one. No long benchmark or real Source experiment is run.

After dependencies are available, the bounded artificial checks are:

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 nice -n 10 .venv/bin/python -m unittest -v test_contract test_native_integration
```

The `.venv`, transient wheels/ranges and bytecode are local runtime, excluded from the source/evidence manifest. Actual installed versions, verified wheel sources/hashes and imported native/kernel paths/hashes are separately bound. No reference-paper PDF is bundled. No actual workload speed, empirical coverage, economic crossing, fixed S gate or paper grade follows from these artificial checks.
