"""Contract/risk projection tests independent of optional native dependencies."""
from fractions import Fraction as F
from itertools import product
import unittest

from contract import Linear, greater, strict_band, TopK
from cohort_adapter import (linear_bounds, claim_value, topk_value,
                            normalize_public_contract, CohortRequest,
                            outward_native_count_domain, vector_support_certificate,
                            support_plan)
from artificial_fixtures import overlap_request, tied_request


class CohortProjectionTests(unittest.TestCase):
    def test_every_certified_sign_and_band_contains_all_integer_truths(self):
        checked = 0
        for a, b in product([F(-2, 3), F(0), F(5, 7)], repeat=2):
            score = Linear.make({"A": a, "B": b}, F(-1, 5))
            for domains in [{"A": (0, 4), "B": (1, 3)}, {"A": (2, 4), "B": (0, 1)}, {"A": (2, 2), "B": (3, 3)}]:
                lo, hi = linear_bounds(score, domains)
                for x in range(domains["A"][0], domains["A"][1]+1):
                    for y in range(domains["B"][0], domains["B"][1]+1):
                        truth = a*x+b*y-F(1, 5)
                        self.assertLessEqual(lo, truth)
                        self.assertGreaterEqual(hi, truth)
                        for claim, expected in [(greater(score), truth > 0), (strict_band(score, F(-1, 3), F(2, 3)), F(-1, 3) < truth < F(2, 3))]:
                            answer = claim_value(claim, domains)
                            if answer is not None: self.assertEqual(answer, expected)
                            checked += 1
        self.assertEqual(checked, 396)

    def test_overlap_exact_values_and_boundaries(self):
        request, _, expected = overlap_request()
        domains = {"A": (3, 3), "B": (2, 2), "C": (2, 2)}
        self.assertEqual({n: claim_value(c, domains) for n, c in request.decisions}, expected)
        self.assertEqual(topk_value(request.topk, domains)["selected"], ["C"])

    def test_topk_internal_and_boundary_ties(self):
        request, _ = tied_request(1)
        domains = {"A": (2, 2), "B": (2, 2), "C": (0, 0)}
        self.assertEqual(topk_value(request.topk, domains)["status"], "TIED")
        request, _ = tied_request(2)
        self.assertEqual(topk_value(request.topk, domains)["selected"], ["A", "B"])

    def test_shared_score_term_cancels_for_strict_topk(self):
        scores = TopK((("a", Linear.make({"A": 1, "Shared": 10})),
                       ("b", Linear.make({"B": 1, "Shared": 10}))), 1)
        domains = {"A": (4, 5), "B": (0, 2), "Shared": (0, 100)}
        self.assertEqual(topk_value(scores, domains)["selected"], ["a"])

    def test_identical_cohort_membership_shares_risk_stream_and_cancels(self):
        request, _, _ = overlap_request()
        from dataclasses import replace
        request = replace(request, cohorts=request.cohorts+(("AliasA", tuple(reversed(request.cohorts[0][1]))),),
                          decisions=(("same", greater(Linear.make({"A": 1, "AliasA": -1}))),), topk=None)
        decisions, top, streams, aliases = normalize_public_contract(request)
        self.assertEqual(aliases["AliasA"], "A")
        self.assertEqual(streams, ())
        self.assertFalse(claim_value(decisions[0][1], {}))

    def test_native_block_and_round_robin_are_predeclared_only(self):
        request, _, _ = overlap_request()
        from dataclasses import replace
        with self.assertRaises(ValueError): replace(request, schedule="pick_after_results")
        with self.assertRaises(ValueError): replace(request, scope="actual")

    def test_native_float_one_fifth_is_not_rounded_inward_to_two_positives(self):
        self.assertEqual(outward_native_count_domain(1/5, 1.0, 5, 1, 1, (0, 5)), (1, 5))

    def test_logical_fraction_boundaries_preserve_all_compatible_integer_counts(self):
        checked = 0
        for N in range(1, 16):
            for observed in range(1, N+1):
                for positives in range(observed+1):
                    lo, hi = outward_native_count_domain(positives/N, (positives+N-observed)/N,
                                                         N, positives, observed, (0, N))
                    self.assertLessEqual(lo, positives)
                    self.assertGreaterEqual(hi, positives+N-observed)
                    checked += 1
        self.assertEqual(checked, 800)

    def test_shared_support_cancellation_retains_original_denominators_and_beta(self):
        from dataclasses import replace
        request, labels, _ = overlap_request()
        request = replace(request, topk=None, support_mode="shared_vector_zero")
        certificate = vector_support_certificate(request)
        self.assertEqual(set(certificate["support_rids"]), {"toy_0","toy_1","toy_2","toy_6","toy_7","toy_8"})
        self.assertEqual(certificate["original_denominators"], {"A":6,"B":6,"C":3})
        self.assertTrue(all(not any(F(a) for a in coeffs) for coeffs in certificate["removed_row_target_coefficients"].values()))
        members, _ = support_plan(request)
        self.assertEqual({g:len(m) for g,m in members.items()}, {"A":3,"B":3,"C":0})
        for _, expression in [(t["id"], t) for t in certificate["targets"]]:
            # Same rational a_g multiplies the restricted count; never 1/Nsubset.
            if "A" in expression["count_coefficients"]:
                self.assertEqual(abs(F(expression["count_coefficients"]["A"])), F(1,6))
        for deleted_value in [False, True]:
            full = {**labels, **{rid:deleted_value for rid in certificate["removed_rids"]}}
            counts_full = {g:sum(full[r] for r in m) for g,m in request.cohorts}
            counts_restricted = {g:sum(full[r] for r in m) for g,m in members.items()}
            for _, c in request.decisions:
                self.assertEqual(claim_value(c,{g:(n,n) for g,n in counts_full.items()}),
                                 claim_value(c,{g:(n,n) for g,n in counts_restricted.items()}))

    def test_support_uses_all_targets_and_rejects_label_blind_but_wrong_deletion(self):
        from dataclasses import replace
        request, _, _ = overlap_request()
        # Top-k A versus C needs overlap records that cancel in A versus B alone.
        self.assertIn("toy_3", vector_support_certificate(request)["support_rids"])
        bad = replace(request, support_mode="shared_vector_zero", declared_support=("toy_0",))
        with self.assertRaises(ValueError): support_plan(bad)


if __name__ == "__main__": unittest.main()
