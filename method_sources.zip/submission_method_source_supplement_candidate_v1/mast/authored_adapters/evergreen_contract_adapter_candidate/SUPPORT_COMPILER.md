# Optional common zero-support compiler

Default `support_mode="native_full"` retains the original full-cohort relation. It is reported separately from `support_mode="shared_vector_zero"`. The latter is an explicit public compiler adapter that can hand the same verified support to either the native exact engine or the progressive cohort adapter. It does not alter the frozen SourceS study.

Let the original known cohort size be n_g and the original count be K_g = sum over r in G_g of y_r. For target j, write

\[
\theta_j=\beta_j+\sum_g c_{jg}K_g/n_g.
\]

The interface stores a_jg = c_jg/n_g as an exact rational coefficient multiplying a count. For every RID r, compilation computes the complete vector

\[
w_j(r)=\sum_g (c_{jg}/n_g)\,1\{r\in G_g\}.
\]

The shared support S includes every RID with at least one nonzero w_j(r). Every removed RID is checked against every target, not just the first claim or a favorable subset. Targets include all atomic inequalities in the Boolean vector and all pairwise score differences required for top-k. Top-k scores may change by a common removed offset, but their differences, strict boundaries and ties remain unchanged.

For all binary assignments, without inspecting any label,

\[
\theta_j=\beta_j+\sum_{r\in S}w_j(r)y_r
=\beta_j+\sum_g(c_{jg}/n_g)K_g^S,
\qquad K_g^S=\sum_{r\in G_g\cap S}y_r.
\]

Each native cohort query now samples **G_g intersect S**, uniformly WOR using its own native Shuffle and population M_g = |G_g intersect S|. Its CS targets K_g^S/M_g and is converted to a count domain for K_g^S. The final target still multiplies this count by c_jg/n_g. The denominator n_g and beta_j never shrink or change. An empty restricted cohort contributes an exactly known zero count without a statistical query.

Removed labels are not set to zero: their possibly nonzero contributions to individual original cohorts cancel only in the entire target expression. Consequently restricted count diagnostics are explicitly not original cohort counts. The optional compiler is valid for this Boolean/ordering contract, not a promise to report all original cohort means after discarding their labels.

`vector_support_certificate()` emits original memberships/sizes, original beta and rational coefficients, retained/removed IDs, and each removed RID's exact zero target-coefficient vector. A supplied `declared_support` must contain all nonzero-vector IDs; missing any one is rejected before requesting a label. A larger declared support is permitted and reported, enabling a common externally fixed support. The metadata hash binds the full target vector. This candidate computes and checks it only on artificial public relations; no Source loader is present.

The small artificial check uses two original size-6 cohorts overlapping on three records. Their rate difference has coefficients +1/6 and -1/6. Shared support leaves three records in each native population, but final coefficients remain +1/6 and -1/6, not +1/3 and -1/3. Deleted-label flips leave every requested truth unchanged. A second target/top-k contrast that needs an overlapping RID prevents that RID from being removed. No posterior-label support selection is allowed.
