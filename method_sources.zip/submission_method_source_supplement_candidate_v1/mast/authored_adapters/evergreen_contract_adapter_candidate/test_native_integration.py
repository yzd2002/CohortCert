from dataclasses import replace
from fractions import Fraction as F
import socket
import inspect
import unittest
from unittest.mock import patch

from contract import Claim, Linear, Record, TopK, greater
from mock_provider import SharedLabelCache
from artificial_fixtures import overlap_request, tied_request
from canonical_bridge import NativeExactCanonicalBridge
from cohort_adapter import CohortNativeIntervalAdapter, CohortRequest
from native_bridge import ExpandedControlBridge, conservative_confidence
from evergreen import col, count_if, prompt, proportion
from evergreen.catalog.schema import Field, Schema
from evergreen.planner.logical.optimizer import PushDownEarlyStopComparison
from evergreen.storage.row import Row
from confseq.betting import betting_cs, cs_from_martingale


REF = "artificial_fixed_predicate_v1"


class NativeIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.network_guard = patch.object(socket.socket, "connect", side_effect=AssertionError("no network/API is authorized"))
        cls.network_guard.start()

    @classmethod
    def tearDownClass(cls):
        cls.network_guard.stop()

    def provider(self, request, labels, **kwargs):
        return SharedLabelCache(REF, request.records, lambda rid, _: labels[rid], **kwargs)

    def test_native_ast_support_and_precise_early_stop_boundary(self):
        with self.assertRaises(TypeError): _ = col("a") + 0.1
        direct = col("a") > col("b")
        self.assertEqual(PushDownEarlyStopComparison._extract_comparison(direct), [])
        literal = PushDownEarlyStopComparison._extract_comparison(col("a") > 0.1)
        self.assertEqual(len(literal), 1)
        self.assertEqual(literal[0].threshold, 0.1)

    def test_native_terminal_column_to_column_query_is_legitimate(self):
        request, labels, _ = overlap_request()
        cache = self.provider(request, labels)
        bridge = ExpandedControlBridge(cache)
        start = cache.begin_request()
        ctx, model = bridge._context("canonical_col_col", 9, F(1, 20), 4)
        schema = Schema((Field("logical_id", str), Field("rid", str), Field("text", str),
                         Field("a", bool), Field("b", bool)), ("logical_id",))
        rows = [Row((f"v{i}", r.rid, r.text, i < 6, 3 <= i < 9)) for i, r in enumerate(request.records)]
        p = f"FIXED_REF={REF}; {{rid}} {{text}} {{logical_id}}"
        df = (ctx.read_rows(rows, schema).map(prompt(p, bool).alias("label"))
              .aggregate([count_if(col("label") & col("a")).alias("na"),
                          count_if(col("label") & col("b")).alias("nb")])
              .check(col("na") > col("nb")))
        output, trace = bridge._execute(df, model, "canonical_col_col", F(1, 20))
        self.assertTrue(output[0][-1])  # counts 3 versus 2, equal cohort denominators
        self.assertTrue(all(a["statistical_observations"] == 12 for a in trace["native_accumulators"]))
        self.assertEqual(trace["cs_calls"], [])
        report = cache.finish_request(start)
        self.assertEqual(report["this_request"]["physical_label_attempts"], 12)

    def test_canonical_exact_completes_full_strict_contract(self):
        request, labels, expected = overlap_request()
        result = NativeExactCanonicalBridge(self.provider(request, labels)).run(request)
        self.assertEqual(result["status"], "COMPLETE", result)
        self.assertEqual(result["decisions"], expected)
        self.assertEqual(result["exact_counts"], {"A": 3, "B": 2, "C": 2})
        self.assertEqual(result["topk"], {"status": "IDENTIFIED", "selected": ["C"], "boundary_tie": False})
        self.assertTrue(result["canonical_aggregate_execution"])
        self.assertEqual(result["costs"]["this_request"]["physical_label_attempts"], 12)
        self.assertEqual(result["costs"]["this_request"]["logical_predicate_evaluations"], 15)
        self.assertEqual(result["costs"]["this_request"]["cache_hits"], 3)

    def test_progressive_overlap_full_vector_and_exact_boundaries(self):
        request, labels, expected = overlap_request()
        result = CohortNativeIntervalAdapter(self.provider(request, labels)).run(request)
        self.assertEqual(result["status"], "COMPLETE", result)
        self.assertEqual(result["decisions"], expected)
        self.assertEqual(result["topk"]["selected"], ["C"])
        self.assertFalse(result["canonical_whole_query_execution"])
        self.assertEqual(result["membership_rows"], 15)
        self.assertLessEqual(F(result["risk_budget"]["actual_native_alpha_sum_exact"]),request.alpha)
        self.assertEqual(result["costs"]["this_request"]["physical_label_attempts"], 12)
        self.assertTrue(any(s["native_ci"] is not None for c in result["cohort_traces"] for s in c["snapshots"]))
        for c in result["cohort_traces"]:
            self.assertIn("Shuffle", c["native_plan_types"])
            self.assertTrue(all(F.from_float(s["effective_alpha"]) <= F(1, 60) for s in c["snapshots"]))

    def test_progressive_native_block_policy_same_truth(self):
        request, labels, expected = overlap_request()
        request = replace(request, schedule="native_block")
        result = CohortNativeIntervalAdapter(self.provider(request, labels)).run(request)
        self.assertEqual(result["status"], "COMPLETE", result)
        self.assertEqual(result["decisions"], expected)

    def test_shared_support_native_sampling_N_shrinks_but_rate_denominator_does_not(self):
        request, labels, expected = overlap_request()
        request = replace(request, topk=None, support_mode="shared_vector_zero")
        support = {"toy_0","toy_1","toy_2","toy_6","toy_7","toy_8"}
        def predicate(rid, _):
            self.assertIn(rid,support)
            return labels[rid]
        result = CohortNativeIntervalAdapter(SharedLabelCache(REF,request.records,predicate)).run(request)
        self.assertEqual(result["status"], "COMPLETE", result)
        self.assertEqual(result["decisions"],expected)
        self.assertEqual(result["membership_rows"],6)
        for trace in result["cohort_traces"]:
            self.assertEqual(trace["population_size"],3)
            self.assertEqual(trace["original_full_cohort_size"],6)
            self.assertEqual(trace["count_target"],"G intersect shared support")
        canonical = NativeExactCanonicalBridge(SharedLabelCache(REF,request.records,predicate)).run(request)
        self.assertEqual(canonical["status"],"COMPLETE",canonical)
        self.assertEqual(canonical["decisions"],expected)
        self.assertFalse(canonical["canonical_same_original_cohort_relation"])
        self.assertEqual(canonical["exact_component_counts"],{"A":2,"B":1})

    def test_strict_topk_boundary_ties_are_not_broken(self):
        request, labels = tied_request(1)
        result = CohortNativeIntervalAdapter(self.provider(request, labels)).run(request)
        self.assertEqual(result["status"], "TIED", result)
        self.assertTrue(result["truth_contract_resolved"])
        self.assertFalse(result["eligible_full_request_completion"])
        self.assertFalse(result["strict_identification_achieved"])
        self.assertEqual(result["topk"], {"status": "TIED", "selected": None, "boundary_tie": True})

    def test_topk_internal_tie_does_not_prevent_strict_boundary(self):
        request, labels = tied_request(2)
        result = CohortNativeIntervalAdapter(self.provider(request, labels)).run(request)
        self.assertEqual(result["status"], "COMPLETE", result)
        self.assertEqual(result["topk"], {"status": "IDENTIFIED", "selected": ["A", "B"], "boundary_tie": False})

    def test_identical_cohort_alias_and_common_offset_need_no_labels(self):
        records = (Record("same_0", "Artificial zero"), Record("same_1", "Artificial one"))
        a, b = Linear.make({"A": F(1, 2)}), Linear.make({"AliasA": F(1, 2)})
        request = CohortRequest(records, (("A", ("same_0", "same_1")), ("AliasA", ("same_1", "same_0"))),
                                (("strict_diff", greater(a.minus(b))),), topk=TopK((("a", a), ("b", b)), 1))
        result = CohortNativeIntervalAdapter(SharedLabelCache(REF, records, lambda *_: self.fail("no label should be requested"))).run(request)
        self.assertEqual(result["status"], "TIED", result)
        self.assertEqual(result["decisions"], {"strict_diff": False})
        self.assertEqual(result["topk"]["status"], "TIED")
        self.assertEqual(result["costs"]["this_request"]["physical_label_attempts"], 0)
        self.assertEqual(result["risk_budget"]["assigned_sum"], "0")

    def test_shared_cache_second_request_cost_and_prefix_are_separate(self):
        request, labels, expected = overlap_request()
        cache = self.provider(request, labels, cache_scope="shared_requests")
        first = NativeExactCanonicalBridge(cache).run(request)
        second = CohortNativeIntervalAdapter(cache).run(request)
        self.assertEqual(first["status"], "COMPLETE", first)
        self.assertEqual(second["status"], "COMPLETE", second)
        self.assertEqual(second["decisions"], expected)
        self.assertEqual(second["costs"]["labels_known_at_entry"], 12)
        self.assertEqual(second["costs"]["this_request"]["physical_label_attempts"], 0)
        self.assertEqual(second["costs"]["cumulative_including_prior_materialization"]["physical_label_attempts"], 12)
        self.assertEqual(sum(c["statistical_observations"] for c in second["cohort_traces"]), 0)
        self.assertEqual(second["costs"]["this_request"]["logical_predicate_evaluations"], 0)

    def test_canonical_budget_exhaustion_is_unknown_and_prefix_cost_retained(self):
        request, labels, _ = overlap_request()
        result = NativeExactCanonicalBridge(self.provider(request, labels, label_attempt_limit=4)).run(request)
        self.assertEqual(result["status"], "UNKNOWN", result)
        self.assertTrue(all(v is None for v in result["decisions"].values()))
        self.assertEqual(result["costs"]["this_request"]["physical_label_attempts"], 4)
        self.assertEqual(result["error"]["type"], "MockLabelBudgetExhausted")

    def test_progressive_budget_exhaustion_is_unknown(self):
        request, labels, _ = overlap_request()
        result = CohortNativeIntervalAdapter(self.provider(request, labels, label_attempt_limit=4)).run(request)
        self.assertEqual(result["status"], "UNKNOWN", result)
        self.assertEqual(result["costs"]["this_request"]["physical_label_attempts"], 4)

    def test_native_cs_path_and_prefetch_cost(self):
        records = tuple(Record(f"pos_{i}", f"Artificial positive {i}") for i in range(80))
        request = CohortRequest(records, (("A", tuple(r.rid for r in records)),),
                                (("above_half", greater(Linear.make({"A": F(1, 80)}), F(1, 2))),),
                                batch_size=8, monitor_every=3, seed=21)
        result = CohortNativeIntervalAdapter(SharedLabelCache(REF, records, lambda *_: True)).run(request)
        self.assertEqual(result["status"], "COMPLETE", result)
        self.assertTrue(result["decisions"]["above_half"])
        c = result["cohort_traces"][0]
        self.assertTrue(any(s["native_ci"] is not None for s in c["snapshots"]))
        self.assertLess(c["statistical_observations"], 80)
        self.assertGreaterEqual(c["prefetched_logical_labels"], c["statistical_observations"])
        self.assertEqual(result["costs"]["this_request"]["physical_label_attempts"], c["prefetched_logical_labels"])

    def test_native_fusion_executes_without_extra_physical_labels(self):
        request, labels, _ = overlap_request()
        cache = self.provider(request, labels)
        bridge = ExpandedControlBridge(cache)
        start = cache.begin_request()
        ctx, model = bridge._context("native_fusion", 9, F(1, 20), 4)
        schema = Schema((Field("logical_id", str), Field("rid", str), Field("text", str)), ("logical_id",))
        rows = [Row((f"f{i}", r.rid, r.text)) for i, r in enumerate(request.records)]
        p = f"FIXED_REF={REF}; {{rid}} {{text}} {{logical_id}}"
        # Use the paper's supported semantic Filter -> Map fusion pattern. The
        # constructed stacked-Map probe triggered a native KeyError; its full
        # schema/API preconditions and attribution remain unadjudicated. That
        # failure remains in NATIVE_TEST_ATTEMPT_01.log, not silently fixed.
        df = (ctx.read_rows(rows, schema).filter(prompt(p, bool))
              .map(prompt(p, bool).alias("label"))
              .aggregate([count_if(col("label")).alias("n")])
              .check(col("n").eq(6)))
        output, trace = bridge._execute(df, model, "native_fusion", F(1, 20))
        self.assertTrue(output[0][-1])
        self.assertIn("FusedFilterProjection", trace["native_plan_types"])
        self.assertGreater(trace["fused_invocations"], 0)
        self.assertEqual(cache.finish_request(start)["this_request"]["physical_label_attempts"], 12)

    def test_actual_confseq_default_grid_outer_readout_and_between_grid_count(self):
        import numpy as np
        signature = inspect.signature(betting_cs)
        self.assertFalse(signature.parameters["convex_comb"].default)
        self.assertFalse(signature.parameters["parallel"].default)
        lower, upper = betting_cs([True,False],alpha=.05,N=3,breaks=100)
        self.assertLessEqual(lower[-1],1/3)
        self.assertGreaterEqual(upper[-1],1/3)
        # The active inversion routine itself must expand beyond accepted grid
        # endpoints. This is an artificial interval-shaped function, not a claim
        # that it is a statistical martingale.
        fn = lambda x,m: np.repeat(1.0 if .203 <= m <= .247 else 100.0,len(x))
        lo, hi = cs_from_martingale([0],fn,breaks=100,alpha=.05)
        self.assertLessEqual(lo[-1],.203)
        self.assertGreaterEqual(hi[-1],.247)
        empty = lambda x,m: np.repeat(1.0 if .203 <= m <= .207 else 100.0,len(x))
        lo, hi = cs_from_martingale([0],empty,breaks=100,alpha=.05)
        self.assertEqual((lo[-1],hi[-1]),(0.0,1.0))

    def test_confidence_parameter_is_conservative(self):
        for alpha in [F(1, 20), F(1, 60), F(1, 1000)]:
            self.assertLessEqual(F.from_float(1-conservative_confidence(alpha)), alpha)


if __name__ == "__main__": unittest.main()
