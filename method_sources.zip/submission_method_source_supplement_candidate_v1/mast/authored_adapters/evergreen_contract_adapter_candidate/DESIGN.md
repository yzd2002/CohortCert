# Evergreen contract adapter candidate: design boundary

Status: implementation candidate, artificial data and mock predicate only. No actual Source inputs, source loaders, outcomes, ledgers, models or paid APIs are in scope. No SourceS arm, quota or gate changes.

**Primary-design correction:** see `NATIVE_CAPABILITY_PATHS.md`. The main routes are now (1) unchanged native exact aggregate execution with a strict output wrapper, and (2) the named progressive `CohortNativeIntervalAdapter`, with only public cohort-membership expansion. The signed-LCM expansion below is retained as an existence/control route, not the main fair comparator. Its fallback does not establish a sufficiently strong baseline.

Pinned upstream: `brown-db/evergreen` commit `41fd08fe74ce54db21701d03b15b3ce79fc13bba` (2026-08-26), paper arXiv `2604.26180v2` (2026-07-02). Upstream code will be copied byte-for-byte, not edited. Imported modules, dependencies and any failures will be recorded here.

## Interfaces

1. `PredicateReference`: fixed reference identifier plus record ID and content digest. A shared cache calls a pure mock predicate only on a miss. Every query records its own statistical observation, but only actual cache misses incur a physical label charge. A cache hit cannot be inserted ahead of that query's native random prefix. Repeated logical tuples are distinct statistical positions, never independent new physical labels.
2. `RequestSpec`: public records, exact rational linear scores, Boolean claim DAG, optional strict top-k output, request alpha and predeclared resource policy. No labels are exposed to compilation or planning.
3. `CompiledRequest`: finite set of native claims, deterministic query seeds, simultaneous risk budget and coverage labels. Equivalent subclaims are shared. Every potential claim receives risk before labels are inspected; dependencies may skip claims whose answers are no longer needed.
4. `NativeEvergreenBridge`: invokes the unchanged native query planner/executor with its shuffle/WOR CS, internal risk allocation and optimizations. Mock language-model injection changes only the source of a fixed predicate's answer. No CohortCert cell allocator, statistical kernel or count-dual optimizer is inserted.
5. `RequestResult`: complete Boolean decision vector when certified, strict top-k status/set with explicit boundary ties, query/observation/cost traces and native-versus-adapter coverage. Unsupported, failed or unfinished work is UNKNOWN, never a losing verdict for the baseline.

## Native claims versus public adapter

- Native count/proportion threshold claims use the original map/aggregate/check execution path. Strict count thresholds use exact integer normalization; native relative-error equality is not used for a strict band.
- A strict band is a Boolean conjunction of its two original strict inequalities. Pairwise comparison and strict top-k are compiled from exact score differences. Dense-rank tie breaking is not substituted for strict identification.
- The native expression API has no general rational affine arithmetic. A proposed exact relational adapter converts a signed rational contrast into one unweighted binary count by a common integer scale, public logical replication and complementing negative terms. The unchanged native engine shuffles the expanded relation WOR and runs its own count CS. Physical record labels remain shared through the fixed-reference cache. Expansion size and all repeated statistical observations are reported; this is an **adapter**, not a native claim on the original relation.
- If static expansion exceeds a predeclared limit, an explicitly named exact-census adapter can obtain original-record labels through the native pipeline and evaluate rational claims exactly. It provides contract completion without a new statistical kernel, but cannot be advertised as native early-stop support. Whether this fallback can actually execute without API access will be tested.

## Risk and random-prefix argument

Every potential native query q is assigned alpha_q with sum alpha_q <= request alpha. Its native internal FWER budget is alpha_q. Each query's random seed/order is fixed independently of labels before execution. On the intersection of all native query coverage events, all adapter Boolean operations and exact rational transforms are correct. Union bounding needs no independence between queries or overlapping groups. Shared caching changes physical cost, not the predeclared tuple order or observations included in any query's prefix. Choosing the next already-budgeted query from previous certified answers is allowed; unseen cached values are not consulted for planning or tuple ordering.

The minimum validation must inspect native plans and observations, rather than merely test a separate reimplementation. It must cover strict boundaries/equality, negative coefficients, overlaps, repeated tuples, strict top-k boundary ties, shared cache charges and nonzero-alpha native CS execution. Artificial tests cannot establish empirical coverage or real-workload speed.
