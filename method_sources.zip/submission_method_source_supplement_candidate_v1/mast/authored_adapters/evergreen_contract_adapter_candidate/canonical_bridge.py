"""Unchanged native whole-query aggregate execution plus exact output wrapper."""
from __future__ import annotations

from fractions import Fraction

from cohort_adapter import (CohortRequest, claim_value, topk_value,
                            normalize_public_contract, support_plan)
from native_bridge import ExpandedControlBridge
from evergreen import col, count_if, prompt
from evergreen.catalog.schema import Field, Schema
from evergreen.storage.row import Row


class NativeExactCanonicalBridge:
    """Native grouped aggregates are exact without downstream literal hints.

    The Boolean vector/strict top-k result is explicitly an exact output wrapper.
    Native terminal results and cap-exhausted UNKNOWN are both retained.
    """
    def __init__(self, cache):
        self.cache = cache

    def run(self, request: CohortRequest):
        if self.cache._public != {r.rid: r.text for r in request.records}:
            raise ValueError("public record/cache binding mismatch")
        members, support_info = support_plan(request)
        normalized_decisions, normalized_topk, streams, aliases = normalize_public_contract(request, members)
        start = self.cache.begin_request()
        bridge = ExpandedControlBridge(self.cache)
        query_id = "native_exact_group_aggregate"
        ctx, model = bridge._context(query_id, request.seed, request.alpha, request.batch_size)
        schema = Schema((Field("logical_id", str), Field("rid", str), Field("text", str), Field("cohort", str)), ("logical_id",))
        public = {r.rid: r.text for r in request.records}
        rows = [Row((f"g{i}_{j}", rid, public[rid], name))
                for i, (name, stream_members) in enumerate(streams) for j, rid in enumerate(stream_members)]
        p = f"FIXED_REF={self.cache.reference}; record {{rid}}, content {{text}}, tuple {{logical_id}}. Return the fixed binary predicate."
        df = (ctx.read_rows(rows, schema).map(prompt(p, bool).alias("label"))
              .aggregate([count_if(col("label")).alias("count")], group_by=[col("cohort")]))
        counts = {}
        error = None
        initial_domains = {name:(0,len(stream_members)) for name,stream_members in streams}
        decisions = {name:claim_value(c,initial_domains) for name,c in normalized_decisions}
        top = topk_value(normalized_topk,initial_domains)
        try:
            if not (all(v is not None for v in decisions.values()) and (top is None or top["status"] in {"IDENTIFIED","TIED"})):
                output, trace = bridge._execute(df, model, query_id, request.alpha)
                result_schema = df.schema()
                for row in output:
                    name = row[result_schema.index_of("cohort")]
                    count = row[result_schema.index_of("count")]
                    if type(count) is not int:
                        raise ValueError("canonical group without literal hint did not emit exact integer count")
                    counts[name] = count
                if set(counts) != {n for n, _ in streams}:
                    raise ValueError("canonical group result incomplete")
            domains = {n: (count, count) for n, count in counts.items()}
            if counts:
                decisions = {n: claim_value(c, domains) for n, c in normalized_decisions}
                top = topk_value(normalized_topk, domains)
        except Exception as exc:
            error = {"type": type(exc).__name__, "message": str(exc)}
        complete = all(v is not None for v in decisions.values()) and (top is None or top["status"] in {"IDENTIFIED", "TIED"})
        eligible = complete and error is None and (top is None or top["status"] == "IDENTIFIED")
        status = "COMPLETE" if eligible else "TIED" if complete and error is None and top is not None and top["status"] == "TIED" else "UNKNOWN"
        return {"scope": "artificial", "status": status,
                "decision_vector_complete": all(v is not None for v in decisions.values()),
                "truth_contract_resolved": complete and error is None,
                "strict_identification_achieved": None if top is None or top["status"] == "UNKNOWN" else top["status"] == "IDENTIFIED",
                "eligible_full_request_completion": eligible,
                "mode": "native_exact_canonical_aggregates_with_strict_output_wrapper" if request.support_mode == "native_full" else "native_exact_aggregates_shared_support_compiler_adapter",
                "canonical_aggregate_execution": True, "output_contract_wrapper": True,
                "canonical_same_original_cohort_relation": request.support_mode == "native_full",
                "native_kernel_unchanged": True, "decisions": decisions, "topk": top,
                "exact_counts": counts if request.support_mode == "native_full" else None,
                "exact_component_counts": counts, "error": error,
                "support_compiler": support_info, "cohort_aliases": aliases,
                "membership_rows": len(rows), "queries": bridge.query_traces,
                "costs": self.cache.finish_request(start),
                "real_workload_performance_established": False, "source_s_gate_assessed": False}
