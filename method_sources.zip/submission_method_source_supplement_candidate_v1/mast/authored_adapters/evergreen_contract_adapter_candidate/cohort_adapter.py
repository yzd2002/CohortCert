"""Progressive cohort wrapper using unchanged native physical input/accumulators.

This is an adapter, not a canonical unchanged StreamAggregate.next() executor.
It exposes prefix intervals rather than waiting for an entire aggregate to emit.
"""
from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from itertools import combinations
from math import ceil, floor, isfinite, nextafter, inf
from hashlib import sha256
import json

from contract import Claim, Linear, Record, TopK, rat
from mock_provider import SharedLabelCache


@dataclass(frozen=True)
class CohortRequest:
    records: tuple[Record, ...]
    cohorts: tuple[tuple[str, tuple[str, ...]], ...]
    # Linear terms refer to cohort positive COUNTS, not physical record IDs.
    # A rate is represented exactly by coefficient 1 / public cohort size.
    decisions: tuple[tuple[str, Claim], ...]
    alpha: Fraction = Fraction(1, 20)
    topk: TopK | None = None
    batch_size: int = 8
    monitor_every: int = 8
    schedule: str = "round_robin"
    seed: int = 101
    scope: str = "artificial"
    support_mode: str = "native_full"
    declared_support: tuple[str, ...] | None = None

    def __post_init__(self):
        object.__setattr__(self, "alpha", rat(self.alpha))
        if self.scope != "artificial":
            raise ValueError("actual-source execution is not authorized")
        if not 0 < self.alpha < 1 or self.batch_size <= 0 or self.monitor_every <= 0:
            raise ValueError("invalid risk/batch specification")
        if self.schedule not in {"round_robin", "native_block"}:
            raise ValueError("undeclared cohort schedule")
        if self.support_mode not in {"native_full", "shared_vector_zero"}:
            raise ValueError("unknown public support compiler mode")
        if self.support_mode == "native_full" and self.declared_support is not None:
            raise ValueError("declared support requires the explicit compiler adapter mode")
        ids = {r.rid for r in self.records}
        if not self.records or len(ids) != len(self.records) or len(ids) > 10000:
            raise ValueError("invalid artificial record set")
        names = {name for name, _ in self.cohorts}
        if not self.cohorts or len(names) != len(self.cohorts):
            raise ValueError("duplicate/empty cohort list")
        if any(not members or len(set(members)) != len(members) or not set(members) <= ids for _, members in self.cohorts):
            raise ValueError("cohorts must be nonempty public RID subsets without duplicates")
        if sum(len(m) for _, m in self.cohorts) > 100000:
            raise ValueError("artificial membership size limit")
        if len({n for n, _ in self.decisions}) != len(self.decisions):
            raise ValueError("duplicate decision names")
        def validate(c):
            if c.op == "gt0":
                if c.expression is None or any(g not in names for g, _ in c.expression.terms):
                    raise ValueError("unknown cohort in score")
            elif c.op == "literal":
                if type(c.value) is not bool: raise ValueError("invalid Boolean literal")
            elif c.op in {"all", "any", "not"}:
                if c.op == "not" and len(c.children) != 1: raise ValueError("invalid not")
                for ch in c.children: validate(ch)
            else: raise ValueError("unknown claim operation")
        for _, c in self.decisions: validate(c)
        if self.topk:
            for _, s in self.topk.scores:
                if any(g not in names for g, _ in s.terms): raise ValueError("unknown top-k cohort")


def linear_bounds(expr: Linear, domains: dict[str, tuple[int, int]]):
    lo = hi = expr.intercept
    for name, a in expr.terms:
        left, right = domains[name]
        lo += a * (left if a >= 0 else right)
        hi += a * (right if a >= 0 else left)
    return lo, hi


def claim_value(claim: Claim, domains):
    if claim.op == "gt0":
        lo, hi = linear_bounds(claim.expression, domains)
        return True if lo > 0 else False if hi <= 0 else None
    if claim.op == "literal": return claim.value
    vals = [claim_value(c, domains) for c in claim.children]
    if claim.op == "not": return None if vals[0] is None else not vals[0]
    if claim.op == "all": return False if False in vals else True if all(v is True for v in vals) else None
    if claim.op == "any": return True if True in vals else False if all(v is False for v in vals) else None
    raise ValueError("invalid claim")


def outward_native_count_domain(lower, upper, N, positives, observed, previous):
    """Conservative readout of native float mean endpoints on an integer target.

    In particular float(1/5) lies above the rational 1/5. Blindly converting that
    value to Fraction and taking ceil(N*lower) would incorrectly produce 2.
    One-ULP outward endpoint rounding avoids an inward conversion at this API
    boundary. It does not recertify floating-point work inside upstream's kernel.
    """
    if not isfinite(lower) or not isfinite(upper):
        raise ValueError("nonfinite native interval")
    lower_fraction = Fraction.from_float(nextafter(float(lower), -inf))
    upper_fraction = Fraction.from_float(nextafter(float(upper), inf))
    lo = max(positives, previous[0], ceil(lower_fraction * N))
    hi = min(positives+N-observed, previous[1], floor(upper_fraction * N))
    if lo > hi: raise ValueError("native count confidence domain became empty")
    return lo, hi


def topk_value(spec: TopK | None, domains):
    if spec is None: return None
    expressions = dict(spec.scores)
    names = tuple(expressions)
    if spec.k == len(names):
        return {"status": "IDENTIFIED", "selected": sorted(names), "boundary_tie": False}
    differences = {(a, b): linear_bounds(expressions[a].minus(expressions[b]), domains)
                   for a in names for b in names if a != b}
    for chosen in combinations(names, spec.k):
        selected = set(chosen)
        if all(differences[a, b][0] > 0 for a in selected for b in names if b not in selected):
            return {"status": "IDENTIFIED", "selected": sorted(selected), "boundary_tie": False}
    if all(lo > 0 or hi < 0 or lo == hi == 0 for lo, hi in differences.values()):
        ranks = {a: 1 + sum(differences[b, a][0] > 0 for b in names if a != b) for a in names}
        if len([a for a in names if ranks[a] <= spec.k]) > spec.k:
            return {"status": "TIED", "selected": None, "boundary_tie": True}
    return {"status": "UNKNOWN", "selected": None, "boundary_tie": None}


def vector_support_certificate(request):
    """Certify the SAME label-blind support for the entire contrast vector.

    Linear terms already multiply counts. Rate coefficients therefore retain
    their original 1/n_g factors; the native sampling N may subsequently shrink.
    """
    memberships = {g: set(m) for g, m in request.cohorts}
    targets = []
    def visit(c, name):
        if c.op == "gt0": targets.append((name, c.expression))
        for i, ch in enumerate(c.children): visit(ch, name+"/"+str(i))
    for name, claim in request.decisions: visit(claim, "decision:"+name)
    if request.topk:
        for a, sa in request.topk.scores:
            for b, sb in request.topk.scores:
                if a != b: targets.append(("topk:"+a+">"+b, sa.minus(sb)))
    ids = [r.rid for r in request.records]
    row_coefficients = {rid: tuple(sum((a for g, a in expression.terms if rid in memberships[g]), Fraction(0))
                                  for _, expression in targets) for rid in ids}
    minimal = {rid for rid, values in row_coefficients.items() if any(values)}
    if request.declared_support is None:
        support = minimal
    else:
        support = set(request.declared_support)
        if len(support) != len(request.declared_support) or not support <= set(ids):
            raise ValueError("declared support has duplicate or unknown record IDs")
        if not minimal <= support:
            raise ValueError("support deletes a nonzero coefficient in the complete target vector")
    removed = [rid for rid in ids if rid not in support]
    if any(any(row_coefficients[rid]) for rid in removed):
        raise ValueError("incomplete zero-support proof")
    payload = {"schema":"complete_public_vector_support_v1",
               "original_cohorts":{g:list(m) for g,m in request.cohorts},
               "original_denominators":{g:len(m) for g,m in request.cohorts},
               "targets":[{"id":name,"beta":str(e.intercept),
                            "count_coefficients":{g:str(a) for g,a in e.terms},
                            "rate_coefficients":{g:str(a*len(memberships[g])) for g,a in e.terms}}
                           for name,e in targets],
               "support_rids":[rid for rid in ids if rid in support],
               "removed_rids":removed,
               "removed_row_target_coefficients":{rid:[str(a) for a in row_coefficients[rid]] for rid in removed},
               "beta_unchanged":True,"original_rate_denominators_unchanged":True,
               "labels_read":False}
    payload["metadata_sha256"] = sha256(json.dumps(payload,sort_keys=True,separators=(",",":")).encode()).hexdigest()
    return payload


def support_plan(request):
    if request.support_mode == "native_full":
        return dict(request.cohorts), {"mode":"native_full","shared_zero_support_applied":False,
            "original_denominators":{g:len(m) for g,m in request.cohorts},
            "note":"native full-cohort cost is distinct from a support-filtered comparator"}
    certificate = vector_support_certificate(request)
    support = set(certificate["support_rids"])
    members = {g:tuple(rid for rid in m if rid in support) for g,m in request.cohorts}
    return members, {"mode":"shared_vector_zero","shared_zero_support_applied":True,
                     "certificate":certificate,"native_sampling_population_sizes":{g:len(m) for g,m in members.items()},
                     "count_target":"positives in G intersect support; not original full-cohort count"}


def normalize_public_contract(request, members_override=None):
    """Share identical cohort streams and cancel common score terms publicly."""
    representatives = {}
    aliases = {}
    members_by_name = dict(request.cohorts) if members_override is None else members_override
    for name, _ in request.cohorts:
        members = members_by_name[name]
        key = tuple(sorted(members))
        aliases[name] = representatives.setdefault(key, name)
    def expression(expr):
        return Linear(tuple((aliases[g], a) for g, a in expr.terms if members_by_name[g]), expr.intercept)
    def claim(c):
        return Claim(c.op, None if c.expression is None else expression(c.expression), tuple(claim(x) for x in c.children), c.value)
    decisions = tuple((n, claim(c)) for n, c in request.decisions)
    top = None if request.topk is None else TopK(tuple((n, expression(s)) for n, s in request.topk.scores), request.topk.k)
    used = set()
    def visit(c):
        if c.expression: used.update(g for g, _ in c.expression.terms)
        for ch in c.children: visit(ch)
    for _, c in decisions: visit(c)
    if top:
        # A common offset cannot affect ranking. Remove its shared cohort terms.
        base = dict(top.scores[0][1].terms)
        common = {g: a for g, a in base.items() if all(dict(s.terms).get(g) == a for _, s in top.scores)}
        scores = tuple((n, Linear(tuple((g, a) for g, a in s.terms if g not in common), s.intercept)) for n, s in top.scores)
        top = TopK(scores, top.k)
        for _, s in top.scores: used.update(g for g, _ in s.terms)
    streams = tuple((name, members_by_name[name]) for name, _ in request.cohorts if name in used)
    return decisions, top, streams, aliases


class CohortCursor:
    def __init__(self, bridge, request, name, members, alpha):
        from native_bridge import _walk
        from evergreen import col, prompt, proportion
        from evergreen.catalog.schema import Field, Schema
        from evergreen.storage.row import Row
        self.name, self.N, self.alpha = name, len(members), alpha
        self.original_N = len(dict(request.cohorts)[name])
        self.request, self.bridge = request, bridge
        import hashlib
        seed = int.from_bytes(hashlib.sha256((str(request.seed)+":"+name).encode()).digest()[:8], "big")
        self.ctx, self.model = bridge._context("cohort:"+name, seed, alpha, request.batch_size)
        public = {r.rid: r.text for r in request.records}
        self.schema = Schema((Field("logical_id", str), Field("rid", str), Field("text", str)), ("logical_id",))
        rows = [Row((f"c{i}", rid, public[rid])) for i, rid in enumerate(members)]
        p = f"FIXED_REF={bridge.cache.reference}; record {{rid}}, content {{text}}, tuple {{logical_id}}. Return the fixed binary predicate."
        df = (self.ctx.read_rows(rows, self.schema)
              .map(prompt(p, bool).alias("label"))
              .aggregate([proportion(col("label")).alias("rate")]))
        state = self.ctx.session_state()
        logical = state.optimize_logical_plan(df.logical_plan())
        self.physical = state.create_physical_plan(logical)
        if type(self.physical).__name__ != "StreamAggregate":
            raise ValueError("native progressive bridge expected root StreamAggregate")
        self.aggregate = self.physical
        native_confidence = self.aggregate._confidence_level
        if native_confidence is None:
            raise ValueError("native operator has no allocated confidence level")
        self.actual_alpha = Fraction.from_float(1.0-native_confidence)
        if self.actual_alpha > alpha:
            raise ValueError("native operator risk exceeds preassigned cohort budget")
        self.nodes = list(_walk(self.physical))
        self.logical_plan = logical.display()
        self.n = 0
        self.members = members
        self.done = False
        self.opened = False
        self.snapshots = []
        self.domain = (0, self.N)
        self.event_start = len(bridge.cache.events)

    def advance(self):
        if self.done: return False
        if not self.opened:
            self.physical.open()
            self.opened = True
        row = self.aggregate._input.next()
        if not self.aggregate._accumulators:
            # Identical initialization order to upstream _next_without_group_by:
            # CountScan receives the first next() before accumulator creation.
            self.aggregate._accumulators = self.aggregate._create_accumulators()
            if len(self.aggregate._accumulators) != 1:
                raise ValueError("expected one native proportion accumulator")
            a = self.aggregate._accumulators[0]
            if a._precomputed_total != self.N or a._confidence_level is None:
                raise ValueError("native known-N/risk configuration was not preserved")
            if Fraction.from_float(1.0-a._confidence_level) > self.alpha:
                raise ValueError("native risk exceeds assigned cohort budget")
            self.actual_alpha = Fraction.from_float(1.0-a._confidence_level)
        if row is None:
            if self.n != self.N: raise ValueError("native stream ended before known population")
            self.done = True
            return False
        self.aggregate._update_accumulators(row)
        self.n += 1
        if self.n == self.N: self.done = True
        if self.done or self.n % self.request.monitor_every == 0:
            self.refresh()
        return True

    def refresh(self):
        from evergreen.estimator import ConfSeqEstimator
        if self.n == 0: return
        a = self.aggregate._accumulators[0]
        if self.n == self.N:
            lower = upper = a._count
            ci = None
        else:
            # No replacement kernel: this is upstream ConfSeqEstimator, operating
            # on the unchanged native accumulator's own consumed prefix.
            ci = ConfSeqEstimator.estimate_mean(a._observations, a._confidence_level,
                                               a._relative_error, a._precomputed_total)
            lower, upper = outward_native_count_domain(ci.lower, ci.upper, self.N,
                                                       a._count, self.n, self.domain)
        lower, upper = max(lower, self.domain[0]), min(upper, self.domain[1])
        if lower > upper: raise ValueError("native count confidence domain became empty")
        self.domain = (lower, upper)
        self.snapshots.append({"native_prefix_length": self.n, "population_size": self.N,
            "count_domain": [lower, upper], "native_ci": None if ci is None else [ci.lower, ci.upper],
            "effective_alpha": 1.0-a._confidence_level, "exact_at_exhaustion": ci is None})

    def close(self):
        if self.opened: self.physical.close()

    def audit(self):
        events = [e for e in self.bridge.cache.events[self.event_start:] if e["query_id"] == "cohort:"+self.name]
        shuffles = [n for n in self.nodes if type(n).__name__ == "Shuffle"]
        if not shuffles: raise ValueError("cohort plan has no native shuffle")
        order = [str(row[shuffles[0].schema().index_of("logical_id")]) for row in (shuffles[0]._shuffled_rows or [])]
        if self.opened and (len(order) != self.N or len(set(order)) != self.N):
            raise ValueError("native shuffle is not a full cohort permutation")
        if [e["logical_id"] for e in events] != order[:len(events)]:
            raise ValueError("cache/provider observations are not a native cohort prefix")
        a = self.aggregate._accumulators[0] if self.aggregate._accumulators else None
        if a is not None:
            value_by_rid = self.bridge.cache.exact_after_census(e["rid"] for e in events)
            rid_by_logical = {str(row[shuffles[0].schema().index_of("logical_id")]): str(row[shuffles[0].schema().index_of("rid")]) for row in shuffles[0]._shuffled_rows}
            expected = [value_by_rid[rid_by_logical[x]] for x in order[:self.n]]
            if list(a._observations) != expected: raise ValueError("native accumulator did not consume its own random prefix")
        return {"cohort": self.name, "population_size": self.N, "statistical_observations": self.n,
                "original_full_cohort_size": self.original_N,
                "count_target": "full cohort" if self.request.support_mode == "native_full" else "G intersect shared support",
                "native_plan_types": [type(n).__name__ for n in self.nodes],
                "optimized_logical_plan": self.logical_plan, "native_permutation": order,
                "assigned_alpha": str(self.alpha), "snapshots": self.snapshots,
                "actual_native_alpha_exact": str(self.actual_alpha),
                "native_observations": [] if a is None else list(a._observations),
                "provider_events": events, "prefetched_logical_labels": len(events),
                "physical_label_attempts": sum(e["physical_label_attempts"] for e in events),
                "cache_hits": sum(e["cache_hit"] for e in events),
                "fused_invocations": self.model.fused_invocations}


class CohortNativeIntervalAdapter:
    def __init__(self, cache: SharedLabelCache):
        self.cache = cache

    def run(self, request: CohortRequest):
        if self.cache._public != {r.rid: r.text for r in request.records}:
            raise ValueError("request/cache public binding mismatch")
        members, support_info = support_plan(request)
        normalized_decisions, normalized_topk, streams, aliases = normalize_public_contract(request, members)
        budget = request.alpha / max(1, len(streams))
        start = self.cache.begin_request()
        cursors = []
        domains = {name: self.cache.known_member_bounds(members)[:2] for name, members in streams}
        history = []
        error = None
        decisions = {n: claim_value(c, domains) for n, c in normalized_decisions}
        top = topk_value(normalized_topk, domains)
        def complete():
            return all(v is not None for v in decisions.values()) and (top is None or top["status"] in {"IDENTIFIED", "TIED"})
        try:
            if not complete():
                from native_bridge import ExpandedControlBridge
                bridge = ExpandedControlBridge(self.cache)
                cursors = [CohortCursor(bridge, request, name, members, budget) for name, members in streams]
            index = 0
            while not complete():
                active = [c for c in cursors if not c.done]
                if not active: break
                cursor = active[0] if request.schedule == "native_block" else cursors[index % len(cursors)]
                index += 1
                if cursor.done: continue
                cursor.advance()
                # Cache side information is used only through deterministic
                # known-label support bounds. It is never appended to a CS.
                for c in cursors:
                    known_lo, known_hi, _ = self.cache.known_member_bounds(c.members)
                    domains[c.name] = (max(c.domain[0], domains[c.name][0], known_lo),
                                       min(c.domain[1], domains[c.name][1], known_hi))
                    if domains[c.name][0] > domains[c.name][1]:
                        raise ValueError("native CI conflicts with known fixed labels")
                decisions = {n: claim_value(c, domains) for n, c in normalized_decisions}
                top = topk_value(normalized_topk, domains)
                if cursor.snapshots and cursor.snapshots[-1]["native_prefix_length"] == cursor.n:
                    history.append({"cohort": cursor.name, "prefix": cursor.n,
                                    "decisions": decisions.copy(), "topk": top})
        except Exception as exc:
            error = {"type": type(exc).__name__, "message": str(exc)}
        finally:
            for c in cursors: c.close()
        traces = []
        for c in cursors:
            try: traces.append(c.audit())
            except Exception as exc: error = {"type": type(exc).__name__, "message": str(exc)}
        actual_alpha_sum = sum((c.actual_alpha for c in cursors), Fraction(0))
        if actual_alpha_sum > request.alpha:
            error = {"type":"RiskBudgetError","message":"sum of actual native cohort alpha exceeds request alpha"}
        vector_complete = all(v is not None for v in decisions.values())
        identified = None if error is not None or top is None or top["status"] == "UNKNOWN" else top["status"] == "IDENTIFIED"
        eligible = complete() and error is None and (top is None or top["status"] == "IDENTIFIED")
        status = "COMPLETE" if eligible else "TIED" if complete() and error is None and top is not None and top["status"] == "TIED" else "UNKNOWN"
        return {"scope": "artificial", "status": status,
                "decision_vector_complete": vector_complete,
                "truth_contract_resolved": complete() and error is None,
                "strict_identification_achieved": identified,
                "eligible_full_request_completion": eligible,
                "mode": "cohort_native_interval_adapter", "schedule": request.schedule,
                "canonical_whole_query_execution": False, "native_kernel_unchanged": True,
                "native_accumulator_update_and_risk_construction": True,
                "membership_rows": sum(len(m) for _, m in streams),
                "materialized_membership_rows": sum(c.N for c in cursors), "cohort_aliases": aliases,
                "support_compiler": support_info,
                "cache_side_information": "deterministic known-label support only; native CS prefixes unchanged",
                "decisions": decisions, "topk": top, "error": error,
                "risk_budget": {"request_alpha": str(request.alpha), "per_cohort_assigned": str(budget),
                                "assigned_sum": str(budget*len(streams)),
                                "actual_native_alpha_sum_exact": str(actual_alpha_sum),
                                "actual_sum_le_request_alpha": actual_alpha_sum <= request.alpha,
                                "native_internal_fwer_preserved": True,
                                "coverage_assumption": "upstream finite-population CS on each native uniform random cohort prefix"},
                "cohort_traces": traces, "history": history, "costs": self.cache.finish_request(start),
                "real_workload_performance_established": False, "source_s_gate_assessed": False}
