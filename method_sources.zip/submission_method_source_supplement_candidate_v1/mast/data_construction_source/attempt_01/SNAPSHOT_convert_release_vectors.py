"""Bounded construction of one complete released14-vector descriptive request.

Actual label values stay in the locked artifact and this process; never print them.
"""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import argparse
import copy
import json
import os
import resource
import signal
import sys
import time
from bounded_array_stream import ArrayStream,ProbeFailure,fail,parser_selftests

W=Path(__file__).resolve().parent;C=W.parent;R=C.parent
RAW=R/'mast_independent_request_construction_v1/MAD_full_dataset.json'
PLAN=C/'RELEASE_KEY_CONSTRUCTION_PLAN.json'
PLAN_SHA='3ff7c826a54aabc9f4fa9a3aeceae92c79af7537eec5489e9ff5655b89686669'
SCOPE_SHA='cdaa912182a20e3238a726aa1abbc25fb0356060b4666cdc232805e635ee46e8'
CAP=10*1024**2
resource.setrlimit(resource.RLIMIT_AS,(384*1024**2,384*1024**2))
resource.setrlimit(resource.RLIMIT_CPU,(19,20))
resource.setrlimit(resource.RLIMIT_FSIZE,(CAP,CAP))
signal.signal(signal.SIGXCPU,lambda n,f:fail('CPU_SOFT_LIMIT'))
READS={RAW,PLAN,C/'PLAN_PIN.json'}
def guard(event,args):
    if event in ('subprocess.Popen','socket.connect'):fail('NO_NETWORK_OR_PROCESS_CAPABILITY')
    if event!='open' or not isinstance(args[0],(str,bytes,os.PathLike)):return
    p=Path(os.fsdecode(args[0])).resolve();mode,flags=args[1:3]
    writing=(isinstance(mode,str) and any(x in mode for x in 'wax+')) or bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC))
    if writing and not p.is_relative_to(W):fail('WRITE_OUTSIDE_NEW_WORK_DIRECTORY')
    if not writing and p not in READS and not p.is_relative_to(W) and not any(p.is_relative_to(x) for x in (Path(sys.prefix),Path('/usr'),Path('/lib'),Path('/etc'),Path('/dev'))):fail('READ_OUTSIDE_EXPLICIT_PUBLIC_ALLOWLIST')
sys.addaudithook(guard)
def canonical(x):return (json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)+'\n').encode('utf8')
def digest(p):
    h=sha256()
    with p.open('rb') as f:
        for block in iter(lambda:f.read(65536),b''):h.update(block)
    return h.hexdigest()
def save(p,x,compact=False):
    raw=canonical(x) if compact else (json.dumps(x,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
    used=sum(f.stat().st_size for f in W.rglob('*') if f.is_file())
    old=p.stat().st_size if p.exists() else 0
    if used-old+len(raw)>CAP:fail('OUTPUT_CAP')
    tmp=p.with_suffix(p.suffix+'.partial')
    with tmp.open('wb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
    tmp.replace(p)
def fsidentity(s):return dict(device=s.st_dev,inode=s.st_ino,bytes=s.st_size,mtime_ns=s.st_mtime_ns)
def typ(x):return 'null' if x is None else type(x).__name__

class Collector:
    def __init__(self,plan,expected_N=100):
        self.plan=plan;self.expected_N=expected_N;self.modes=plan['mode_ids']
        self.targets={v['exact_trace_key']:v for v in plan['cohort_selection']}
        self.frames={v['id']:[] for v in plan['cohort_selection']};self.vectors={k:[] for k in self.frames}
        self.errors=Counter();self.seen={k:set() for k in self.frames};self.seen_ids={k:set() for k in self.frames};self.seen_indices={k:set() for k in self.frames}
        self.schema={k:{m:dict(present=0,absent=0,null=0,integer_binary=0,invalid_types={}) for m in self.modes} for k in self.frames}
        self.global_ids=set();self.global_repeated=0
    def feed(self,row,index,span):
        meta=tuple(row.get(k) for k in ('mas_name','llm_name','benchmark_name'));rid=row.get('trace_id')
        if all(type(x) is str for x in meta) and type(rid) is int:
            gid=(*meta,rid)
            self.global_repeated+=int(gid in self.global_ids);self.global_ids.add(gid)
        trace=row.get('trace');key=trace.get('key') if isinstance(trace,dict) else None
        if type(key) is not str or key not in self.targets:return
        target=self.targets[key];cohort=target['id'];ix=trace.get('index')
        self.frames[cohort].append(dict(source_array_index=index,exact_trace_key=key,
            metadata=dict(zip(('mas_name','llm_name','benchmark_name'),meta)),
            original_trace_id=rid if type(rid) is int else None,trace_id_type=typ(rid),
            trace_index=ix if type(ix) is int else None,trace_index_type=typ(ix),**span))
        if meta!=(target['expected_mas'],target['expected_llm'],'ProgramDev'):self.errors['SELECTED_METADATA_MISMATCH']+=1
        valid_id=type(rid) is int and type(ix) is int
        if not valid_id:self.errors['SELECTED_ID_UNSUPPORTED']+=1
        else:
            address=(key,ix,rid)
            if address in self.seen[cohort] or rid in self.seen_ids[cohort] or ix in self.seen_indices[cohort]:self.errors['SELECTED_DUPLICATE_IDENTITY']+=1
            self.seen[cohort].add(address);self.seen_ids[cohort].add(rid);self.seen_indices[cohort].add(ix)
        annotation=row.get('mast_annotation');valid_schema=isinstance(annotation,dict) and set(annotation)==set(self.modes)
        if not valid_schema:self.errors['SELECTED_ANNOTATION_SHAPE']+=1
        values=[];complete=valid_schema
        for mode in self.modes:
            field=self.schema[cohort][mode]
            if not isinstance(annotation,dict) or mode not in annotation:
                field['absent']+=1;complete=False;continue
            field['present']+=1;value=annotation[mode]
            if value is None:field['null']+=1;complete=False
            elif type(value) is int and value in (0,1):field['integer_binary']+=1;values.append(value)
            else:
                name='non_binary_integer' if type(value) is int else typ(value)
                field['invalid_types'][name]=field['invalid_types'].get(name,0)+1;complete=False
        if not complete:self.errors['SELECTED_REFERENCE_INCOMPLETE']+=1
        if complete and valid_id:self.vectors[cohort].append(dict(trace_index=ix,original_trace_id=rid,values=values))
    def finish(self):
        for cohort,rows in self.frames.items():
            if len(rows)!=self.expected_N:self.errors['FIXED_FRAME_COUNT_MISMATCH']+=1
            if not rows:self.errors['EMPTY_FIXED_FRAME']+=1
            if len(self.vectors[cohort])!=len(rows):self.errors['FRAME_HAS_UNAVAILABLE_VECTOR']+=1
        return dict(self.errors)

def selftests(plan):
    base=[]
    for t in plan['cohort_selection']:
        base.append(dict(mas_name=t['expected_mas'],llm_name=t['expected_llm'],benchmark_name='ProgramDev',trace_id=0,
            trace={'key':t['exact_trace_key'],'index':0,'trajectory':'ARTIFICIAL_NOT_EMITTED'},mast_annotation={m:0 for m in plan['mode_ids']}))
    cases=[]
    def run(name,rows,expect_complete):
        c=Collector(plan,1)
        for i,row in enumerate(rows):c.feed(row,i,dict(source_start_byte=i,source_end_byte=i+1,whole_record_sha256='ARTIFICIAL'))
        complete=not c.finish()
        if complete!=expect_complete:fail('ARTIFICIAL_CONSTRUCTION_GATE_FAILED')
        cases.append(dict(name=name,status='PASS'))
    run('complete_whole_vector_three_frames',copy.deepcopy(base),True)
    for value,name in [(None,'null_rejects_whole_request'),(True,'bool_rejects_whole_request'),('0','string_rejects_whole_request')]:
        rows=copy.deepcopy(base);rows[0]['mast_annotation'][plan['mode_ids'][0]]=value;run(name,rows,False)
    rows=copy.deepcopy(base);del rows[0]['mast_annotation'][plan['mode_ids'][0]];run('missing_mode_rejects',rows,False)
    rows=copy.deepcopy(base);rows[0]['mast_annotation']['EXTRA']=0;run('extra_mode_rejects',rows,False)
    run('empty_frame_not_vacuously_complete',copy.deepcopy(base[:2]),False)
    rows=copy.deepcopy(base);rows.append(copy.deepcopy(rows[0]));run('duplicate_or_count_excess_not_deduplicated_or_truncated',rows,False)
    rows=copy.deepcopy(base);rows[0]['benchmark_name']='ProgramDev-v2';run('header_alias_not_accepted',rows,False)
    rows=copy.deepcopy(base);old=copy.deepcopy(base[0]);old['trace']['key']='MetaGPT_ProgramDev_GPT4o';rows.append(old);run('other_namespace_same_ordinal_not_dropped_from_selected',rows,True)
    return dict(parser=parser_selftests(),construction_cases=cases,actual_labels_or_trajectories_emitted=False)

def scan(plan,out):
    collector=Collector(plan);count=0
    with RAW.open('rb') as f:
        before=fsidentity(os.fstat(f.fileno()));reader=ArrayStream(f)
        if before['bytes']!=plan['source_bytes']:fail('RAW_SIZE_MISMATCH')
        for row,span in reader.records():
            collector.feed(row,count,span);count+=1
            if count%128==0:save(out/'PROGRESS.json',dict(parsed_rows=count,phase='conversion_metadata_only_status'))
        after=fsidentity(os.fstat(f.fileno()))
    verified=before==after and reader.bytes_read==plan['source_bytes'] and reader.hasher.hexdigest()==plan['source_sha256']
    if not verified:fail('FULL_RAW_IDENTITY_MISMATCH')
    if count!=1642:collector.errors['RELEASE_ROW_COUNT_MISMATCH']+=1
    return collector,dict(rows=count,bytes_read=reader.bytes_read,sha256=reader.hasher.hexdigest(),
        before=before,after=after,identity_verified=verified,peak_buffer_bytes=reader.peak_buffer_bytes,max_record_bytes=reader.maximum_record_bytes)

def independent_audit(candidate,metadata_path,plan):
    # This pass is independent of Collector and its stored vector lists.
    raw=candidate.read_bytes()
    if len(raw)>1024**2:fail('CANDIDATE_PAYLOAD_TOO_LARGE')
    p=json.loads(raw);metadata=json.loads(metadata_path.read_bytes())
    if canonical(p)!=raw or p['metadata_sha256']!=digest(metadata_path):fail('CANONICAL_OR_METADATA_BINDING_MISMATCH')
    expected_dataset=dict(revision=plan['source_revision'],sha256=plan['source_sha256'],bytes=plan['source_bytes'])
    if p['schema']!='fixed-release-whole-vector-labelmap/v1' or p['construction_plan_sha256']!=PLAN_SHA or p['mode_ids']!=plan['mode_ids'] or p['dataset']!=expected_dataset:fail('PAYLOAD_HEADER_BINDING_MISMATCH')
    if metadata['schema']!='fixed-release-independent-record-identities/v1' or metadata['construction_plan_sha256']!=PLAN_SHA or metadata['dataset_sha256']!=plan['source_sha256']:fail('METADATA_HEADER_BINDING_MISMATCH')
    expected={t['exact_trace_key']:t for t in plan['cohort_selection']};byaddr={};meta_by_source={}
    if [g['id'] for g in p['groups']]!=[t['id'] for t in plan['cohort_selection']]:fail('GROUP_ORDER_MISMATCH')
    for g in p['groups']:
        t=next(t for t in plan['cohort_selection'] if t['id']==g['id'])
        if g['exact_trace_key']!=t['exact_trace_key'] or len(g['rows'])!=100:fail('PAYLOAD_GROUP_BINDING_MISMATCH')
        if g['rows']!=sorted(g['rows'],key=lambda v:(v['trace_index'],v['original_trace_id'])):fail('PAYLOAD_ROW_ORDER_MISMATCH')
        for v in g['rows']:
            if type(v['trace_index']) is not int or type(v['original_trace_id']) is not int or len(v['values'])!=14 or any(type(b) is not int or b not in (0,1) for b in v['values']):fail('PAYLOAD_ROW_TYPE_MISMATCH')
            address=(g['exact_trace_key'],v['trace_index'],v['original_trace_id'])
            if address in byaddr:fail('PAYLOAD_DUPLICATE_ADDRESS')
            byaddr[address]=v['values']
    for rows in metadata['frames'].values():
        for v in rows:
            if v['source_array_index'] in meta_by_source:fail('METADATA_SOURCE_INDEX_DUPLICATE')
            meta_by_source[v['source_array_index']]=v
    if len(byaddr)!=300 or len(meta_by_source)!=300:fail('AUDIT_WHOLE_REQUEST_SIZE_MISMATCH')
    seen=set();counts=Counter();n=0
    with RAW.open('rb') as f:
        before=fsidentity(os.fstat(f.fileno()));reader=ArrayStream(f)
        for row,span in reader.records():
            i=n;n+=1;trace=row.get('trace');key=trace.get('key') if isinstance(trace,dict) else None
            if key not in expected:continue
            t=expected[key];counts[t['id']]+=1
            if (row.get('mas_name'),row.get('llm_name'),row.get('benchmark_name'))!=(t['expected_mas'],t['expected_llm'],'ProgramDev'):fail('AUDIT_SOURCE_METADATA_MISMATCH')
            address=(key,trace['index'],row['trace_id'])
            if address in seen or address not in byaddr:fail('AUDIT_SOURCE_ADDRESS_MISMATCH')
            seen.add(address);annotation=row.get('mast_annotation')
            if not isinstance(annotation,dict) or set(annotation)!=set(plan['mode_ids']):fail('AUDIT_SOURCE_ANNOTATION_SHAPE')
            bits=[annotation[m] for m in plan['mode_ids']]
            if any(type(b) is not int or b not in (0,1) for b in bits) or bits!=byaddr[address]:fail('AUDIT_VECTOR_RECORD_MISMATCH')
            v=meta_by_source.get(i)
            if v is None or any(v[k]!=span[k] for k in ('source_start_byte','source_end_byte','whole_record_sha256')) or (v['exact_trace_key'],v['trace_index'],v['original_trace_id'])!=address:fail('AUDIT_RECORD_IDENTITY_MISMATCH')
        after=fsidentity(os.fstat(f.fileno()))
    if n!=1642 or len(seen)!=300 or dict(counts)!={'A':100,'B':100,'C':100}:fail('AUDIT_EXHAUSTIVE_FRAME_MISMATCH')
    if before!=after or reader.bytes_read!=plan['source_bytes'] or reader.hasher.hexdigest()!=plan['source_sha256']:fail('AUDIT_FULL_RAW_IDENTITY_MISMATCH')
    return dict(status='PASS',all300_vectors_match_source_records=True,all28_request_cohorts_retained=True,
        second_full_raw_bytes=reader.bytes_read,raw_sha256=reader.hasher.hexdigest(),raw_before=before,raw_after=after,
        no_positive_counts_or_comparison_truths_computed=True,payload_sha256=digest(candidate),metadata_sha256=digest(metadata_path))

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',required=True);args=ap.parse_args();out=Path(args.out).resolve()
    if not out.is_relative_to(W) or not out.is_dir():fail('LOCAL_ATTEMPT_REQUIRED')
    if digest(PLAN)!=PLAN_SHA or digest(W/'RESOURCE_AND_OUTPUT_PLAN.json')!=SCOPE_SHA:fail('PLAN_CHANGED')
    plan=json.loads(PLAN.read_bytes());pin=json.loads((C/'PLAN_PIN.json').read_bytes());codepin=json.loads((out/'CODE_PIN.json').read_bytes())
    scope=json.loads((W/'RESOURCE_AND_OUTPUT_PLAN.json').read_bytes())
    if digest(C/'PLAN_PIN.json')!=scope['root_pin_sha256']:fail('PROSPECTIVE_PIN_CHANGED')
    if digest(W/'CRITICAL_DEFINITION_REVIEW.md')!=codepin['critical_definition_review_sha256']:fail('DEFINITION_REVIEW_CHANGED')
    if digest(W/'bounded_array_stream.py')!='2e1b6cbc5203838d469bdd7137318a8307b4b3d8c325dcd2ef8ec88580a1ec0d':fail('INHERITED_PARSER_CHANGED')
    if pin['plan_sha256']!=PLAN_SHA or digest(Path(__file__))!=codepin['worker_sha256'] or digest(W/'bounded_array_stream.py')!=codepin['parser_sha256']:fail('PIN_CHANGED')
    if os.getpriority(os.PRIO_PROCESS,0)<10 or any(os.environ.get(k)!='1' for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS')):fail('NICE_OR_THREADS_CHANGED')
    original_pins={str(p):digest(p) for p in (PLAN,C/'PLAN_PIN.json',W/'RESOURCE_AND_OUTPUT_PLAN.json')}
    start=time.monotonic();startcpu=time.process_time();collector=None;pass1=None;audit=None;error=None;ready=False;meta_path=out/'RECORD_IDENTITIES.json';candidate=out/'LABEL_VECTOR_CANDIDATE.json';locked=out/'LOCKED_LABEL_VECTORS.json'
    try:
        save(out/'SELFTEST_RESULTS.json',selftests(plan))
        collector,pass1=scan(plan,out);errors=collector.finish()
        save(meta_path,dict(schema='fixed-release-independent-record-identities/v1',construction_plan_sha256=PLAN_SHA,
            dataset_sha256=plan['source_sha256'],frames=collector.frames,all_selected_rows_retained=True),compact=True)
        save(out/'STRUCTURAL_METADATA.json',dict(selected_N={k:len(v) for k,v in collector.frames.items()},
            schema_counters=collector.schema,structural_errors=errors,global_flat_ID_repeated_occurrences=collector.global_repeated,
            inherited_release_null_rows=4,inherited_global_context_manifest='4e6fab0c27760c5256b4405dad62fb1241a1dbdcf2c3b09ef64baea5cc5e5310',
            no_label_prevalence_or_Boolean_truths_computed=True))
        if errors:fail('WHOLE_REQUEST_REFERENCE_INCOMPLETE')
        payload=dict(schema='fixed-release-whole-vector-labelmap/v1',construction_plan_sha256=PLAN_SHA,
            dataset=dict(revision=plan['source_revision'],sha256=plan['source_sha256'],bytes=plan['source_bytes']),
            metadata_sha256=digest(meta_path),mode_ids=plan['mode_ids'],groups=[dict(id=t['id'],exact_trace_key=t['exact_trace_key'],
                rows=sorted(collector.vectors[t['id']],key=lambda v:(v['trace_index'],v['original_trace_id']))) for t in plan['cohort_selection']])
        save(candidate,payload,compact=True)
        audit=independent_audit(candidate,meta_path,plan)
        save(out/'INDEPENDENT_CONSTRUCTION_AUDIT.json',audit)
        for name,h in original_pins.items():
            if digest(Path(name))!=h:fail('BOUND_INPUT_CHANGED')
        candidate.replace(locked);os.chmod(locked,0o444);os.chmod(meta_path,0o444);ready=True
    except BaseException as exc:error=dict(type=type(exc).__name__,code=str(exc) if isinstance(exc,ProbeFailure) else 'REDACTED_CONSTRUCTION_EXCEPTION')
    summary=dict(schema='release-key-data-construction-status/v1',status='DATA_CONSTRUCTION_READY' if ready else 'REFERENCE_INCOMPLETE',
        definition_scope='Fixed-release descriptive sibling only; original paper/task/Claude identity UNKNOWN retained.',
        construction_plan_sha256=PLAN_SHA,raw_sha256=plan['source_sha256'],raw_bytes=plan['source_bytes'],
        execution_ready=False,scientific_or_acceptance_approval=False,all28_all14_strict0_tiesfalse_unchanged=True,
        selected_N={} if collector is None else {k:len(v) for k,v in collector.frames.items()},
        metadata_sha256=digest(meta_path) if meta_path.exists() else None,
        locked_vector_sha256=digest(locked) if locked.exists() else None,locked_vector_bytes=locked.stat().st_size if locked.exists() else None,
        locked_vector_permissions=oct(locked.stat().st_mode&0o777) if locked.exists() else None,
        canonical_vector_file='LOCKED_LABEL_VECTORS.json' if ready else None,
        whole_request_reference='COMPLETE300x14_BINARY_INTEGER' if ready else 'REFERENCE_INCOMPLETE',
        pass1=pass1,independent_source_record_audit=audit,error=error,
        source_input_pins=original_pins,process_CPU_seconds=time.process_time(),construction_CPU_seconds=time.process_time()-startcpu,
        wall_seconds=time.monotonic()-start,peak_RSS_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,
        nice=os.getpriority(os.PRIO_PROCESS,0),threads=1,AS_limit_bytes=384*1024**2,CPU_hard_seconds=20,wall_limit_seconds=180,
        physical_acquisition_unit='one submitted physical trace attempt returns all14 saved labels; no model-forward count claim',
        labels_or_distributions_or_target_truths_emitted=False,published_aggregates_already_known=True,
        original285f_and87d747_unresolved_preserved=True,Source_gates_unchanged=True,
        actual_original_Source_reads=0,Source_process_actions=0,trajectory_analysis=0,model_or_paid_label_API_calls=0,policy_or_method_runs=0)
    save(out/'CONSTRUCTION_STATUS.json',summary)
    files=[dict(path=p.name,bytes=p.stat().st_size,sha256=digest(p)) for p in sorted(out.iterdir()) if p.is_file() and p.name not in ('SANITIZED_STDOUT.log','STDERR.log','PROCESS_STATUS.json')]
    save(out/'WORKER_CLOSED.json',dict(status=summary['status'],construction_status_sha256=digest(out/'CONSTRUCTION_STATUS.json'),
        codepin=codepin,files=files,Source_actions=0,execution_ready=False))
    print(json.dumps({k:summary[k] for k in ('status','selected_N','locked_vector_sha256','locked_vector_bytes','process_CPU_seconds','peak_RSS_bytes','execution_ready')}),flush=True)
    return 0 if ready else 2

if __name__=='__main__':
    try:raise SystemExit(main())
    except BaseException as exc:
        if isinstance(exc,SystemExit):raise
        print(json.dumps(dict(status='EARLY_CONSTRUCTION_FAILURE_RETAINED_UNKNOWN',error_type=type(exc).__name__,Source_actions=0)),flush=True);raise SystemExit(4)
