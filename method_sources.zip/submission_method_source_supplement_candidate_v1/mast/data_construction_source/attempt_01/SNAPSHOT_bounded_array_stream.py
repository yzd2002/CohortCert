from hashlib import sha256
import codecs
import io
import json
CHUNK=65536
MAX_BUFFER=16*1024**2

class ProbeFailure(Exception):
    pass


def fail(code):raise ProbeFailure(code)


def strict_pairs(pairs):
    result={}
    for key,value in pairs:
        if key in result:fail('DUPLICATE_JSON_KEY')
        result[key]=value
    return result


def nonfinite(_):fail('NONFINITE_JSON_NUMBER')


class ArrayStream:
    def __init__(self,stream,chunk=CHUNK,max_buffer=MAX_BUFFER):
        self.stream=stream;self.chunk=chunk;self.max_buffer=max_buffer
        self.buffer='';self.base=0;self.eof=False;self.decoder=codecs.getincrementaldecoder('utf-8')('strict')
        self.json_decoder=json.JSONDecoder(object_pairs_hook=strict_pairs,parse_constant=nonfinite)
        self.hasher=sha256();self.bytes_read=0;self.peak_buffer_bytes=0;self.maximum_record_bytes=0
    def consume(self,n):
        self.base+=len(self.buffer[:n].encode('utf-8'));self.buffer=self.buffer[n:]
    def more(self,grow=False):
        if self.eof:return False
        current=len(self.buffer.encode('utf-8'))
        pending=len(self.decoder.getstate()[0])
        room=self.max_buffer-current-pending
        if room<=0:fail('RECORD_OR_BUFFER_CAP_REACHED')
        size=min(room,max(self.chunk,current) if grow else self.chunk)
        raw=self.stream.read(size)
        self.hasher.update(raw);self.bytes_read+=len(raw)
        if raw:self.buffer+=self.decoder.decode(raw,final=False)
        else:self.buffer+=self.decoder.decode(b'',final=True);self.eof=True
        self.peak_buffer_bytes=max(self.peak_buffer_bytes,len(self.buffer.encode('utf-8'))+len(self.decoder.getstate()[0]))
        return bool(raw)
    def spaces(self):
        while True:
            i=0
            while i<len(self.buffer) and self.buffer[i] in ' \t\r\n':i+=1
            if i:self.consume(i)
            if self.buffer or self.eof:return
            self.more()
    def peek(self):
        self.spaces()
        if not self.buffer:fail('UNEXPECTED_END_OF_JSON')
        return self.buffer[0]
    def records(self):
        if self.peek()!='[':fail('ROOT_SCHEMA_NOT_ARRAY')
        self.consume(1)
        if self.peek()==']':self.consume(1)
        else:
            while True:
                if self.peek()!='{':fail('ROOT_RECORD_NOT_OBJECT')
                start=self.base
                while True:
                    try:obj,end=self.json_decoder.raw_decode(self.buffer);break
                    except json.JSONDecodeError:
                        if self.eof:fail('MALFORMED_OR_TRUNCATED_JSON')
                        self.more(grow=True)
                raw=self.buffer[:end].encode('utf-8')
                if len(raw)>self.max_buffer:fail('RECORD_CAP_REACHED')
                self.maximum_record_bytes=max(self.maximum_record_bytes,len(raw))
                record_hash=sha256(raw).hexdigest();stop=start+len(raw)
                self.consume(end)
                del raw
                yield obj,dict(source_start_byte=start,source_end_byte=stop,whole_record_sha256=record_hash)
                delimiter=self.peek()
                if delimiter==']':self.consume(1);break
                if delimiter!=',':fail('INVALID_ARRAY_SEPARATOR')
                self.consume(1)
                if self.peek()==']':fail('TRAILING_ARRAY_COMMA')
        self.spaces()
        while not self.eof:
            if self.buffer:fail('NONWHITESPACE_AFTER_ARRAY')
            self.more();self.spaces()
        if self.buffer:fail('NONWHITESPACE_AFTER_ARRAY')


def parser_selftests():
    small=[{'metadata':'brace } and quote " and slash \\ and astral 🌿','nested':[{'k':'é漢'}]},
           {'metadata':'second','nested':None}]
    raw=(json.dumps(small,ensure_ascii=False)+' \n').encode()
    reader=ArrayStream(io.BytesIO(raw),chunk=7,max_buffer=4096)
    decoded=[row for row,_ in reader.records()]
    if decoded!=small or reader.hasher.hexdigest()!=sha256(raw).hexdigest():fail('ARTIFICIAL_PARSER_ROUNDTRIP_FAILED')
    for raw_bad in (b'[{},]',b'[{}]X',b'[{"k":1,"k":2}]',b'[{"k":NaN}]',b'[{"k":"unfinished'):
        try:list(ArrayStream(io.BytesIO(raw_bad),chunk=5,max_buffer=4096).records())
        except ProbeFailure:pass
        else:fail('ARTIFICIAL_MALFORMED_INPUT_ACCEPTED')
    try:list(ArrayStream(io.BytesIO(b'[{"text":"'+b'x'*1024+b'"}]'),chunk=8,max_buffer=64).records())
    except ProbeFailure:pass
    else:fail('ARTIFICIAL_RECORD_CAP_NOT_ENFORCED')
    return dict(status='PASS',small_UTF8_escape_and_nested_roundtrip=True,malformed_rejections=5,
        bounded_record_rejection=True,source_payload_opened=False)

