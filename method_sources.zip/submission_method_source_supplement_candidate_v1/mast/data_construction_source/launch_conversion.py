"""Only launches and waits for the own bounded construction process."""
from pathlib import Path
from hashlib import sha256
import json
import os
import subprocess
import sys
import time
W=Path(__file__).resolve().parent
def save(p,x):
    tmp=p.with_suffix('.partial')
    with tmp.open('w') as f:json.dump(x,f,sort_keys=True,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
    tmp.replace(p)
def main():
    out=W/'attempt_01';out.mkdir(exist_ok=False)
    worker=W/'convert_release_vectors.py'
    pin={k:sha256((W/n).read_bytes()).hexdigest() for k,n in [('worker_sha256','convert_release_vectors.py'),('parser_sha256','bounded_array_stream.py'),('launcher_sha256','launch_conversion.py'),('resource_plan_sha256','RESOURCE_AND_OUTPUT_PLAN.json'),('critical_definition_review_sha256','CRITICAL_DEFINITION_REVIEW.md')]}
    save(out/'CODE_PIN.json',pin)
    for n in ('convert_release_vectors.py','bounded_array_stream.py','RESOURCE_AND_OUTPUT_PLAN.json','CRITICAL_DEFINITION_REVIEW.md'):(out/('SNAPSHOT_'+n)).write_bytes((W/n).read_bytes())
    start=time.monotonic();child=None;status=dict(state='STARTING',Source_process_actions=0)
    save(out/'PROCESS_STATUS.json',status)
    with (out/'SANITIZED_STDOUT.log').open('xb') as stdout,(out/'STDERR.log').open('xb') as stderr:
        try:
            child=subprocess.Popen([sys.executable,'-B',str(worker),'--out',str(out)],stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,close_fds=True,
                env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1'))
            status.update(state='RUNNING_OWN_CONSTRUCTION_CHILD',own_child_PID=child.pid);save(out/'PROCESS_STATUS.json',status)
            try:code=child.wait(timeout=180)
            except subprocess.TimeoutExpired:child.kill();code=child.wait();status['wall_timeout']=True
            status.update(state='CLOSED_OWN_CHILD_WAITED',returncode=code,child_waited=True)
        except BaseException as exc:
            if child is not None and child.poll() is None:child.kill();child.wait()
            status.update(state='FAILED_RETAINED',launcher_error_type=type(exc).__name__,child_waited=True)
    status.update(wall_seconds=time.monotonic()-start,worker_closed_marker_present=(out/'WORKER_CLOSED.json').is_file(),policy_or_method_runs=0)
    save(out/'PROCESS_STATUS.json',status);print(json.dumps(status))
if __name__=='__main__':main()
