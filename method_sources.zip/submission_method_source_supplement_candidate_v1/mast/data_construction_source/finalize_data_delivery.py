"""Finalize sanitized metadata and opaque artifact hashes; never decode labels."""
from pathlib import Path
from hashlib import sha256
import json

W=Path(__file__).resolve().parent;C=W.parent;R=C.parent;A=W/'attempt_01'
def load(p):return json.loads(p.read_bytes())
def digest(p):
    h=sha256()
    with p.open('rb') as f:
        for block in iter(lambda:f.read(65536),b''):h.update(block)
    return h.hexdigest()
def save(name,value):
    p=W/name
    if p.exists():raise ValueError('Preserve already finalized artifacts')
    p.write_text(json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n')

def main():
    status=load(A/'CONSTRUCTION_STATUS.json');proc=load(A/'PROCESS_STATUS.json');closed=load(A/'WORKER_CLOSED.json')
    structural=load(A/'STRUCTURAL_METADATA.json');tests=load(A/'SELFTEST_RESULTS.json')
    plan=load(C/'RELEASE_KEY_CONSTRUCTION_PLAN.json')
    assert status['status']=='DATA_CONSTRUCTION_READY' and status['error'] is None and not status['execution_ready']
    assert status['selected_N']=={'A':100,'B':100,'C':100}
    assert proc['state']=='CLOSED_OWN_CHILD_WAITED' and proc['child_waited'] and proc['returncode']==0 and proc['worker_closed_marker_present']
    assert closed['status']==status['status'] and closed['construction_status_sha256']==digest(A/'CONSTRUCTION_STATUS.json')
    for entry in closed['files']:
        p=A/entry['path'];assert p.stat().st_size==entry['bytes'] and digest(p)==entry['sha256']
    assert (A/'STDERR.log').stat().st_size==0
    assert status['process_CPU_seconds']<20 and proc['wall_seconds']<180 and status['peak_RSS_bytes']<384*1024**2
    for cohort,fields in structural['schema_counters'].items():
        assert len(fields)==14
        for f in fields.values():assert f==dict(present=100,absent=0,null=0,integer_binary=100,invalid_types={})
    assert not structural['structural_errors'] and structural['global_flat_ID_repeated_occurrences']==90
    assert tests['parser']['status']=='PASS' and len(tests['construction_cases'])==10 and all(t['status']=='PASS' for t in tests['construction_cases'])
    for p,h in status['source_input_pins'].items():assert digest(Path(p))==h
    assert digest(C/'RELEASE_KEY_CONSTRUCTION_PLAN.json')=='3ff7c826a54aabc9f4fa9a3aeceae92c79af7537eec5489e9ff5655b89686669'
    payload=A/'LOCKED_LABEL_VECTORS.json';identities=A/'RECORD_IDENTITIES.json'
    # Opaque byte hashing only. No json.load or annotation access for payload.
    assert digest(payload)==status['locked_vector_sha256'] and payload.stat().st_size==status['locked_vector_bytes']
    assert digest(identities)==status['metadata_sha256']
    assert payload.stat().st_mode&0o777==0o444 and identities.stat().st_mode&0o777==0o444
    oldC=R/'mast_independent_request_construction_v1'
    previous_manifests=[(oldC/'metadata_construction_probe_v1/DELIVERY_MANIFEST.json','4e6fab0c27760c5256b4405dad62fb1241a1dbdcf2c3b09ef64baea5cc5e5310'),
        (oldC/'metadata_identity_investigation_v1/DELIVERY_MANIFEST_V2.json','87d7477432ba00a6fa9b9896d24779de17082cd1d5f7690660bc7d13e2295220')]
    for p,h in previous_manifests:
        assert digest(p)==h
        for entry in load(p)['files']:
            f=p.parent/entry['path'];assert f.stat().st_size==entry['bytes'] and digest(f)==entry['sha256']
    assert digest(oldC/'CONSTRUCTION_PLAN.json')=='285f7748154839d25fbf67332119a37f8c4a02357c044a84ef6658922a4120ff'
    rs=(oldC/'MAD_full_dataset.json').stat();expected=status['independent_source_record_audit']['raw_after']
    assert dict(device=rs.st_dev,inode=rs.st_ino,bytes=rs.st_size,mtime_ns=rs.st_mtime_ns)==expected
    components=[dict(mode_id=m,left='A',right=right,operator='>',threshold='0 exact',false_includes_ties=True)
        for m in plan['mode_ids'] for right in ('B','C')]
    contract=dict(schema='mast-release-key-data-contract/v1',data_construction_status='DATA_CONSTRUCTION_READY',
        construction_plan_sha256=status['construction_plan_sha256'],
        source_revision=plan['source_revision'],source_bytes=plan['source_bytes'],source_sha256=plan['source_sha256'],
        cohorts=plan['cohort_selection'],preserved_benchmark_header='ProgramDev',
        cohort_N={'A':100,'B':100,'C':100},mode_ids=plan['mode_ids'],request_count=1,components=components,
        locked_vector_artifact=dict(path='attempt_01/LOCKED_LABEL_VECTORS.json',bytes=payload.stat().st_size,
            sha256=digest(payload),mode='0444',format='canonical UTF8 JSON, sorted keys, compact separators, LF',
            row_order='cohort A/B/C then increasing(trace.index,original trace_id)',
            permitted_use='Future independently authorized saved-vector oracle or source audit only; no coordinator label inspection'),
        record_identity_artifact=dict(path='attempt_01/RECORD_IDENTITIES.json',bytes=identities.stat().st_size,sha256=digest(identities),mode='0444'),
        physical_cost_requirement='One submitted physical trace acquisition returns the whole14-vector to every comparator; not14 separately charged calls or a verified model forward.',
        target='Fixed released judge flags, not human gold or objective failure truth.',
        interpretation='Finite-release cohort means only; not a causal, matched-task, paper-figure reproduction, or original285f completion claim.',
        original_paper_task_equivalence='UNKNOWN',cross_system_task_alignment='UNKNOWN',released_Claude_is_Claude3_7='UNKNOWN',
        known_release_global_context=dict(null_rows=4,flat_composite_duplicate_occurrences=90,none_silently_removed=True),
        execution_ready=False,
        unfixed_execution_requirements=['engine/vector acquisition adapter and full whole-request accounting','priors/pilot/initialization','sampling schedules/seeds','risk allocation/checkpoints','budgets/caps','failure/censor/replay/archive policy'],
        no_policy_or_method_run=True,no_inference_results_or_truth_answers_computed=True,
        published_aggregate_figures_already_known=True,not_blind_validation=True,
        SourceS_gates_unchanged=True,actual_original_Source_actions=0,model_or_paid_label_API_calls=0)
    save('DATA_CONTRACT.json',contract)
    final=dict(schema='mast-release-key-construction-final/v1',status='DATA_CONSTRUCTION_READY',execution_ready=False,
        definition_review='COHERENT_ONLY_AS_DESCRIPTIVE_RELEASE_SIBLING',
        construction_plan_sha256=status['construction_plan_sha256'],data_contract_sha256=digest(W/'DATA_CONTRACT.json'),
        canonical_labelmap_sha256=digest(payload),canonical_labelmap_bytes=payload.stat().st_size,
        record_identities_sha256=digest(identities),record_identities_bytes=identities.stat().st_size,
        all300_full14_binary_integer_vectors_complete_and_source_matched=True,
        full_original_metadata_headers_preserved=True,no_position_slice_dedup_or_mode_filter=True,
        source_file_passes=2,source_file_SHA_verified_both_passes=True,
        artificial_gate_tests_PASS=10,independent_source_record_audit='PASS_DIFFERENT_CODE_PATH_SAME_BOUNDED_PROCESS',
        worker_closed_and_parent_waited=True,source_parse_cpu_seconds=status['process_CPU_seconds'],
        peak_RSS_bytes=status['peak_RSS_bytes'],parent_wall_seconds=proc['wall_seconds'],
        original285f_frame_and87d747_semantic_UNKNOWN_preserved=True,
        original4e6fa_all18_bound_files_unchanged=True,original87d747_all67_bound_files_unchanged=True,
        labels_or_prevalence_or28_truths_output_to_coordinator=False,
        locked_payload_contents_not_decoded_by_finalizer=True,
        prior_known_global4null_and90_ID_repeats_retained=True,
        methods_priors_risks_pilot_seeds_checkpoints_budgets_failures_not_authorized=True,
        original_Source_maps_oldraw_methods_ledgers_PID_actions=0,
        model_or_paid_label_API_calls=0,method_or_policy_runs=0,
        SourceS_gates_changed=False,causal_performance_utility_or_acceptance_claim=False)
    save('FINAL_STATUS.json',final)
    rows='\n'.join(f"| {t['id']} | `{t['exact_trace_key']}` | {t['expected_mas']} | {t['expected_llm']} | ProgramDev | 100 |" for t in plan['cohort_selection'])
    report=f'''# Release-key descriptive request: independent construction review

**DATA_CONSTRUCTION_READY only; execution_ready=false.** The new sibling is coherent as descriptive means over three exact namespaces of a fixed public release. This report does not resolve or replace the original285f paper-matched request or87d747's semantic UNKNOWN. The label files are construction artifacts for a future independently reviewed oracle/audit; no method, policy, inference or Source experiment ran.

The plan was pinned before this conversion: `{status['construction_plan_sha256']}`. `CRITICAL_DEFINITION_REVIEW.md` and `RESOURCE_AND_OUTPUT_PLAN.json` were written before implementation and conversion. They explicitly separate this new estimand from a matched-benchmark or causal model/framework effect. Published aggregates and the metadata investigation were already known; this is not blind validation or proof of method advantage.

## Complete frozen release population

| Cohort | Exact released key | Raw MAS | Raw LLM | Raw benchmark | Full N |
|---|---|---|---|---|---:|
{rows}

Every row with one of these exact keys was retained. No positional slice,100-row truncation, header alias, mode choice, deduplication or label-dependent selection occurred. The frozen source is `mcemri/MAST-Data@95118ac951421753cf1deb87ddea3b01e693c41b`,199,574,367 bytes, SHA256 `{plan['source_sha256']}`. Both complete streaming passes independently checked its array/EOF, byte count, SHA and unchanged file identity. No whole199MB `json.load` or raw copy was used.

All300 selected rows have exactly the14 declared mode fields, each an integer in the allowed binary set; bool/string/null/missing/extra fields are rejected. Each cohort has100 unique trace IDs and indices. The independent record identities retain dataset SHA, original metadata, exact key, original trace_id, trace.index, source-array index/byte span and full-source-record SHA. Canonical row order uses the source index identities, never labels. The source header stays ProgramDev; the Claude version and paper's original100-task correspondence/cross-system task alignment remain UNKNOWN.

Known release-wide context is preserved:4 rows have unavailable annotations, and the flat configuration+trace_id identifier has90 repeated occurrences across different key namespaces. This conversion freshly observed the90 ID repeats and inherited the4-null context from the unchanged4e6fa source-bound review. None was silently erased, imputed or deduplicated. The selected300 are complete; this does not claim the entire release is complete or the flat identifier globally unique.

## Locked artifacts and source-record verification

The canonical payload `attempt_01/LOCKED_LABEL_VECTORS.json` is **{payload.stat().st_size:,} bytes**, read-only0444, SHA256 `{digest(payload)}`. The independent `RECORD_IDENTITIES.json` is **{identities.stat().st_size:,} bytes**, read-only0444, SHA256 `{digest(identities)}`. The payload binds the record-identity SHA, root construction-plan SHA, dataset SHA/revision/bytes, mode order, full cohorts, indices and original IDs. There are no per-vector-only hashes in coordinator metadata.

After writing a candidate, a second code path in the same bounded process loaded the canonical file, verified canonical serialization and all header/metadata bindings, reread the entire source, and checked every one of300 vectors against its exact original record and record hash. It did not reuse Collector's stored vector list. This is an independent implementation check within one trusted construction process, not a separate scientific trial or an upstream authenticated oracle. Only after success was the candidate atomically published and locked. The coordinator/finalizer received identities, completeness, sizes and opaque hashes; it never decoded label payload contents or computed positives, negatives, prevalence, any of the28 answers, or rate differences.

The request remains **one full28-Boolean request over all14 modes**: per mode A>B and A>C, exact zero threshold, ties false, no equivalence margin/ranking. A physical trace attempt returns the entire14-component saved-label vector once to all methods. This is not14 paid calls, independent mode strata, or evidence that the provider used one forward. "Independently justified" describes the requirement for each output's certificate, not statistical independence. `DATA_CONTRACT.json` binds these meanings and the artifact hashes without target answers.

## Gates, resources and limits

Ten tiny artificial construction cases passed: complete frames; null, bool, string, missing/extra mode, empty frame, duplicate/count excess, wrong header; and a repeated ordinal in an unrelated key namespace. Parser checks additionally covered Unicode/escapes, malformed/truncated JSON, duplicate keys, nonfinite numbers and the record cap. Empty/ambiguous/incomplete frames cannot pass vacuously. On any whole-request reference/identity error, no final locked labelmap would be published; failed candidates and sanitized failure evidence are retained. This run had no failed conversion attempt.

Both source passes and source-record verification ran in one nice10/single-thread child under AS384MiB, CPU19s soft/20s hard,16MiB stream/record and10MiB cumulative output caps. Observed child CPU was{status['process_CPU_seconds']:.6f}s, peak RSS{status['peak_RSS_bytes']:,} bytes; parent wall was{proc['wall_seconds']:.3f}s against180s. The parent durably recorded its own child PID, waited for exit0, and checked a complete worker-closed marker. These are construction-resource observations, not algorithm/Source/model latency results.

Method/physical-vector adapters, priors/pilot/initialization, schedules/seeds, risk/checkpoints, budgets/caps and failure/censor/replay/archive handling still need a complete prospective reviewed execution protocol. Data construction does not authorize sampling, a saved-label policy experiment, Full-feedback extension, original SourceS bypass or an acceptance/utility claim. Judge-relative released annotations are not human gold or objective failure truth.

All original285f/PIN/raw,4e6fa and87d747 inputs remain read-only; all18 and67 bound review files respectively were rehashed unchanged. Every new write is inside this work directory. Actual original Source/maps/oldraw/methods/ledgers/PID15744 actions, trajectory analysis, human-panel reads, model/paid-label API calls and method/policy runs were0. `FINAL_STATUS.json` is the limited data-construction decision; `DELIVERY_MANIFEST.json` binds the complete delivery.
'''
    for before,after in [('original285f','original 285f'),('or87d747','or 87d747'),('slice,100','slice, 100'),('whole199MB','whole 199MB'),('All300','All 300'),('the14','the 14'),('has100','has 100'),('original100','original 100'),('preserved:4','preserved: 4'),('has90','has 90'),('the90','the 90'),('the4-null','the 4-null'),('unchanged4e6fa','unchanged 4e6fa'),('selected300','selected 300'),('of300','of 300'),('the28','the 28'),('full28','full 28'),('all14','all 14'),('entire14','entire 14'),('not14','not 14'),('one14','one 14'),('AS384','AS 384'),('CPU19','CPU 19'),('hard,16MiB','hard, 16MiB'),('and10MiB','and 10MiB'),('was{','was {'),('RSS'+str(status['peak_RSS_bytes']),'RSS '+str(status['peak_RSS_bytes'])),('against180s','against 180s'),('exit0','exit 0'),('all18','all 18'),('and67','and 67'),('respectively','respectively'),('were0','were 0')]:report=report.replace(before,after)
    p=W/'REVIEW.md'
    if p.exists():raise ValueError('Preserve existing review')
    p.write_text(report)
    files=[]
    for p in sorted(W.rglob('*')):
        if p.is_file():files.append(dict(path=str(p.relative_to(W)),bytes=p.stat().st_size,sha256=digest(p),mode=oct(p.stat().st_mode&0o777),
            artifact_role='LOCKED_REFERENCE_LABEL_PAYLOAD_NO_COORDINATOR_DECODE' if p==payload else 'code_or_sanitized_metadata_and_evidence'))
    assert sum(x['bytes'] for x in files)<10*1024**2
    save('DELIVERY_MANIFEST.json',dict(schema='mast-release-key-construction-delivery/v1',status='DATA_CONSTRUCTION_READY',execution_ready=False,
        construction_plan_sha256=status['construction_plan_sha256'],files=files,file_count=len(files),content_bytes=sum(x['bytes'] for x in files),
        canonical_labelmap_sha256=digest(payload),record_identities_sha256=digest(identities),data_contract_sha256=digest(W/'DATA_CONTRACT.json'),
        retained_original_plan_sha256='285f7748154839d25fbf67332119a37f8c4a02357c044a84ef6658922a4120ff',
        retained_original_identity_manifest_sha256='87d7477432ba00a6fa9b9896d24779de17082cd1d5f7690660bc7d13e2295220',
        actual_Source_actions=0,new_method_runs=0,no_truth_or_prevalence_outputs=True))
    print(json.dumps(dict(status=final['status'],execution_ready=False,manifest_sha256=digest(W/'DELIVERY_MANIFEST.json'),
        final_status_sha256=digest(W/'FINAL_STATUS.json'),review_sha256=digest(W/'REVIEW.md'),data_contract_sha256=digest(W/'DATA_CONTRACT.json'),
        canonical_labelmap_sha256=digest(payload),record_identities_sha256=digest(identities),content_files=len(files),
        output_bytes=sum(p.stat().st_size for p in W.rglob('*') if p.is_file()))))

if __name__=='__main__':main()
