CohortCert v3 reproducibility candidate (local, not yet publicly released).

Start in04_Reproducibility/README_V3_先读.txt. Frozen inputs, code, allCSV results, audit/certificate evidence and CPU replay are included; GPU weights are excluded and pinned14-file hashes are provided. The complete original compressed traces are separate in07_Raw_Trace_Archives, with SHA256 indexes. Obtain those files too for direct full raw audit, or create new local replay manifests and regenerate them. Missing raw traces cause audit failure, never an asserted full pass.

The source in03_Source builds the same paper text as01_Submit. Software release license and third-party terms must be confirmed by the authors before public distribution. Do not use a local path as a public artifact URL. No future or unvalidated research is part of the reported v3 results.
