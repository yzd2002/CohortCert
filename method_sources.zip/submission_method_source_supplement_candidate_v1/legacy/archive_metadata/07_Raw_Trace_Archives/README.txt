全部32,960条新语料主实验和排名对照的完整原始轨迹均保留在这些分卷中。各分卷是独立可解包的tar文件；无需拼接。将所有分卷解包到04_Reproducibility/revision_evidence即可恢复历史目录结构。原始文件内容及历史清单未修改；RAW_ARCHIVE_INDEX.json列出各卷SHA256及成员。原语料9,600条轨迹、192个离线案例、23次真实推理轨迹已在核心包内另行保留。

Each TAR is independently extractable; extract into 04_Reproducibility/revision_evidence. Do not concatenate. Archive byte hashes and member paths are in RAW_ARCHIVE_INDEX.json. The historical manifests retain original absolute paths; reproduce.py maps them in memory for portable inspection without editing the evidence.
