"""Compile a validated decision contract into a signed-contrast matrix A and a
certificate family W.

The core identity (scheme 5.2):

    theta = A y,   A in Q^{J x N},   y in {0,1}^N

where ``a_{j,i}`` is record i's signed contribution to atomic contrast j.
Structured cohort proportions are represented exactly with ``Fraction`` so the
compiler itself introduces no floating-point drift.

Key correctness points baked in here:
  * Overlapping cohorts are NOT cancelled. When n_L != n_R the shared records
    carry coefficient 1/n_L - 1/n_R (scheme 6.1) -- never silently dropped.
  * A ``compare`` / ``direction`` decision is a single lower atom theta > b.
  * An ``equivalence`` decision is two atoms: theta > -eps AND theta < eps.
  * Ranking decisions enumerate certificates as disjunctions of pairwise lower
    atoms; candidate count is already bounded by the validator (<= 8).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from fractions import Fraction
from itertools import combinations
from typing import Any

from query.certificate_family import (
    ATOM_LOWER,
    ATOM_UPPER,
    Atom,
    CertificateFamily,
)
from query.contract_schema import ContractUnsupported, normalize_decisions, validate_contract
from query.snapshot import Snapshot


@dataclass
class MatrixA:
    """Sparse signed-contrast matrix. ``rows[r]`` maps record_id -> coefficient."""

    rows: list[dict] = field(default_factory=list)

    def atom_row_count(self) -> int:
        return len(self.rows)

    def rows_with_any_nonzero_coefficient(self) -> set:
        """The request's effective evidence-support set I_q (scheme 6.1).

        Coefficients that evaluate to exactly zero are excluded on purpose:
        when |A| == |B| a shared record contributes 1/n - 1/n = 0 and its label
        cannot change the contrast, so sending it to the semantic operator
        would burn budget for no information (scheme 6.2).
        """
        support: set = set()
        for row in self.rows:
            support.update(i for i, c in row.items() if c != 0)
        return support


def rows_with_any_nonzero_coefficient(A: MatrixA) -> set:
    return A.rows_with_any_nonzero_coefficient()


def effective_support(A: MatrixA, keep_cancellations: bool = False) -> set:
    """The sampling population for one run (§18 ablation-aware).

    Default is the scheme 6.2 support (zero-coefficient records excluded).
    With ``keep_cancellations=True`` the ablation arm pays for shared records
    too: the zero-coefficient entries that ``compile_signed_decisions``
    deliberately kept in the rows join the population. Their contribution is
    still exactly zero, so certified values cannot change -- only the cost
    does, which is the quantity the ablation measures. Without this, the
    support function filtered the kept records straight back out and the
    ablation arm was a runtime no-op.
    """
    if keep_cancellations:
        support: set = set()
        for row in A.rows:
            support.update(row.keys())
        return support
    return A.rows_with_any_nonzero_coefficient()


def _to_fraction(x) -> Fraction:
    """Exact Fraction from int / str / Fraction, or float via its decimal string.

    ``Fraction(0.03)`` would capture the binary approximation; routing floats
    through ``str`` keeps the contract's intended decimal value exact.
    """
    if isinstance(x, Fraction):
        return x
    if isinstance(x, int):
        return Fraction(x)
    if isinstance(x, float):
        return Fraction(str(x))
    return Fraction(x)


def _diff_row(L: set, nL: int, R: set, nR: int,
              keep_cancellations: bool = False) -> dict:
    """Coefficient row for theta = mu_L - mu_R, with exact shared-record terms.

    Records whose coefficient cancels to exactly zero are dropped here as well
    as in the support set: keeping them would let a fully cancelled record into
    the sampling population, which is precisely the waste scheme 6.2 removes.
    ``keep_cancellations=True`` is the §18 ablation arm ("no signed
    cancellation"): zero-coefficient records stay in the row and in the
    effective support, so the sampler pays for shared records -- the baseline
    the cancellation is measured against. Their coefficients are still exactly
    0, so certified values are unchanged; only the cost changes.
    """
    row: dict = {}
    for i in L:
        row[i] = row.get(i, Fraction(0)) + Fraction(1, nL)
    for i in R:
        row[i] = row.get(i, Fraction(0)) - Fraction(1, nR)
    if keep_cancellations:
        return row
    return {i: c for i, c in row.items() if c != 0}


def compile_signed_decisions(contract: dict, snapshot: Snapshot,
                             keep_cancellations: bool = False):
    """Return ``(MatrixA, CertificateFamily)`` or raise ``ContractUnsupported``.

    ``keep_cancellations`` is the §18 ablation switch: with it, fully
    cancelled shared records remain in every row and in the effective support,
    so the request pays |cohort union| instead of |I_q|. Ablation only -- the
    frozen main configuration keeps the exact cancellation of scheme 6.2.
    """
    ok, reason = validate_contract(contract, snapshot)
    if not ok:
        raise ContractUnsupported(reason)

    cohorts = {c["id"]: snapshot.cohort_records(c) for c in contract["cohorts"]}
    sizes = {cid: len(recs) for cid, recs in cohorts.items()}

    blocks = normalize_decisions(contract)

    rows: list[dict] = []
    atoms: list[Atom] = []
    certificates: list[list[int]] = []
    certificate_decisions: list[int] = []
    decision_types: list[str] = []

    # Two decisions over the same cohort pair must share one coefficient row:
    # the row *is* the contrast, so duplicating it would double-charge the same
    # evidence and break the shared-record cancellation of scheme 6.2.
    row_cache: dict[tuple, int] = {}

    def row_index_for(L: str, R: str) -> int:
        key = (L, R)
        if key not in row_cache:
            row_cache[key] = len(rows)
            rows.append(_diff_row(cohorts[L], sizes[L], cohorts[R], sizes[R],
                                  keep_cancellations))
        return row_cache[key]

    def add_atom(kind: str, threshold, ridx: int, label: str, pair: tuple) -> int:
        idx = len(atoms)
        atoms.append(
            Atom(
                index=idx,
                kind=kind,
                threshold=Fraction(threshold),
                row_index=ridx,
                label=label,
                cohort_pair=pair,
            )
        )
        return idx

    for di, decision in enumerate(blocks):
        dtype = decision["type"]
        decision_types.append(dtype)
        first_cert = len(certificates)

        if dtype in ("compare", "direction"):
            L, R = decision["left"], decision["right"]
            b = _to_fraction(decision["threshold"])
            ridx = row_index_for(L, R)
            add_atom(ATOM_LOWER, b, ridx, f"{L} - {R} > {b}", (L, R))
            certificates.append([atoms[-1].index])

        elif dtype == "equivalence":
            L, R = decision["left"], decision["right"]
            eps = _to_fraction(decision["tolerance"])
            ridx = row_index_for(L, R)
            lo = Atom(index=len(atoms), kind=ATOM_LOWER, threshold=-eps,
                      row_index=ridx, label=f"{L} - {R} > -{eps}", cohort_pair=(L, R))
            hi = Atom(index=len(atoms) + 1, kind=ATOM_UPPER, threshold=eps,
                      row_index=ridx, label=f"{L} - {R} < {eps}", cohort_pair=(L, R))
            atoms.extend([lo, hi])
            certificates.append([lo.index, hi.index])

        elif dtype in ("top1", "topk"):
            cands = decision["candidates"]
            pair_atom: dict[tuple, int] = {}
            for g in cands:
                for h in cands:
                    if g == h:
                        continue
                    ridx = row_index_for(g, h)
                    pair_atom[(g, h)] = add_atom(
                        ATOM_LOWER, 0, ridx, f"{g} - {h} > 0", (g, h)
                    )

            if dtype == "top1":
                for g in cands:
                    certificates.append([pair_atom[(g, h)] for h in cands if h != g])
            else:  # topk
                k = decision["k"]
                if "topk_set" in decision:
                    S = set(decision["topk_set"])
                    certificates.append(
                        [pair_atom[(g, h)] for g in S for h in cands if h not in S]
                    )
                else:
                    for subset in combinations(cands, k):
                        S = set(subset)
                        certificates.append(
                            [pair_atom[(g, h)] for g in S for h in cands if h not in S]
                        )

        certificate_decisions.extend([di] * (len(certificates) - first_cert))

    family = CertificateFamily(
        atoms=atoms,
        certificates=certificates,
        cohort_sizes=sizes,
        decision_type=decision_types[0] if len(decision_types) == 1 else "bundle",
        labels={c["id"]: c.get("label", c["id"]) for c in contract["cohorts"]},
        certificate_decisions=certificate_decisions,
        decision_types=decision_types,
    )
    return MatrixA(rows=rows), family
