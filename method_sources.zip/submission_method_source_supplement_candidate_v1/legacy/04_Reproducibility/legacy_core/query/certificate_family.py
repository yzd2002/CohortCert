"""The certificate family W produced by the compiler.

A decision contract is a boolean expression over signed contrasts:

    Phi_q = \\/_w  /\\_j in J_w  (theta_j rel b_j)

where each atomic judgement is either a *lower* bound ``theta_j > b_j`` or an
*upper* bound ``theta_j < b_j``. A ``compare`` decision is one lower atom; an
``equivalence`` decision is two atoms (lower -eps, upper +eps); a ranking
decision (top-1 / top-k) is a disjunction of certificates, each a conjunction
of pairwise lower atoms (scheme 5.3, 8.1).

This module is pure logic: it knows nothing about how the contrast intervals
are obtained. ``check`` consumes per-atom interval bounds and reports which
certificates are satisfied.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from fractions import Fraction
from typing import Any

ATOM_LOWER = "lower"  # theta > b
ATOM_UPPER = "upper"  # theta < b


@dataclass(frozen=True)
class Atom:
    """One atomic signed-contrast judgement.

    ``row_index`` points into ``MatrixA.rows`` (the coefficient row for the
    contrast theta_j). ``kind``/``threshold`` define the bound. ``label`` and
    ``cohort_pair`` exist only for traceability in rendering / audits.
    """

    index: int
    kind: str
    threshold: Fraction
    row_index: int
    label: str
    cohort_pair: tuple


@dataclass
class CertificateFamily:
    """Certificates for one request.

    ``certificates`` is the flat list of certificates; ``certificate_decisions[i]``
    says which *declared decision* certificate ``i`` belongs to. A single-decision
    contract gives every entry ``0``; a multi-judgement bundle (scheme 15.1)
    groups them. Certificates of one decision are alternatives (OR): any one of
    them being satisfied settles that decision. Decisions themselves are a
    conjunction (AND): a bundle is complete only when *every* declared judgement
    is settled -- dropping the hardest one is not "complete" (scheme 17.1).
    """

    atoms: list[Atom]
    certificates: list[list[int]]  # each certificate = AND of atom indices
    cohort_sizes: dict = field(default_factory=dict)
    decision_type: str = ""
    labels: dict = field(default_factory=dict)
    certificate_decisions: list[int] = field(default_factory=list)
    decision_types: list[str] = field(default_factory=list)

    def __post_init__(self):
        self._by_index = {a.index: a for a in self.atoms}
        if not self.certificate_decisions:
            self.certificate_decisions = [0] * len(self.certificates)
        if len(self.certificate_decisions) != len(self.certificates):
            raise ValueError("certificate_decisions must align with certificates")
        if not self.decision_types:
            self.decision_types = [self.decision_type] if self.decision_type else [""]

    @property
    def decision_count(self) -> int:
        return len(self.decision_types)

    def decision_indices(self) -> list[int]:
        return list(range(self.decision_count))

    def certificates_of(self, di: int) -> list[int]:
        return [ci for ci, d in enumerate(self.certificate_decisions) if d == di]

    def check_per_decision(
        self, bounds: dict[int, tuple[Fraction, Fraction]]
    ) -> dict[int, list[int]]:
        """Satisfied certificate indices, grouped by declared decision."""
        satisfied = self.check(bounds)
        out: dict[int, list[int]] = {di: [] for di in self.decision_indices()}
        for ci in satisfied:
            out[self.certificate_decisions[ci]].append(ci)
        return out

    def bundle_complete(self, satisfied: list[int]) -> bool:
        """True when every declared decision has a satisfied certificate.

        For a single-decision contract this reduces to ``bool(satisfied)``, so
        existing behaviour is preserved exactly.
        """
        if not satisfied:
            return False
        hit = {self.certificate_decisions[ci] for ci in satisfied}
        return hit >= set(self.decision_indices())

    def per_decision_status(self, satisfied: list[int]) -> list[dict]:
        """Per-decision verdict, for the rendered object and for metrics."""
        hit = {self.certificate_decisions[ci] for ci in satisfied} if satisfied else set()
        return [
            {
                "decision_index": di,
                "decision_type": self.decision_types[di],
                "certified": di in hit,
                "satisfied_certificates": sorted(
                    ci for ci in satisfied if self.certificate_decisions[ci] == di
                ),
            }
            for di in self.decision_indices()
        ]

    def check(self, bounds: dict[int, tuple[Fraction, Fraction]]) -> list[int]:
        """Return the list of satisfied certificate indices.

        ``bounds[atom_index] = (L_j, U_j)`` from the confidence sequence.
        A lower atom is satisfied iff ``L_j > threshold`` (strict, per scheme
        5.3); an upper atom iff ``U_j < threshold``. An empty result means the
        decision is not yet certified.
        """
        satisfied: list[int] = []
        for ci, atom_ids in enumerate(self.certificates):
            ok = True
            for aid in atom_ids:
                lo, hi = bounds[aid]
                atom = self._by_index[aid]
                if atom.kind == ATOM_LOWER:
                    if not (lo > atom.threshold):
                        ok = False
                        break
                else:  # upper
                    if not (hi < atom.threshold):
                        ok = False
                        break
            if ok:
                satisfied.append(ci)
        return satisfied

    def certificate_cohorts(self, ci: int) -> set[str]:
        return {self._by_index[aid].cohort_pair for aid in self.certificates[ci]}
