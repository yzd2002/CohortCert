"""Load, validate and hash the frozen semantic predicates (proposal 4.3 / 10.3).

The predicate file is part of the operator definition: the same text labelled
under a different prompt is a *different* semantic operator, so the prompt is
hashed together with the model settings and that hash travels with every label
snapshot. Validation is mechanical (ids, version pins, required rules, per
dataset counts) -- it never judges whether a predicate is a good business
question, which stays a human decision made before freezing.
"""
from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable

import yaml

__all__ = [
    "DEFAULT_PREDICATE_PATH",
    "MAIN_WORKLOAD_DATASETS",
    "PREDICATE_DATASETS",
    "REQUIRED_PREDICATE_FIELDS",
    "Predicate",
    "PredicateSet",
    "load_predicates",
    "validate_predicates",
    "prompt_hash",
    "render_prompt",
]

DEFAULT_PREDICATE_PATH = Path(__file__).resolve().parents[1] / "configs" / "predicates.yaml"

# The two main datasets the 480-query workload draws from (proposal 4.3: four
# narrow predicates each). "control" is a separate, workload-free dataset whose
# single predicate exists only to score the frozen operator against the
# existing human labels of UCI Sentiment Labelled Sentences (proposal 15.3).
MAIN_WORKLOAD_DATASETS = ("opinrank", "cfpb")
PREDICATE_DATASETS = MAIN_WORKLOAD_DATASETS + ("control",)

REQUIRED_PREDICATE_FIELDS = (
    "id",
    "dataset",
    "question",
    "positive",
    "negative",
    "negation_rule",
    "insufficient_evidence",
    "prompt",
)

#: 4.3: a predicate id must pin a version, matching the contract validator.
_VERSION_RE = re.compile(r"_v\d+$")

#: 10.3: what has to be pinned for a prompt hash to mean anything.
_HASHED_OPERATOR_FIELDS = (
    "model",
    "precision",
    "max_context_tokens",
    "answer_strings",
    "decode_rule",
    "enable_thinking",
)


@dataclass(frozen=True)
class Predicate:
    id: str
    dataset: str
    question: str
    positive: str
    negative: str
    negation_rule: str
    insufficient_evidence: str
    prompt: str

    @classmethod
    def from_dict(cls, d: dict) -> "Predicate":
        missing = [f for f in REQUIRED_PREDICATE_FIELDS if not d.get(f)]
        if missing:
            raise ValueError(f"predicate {d.get('id')!r} missing fields {missing}")
        return cls(**{f: d[f] for f in REQUIRED_PREDICATE_FIELDS})


@dataclass(frozen=True)
class PredicateSet:
    version: int
    operator: dict = field(default_factory=dict)
    predicates: tuple = ()
    source_path: str = ""

    def by_id(self, predicate_id: str) -> Predicate:
        for p in self.predicates:
            if p.id == predicate_id:
                return p
        raise KeyError(f"unknown predicate {predicate_id!r}")

    def for_dataset(self, dataset: str) -> list[Predicate]:
        return [p for p in self.predicates if p.dataset == dataset]

    def ids(self) -> list[str]:
        return [p.id for p in self.predicates]

    def operator_env(self, predicate: "Predicate | None" = None,
                     actual_model: str | None = None,
                     actual_batch_size: int | None = None,
                     decode_mode: str | None = None) -> dict:
        """The 10.3 environment fields, ready for a ``LabelSnapshot``.

        ``predicate`` fills ``prompt_template_hash`` (leave empty only when the
        caller genuinely has no predicate context). ``actual_model`` records
        what really produced the labels when ``--model`` overrode the frozen
        reference operator, so a rehearsal snapshot can never masquerade as an
        8B reference snapshot. ``actual_batch_size`` is mandatory in practice:
        bf16 two-way scoring is not bit-stable across batch shapes, so the
        canonical snapshot is defined for one pinned batch size.

        ``decode_mode`` records *how* the two-way comparison was taken. It is
        written **only when non-default**, for two reasons. (1) The default is
        the restricted first-token comparison described by ``decode_rule``, so
        a snapshot without the key is unambiguously that operator. (2) The key
        is deliberately outside ``OPERATOR_ENV_FIELDS``, so adding it cannot
        change the ``content_hash`` of the 17 snapshots already sealed
        (2026-10-07 lesson: a field that perturbs the hash invalidates the
        whole sealed corpus). Provenance carried this way is *reported*, not
        *sealed*: swapping the label body is still caught, because ``labels``
        is inside the hash.
        """
        op = self.operator
        chunk = op.get("chunk_rule", {})
        env = {
            "model_revision": op.get("model", ""),
            "tokenizer_revision": op.get("model", ""),
            "prompt_template_hash": (
                prompt_hash(predicate, op) if predicate is not None else ""
            ),
            "chunk_rule": (
                f"max_chars={chunk.get('max_chars')};"
                f"overlap={chunk.get('overlap_chars')};"
                f"split_on={chunk.get('split_on')}"
            ),
            "record_result_rule": op.get("record_result_rule", ""),
            "decode_rule": op.get("decode_rule", ""),
            "precision": op.get("precision", ""),
            "max_context_tokens": op.get("max_context_tokens", 0),
            "batch_size": (
                actual_batch_size if actual_batch_size is not None
                else op.get("batch_size", "")
            ),
            "environment_id": f"predicates_v{self.version}",
        }
        if actual_model and actual_model != env["model_revision"]:
            env["model_revision_actual"] = actual_model
            env["tokenizer_revision_actual"] = actual_model
        if decode_mode:
            env["decode_mode"] = decode_mode
        return env

    def chunk_rule(self) -> dict:
        return dict(self.operator.get("chunk_rule", {}))


def load_predicates(path: str | Path = DEFAULT_PREDICATE_PATH) -> PredicateSet:
    """Read the frozen predicate file. Raises on anything structurally wrong."""
    p = Path(path)
    doc = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    errors = validate_predicates(doc)
    if errors:
        raise ValueError(
            f"{p} failed predicate validation:\n  - " + "\n  - ".join(errors)
        )
    return PredicateSet(
        version=int(doc.get("version", 0)),
        operator=doc.get("operator", {}) or {},
        predicates=tuple(Predicate.from_dict(d) for d in doc.get("predicates", [])),
        source_path=str(p),
    )


def validate_predicates(doc: dict) -> list[str]:
    """Return problems with a predicate document; empty means it can be frozen."""
    errors: list[str] = []
    if not isinstance(doc, dict):
        return ["predicate document must be a mapping"]

    op = doc.get("operator") or {}
    for f in ("model", "answer_strings", "chunk_rule", "record_result_rule"):
        if f not in op:
            errors.append(f"operator block missing {f!r}")
    if op.get("answer_strings") and len(op["answer_strings"]) != 2:
        errors.append("operator.answer_strings must contain exactly two strings")

    preds = doc.get("predicates") or []
    if not isinstance(preds, list) or not preds:
        errors.append("no predicates defined")
        return errors

    seen: set[str] = set()
    counts: dict[str, int] = {}
    for d in preds:
        pid = d.get("id", "<no id>")
        missing = [f for f in REQUIRED_PREDICATE_FIELDS if not d.get(f)]
        if missing:
            errors.append(f"predicate {pid!r} missing {missing}")
            continue
        if not _VERSION_RE.search(pid):
            errors.append(f"predicate id {pid!r} must pin a version, e.g. '_v1'")
        if pid in seen:
            errors.append(f"duplicate predicate id {pid!r}")
        seen.add(pid)
        if d.get("dataset") not in PREDICATE_DATASETS:
            errors.append(
                f"predicate {pid!r} has unknown dataset {d.get('dataset')!r}; "
                f"expected one of {PREDICATE_DATASETS}"
            )
        else:
            counts[d["dataset"]] = counts.get(d["dataset"], 0) + 1

    # 4.3: exactly four narrow predicates per main workload dataset. The
    # control dataset is exempt: it carries exactly one operator-scoring
    # predicate and is never referenced by the query workload.
    for ds in MAIN_WORKLOAD_DATASETS:
        if counts.get(ds, 0) != 4:
            errors.append(
                f"dataset {ds!r} has {counts.get(ds, 0)} predicates; proposal 4.3 requires 4"
            )
    if counts.get("control", 0) != 1:
        errors.append(
            f"dataset 'control' has {counts.get('control', 0)} predicates; expected exactly 1"
        )
    return errors


def prompt_hash(predicate: Predicate, operator: dict | None = None) -> str:
    """Hash the prompt together with the operator settings that shape it.

    Two runs with the same text but a different prompt or decoding rule are two
    different operators; the hash makes that visible instead of debatable.
    """
    op = operator or {}
    payload = {
        "predicate_id": predicate.id,
        "prompt": " ".join(predicate.prompt.split()),
        "operator": {
            f: op.get(f) for f in _HASHED_OPERATOR_FIELDS if f in op
        },
        "chunk_rule": op.get("chunk_rule"),
        "record_result_rule": op.get("record_result_rule"),
    }
    blob = repr(sorted(payload.items(), key=lambda kv: kv[0])).encode("utf-8")
    return hashlib.sha256(blob).hexdigest()


def render_prompt(predicate: Predicate, text: str) -> str:
    """The exact string sent to the model: instruction, then the record text.

    Data and instruction are kept in separate blocks so record text cannot
    silently extend the instruction (proposal 22, prompt-injection hygiene).
    """
    return (
        "INSTRUCTION:\n"
        + " ".join(predicate.prompt.split())
        + "\n\nRECORD TEXT:\n"
        + (text or "")
        + "\n\nANSWER (single digit):"
    )
