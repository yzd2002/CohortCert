"""Production snapshot backend over the frozen parquet populations.

``MemorySnapshot`` is a test double; this is the one that talks to the real
frozen populations in ``data/cohorts/``. It implements the same
:class:`~query.snapshot.Snapshot` protocol, so the compiler and the whole
pipeline are unchanged -- only the source of "which records belong to a cohort"
differs.

Two facts drive the design:

* **Known denominators are the precondition for finite-population confidence
  sequences** (scheme 5.2). Cohort membership must be computable exactly from
  structured metadata, never estimated from the semantic predicate.
* **This machine has 17 GB of RAM** (scheme assumes >= 64 GB), so the backend
  loads one column at a time and never materialises the full table. Columns are
  cached because a query touches the same few fields repeatedly.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Iterable, Mapping, Sequence

import pyarrow.parquet as pq

from query.snapshot import (
    ALLOWED_AST_OPS,
    COMPARISON_AST_OPS,
    Snapshot,
    _compare,
    parse_ast_op,
)

__all__ = ["ParquetSnapshot", "load_snapshot", "DEFAULT_MANIFEST"]

DEFAULT_MANIFEST = Path(__file__).resolve().parents[1] / "data" / "cohorts" / "snapshot_manifest.json"


class ParquetSnapshot:
    """A frozen record population stored as parquet.

    Only the restricted AST operations of scheme 10.2 are supported, so a cohort
    is always a mechanically determined subset of a finite population -- which
    is what makes its size a *known* denominator.
    """

    def __init__(
        self,
        path: str | Path,
        record_id_field: str = "record_id",
        text_field: str = "text",
    ) -> None:
        self.path = Path(path)
        if not self.path.exists():
            raise FileNotFoundError(f"snapshot parquet not found: {self.path}")
        self.record_id_field = record_id_field
        self.text_field = text_field

        pf = pq.ParquetFile(self.path)
        self.population_size = int(pf.metadata.num_rows)
        self.schema_fields = [n for n in pf.schema_arrow.names]
        self._columns: dict[str, list] = {}
        # Membership depends only on this frozen snapshot and cohort AST.
        self._cohort_cache: dict[str, set] = {}

    # -- column access -----------------------------------------------------

    def _column(self, field: str) -> list:
        """Load one column, once. Never the whole table."""
        if field not in self.schema_fields:
            raise KeyError(
                f"field {field!r} not in snapshot schema {self.schema_fields}"
            )
        if field not in self._columns:
            table = pq.read_table(self.path, columns=[field])
            self._columns[field] = table.column(field).to_pylist()
        return self._columns[field]

    def record_ids(self) -> list:
        return self._column(self.record_id_field)

    # -- Snapshot protocol -------------------------------------------------

    def evaluate_filter(self, ast: dict) -> set:
        op, args = parse_ast_op(ast)
        if op not in ALLOWED_AST_OPS:
            raise ValueError(f"disallowed AST op: {op}")

        ids = self._column(self.record_id_field)
        if op == "in":
            field, values = args[0], set(args[1])
            col = self._column(field)
            return {rid for rid, v in zip(ids, col) if v in values}
        if op == "eq":
            field, val = args[0], args[1]
            col = self._column(field)
            return {rid for rid, v in zip(ids, col) if v == val}
        if op == "ne":
            field, val = args[0], args[1]
            col = self._column(field)
            # missing (None) matches no value; see MemorySnapshot for rationale
            return {rid for rid, v in zip(ids, col) if v is not None and v != val}
        if op in COMPARISON_AST_OPS:
            field, bound = args[0], args[1]
            col = self._column(field)
            return {rid for rid, v in zip(ids, col) if _compare(v, bound, op)}
        if op == "and":
            result: set | None = None
            for sub in args:
                s = self.evaluate_filter(sub)
                result = s if result is None else (result & s)
            return result or set()
        if op == "or":
            result: set = set()
            for sub in args:
                result |= self.evaluate_filter(sub)
            return result
        if op == "not":
            return set(ids) - self.evaluate_filter(args[0])
        raise ValueError(f"unknown op {op}")

    def cohort_records(self, cohort: dict) -> set:
        # Repeated compilation within one frozen snapshot has identical cohort
        # membership. Return a copy so callers cannot mutate the cached set.
        try:
            key = json.dumps(cohort, sort_keys=True, separators=(",", ":"))
        except (TypeError, ValueError):
            return self._cohort_records_uncached(cohort)
        if key not in self._cohort_cache:
            result = self._cohort_records_uncached(cohort)
            if len(self._cohort_cache) >= 256:
                self._cohort_cache.clear()
            self._cohort_cache[key] = result.copy()
            return result
        return self._cohort_cache[key].copy()

    def _cohort_records_uncached(self, cohort: dict) -> set:
        if cohort.get("record_ids") is not None:
            requested = set(cohort["record_ids"])
            known = set(self._column(self.record_id_field))
            unknown = requested - known
            if unknown:
                # 5.2: the known denominator is what makes the finite-population
                # guarantee meaningful. A cohort naming ids outside the frozen
                # population would inflate the denominator and every
                # coefficient compiled from it -- reject at parse time (10.2).
                from query.contract_schema import ContractUnsupported

                sample = sorted(unknown)[:5]
                raise ContractUnsupported(
                    f"cohort record_ids not in the frozen population "
                    f"({len(unknown)} unknown, e.g. {sample})"
                )
            return requested
        if "filter_ast" not in cohort:
            raise ValueError("cohort must carry 'filter_ast' or 'record_ids'")
        return self.evaluate_filter(cohort["filter_ast"])

    # -- record text for the operator and for quotes -----------------------

    def texts(self, record_ids: Sequence[str] | None = None) -> dict:
        """Return ``{record_id: text}`` for the requested records.

        Loaded on first use and cached for the process lifetime. Parquet is
        columnar, so the text column is materialized whole (~100-200 MB for
        the frozen snapshots, well inside the 17 GB host budget) and then
        sliced per request; per-row lazy loading is not available without a
        row-group rewrite. The ids argument restricts the *returned* mapping,
        and absent ids raise.
        """
        ids = self._column(self.record_id_field)
        if record_ids is None:
            return {rid: t for rid, t in zip(ids, self._column(self.text_field))}
        wanted = set(map(str, record_ids))
        out: dict = {}
        text_col = self._column(self.text_field)
        for rid, t in zip(ids, text_col):
            if rid in wanted:
                out[rid] = t
        missing = wanted - set(out)
        if missing:
            raise KeyError(f"{len(missing)} record id(s) absent from snapshot, e.g. {sorted(missing)[:3]}")
        return out

    def values(self, field: str, record_ids: Iterable[str] | None = None) -> dict:
        """Structured field values, for building cohorts and reporting groups."""
        ids = self._column(self.record_id_field)
        col = self._column(field)
        if record_ids is None:
            return dict(zip(ids, col))
        wanted = set(map(str, record_ids))
        return {rid: v for rid, v in zip(ids, col) if rid in wanted}


def load_snapshot(
    dataset: str,
    manifest_path: str | Path | None = None,
    **kwargs,
) -> ParquetSnapshot:
    """Open a frozen population by dataset name from the snapshot manifest."""
    # Resolved at call time (not as a default argument) so the manifest path
    # can be redirected in tests.
    manifest = json.loads(Path(manifest_path or DEFAULT_MANIFEST).read_text(encoding="utf-8"))
    pops = manifest.get("populations", {})
    if dataset not in pops:
        raise KeyError(f"dataset {dataset!r} not in manifest; have {sorted(pops)}")
    entry = pops[dataset]
    path = entry.get("path") or entry.get("parquet")
    if not path:
        raise KeyError(f"manifest entry for {dataset!r} has no parquet path")
    # Manifest paths are written relative to the project root on whichever OS
    # produced them; normalise both separators.
    p = Path(str(path).replace("\\", "/"))
    if not p.is_absolute():
        p = Path(__file__).resolve().parents[1] / p
    return ParquetSnapshot(p, **kwargs)


def _assert_protocol(snapshot: Snapshot) -> None:  # pragma: no cover
    """Type-level reminder: this must satisfy the Snapshot protocol."""
    assert isinstance(snapshot, Snapshot)
