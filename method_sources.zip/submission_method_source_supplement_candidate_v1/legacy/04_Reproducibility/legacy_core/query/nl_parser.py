"""Natural language to restricted-AST front end (proposal 10.1 / 10.2, G6).

The pipeline has always been fed hand-written contracts. This module closes the
front door: it turns a request sentence into the same typed contract, so the
system is driven by language rather than by a dict someone typed.

It is deliberately **not** a language model. The grammar is a fixed set of
slots -- entity values, a time window, a predicate, a decision type, a
threshold -- and every slot is resolved against a closed vocabulary. Proposal
10.2 says the model "only generates a restricted AST"; here the restriction is
enforced structurally:

* entity values must exist in the snapshot's own vocabulary, so a hallucinated
  group cannot enter a cohort;
* the predicate must be one of the frozen eight, matched on its exact question
  text, so a plausible-sounding predicate cannot smuggle in a new definition;
* the decision type must be one of the five the compiler knows;
* the result is passed through ``validate_contract`` before it is returned.

Anything that does not resolve becomes ``ContractUnsupported`` with a reason.
That is the intended failure mode: an unparsed request is an ``unsupported``
answer, never a guess that quietly becomes a certificate.

What this is *not* claiming
---------------------------
It does not solve open-vocabulary NL understanding. It parses the request
language this project's own workload generator emits, plus reasonable
variations of it, and refuses everything else. Reporting the refusal rate on
the generated workload is part of the evaluation (proposal 15.2: the workload is
executable synthetic text, and that must be said plainly).
"""
from __future__ import annotations

import re
from typing import Iterable, Mapping, Sequence

from query.contract_schema import ContractUnsupported, validate_contract

__all__ = [
    "build_vocabulary",
    "parse_request",
    "ParseResult",
]

_ENTITY_RE = re.compile(r"([A-Za-z_][A-Za-z0-9_]*)\s*=\s*")
_DATE_RE = re.compile(r"\d{4}-\d{2}-\d{2}")
_POINTS_RE = re.compile(
    r"(?:at\s+least\s+)?([\d]+(?:\.[\d]+)?)\s*(?:percentage\s+)?points?", re.I
)
_SUMMARY_ITEM_RE = re.compile(
    r"([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s+vs\s+"
    r"([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*\(([><])?\s*([\d.]+)\s*points?\)"
)


class ParseResult:
    """What the parser resolved, so a refusal can explain itself."""

    def __init__(self, contract=None, predicate_id="", entities=(), window=None,
                 decision="", reason=""):
        self.contract = contract
        self.predicate_id = predicate_id
        self.entities = list(entities)
        self.window = window
        self.decision = decision
        self.reason = reason

    @property
    def ok(self) -> bool:
        return self.contract is not None


def build_vocabulary(snapshot, fields: Sequence[str] | None = None,
                     max_values: int = 4000) -> dict[str, set]:
    """Distinct values per schema field, for closed-vocabulary entity matching.

    Fields with more than ``max_values`` distinct values are skipped: they are
    identifiers rather than group names, and a cohort keyed on one is not a
    "group" in any sense the decision contract cares about.
    """
    fields = list(fields or getattr(snapshot, "schema_fields", []) or [])
    out: dict[str, set] = {}
    for f in fields:
        try:
            col = snapshot._column(f)  # both snapshot backends expose this
        except Exception:  # noqa: BLE001 - vocabulary is best-effort
            continue
        vals: set = set()
        for v in col:
            if v is None or v == "":
                continue
            vals.add(str(v))
            if len(vals) > max_values:
                break
        if vals and len(vals) <= max_values:
            out[f] = vals
    return out


def _match_entities(text: str, vocabulary: Mapping[str, Iterable],
                    aliases: Mapping[str, str] | None = None):
    """Resolve ``field=value`` mentions against the closed vocabulary.

    Longest value wins, so ``product=Checking or savings account`` is not
    shadowed by a shorter overlapping value. Matches keep their order of first
    appearance in the text, which is what makes ``left``/``right`` meaningful.

    ``aliases`` maps a *display* name used in prose to the real schema field
    (``{"hotel": "hotel_id"}``). The alias is accepted on input but the produced
    AST always carries the real field name, so the display wording can never
    leak into a filter.
    """
    aliases = dict(aliases or {})
    hits: list[tuple[int, str, str]] = []
    for field, values in vocabulary.items():
        names = {field} | {a for a, f in aliases.items() if f == field}
        for v in values:
            for name in names:
                pos = text.find(f"{name}={v}")
                if pos >= 0:
                    hits.append((pos, field, v))
                    break
    # Drop shadowed matches: if a longer value at the same field starts here,
    # the shorter one is a prefix artifact.
    hits.sort(key=lambda h: (h[0], -len(h[2])))
    kept: list[tuple[int, str, str]] = []
    for pos, field, v in hits:
        if any(k[0] == pos and k[1] == field and len(k[2]) >= len(v) for k in kept):
            continue
        kept.append((pos, field, v))
    kept.sort(key=lambda h: h[0])
    return [(f, v) for _, f, v in kept]


def _match_predicate(text: str, predicates):
    """Match the frozen predicate by its exact question text (longest first)."""
    best, best_len = None, 0
    for p in predicates:
        q = (p.question or "").strip()
        if q and q in text and len(q) > best_len:
            best, best_len = p, len(q)
        if p.id in text and len(p.id) > best_len:
            best, best_len = p, len(p.id)
    return best


def _time_bounds(text: str):
    dates = _DATE_RE.findall(text)
    if len(dates) >= 2:
        lo, hi = sorted(dates[:2])
        return lo, hi
    return None


def _pp(text: str) -> float | None:
    m = _POINTS_RE.search(text)
    if not m:
        return None
    try:
        return float(m.group(1)) / 100.0
    except ValueError:
        return None


def _looks_iso_dates(values: Iterable) -> bool:
    """True when the column's values can be compared against an ISO date.

    A snapshot can carry several date-ish columns -- a raw string as published
    and a parsed ISO one. Comparing a raw column against ``2024-01-01`` silently
    yields an empty cohort, which would look like "no data" rather than the bug
    it is, so the choice is made on evidence instead of on the field name.
    """
    checked = 0
    for v in values:
        if v is None or v == "":
            continue
        if _DATE_RE.fullmatch(str(v).strip()):
            return True
        checked += 1
        if checked >= 50:
            break
    return False


def _time_field(snapshot, explicit: str | None) -> str | None:
    if explicit:
        return explicit
    candidates = [
        f for f in getattr(snapshot, "schema_fields", []) or []
        if "date" in f.lower() or f.lower().endswith("_at")
    ]
    for f in candidates:
        try:
            if _looks_iso_dates(snapshot._column(f)):
                return f
        except Exception:  # noqa: BLE001 - best-effort field probing
            continue
    return candidates[0] if candidates else None


def parse_request(
    text: str,
    snapshot=None,
    predicates=None,
    vocabulary: Mapping[str, Iterable] | None = None,
    field_aliases: Mapping[str, str] | None = None,
    snapshot_id: str = "",
    alpha: float = 0.05,
    budget: int = 1024,
    time_field: str | None = None,
    default_direction_threshold: float = 0.0,
    validate: bool = True,
) -> ParseResult:
    """Parse a request sentence into a typed contract.

    Raises :class:`ContractUnsupported` when a required slot cannot be resolved
    -- including when ``validate=True`` and the snapshot rejects the contract.
    """
    text = " ".join(str(text).split())
    if not text:
        raise ContractUnsupported("empty request")

    if predicates is None:
        from query.predicates import load_predicates

        predicates = list(load_predicates().predicates)
    preds = list(getattr(predicates, "predicates", predicates))

    if vocabulary is None:
        if snapshot is None:
            raise ContractUnsupported(
                "no vocabulary: pass one, or a snapshot to derive it from"
            )
        vocabulary = build_vocabulary(snapshot)
    if field_aliases is None:
        field_aliases = {}

    predicate = _match_predicate(text, preds)
    if predicate is None:
        raise ContractUnsupported(
            "no frozen predicate matched the request text"
        )

    entities = _match_entities(text, vocabulary, field_aliases)
    if not entities:
        raise ContractUnsupported("no known entity values found in the request")

    window = _time_bounds(text)
    tf = _time_field(snapshot, time_field)
    if window is not None and tf is None:
        window = None  # cannot express a time window without a time field

    def cohort_filter(field: str, value: str):
        parts = [{"eq": [field, value]}]
        if window is not None:
            parts.append({"ge": [tf, window[0]]})
            parts.append({"le": [tf, window[1]]})
        return {"and": parts} if len(parts) > 1 else parts[0]

    # Stable cohort order = order of first appearance.
    seen: list[tuple[str, str]] = []
    for f, v in entities:
        if (f, v) not in seen:
            seen.append((f, v))
    cohorts = [
        {
            "id": f"g{j + 1}",
            "filter_ast": cohort_filter(f, v),
            "label": f"{f}={v}",
        }
        for j, (f, v) in enumerate(seen)
    ]
    ids = [c["id"] for c in cohorts]
    lower = text.lower()

    # --- summary: several comparisons declared up front --------------------
    # Both wordings appear in the workload ("requested in advance" / "declared
    # in advance"); matching only one silently downgrades a bundle to a single
    # comparison, which is a contract change, not a parse detail.
    if "in advance" in lower and ("comparison" in lower or "comparisons" in lower):
        items = _SUMMARY_ITEM_RE.findall(text)
        if not items:
            raise ContractUnsupported(
                "summary request declared but no parsable 'X vs Y (>N points)' items"
            )
        decisions = []
        def _resolve(name: str, value: str):
            """Alias-tolerant lookup of an entity in ``seen``."""
            field = field_aliases.get(name, name)
            for i, (f, v) in enumerate(seen):
                if f == field and v == value:
                    return i
            return None

        for _f1, _v1, _f2, _v2, _rel, num in items:
            try:
                thr = float(num) / 100.0
            except ValueError:
                raise ContractUnsupported(f"unparsable threshold in summary item {num!r}")
            li = _resolve(_f1, _v1.strip())
            ri = _resolve(_f2, _v2.strip())
            if li is None or ri is None:
                raise ContractUnsupported(
                    "summary item references an entity not in the request"
                )
            decisions.append({
                "type": "compare", "left": ids[li], "right": ids[ri],
                "threshold": thr, "unit": "proportion_difference",
            })
        decision_kind = "summary"
        if not (3 <= len(decisions) <= 6):
            raise ContractUnsupported(
                f"summary must declare 3-6 judgements, got {len(decisions)}"
            )

    # --- ranking -----------------------------------------------------------
    elif "highest" in lower and ("which" in lower or "rank" in lower):
        m = re.search(r"which\s+(\d+)\s+of\s+these", lower)
        k = int(m.group(1)) if m else 1
        if k == 1:
            decisions = [{"type": "top1", "candidates": ids}]
        else:
            decisions = [{"type": "topk", "candidates": ids, "k": k}]
        decision_kind = "ranking"

    # --- equivalence -------------------------------------------------------
    elif "within" in lower and "of each other" in lower:
        tol = _pp(text)
        if tol is None:
            tol = 0.0
        if len(ids) < 2:
            raise ContractUnsupported("equivalence needs two cohorts")
        decisions = [{
            "type": "equivalence", "left": ids[0], "right": ids[1],
            "tolerance": tol, "unit": "proportion_difference",
        }]
        decision_kind = "equivalence"

    # --- direction ---------------------------------------------------------
    elif "more common" in lower or "more frequent" in lower:
        if len(ids) < 2:
            raise ContractUnsupported("direction needs two cohorts")
        # "more common" alone does not pin a threshold; if the request states
        # one, honour it, otherwise fall back to the declared default. Either
        # way the threshold is written into the contract so it is auditable --
        # a direction judgement with an unspecified threshold is not a
        # well-formed question.
        thr = _pp(text)
        decisions = [{
            "type": "direction", "left": ids[0], "right": ids[1],
            "threshold": default_direction_threshold if thr is None else thr,
            "unit": "proportion_difference",
        }]
        decision_kind = "direction"

    # --- compare -----------------------------------------------------------
    else:
        thr = _pp(text)
        if thr is None:
            thr = 0.0
        if len(ids) < 2:
            raise ContractUnsupported("comparison needs two cohorts")
        decisions = [{
            "type": "compare", "left": ids[0], "right": ids[1],
            "threshold": thr, "unit": "proportion_difference",
        }]
        decision_kind = "compare"

    contract = {
        "snapshot_id": snapshot_id or f"{predicate.dataset}_v1",
        "predicate_id": predicate.id,
        "cohorts": cohorts,
        "decisions": decisions,
        "risk": {"alpha": alpha, "scope": "this_request"},
        "budget": {"max_oracle_record_predicate_calls": int(budget)},
        "population_scope": "the_frozen_public_corpus",
    }

    if validate and snapshot is not None:
        ok, reason = validate_contract(contract, snapshot)
        if not ok:
            raise ContractUnsupported(f"parsed contract rejected: {reason}")

    return ParseResult(
        contract=contract, predicate_id=predicate.id,
        entities=seen, window=window, decision=decision_kind,
    )
