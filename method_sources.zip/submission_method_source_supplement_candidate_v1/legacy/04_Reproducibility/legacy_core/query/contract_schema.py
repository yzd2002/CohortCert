"""Query contract schema and the deterministic validator.

The contract is the *only* structured input the system accepts. The language
model (or a parser) produces a restricted AST + typed contract; this module
mechanically checks that the contract is well-formed and resolvable against the
frozen snapshot. Anything it cannot verify is returned as ``unsupported``
rather than silently mis-executed (scheme 10.2).

The validator never judges semantic truth -- it only guarantees that the
output contract can be executed and that fields, cohorts, units, predicate
versions, candidate counts and budgets are internally consistent.
"""
from __future__ import annotations

import re
from typing import Any

from query.snapshot import ALLOWED_AST_OPS, COMPARISON_AST_OPS, Snapshot

# Decision types the compiler understands.
DECISION_TYPES = {"compare", "direction", "equivalence", "top1", "topk"}

# Proportion units explicitly sanctioned by the contract spec.
ALLOWED_UNITS = {"proportion_difference"}

# Upper bound on the number of candidate cohorts in a ranking decision
# (scheme 5.3: "候选数限制为不超过 8").
MAX_CANDIDATES = 8

# A multi-judgement summary request carries 3-6 declared comparisons
# (scheme 15.1). Single-decision contracts remain valid for the paired and
# ranking query families; bundles are what the summary family produces.
MAX_BUNDLE_DECISIONS = 6

# Guard against a bundle that explodes the certificate family (6 x top1 over 8
# candidates is already 336 atoms). Anything beyond this is refused up front
# rather than silently burning the budget on an unresolvable family.
MAX_BUNDLE_ATOMS = 512

# A predicate id must pin a version so the operator semantics are reproducible.
PREDICATE_VERSION_RE = re.compile(r"_v\d+$")

# Top-level required keys. A contract carries either 'decision' (one) or
# 'decisions' (a bundle); that alternative is checked in normalize_decisions.
_REQUIRED_KEYS = {
    "snapshot_id",
    "predicate_id",
    "cohorts",
    "risk",
    "budget",
    "population_scope",
}


def normalize_decisions(contract: dict) -> list[dict]:
    """Return the contract's decision blocks as a list (scheme 15.1).

    A *bundle* is one request that declares 3-6 comparisons up front. The
    contract must name every judgement before execution: picking the
    significant ones after seeing the results is exactly what the scheme
    forbids (15.1). Single-decision contracts are still valid and are returned
    as a one-element list, so every downstream consumer sees the same shape.
    """
    if "decisions" in contract and "decision" in contract:
        raise ContractUnsupported("contract carries both 'decision' and 'decisions'")
    if "decisions" in contract:
        blocks = contract["decisions"]
        if not isinstance(blocks, list) or not blocks:
            raise ContractUnsupported("'decisions' must be a non-empty list")
        if len(blocks) > MAX_BUNDLE_DECISIONS:
            raise ContractUnsupported(
                f"bundle declares {len(blocks)} decisions, "
                f"max is {MAX_BUNDLE_DECISIONS}"
            )
        for d in blocks:
            if not isinstance(d, dict) or "type" not in d:
                raise ContractUnsupported("each decision in 'decisions' needs a 'type'")
        return list(blocks)
    if "decision" in contract:
        d = contract["decision"]
        if not isinstance(d, dict) or "type" not in d:
            raise ContractUnsupported("decision must be an object with 'type'")
        return [d]
    raise ContractUnsupported("contract must carry 'decision' or 'decisions'")


class ContractUnsupported(Exception):
    """Raised when a contract cannot be mechanically validated.

    The pipeline catches this and returns ``unsupported`` to the caller
    instead of attempting execution.
    """

    def __init__(self, reason: str):
        super().__init__(reason)
        self.reason = reason


def _walk_ast(ast: Any, schema_fields: list[str]) -> None:
    """Validate an AST node for allowed ops and field existence only.

    Does not evaluate the filter -- it just proves the contract is
    mechanically resolvable and references only declared schema fields.
    """
    if not isinstance(ast, dict):
        raise ContractUnsupported(f"filter AST node must be a dict, got {type(ast).__name__}")
    if "op" in ast:
        op = ast["op"]
        args = ast.get("args", [])
    elif len(ast) == 1:
        op = next(iter(ast))
        args = ast[op]
    else:
        raise ContractUnsupported(f"ambiguous AST node: {list(ast)}")
    if op not in ALLOWED_AST_OPS:
        raise ContractUnsupported(f"disallowed AST operation '{op}'")
    if op in ("in", "eq", "ne") or op in COMPARISON_AST_OPS:
        if not args or not isinstance(args[0], str):
            raise ContractUnsupported(f"op '{op}' requires a field name as first argument")
        if args[0] not in schema_fields:
            raise ContractUnsupported(
                f"field '{args[0]}' not in snapshot schema {schema_fields}"
            )
        if op in COMPARISON_AST_OPS:
            if len(args) != 2 or args[1] is None or isinstance(args[1], (dict, list)):
                raise ContractUnsupported(
                    f"op '{op}' requires an orderable bound as second argument"
                )
        if op == "in":
            # the snapshot backend does set(args[1]); an unhashable member or a
            # non-list second argument would raise TypeError mid-evaluation and
            # take the whole sweep down instead of returning unsupported (10.2)
            if len(args) != 2 or not isinstance(args[1], list):
                raise ContractUnsupported(
                    "op 'in' requires a list of values as second argument"
                )
            if any(isinstance(v, (dict, list)) for v in args[1]):
                raise ContractUnsupported(
                    "op 'in' values must be scalars (dict/list members are not hashable)"
                )
    elif op in ("and", "or"):
        if not isinstance(args, list) or not args:
            raise ContractUnsupported(f"op '{op}' requires a non-empty list of sub-nodes")
        for sub in args:
            _walk_ast(sub, schema_fields)
    elif op == "not":
        if not isinstance(args, list) or len(args) != 1:
            raise ContractUnsupported("op 'not' requires exactly one sub-node")
        _walk_ast(args[0], schema_fields)


def validate_contract(contract: dict, snapshot: Snapshot) -> tuple[bool, str | None]:
    """Return ``(ok, reason)``. ``ok=False`` means the contract is unsupported."""
    try:
        _check_structure(contract, snapshot)
        return True, None
    except ContractUnsupported as e:
        return False, e.reason


def _check_structure(contract: dict, snapshot: Snapshot) -> None:
    if not isinstance(contract, dict):
        raise ContractUnsupported("contract must be an object")
    missing = _REQUIRED_KEYS - set(contract)
    if missing:
        raise ContractUnsupported(f"contract missing keys: {sorted(missing)}")

    snapshot_id = contract["snapshot_id"]
    if not isinstance(snapshot_id, str) or not snapshot_id:
        raise ContractUnsupported("snapshot_id must be a non-empty string")

    predicate_id = contract["predicate_id"]
    if not isinstance(predicate_id, str) or not PREDICATE_VERSION_RE.search(predicate_id):
        raise ContractUnsupported(
            f"predicate_id must pin a version (e.g. '..._v1'), got {predicate_id!r}"
        )

    population_scope = contract["population_scope"]
    if not isinstance(population_scope, str) or not population_scope:
        raise ContractUnsupported("population_scope must be a non-empty string")

    # --- cohorts ---------------------------------------------------------
    cohorts = contract["cohorts"]
    if not isinstance(cohorts, list) or not cohorts:
        raise ContractUnsupported("cohorts must be a non-empty list")
    cohort_ids: list[str] = []
    for c in cohorts:
        if not isinstance(c, dict) or "id" not in c:
            raise ContractUnsupported("each cohort needs an 'id'")
        cid = c["id"]
        if not isinstance(cid, str) or not cid:
            raise ContractUnsupported("cohort id must be a non-empty string")
        if cid in cohort_ids:
            raise ContractUnsupported(f"duplicate cohort id '{cid}'")
        has_ast = "filter_ast" in c and c["filter_ast"] is not None
        has_ids = "record_ids" in c and c["record_ids"] is not None
        if not (has_ast or has_ids):
            raise ContractUnsupported(f"cohort '{cid}' needs filter_ast or record_ids")
        if has_ast:
            _walk_ast(c["filter_ast"], snapshot.schema_fields)
        # Non-empty group (the "known denominator" precondition).
        recs = snapshot.cohort_records(c)
        if len(recs) == 0:
            raise ContractUnsupported(f"cohort '{cid}' resolves to an empty group")
        cohort_ids.append(cid)

    cohort_set = set(cohort_ids)

    # --- decisions (one, or a declared bundle) ---------------------------
    blocks = normalize_decisions(contract)
    atom_estimate = 0
    for d in blocks:
        dtype = d["type"]
        if dtype not in DECISION_TYPES:
            raise ContractUnsupported(f"unsupported decision type '{dtype}'")
        if dtype in ("compare", "direction", "equivalence"):
            _check_pair_decision(d, cohort_set)
            atom_estimate += 2 if dtype == "equivalence" else 1
        else:  # top1 / topk
            _check_ranking_decision(d, cohort_set)
            m = len(d["candidates"])
            atom_estimate += m * (m - 1)
    if atom_estimate > MAX_BUNDLE_ATOMS:
        raise ContractUnsupported(
            f"decision bundle expands to {atom_estimate} atoms, "
            f"max is {MAX_BUNDLE_ATOMS}"
        )

    # --- risk ------------------------------------------------------------
    risk = contract["risk"]
    if not isinstance(risk, dict) or "alpha" not in risk:
        raise ContractUnsupported("risk must carry 'alpha'")
    alpha = risk["alpha"]
    if not isinstance(alpha, (int, float)) or not (0.0 < float(alpha) < 1.0):
        raise ContractUnsupported(f"alpha must be in (0,1), got {alpha!r}")

    # --- budget ----------------------------------------------------------
    budget = contract["budget"]
    if not isinstance(budget, dict) or "max_oracle_record_predicate_calls" not in budget:
        raise ContractUnsupported("budget must carry 'max_oracle_record_predicate_calls'")
    cap = budget["max_oracle_record_predicate_calls"]
    if not isinstance(cap, int) or isinstance(cap, bool) or cap <= 0:
        raise ContractUnsupported(
            f"max_oracle_record_predicate_calls must be a positive int, got {cap!r}"
        )

    # Finite population must be positive (known denominators require it).
    if not isinstance(snapshot.population_size, int) or snapshot.population_size <= 0:
        raise ContractUnsupported("snapshot.population_size must be a positive int")


def _check_pair_decision(decision: dict, cohort_set: set) -> None:
    left = decision.get("left")
    right = decision.get("right")
    if left not in cohort_set or right not in cohort_set:
        raise ContractUnsupported(
            f"compare cohorts {left!r}/{right!r} not declared in cohorts"
        )
    unit = decision.get("unit")
    if unit not in ALLOWED_UNITS:
        raise ContractUnsupported(f"unit must be one of {sorted(ALLOWED_UNITS)}, got {unit!r}")
    if decision["type"] == "equivalence":
        if "tolerance" not in decision:
            raise ContractUnsupported("equivalence decision requires 'tolerance'")
        if not isinstance(decision["tolerance"], (int, float)) or decision["tolerance"] <= 0:
            raise ContractUnsupported("tolerance must be a positive number")
        if abs(decision["tolerance"]) > 1.0:
            # 5.3: b_j=0.02 means two percentage points, not 200%. A
            # proportion-difference threshold is a number in [-1, 1];
            # anything larger is a unit error, not a business tolerance.
            raise ContractUnsupported(
                "tolerance is a proportion difference and must be within [-1, 1]"
            )
    else:
        if "threshold" not in decision:
            raise ContractUnsupported(f"{decision['type']} decision requires 'threshold'")
        if not isinstance(decision["threshold"], (int, float)):
            raise ContractUnsupported("threshold must be a number")
        if abs(decision["threshold"]) > 1.0:
            raise ContractUnsupported(
                "threshold is a proportion difference and must be within [-1, 1]"
            )


def _check_ranking_decision(decision: dict, cohort_set: set) -> None:
    cands = decision.get("candidates")
    if not isinstance(cands, list) or not cands:
        raise ContractUnsupported("ranking decision requires a non-empty 'candidates' list")
    for c in cands:
        if c not in cohort_set:
            raise ContractUnsupported(f"candidate '{c}' not declared in cohorts")
    if len(cands) != len(set(cands)):
        raise ContractUnsupported("candidates list contains duplicates")
    if len(cands) > MAX_CANDIDATES:
        raise ContractUnsupported(
            f"candidate count {len(cands)} exceeds MAX_CANDIDATES={MAX_CANDIDATES}"
        )
    if decision["type"] == "topk":
        k = decision.get("k")
        if not isinstance(k, int) or k <= 0 or k >= len(cands):
            raise ContractUnsupported(
                f"topk 'k' must be an int with 0 < k < {len(cands)}, got {k!r}"
            )
        if "topk_set" in decision:
            s = decision["topk_set"]
            if not isinstance(s, list) or len(s) != k or set(s) - set(cands):
                raise ContractUnsupported("topk_set must be a length-k subset of candidates")
