"""Snapshot protocol and an in-memory implementation used by the compiler and
its tests.

Production snapshots (built from frozen parquet cohorts) implement the same
``Snapshot`` protocol. The compiler depends only on the protocol, never on
parquet or any other storage format, so it stays GPU-independent and testable.
"""
from __future__ import annotations

from typing import Protocol, runtime_checkable
import math


# Operations a query contract is allowed to use when constructing cohorts.
# Anything outside this set must be rejected by the validator (scheme 10.2:
# "language model only generates a restricted AST").
#
# The comparison operators exist because scheme 15.1 separates train / dev /
# test by *time range* as well as by entity: without them a cohort cannot
# express "complaints received in this window", and the split would leak.
# They are still total functions over one field, so a cohort remains a
# mechanically determined subset with a known denominator.
ALLOWED_AST_OPS = {"in", "eq", "ne", "and", "or", "not", "ge", "le", "gt", "lt"}

#: Operators that take (field, bound) and compare orderable values.
COMPARISON_AST_OPS = {"ge", "le", "gt", "lt"}


@runtime_checkable
class Snapshot(Protocol):
    """What the compiler needs from a data snapshot."""

    population_size: int
    schema_fields: list[str]

    def cohort_records(self, cohort: dict) -> set:
        """Return the set of record ids belonging to ``cohort``.

        A cohort is either ``{"record_ids": [...]}`` (test / stub path) or
        ``{"filter_ast": {...}}`` (production path evaluated against the
        finite population).
        """
        ...


def parse_ast_op(ast: dict):
    """Normalize an AST node to ``(op, args)``.

    Accepts both the compact form ``{"in": [field, values]}`` (used in the
    scheme's contract examples) and the explicit form
    ``{"op": "and", "args": [...]}``. Shared by every snapshot backend so the
    restricted-AST semantics are defined exactly once (scheme 10.2).
    """
    if not isinstance(ast, dict):
        raise ValueError(f"AST node must be a dict, got {type(ast).__name__}")
    if "op" in ast:
        return ast["op"], ast.get("args", [])
    if len(ast) != 1:
        raise ValueError(f"ambiguous AST node with multiple keys: {list(ast)}")
    op = next(iter(ast))
    return op, ast[op]


#: Backwards-compatible private alias.
_parse_op = parse_ast_op


def _compare(value, bound, op: str) -> bool:
    """Order comparison inside the restricted AST.

    A missing or ``None`` value is never "less than" anything -- it is unknown,
    so it matches no bound. Silently ordering nulls would let a cohort with
    unparsed dates absorb records the contract did not ask for.
    """
    if value is None or bound is None:
        return False
    try:
        if op == "ge":
            return value >= bound
        if op == "le":
            return value <= bound
        if op == "gt":
            return value > bound
        return value < bound
    except TypeError:
        return False


class MemorySnapshot:
    """Tiny finite-population snapshot for compiler tests and stubs.

    ``records`` maps ``record_id -> {field: value}``. The population is exactly
    the set of keys; cohort sizes (the "known denominators") are always
    determinable, which is the precondition for finite-population confidence
    sequences.
    """

    def __init__(self, records: dict, schema_fields: list[str] | None = None):
        self.records = dict(records)
        self.population_size = len(self.records)
        if schema_fields is None:
            schema_fields = sorted({k for r in self.records.values() for k in r})
        self.schema_fields = list(schema_fields)

    def record_ids(self) -> list:
        return list(self.records)

    def _column(self, field: str) -> list:
        """Column access aligned with ``record_ids()``, for column-wise code.

        Production backends load one column at a time; this test double simply
        projects its in-memory records in the same order, so the workload
        generator and the compiler see identical semantics.
        """
        return [r.get(field) for r in self.records.values()]

    def evaluate_filter(self, ast: dict) -> set:
        op, args = _parse_op(ast)
        if op not in ALLOWED_AST_OPS:
            raise ValueError(f"disallowed AST op: {op}")
        if op == "in":
            field, values = args[0], set(args[1])
            return {rid for rid, r in self.records.items() if r.get(field) in values}
        if op == "eq":
            field, val = args[0], args[1]
            return {rid for rid, r in self.records.items() if r.get(field) == val}
        if op == "ne":
            field, val = args[0], args[1]
            # A record with a *missing* field matches no operator value at all
            # (missing != any val is not a meaningful membership): excluding
            # keeps "ne" the exact complement of "eq" over non-missing values.
            return {
                rid for rid, r in self.records.items()
                if r.get(field) is not None and r.get(field) != val
            }
        if op in COMPARISON_AST_OPS:
            return {rid for rid, r in self.records.items() if _compare(r.get(args[0]), args[1], op)}
        if op == "and":
            result = None
            for sub in args:
                s = self.evaluate_filter(sub)
                result = s if result is None else (result & s)
            return result or set()
        if op == "or":
            result: set = set()
            for sub in args:
                result |= self.evaluate_filter(sub)
            return result
        if op == "not":
            return set(self.records) - self.evaluate_filter(args[0])
        raise ValueError(f"unknown op {op}")

    def cohort_records(self, cohort: dict) -> set:
        if cohort.get("record_ids") is not None:
            requested = set(cohort["record_ids"])
            unknown = requested - set(self.records)
            if unknown:
                # same 5.2 rule as the parquet backend: the known denominator
                # is the guarantee; unknown ids must be rejected at parse time
                from query.contract_schema import ContractUnsupported

                sample = sorted(unknown)[:5]
                raise ContractUnsupported(
                    f"cohort record_ids not in the snapshot population "
                    f"({len(unknown)} unknown, e.g. {sample})"
                )
            return requested
        if "filter_ast" not in cohort:
            raise ValueError("cohort must carry 'filter_ast' or 'record_ids'")
        return self.evaluate_filter(cohort["filter_ast"])
