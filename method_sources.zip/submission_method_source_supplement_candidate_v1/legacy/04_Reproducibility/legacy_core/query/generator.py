"""Deterministic generation of the automated query workload (proposal 15.1).

The workload is *synthetic but executable*: cohorts come from real metadata,
never from semantic labels, so a query never presupposes the answer it asks for
(proposal 15.1: "no requirement that a significant difference exists"). Every
query is emitted as a full decision contract plus its natural-language source,
because the end-to-end layer is scored from the natural language in (proposal
15.3).

Three-way separation is enforced here, not assumed:

1. **Query family** -- a concrete instance (dimension + cohort values + wording)
   belongs to exactly one split. Entity assignment makes this structural rather
   than a matter of bookkeeping.
2. **Entity set** -- each entity value (product, issue, company, state, city,
   hotel) is hashed into exactly one split, so no entity appears on two sides of
   the separation.
3. **Time range** -- splits use disjoint, chronologically ordered windows.

Two predicates per domain never enter train or dev; they appear only in test as
the semantic generalisation probe (proposal 15.1). Their queries still pay for
their pilot.

``check_separation`` re-verifies all three properties from the emitted workload,
so the guarantee is checked rather than asserted in prose.
"""
from __future__ import annotations

import hashlib
import itertools
import json
import random
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

import yaml

from query.predicates import Predicate, PredicateSet

__all__ = [
    "DEFAULT_CONFIG_PATH",
    "CohortRef",
    "QuerySpec",
    "WorkloadConfig",
    "CohortCatalog",
    "generate_workload",
    "generate_split",
    "write_jsonl",
    "read_jsonl",
    "check_separation",
]

DEFAULT_CONFIG_PATH = (
    Path(__file__).resolve().parents[1] / "configs" / "query_generation.yaml"
)

SPLITS = ("train", "dev", "test")


# --------------------------------------------------------------------------
# data carriers
# --------------------------------------------------------------------------


@dataclass(frozen=True)
class CohortRef:
    """One query group: a mechanically determined subset of the population."""

    cohort_id: str
    filter_ast: dict
    label: str
    size: int
    entity_key: str
    dimension: str


@dataclass
class QuerySpec:
    query_id: str = ""
    dataset: str = ""
    split: str = ""
    kind: str = ""           # pairwise | summary | ranking
    family: str = ""         # entity dimension the cohorts come from
    predicate_id: str = ""
    contract: dict = field(default_factory=dict)
    natural_language: str = ""
    nl_variants: list = field(default_factory=list)
    entity_keys: list = field(default_factory=list)
    time_window: list = field(default_factory=list)
    cohort_sizes: dict = field(default_factory=dict)
    judgement_count: int = 1

    def to_dict(self) -> dict:
        return {
            "query_id": self.query_id,
            "dataset": self.dataset,
            "split": self.split,
            "kind": self.kind,
            "family": self.family,
            "predicate_id": self.predicate_id,
            "contract": self.contract,
            "natural_language": self.natural_language,
            "nl_variants": self.nl_variants,
            "entity_keys": self.entity_keys,
            "time_window": self.time_window,
            "cohort_sizes": self.cohort_sizes,
            "judgement_count": self.judgement_count,
        }

    @classmethod
    def from_dict(cls, d: Mapping[str, Any]) -> "QuerySpec":
        return cls(**{k: d[k] for k in (
            "query_id", "dataset", "split", "kind", "family", "predicate_id",
            "contract", "natural_language", "nl_variants", "entity_keys",
            "time_window", "cohort_sizes", "judgement_count",
        ) if k in d})


# --------------------------------------------------------------------------
# config
# --------------------------------------------------------------------------


class WorkloadConfig:
    """The frozen workload plan. Every random choice is seeded from here."""

    def __init__(self, doc: Mapping[str, Any]):
        self.doc = dict(doc)
        self.salt = str(doc.get("salt", ""))
        self.seed = int(doc.get("seed", 0))
        self.splits: dict = doc["splits"]
        self.kind_mix: dict = doc["kind_mix"]
        self.thresholds: dict = doc["thresholds"]
        self.tolerances: list = list(doc["equivalence_tolerance"])
        self.decision_mix: dict = doc["decision_mix"]
        self.summary_range: tuple = (
            int(doc["summary_judgements"]["min"]), int(doc["summary_judgements"]["max"])
        )
        self.candidate_range: tuple = (
            int(doc["ranking_candidates"]["min"]), int(doc["ranking_candidates"]["max"])
        )
        self.k_range: tuple = (int(doc["ranking_k"]["min"]), int(doc["ranking_k"]["max"]))
        self.min_cohort: dict = doc["min_cohort_size"]
        self.max_instances_per_groupset: int = int(doc.get("max_instances_per_groupset", 6))
        self.datasets: dict = doc["datasets"]
        self.budget: int = int(doc["budget"]["max_oracle_record_predicate_calls"])
        self._validate()

    @classmethod
    def load(cls, path: str | Path = DEFAULT_CONFIG_PATH) -> "WorkloadConfig":
        return cls(yaml.safe_load(Path(path).read_text(encoding="utf-8")))

    def _validate(self) -> None:
        for sp in SPLITS:
            if sp not in self.splits:
                raise ValueError(f"split {sp!r} missing from config")
        for sp, mix in self.kind_mix.items():
            total = sum(mix.values())
            want = int(self.splits[sp]["per_dataset"])
            if total != want:
                raise ValueError(
                    f"split {sp!r} kind_mix sums to {total}, per_dataset is {want}"
                )
        for ds, spec in self.datasets.items():
            wins = spec["time_windows"]
            order = [wins[sp] for sp in SPLITS if sp in wins]
            for (_, hi), (lo, _) in zip(order, order[1:]):
                if hi >= lo:
                    raise ValueError(
                        f"dataset {ds!r}: time windows overlap or are out of order "
                        f"({hi} >= {lo}); splits must be separated by time"
                    )
            held = set(spec["predicates"]["held_out"])
            tuning = set(spec["predicates"]["tuning"])
            if held & tuning:
                raise ValueError(
                    f"dataset {ds!r}: a predicate is both tuning and held-out"
                )

    def time_window(self, dataset: str, split: str) -> list:
        return list(self.datasets[dataset]["time_windows"][split])

    def dimensions(self, dataset: str) -> list:
        return list(self.datasets[dataset]["entity_dimensions"].keys())

    def min_size(self, dataset: str) -> int:
        return int(self.min_cohort[dataset])

    def predicates_for(self, dataset: str, split: str) -> list:
        p = self.datasets[dataset]["predicates"]
        return list(p["tuning"]) + (list(p["held_out"]) if split == "test" else [])

    def templates(self, dataset: str) -> dict:
        """Natural-language templates for a dataset (proposal 15.2)."""
        return dict(self.datasets[dataset].get("templates") or DEFAULT_TEMPLATES)

    def rng(self, dataset: str, split: str) -> random.Random:
        """One deterministic RNG per (dataset, split): reproducible, isolated."""
        blob = f"{self.salt}|{self.seed}|{dataset}|{split}".encode("utf-8")
        return random.Random(int(hashlib.sha256(blob).hexdigest()[:16], 16))


# --------------------------------------------------------------------------
# cohort catalog: sizes come from metadata, never from semantic labels
# --------------------------------------------------------------------------


class CohortCatalog:
    """Pre-computed (dimension, value, split) group sizes for one dataset.

    Sizes are counted from structured metadata inside the split's time window,
    which is what makes them *known denominators*. A value whose group is too
    small to certify is dropped rather than padded -- the alternative would be
    queries that can never be answered within budget.
    """

    def __init__(self, dataset: str, snapshot, config: WorkloadConfig):
        self.dataset = dataset
        self.snapshot = snapshot
        self.cfg = config
        self.time_field = config.datasets[dataset]["time_field"]
        self.min_size = config.min_size(dataset)
        self._counts: dict[tuple, int] = {}
        self._assignment: dict[str, dict[str, list]] = {}
        self._build()

    # -- construction -----------------------------------------------------

    def _build(self) -> None:
        ids = self.snapshot.record_ids()
        times = self.snapshot._column(self.time_field)
        windows = {
            sp: tuple(self.cfg.time_window(self.dataset, sp)) for sp in SPLITS
        }
        for dim in self.cfg.dimensions(self.dataset):
            col = self.snapshot._column(dim)
            seen: dict[str, int] = {}
            for rid, value, t in zip(ids, col, times):
                if value is None or value == "":
                    continue
                seen[value] = seen.get(value, 0) + 1
                for sp, (lo, hi) in windows.items():
                    if t is None or not (lo <= t <= hi):
                        continue
                    key = (dim, value, sp)
                    self._counts[key] = self._counts.get(key, 0) + 1
            # A long tail of entities with a handful of records each is not a
            # query group; the config caps each dimension at its head.
            top = int(self.cfg.datasets[self.dataset]["entity_dimensions"][dim].get("top", 0))
            if top and len(seen) > top:
                head = sorted(seen, key=lambda v: (-seen[v], v))[:top]
                seen = {v: seen[v] for v in head}
            self._assignment[dim] = self._assign(seen)

    def _assign(self, totals: Mapping[str, int]) -> dict[str, list]:
        """Split entity values into disjoint sets, balancing *volume*.

        Values are taken largest-first and handed to whichever split is furthest
        below its share of the total volume. A pure hash cut would regularly give
        one split nothing but tail entities -- and since a split also owns only
        its own time window, those groups fall under ``min_cohort_size`` and the
        split becomes unqueryable. Balancing volume keeps every split usable
        while keeping the entity sets disjoint (proposal 15.1).
        """
        shares = {sp: float(self.cfg.splits[sp]["share"]) for sp in SPLITS}
        total_share = sum(shares.values())
        n = len(totals)
        quota: dict[str, int] = {}
        cursor = 0
        for i, sp in enumerate(SPLITS):
            take = (
                n - cursor
                if i == len(SPLITS) - 1
                else int(round(n * shares[sp] / total_share))
            )
            quota[sp] = take
            cursor += take

        ordered = sorted(
            totals,
            key=lambda v: (
                -totals[v],
                hashlib.sha256(
                    f"{self.cfg.salt}|{self.dataset}|{v}".encode("utf-8")
                ).hexdigest(),
            ),
        )
        assigned: dict[str, list] = {sp: [] for sp in SPLITS}
        load: dict[str, int] = {sp: 0 for sp in SPLITS}
        for v in ordered:
            cands = [sp for sp in SPLITS if len(assigned[sp]) < quota[sp]]
            if not cands:
                break
            sp = min(cands, key=lambda s: (load[s] + totals[v]) / shares[s])
            assigned[sp].append(v)
            load[sp] += totals[v]
        return assigned

    # -- queries ----------------------------------------------------------

    def available(self, dim: str, split: str) -> list:
        """Values of ``dim`` usable in ``split``, largest group first."""
        out = []
        for value in self._assignment.get(dim, {}).get(split, []):
            size = self._counts.get((dim, value, split), 0)
            if size >= self.min_size:
                out.append((value, size))
        out.sort(key=lambda kv: (-kv[1], kv[0]))
        return out

    def cohort(self, dim: str, value: Any, split: str, cohort_id: str) -> CohortRef:
        lo, hi = self.cfg.time_window(self.dataset, split)
        ast = {
            "and": [
                {"eq": [dim, value]},
                {"ge": [self.time_field, lo]},
                {"le": [self.time_field, hi]},
            ]
        }
        label_field = self.cfg.datasets[self.dataset]["labels"].get(dim, dim)
        size = self._counts.get((dim, value, split), 0)
        return CohortRef(
            cohort_id=cohort_id,
            filter_ast=ast,
            label=f"{label_field}={value}",
            size=size,
            entity_key=f"{dim}={value}",
            dimension=dim,
        )


# --------------------------------------------------------------------------
# natural language templates (proposal 15.2)
# --------------------------------------------------------------------------

# Natural-language templates are per-dataset in the config (proposal 15.2:
# "basic natural language is generated from the DSL by deterministic
# templates, so slots have unambiguous referents"). These defaults exist so a
# dataset without configured templates still renders a well-formed request.
DEFAULT_TEMPLATES = {
    "compare": [
        "For records from {lo} to {hi}, is the share satisfying '{question}' at "
        "least {pp} percentage points higher for {left} than for {right}?",
    ],
    "direction": [
        "For records from {lo} to {hi}, is '{question}' more frequent for {left} "
        "than for {right}?",
    ],
    "equivalence": [
        "For records from {lo} to {hi}, are {left} and {right} within {pp} "
        "percentage points of each other on '{question}'?",
    ],
    "top1": [
        "For records from {lo} to {hi}, which of these has the highest share "
        "satisfying '{question}': {candidates}?",
    ],
    "topk": [
        "For records from {lo} to {hi}, which {k} of these have the highest share "
        "satisfying '{question}': {candidates}?",
    ],
    "summary": [
        "For records from {lo} to {hi}, {n} comparisons were declared in advance "
        "on '{question}'. Report each one: {items}.",
    ],
}


def _pp(threshold: float) -> str:
    """Render a threshold as percentage points without float noise."""
    if not threshold:
        return "0"
    text = f"{float(threshold) * 100:.4g}"
    return text[:-2] if text.endswith(".0") else text


def _render_nl(templates: Mapping[str, list], kind_key: str, ctx: dict, variant: int = 0) -> str:
    variants = templates.get(kind_key) or DEFAULT_TEMPLATES[kind_key]
    return variants[variant % len(variants)].format(**ctx)


# --------------------------------------------------------------------------
# generation
# --------------------------------------------------------------------------


def _pick_decision(rng: random.Random, mix: Mapping[str, float]) -> str:
    r = rng.random()
    acc = 0.0
    for name, share in mix.items():
        acc += float(share)
        if r <= acc:
            return name
    return list(mix)[-1]


def _pairwise_decision(rng, kind: str, left: str, right: str, cfg: WorkloadConfig):
    if kind == "equivalence":
        return {
            "type": "equivalence",
            "left": left,
            "right": right,
            "tolerance": rng.choice(cfg.tolerances),
            "unit": "proportion_difference",
        }
    pool = cfg.thresholds["direction"] if kind == "direction" else cfg.thresholds["pairwise"]
    return {
        "type": "compare" if kind == "compare" else "direction",
        "left": left,
        "right": right,
        "threshold": rng.choice(pool),
        "unit": "proportion_difference",
    }


def _choose_dimension(rng, catalog: CohortCatalog, split: str, need: int) -> str | None:
    dims = list(catalog.cfg.dimensions(catalog.dataset))
    rng.shuffle(dims)
    for d in dims:
        if len(catalog.available(d, split)) >= need:
            return d
    return None


def _signature(dataset, split, dim, values, predicate_id, extra) -> str:
    return f"{dataset}|{split}|{dim}|{'&'.join(map(str, values))}|{predicate_id}|{extra}"


def generate_split(
    dataset: str,
    split: str,
    catalog: CohortCatalog,
    cfg: WorkloadConfig,
    predicates: PredicateSet,
    max_attempts: int = 200,
) -> list[QuerySpec]:
    """Generate one (dataset, split) slice of the workload."""
    rng = cfg.rng(dataset, split)
    mix = cfg.kind_mix[split]
    kinds = []
    for kind, count in mix.items():
        kinds.extend([kind] * int(count))
    rng.shuffle(kinds)

    pred_ids = cfg.predicates_for(dataset, split)
    lo, hi = cfg.time_window(dataset, split)
    used: set[str] = set()
    instances: dict[str, int] = {}
    specs: list[QuerySpec] = []

    for i, kind in enumerate(kinds):
        # A summary needs at least three groups: two groups give only two
        # distinct contrasts, which cannot fill the 3-6 declared judgements of
        # proposal 15.1.
        need = {"pairwise": 2, "summary": 3, "ranking": int(cfg.candidate_range[0])}[kind]
        dim = _choose_dimension(rng, catalog, split, need)
        if dim is None:
            raise ValueError(
                f"{dataset}/{split}: no dimension has {need} usable groups "
                f"(min_cohort_size={catalog.min_size}); loosen the config or widen "
                f"the time window rather than generating unanswerable queries"
            )
        pool = catalog.available(dim, split)
        predicate_id = pred_ids[i % len(pred_ids)]
        predicate = predicates.by_id(predicate_id)

        spec = None
        for _ in range(max_attempts):
            dtype, thr, k, n_judgements = "", None, 0, 0
            if kind == "ranking":
                n_cands = rng.randint(
                    int(cfg.candidate_range[0]),
                    min(int(cfg.candidate_range[1]), len(pool)),
                )
                picks = rng.sample(range(len(pool)), n_cands)
                k = rng.randint(cfg.k_range[0], min(cfg.k_range[1], n_cands - 1))
                param = f"top{k}:{n_cands}"
            elif kind == "pairwise":
                dtype = _pick_decision(rng, cfg.decision_mix["pairwise"])
                choices = (
                    cfg.tolerances if dtype == "equivalence"
                    else cfg.thresholds["direction"] if dtype == "direction"
                    else cfg.thresholds["pairwise"]
                )
                thr = rng.choice(choices)
                picks = rng.sample(range(len(pool)), 2)
                param = f"{dtype}:{thr}"
            else:
                n_groups = rng.randint(3, min(4, len(pool)))
                n_judgements = rng.randint(
                    int(cfg.summary_range[0]), int(cfg.summary_range[1])
                )
                picks = rng.sample(range(len(pool)), n_groups)
                param = f"sum{n_groups}:{n_judgements}"

            values = [pool[p][0] for p in picks]
            base = _signature(dataset, split, dim, values, predicate_id, f"{kind}:{param}")
            seen_count = instances.get(base, 0)
            if seen_count >= cfg.max_instances_per_groupset:
                continue
            instances[base] = seen_count + 1
            used.add(f"{base}#{seen_count}")
            spec = _build_spec(
                dataset, split, kind, dim, values, catalog, cfg,
                predicate, predicate_id, lo, hi, rng, index=len(specs),
                plan={"dtype": dtype, "threshold": thr, "k": k,
                      "n_judgements": n_judgements},
            )
            break
        if spec is None:
            # Exhausted distinct combinations for this slot. Emitting a duplicate
            # would silently inflate the count, so refuse instead.
            raise ValueError(
                f"{dataset}/{split}: could not find a distinct query for slot {i} "
                f"(kind={kind}, dim={dim}) after {max_attempts} attempts"
            )
        specs.append(spec)
    return specs


def _build_spec(
    dataset, split, kind, dim, values, catalog, cfg,
    predicate: Predicate, predicate_id: str, lo: str, hi: str, rng, index: int,
    plan: Mapping[str, Any] | None = None,
) -> QuerySpec:
    """Assemble one query from cohorts that were already drawn and de-duplicated.

    ``plan`` carries the decision parameters drawn while searching for a distinct
    instance, so the signature that was checked matches the contract that is
    built -- otherwise the same cohorts could silently produce two identical
    queries under different thresholds.
    """
    plan = dict(plan or {})
    templates = cfg.templates(dataset)
    cohorts: list[CohortRef] = [
        catalog.cohort(dim, v, split, f"g{j + 1}") for j, v in enumerate(values)
    ]
    ids = [c.cohort_id for c in cohorts]
    question = predicate.question

    if kind == "pairwise":
        dtype = plan.get("dtype") or "compare"
        if dtype == "equivalence":
            tol = plan.get("threshold") if plan.get("threshold") is not None else cfg.tolerances[0]
            decisions = [{
                "type": "equivalence", "left": ids[0], "right": ids[1],
                "tolerance": tol, "unit": "proportion_difference",
            }]
        else:
            thr = plan.get("threshold")
            if thr is None:
                thr = cfg.thresholds["pairwise"][0]
            decisions = [{
                "type": "compare" if dtype == "compare" else "direction",
                "left": ids[0], "right": ids[1],
                "threshold": thr, "unit": "proportion_difference",
            }]
        ctx = {
            "lo": lo, "hi": hi, "left": cohorts[0].label, "right": cohorts[1].label,
            "question": question,
            "pp": _pp(decisions[0].get("threshold", decisions[0].get("tolerance", 0.0))),
        }
        key = "equivalence" if dtype == "equivalence" else dtype
        nl = _render_nl(templates, key, ctx)
        variants = [
            _render_nl(templates, key, ctx, variant=v)
            for v in range(1, len(templates.get(key, DEFAULT_TEMPLATES[key])) + 1)
        ]

    elif kind == "summary":
        # 3-6 judgements declared up front over the chosen groups (proposal 15.1).
        # Unordered pairs only: with the all-nonneg threshold menu, drawing both
        # A>B and B>A into one bundle would be a mathematically contradictory
        # contract that no reference operator could ever satisfy.
        pairs = list(itertools.combinations(ids, 2))
        rng.shuffle(pairs)
        n = int(plan.get("n_judgements") or cfg.summary_range[0])
        n = max(int(cfg.summary_range[0]), min(n, len(pairs), int(cfg.summary_range[1])))
        chosen = pairs[:n]
        decisions = [
            {
                "type": "compare", "left": a, "right": b,
                "threshold": rng.choice(cfg.thresholds["summary"]),
                "unit": "proportion_difference",
            }
            for a, b in chosen
        ]
        items = "; ".join(
            f"{cohorts[ids.index(a)].label} vs {cohorts[ids.index(b)].label} "
            f"(>{_pp(d['threshold'])} points)"
            for (a, b), d in zip(chosen, decisions)
        )
        ctx = {
            "lo": lo, "hi": hi, "n": n, "question": question, "items": items,
        }
        nl = _render_nl(templates, "summary", ctx)
        variants = []

    else:  # ranking
        k = int(plan.get("k") or 1)
        k = max(1, min(k, len(ids) - 1))
        if k == 1:
            decisions = [{"type": "top1", "candidates": ids}]
            key = "top1"
        else:
            decisions = [{"type": "topk", "candidates": ids, "k": k}]
            key = "topk"
        ctx = {
            "lo": lo, "hi": hi, "question": question, "k": k,
            "candidates": ", ".join(c.label for c in cohorts),
        }
        nl = _render_nl(templates, key, ctx)
        variants = []

    contract = {
        "snapshot_id": f"{dataset}_v1",
        "predicate_id": predicate_id,
        "cohorts": [
            {"id": c.cohort_id, "filter_ast": c.filter_ast, "label": c.label}
            for c in cohorts
        ],
        "decisions": decisions,
        "risk": {"alpha": 0.05, "scope": "this_request"},
        "budget": {"max_oracle_record_predicate_calls": cfg.budget},
        "population_scope": f"frozen {dataset} snapshot, {lo}..{hi}",
    }

    return QuerySpec(
        query_id=f"{dataset}-{split}-{index:04d}",
        dataset=dataset,
        split=split,
        kind=kind,
        family=dim,
        predicate_id=predicate_id,
        contract=contract,
        natural_language=nl,
        nl_variants=variants,
        entity_keys=[c.entity_key for c in cohorts],
        time_window=[lo, hi],
        cohort_sizes={c.cohort_id: c.size for c in cohorts},
        judgement_count=len(decisions),
    )


def generate_workload(
    snapshots: Mapping[str, Any],
    predicates: PredicateSet,
    config: WorkloadConfig | None = None,
) -> list[QuerySpec]:
    """Generate the full 480-query workload, ordered by dataset then split."""
    cfg = config or WorkloadConfig.load()
    specs: list[QuerySpec] = []
    total = 0
    for dataset in cfg.datasets:
        if dataset not in snapshots:
            continue
        catalog = CohortCatalog(dataset, snapshots[dataset], cfg)
        for split in SPLITS:
            part = generate_split(dataset, split, catalog, cfg, predicates)
            specs.extend(part)
            total += len(part)
    return specs


# --------------------------------------------------------------------------
# io + separation audit
# --------------------------------------------------------------------------


def write_jsonl(path: str | Path, specs: Iterable[QuerySpec]) -> int:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    n = 0
    with p.open("w", encoding="utf-8") as fh:
        for s in specs:
            fh.write(json.dumps(s.to_dict(), ensure_ascii=False) + "\n")
            n += 1
    return n


def read_jsonl(path: str | Path) -> list[QuerySpec]:
    out = []
    with Path(path).open(encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if line:
                out.append(QuerySpec.from_dict(json.loads(line)))
    return out


def check_separation(
    specs: Sequence[QuerySpec],
    held_out: Mapping[str, set] | None = None,
) -> list[str]:
    """Re-verify the three-way separation from the emitted workload.

    Returns a list of violations; empty means train / dev / test are separated
    by entity, by time and by query instance. ``held_out`` maps dataset ->
    predicate ids that must appear in test only (15.1: semantic-generalization
    predicates never enter train or dev) -- generation enforces this, but the
    audit re-checks it from the emitted rows rather than trusting the builder.
    """
    problems: list[str] = []
    held_out = held_out or {}

    entity_owner: dict[tuple, str] = {}
    for s in specs:
        for key in s.entity_keys:
            owner = (s.dataset, key)
            prev = entity_owner.setdefault(owner, s.split)
            if prev != s.split:
                problems.append(
                    f"entity leak: {s.dataset}/{key} appears in {prev} and {s.split}"
                )
        if s.predicate_id in held_out.get(s.dataset, set()) and s.split != "test":
            problems.append(
                f"held-out predicate leak: {s.dataset}/{s.predicate_id} "
                f"appears in {s.split}"
            )

    windows: dict[tuple, tuple] = {}
    for s in specs:
        owner = (s.dataset, s.split)
        w = tuple(s.time_window)
        prev = windows.setdefault(owner, w)
        if prev != w:
            problems.append(f"time window differs within {owner}: {prev} vs {w}")
    for dataset in {s.dataset for s in specs}:
        by_split = {sp: windows[(dataset, sp)] for sp in SPLITS if (dataset, sp) in windows}
        ordered = [by_split[sp] for sp in SPLITS if sp in by_split]
        for (_, hi), (lo, _) in zip(ordered, ordered[1:]):
            if hi >= lo:
                problems.append(
                    f"time leak in {dataset}: window ends {hi} but next starts {lo}"
                )

    instance_owner: dict[tuple, str] = {}
    for s in specs:
        key = (
            s.dataset, s.family,
            tuple(sorted(s.entity_keys)), s.predicate_id, s.natural_language,
        )
        prev = instance_owner.setdefault(key, s.split)
        if prev != s.split:
            problems.append(
                f"query family leak: {s.query_id} duplicates {prev} instance {key[:3]}"
            )

    # Wording variants must not repeat across splits either: the same sentence
    # appearing in train and test is the paraphrase-leak the 15.1 wording
    # isolation is meant to prevent.
    variant_owner: dict[tuple, str] = {}
    for s in specs:
        for v in s.nl_variants or []:
            owner = (s.dataset, " ".join(str(v).split()).lower())
            prev = variant_owner.setdefault(owner, s.split)
            if prev != s.split:
                problems.append(
                    f"wording leak in {s.dataset}: a variant of {s.query_id} "
                    f"appears in {prev} and {s.split}"
                )

    return problems
