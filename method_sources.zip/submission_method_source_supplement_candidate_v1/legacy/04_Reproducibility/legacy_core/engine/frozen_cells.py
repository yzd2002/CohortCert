"""Freeze coefficient cells, their random permutations, and per-cell risk.

Implements scheme 7.1 / 7.2 / 7.5:

  * A *cell* groups records that share (a) the same coefficient signature
    ``sig(i) = (a_{1,i}, ..., a_{J,i})`` and (b) the same proxy-quantile bin.
    Within a cell every contrast has identical coefficients, so the cell can be
    summarized by a single count K_h.
  * Each cell gets ONE independently generated uniform permutation. Sampling may
    only consume the next prefix -- the scheduler may choose *which* cell to
    advance, never *which* record inside a cell.
  * Per-cell risk ``alpha_h = alpha / H`` with ``sum alpha_h <= alpha``
    (scheme 7.5). When H == 0 there is nothing to allocate.

The hard cap ``H <= 64`` (scheme 7.1) is enforced; if a partition would exceed
it the caller must reduce the number of quantile bins rather than merge records
with different coefficients.
"""
from __future__ import annotations

import json
import os
import random
from dataclasses import dataclass, field
from fractions import Fraction
from typing import Any

MAX_CELLS = 64
N_QUANTILE_BINS = 4


def _to_fraction(x) -> Fraction:
    """Exact Fraction from int / str / Fraction, or float via its decimal string.

    ``Fraction(0.12)`` would capture the binary approximation; routing floats
    through ``str`` keeps the intended decimal value exact.
    """
    if isinstance(x, Fraction):
        return x
    if isinstance(x, int):
        return Fraction(x)
    if isinstance(x, float):
        return Fraction(str(x))
    return Fraction(x)


@dataclass
class Cell:
    cell_id: int
    signature: tuple
    bin: int
    records: list
    N: int = field(init=False)

    def __post_init__(self):
        self.N = len(self.records)


def quantize(score: float, n_bins: int = N_QUANTILE_BINS) -> int:
    """Equal-width fallback for a single score without a reference sample.

    The freezing path proper uses ``quantile_bin`` (7.1: 最多四个代理分数量化
    区间 -- quantiles of the *observed* pilot scores, so each stratum holds a
    comparable number of records); this helper remains for callers that have
    no score distribution to take quantiles of.
    """
    if not (0.0 <= score <= 1.0):
        raise ValueError(f"proxy score must be in [0,1], got {score!r}")
    return min(n_bins - 1, int(score * n_bins))


def quantile_bin(score: float, edges: list[float]) -> int:
    """Bin ``score`` by pre-computed quantile edges (7.1)."""
    import bisect

    if not (0.0 <= score <= 1.0):
        raise ValueError(f"proxy score must be in [0,1], got {score!r}")
    return bisect.bisect_right(edges, score)


def quantile_edges(scores: list[float], n_bins: int = N_QUANTILE_BINS) -> list[float]:
    """Interior quantile edges of the observed scores, ascending.

    With n_bins=4 the edges are the 25/50/75th percentiles, giving four
    strata of comparable size even when scores cluster near 0 or 1. Ties
    collapse naturally: identical scores land in the same bin, so fewer
    non-empty strata may result, which is fine (empty strata are dropped
    downstream by the (signature, bin) grouping).
    """
    if n_bins < 1:
        raise ValueError(f"n_bins must be >= 1, got {n_bins}")
    if not scores:
        return []
    ordered = sorted(float(s) for s in scores)
    edges: list[float] = []
    for k in range(1, n_bins):
        pos = len(ordered) * k / n_bins
        lo = int(pos)
        hi = min(lo + 1, len(ordered) - 1)
        frac = pos - lo
        val = ordered[lo] * (1.0 - frac) + ordered[hi] * frac
        if not edges or val > edges[-1]:
            edges.append(val)
    return edges


def freeze_coefficient_cells(
    active_ids,
    A,
    proxy,
    n_bins: int = N_QUANTILE_BINS,
    max_cells: int = MAX_CELLS,
):
    """Partition ``active_ids`` into coefficient cells.

    ``A`` is the signed-contrast matrix (duck-typed: must expose ``.rows`` as a
    list of ``{record_id: Fraction}`` coefficient maps). ``proxy`` must expose
    ``.score(record_id) -> float``. Score strata are quantiles of the observed
    scores (7.1), so strata stay balanced even for skewed proxy outputs.
    """
    scores = {i: float(proxy.score(i)) for i in active_ids}
    edges = quantile_edges(list(scores.values()), n_bins)
    groups: dict[tuple, list] = {}
    for i in active_ids:
        sig = tuple(A.rows[r].get(i, Fraction(0)) for r in range(len(A.rows)))
        b = quantile_bin(scores[i], edges)
        groups.setdefault((sig, b), []).append(i)

    if len(groups) > max_cells:
        raise ValueError(
            f"cell count {len(groups)} exceeds max_cells={max_cells}; "
            f"reduce n_bins rather than merging distinct coefficients"
        )

    cells = [
        Cell(cid, sig, b, sorted(recs))
        for cid, ((sig, b), recs) in enumerate(groups.items())
    ]
    return cells


def allocate_fixed_cell_risk(cells, alpha):
    """Return ``{cell_id: alpha_h}`` with ``alpha_h = alpha / H`` (scheme 7.5)."""
    H = len(cells)
    if H == 0:
        return {}
    ah = _to_fraction(alpha) / H
    return {c.cell_id: ah for c in cells}


def independent_uniform_permutations(cells, seed: int):
    """One uniform permutation per cell, reproducible for a fixed seed."""
    rng = random.Random(seed)
    perms: dict[int, list] = {}
    for c in cells:
        lst = list(c.records)
        rng.shuffle(lst)
        perms[c.cell_id] = lst
    return perms


def save_permutations(perms: dict[int, list], path: str) -> None:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump({str(k): v for k, v in perms.items()}, f)


def load_permutations(path: str) -> dict[int, list]:
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    return {int(k): v for k, v in data.items()}


def next_prefix(permutation: list, n: int) -> list:
    """Return the first ``n`` (or all) records of a cell permutation."""
    return permutation[: max(0, min(n, len(permutation)))]
