"""Reference semantic operator interface: budgeted, charged, failure-aware reads.

Two proposal requirements live in this file.

**10.3 / 13.3 -- the operator is a frozen object, not an ad-hoc call.**
:math:`y_{i,p} = f_{\\vartheta,p}(x_i)` is fixed by the model weights, tokenizer,
prompt, chunking rule, decoding rule, numeric precision and environment id.
Before any label is trusted, the tokenizer encoding of the two answer strings
must be verified and a canonical label snapshot must be published; cross-run
label disagreements are reported separately rather than hidden.

**11 -- a failed semantic call is never label 0.**
Any selected record whose semantic call fails uses a pre-declared, *charged*
retry policy; if it still fails the request terminates and keeps whatever
partial result is valid. Failures must not be recorded as 0 and must not be
skipped in favour of a cheaper record. This is the single rule that separates an
execution failure from a silently wrong certificate, so it is enforced here
rather than left to callers.
"""
from __future__ import annotations

import hashlib
import json
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping, Protocol, Sequence, runtime_checkable

__all__ = [
    "Oracle",
    "OracleFailure",
    "RetryPolicy",
    "BudgetedOracle",
    "LabelSnapshot",
    "duplicate_consistency_report",
    "validate_answer_tokenization",
    "repeat_consistency_verdict",
    "degeneracy_verdict",
    "canary_verdict",
    "text_sha256",
    "OPERATOR_ENV_FIELDS",
    "chunk_text",
    "ReferenceOperator",
    "build_label_snapshot",
]

#: 10.3: what has to be pinned before a label snapshot means anything.
#: ``batch_size`` is in the list on purpose: two-way scoring in bf16 is not
#: bit-identical across batch shapes (reduction order differs), and near-tie
#: records can flip -- measured 2/50 flips between batch 1 and batch 8 on
#: 2026-10-03. The canonical snapshot is therefore defined *for* a pinned
#: batch size, and the build must run at that size end to end.
OPERATOR_ENV_FIELDS = (
    "model_revision",
    "tokenizer_revision",
    "prompt_template_hash",
    "chunk_rule",
    "record_result_rule",
    "decode_rule",
    "precision",
    "max_context_tokens",
    "batch_size",
    "environment_id",
)


@runtime_checkable
class Oracle(Protocol):
    def read(self, record_ids: Sequence[str]) -> dict:
        """Return ``{record_id: 0|1}`` for exactly the queried records."""
        ...


class OracleFailure(Exception):
    """A semantic call could not be completed after the declared retries.

    Carries the ids that could not be read so the caller can report them
    instead of pretending the labels were observed.
    """

    def __init__(self, record_ids: Sequence[str], attempts: int, cause: Any = None):
        self.record_ids = list(record_ids)
        self.attempts = attempts
        self.cause = cause
        detail = f" after {attempts} attempt(s)"
        if cause is not None:
            detail += f"; last cause: {cause!r}"
        super().__init__(
            f"{len(self.record_ids)} record(s) could not be labelled{detail}; "
            f"failing ids e.g. {self.record_ids[:3]}"
        )


@dataclass(frozen=True)
class RetryPolicy:
    """Pre-declared retry policy (proposal 11).

    Every attempt is charged: retries are a real cost of the run, not a free
    do-over. ``max_attempts=1`` means "no retries, fail immediately".
    """

    max_attempts: int = 3

    def __post_init__(self) -> None:
        if self.max_attempts < 1:
            raise ValueError("max_attempts must be >= 1")


def _coerce_labels(record_ids: Sequence[str], raw: Any) -> dict | None:
    """Return ``{id: 0|1}`` only if *every* requested id came back as 0/1.

    Anything else -- a missing id, a None, a float score, a string -- is a
    failure, because defaulting it to 0 would silently fabricate evidence
    (proposal 11).
    """
    if not isinstance(raw, Mapping):
        return None
    out: dict = {}
    for rid in record_ids:
        if rid not in raw:
            return None
        v = raw[rid]
        if isinstance(v, bool) or not isinstance(v, int) or v not in (0, 1):
            return None
        out[rid] = v
    return out


class BudgetedOracle:
    """Charged, budget-checked, retrying wrapper around any oracle.

    * Every attempt is charged -- including retries and including the pilot
      (proposal 7.1: pilot calls are never free).
    * The batch is clipped to the remaining budget *before* the call, so
      ``budget_calls`` is a hard cap on semantic calls, not a suggestion.
    * A read that returns fewer usable labels than requested raises
      :class:`OracleFailure` instead of returning a partial dict.

    ``vault`` switches the reader into fixed-oracle replay mode: labels come
    from the sealed reference vault (which charges the would-have-been cost to
    the eval ledger) and *no* GPU cost is claimed for the query side.
    """

    def __init__(
        self,
        oracle: Oracle,
        budget_calls: int,
        ledger=None,
        request_id: str | None = None,
        vault=None,
        retry: RetryPolicy | None = None,
        replay: bool = False,
        token_budget: int | None = None,
        gpu_ms_budget: float | None = None,
    ) -> None:
        self.oracle = oracle
        self.vault = vault
        self.budget_calls = int(budget_calls)
        self.ledger = ledger
        self.request_id = request_id
        self.retry = retry or RetryPolicy()
        self.replay = replay
        self.spent = 0
        # 7.1: token and GPU-time are independent hard caps on top of the
        # call-count budget. None disables the cap (the historical behavior);
        # real-operator reads report cost via ``oracle.last_cost``.
        self.token_budget = token_budget
        self.gpu_ms_budget = gpu_ms_budget
        self.spent_tokens = 0
        self.spent_gpu_ms = 0.0
        self.failed_ids: list = []

    @property
    def remaining(self) -> int:
        return max(0, self.budget_calls - self.spent)

    def clip_to_budget(self, record_ids: Sequence[str]) -> list:
        """Keep only the prefix that still fits in the budget."""
        return list(record_ids)[: self.remaining]

    def _cap_violation(self) -> str | None:
        if self.token_budget is not None and self.spent_tokens > self.token_budget:
            return (f"token cap exceeded: {self.spent_tokens} > {self.token_budget}")
        if self.gpu_ms_budget is not None and self.spent_gpu_ms > self.gpu_ms_budget:
            return (f"GPU-time cap exceeded: {self.spent_gpu_ms:.1f} ms > "
                    f"{self.gpu_ms_budget:.1f} ms")
        return None

    def read(
        self,
        record_ids: Sequence[str],
        phase: str = "oracle",
        caller: str = "",
    ) -> dict:
        ids = list(record_ids)
        if not ids:
            return {}
        cap = self._cap_violation()
        if cap:
            raise OracleFailure(ids, 0, cause=cap)
        if len(ids) > self.remaining:
            raise OracleFailure(
                ids[self.remaining:], 0,
                cause=f"budget exhausted: {len(ids)} requested, {self.remaining} left",
            )

        last_cause: Any = None
        for attempt in range(1, self.retry.max_attempts + 1):
            if attempt > 1:
                if len(ids) > self.remaining:
                    # A retry charges the whole batch again (7.1: every attempt is
                    # billed). If it no longer fits, retrying would break the hard
                    # budget cap (5.4) -- abort instead of silently overspending.
                    self.failed_ids.extend(ids)
                    raise OracleFailure(
                        ids, attempt - 1,
                        cause=(f"retry aborted: hard budget cap would be exceeded "
                               f"(need {len(ids)}, {self.remaining} left); "
                               f"last error: {last_cause!r}"),
                    )
                cap = self._cap_violation()
                if cap:
                    self.failed_ids.extend(ids)
                    raise OracleFailure(ids, attempt - 1,
                                        cause=f"retry aborted: {cap}; last error: {last_cause!r}")
            t0 = time.perf_counter()
            raw: Any = None
            try:
                if self.vault is not None:
                    raw = self.vault.get(ids, caller=caller or phase, replay=self.replay)
                else:
                    raw = self.oracle.read(ids)
            except Exception as exc:  # noqa: BLE001 - the point is to charge it
                raw = None
                last_cause = exc
            wall_ms = (time.perf_counter() - t0) * 1000.0

            labels = _coerce_labels(ids, raw)
            # Charge every attempt, successful or not.
            self.spent += len(ids)
            if self.ledger is not None:
                self.ledger.record(
                    "query",
                    phase,
                    wall_ms=wall_ms,
                    semantic_calls=0 if self.vault is not None else len(ids),
                    records_read=len(ids) if labels is not None else 0,
                    cpu_ms=0.0 if self.vault is not None else wall_ms,
                    request_id=self.request_id,
                    note=(
                        f"caller={caller or phase}; attempt={attempt}/{self.retry.max_attempts}; "
                        + ("ok" if labels is not None else f"failed: {last_cause!r}")
                        + ("; replay: no real GPU latency" if self.vault is not None else "")
                    ),
                )
            if labels is not None:
                # Accumulate the real cost the operator just reported, so the
                # caps bite on the *next* read/attempt.
                cost = getattr(self.oracle, "last_cost", None) or {}
                self.spent_tokens += int(cost.get("input_tokens", 0) or 0)
                self.spent_gpu_ms += float(cost.get("gpu_active_ms", 0.0) or 0.0)
                return labels

        self.failed_ids.extend(ids)
        raise OracleFailure(ids, self.retry.max_attempts, cause=last_cause)

    def read_prefix(
        self,
        record_ids: Sequence[str],
        phase: str = "oracle",
        caller: str = "",
    ) -> tuple[dict, "OracleFailure | None", dict]:
        """Read in permutation order, committing only the contiguous prefix.

        Proposal 11, verbatim in intent: batch inference may complete out of
        order, but statistical updates must be submitted **in the pre-drawn
        permutation order**. So:

        * the *committed* sample is the longest prefix of complete returns;
        * labels computed *after* a hard failure are **stashed** -- they were
          paid for and are reported -- but they must never be used to extend the
          sample, because letting completion speed pick the sample would bias
          it toward whichever records happened to finish first.

        Returns ``(committed, failure_or_None, stashed)``. A ``None`` failure
        means the whole batch came back.
        """
        ids = list(record_ids)
        if not ids:
            return {}, None, {}
        if len(ids) > self.remaining:
            raise OracleFailure(
                ids[self.remaining:], 0,
                cause=f"budget exhausted: {len(ids)} requested, {self.remaining} left",
            )

        # Fast path: the whole batch completes, which is the normal case.
        try:
            return self.read(ids, phase=phase, caller=caller), None, {}
        except OracleFailure as exc:
            failure = exc

        # Something in the batch never came back. Walk the batch in order so the
        # committed sample is a genuine prefix rather than "whatever finished".
        committed: dict = {}
        failed_at: int | None = None
        for pos, rid in enumerate(ids):
            try:
                committed.update(self.read([rid], phase=phase, caller=f"{caller}:prefix"))
            except OracleFailure as exc:
                failed_at = pos
                failure = exc
                break

        if failed_at is None:
            return committed, None, {}

        stashed: dict = {}
        for rid in ids[failed_at + 1:]:
            try:
                stashed.update(self.read([rid], phase=phase, caller=f"{caller}:stashed"))
            except OracleFailure:
                continue
        return committed, failure, stashed


# --------------------------------------------------------------------------
# Canonical label snapshot and operator reproducibility (proposal 10.3)
# --------------------------------------------------------------------------


@dataclass
class LabelSnapshot:
    """A frozen, hashable label population.

    Repeated runs on one GPU are not automatically bit-identical across batch
    sizes or hardware, so the snapshot -- not the live model -- is the
    statistical target. Disagreements found while building it are reported
    separately (``duplicate_consistency_report``) and never averaged away.
    """

    predicate_id: str
    snapshot_hash: str
    env: dict = field(default_factory=dict)
    labels: dict = field(default_factory=dict)
    duplicate_check: dict | None = None
    created_utc: str = ""

    def content_hash(self) -> str:
        payload = json.dumps(
            {
                "predicate_id": self.predicate_id,
                "snapshot_hash": self.snapshot_hash,
                "env": {k: self.env.get(k) for k in OPERATOR_ENV_FIELDS},
                "labels": {k: self.labels[k] for k in sorted(self.labels)},
            },
            ensure_ascii=False,
            sort_keys=True,
        ).encode("utf-8")
        return hashlib.sha256(payload).hexdigest()

    def save(self, path: str | Path) -> Path:
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(
            json.dumps(
                {
                    "predicate_id": self.predicate_id,
                    "snapshot_hash": self.snapshot_hash,
                    "env": self.env,
                    "labels": self.labels,
                    "duplicate_check": self.duplicate_check,
                    "created_utc": self.created_utc,
                    "content_hash": self.content_hash(),
                },
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )
        return p

    @classmethod
    def load(cls, path: str | Path, verify_hash: bool = True) -> "LabelSnapshot":
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        snap = cls(
            predicate_id=data["predicate_id"],
            snapshot_hash=data["snapshot_hash"],
            env=data.get("env", {}),
            labels=data.get("labels", {}),
            duplicate_check=data.get("duplicate_check"),
            created_utc=data.get("created_utc", ""),
        )
        stored = data.get("content_hash")
        if verify_hash and stored:
            recomputed = snap.content_hash()
            if recomputed != stored:
                raise ValueError(
                    f"label snapshot {Path(path).name} failed its content hash: "
                    f"stored {stored} != recomputed {recomputed}. The file was "
                    "edited or corrupted after sealing; do not consume it."
                )
        return snap


def duplicate_consistency_report(
    repeated: Mapping[str, Iterable[int]], examples: int = 5
) -> dict:
    """Report how often repeated labelling of one record disagreed.

    ``repeated`` maps record_id -> the labels produced by each repeat run.

    A record that was labelled once cannot disagree with itself, so a build
    run at ``--repeats 1`` reports zero disagreements *vacuously*: that 0 is
    a fact about the experiment, not evidence that the operator is stable.
    Before 2026-10-04 the report divided by the whole population, which made
    a single-pass build (0 Jordan out of 40,000 records) indistinguishable
    from a three-pass build that genuinely agreed every time. It now keeps
    three things separate:

    ``records_checked``       how many records exist at all;
    ``records_with_repeats``  how many were labelled more than once -- the
                              only denominator a disagreement rate may use;
    ``observed_disagreement_rate``
                              over that denominator, or ``None`` when the
                              build could not have detected a disagreement.

    Even when measured, zero observed does not prove the true rate is zero
    (proposal 17.3), so the rate always ships with its denominator.
    """
    n = 0
    n_repeated = 0
    inconsistent = 0
    sample: list = []
    passes_seen: set = set()
    for rid, runs in repeated.items():
        runs = list(runs)
        if not runs:
            continue
        n += 1
        passes_seen.add(len(runs))
        if len(runs) > 1:
            n_repeated += 1
        if len(set(runs)) > 1:
            inconsistent += 1
            if len(sample) < examples:
                sample.append({"record_id": rid, "labels": runs})
    repeats_min = min(passes_seen) if passes_seen else 0
    repeats_max = max(passes_seen) if passes_seen else 0
    return {
        "records_checked": n,
        "records_with_repeats": n_repeated,
        "repeats_min": repeats_min,
        "repeats_max": repeats_max,
        "homogeneous_repeats": repeats_min == repeats_max,
        "records_inconsistent": inconsistent,
        "observed_disagreement_rate": (inconsistent / n_repeated) if n_repeated else None,
        "measured": n_repeated > 0,
        "note": (
            "repeat disagreement rate over records labelled more than once; "
            "zero observed does not prove zero"
            if n_repeated
            else "NOT MEASURED: every record was labelled exactly once, so this "
                 "build could not have detected a disagreement. The zero is a "
                 "fact about the experiment, not evidence of operator stability."
        ),
        "examples": sample,
    }


def repeat_consistency_verdict(report: Mapping | None) -> dict:
    """What a snapshot's ``duplicate_check`` block actually entitles you to say.

    Returns ``{"status", "claim"}`` where status is one of ``missing``,
    ``legacy``, ``not_measured``, ``heterogeneous``, ``measured``. Existing
    sealed snapshots were written before the repeat structure was recorded,
    so for them there is no way to tell a single pass from repeats that
    happened to agree; those come back ``legacy`` rather than a guess that
    would quietly turn into a quoted number in a paper.
    """
    if not report:
        return {"status": "missing", "claim": "no duplicate-consistency block attached"}
    if "measured" not in report:
        return {
            "status": "legacy",
            "claim": "written before repeat structure was recorded; a rate read "
                     "off this block conflates single-pass with repeated-pass "
                     "records, so do not quote it as an error rate",
        }
    if not report.get("measured"):
        return {
            "status": "not_measured",
            "claim": f"single pass per record ({report.get('records_checked')} records); "
                     "no repeat consistency was measured",
        }
    if not report.get("homogeneous_repeats", True):
        return {
            "status": "heterogeneous",
            "claim": f"mixed repeat counts ({report.get('repeats_min')}-"
                     f"{report.get('repeats_max')} passes per record); the aggregate "
                     "rate divides by records that were never repeated and is not "
                     "interpretable -- rerun one pass count end to end",
        }
    rate = report.get("observed_disagreement_rate")
    return {
        "status": "measured",
        "claim": f"{report.get('records_inconsistent')}/{report.get('records_with_repeats')} "
                 f"repeated records disagreed at {report.get('repeats_max')} passes "
                 f"(rate {rate:.4g})" if isinstance(rate, float) else "measured",
    }


def degeneracy_verdict(labels: Mapping, min_records: int = 100) -> dict:
    """Would these labels seal a degenerate (constant-output) snapshot?

    The Qwen3.5-9B replacement labelling run of 2026-10-07 returned 0 for all
    25,150 records across 8 predicates with wildly different 8B positive rates
    (17%-69%) -- the two-way scoring path had not been adapted to the model,
    and nothing on the build path refused the result.  A snapshot whose output
    carries no signal must not seal silently: the caller gates the *write*,
    never a single record (a genuinely all-negative small population stays
    under ``min_records`` and is allowed).
    """
    n = len(labels)
    if n == 0:
        return {"ok": False, "reason": "no labels at all"}
    ones = sum(1 for v in labels.values() if v == 1)
    if n < min_records:
        return {"ok": True, "reason": f"population {n} < min_records {min_records}",
                "positive_rate": ones / n}
    if ones == 0:
        return {"ok": False, "reason": f"all-zero labels over {n} records -- "
                "constant output carries no signal (degenerate operator run)"}
    if ones == n:
        return {"ok": False, "reason": f"all-one labels over {n} records -- "
                "constant output carries no signal (degenerate operator run)"}
    return {"ok": True, "positive_rate": ones / n}


def canary_verdict(canary_labels, ref_labels: Mapping | None = None,
                   pos_band: tuple[float, float] = (0.02, 0.98),
                   agree_min: float = 0.5,
                   pos_delta_max: float = 0.25) -> dict:
    """Gate a small canary labelling run before a full build is spent.

    The canary exists because a broken operator (wrong chat template, wrong
    scoring path) produces *plausible-looking* records at full speed -- the
    Qwen3.5-9B run of 2026-10-07 burned ~25k records before anyone looked at
    the positive rate.  Gates, in order of what they catch:

    * **degeneracy** -- the canary sample itself must contain both labels
      (constant output is the exact failure signature we observed);
    * **positive-rate band** -- the rate must sit inside ``pos_band``
      (default allows genuinely rare-positive predicates but not 0/1);
    * **reference cross-check** (optional) -- against an existing trusted
      snapshot on the same records: agreement floor *and* positive-rate
      proximity.  Deliberately loose: the canary is a sanity gate on a
      *different* operator, not a validity claim.
    """
    n = len(canary_labels)
    if n == 0:
        return {"ok": False, "reason": "canary produced no labels"}
    ones = sum(1 for v in canary_labels.values() if v == 1)
    pos_rate = ones / n
    checks: list[dict] = [{
        "check": "degenerate_sample", "ok": 0 < ones < n,
        "detail": f"{ones}/{n} positive",
    }, {
        "check": "positive_band", "ok": pos_band[0] <= pos_rate <= pos_band[1],
        "detail": f"rate {pos_rate:.3f} vs band [{pos_band[0]}, {pos_band[1]}]",
    }]
    if ref_labels is not None:
        shared = [rid for rid in canary_labels if rid in ref_labels]
        if shared:
            agree = sum(1 for rid in shared if canary_labels[rid] == ref_labels[rid]) / len(shared)
            pos_ref = sum(1 for rid in shared if ref_labels[rid] == 1) / len(shared)
            checks.append({
                "check": "ref_agreement", "ok": agree >= agree_min,
                "detail": f"agreement {agree:.3f} >= {agree_min} on {len(shared)} shared",
            })
            checks.append({
                "check": "ref_positive_delta", "ok": abs(pos_rate - pos_ref) <= pos_delta_max,
                "detail": f"rate {pos_rate:.3f} vs ref {pos_ref:.3f} (max delta {pos_delta_max})",
            })
        else:
            checks.append({"check": "ref_overlap", "ok": False,
                           "detail": "reference snapshot shares no records with the canary"})
    ok = all(c["ok"] for c in checks)
    return {"ok": ok, "canary_records": n, "positive_rate": pos_rate, "checks": checks}


def validate_answer_tokenization(tokenizer, positive: str = "1", negative: str = "0") -> dict:
    """Verify how the two answer strings tokenize before trusting 2-way scoring.

    Proposal 10.3: if scoring is done by next-token two-way comparison, the
    encoding of the chosen answer strings must be checked first and the result
    is part of the operator definition. A tokenizer that splits an answer into
    several tokens, or maps the two answers onto the same ids, invalidates the
    scoring rule -- better to find out here than after 256k labels.
    """
    def _ids(s: str) -> list:
        return list(tokenizer.encode(s, add_special_tokens=False))

    pos, neg = _ids(positive), _ids(negative)
    ok = bool(pos) and bool(neg) and pos != neg
    return {
        "positive": positive,
        "negative": negative,
        "positive_ids": pos,
        "negative_ids": neg,
        "single_token_each": len(pos) == 1 and len(neg) == 1,
        "distinct": pos != neg,
        "ok": ok,
        "warning": (
            ""
            if ok and len(pos) == 1 and len(neg) == 1
            else "answer strings are not single distinct tokens; fix the prompt or "
            "switch to constrained generation before freezing the operator"
        ),
    }


def text_sha256(text: str) -> str:
    """Stable hash of the exact quoted text (proposal 10.4 provenance)."""
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


# --------------------------------------------------------------------------
# Chunking, the reference operator, and the canonical snapshot (10.3)
# --------------------------------------------------------------------------


def chunk_text(text: str, rule: Mapping[str, Any] | None = None) -> list[str]:
    """Split one record into chunks under the frozen chunk rule.

    The rule is part of the operator definition: a different split can change a
    record-level label, so it is frozen in ``configs/predicates.yaml`` rather
    than chosen per run. Every chunk costs a model call, and that cost is
    charged -- long records are genuinely more expensive, which is exactly what
    the cost ledger must show (proposal 13.4).
    """
    rule = dict(rule or {})
    max_chars = int(rule.get("max_chars", 3000))
    overlap = int(rule.get("overlap_chars", 0))
    if max_chars <= 0:
        raise ValueError("chunk rule max_chars must be positive")
    text = text or ""
    if not text:
        return [""]
    if len(text) <= max_chars:
        return [text]

    import re

    units = [u for u in re.split(r"(?<=\n)|(?<=[.!?])\s+", text) if u]
    # A unit longer than the window is cut hard; otherwise it could never fit.
    pieces: list[str] = []
    for u in units:
        if len(u) <= max_chars:
            pieces.append(u)
            continue
        step = max(1, max_chars - overlap)
        start = 0
        while start < len(u):
            pieces.append(u[start: start + max_chars])
            start += step

    chunks: list[str] = []
    cur = ""
    for piece in pieces:
        candidate = (cur + piece) if cur else piece
        if len(candidate) <= max_chars:
            cur = candidate
            continue
        chunks.append(cur)
        tail = cur[-overlap:] if overlap > 0 and cur else ""
        cur = tail + piece
        while len(cur) > max_chars:  # overlap + a long piece can still overflow
            chunks.append(cur[:max_chars])
            cur = cur[max_chars - overlap:] if overlap > 0 else cur[max_chars:]
    if cur:
        chunks.append(cur)
    return chunks or [""]


class ReferenceOperator:
    """The frozen semantic operator f_{theta,p} over a record population.

    It turns "a model plus a prompt" into an object with one narrow interface:
    give it record ids, get 0/1 labels back. Behind that interface it applies
    the frozen chunk rule, renders the exact prompt, calls the backend, and
    combines chunk labels with the frozen record rule (logical OR).

    ``backend`` is injected so the whole operator can be exercised on CPU
    without an 8B model: it only needs ``label(prompts) -> list[int|None]`` and
    an optional ``last_cost`` mapping. A ``None`` label means the backend failed
    on that item, which becomes an exception here and therefore an
    :class:`OracleFailure` at the pipeline level -- never a silent 0.
    """

    def __init__(
        self,
        backend,
        predicate,
        operator_config: Mapping[str, Any] | None = None,
        texts: Mapping[str, str] | None = None,
        ledger=None,
        request_id: str | None = None,
        ledger_category: str = "query",
        ledger_phase: str = "oracle",
    ) -> None:
        self.backend = backend
        self.predicate = predicate
        self.config = dict(operator_config or {})
        self.texts = dict(texts or {})
        self.ledger = ledger
        self.request_id = request_id
        # Label building (persistent semantic materialization) is *build* cost
        # under 14.1, not query cost; the batch label-build script routes its
        # events to ("build", "materialize") through these knobs.
        self.ledger_category = ledger_category
        self.ledger_phase = ledger_phase
        self.calls = 0

    def _combine(self, chunk_labels: Sequence[int | None]) -> int | None:
        if any(x is None for x in chunk_labels):
            return None
        rule = self.config.get("record_result_rule", "logical_or_over_chunks")
        if rule == "logical_or_over_chunks":
            return 1 if any(chunk_labels) else 0
        raise ValueError(f"unknown record_result_rule {rule!r}")

    def read(self, record_ids: Sequence[str]) -> dict:
        from query.predicates import render_prompt

        rule = self.config.get("chunk_rule")
        ids = list(record_ids)
        if not ids:
            return {}

        prompts: list[str] = []
        owner: list[tuple[str, int]] = []  # (record_id, chunk_count) per prompt
        chunk_counts: dict[str, int] = {}
        for rid in ids:
            text = self.texts.get(rid)
            if text is None:
                raise KeyError(f"record {rid!r} has no text in this snapshot")
            chunks = chunk_text(text, rule)
            chunk_counts[rid] = len(chunks)
            for ch in chunks:
                prompts.append(render_prompt(self.predicate, ch))
                owner.append((rid, len(chunks)))

        raw = self.backend.label(prompts)
        if raw is None or len(raw) != len(prompts):
            raise RuntimeError(
                f"backend returned {0 if raw is None else len(raw)} labels for "
                f"{len(prompts)} prompts"
            )

        by_record: dict[str, list] = {rid: [] for rid in ids}
        for (rid, _), lab in zip(owner, raw):
            by_record[rid].append(lab)

        out: dict[str, int] = {}
        for rid in ids:
            combined = self._combine(by_record[rid])
            if combined is None:
                raise RuntimeError(f"backend failed on a chunk of record {rid!r}")
            out[rid] = combined

        self.calls += len(prompts)
        cost = getattr(self.backend, "last_cost", None) or {}
        # exposed so BudgetedOracle can enforce token/GPU-time caps (7.1)
        self.last_cost = cost
        if self.ledger is not None:
            self.ledger.record(
                self.ledger_category,
                self.ledger_phase,
                semantic_calls=len(prompts),
                records_read=len(ids),
                input_tokens=int(cost.get("input_tokens", 0)),
                output_tokens=int(cost.get("output_tokens", 0)),
                gpu_active_ms=float(cost.get("gpu_active_ms", 0.0)),
                request_id=self.request_id,
                note=f"predicate={self.predicate.id}; chunks={sum(chunk_counts.values())}",
            )
        return out


def build_label_snapshot(
    backend,
    predicate,
    operator_config: Mapping[str, Any],
    texts: Mapping[str, str],
    record_ids: Sequence[str],
    snapshot_hash: str = "",
    repeats: int = 1,
    ledger=None,
) -> LabelSnapshot:
    """Produce the canonical label snapshot with a duplicate-consistency check.

    Proposal 10.3: repeated runs are not assumed identical across hardware or
    batch sizes. Each record is labelled ``repeats`` times, the disagreements
    are *reported* (never averaged away), and the published snapshot takes the
    majority label -- ties resolve to 0 (4.3: "no explicit statement" is
    output 0), matching ``_majority`` in scripts/run_semantic_operator.py.
    """
    operator = ReferenceOperator(backend, predicate, operator_config, texts, ledger=ledger)
    repeated: dict[str, list[int]] = {rid: [] for rid in record_ids}
    for _ in range(max(1, int(repeats))):
        labels = operator.read(list(record_ids))
        for rid in record_ids:
            repeated[rid].append(labels[rid])

    canonical: dict[str, int] = {}
    for rid, runs in repeated.items():
        ones = sum(1 for v in runs if v == 1)
        zeros = len(runs) - ones
        canonical[rid] = 1 if ones > zeros else 0

    return LabelSnapshot(
        predicate_id=predicate.id,
        snapshot_hash=snapshot_hash,
        env=dict(operator_config),
        labels=canonical,
        duplicate_check=duplicate_consistency_report(repeated),
        created_utc=datetime.now(timezone.utc).isoformat(timespec="seconds"),
    )
