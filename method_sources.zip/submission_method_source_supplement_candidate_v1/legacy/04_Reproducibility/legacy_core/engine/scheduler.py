"""Certificate-driven scheduler (scheme 8.2) and the signed push-forward that
turns per-cell count intervals into per-contrast intervals (scheme 7.5).

Everything here is CPU math -- no GPU, no model. The scheduler decides *which*
cell to advance next and *how many* records, using only interval-width
predictions and the certificate difficulty. It never reads inside a cell (that
would violate the uniform-permutation rule); it only picks a cell.

Key identities (scheme):
  * contrast width   W_j = sum_h |a_{j,h}| * v_h,  v_h = u_h - l_h
  * contrast midpoint theta~_j = (L_j + U_j) / 2     (NOT a point estimate)
  * difficulty       d_j = max(theta~_j - b_j, eps_sched),  r_j = W_j / (2 d_j)
  * certificate Psi(w) = (1/gamma) log( mean_j exp(gamma r_j) )
  * predicted width after adding b records to cell h:
        v_h' = v_h * sqrt( n_h (N_h - n_h - b_h) / ((n_h + b_h)(N_h - n_h)) )
    valid only for 0 < n_h < n_h+b_h < N_h; an un-sampled cell keeps its full
    width until its init batch, a finished cell has width 0.
"""
from __future__ import annotations

import math
import random
from fractions import Fraction
from typing import Any, Mapping

EPS_SCHED = 1e-4  # numerical guard for division; never replaces business tolerance
INIT_BATCH = 8
BATCH_CHOICES = (16, 32, 64)


def cell_coeff(cell, row_index) -> Fraction:
    """The (uniform) coefficient of atom-row ``row_index`` inside ``cell``."""
    return cell.signature[row_index]


def predict_cell_width(cs, batch: int) -> float:
    """Predicted K_h interval width after appending ``batch`` records (scheme 8.2)."""
    n, N = cs.n, cs.N
    v = float(cs.width)
    if n == 0:
        return v  # init batch, no shrinkage predicted yet
    if n + batch >= N:
        return 0.0  # cell will be exhausted -> exact
    if not (0 < n < n + batch < N):
        return v
    factor = math.sqrt(n * (N - n - batch) / ((n + batch) * (N - n)))
    return v * factor


def pushforward_contrast_bounds(
    c_j_by_row: dict, cells, cell_cs: dict, family
) -> dict[int, tuple[Fraction, Fraction] | None]:
    """Map each atom to its signed-contrast interval (L_j, U_j) (scheme 7.5).

    ``c_j_by_row[row]`` is the exact pilot contribution for that coefficient
    row; each cell contributes ``a_{j,h} * K_h`` with K_h in the cell's current
    integer confidence set. Returns ``None`` for an atom whose interval cannot be
    formed because a supporting cell is inconsistent.
    """
    out: dict[int, tuple[Fraction, Fraction] | None] = {}
    for atom in family.atoms:
        r = atom.row_index
        cj = c_j_by_row.get(r, Fraction(0))
        L = cj
        U = cj
        ok = True
        for cell in cells:
            a = cell.signature[r]
            bnd = cell_cs[cell.cell_id].bounds
            if bnd is None:
                ok = False
                break
            lo, hi = bnd
            if a >= 0:
                L += a * lo
                U += a * hi
            else:
                L += a * hi
                U += a * lo
        out[atom.index] = (L, U) if ok else None
    return out


def atom_difficulty(L: Fraction, U: Fraction, threshold: Fraction, kind: str,
                    eps: float = EPS_SCHED):
    W = float(U - L)
    mid = float((L + U) / 2)
    gap = (mid - float(threshold)) if kind == "lower" else (float(threshold) - mid)
    d = max(gap, eps)
    return W, d, W / (2.0 * d)


def _atom_satisfied(bnd: tuple[Fraction, Fraction], atom) -> bool:
    """True when the current interval already certifies this atom (5.3 strict)."""
    lo, hi = bnd
    if atom.kind == "lower":
        return lo > atom.threshold
    return hi < atom.threshold


def certificate_difficulty(
    family, contrast_bounds: dict, gamma: float = 1.0, eps: float = EPS_SCHED
) -> list[tuple[list[int], float | None]]:
    """Per-certificate list of (open atom ids, Psi). Psi None if a supporting
    atom has no interval yet.

    Only atoms in ``J_w^open`` -- the not-yet-certified ones -- contribute
    (scheme 8.2). Atoms the current bounds already certify are exact facts
    about the answer; scheduling budget toward them buys nothing. A
    certificate whose atoms are all certified has Psi 0.0: it is complete and
    belongs to the answer checker, not the scheduler.

    ``gamma`` is the smoothing temperature and ``eps`` the fixed numerical
    guard in ``d_j = max(theta~_j - b_j, eps)``. Both are dev-set hyper-parameters
    (proposal 23): they are passed in rather than read from module state so a
    single process can run an ablation without importing-order luck.
    """
    out = []
    for cert in family.certificates:
        rs: list[float] = []
        open_atoms: list[int] = []
        valid = True
        for aid in cert:
            bnd = contrast_bounds.get(aid)
            if bnd is None:
                valid = False
                break
            atom = family._by_index[aid]
            if _atom_satisfied(bnd, atom):
                continue  # certified: not in J_w^open
            _, _, r = atom_difficulty(bnd[0], bnd[1], atom.threshold, atom.kind, eps=eps)
            rs.append(r)
            open_atoms.append(aid)
        if not valid:
            out.append((open_atoms, None))
            continue
        if not rs:
            out.append(([], 0.0))
            continue
        mx = max(rs)
        logmean = math.log(sum(math.exp(gamma * (r - mx)) for r in rs) / len(rs)) + gamma * mx
        out.append((open_atoms, logmean / gamma))
    return out


def decision_difficulty(
    family, contrast_bounds: dict, gamma: float = 1.0, eps: float = EPS_SCHED
) -> list[float | None]:
    """Per-declared-decision difficulty: the *best* certificate of that decision.

    Certificates inside one decision are alternatives (OR), so the decision is
    settled by the easiest of them; decisions themselves are a conjunction (AND),
    so their difficulties add. Summing over the flat certificate list instead --
    what a naive implementation does -- makes a top-1 request look 8x harder
    than it is and misdirects the allocation (scheme 8.2).
    """
    per_cert = certificate_difficulty(family, contrast_bounds, gamma, eps=eps)
    out: list[float | None] = []
    for di in family.decision_indices():
        vals = [
            per_cert[ci][1]
            for ci, d in enumerate(family.certificate_decisions)
            if d == di
        ]
        measurable = [v for v in vals if v is not None]
        # One unmeasurable certificate does not sink the decision, but a
        # decision with no measurable certificate is unmeasurable.
        out.append(min(measurable) if measurable else None)
    return out


def bundle_difficulty(family, contrast_bounds: dict, gamma: float = 1.0,
                      eps: float = EPS_SCHED) -> float:
    """Total open difficulty of a request: sum over its declared decisions."""
    return sum(
        v for v in decision_difficulty(family, contrast_bounds, gamma, eps=eps)
        if v is not None
    )


def _choose_batch(cs) -> int:
    remaining = cs.N - cs.n
    if cs.n == 0:
        return min(INIT_BATCH, remaining)
    for b in BATCH_CHOICES:
        if b <= remaining:
            return b
    return remaining


def choose_by_certificate_gain_per_cost(
    cells, cell_cs: dict, c_j_by_row: dict, family,
    gamma: float = 1.0, cost_per_record: "float | Mapping" = 1.0,
    explore: bool = False,
    explore_rng: random.Random | None = None, epsilon_sched: float = EPS_SCHED,
) -> tuple[int, int]:
    """Pick ``(cell_id, batch)`` maximizing predicted certificate-difficulty
    reduction per predicted cost (scheme 8.2 / pseudo-code line 797).

    ``cost_per_record`` is either a uniform float or a ``{cell_id: cost}``
    mapping -- the mapping form is the §18 heterogeneous-cost arm, where a
    cell's records are priced by their mean text length instead of uniformly.

    ``explore=True`` forces a not-yet-finished cell chosen by ``explore_rng``
    (the fixed exploration rounds of scheme 8.2). The rng is passed in and
    seeded by the caller: a module-level global would make the same
    ``sampling_seed`` produce different trajectories across runs, breaking
    the fixed-oracle replay protocol (17.3). Returns ``(-1, 0)`` only when
    every cell is finished.
    """
    not_done = [c for c in cells if cell_cs[c.cell_id].n < cell_cs[c.cell_id].N]
    if not not_done:
        return -1, 0

    if explore:
        rng = explore_rng if explore_rng is not None else random.Random(0)
        c = rng.choice(not_done)
        return c.cell_id, _choose_batch(cell_cs[c.cell_id])

    # 8.2: un-sampled cells get one initialization batch first. The width
    # prediction is meaningless at n=0 (predict_cell_width just returns the
    # full width), so the gain heuristic would systematically starve them;
    # deterministically serve the largest un-sampled cell first.
    unsampled = [c for c in not_done if cell_cs[c.cell_id].n == 0]
    if unsampled:
        c = max(unsampled, key=lambda x: (x.N, x.cell_id))
        return c.cell_id, _choose_batch(cell_cs[c.cell_id])

    cur_bounds = pushforward_contrast_bounds(c_j_by_row, cells, cell_cs, family)
    cur_total = bundle_difficulty(family, cur_bounds, gamma, eps=epsilon_sched)

    best = None  # (gain_per_cost, cell_id, batch)
    fallback = None  # largest remaining cell for the "all gains non-positive" case
    for c in not_done:
        cs = cell_cs[c.cell_id]
        b = _choose_batch(cs)
        # Predict widths: only cell c shrinks; others keep current width.
        pred_widths = {}
        for cc in cells:
            ccs = cell_cs[cc.cell_id]
            pred_widths[cc.cell_id] = (
                predict_cell_width(ccs, b) if cc.cell_id == c.cell_id else float(ccs.width)
            )
        pred_bounds = _pushforward_with_widths(c_j_by_row, cells, cell_cs, family, pred_widths)
        pred_total = bundle_difficulty(family, pred_bounds, gamma, eps=epsilon_sched)
        gain = cur_total - pred_total  # reduction in open-certificate difficulty
        if isinstance(cost_per_record, Mapping):
            unit = float(cost_per_record.get(c.cell_id, 1.0))
        else:
            unit = float(cost_per_record)
        cost = unit * b
        gpc = gain / cost if cost > 0 else 0.0
        if best is None or gpc > best[0]:
            best = (gpc, c.cell_id, b)
        if fallback is None or cs.N > cell_cs[fallback[0]].N:
            fallback = (c.cell_id, b)

    if best is not None and best[0] > 0:
        return best[1], best[2]
    # All predicted gains non-positive: pick the largest not-done cell.
    return fallback


def _pushforward_with_widths(
    c_j_by_row, cells, cell_cs, family, pred_widths: dict
) -> dict[int, tuple[Fraction, Fraction] | None]:
    """Like pushforward_contrast_bounds but using predicted (float) widths for
    cells whose interval has not been narrowed yet. Used only for scheduling
    predictions -- the real bounds always come from CellCS."""
    out: dict[int, tuple[Fraction, Fraction] | None] = {}
    for atom in family.atoms:
        r = atom.row_index
        cj = c_j_by_row.get(r, Fraction(0))
        L = float(cj)
        U = float(cj)
        ok = True
        for cell in cells:
            a = float(cell.signature[r])
            cs = cell_cs[cell.cell_id]
            bnd = cs.bounds
            if bnd is None:
                ok = False
                break
            lo, hi = bnd
            cur_w = float(hi - lo)
            pred_w = pred_widths.get(cell.cell_id, cur_w)
            if cur_w > 0 and pred_w < cur_w:
                # shrink the integer interval symmetrically toward its midpoint
                mid = (lo + hi) / 2.0
                plo = mid - pred_w / 2.0
                phi = mid + pred_w / 2.0
            else:
                plo, phi = float(lo), float(hi)
            if a >= 0:
                L += a * plo
                U += a * phi
            else:
                L += a * phi
                U += a * plo
        out[atom.index] = (Fraction(L), Fraction(U)) if ok else None
    return out
