"""Deterministic output verification (proposal 10.5).

The renderer is allowed to organise the answer, but a *deterministic checker*
decides whether the answer may be published. It cannot verify that a sentence
is true in the world -- nobody can -- but it can and must verify that the
output does not exceed what was executed:

* every interval is well formed (L <= U) and parseable as an exact rational;
* every claimed certificate is actually satisfied by the reported intervals --
  a claim is re-checked from scratch, not trusted from the caller;
* every quoted record was really read by the operator;
* cohort sizes are positive and cover the cohorts of the decision;
* alpha is in range and the risk scope is stated.

Anything that fails is returned as a list of reasons. The pipeline downgrades
the certificate to ``execution_error`` rather than shipping it, and the failure
itself stays in the metric denominator.
"""
from __future__ import annotations

from fractions import Fraction
from typing import Any, Mapping

__all__ = ["ALLOWED_STATUSES", "verify_certificate"]

ALLOWED_STATUSES = ("certified", "unresolved", "unsupported", "execution_error")


def _as_fraction(x: Any):
    """Parse a rendered interval endpoint back into an exact rational."""
    if isinstance(x, Fraction):
        return x
    if isinstance(x, int):
        return Fraction(x)
    if isinstance(x, str):
        return Fraction(x)
    return None


def verify_certificate(
    cert: Mapping[str, Any],
    family=None,
    contract: Mapping[str, Any] | None = None,
) -> list[str]:
    """Return a list of problems; empty means the object may be published."""
    errors: list[str] = []

    status = cert.get("status")
    if status not in ALLOWED_STATUSES:
        errors.append(f"status {status!r} not in {ALLOWED_STATUSES}")
        return errors  # nothing else is meaningful

    alpha = cert.get("alpha")
    if not isinstance(alpha, (int, float)) or not (0.0 < float(alpha) < 1.0):
        errors.append(f"alpha {alpha!r} outside (0,1)")

    if not cert.get("risk_scope"):
        errors.append("risk_scope is empty: sampling / semantic / scope must be separated")

    # -- intervals ---------------------------------------------------------
    bounds: dict[int, tuple[Fraction, Fraction]] = {}
    for item in cert.get("contrast_intervals") or []:
        idx = item.get("atom_index")
        raw = item.get("interval")
        if raw is None:
            errors.append(f"atom {idx} has no interval")
            continue
        if not isinstance(raw, (list, tuple)) or len(raw) != 2:
            errors.append(f"atom {idx} interval is not a 2-tuple: {raw!r}")
            continue
        lo, hi = _as_fraction(raw[0]), _as_fraction(raw[1])
        if lo is None or hi is None:
            errors.append(f"atom {idx} endpoint is not an exact rational: {raw!r}")
            continue
        if lo > hi:
            errors.append(f"atom {idx} has an empty interval ({lo} > {hi})")
            continue
        bounds[int(idx)] = (lo, hi)

    # -- re-check every claim from the intervals ---------------------------
    if family is not None:
        claimed = list(cert.get("certified_claim_ids") or [])
        for ci in claimed:
            if not (0 <= ci < len(family.certificates)):
                errors.append(f"certified claim {ci} is not a certificate index")
                continue
            for aid in family.certificates[ci]:
                if aid not in bounds:
                    errors.append(f"claim {ci} cites atom {aid} with no interval")
                    continue
                atom = family._by_index[aid]
                lo, hi = bounds[aid]
                if atom.kind == "lower" and not (lo > atom.threshold):
                    errors.append(
                        f"claim {ci}: atom {aid} certified lower but L={lo} <= b={atom.threshold}"
                    )
                if atom.kind == "upper" and not (hi < atom.threshold):
                    errors.append(
                        f"claim {ci}: atom {aid} certified upper but U={hi} >= b={atom.threshold}"
                    )
        # A claim no interval supports must not be listed as certified.
        # The bounds dict above only carries atoms the certificate object
        # reported; family.check would raise KeyError on a missing atom
        # instead of reporting it, and the verifier is the last line of
        # defense -- it must degrade to an error list, never crash.
        complete = bounds and all(
            aid in bounds
            for cert_ids in family.certificates
            for aid in cert_ids
        )
        recomputed = family.check(bounds) if complete else []
        for ci in claimed:
            if ci not in recomputed:
                errors.append(f"claim {ci} listed as certified but not satisfied by intervals")

        # -- bundle completeness (scheme 17.1) -----------------------------
        # Publishing "certified" while silently dropping the hardest judgement
        # of a multi-judgement request would inflate the coverage metric, so it
        # is checked here rather than trusted from the renderer.
        if status == "certified" and not family.bundle_complete(claimed):
            unsettled = [
                d["decision_index"] for d in family.per_decision_status(claimed)
                if not d["certified"]
            ]
            errors.append(
                f"status is 'certified' but decisions {unsettled} are not settled; "
                "a multi-judgement request must settle every declared comparison"
            )
        declared_status = cert.get("decision_status")
        if declared_status is not None:
            if len(declared_status) != family.decision_count:
                errors.append(
                    f"decision_status has {len(declared_status)} entries, "
                    f"contract declares {family.decision_count}"
                )
            for entry, actual in zip(declared_status, family.per_decision_status(claimed)):
                if bool(entry.get("certified")) != actual["certified"]:
                    errors.append(
                        f"decision {entry.get('decision_index')} reported "
                        f"certified={entry.get('certified')} but intervals say "
                        f"{actual['certified']}"
                    )

    # -- provenance --------------------------------------------------------
    sampled = set(cert.get("sampled_record_ids") or [])
    for q in cert.get("illustrative_quotes") or []:
        rid = q.get("record_id")
        if rid not in sampled:
            errors.append(f"quote cites record {rid!r} that was never read by the operator")
        if not q.get("text_sha256"):
            errors.append(f"quote for {rid!r} has no text hash")

    # -- cohorts / known denominators --------------------------------------
    sizes = cert.get("cohort_sizes") or {}
    if not sizes:
        errors.append("cohort_sizes is empty: the known denominator must be reported")
    for cid, n in sizes.items():
        if not isinstance(n, int) or n <= 0:
            errors.append(f"cohort {cid!r} has non-positive size {n!r}")
    if contract is not None:
        declared = {c["id"] for c in contract.get("cohorts", []) if "id" in c}
        missing = declared - set(sizes)
        if missing:
            errors.append(f"cohort_sizes missing declared cohorts: {sorted(missing)}")

    return errors
