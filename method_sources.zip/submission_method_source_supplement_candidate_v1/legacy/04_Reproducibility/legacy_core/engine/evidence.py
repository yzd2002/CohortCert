"""Illustrative quote retrieval (proposal 10.4).

Two different kinds of retrieval exist in this system and must never be mixed:

* **statistical evidence acquisition** -- which records are sent to the semantic
  operator. It must obey within-cell uniform sampling and cover the population.
* **illustrative quote retrieval** -- a few spans, chosen *from records that were
  already processed*, that help a human understand what the predicate matched.

Quotes are decoration and provenance, never evidence: two positive quotes do
not mean most of the cohort is positive, and a quote can never substitute for
the sampling certificate. Every quote therefore carries the record id, the hash
of the exact text and the character range it was cut from.
"""
from __future__ import annotations

from typing import Mapping, Sequence

from engine.oracle_interface import text_sha256

__all__ = ["illustrative_quotes", "MAX_QUOTE_CHARS"]

MAX_QUOTE_CHARS = 240


def illustrative_quotes(
    sampled_record_ids: Sequence[str],
    labels: Mapping[str, int],
    texts: Mapping[str, str] | None = None,
    max_quotes: int = 3,
    max_chars: int = MAX_QUOTE_CHARS,
) -> list[dict]:
    """Pick up to ``max_quotes`` positive observed spans, in read order.

    Only records that were actually read by the semantic operator are eligible
    -- retrieving a quote must not smuggle in unread evidence. Positive labels
    are preferred because they show what the predicate matched; if no positive
    was observed the list is legitimately empty and the certificate stands on
    its own.

    ``texts`` may be omitted (CPU / stub runs with no corpus loaded); the list
    is then empty rather than fabricated.
    """
    if not texts:
        return []
    if max_quotes <= 0:
        return []
    out: list[dict] = []
    for rid in sampled_record_ids:
        if labels.get(rid) != 1:
            continue
        text = texts.get(rid)
        if not text:
            continue
        span = text[:max_chars]
        out.append(
            {
                "record_id": rid,
                "text_sha256": text_sha256(text),
                "char_range": [0, len(span)],
                "span": span,
                "truncated": len(text) > max_chars,
            }
        )
        if len(out) >= max_quotes:
            break
    return out
