"""Fixed-time CI diagnostic (proposal 18: the unsafe demonstration arm).

This module exists to show WHY the confidence-sequence machinery is required,
not to compete. It reproduces the classic shortcut the proposal calls out --
"每轮都使用普通固定时刻 95% 区间" -- by swapping the anytime-valid CellCS for
an ordinary fixed-sample Clopper-Pearson interval recomputed after every round.

Everything else is held fixed: same snapshot, semantic operator, certificate
family, verifier, uniform-proportional allocation, no pilot (the Uniform-CS
skeleton). Exactly one statistical component changes, so any coverage failure
the run exhibits is attributable to sequential reuse of a fixed-time interval
alone -- the per-cell risk split and the family machinery are untouched.

UNSAFE BY CONSTRUCTION. Reusing a fixed-time interval across rounds inflates
the false-coverage rate far above its nominal level (the multiple-testing
effect the Ville-threshold CS exists to prevent). Output is nominal-only and
must never enter a coverage claim: ``registry.is_validity_controlled`` is
False for this method, and runs land in diagnostic output files only.
"""
from __future__ import annotations

from fractions import Fraction
from typing import Mapping, Sequence

from scipy.stats import beta

__all__ = ["FixedTimeCS", "run_fixed_ci_diag"]


class FixedTimeCS:
    """Per-round fixed-sample (1-alpha) interval for one cell's positive count.

    Deliberately mirrors the CellCS interface surface pipeline.answer touches
    (``N``/``n``/``update``/``bounds``/``inconsistent``). The per-cell alpha it
    is handed is the pipeline's correct split across cells; what is dropped is
    ONLY the anytime-valid tracking -- each round gets a fresh fixed-time
    interval, which is exactly the unsafe practice the proposal names.
    """

    def __init__(self, N: int, alpha: float = 0.05, a: float = 1.0,
                 b: float = 1.0, lam: float = 0.5):
        self.N = int(N)
        self.alpha = float(alpha)
        self.n = 0
        self.s = 0
        self.inconsistent = False
        self._bounds: tuple[Fraction, Fraction] = (Fraction(0), Fraction(self.N))

    def update(self, labels: Sequence[int]) -> None:
        self.n += len(labels)
        self.s += sum(1 for x in labels if x == 1)
        if self.n == 0:
            return
        # Clopper-Pearson on the sampled proportion; empty tails clamp to the
        # deterministic bound. Scaled to a cell-total interval: the pushforward
        # multiplies by exact signed coefficients, so the naive practitioner's
        # "p_hat times N" translation is what this arm exhibits.
        lo_p = float(beta.ppf(self.alpha / 2, self.s, self.n - self.s + 1)) \
            if self.s > 0 else 0.0
        hi_p = float(beta.ppf(1 - self.alpha / 2, self.s + 1, self.n - self.s)) \
            if self.s < self.n else 1.0
        lo = max(0.0, lo_p * self.N)
        hi = min(float(self.N), hi_p * self.N)
        if lo > hi:  # cannot happen for CP, but never emit an empty interval
            lo, hi = hi, lo
        self._bounds = (Fraction(lo).limit_denominator(10**9),
                        Fraction(hi).limit_denominator(10**9))

    @property
    def bounds(self) -> tuple[Fraction, Fraction]:
        return self._bounds


def run_fixed_ci_diag(
    contract,
    snapshot,
    oracle,
    alpha: float = 0.05,
    budget_calls: int = 1024,
    seed: int = 0,
    texts: Mapping[str, str] | None = None,
    ledger=None,
    request_id: str | None = None,
    proxy=None,
    **render_kw,
):
    """Run the request with fixed-time per-round intervals (UNSAFE diagnostic)."""
    from engine.baselines.uniform_cs import proportional_strategy
    from engine.pipeline import answer

    return answer(
        contract, snapshot, oracle, alpha=alpha, budget_calls=budget_calls,
        seed=seed, texts=texts, ledger=ledger, request_id=request_id,
        scheduler_strategy=proportional_strategy, use_pilot=False,
        proxy=proxy, cell_cs_factory=FixedTimeCS, **render_kw,
    )
