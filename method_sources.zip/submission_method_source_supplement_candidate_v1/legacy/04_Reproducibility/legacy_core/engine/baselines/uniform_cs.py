"""Uniform-CS baseline (proposal 16).

Uniform sampling with correct risk control and the same output contract. It is
the honest "do nothing clever" competitor: same frozen snapshot, same semantic
operator, same confidence-sequence kernel, same certificate family, same
verifier -- but no pilot and no certificate-driven allocation.

What is deliberately *kept*:

* coefficient-cell stratification. It is not a trick of this method, it is what
  makes a finite-population confidence sequence valid at all: inside a cell
  every record contributes the same coefficient, so the cell reduces to one
  count. Baselines that split allocation across cells with mixed coefficients
  would not be controlling risk, they would just be wider without saying so.

What is deliberately *dropped*:

* the pilot (``c_j`` starts at zero, so the cells carry the whole burden);
* the certificate-gain heuristic (allocation is proportional, not steered).
"""
from __future__ import annotations

import random
from typing import Mapping

from engine.scheduler import BATCH_CHOICES

__all__ = ["proportional_strategy", "run_uniform_cs"]

_BATCH = 16


def proportional_strategy(cells, cell_cs, c_j, family, seed: int | None = None):
    """Advance cells in proportion to their size, ignoring the certificate.

    The cell whose sampled fraction is furthest below the overall fraction goes
    next -- proportional allocation carried out greedily, one batch at a time.
    """
    not_done = [c for c in cells if cell_cs[c.cell_id].n < cell_cs[c.cell_id].N]
    if not not_done:
        return -1, 0
    c = min(not_done, key=lambda c: (cell_cs[c.cell_id].n / cell_cs[c.cell_id].N))
    remaining = cell_cs[c.cell_id].N - cell_cs[c.cell_id].n
    return c.cell_id, min(_BATCH, remaining)


def run_uniform_cs(
    contract,
    snapshot,
    oracle,
    alpha: float = 0.05,
    budget_calls: int = 1024,
    seed: int = 0,
    texts: Mapping[str, str] | None = None,
    ledger=None,
    request_id: str | None = None,
    proxy=None,
    **render_kw,
):
    """Run the request under Uniform-CS.

    ``proxy`` is accepted for plumbing symmetry (16.3): this baseline drops the
    pilot, so a proxy that needs labels to fit has nothing to fit on and the
    pipeline falls back to the deterministic stub -- identically for every
    method with ``use_pilot=False``. What is deliberately dropped here is the
    pilot and the gain heuristic, not some extra stub advantage.
    """
    from engine.pipeline import answer

    return answer(
        contract, snapshot, oracle, alpha=alpha, budget_calls=budget_calls,
        seed=seed, texts=texts, ledger=ledger, request_id=request_id,
        scheduler_strategy=proportional_strategy, use_pilot=False,
        proxy=proxy, **render_kw,
    )
