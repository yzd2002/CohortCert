"""ProxyStratified-CS baseline (proposal 16): ABae / UQE style.

Proxy-driven stratification with cost-aware allocation, running on the *same*
confidence-sequence kernel and the same output contract as this method. It is
the strongest classical competitor because it uses exactly the information
CohortCert uses -- the frozen proxy prior -- but for a different purpose: to
balance estimator variance per layer instead of to settle a certificate.

Design constraints that keep the comparison fair and the statistics valid:

* stratification is proxy-driven (finer proxy quantile bins than this method
  uses), but never mixes coefficient signatures inside a layer: a layer with
  mixed coefficients cannot be summarised by one count, so a confidence
  sequence over it would not be the risk-controlling quantity it claims to be;
* allocation is the Neyman / cost-aware rule -- layer weight
  ``sqrt(N_h p_h (1 - p_h))`` with the proxy mean as ``p_h`` -- and never looks
  at the certificate family;
* the number of bins degrades automatically to respect the cell cap (scheme
  7.1, H <= 64) instead of merging distinct coefficients.
"""
from __future__ import annotations

from fractions import Fraction
from typing import Mapping

from engine.frozen_cells import MAX_CELLS, Cell, quantize
from engine.baselines.shared_contrast import neyman_strategy

__all__ = ["make_proxy_cell_factory", "run_proxy_stratified_cs"]


def _signature(A, record_id) -> tuple:
    return tuple(A.rows[r].get(record_id, Fraction(0)) for r in range(len(A.rows)))


def make_proxy_cell_factory(proxy, n_bins: int = 8, max_cells: int = MAX_CELLS):
    """Return a ``(active_ids, A) -> cells`` stratifier with proxy quantile bins.

    Bins are reduced -- never merged across coefficient signatures -- until the
    partition fits the cell cap, so the baseline always runs.
    """
    def factory(active_ids, A):
        sigs = {i: _signature(A, i) for i in active_ids}
        n_sig = len(set(sigs.values()))
        bins = max(1, min(n_bins, max_cells // max(n_sig, 1)))
        while bins > 1 and n_sig * bins > max_cells:
            bins -= 1

        groups: dict[tuple, list] = {}
        for i in active_ids:
            key = (sigs[i], quantize(proxy.score(i), bins))
            groups.setdefault(key, []).append(i)

        return [
            Cell(cid, sig, b, sorted(recs))
            for cid, ((sig, b), recs) in enumerate(groups.items())
        ]

    return factory


def run_proxy_stratified_cs(
    contract,
    snapshot,
    oracle,
    proxy,
    alpha: float = 0.05,
    budget_calls: int = 1024,
    seed: int = 0,
    n_bins: int = 8,
    texts: Mapping[str, str] | None = None,
    ledger=None,
    request_id: str | None = None,
    **render_kw,
):
    """Run the request under ProxyStratified-CS (ABae / UQE style)."""
    from engine.pipeline import answer

    return answer(
        contract, snapshot, oracle, alpha=alpha, budget_calls=budget_calls,
        seed=seed, texts=texts, ledger=ledger, request_id=request_id,
        cell_factory=make_proxy_cell_factory(proxy, n_bins=n_bins),
        scheduler_strategy=neyman_strategy(proxy),
        proxy=proxy,
        **render_kw,
    )
