"""BARGAIN baseline (proposal 16 / 16.2).

BARGAIN [R8] optimises model calls against a **row-level quality target**: it
guarantees that the total number of binary label errors stays within a budget
``r``, with a declared risk. That guarantee is about *labels*, not about the
*final comparison* -- and proposal 16.2 is explicit that the two must not be
conflated:

    行级错误保证传递到最终对比；不能把精确率保证当作比较方向保证。

So the honest adaptation is a two-step propagation, and both steps are done
here rather than hand-waved:

1. bound the number of wrong labels among the *unaudited* records by ``r``,
   using an anytime-valid bound on a count -- the same finite-population
   likelihood-ratio confidence sequence every other method uses, so the
   comparison is not contaminated by a different statistical kernel;
2. propagate ``r`` into every contrast as an interval inflation
   ``rho_j(r)``: if at most ``r`` unaudited labels are wrong, then ``theta_j``
   can move by at most the sum of the ``r`` largest ``|c_i|`` over the unaudited
   records. No assumption about *which* records are wrong, hence the bound is
   valid but deliberately pessimistic.

Only the error bound the method actually delivers may be used: ``r`` comes out
of the confidence sequence at risk ``delta``, never from an empirical accuracy
number measured on the same run (that would be fitting the guarantee to the
data it is supposed to cover).

The trap this baseline is here to expose
----------------------------------------
A proxy can be 95% accurate and still certify nothing. ``rho_j(r)`` sums the
largest coefficients, so a handful of plausible errors among the records that
carry the biggest weight can move the contrast further than the threshold. A
system that reports "precision 95%, therefore A > B" is not making a
comparison guarantee, and this baseline shows where that shortcut breaks.
"""
from __future__ import annotations

from fractions import Fraction
from typing import Mapping

from engine.cost_ledger import flatten_charged_cost
from engine.finite_population_cs import CellCS

__all__ = ["rho_j", "run_bargain", "predict_labels"]


def predict_labels(proxy, record_ids) -> dict:
    """Cheap-model predictions: the proxy thresholded at 1/2."""
    return {i: int(proxy.score(i) >= 0.5) for i in record_ids}


def rho_j(coefficients: Mapping, r: int) -> Fraction:
    """Widest move of ``theta`` if at most ``r`` of these labels are wrong.

    Sum of the ``r`` largest ``|c_i|`` -- conservative because the adversary
    picks which records are wrong, but not arbitrarily conservative: it uses the
    actual coefficient magnitudes of this contrast.
    """
    r = int(max(0, r))
    if r == 0:
        return Fraction(0)
    mags = sorted((abs(c) for c in coefficients.values()), reverse=True)
    return sum(mags[:r], Fraction(0))


def run_bargain(
    contract,
    snapshot,
    oracle,
    proxy=None,
    alpha: float = 0.05,
    budget_calls: int = 1024,
    seed: int = 0,
    delta: float | None = None,
    audit_batch: int = 32,
    texts: Mapping[str, str] | None = None,
    ledger=None,
    request_id: str | None = None,
    trace=None,
    **render_kw,
):
    """Run one request under the BARGAIN adaptation.

    ``delta`` is the risk of the row-level error bound and therefore the risk of
    the final interval. It defaults to ``alpha`` so the comparison against the
    other methods is made at the same declared risk (proposal 16.3).
    """
    import random

    from engine.pipeline import (
        BudgetedOracle,
        OracleFailure,
        RetryPolicy,
        deterministic_bounds_already_decide,
        fixed_uniform_pilot,
        render_verified,
        semantic_sensitivity,
        unsupported_certificate,
        verify_certificate,
    )
    from engine.evidence import illustrative_quotes
    from engine.answer_checker import decide
    from query.compiler import compile_signed_decisions, effective_support
    from query.contract_schema import ContractUnsupported

    delta = float(alpha) if delta is None else float(delta)
    reader = BudgetedOracle(
        oracle, budget_calls=budget_calls, ledger=ledger,
        request_id=request_id, retry=RetryPolicy(),
    )
    observed_labels: dict = {}
    sampled_record_ids: list = []

    try:
        A, family = compile_signed_decisions(
            contract, snapshot,
            keep_cancellations=bool(render_kw.get("keep_cancellations", False)))
    except ContractUnsupported as e:
        return unsupported_certificate(
            e.reason, contract=contract, alpha=alpha, seed=seed,
            semantic_calls=reader.spent, records_read=0, budget_calls=budget_calls,
        )

    # 2026-10-13 fix: ``audited`` / ``errors_observed`` / ``r_unaudited`` used to
    # be initialised *below*, after this function.  Every early return -- empty
    # support, a structural (deterministic) decision, or an OracleFailure --
    # therefore hit ``NameError`` instead of returning a certificate.  They are
    # seeded here with the "nothing audited yet" values, which is exactly right
    # for those paths; the real values are set once the audit loop starts.
    audited: list = []
    errors_observed = 0
    r_unaudited = 0

    def _render(bounds, satisfied, reason="", status_override="", info=None):
        charged = (
            ledger.request_cost(request_id)
            if ledger is not None and request_id
            else {
                "semantic_calls": reader.spent,
                "records_read": len(observed_labels),
                "budget_calls": budget_calls,
                "source": "local_counter; no ledger attached",
            }
        )
        # 10.1: same top-level shape as pipeline._render — consumers read
        # charged["semantic_calls"]; the raw nesting reported 0 there.
        charged = flatten_charged_cost(charged)
        cert = render_verified(
            contract, family, bounds, satisfied, alpha, seed,
            render_kw.get("snapshot_hash", ""), render_kw.get("query_contract_hash", ""),
            render_kw.get("partition_hash", ""), render_kw.get("model_and_prompt_hash", ""),
            sampled_record_ids=sampled_record_ids,
            semantic_sensitivity=(
                semantic_sensitivity(A, family, bounds, satisfied) if satisfied else []
            ),
            charged_cost=charged,
            illustrative_quotes=illustrative_quotes(
                sampled_record_ids, observed_labels, texts,
                max_quotes=render_kw.get("max_quotes", 3),
            ),
            bundle_complete=family.bundle_complete(satisfied),
            decision_status=family.per_decision_status(satisfied),
        )
        cert["method"] = "bargain"
        cert["validity"] = "row_level_error_propagation"
        cert["bargain"] = {
            "delta": delta,
            "audited": len(audited),
            "errors_observed": errors_observed,
            "r_unaudited": r_unaudited,
            "proxy_accuracy_on_audit": (
                None if not audited else 1.0 - errors_observed / len(audited)
            ),
        }
        if info:
            cert["bargain"].update(info)
        errs = verify_certificate(cert, family=family, contract=contract)
        if status_override:
            cert["status"] = status_override
            if reason:
                cert["reason"] = reason
        if errs and status_override not in ("unsupported",):
            cert["status"] = "execution_error"
            cert["verify_errors"] = errs
        return cert

    active_ids = sorted(effective_support(
        A, bool(render_kw.get("keep_cancellations", False))))
    if not active_ids:
        return _render({}, [], reason="no active support: contrast is identically zero")

    structural = deterministic_bounds_already_decide(A, family)
    if structural is not None:
        bounds, satisfied = structural
        if trace is not None:
            trace(bounds)
        return _render(bounds, satisfied)

    if proxy is None:
        from engine.proxy import StubProxy

        proxy = StubProxy(seed=seed)

    # --- pilot: exact labels, and the first look at proxy disagreement -------
    pilot_ids = fixed_uniform_pilot(active_ids, budget_calls, seed)
    try:
        pilot_labels = reader.read(pilot_ids, phase="pilot", caller="pilot")
    except OracleFailure as exc:
        return _render({}, [], reason=str(exc), status_override="execution_error")
    observed_labels.update(pilot_labels)
    sampled_record_ids.extend(pilot_ids)

    # 7.1 / G5: fit a real proxy (EmbeddingLRProxy) on this request's pilot
    # labels before predict_labels scores anything -- same rule as
    # pipeline.answer. A failed fit degrades to the deterministic stub.
    from engine.pipeline import _fit_proxy_or_fallback

    proxy = _fit_proxy_or_fallback(proxy, pilot_ids, pilot_labels, seed)

    remaining = [i for i in active_ids if i not in set(pilot_ids)]
    rng = random.Random(seed + 1)
    audit_order = list(remaining)
    rng.shuffle(audit_order)

    predicted = predict_labels(proxy, remaining)
    # audited / errors_observed already seeded above (see the fix note).
    r_unaudited = len(remaining)

    def _bounds_now() -> dict:
        """Point estimate widened by the worst case allowed by ``r``."""
        unaudited = [i for i in remaining if i not in audited_set]
        out = {}
        for atom in family.atoms:
            row = A.rows[atom.row_index]
            theta = Fraction(0)
            for i in pilot_ids:
                c = row.get(i)
                if c and pilot_labels[i]:
                    theta += c
            for i in audited:
                c = row.get(i)
                if c and observed_labels[i]:
                    theta += c
            unaudited_coeffs = {i: row[i] for i in unaudited if i in row}
            for i, c in unaudited_coeffs.items():
                if predicted[i]:
                    theta += c
            rho = rho_j(unaudited_coeffs, r_unaudited)
            out[atom.index] = (theta - rho, theta + rho)
        return out

    audited_set: set = set()

    def _update_r() -> None:
        """Re-bound the unaudited error count from the audit sample."""
        nonlocal r_unaudited
        n_audit = len(audited)
        M = len(remaining)
        if n_audit == 0:
            r_unaudited = M
            return
        cs = CellCS(N=M, alpha=delta, n=n_audit, s=errors_observed, lam=0.5)
        b = cs.bounds
        total_high = b[1] if b is not None else M
        r_unaudited = max(0, min(M - n_audit, total_high - errors_observed))

    _update_r()
    bounds = _bounds_now()
    satisfied = decide(family, bounds)
    if trace is not None:
        trace(bounds)

    cursor = 0
    while reader.remaining > 0 and cursor < len(audit_order):
        if family.bundle_complete(satisfied):
            break
        batch = min(audit_batch, reader.remaining, len(audit_order) - cursor)
        ids = audit_order[cursor: cursor + batch]
        try:
            labels = reader.read(ids, phase="oracle", caller="bargain_audit")
        except OracleFailure as exc:
            return _render(bounds, [], reason=str(exc), status_override="execution_error")
        observed_labels.update(labels)
        sampled_record_ids.extend(ids)
        for i in ids:
            audited.append(i)
            audited_set.add(i)
            if labels[i] != predicted[i]:
                errors_observed += 1
        cursor += batch
        _update_r()
        bounds = _bounds_now()
        satisfied = decide(family, bounds)
        if trace is not None:
            trace(bounds)

    return _render(bounds, satisfied)
