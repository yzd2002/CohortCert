"""IFocus / ordering-CS baseline (proposal 16).

IFocus [R10] samples **for an ordering**, not for mean accuracy: it spends its
budget resolving the group order a visualization needs and stops as soon as
that order is pinned down, long before every group mean is precise. Proposal 16
lists it as the strong classical control for ranking, and 25.2 concedes the
idea outright:

    承认排序导向抽样是已有思想。... 仅把 IFocus 的标签换成 LLM 调用不够。

So this is not a re-implementation of IFocus's original machinery. It is a
faithful *transfer of its execution principle* into this system:

* **target the ordering.** Allocation is restricted to the pairs that are
  adjacent in the current estimated ranking. A pair far apart in the ranking is
  irrelevant to the order no matter how wide its interval is, so buying
  evidence for it is wasted budget -- the exact opposite of a mean-precision
  objective, which would spend on the *widest* intervals.
* **same kernel, same contract.** It runs through ``engine.pipeline.answer``
  with only the allocation strategy swapped, so it shares the compiler, the
  coefficient cells, the finite-population confidence sequence, the renderer
  and the verifier. The comparison measures the *objective*, not the machinery.

What it does **not** do is lower the bar for certification: the status still
comes from ``family.check`` on the reported intervals, identical to every other
method. The ordering insight is reported separately as ``ordering``, because
"the order is determined" and "the declared certificate is satisfied" are
different statements and mixing them would manufacture a win.

The interesting failure mode
----------------------------
For a top-k certificate the family demands every cross-boundary pair be
separated, while the ordering only needs the adjacent ones. IFocus can therefore
settle the *ordering* several steps before it satisfies the *contract*. That gap
is reported rather than smoothed over: it is the empirical content of 25.2.
"""
from __future__ import annotations

from fractions import Fraction
from typing import Mapping, Sequence

from engine.scheduler import (
    choose_by_certificate_gain_per_cost,
    pushforward_contrast_bounds,
)

__all__ = [
    "estimate_ranking",
    "adjacent_pairs",
    "ordering_resolved",
    "make_ifocus_strategy",
    "run_ifocus_cs",
]


def estimate_ranking(family, bounds, candidates: Sequence[str]) -> list[str]:
    """Rank candidates by the pairwise evidence available right now.

    Each candidate is scored by the sum of its pairwise midpoints. This is only
    used to decide *where to spend next* -- the certified answer never comes
    from a ranking built on unfinished intervals.
    """
    score = {c: 0.0 for c in candidates}
    for atom in family.atoms:
        g, h = atom.cohort_pair
        if g not in score or h not in score:
            continue
        bnd = bounds.get(atom.index)
        if bnd is None:
            continue
        mid = (float(bnd[0]) + float(bnd[1])) / 2.0
        score[g] += mid
        score[h] -= mid
    return sorted(candidates, key=lambda c: -score[c])


def adjacent_pairs(order: Sequence[str]) -> list[tuple[str, str]]:
    return [(order[i], order[i + 1]) for i in range(len(order) - 1)]


def ordering_resolved(family, bounds, order: Sequence[str]) -> bool:
    """True when every adjacent pair in ``order`` is strictly separated.

    Separation of adjacent pairs plus simultaneous validity gives the whole
    ordering by transitivity: ``L_(i) > U_(i+1) >= theta_(i+1) >= L_(i+1) > ...``.
    """
    sep = set()
    for atom in family.atoms:
        bnd = bounds.get(atom.index)
        if bnd is None:
            continue
        if float(bnd[0]) > 0:
            sep.add(atom.cohort_pair)
    for g, h in adjacent_pairs(order):
        if (g, h) not in sep:
            return False
    return True


def make_ifocus_strategy(cohort_records: Mapping[str, set]):
    """Allocation restricted to the pairs that decide the ordering.

    ``cohort_records`` maps a cohort id to its record ids, which is what lets the
    strategy turn "resolve group A vs group B" into "read cells that actually
    contain A or B records".
    """
    # Which cohorts a record belongs to (a record can sit in several cohorts
    # when the groups overlap -- the shared-source case this project is about).
    def _cells_for(cells, cohorts):
        wanted: set = set()
        for c in cohorts:
            wanted |= set(cohort_records.get(c, ()))
        return wanted

    def strategy(cells, cell_cs, c_j_by_row, family, explore: bool = False,
                 explore_rng=None):
        not_done = [c for c in cells if cell_cs[c.cell_id].n < cell_cs[c.cell_id].N]
        if not not_done:
            return -1, 0
        if explore:
            # 17.3: seeded rng from the pipeline, not a module-level global
            import random

            c = (explore_rng or random.Random(0)).choice(not_done)
            return c.cell_id, min(16, cell_cs[c.cell_id].N - cell_cs[c.cell_id].n)

        bounds = pushforward_contrast_bounds(c_j_by_row, cells, cell_cs, family)
        candidates = sorted({g for a in family.atoms for g in a.cohort_pair})
        order = estimate_ranking(family, bounds, candidates)

        # The pairs the ordering actually depends on, most ambiguous first.
        best_pair, best_gap = None, None
        for g, h in adjacent_pairs(order):
            for atom in family.atoms:
                if atom.cohort_pair != (g, h):
                    continue
                bnd = bounds.get(atom.index)
                if bnd is None:
                    continue
                lo, hi = float(bnd[0]), float(bnd[1])
                gap = hi - lo  # widest ambiguous pair gets the next batch
                if lo > 0:
                    continue  # already separated, ordering does not need it
                if best_gap is None or gap > best_gap:
                    best_pair, best_gap = (g, h), gap

        if best_pair is None:
            # Every adjacent pair is separated: the ordering is settled, so fall
            # back to the certificate objective to finish the declared contract.
            return choose_by_certificate_gain_per_cost(cells, cell_cs, c_j_by_row, family)

        wanted = _cells_for(cells, best_pair)
        scored = [
            (len(set(c.records) & wanted), cell_cs[c.cell_id].N - cell_cs[c.cell_id].n, c)
            for c in not_done
        ]
        scored = [s for s in scored if s[0] > 0]
        if not scored:
            return choose_by_certificate_gain_per_cost(cells, cell_cs, c_j_by_row, family)
        scored.sort(key=lambda s: (-s[0], -s[1]))
        c = scored[0][2]
        remaining = cell_cs[c.cell_id].N - cell_cs[c.cell_id].n
        return c.cell_id, min(32, remaining)

    return strategy


def run_ifocus_cs(
    contract,
    snapshot,
    oracle,
    alpha: float = 0.05,
    budget_calls: int = 1024,
    seed: int = 0,
    texts: Mapping[str, str] | None = None,
    ledger=None,
    request_id: str | None = None,
    proxy=None,
    **render_kw,
):
    """Run a ranking request under ordering-targeted allocation.

    Contracts without a ranking decision are reported as ``unsupported``:
    ordering-CS is a ranking control by construction (proposal 16), and
    pretending it also covers pairwise comparisons would just be a second copy
    of the certificate scheduler under a different name.
    """
    from engine.pipeline import answer, unsupported_certificate
    from query.contract_schema import normalize_decisions

    decisions = normalize_decisions(contract)
    if not any(d.get("type") in ("top1", "topk") for d in decisions):
        return unsupported_certificate(
            "ifocus/ordering-CS applies to ranking decisions only",
            contract=contract, alpha=alpha, seed=seed,
            budget_calls=budget_calls,
        )

    cohort_records = {
        c["id"]: set(snapshot.cohort_records(c)) for c in contract["cohorts"]
    }
    cert = answer(
        contract, snapshot, oracle, alpha=alpha, budget_calls=budget_calls,
        seed=seed, texts=texts, ledger=ledger, request_id=request_id,
        scheduler_strategy=make_ifocus_strategy(cohort_records),
        proxy=proxy, **render_kw,
    )
    cert["method"] = "ifocus_ordering_cs"

    # Ordering diagnostics: same intervals, a different question.
    from engine.answer_checker import decide
    from query.compiler import compile_signed_decisions

    try:
        _, family = compile_signed_decisions(contract, snapshot)
        bounds = {}
        for item in cert.get("contrast_intervals", []):
            iv = item.get("interval")
            if iv is None:
                bounds[item["atom_index"]] = None
            else:
                bounds[item["atom_index"]] = (Fraction(iv[0]), Fraction(iv[1]))
        candidates = sorted({g for a in family.atoms for g in a.cohort_pair})
        known = {k: v for k, v in bounds.items() if v is not None}
        order = estimate_ranking(family, known, candidates) if known else candidates
        k = 1
        for d in decisions:
            if d.get("type") == "topk":
                k = int(d.get("k", 1))
        cert["ordering"] = {
            "estimated_order": list(order),
            "top_k": list(order[:k]),
            "ordering_resolved": bool(known) and ordering_resolved(family, known, order),
            "certified": cert.get("status") == "certified",
            "note": (
                "ordering settled by adjacent-pair separation plus transitivity; "
                "the certificate status is decided separately by the declared family"
            ),
        }
    except Exception:  # diagnostics must never break the run
        cert["ordering"] = {"estimated_order": [], "ordering_resolved": False}

    return cert
