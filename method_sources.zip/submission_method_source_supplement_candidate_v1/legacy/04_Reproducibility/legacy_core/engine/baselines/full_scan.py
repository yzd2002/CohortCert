"""FullScan + exact query baseline (proposal 16).

Not a competitor to be beaten -- it is the reference. FullScan reads every
record in the request's effective support I_q and evaluates the same semantic
operator exhaustively, so its numerical error against the reference operator is
zero by construction (17.2). What it costs is ``|I_q|`` semantic calls, which is
exactly the number the sampling methods are trying to avoid.

It is reported for every task, and the point of showing it is honest: for
heavily repeated queries, materialising everything may well be cheaper. The
paper should say when on-demand execution wins and when it does not, rather
than claiming it always does.

The baseline is run through the ordinary pipeline with the budget raised to
``|I_q|``, so it shares the parser, the certificate family, the renderer and the
verifier with every other method.
"""
from __future__ import annotations

from typing import Mapping

from query.compiler import compile_signed_decisions, effective_support

__all__ = ["support_size", "run_full_scan"]


def support_size(contract, snapshot, keep_cancellations: bool = False) -> int:
    """``|I_q|``: the exact cost of materialising this request (scheme 6.1).

    ``keep_cancellations=True`` is the §18 ablation: the support widens to the
    cohort union (zero-coefficient shared records included), which is the cost
    the exact cancellation of 6.2 is measured against.
    """
    A, _ = compile_signed_decisions(contract, snapshot,
                                    keep_cancellations=keep_cancellations)
    return len(effective_support(A, keep_cancellations))


def run_full_scan(
    contract,
    snapshot,
    oracle,
    alpha: float = 0.05,
    seed: int = 0,
    texts: Mapping[str, str] | None = None,
    ledger=None,
    request_id: str | None = None,
    max_support: int | None = None,
    **render_kw,
):
    """Answer the request by reading every record in its support.

    ``max_support`` refuses to materialise absurdly large supports rather than
    silently running for hours; the refusal is reported as ``unsupported`` with
    the cost it would have incurred, so the request still lands in the metric
    denominator.
    """
    from engine.pipeline import answer

    # The §18 ablation flag rides in render_kw (registry forwards it); the
    # gate and the reported cost must use the SAME support the run will pay.
    n = support_size(contract, snapshot,
                     keep_cancellations=render_kw.get("keep_cancellations", False))
    if max_support is not None and n > max_support:
        from engine.pipeline import _declared_decision_count, unsupported_certificate

        # Refusing is not free: the materialisation cost is reported so the
        # budget-coverage curve still accounts for the request.
        return unsupported_certificate(
            f"support size {n} exceeds max_support={max_support}",
            contract=contract, alpha=alpha, seed=seed,
            semantic_calls=n, records_read=n, budget_calls=n,
            extra={"materialised_cost_if_run": n},
        )

    return answer(
        contract, snapshot, oracle, alpha=alpha, budget_calls=max(n, 1), seed=seed,
        texts=texts, ledger=ledger, request_id=request_id, allow_full_scan=True,
        # The tiny-request gate (7.1) exists so sampling methods cannot dodge
        # their own machinery on small supports. FullScan is the exhaustive
        # reference (16): reading every record of I_q IS its definition, at
        # every support size. Without lifting the gate, a support above
        # TINY_FULL_SCAN_MAX silently fell back to the sampled pipeline and
        # certified early -- neither exact nor costing |I_q|.
        tiny_full_scan_max=None,
        **render_kw,
    )
