"""Evergreen-style baseline (arXiv:2604.26180, Lee et al., 2026).

Evergreen verifies claims derived from semantic aggregates with two
verification-aware optimizations that map onto a comparative request:
relevance sorting, and estimation with an anytime-valid confidence sequence
plus early stopping. This baseline re-expresses exactly those two under the
shared contract (proposal 16.3), so the comparison isolates *scheduling*.

Mapping
-------
1. "Estimation with anytime-valid CS + early stopping": the shared CellCS
   kernel (the same Waudby-Smith--Ramdas finite-population sequence every
   method uses) and the shared decide() rule. Not re-implemented -- shared.
2. "Relevance sorting": Evergreen reads the most relevant records first.
   In our contract a scope is a cohort and a cohort is one coefficient cell,
   so the faithful, validity-preserving translation is *cross-scope*
   relevance-first allocation: the next batch goes to the cohort holding the
   highest proxy-scored unread record. Within a cohort the read order stays a
   uniform random permutation -- that premise is what the finite-population
   martingale needs, and dropping it would test a premise violation, not
   Evergreen's scheduling idea.

What is deliberately NOT copied, and why
----------------------------------------
* Within-scope relevance ordering (see above: breaks the without-replacement
  martingale; Evergreen's own guarantees are verdict F1, not distribution-free
  coverage, so the faithful mapping keeps the kernel and sorts at scope level).
* Operator fusion / similarity filtering / prompt caching: engine-level
  optimizations orthogonal to scheduling; cross-request caching is disabled
  for honest cost accounting everywhere (frozen_main.yaml).

The proxy is the shared one (fit on the same pilot everyone pays for), so the
only thing that differs from ``cohortcert`` is the allocation rule:
relevance-first greedy instead of certificate-gain scheduling.
"""
from __future__ import annotations

from typing import Callable, Mapping

__all__ = ["make_relevance_first_strategy", "run_evergreen_cs"]

_BATCH = 16  # same batch as uniform_cs, so batch shape never confounds


def make_relevance_first_strategy(proxy, batch: int = _BATCH) -> Callable:
    """Return a SchedulerStrategy: most relevant unfinished scope first.

    A cell's relevance is the maximum proxy score among its records -- the
    scope containing the single most relevant unread record is read next.
    Ties break by cell id for determinism. Cells are exhausted in allocation
    order (the kernel draws uniformly within a cell either way); the strategy
    never sees or changes the within-cell permutation.
    """

    def _max_score(cell) -> float:
        try:
            return max(float(proxy.score(i)) for i in cell.records)
        except Exception:
            # No proxy or a broken one: neutral constant, allocation degrades
            # to cell-id order. Validity is untouched (the kernel gates all).
            return 0.0

    def strategy(cells, cell_cs, c_j, family):
        not_done = [c for c in cells if cell_cs[c.cell_id].n < cell_cs[c.cell_id].N]
        if not not_done:
            return -1, 0
        c = min(not_done, key=lambda c: (-_max_score(c), str(c.cell_id)))
        remaining = cell_cs[c.cell_id].N - cell_cs[c.cell_id].n
        return c.cell_id, min(batch, remaining)

    return strategy


def run_evergreen_cs(
    contract,
    snapshot,
    oracle,
    alpha: float = 0.05,
    budget_calls: int = 1024,
    seed: int = 0,
    texts: Mapping[str, str] | None = None,
    ledger=None,
    request_id: str | None = None,
    proxy=None,
    **render_kw,
):
    """Run the request under the Evergreen-style baseline.

    Same contract, snapshot, oracle, alpha, budget, pilot, proxy, renderer and
    verifier as every other method (16.3); only the scheduler strategy differs
    from ``cohortcert`` (and from ``shared_contrast_uniform``, which allocates
    proportionally instead of by relevance).
    """
    from engine.pipeline import answer

    return answer(
        contract, snapshot, oracle, alpha=alpha, budget_calls=budget_calls,
        seed=seed, texts=texts, ledger=ledger, request_id=request_id,
        scheduler_strategy=make_relevance_first_strategy(proxy),
        use_pilot=True, proxy=proxy, **render_kw,
    )
