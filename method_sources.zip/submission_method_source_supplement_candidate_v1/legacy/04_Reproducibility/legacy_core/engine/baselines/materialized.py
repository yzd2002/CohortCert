"""Full semantic materialisation + SQL baseline (proposal 14.3).

The deployment alternative the paper must be honest about: materialise the
labels of the whole population once (that is exactly what the Wave-2 label
build did), answer every request exactly with a lookup, and pay
``C_build / Q`` per request after amortisation. For heavily repeated queries
this wins; the paper must show when on-demand execution wins and when it does
not, not claim it always does (full_scan.py docstring, 14.3).

Accounting rules (14.1 / 14.3):

* the per-request marginal semantic cost is **0** -- the labels already exist;
* the build cost is NOT hidden: ``load_build_cost`` recovers the measured
  C_build of the canonical label-build ledger, and the analysis stage
  amortises it over the number of requests Q (``amortized_per_request``);
* the cert carries both numbers side by side (``live_equivalent_calls`` =
  what a live full scan would have charged, ``semantic_calls`` = 0) so no
  table can mistake the marginal cost for the whole cost;
* the vault reads still happen and land in the cost ledger as **evaluation
  accounting of pre-paid labels** -- they are never reported as deployment
  query cost.

Numerically this is FullScan: exact bounds, zero error against the reference
operator, not a simultaneously valid sampling certificate because there is
nothing left to be valid *about* -- it is exact.
"""
from __future__ import annotations

import json
from pathlib import Path

__all__ = ["load_build_cost", "load_full_build_cost", "amortized_per_request",
           "run_materialized_full_scan"]


def _ledger_root() -> Path:
    from pathlib import Path as _P

    return _P(__file__).resolve().parents[2] / "results" / "raw_logs"


def load_build_cost(dataset: str, predicate_id: str, raw_logs_root: Path | None = None) -> dict:
    """Recover the measured C_build of the canonical label-build run.

    Crash retries leave several ledgers per predicate; the canonical build is
    the one that actually completed the population, i.e. the one that read the
    most records. Sums are taken over its ``materialize`` events.
    """
    root = Path(raw_logs_root) if raw_logs_root is not None else _ledger_root()
    pattern = f"labelbuild__{dataset}__{predicate_id}__*"
    best: dict | None = None
    for ledger_dir in sorted(root.glob(pattern)):
        build = ledger_dir / "build.jsonl"
        if not build.exists():
            continue
        totals = {"semantic_calls": 0, "input_tokens": 0, "output_tokens": 0,
                  "gpu_active_ms": 0.0, "records": 0}
        for line in build.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            ev = json.loads(line)
            if ev.get("phase") != "materialize":
                continue
            totals["semantic_calls"] += int(ev.get("semantic_calls") or 0)
            totals["input_tokens"] += int(ev.get("input_tokens") or 0)
            totals["output_tokens"] += int(ev.get("output_tokens") or 0)
            totals["gpu_active_ms"] += float(ev.get("gpu_active_ms") or 0.0)
            totals["records"] += int(ev.get("records_read") or 0)
        if best is None or totals["records"] > best["build_cost"]["records"]:
            best = {"run_id": ledger_dir.name, "build_cost": totals}
    if best is None:
        raise FileNotFoundError(
            f"no label-build ledger for {dataset}__{predicate_id} under {root}; "
            f"the materialised baseline refuses to invent a build cost"
        )
    return best


# ---------------------------------------------------------------------------
# Full build cost across crash-retry ledgers.
#
# Why load_build_cost alone is not the true build cost: a resumed build skips
# records already labelled by an earlier crashed attempt, so its
# ``records_read`` (and cost) covers only the remaining slice. Summing only
# the canonical ledger therefore UNDERCOUNTS C_build (this produced the
# erroneous 227,944 total in an earlier draft; the audited total is below).
#
# The ledgers that constitute each Wave-2 8B build are pinned explicitly and
# asserted against the frozen population size, so any future ledger change
# that breaks the accounting fails loudly instead of silently redefining it.
# Excluded by construction: the 2026-10-03 1.7B smoke run, the 8B/9B
# consistency-audit reruns (2026-10-07/08), and every Qwen3.5-9B ledger.
# account_access pins both 10-04 ledgers although they overlap by ~400
# re-read records (1% of the population): the ledger records money actually
# spent, and the assertion above bounds such overlap at 2%.
# ---------------------------------------------------------------------------
_BUILD_LEDGERS: dict[tuple[str, str], dict] = {
    ("cfpb", "explicit_account_access_problem_v1"): {
        "population": 40000,
        "run_ids": [
            "labelbuild__cfpb__explicit_account_access_problem_v1__20261004T094607Z",
            "labelbuild__cfpb__explicit_account_access_problem_v1__20261004T100645Z",
        ],
    },
    ("cfpb", "explicit_repeated_contact_v1"): {
        "population": 40000,
        "run_ids": [
            "labelbuild__cfpb__explicit_repeated_contact_v1__20261004T102204Z",
            "labelbuild__cfpb__explicit_repeated_contact_v1__20261004T103914Z",
        ],
    },
    ("cfpb", "explicit_processing_delay_v1"): {
        "population": 40000,
        "run_ids": [
            "labelbuild__cfpb__explicit_processing_delay_v1__20261004T102315Z",
            "labelbuild__cfpb__explicit_processing_delay_v1__20261004T105347Z",
        ],
    },
    ("cfpb", "explicit_unresolved_problem_v1"): {
        "population": 40000,
        "run_ids": [
            "labelbuild__cfpb__explicit_unresolved_problem_v1__20261004T102636Z",
            "labelbuild__cfpb__explicit_unresolved_problem_v1__20261004T110625Z",
        ],
    },
    ("opinrank", "explicit_cleanliness_complaint_v1"): {
        "population": 18569,
        "run_ids": [
            "labelbuild__opinrank__explicit_cleanliness_complaint_v1__20261004T103044Z",
        ],
    },
    ("opinrank", "explicit_noise_complaint_v1"): {
        "population": 18569,
        "run_ids": [
            "labelbuild__opinrank__explicit_noise_complaint_v1__20261004T103644Z",
            "labelbuild__opinrank__explicit_noise_complaint_v1__20261004T111814Z",
        ],
    },
    ("opinrank", "explicit_staff_response_complaint_v1"): {
        "population": 18569,
        "run_ids": [
            "labelbuild__opinrank__explicit_staff_response_complaint_v1__20261004T112253Z",
        ],
    },
    ("opinrank", "explicit_facility_fault_complaint_v1"): {
        "population": 18569,
        "run_ids": [
            "labelbuild__opinrank__explicit_facility_fault_complaint_v1__20261004T112906Z",
        ],
    },
}


def load_full_build_cost(dataset: str, predicate_id: str, raw_logs_root: Path | None = None) -> dict:
    """Measured C_build summed over ALL ledgers of the Wave-2 8B build.

    Unlike :func:`load_build_cost` (canonical ledger only), this adds the
    earlier crash-retry slices so that records sum to the frozen population.
    The per-predicate ledger list is pinned in ``_BUILD_LEDGERS`` and the
    record total is asserted against the population size.
    """
    root = Path(raw_logs_root) if raw_logs_root is not None else _ledger_root()
    spec = _BUILD_LEDGERS.get((dataset, predicate_id))
    if spec is None:
        raise FileNotFoundError(
            f"no pinned build-ledger list for {dataset}__{predicate_id}; "
            f"refuses to invent one"
        )
    totals = {"semantic_calls": 0, "input_tokens": 0, "output_tokens": 0,
              "gpu_active_ms": 0.0, "records": 0}
    seen: list[str] = []
    for run_id in spec["run_ids"]:
        build = root / run_id / "build.jsonl"
        if not build.exists():
            raise FileNotFoundError(f"pinned build ledger missing: {build}")
        for line in build.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            ev = json.loads(line)
            if ev.get("phase") != "materialize":
                continue
            totals["semantic_calls"] += int(ev.get("semantic_calls") or 0)
            totals["input_tokens"] += int(ev.get("input_tokens") or 0)
            totals["output_tokens"] += int(ev.get("output_tokens") or 0)
            totals["gpu_active_ms"] += float(ev.get("gpu_active_ms") or 0.0)
            totals["records"] += int(ev.get("records_read") or 0)
        seen.append(run_id)
    if not (spec["population"] <= totals["records"] <= int(spec["population"] * 1.02)):
        raise ValueError(
            f"build ledgers for {dataset}__{predicate_id} cover "
            f"{totals['records']} records, population is {spec['population']}; "
            f"the pinned list is stale -- re-derive it before trusting C_build"
        )
    return {"run_ids": seen, "build_cost": totals}


def amortized_per_request(build_cost: dict, q_requests: int) -> dict:
    """14.3: C_bar(Q) = (C_build + sum C_q) / Q with marginal per-request C_q ~ 0."""
    if q_requests <= 0:
        raise ValueError("Q must be positive")
    return {
        "q_requests": q_requests,
        "semantic_calls_per_request": build_cost["semantic_calls"] / q_requests,
        "gpu_active_ms_per_request": build_cost["gpu_active_ms"] / q_requests,
        "input_tokens_per_request": build_cost["input_tokens"] / q_requests,
        "output_tokens_per_request": build_cost["output_tokens"] / q_requests,
    }


def run_materialized_full_scan(
    contract,
    snapshot,
    oracle,
    alpha: float = 0.05,
    seed: int = 0,
    texts=None,
    ledger=None,
    request_id: str | None = None,
    build_cost: dict | None = None,
    **render_kw,
):
    """Answer exactly from the pre-materialised labels (marginal cost 0)."""
    from engine.baselines.full_scan import run_full_scan, support_size

    cert = run_full_scan(
        contract, snapshot, oracle, alpha=alpha, seed=seed,
        texts=texts, ledger=ledger, request_id=request_id, **render_kw,
    )
    n = support_size(contract, snapshot)
    charged = dict(cert.get("charged_cost") or {})
    live = charged.get("semantic_calls", n)
    cert["charged_cost"] = {
        **charged,
        "semantic_calls": 0,
        "records_read": 0,
        "live_equivalent_calls": live,
        "accounting": "materialized_marginal (14.3): C_build amortised over Q at analysis time",
    }
    cert["method"] = "materialized_full_scan"
    cert["materialization"] = {
        "build_cost_total": build_cost or {},
        "note": "per-request amortised share = C_build/Q (analysis stage)",
    }
    return cert
