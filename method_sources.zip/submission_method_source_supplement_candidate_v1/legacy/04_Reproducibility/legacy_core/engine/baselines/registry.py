"""One entry point for every method compared in the experiments (proposal 16.3).

Fairness is structural here, not a promise: every method is called with the same
contract, the same frozen snapshot, the same read-only oracle, the same alpha,
the same budget and the same renderer + verifier. The only things that differ
are the two plug-in points the pipeline exposes -- how records are stratified
and how the next batch is allocated -- plus whether a pilot is run.

FullScan ignores the budget by design: it reads the whole support and reports
that cost, which is the quantity the budgeted methods are measured against.

Two separate tables
-------------------
``METHODS`` holds the methods whose **reported coverage is a risk-controlled
claim** and which may therefore be pooled into the CCR / FCR comparison.

``DIAGNOSTIC_METHODS`` holds methods that are reported *alongside* but whose
numbers must not be pooled, because they do not carry the same guarantee:

* ``olla_cs:original`` -- re-partitions without stage budgets, i.e. the exact
  thing proposal 16.1 warns against. It exists so the cost of the risk-aligned
  adaptation is measured rather than asserted.
* ``hybrid_topk_rag`` -- retrieval-ranked estimation with zero-width intervals.
  It has no coverage guarantee at all; its false-certification rate *is* the
  finding.

Both are tagged in their output (``validity``, ``diagnostic``) so a table built
from the raw logs cannot quietly mix them in.
"""
from __future__ import annotations

from typing import Callable, Mapping

__all__ = [
    "METHODS",
    "DIAGNOSTIC_METHODS",
    "METHOD_NOTES",
    "PENDING",
    "run_method",
    "available_methods",
    "diagnostic_methods",
    "all_methods",
    "is_validity_controlled",
]


def _cohortcert(contract, snapshot, oracle, alpha, budget_calls, seed, proxy, **kw):
    from engine.pipeline import answer

    return answer(
        contract, snapshot, oracle, alpha=alpha, budget_calls=budget_calls,
        seed=seed, proxy=proxy, **kw
    )


def _tiny_full_scan(contract, snapshot, oracle, alpha, budget_calls, seed, proxy, **kw):
    """7.1 tiny-request exact path, shared by every method (16.3 fairness).

    The pipeline's exact shortcut fires only for tiny supports; methods with
    their own read loops (OLLA, BARGAIN, hybrid top-k) must go through the
    same gate, or high-budget comparisons would systematically reward the
    methods that route through ``pipeline.answer`` and starve the rest.
    Returns ``None`` when the request is not tiny; the caller then runs its
    own loop.
    """
    from query.compiler import compile_signed_decisions, effective_support
    from engine.pipeline import TINY_FULL_SCAN_MAX, answer

    # §18 ablation: the gate must see the same support the run will pay for.
    # Compiling without the flag here would admit a keepcanc run whose real
    # cost (cohort union) exceeds the budget the cancelled support passed.
    keep_canc = bool(kw.get("keep_cancellations", False))
    try:
        A, _ = compile_signed_decisions(contract, snapshot,
                                        keep_cancellations=keep_canc)
    except Exception:
        return None  # unsupported contracts fall through to the method itself
    support = len(effective_support(A, keep_canc))
    if support > TINY_FULL_SCAN_MAX or support > budget_calls:
        return None
    return answer(
        contract, snapshot, oracle, alpha=alpha, budget_calls=budget_calls,
        seed=seed, proxy=proxy, **kw
    )


def _shared_contrast_uniform(contract, snapshot, oracle, alpha, budget_calls, seed, proxy, **kw):
    from engine.baselines.shared_contrast import run_shared_contrast

    # 16.3: the proxy is part of the shared machinery, not part of what this
    # baseline is testing. Dropping it here degrades its stratification and
    # working prior to the deterministic stub while the method under test keeps
    # the real one -- every measured gap would then be partly a proxy artefact.
    return run_shared_contrast(
        contract, snapshot, oracle, alpha=alpha, budget_calls=budget_calls,
        seed=seed, mode="uniform", proxy=proxy, **kw
    )


def _shared_contrast_neyman(contract, snapshot, oracle, alpha, budget_calls, seed, proxy, **kw):
    from engine.baselines.shared_contrast import run_shared_contrast

    return run_shared_contrast(
        contract, snapshot, oracle, alpha=alpha, budget_calls=budget_calls,
        seed=seed, mode="neyman", proxy=proxy, **kw
    )


def _uniform_cs(contract, snapshot, oracle, alpha, budget_calls, seed, proxy, **kw):
    from engine.baselines.uniform_cs import run_uniform_cs

    return run_uniform_cs(
        contract, snapshot, oracle, alpha=alpha, budget_calls=budget_calls,
        seed=seed, proxy=proxy, **kw
    )


def _proxy_stratified(contract, snapshot, oracle, alpha, budget_calls, seed, proxy, **kw):
    from engine.baselines.proxy_stratified_cs import run_proxy_stratified_cs

    if proxy is None:
        from engine.proxy import StubProxy

        proxy = StubProxy(seed=seed)
    return run_proxy_stratified_cs(
        contract, snapshot, oracle, proxy, alpha=alpha, budget_calls=budget_calls,
        seed=seed, **kw
    )


def _full_scan(contract, snapshot, oracle, alpha, budget_calls, seed, proxy, **kw):
    from engine.baselines.full_scan import run_full_scan

    return run_full_scan(
        contract, snapshot, oracle, alpha=alpha, seed=seed, **kw
    )


def _materialized(contract, snapshot, oracle, alpha, budget_calls, seed, proxy, **kw):
    from engine.baselines.materialized import run_materialized_full_scan

    return run_materialized_full_scan(
        contract, snapshot, oracle, alpha=alpha, seed=seed, **kw
    )


def _olla_cs(contract, snapshot, oracle, alpha, budget_calls, seed, proxy, **kw):
    from engine.baselines.olla_cs import run_olla_cs

    pre = _tiny_full_scan(contract, snapshot, oracle, alpha, budget_calls, seed, proxy, **kw)
    if pre is not None:
        return pre
    return run_olla_cs(
        contract, snapshot, oracle, proxy=proxy, alpha=alpha,
        budget_calls=budget_calls, seed=seed, mode="risk_aligned", **kw
    )


def _bargain(contract, snapshot, oracle, alpha, budget_calls, seed, proxy, **kw):
    from engine.baselines.bargain import run_bargain

    pre = _tiny_full_scan(contract, snapshot, oracle, alpha, budget_calls, seed, proxy, **kw)
    if pre is not None:
        return pre
    return run_bargain(
        contract, snapshot, oracle, proxy=proxy, alpha=alpha,
        budget_calls=budget_calls, seed=seed, **kw
    )


def _ifocus(contract, snapshot, oracle, alpha, budget_calls, seed, proxy, **kw):
    from engine.baselines.ifocus import run_ifocus_cs

    return run_ifocus_cs(
        contract, snapshot, oracle, alpha=alpha, budget_calls=budget_calls,
        seed=seed, proxy=proxy, **kw
    )


def _evergreen_cs(contract, snapshot, oracle, alpha, budget_calls, seed, proxy, **kw):
    from engine.baselines.evergreen_cs import run_evergreen_cs

    # Same exact short-circuit as the other read-loop methods: without it, a
    # small request would cost |I_q| here and something else elsewhere (16.1).
    pre = _tiny_full_scan(contract, snapshot, oracle, alpha, budget_calls, seed, proxy, **kw)
    if pre is not None:
        return pre
    return run_evergreen_cs(
        contract, snapshot, oracle, alpha=alpha, budget_calls=budget_calls,
        seed=seed, proxy=proxy, **kw
    )


def _olla_original(contract, snapshot, oracle, alpha, budget_calls, seed, proxy, **kw):
    from engine.baselines.olla_cs import run_olla_cs

    # Same exact short-circuit as its risk-aligned twin. Without it, a small
    # request costs |I_q| under one OLLA variant and something else under the
    # other, and their reported gap would be a bookkeeping accident rather than
    # the cost of skipping stage budgets (16.1).
    pre = _tiny_full_scan(contract, snapshot, oracle, alpha, budget_calls, seed, proxy, **kw)
    if pre is not None:
        return pre
    return run_olla_cs(
        contract, snapshot, oracle, proxy=proxy, alpha=alpha,
        budget_calls=budget_calls, seed=seed, mode="original", **kw
    )


def _hybrid_topk(contract, snapshot, oracle, alpha, budget_calls, seed, proxy, **kw):
    from engine.baselines.hybrid_topk import run_hybrid_topk

    pre = _tiny_full_scan(contract, snapshot, oracle, alpha, budget_calls, seed, proxy, **kw)
    if pre is not None:
        return pre
    return run_hybrid_topk(
        contract, snapshot, oracle, alpha=alpha, budget_calls=budget_calls,
        seed=seed, **kw
    )


def _fixed_ci_diag(contract, snapshot, oracle, alpha, budget_calls, seed, proxy, **kw):
    from engine.baselines.fixed_ci_diag import run_fixed_ci_diag

    pre = _tiny_full_scan(contract, snapshot, oracle, alpha, budget_calls, seed, proxy, **kw)
    if pre is not None:
        return pre
    return run_fixed_ci_diag(
        contract, snapshot, oracle, alpha=alpha, budget_calls=budget_calls,
        seed=seed, proxy=proxy, **kw
    )


METHODS: dict[str, Callable] = {
    "cohortcert": _cohortcert,
    "shared_contrast_uniform": _shared_contrast_uniform,
    "shared_contrast_neyman": _shared_contrast_neyman,
    "uniform_cs": _uniform_cs,
    "proxy_stratified_cs": _proxy_stratified,
    "olla_cs": _olla_cs,
    "bargain": _bargain,
    "ifocus_ordering_cs": _ifocus,
    "evergreen_cs": _evergreen_cs,
    "full_scan": _full_scan,
    "materialized_full_scan": _materialized,
}

DIAGNOSTIC_METHODS: dict[str, Callable] = {
    "olla_cs_original": _olla_original,
    "hybrid_topk_rag": _hybrid_topk,
    "fixed_ci_diag": _fixed_ci_diag,
}

METHOD_NOTES: Mapping[str, str] = {
    "cohortcert": "this method: coefficient cells + certificate-driven allocation",
    "shared_contrast_uniform": "same machinery, balanced allocation (decisive control)",
    "shared_contrast_neyman": "same machinery, cost-aware Neyman allocation",
    "uniform_cs": "no pilot, proportional allocation, correct risk control",
    "proxy_stratified_cs": "ABae/UQE style proxy stratification + Neyman, same kernel",
    "olla_cs": "OLLA adaptive re-stratification, risk-aligned stage budgets (16.1)",
    "bargain": "row-level error budget rho_j(r) propagated to the contrast (16.2)",
    "ifocus_ordering_cs": "ordering-targeted allocation for ranking (16)",
    "evergreen_cs": (
        "Evergreen-style (arXiv:2604.26180) relevance-first scope allocation "
        "+ the shared anytime-valid CS kernel; within-scope order stays uniform"
    ),
    "full_scan": "exhaustive reference: zero numerical error, cost = |I_q|",
    "materialized_full_scan": (
        "14.3 materialisation+SQL control: exact answers, marginal query cost 0, "
        "measured C_build amortised over Q at analysis time (never hidden)"
    ),
    "olla_cs_original": "DIAGNOSTIC: adaptive re-partition without stage budgets; nominal only",
    "hybrid_topk_rag": "DIAGNOSTIC: retrieval-ranked rate, zero-width intervals, no guarantee",
    "fixed_ci_diag": (
        "DIAGNOSTIC (proposal 18): per-round fixed-time 95% interval instead of "
        "the confidence sequence; demonstrates the sequential-reuse failure mode"
    ),
}

#: Baselines required by proposal 16 that are not implemented yet.
#: Empty as of 2026-10-03: all eight rows of the proposal 16 table are covered
#: (four of them inside ``olla_cs``/``bargain``/``ifocus``/``hybrid_topk``).
PENDING: tuple = ()


def available_methods() -> list:
    return sorted(METHODS)


def diagnostic_methods() -> list:
    return sorted(DIAGNOSTIC_METHODS)


def all_methods() -> list:
    return sorted(set(METHODS) | set(DIAGNOSTIC_METHODS))


def is_validity_controlled(name: str) -> bool:
    """False for methods whose output must not enter a coverage claim."""
    return name in METHODS


def run_method(
    name: str,
    contract,
    snapshot,
    oracle,
    alpha: float = 0.05,
    budget_calls: int = 1024,
    seed: int = 0,
    proxy=None,
    **kw,
) -> dict:
    """Run one method by name; diagnostics and valid methods share the signature."""
    table = METHODS if name in METHODS else DIAGNOSTIC_METHODS
    if name not in table:
        raise KeyError(
            f"unknown method {name!r}; have {all_methods()}"
        )
    return table[name](
        contract, snapshot, oracle, alpha, budget_calls, seed, proxy, **kw
    )
