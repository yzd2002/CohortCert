"""SharedContrast-CS baseline (scheme 16 / 98).

The decisive comparison for H2: keep the *entire* CohortCert machinery --
signed representation, pilot, stratification, working prior, finite-population
confidence sequences, the oracle vault and the certificate-family stop
condition -- and change ONLY the allocation target. Instead of steering sampling
by certificate gain, allocate uniformly (balanced) or by a cost-aware Neyman
rule. Any remaining advantage of CohortCert must then come from the
certificate-driven scheduling, not from sharing samples or algebra.

The baseline is dropped into the same ``pipeline.answer`` loop via the
``scheduler_strategy`` argument, so it never re-implements the sampling core.
"""
from __future__ import annotations

from typing import Callable


_DEFAULT_BATCH = 16


def uniform_strategy(cells, cell_cs, c_j, family) -> tuple[int, int]:
    """Balanced uniform allocation: advance the least-sampled not-done cell."""
    not_done = [c for c in cells if cell_cs[c.cell_id].n < cell_cs[c.cell_id].N]
    if not not_done:
        return -1, 0
    c = min(not_done, key=lambda c: cell_cs[c.cell_id].n)
    remaining = cell_cs[c.cell_id].N - cell_cs[c.cell_id].n
    batch = min(_DEFAULT_BATCH, remaining)
    return c.cell_id, batch


def neyman_strategy(proxy) -> Callable:
    """Cost-aware Neyman allocation using the frozen proxy prior as sigma.

    Weight_h = sqrt(N_h * p_h(1-p_h)) / cost_h, cost_h = 1 (stub). Picks the
    highest-weight not-done cell. This is the baseline's best honest shot at
    out-performing certificate scheduling without using the certificate itself.
    """
    def strat(cells, cell_cs, c_j, family) -> tuple[int, int]:
        not_done = [c for c in cells if cell_cs[c.cell_id].n < cell_cs[c.cell_id].N]
        if not not_done:
            return -1, 0
        best = None
        for c in not_done:
            remaining = cell_cs[c.cell_id].N - cell_cs[c.cell_id].n
            if remaining <= 0:
                continue
            p = sum(proxy.score(i) for i in c.records) / max(len(c.records), 1)
            w = (c.N * p * (1.0 - p)) ** 0.5
            if best is None or w > best[0]:
                best = (w, c)
        if best is None:
            return -1, 0
        c = best[1]
        remaining = cell_cs[c.cell_id].N - cell_cs[c.cell_id].n
        return c.cell_id, min(_DEFAULT_BATCH, remaining)

    return strat


def run_shared_contrast(
    contract, snapshot, oracle, alpha=0.05, budget_calls=1024, seed=0,
    mode: str = "uniform", proxy=None, **render_kw,
):
    """Run the request under SharedContrast-CS (uniform or neyman)."""
    from engine.pipeline import answer

    if mode == "neyman":
        if proxy is None:
            raise ValueError("neyman mode requires a proxy")
        strategy = neyman_strategy(proxy)
    else:
        strategy = uniform_strategy
    # proxy must flow into answer() as well: the pipeline fits it on the pilot
    # labels (in place) before any strategy call, which is what makes an
    # EmbeddingLRProxy usable here. The strategy closure and answer() share
    # the same instance, so the fit is visible to both.
    return answer(
        contract, snapshot, oracle, alpha=alpha, budget_calls=budget_calls,
        seed=seed, scheduler_strategy=strategy, proxy=proxy, **render_kw,
    )
