"""Hybrid Top-k RAG baseline (proposal 16): a diagnostic, not a competitor.

Proposal 16 lists this one with a different job from the others:

    Hybrid Top-k RAG | 全部任务的诊断比较 | 相同模型、上下文与 token 预算；
    展示相关性检索与总体比较的差别

The point is not to lose to it or beat it -- it is to make the *category error*
measurable. A retrieval system answers "here are the most relevant texts"; an
analytical comparison asks "what share of the group satisfies this predicate".
Feeding the first into the second produces an estimate of the wrong quantity:
relevance-ranked retrieval over-samples the records that look like the
predicate, so its positive rate is biased upward and its confidence is
unearned.

This baseline does exactly what a strong RAG pipeline would do, honestly:

* rank the request's active support by a relevance score (the same proxy every
  other method uses, so the ranking quality is not being unfairly handicapped);
* spend the whole budget on the top-k;
* report the retrieved-sample rate as if it were the population rate, with
  **zero-width intervals** -- which is what a system that says "based on these
  documents" is implicitly asserting.

It therefore emits ``status="certified"`` and a validity tag of
``"none_diagnostic"``. That is deliberate. The false-certification rate measured
against the sealed vault *is* the result: it quantifies how often the retrieval
story would have produced a confident wrong answer.
"""
from __future__ import annotations

from fractions import Fraction
from typing import Mapping

__all__ = ["relevance_rank", "run_hybrid_topk"]


def relevance_rank(active_ids, proxy, budget: int) -> list:
    """Top-k record ids by relevance score, ties broken by id for determinism."""
    scored = sorted(active_ids, key=lambda i: (-float(proxy.score(i)), str(i)))
    return scored[: max(0, int(budget))]


def run_hybrid_topk(
    contract,
    snapshot,
    oracle,
    proxy=None,
    alpha: float = 0.05,
    budget_calls: int = 1024,
    seed: int = 0,
    texts: Mapping[str, str] | None = None,
    ledger=None,
    request_id: str | None = None,
    **render_kw,
):
    """Answer by retrieval: rank, read the top-k, report the retrieved rate."""
    from engine.pipeline import (
        BudgetedOracle,
        OracleFailure,
        RetryPolicy,
        deterministic_bounds_already_decide,
        render_verified,
        unsupported_certificate,
        verify_certificate,
    )
    from engine.evidence import illustrative_quotes
    from engine.answer_checker import decide
    from query.compiler import compile_signed_decisions, effective_support
    from query.contract_schema import ContractUnsupported

    reader = BudgetedOracle(
        oracle, budget_calls=budget_calls, ledger=ledger,
        request_id=request_id, retry=RetryPolicy(),
    )
    observed_labels: dict = {}
    sampled_record_ids: list = []

    try:
        A, family = compile_signed_decisions(
            contract, snapshot,
            keep_cancellations=bool(render_kw.get("keep_cancellations", False)))
    except ContractUnsupported as e:
        return unsupported_certificate(
            e.reason, contract=contract, alpha=alpha, seed=seed,
            semantic_calls=reader.spent, budget_calls=budget_calls,
        )

    active_ids = sorted(effective_support(
        A, bool(render_kw.get("keep_cancellations", False))))
    if not active_ids:
        return unsupported_certificate(
            "no active support: contrast is identically zero",
            contract=contract, alpha=alpha, seed=seed, budget_calls=budget_calls,
        )

    # The algebra alone may already decide it -- even retrieval gets that right.
    structural = deterministic_bounds_already_decide(A, family)
    if structural is not None:
        bounds, satisfied = structural
    else:
        # 7.1 / G5: this diagnostic has no pilot to fit a real proxy with, so
        # an unfitted model proxy (EmbeddingLRProxy before any labels) cannot
        # score. Fall back to the deterministic stub instead of crashing --
        # honest for a method that carries no coverage guarantee anyway.
        if proxy is None or not getattr(proxy, "is_fitted", True):
            from engine.proxy import StubProxy

            proxy = StubProxy(seed=seed)

        picked = relevance_rank(active_ids, proxy, budget_calls)
        try:
            labels = reader.read(picked, phase="oracle", caller="hybrid_topk")
        except OracleFailure as exc:
            picked = []  # fall through with no evidence
            labels = {}
            reason = str(exc)
        else:
            reason = ""
        observed_labels.update(labels)
        sampled_record_ids.extend(picked)

        if not picked:
            return unsupported_certificate(
                reason or "retrieval returned nothing",
                contract=contract, alpha=alpha, seed=seed,
                semantic_calls=reader.spent, budget_calls=budget_calls,
            )

        # Cohort rates estimated from the records retrieval happened to
        # surface -- computed PER ATOM. A single global record->cohort map is
        # wrong for overlapping cohorts: with cohorts A/B and A/C, the same
        # record legitimately sits on different sides in different contrasts,
        # and the last atom processed would silently reassign it everywhere.
        picked_set = set(picked)
        rates: dict[int, dict] = {}
        for atom in family.atoms:
            g, h = atom.cohort_pair
            side = {}
            for name, sign in ((g, 1), (h, -1)):
                tot = pos = 0
                for i, c in A.rows[atom.row_index].items():
                    if c == 0 or i not in picked_set:
                        continue
                    if (c > 0) == (sign > 0):
                        tot += 1
                        pos += int(labels.get(i, 0))
                side[name] = Fraction(pos, tot) if tot else Fraction(0)
            rates[atom.index] = side

        bounds = {}
        for atom in family.atoms:
            g, h = atom.cohort_pair
            side = rates[atom.index]
            theta = Fraction(0)
            for i, c in A.rows[atom.row_index].items():
                if c == 0:
                    continue
                theta += c * side[g if c > 0 else h]
            # Zero width: this is the assertion a retrieval answer makes.
            bounds[atom.index] = (theta, theta)
        satisfied = decide(family, bounds)

    charged = (
        ledger.request_cost(request_id)
        if ledger is not None and request_id
        else {
            "semantic_calls": reader.spent,
            "records_read": len(observed_labels),
            "budget_calls": budget_calls,
            "source": "local_counter; no ledger attached",
        }
    )
    cert = render_verified(
        contract, family, bounds, satisfied, alpha, seed,
        render_kw.get("snapshot_hash", ""), render_kw.get("query_contract_hash", ""),
        render_kw.get("partition_hash", ""), render_kw.get("model_and_prompt_hash", ""),
        sampled_record_ids=sampled_record_ids,
        semantic_sensitivity=[],
        charged_cost=charged,
        illustrative_quotes=illustrative_quotes(
            sampled_record_ids, observed_labels, texts,
            max_quotes=render_kw.get("max_quotes", 3),
        ),
        bundle_complete=family.bundle_complete(satisfied),
        decision_status=family.per_decision_status(satisfied),
    )
    cert["method"] = "hybrid_topk_rag"
    cert["validity"] = "none_diagnostic"
    cert["diagnostic"] = True
    cert["retrieval"] = {
        "retrieved": len(sampled_record_ids),
        "active_support": len(active_ids),
        "coverage": (
            len(sampled_record_ids) / len(active_ids) if active_ids else 0.0
        ),
        "note": (
            "relevance-ranked retrieval estimates the retrieved-sample rate, not "
            "the population rate; intervals are zero-width by construction and "
            "carry no coverage guarantee"
        ),
    }
    errs = verify_certificate(cert, family=family, contract=contract)
    if errs:
        cert["status"] = "execution_error"
        cert["verify_errors"] = errs
    return cert
