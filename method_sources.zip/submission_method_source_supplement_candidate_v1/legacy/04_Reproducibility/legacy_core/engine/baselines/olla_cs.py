"""OLLA and risk-aligned OLLA-CS baseline (proposal 16 / 16.1).

OLLA [R9] is *LLM-driven online aggregation*: semantic stratification plus
**adaptive** allocation and **adaptive re-stratification** -- the strata are
re-cut as labels come back, unlike a frozen proxy partition. That adaptivity is
exactly what makes it a strong competitor, and exactly what makes it dangerous
to combine with a confidence sequence.

Proposal 16.1 states the trap plainly:

    不能把旧置信序列直接用于重新划分后的单元。

A confidence sequence is a statement about one fixed finite population sampled
in a fixed way. Once the partition changes, the old sequence is a statement
about a population that no longer exists. Carrying it over produces numbers
that look like a certificate and are not one.

The safe adaptation implemented here
------------------------------------
At every re-partition ``s``:

1. every label read so far is converted into an **exact** contribution ``c_j``
   (it is known, not estimated -- no distributional assumption left);
2. fresh cells are built on the records that are **still unread**;
3. the new cells get a **pre-declared stage budget** ``alpha_s = alpha * 2**-(s+1)``.

Since ``sum_s alpha * 2**-(s+1) = alpha``, the union bound over stages keeps the
request-level guarantee. The price is real: stage 0 only receives ``alpha/2``
even when no re-partition ever happens. Proposal 16.1 calls this out -- "这会
产生额外保守性" -- and requires reporting both variants instead of quietly
picking the flattering one.

Two modes, never mixed
----------------------
``mode="risk_aligned"``  (OLLA-CS)
    The adaptation above. Valid. Comparable against the other methods.
``mode="original"``      (OLLA as published)
    Re-partitions but carries the old evidence into the new cells and keeps
    spending the full ``alpha`` at every stage. This is the thing 16.1 says not
    to do; it is implemented so the paper can *report the difference* rather
    than assert it. It is registered as a **diagnostic** method and is tagged
    ``validity="nominal_only"`` so its coverage numbers cannot be pooled into a
    risk-controlled comparison by accident.
"""
from __future__ import annotations

import math
import random
from fractions import Fraction
from typing import Mapping

from engine.cost_ledger import flatten_charged_cost
from engine.finite_population_cs import CellCS
from engine.frozen_cells import (
    MAX_CELLS,
    allocate_fixed_cell_risk,
    freeze_coefficient_cells,
    independent_uniform_permutations,
)
from engine.scheduler import BATCH_CHOICES, pushforward_contrast_bounds

__all__ = [
    "AdaptiveProxy",
    "stage_alpha",
    "olla_allocate",
    "run_olla_cs",
    "OLLA_MODES",
]

OLLA_MODES = ("risk_aligned", "original")

#: How many scheduling steps between re-partitions.
DEFAULT_REFRESH_EVERY = 8

#: Prior strength (pseudo-counts) when shrinking a stratum rate toward what has
#: actually been observed. Small enough to learn fast, large enough that a
#: stratum with three labels does not swing the partition.
_SHRINK_M = 5.0


class AdaptiveProxy:
    """A proxy that is *re-cut* from observed labels, not frozen at pilot time.

    This is the "adaptive stratification" part of OLLA. The base proxy gives a
    prior rate; each proxy bin accumulates the labels actually observed inside
    it and the score becomes the shrunk empirical rate

        (k + m * p0) / (n + m)

    with ``m`` the prior strength. Re-binning on this score moves records into
    strata that match reality better as evidence arrives -- which is precisely
    why the partition cannot be treated as fixed.
    """

    def __init__(self, base, n_bins: int = 4, m: float = _SHRINK_M):
        self.base = base
        self.n_bins = n_bins
        self.m = m
        self._k: dict[int, int] = {}
        self._n: dict[int, int] = {}

    @staticmethod
    def _bin(score: float, n_bins: int) -> int:
        return min(n_bins - 1, int(max(0.0, min(1.0, score)) * n_bins))

    def observe(self, record_ids, labels) -> None:
        for rid in record_ids:
            if rid not in labels:
                continue
            b = self._bin(self.base.score(rid), self.n_bins)
            self._n[b] = self._n.get(b, 0) + 1
            self._k[b] = self._k.get(b, 0) + int(labels[rid])

    def score(self, record_id: str) -> float:
        p0 = float(self.base.score(record_id))
        b = self._bin(p0, self.n_bins)
        n = self._n.get(b, 0)
        k = self._k.get(b, 0)
        return (k + self.m * p0) / (n + self.m)

    def fit(self, record_ids, labels):
        self.observe(record_ids, labels)
        return self


def stage_alpha(alpha: float, stage: int, mode: str = "risk_aligned") -> float:
    """Pre-declared risk budget for re-partition stage ``s`` (proposal 16.1).

    ``risk_aligned``:  ``alpha * 2**-(s+1)``  -- summable, total <= alpha.
    ``original``:      ``alpha`` at every stage -- **not** summable. This is the
    invalid reuse; it exists so the experiment can report how much the
    adaptation costs, not as a silent default.
    """
    if mode not in OLLA_MODES:
        raise ValueError(f"mode must be one of {OLLA_MODES}, got {mode!r}")
    if mode == "original":
        return float(alpha)
    return float(alpha) * (2.0 ** -(int(stage) + 1))


def _cell_rate(cs: CellCS, prior: float) -> float:
    """Observed rate in a cell, falling back to the proxy prior when empty."""
    if cs.n > 0:
        return cs.s / cs.n
    return prior


def olla_allocate(cells, cell_cs, c_j_by_row, family, gamma: float = 1.0,
                  explore: bool = False, explore_rng=None):
    """Adaptive allocation: Neyman using **observed** rates, not proxy rates.

    This is the distinction from ProxyStratified-CS: that baseline balances
    variance using the frozen proxy mean, while OLLA re-estimates each stratum's
    rate from the labels it has already bought and re-allocates accordingly.
    Neither looks at the certificate family -- the target is estimator variance,
    which is the whole point of the comparison.
    """
    not_done = [c for c in cells if cell_cs[c.cell_id].n < cell_cs[c.cell_id].N]
    if not not_done:
        return -1, 0

    if explore:
        # 17.3: exploration draws come from the run-seeded rng, never a global
        rng = explore_rng if explore_rng is not None else random.Random(0)
        c = rng.choice(not_done)
        return c.cell_id, _batch_for(cell_cs[c.cell_id])

    total_N = sum(cell_cs[c.cell_id].N for c in not_done)
    total_n = sum(cell_cs[c.cell_id].n for c in not_done)
    if total_N == 0:
        return -1, 0

    weights = {}
    for c in not_done:
        cs = cell_cs[c.cell_id]
        # prior = the cell's own proxy-implied rate when nothing is read yet
        p = _cell_rate(cs, 0.5)
        sd = math.sqrt(max(p * (1.0 - p), 1e-6))
        weights[c.cell_id] = cs.N * sd
    W = sum(weights.values()) or 1.0

    best, best_deficit = None, None
    for c in not_done:
        cs = cell_cs[c.cell_id]
        target = (total_n + 1) * weights[c.cell_id] / W
        deficit = target - cs.n
        if best_deficit is None or deficit > best_deficit:
            best, best_deficit = c, deficit
    b = _batch_for(cell_cs[best.cell_id])
    return best.cell_id, b


def _batch_for(cs: CellCS) -> int:
    remaining = cs.N - cs.n
    if cs.n == 0:
        return min(16, remaining)
    for b in BATCH_CHOICES:
        if b <= remaining:
            return b
    return remaining


def _add_exact(c_j: dict[int, Fraction], A, ids, labels) -> None:
    """Fold known labels into the exact per-row contribution ``c_j``."""
    for r, row in enumerate(A.rows):
        total = Fraction(0)
        for i in ids:
            coeff = row.get(i)
            if coeff is None:
                continue
            if labels.get(i):
                total += coeff
        c_j[r] = c_j.get(r, Fraction(0)) + total


def run_olla_cs(
    contract,
    snapshot,
    oracle,
    proxy=None,
    alpha: float = 0.05,
    budget_calls: int = 1024,
    seed: int = 0,
    mode: str = "risk_aligned",
    refresh_every: int = DEFAULT_REFRESH_EVERY,
    max_refreshes: int = 6,
    texts: Mapping[str, str] | None = None,
    ledger=None,
    request_id: str | None = None,
    trace=None,
    **render_kw,
):
    """Run one request under OLLA (``original``) or OLLA-CS (``risk_aligned``).

    The loop mirrors ``engine.pipeline.answer`` -- same compiler, same
    coefficient cells, same finite-population kernel, same renderer and
    verifier -- and adds the one thing OLLA has that the others do not: the
    partition is re-cut while the request is running.
    """
    from engine.pipeline import (
        BudgetedOracle,
        OracleFailure,
        RetryPolicy,
        compute_pilot_contribution,
        deterministic_bounds_already_decide,
        exact_bounds_from_labels,
        fixed_uniform_pilot,
        render_verified,
        semantic_sensitivity,
        unsupported_certificate,
        verify_certificate,
    )
    from engine.evidence import illustrative_quotes
    from engine.answer_checker import decide, check_consistency
    from query.compiler import compile_signed_decisions, effective_support
    from query.contract_schema import ContractUnsupported

    if mode not in OLLA_MODES:
        raise ValueError(f"mode must be one of {OLLA_MODES}, got {mode!r}")

    reader = BudgetedOracle(
        oracle, budget_calls=budget_calls, ledger=ledger,
        request_id=request_id, retry=RetryPolicy(),
    )
    observed_labels: dict = {}
    sampled_record_ids: list = []

    try:
        A, family = compile_signed_decisions(
            contract, snapshot,
            keep_cancellations=bool(render_kw.get("keep_cancellations", False)))
    except ContractUnsupported as e:
        return unsupported_certificate(
            e.reason, contract=contract, alpha=alpha, seed=seed,
            semantic_calls=reader.spent, records_read=0, budget_calls=budget_calls,
        )

    def _render(bounds, satisfied, reason="", status_override="", extra=None):
        charged = (
            ledger.request_cost(request_id)
            if ledger is not None and request_id
            else {
                "semantic_calls": reader.spent,
                "records_read": len(observed_labels),
                "budget_calls": budget_calls,
                "source": "local_counter; no ledger attached",
            }
        )
        # 10.1: same top-level shape as pipeline._render — consumers read
        # charged["semantic_calls"]; the raw nesting reported 0 there.
        charged = flatten_charged_cost(charged)
        cert = render_verified(
            contract, family, bounds, satisfied, alpha, seed,
            render_kw.get("snapshot_hash", ""), render_kw.get("query_contract_hash", ""),
            render_kw.get("partition_hash", ""), render_kw.get("model_and_prompt_hash", ""),
            sampled_record_ids=sampled_record_ids,
            semantic_sensitivity=(
                semantic_sensitivity(A, family, bounds, satisfied) if satisfied else []
            ),
            charged_cost=charged,
            illustrative_quotes=illustrative_quotes(
                sampled_record_ids, observed_labels, texts,
                max_quotes=render_kw.get("max_quotes", 3),
            ),
            bundle_complete=family.bundle_complete(satisfied),
            decision_status=family.per_decision_status(satisfied),
        )
        cert["method"] = f"olla_cs:{mode}"
        cert["validity"] = (
            "per_request_simultaneous" if mode == "risk_aligned" else "nominal_only"
        )
        cert["olla"] = {
            "mode": mode,
            "stage": stage,
            "refreshes": refreshes,
            "stage_alpha": stage_alpha(alpha, stage, mode),
        }
        if extra:
            cert["olla"].update(extra)
        errors = verify_certificate(cert, family=family, contract=contract)
        if status_override:
            cert["status"] = status_override
            if reason:
                cert["reason"] = reason
        if errors and status_override not in ("unsupported",):
            cert["status"] = "execution_error"
            cert["verify_errors"] = errors
        return cert

    active_ids = sorted(effective_support(
        A, bool(render_kw.get("keep_cancellations", False))))
    if not active_ids:
        return _render({}, [], reason="no active support: contrast is identically zero")

    structural = deterministic_bounds_already_decide(A, family)
    if structural is not None:
        bounds, satisfied = structural
        if trace is not None:
            trace(bounds)
        return _render(bounds, satisfied)

    if proxy is None:
        from engine.proxy import StubProxy

        proxy = StubProxy(seed=seed)

    # --- pilot ------------------------------------------------------------
    stage = 0
    refreshes = 0
    pilot_ids = fixed_uniform_pilot(active_ids, budget_calls, seed)
    try:
        pilot_labels = reader.read(pilot_ids, phase="pilot", caller="pilot")
    except OracleFailure as exc:
        return _render({}, [], reason=str(exc), status_override="execution_error")
    observed_labels.update(pilot_labels)
    sampled_record_ids.extend(pilot_ids)
    c_j = compute_pilot_contribution(A, pilot_ids, pilot_labels)
    # 7.1 / G5: a real proxy (EmbeddingLRProxy) must be fitted on this
    # request's pilot labels before it scores anything -- the same rule
    # pipeline.answer applies. AdaptiveProxy therefore wraps the *fitted*
    # base and accumulates observed rates on top; a failed fit degrades to
    # the deterministic stub instead of crashing the request.
    from engine.pipeline import _fit_proxy_or_fallback

    adaptive = AdaptiveProxy(
        _fit_proxy_or_fallback(proxy, pilot_ids, pilot_labels, seed)
    )
    adaptive.observe(pilot_ids, pilot_labels)

    remaining = [i for i in active_ids if i not in set(pilot_ids)]
    if not remaining:
        return _render(
            exact_bounds_from_labels(A, family, observed_labels),
            decide(family, exact_bounds_from_labels(A, family, observed_labels)),
        )

    def _build_stage(ids, alpha_s, seed_stage):
        cells = freeze_coefficient_cells(ids, A, adaptive)
        risk = allocate_fixed_cell_risk(cells, alpha_s)
        cs = {
            c.cell_id: CellCS(c.N, float(risk.get(c.cell_id, Fraction(0))), lam=0.5)
            for c in cells
        }
        perms = independent_uniform_permutations(cells, seed_stage)
        return cells, cs, perms, {c.cell_id: 0 for c in cells}

    cells, cell_cs, perms, cursor = _build_stage(
        remaining, stage_alpha(alpha, stage, mode), seed
    )

    step = 0
    while reader.remaining > 0:
        bounds = pushforward_contrast_bounds(c_j, cells, cell_cs, family)
        if not check_consistency(bounds):
            return _render(bounds, [], reason="certificate_inconsistency",
                           status_override="execution_error")
        satisfied = decide(family, bounds)
        if trace is not None:
            trace(bounds)
        if family.bundle_complete(satisfied):
            break

        step += 1
        cell_id, batch = olla_allocate(
            cells, cell_cs, c_j, family, explore=(step % 4 == 0),
            explore_rng=random.Random(f"{seed}:explore:{step}"),
        )
        if cell_id < 0 or batch <= 0:
            break
        batch = min(batch, reader.remaining, cell_cs[cell_id].N - cell_cs[cell_id].n)
        if batch <= 0:
            break

        start = cursor[cell_id]
        ids = perms[cell_id][start: start + batch]
        try:
            labels = reader.read(ids, phase="oracle", caller="olla")
        except OracleFailure as exc:
            return _render(bounds, [], reason=str(exc), status_override="execution_error")
        observed_labels.update(labels)
        sampled_record_ids.extend(ids)
        cell_cs[cell_id].update([labels[i] for i in ids])
        cursor[cell_id] += batch
        adaptive.observe(ids, labels)

        # --- adaptive re-stratification ------------------------------------
        if (
            refresh_every > 0
            and step % refresh_every == 0
            and refreshes < max_refreshes
            and reader.remaining > 0
        ):
            unread: list = []
            read_now: list = []
            for c in cells:
                p = perms[c.cell_id]
                n_read = cursor[c.cell_id]
                read_now.extend(p[:n_read])
                unread.extend(p[n_read:])
            if not unread:
                break

            if mode == "risk_aligned":
                # Everything read becomes exact; new cells start empty.
                _add_exact(c_j, A, read_now, observed_labels)
                stage += 1
                cells, cell_cs, perms, cursor = _build_stage(
                    unread, stage_alpha(alpha, stage, mode), seed + 1000 * stage
                )
            else:
                # The invalid reuse this baseline exists to report: the old
                # evidence is carried into the new cells and alpha is spent
                # again. Deliberately kept, deliberately flagged.
                carried = {}
                for c in cells:
                    cs = cell_cs[c.cell_id]
                    carried[c.cell_id] = (cs.n, cs.s, cs.N)
                stage += 1
                cells, cell_cs, perms, cursor = _build_stage(
                    unread, stage_alpha(alpha, stage, mode), seed + 1000 * stage
                )
                for c in cells:
                    n0 = s0 = 0
                    for (_n, _s, _N) in carried.values():
                        share = len(c.records) / max(len(unread), 1)
                        n0 += int(round(_n * share))
                        s0 += int(round(_s * share))
                    n0 = min(n0, c.N)
                    s0 = min(s0, n0)
                    cell_cs[c.cell_id].n = n0
                    cell_cs[c.cell_id].s = s0
            refreshes += 1

    bounds = pushforward_contrast_bounds(c_j, cells, cell_cs, family)
    satisfied = decide(family, bounds) if check_consistency(bounds) else []
    return _render(bounds, satisfied)
