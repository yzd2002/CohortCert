#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Finite-population likelihood-ratio confidence sequence for one cell.

Implements 项目方案.md section 7.3, following Waudby-Smith & Ramdas (NeurIPS
2020) - this is an existing result, used here, not a new bound.

Model
-----
A cell holds N records with an unknown number K of positives. We read a uniformly
random permutation prefix of length n and observe s positives. The ordered-path
likelihood under candidate K is

    p_K(y_1:n) = (K)_s (N-K)_{n-s} / (N)_n

with (v)_m the falling factorial, and the working prior mixture is

    q(y_1:n) = (1-lam) * B(1+s, 1+n-s)/B(1,1)
             + lam    * B(a+s, b+n-s)/B(a,b)

The ratio M_n(K) = q / p_K is a non-negative supermartingale at the true K, so by
Ville's inequality P(exists n: M_n(K) >= 1/alpha) <= alpha, and

    {K : M_n(K) < 1/alpha}

is a valid confidence set. log M_n(K) is convex in K, so the set is an interval
and its endpoints can be found by bisection instead of enumerating all K.

Notes
-----
* The proxy prior (a, b) is a *working* parameter frozen before formal sampling.
  A mis-specified proxy costs efficiency, never validity (section 7.4), because
  the mixture always retains the Beta(1,1) component.
* We report the running intersection of confidence sets across updates. An empty
  intersection means something is wrong - return it as a signal, never as licence
  to certify anything.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

__all__ = ["log_falling", "log_beta", "log_mixture", "log_ratio", "CellCS"]


def log_falling(v: float, m: int) -> float:
    """log (v)_m where (v)_m = v(v-1)...(v-m+1), (v)_0 = 1."""
    if m < 0:
        return -math.inf
    if m == 0:
        return 0.0
    if v - m + 1 <= 0:
        return -math.inf
    return math.lgamma(v + 1.0) - math.lgamma(v - m + 1.0)


def log_beta(u: float, v: float) -> float:
    return math.lgamma(u) + math.lgamma(v) - math.lgamma(u + v)


def _logaddexp(x: float, y: float) -> float:
    hi = max(x, y)
    if hi == -math.inf:
        return -math.inf
    return hi + math.log1p(math.exp(min(x, y) - hi))


def log_mixture(
    s: int, n: int, a: float, b: float, lam: float = 0.5
) -> float:
    """log q(y_1:n) for the two-component working prior.

    ``lam`` is the weight of the proxy component. Both endpoints must work:
    ``lam=0`` is the base-Beta(1,1)-only ablation of proposal 18 and used to
    raise ``ValueError: math domain error`` here -- an ablation that crashes is
    an ablation nobody runs, so its result never gets reported. Weights outside
    [0, 1] are refused rather than quietly producing a negative mixture.
    """
    if not 0.0 <= lam <= 1.0:
        raise ValueError(f"mixture weight lam must be in [0, 1]; got {lam}")
    base = log_beta(1.0 + s, 1.0 + n - s) - log_beta(1.0, 1.0)
    if lam == 0.0:
        return base
    proxy = log_beta(a + s, b + n - s) - log_beta(a, b)
    if lam == 1.0:
        return proxy
    return _logaddexp(math.log1p(-lam) + base, math.log(lam) + proxy)


def log_path_likelihood(K: float, N: int, n: int, s: int) -> float:
    """log p_K(y_1:n) for the ordered binary path, up to a K-free constant."""
    if K < s or K > N - n + s:
        return -math.inf
    return log_falling(K, s) + log_falling(N - K, n - s) - log_falling(N, n)


def log_ratio(K: float, N: int, n: int, s: int, a: float, b: float, lam: float = 0.5) -> float:
    """log M_n(K) = log q - log p_K."""
    return log_mixture(s, n, a, b, lam) - log_path_likelihood(K, N, n, s)


@dataclass
class CellCS:
    """Running confidence sequence for the positive count of one cell.

    Parameters
    ----------
    N: cell size
    alpha: risk budget for this cell (sum over cells must be <= request alpha)
    a, b: working prior shapes from the frozen proxy; defaults are Beta(1,1)
    lam: mixture weight on the proxy component
    """

    N: int
    alpha: float = 0.05
    a: float = 1.0
    b: float = 1.0
    lam: float = 0.5
    n: int = 0
    s: int = 0
    low: int = 0
    inconsistent: bool = False
    high: int = field(default=None)  # type: ignore[assignment]

    def __post_init__(self) -> None:
        if self.high is None:
            self.high = self.N
        # 7.3: "数值实现可以保守地保留边界候选，不可向内错误舍入." lgamma
        # round-off near the Ville threshold could exclude a candidate the
        # math includes, shrinking the CS inward. A tiny slack widens the
        # set at the boundary -- the conservative direction.
        thr = -math.log(self.alpha) if self.alpha > 0 else math.inf
        self._threshold = thr + (1e-9 * max(1.0, abs(thr)) if thr < math.inf else 0.0)

    # -- internal ---------------------------------------------------------

    def _log_M(self, K: float) -> float:
        return log_ratio(K, self.N, self.n, self.s, self.a, self.b, self.lam)

    def _accepts(self, K: int) -> bool:
        return self._log_M(K) < self._threshold

    def _current_set(self) -> tuple[int, int] | None:
        """Bisect the convex sublevel set; returns None if it is empty."""
        if self.n == 0:
            return 0, self.N
        lo_min, hi_max = self.s, self.N - self.n + self.s
        if hi_max < lo_min:
            return None

        # locate a feasible point: start from the posterior mode estimate
        mode = max(lo_min, min(hi_max, int(round(self.s * (self.N + 1) / max(self.n, 1)))))
        if not self._accepts(mode):
            # convex sublevel set: scan outward a bounded number of steps
            found = None
            for probe in range(lo_min, hi_max + 1):
                if self._accepts(probe):
                    found = probe
                    break
            if found is None:
                return None
            mode = found

        # left edge
        left = lo_min
        lo, hi = lo_min, mode
        while lo < hi:
            mid = (lo + hi) // 2
            if self._accepts(mid):
                hi = mid
            else:
                lo = mid + 1
        left = lo

        # right edge
        lo, hi = mode, hi_max
        while lo < hi:
            mid = (lo + hi + 1) // 2
            if self._accepts(mid):
                lo = mid
            else:
                hi = mid - 1
        right = lo
        return left, right

    # -- public -----------------------------------------------------------

    def update(self, new_labels: list[int]) -> tuple[int, int] | None:
        """Append newly read labels (in permutation order) and intersect."""
        if self.inconsistent:
            # A previous step found the running intersection empty. Recording
            # the exact [s, s] now would silently wipe that signal (the final
            # render would look resolvable); keep reporting the inconsistency.
            for y in new_labels:
                if y not in (0, 1):
                    raise ValueError("labels must be binary")
                self.n += 1
                self.s += int(y)
            return None
        for y in new_labels:
            if y not in (0, 1):
                raise ValueError("labels must be binary")
            self.n += 1
            self.s += int(y)
        if self.n > self.N:
            raise ValueError("read more records than the cell contains")
        if self.n == self.N:
            self.low = self.high = self.s
            return self.bounds

        cur = self._current_set()
        if cur is None:
            # Inconsistent: report it, do not silently widen. The flag makes
            # the state sticky so a later exact completion cannot erase it.
            self.inconsistent = True
            self.low, self.high = 1, 0
            return None
        l, h = cur
        self.low = max(self.low, l)
        self.high = min(self.high, h)
        return self.bounds

    @property
    def bounds(self) -> tuple[int, int] | None:
        if self.low > self.high:
            return None
        return self.low, self.high

    @property
    def width(self) -> int:
        b = self.bounds
        return 0 if b is None else b[1] - b[0]
