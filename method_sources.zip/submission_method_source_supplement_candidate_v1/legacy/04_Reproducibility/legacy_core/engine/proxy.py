"""Semantic proxy used only for stratification / working prior / scheduling.

Per scheme 7.1 the proxy predicts P(predicate true | text). It NEVER decides
inclusion, NEVER produces the reference label, and NEVER reads unqueried
labels. A deterministic ``StubProxy`` lets the full pipeline run on CPU before
the real Qwen3-Embedding-0.6B + CPU logistic-regression proxy (scheme 7.1) is
trained. Swap in ``EmbeddingLRProxy`` once embeddings exist -- same interface.
"""
from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Protocol, runtime_checkable


@runtime_checkable
class Proxy(Protocol):
    def score(self, record_id: str) -> float:
        """Predicted probability in [0, 1] that the predicate holds for the text."""
        ...


class StubProxy:
    """Deterministic, label-free proxy for CPU-only development and tests.

    Scores are either taken from an explicit ``score_map`` (tests) or derived
    from a stable hash of the record id (reproducible, no model needed).
    """

    def __init__(self, seed: int = 0, score_map: dict | None = None):
        self.seed = seed
        self.score_map = dict(score_map) if score_map else {}

    def score(self, record_id: str) -> float:
        if record_id in self.score_map:
            return float(self.score_map[record_id])
        digest = hashlib.md5(f"{self.seed}:{record_id}".encode("utf-8")).digest()
        return int.from_bytes(digest[:8], "big") / 2**64

    def fit(self, records, labels):
        # The stub needs no training; real proxies override this.
        return self


class EmbeddingLRProxy:
    """CPU logistic-regression proxy on precomputed Qwen3-Embedding-0.6B vectors.

    Training labels come from the 8B reference oracle (pilot sample) -- those are
    still blocked on the 5090, so this class is written now and *fit* later.
    Scoring needs no GPU: it is a single dense matmul + sigmoid on the CPU.

    Embeddings are produced by ``data_scripts/embed_snapshots.py`` and stored as
    ``<dataset>_emb.npy`` (n x dim float32) plus ``<dataset>_index.parquet``
    (record_id -> row). This proxy is per-dataset (one embedding matrix).
    """

    def __init__(self, dataset: str, embeddings_dir: str | Path):
        import numpy as np
        import pandas as pd

        d = Path(embeddings_dir)
        emb_path = d / f"{dataset}_emb.npy"
        idx_path = d / f"{dataset}_index.parquet"
        if not emb_path.exists():
            raise FileNotFoundError(
                f"embeddings for '{dataset}' not found at {emb_path}; "
                f"run data_scripts/embed_snapshots.py first"
            )
        self.dataset = dataset
        self._emb = np.load(emb_path)
        idx = pd.read_parquet(idx_path)
        self._row_of = {
            str(r): int(i) for r, i in zip(idx["record_id"], idx["emb_row"])
        }
        self._model = None
        self._dim = int(self._emb.shape[1])
        # Per-request score memo (see score()); cleared on fit(), fresh on clone.
        self._score_cache = {}
        self._fast_lr = False

    def fit(self, record_ids, labels, C: float = 1.0, max_iter: int = 1000):
        """Train the logistic regressor on the embeddings of ``record_ids``."""
        import numpy as np
        from sklearn.linear_model import LogisticRegression

        rows = [self._row_of[str(r)] for r in record_ids]
        X = self._emb[rows]
        y = np.asarray(labels, dtype=int)
        self._model = LogisticRegression(C=C, max_iter=max_iter)
        self._model.fit(X, y)
        self._fast_lr = (len(self._model.classes_) == 2 and self._model.coef_.shape == (1, self._dim))
        # A retrained model scores differently: any cached scores are stale.
        self._score_cache.clear()
        return self

    def score(self, record_id: str) -> float:
        import numpy as np

        if self._model is None:
            raise RuntimeError("fit() must be called before score()")
        cached = self._score_cache.get(record_id)
        if cached is not None:
            return cached
        row = self._row_of[str(record_id)]
        x = self._emb[row : row + 1].astype(np.float64)
        # The binary sklearn path performs exactly x @ coef.T + intercept,
        # scipy.special.expit in place, and selects the second probability.
        # Keep sklearn's validation/error behavior for nonfinite inputs and
        # non-binary or externally supplied models. No batching or reordering.
        if self._fast_lr and x.shape == (1, self._dim) and np.isfinite(x).all():
            from scipy.special import expit
            prob = (x @ self._model.coef_.T + self._model.intercept_).reshape(-1)
            expit(prob, out=prob)
            value = float(prob[0])
        else:
            value = float(self._model.predict_proba(x)[0, 1])
        # Per-request memo: neyman/OLLA-style allocators re-score every record
        # of every cell at every scheduling step (hundreds of thousands of
        # identical queries per request). The model is fixed once fitted, so
        # the cache cannot drift; instances are per-request clones, so nothing
        # leaks across requests. Pure performance -- identical values.
        self._score_cache[record_id] = value
        return value

    @property
    def is_fitted(self) -> bool:
        return self._model is not None

    def clone_unfitted(self) -> "EmbeddingLRProxy":
        """Fresh unfitted proxy sharing this one's loaded embedding matrix.

        ``fit`` overwrites ``_model`` in place, so reusing one instance across
        requests would carry the previous request's pilot-trained model into
        the next one (and its scores into stratification). The embedding
        matrix (156 MB for cfpb) is immutable and shared by reference; only
        the tiny per-request trained state is fresh.
        """
        clone = object.__new__(type(self))
        clone.dataset = self.dataset
        clone._emb = self._emb
        clone._row_of = self._row_of
        clone._model = None
        clone._dim = self._dim
        clone._score_cache = {}
        clone._fast_lr = False
        return clone

