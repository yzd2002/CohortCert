#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Cost ledger for proposal section 14 (成本账本).

Three ledgers, three files, never mixed
---------------------------------------
``build.jsonl``  one-off construction: download, clean, embed, index,
                 request-specific pilot, proxy training, semantic materialisation.
``query.jsonl``  per-request serving cost, split by the six phases of 14.1.
``eval.jsonl``   one-off evaluation: full-scan reference labels, CPU trajectory
                 replays, repeat seeds, figure statistics.

Section 14.2 states that evaluation cost must not be secretly available to the
deployed algorithm. Splitting the files is the cheapest enforcement that
actually works: any code that wants evaluation data has to open ``eval.jsonl``
on purpose, and auditing who read what is a grep away. The oracle vault below
goes one step further and logs *every* read together with the caller name.

What is counted
---------------
14.1: :math:`C_q = C^{parse} + C^{pilot} + C^{oracle} + C^{schedule} +
C^{certificate} + C^{render}`. Time, tokens and call counts are reported side by
side; semantic calls of different length are never treated as equal cost.

14.3: cold start includes all request-specific work. Warm start may reuse
existing embeddings, same-version labels and proxies, but build cost does not
disappear - it is amortised, not deleted:
:math:`\\bar C(Q) = (C_{build} + \\sum_q C_q) / Q`.

Units
-----
wall_ms / gpu_active_ms / cpu_ms are milliseconds; tokens and calls are counts;
peak_gpu_bytes is bytes and aggregates by max, never by sum.
"""

from __future__ import annotations

import json
import time
import uuid
from contextlib import contextmanager
from dataclasses import dataclass, field, fields
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator, Mapping, Sequence

__all__ = [
    "SCHEMA_VERSION",
    "CATEGORIES",
    "BUILD_PHASES",
    "QUERY_PHASES",
    "EVAL_PHASES",
    "CostEvent",
    "CostLedger",
    "OracleVault",
]

SCHEMA_VERSION = "1.0.0"

CATEGORIES = ("build", "query", "eval")

#: Total per-request cost is the sum over exactly these six phases (14.1).
QUERY_PHASES = ("parse", "pilot", "oracle", "schedule", "certificate", "render")

BUILD_PHASES = (
    "download",
    "clean",
    "embed",
    "index",
    "pilot",
    "proxy_train",
    "materialize",
)

EVAL_PHASES = ("full_scan_labels", "trajectory_replay", "repeat_seed", "figure_stats")

_PHASES_BY_CATEGORY = {
    "build": BUILD_PHASES,
    "query": QUERY_PHASES,
    "eval": EVAL_PHASES,
}

#: Summed when aggregating. peak_gpu_bytes is deliberately absent - it is a
#: maximum, and adding peak usages across events would be meaningless.
_SUM_FIELDS = (
    "wall_ms",
    "semantic_calls",
    "input_tokens",
    "output_tokens",
    "gpu_active_ms",
    "cpu_ms",
    "records_read",
    "cache_hits",
)


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


#: Headline fields ``request_cost`` nests under ``total``; every consumer reads
#: them from the top level (10.1: the nesting made olla/bargain report 0 calls
#: wherever no sampled-ids fallback existed, e.g. the live runner).
_HEADLINE_COST_FIELDS = ("semantic_calls", "records_read", "gpu_active_ms", "wall_ms")


def flatten_charged_cost(charged: dict) -> dict:
    """Lift ``total``'s headline fields to the top level, in place and idempotent.

    Single shared shape for every certificate's ``charged_cost``: pipeline,
    olla_cs and bargain all assemble ``ledger.request_cost(request_id)`` and
    must hand consumers the same dictionary shape (10.1). The nested
    ``request_id``/``per_phase``/``total`` keys are preserved for audit.
    """
    total = charged.get("total", {})
    for k in _HEADLINE_COST_FIELDS:
        v = total.get(k)
        if v is not None:
            charged[k] = v
    return charged


@dataclass
class CostEvent:
    """One line of one ledger file."""

    category: str
    phase: str
    wall_ms: float = 0.0
    semantic_calls: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    gpu_active_ms: float = 0.0
    cpu_ms: float = 0.0
    peak_gpu_bytes: int = 0
    records_read: int = 0
    cache_hits: int = 0
    request_id: str | None = None
    seed: int | None = None
    # 14.3: warm start reuses embeddings / same-version labels / proxies.
    warm_start: bool = False
    # True when this call was served from a cross-request cache. 14.2 requires
    # cross-request caching to be flagged separately; within-request
    # deduplication is always allowed and is not what this field means.
    served_from_cache: bool = False
    note: str = ""
    ts_utc: str = field(default_factory=_now_iso)

    def to_dict(self) -> dict[str, Any]:
        return {f.name: getattr(self, f.name) for f in fields(self)}


class CostLedger:
    """Append-only JSONL cost ledger rooted at ``results/raw_logs/<run_id>/``.

    Parameters
    ----------
    root: directory holding one subdirectory per run.
    run_id: defaults to ``<utc timestamp>-<6 hex>``. Pass a fixed id to resume.
    dataset: population name (``cfpb`` / ``opinrank``) the run is scoped to.
    cache_across_requests: recorded once in ``meta.json``; 14.2 wants this
        stated explicitly rather than inferred from cost numbers.
    """

    def __init__(
        self,
        root: str | Path = "results/raw_logs",
        run_id: str | None = None,
        dataset: str | None = None,
        model_revision: str | None = None,
        cache_across_requests: bool = False,
        note: str = "",
    ) -> None:
        self.root = Path(root)
        self.run_id = run_id or (
            datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + uuid.uuid4().hex[:6]
        )
        self.dataset = dataset
        self.dir = self.root / self.run_id
        self.dir.mkdir(parents=True, exist_ok=True)

        self._events: list[CostEvent] = []
        self._meta = {
            "schema_version": SCHEMA_VERSION,
            "run_id": self.run_id,
            "dataset": dataset,
            "model_revision": model_revision,
            "cache_across_requests": cache_across_requests,
            "note": note,
            "created_utc": _now_iso(),
        }
        (self.dir / "meta.json").write_text(
            json.dumps(self._meta, ensure_ascii=False, indent=2), encoding="utf-8"
        )

    # -- recording --------------------------------------------------------

    def record(self, category: str, phase: str, **kwargs: Any) -> CostEvent:
        """Append one event. Unknown phases are rejected on purpose: a typo in
        a phase name silently moves cost between the six buckets of 14.1."""
        if category not in CATEGORIES:
            raise ValueError(f"unknown category {category!r}; expected one of {CATEGORIES}")
        allowed = _PHASES_BY_CATEGORY[category]
        if phase not in allowed:
            raise ValueError(
                f"phase {phase!r} does not belong to category {category!r}; "
                f"allowed: {', '.join(allowed)}"
            )
        ev = CostEvent(category=category, phase=phase, **kwargs)
        self._events.append(ev)
        path = self.dir / f"{category}.jsonl"
        with path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(ev.to_dict(), ensure_ascii=False) + "\n")
        return ev

    @contextmanager
    def span(self, category: str, phase: str, **kwargs: Any) -> Iterator[dict[str, Any]]:
        """Time a block and record it. Yield a dict the caller can fill in.

        >>> with ledger.span("query", "oracle") as ev:
        ...     labels = vault.get(ids, caller="scheduler")
        ...     ev["semantic_calls"] = len(ids)
        """
        box: dict[str, Any] = {}
        t0 = time.perf_counter()
        try:
            yield box
        finally:
            box.setdefault("wall_ms", (time.perf_counter() - t0) * 1000.0)
            self.record(category, phase, **{**kwargs, **box})

    # -- aggregation ------------------------------------------------------

    def _select(
        self,
        category: str | None = None,
        request_id: str | None = None,
        phase: str | None = None,
    ) -> list[CostEvent]:
        out = self._events
        if category is not None:
            out = [e for e in out if e.category == category]
        if request_id is not None:
            out = [e for e in out if e.request_id == request_id]
        if phase is not None:
            out = [e for e in out if e.phase == phase]
        return out

    @staticmethod
    def _aggregate(events: Sequence[CostEvent]) -> dict[str, Any]:
        total: dict[str, Any] = {k: 0 for k in _SUM_FIELDS}
        # Initialised outside the loop: an empty selection still needs the key,
        # otherwise max() over two categories raises when one of them is empty.
        total["peak_gpu_bytes"] = 0
        for e in events:
            for k in _SUM_FIELDS:
                total[k] += getattr(e, k)
            total["peak_gpu_bytes"] = max(total.get("peak_gpu_bytes", 0), e.peak_gpu_bytes)
        total["events"] = len(events)
        # Summed wall time is NOT wall-clock duration when anything runs in
        # parallel; keep both so nobody reports the sum as latency by accident.
        total["wall_ms_sum"] = total.pop("wall_ms")
        return total

    def totals(
        self,
        category: str | None = None,
        request_id: str | None = None,
        phase: str | None = None,
    ) -> dict[str, Any]:
        return self._aggregate(self._select(category, request_id, phase))

    def request_cost(self, request_id: str) -> dict[str, Any]:
        """Per-phase breakdown plus the 14.1 total for one request."""
        per_phase = {
            p: self._aggregate(self._select("query", request_id, p)) for p in QUERY_PHASES
        }
        total = self._aggregate(self._select("query", request_id))
        return {"request_id": request_id, "per_phase": per_phase, "total": total}

    def amortized(self) -> dict[str, Any]:
        """14.3: :math:`\\bar C(Q) = (C_{build} + \\sum_q C_q) / Q`.

        Raises if no query has been recorded - dividing by zero requests is
        exactly the kind of silent error a cost table should not survive.
        """
        request_ids = sorted(
            {e.request_id for e in self._events if e.category == "query" and e.request_id}
        )
        if not request_ids:
            raise ValueError("no query events recorded; amortisation is undefined")
        q = len(request_ids)
        build = self.totals("build")
        query = self.totals("query")

        per_request: dict[str, Any] = {}
        for k in _SUM_FIELDS:
            if k == "wall_ms":
                per_request[k] = (build["wall_ms_sum"] + query["wall_ms_sum"]) / q
            else:
                per_request[k] = (build[k] + query[k]) / q
        per_request["peak_gpu_bytes"] = max(build["peak_gpu_bytes"], query["peak_gpu_bytes"])

        query_only = {k: query[k] / q for k in _SUM_FIELDS if k != "wall_ms"}
        query_only["wall_ms"] = query["wall_ms_sum"] / q
        query_only["peak_gpu_bytes"] = query["peak_gpu_bytes"]

        return {
            "requests": q,
            "build_total": build,
            "query_total": query,
            "per_request_amortized": per_request,
            "per_request_query_only": query_only,
        }

    # -- lifecycle --------------------------------------------------------

    def summary(self) -> dict[str, Any]:
        out: dict[str, Any] = {
            "meta": self._meta,
            "closed_utc": _now_iso(),
            "by_category": {c: self.totals(c) for c in CATEGORIES},
        }
        try:
            out["amortized"] = self.amortized()
        except ValueError:
            out["amortized"] = None
        return out

    def close(self) -> Path:
        path = self.dir / "summary.json"
        path.write_text(json.dumps(self.summary(), ensure_ascii=False, indent=2), encoding="utf-8")
        return path


class OracleVault:
    """Read-only reference-label interface with an access log (proposal 14.2).

    Reference labels are produced once by a full scan and then sealed here. The
    algorithm submits explicit record ids and receives exactly those labels -
    it can never sweep the vault. Every read is charged to ``eval.jsonl`` as the
    cost that *would* have been incurred, and written to ``oracle_access.jsonl``
    with the caller name, so a scheduler that quietly peeks at labels leaves a
    trace.

    ``replay=True`` marks the read as fixed-oracle trajectory replay: it is
    valid for call counts and coverage, and explicitly NOT a real GPU latency
    measurement (14.2).
    """

    def __init__(
        self,
        labels: Mapping[str, int],
        ledger: CostLedger,
        cost_per_label: dict[str, float] | None = None,
    ) -> None:
        self._labels = dict(labels)
        self._ledger = ledger
        self._cost = dict(cost_per_label or {})
        self._access_log = ledger.dir / "oracle_access.jsonl"

    @property
    def size(self) -> int:
        return len(self._labels)

    def get(
        self,
        record_ids: Sequence[str],
        caller: str,
        replay: bool = False,
    ) -> dict[str, int]:
        ids = list(record_ids)
        unknown = [i for i in ids if i not in self._labels]
        if unknown:
            raise KeyError(f"{len(unknown)} id(s) absent from the vault, e.g. {unknown[:3]}")

        entry = {
            "ts_utc": _now_iso(),
            "caller": caller,
            "n_ids": len(ids),
            "replay": replay,
        }
        with self._access_log.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(entry, ensure_ascii=False) + "\n")

        self._ledger.record(
            "eval",
            "full_scan_labels",
            semantic_calls=len(ids),
            input_tokens=int(self._cost.get("input_tokens_per_label", 0) * len(ids)),
            output_tokens=int(self._cost.get("output_tokens_per_label", 0) * len(ids)),
            gpu_active_ms=self._cost.get("gpu_active_ms_per_label", 0.0) * len(ids),
            records_read=len(ids),
            note=(
                f"caller={caller}; {'trajectory replay, no real GPU latency' if replay else 'would-have-been cost'}"
            ),
        )
        return {i: self._labels[i] for i in ids}

    def access_log(self) -> list[dict[str, Any]]:
        if not self._access_log.exists():
            return []
        return [
            json.loads(line)
            for line in self._access_log.read_text(encoding="utf-8").splitlines()
            if line.strip()
        ]
