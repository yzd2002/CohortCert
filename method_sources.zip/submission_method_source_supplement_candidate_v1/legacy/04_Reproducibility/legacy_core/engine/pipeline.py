"""End-to-end certificate pipeline (scheme 11, adapted for CPU / stub oracle).

This is the minimal loop that wires the compiled contract to the fixed-cell
confidence sequences and a pluggable *scheduler*. The same loop serves both the
CohortCert scheduler and the SharedContrast-CS baseline -- only the scheduler
strategy differs (scheme 98: identical signed representation, pilot,
stratification, prior and cache; swap only the allocation target).

The oracle here is a stand-in. In production it is Qwen3-8B behind
``cost_ledger.OracleVault``; on CPU it is a deterministic stub so the whole
system runs and is tested without a GPU. The *scientific* labels still require
the 8B model (scheme 13) -- this delivers the pipeline, not the science.

Execution details that are easy to drop and are therefore wired in here
-----------------------------------------------------------------
* **6.3** before any semantic call the sharp deterministic bounds are checked:
  if the answer is already determined by the algebra alone, no label is read.
* **7.1** pilot calls are charged like any other call; nothing is free.
* **7.1** a very small request is scanned exactly when the budget allows it.
* **8.2** fixed exploration rounds, so the gain heuristic cannot starve a cell.
* **9.2** every certified claim is reported with the number of arbitrary label
  corrections it provably survives.
* **10.4** illustrative quotes are taken only from records already read.
* **10.5** the rendered object passes a deterministic verifier before it ships.
* **11**  a failed semantic call is charged, retried, and then terminates the
  request with its valid partial result. It is never recorded as label 0.
* **14**  parse / pilot / oracle / schedule / certificate / render are charged
  separately when a ledger is supplied.
"""
from __future__ import annotations

import inspect
import math
import random
import secrets
import time
from fractions import Fraction
from typing import Callable, Mapping, Protocol, Sequence, runtime_checkable

from query.compiler import (
    compile_signed_decisions,
    effective_support,
    rows_with_any_nonzero_coefficient,
)
from query.contract_schema import ContractUnsupported, normalize_decisions
from engine.cost_ledger import flatten_charged_cost
from engine.proxy import StubProxy
from engine.frozen_cells import (
    allocate_fixed_cell_risk,
    freeze_coefficient_cells,
    independent_uniform_permutations,
)
from engine.finite_population_cs import CellCS

#: 7.1: only *tiny* requests are scanned exactly instead of sampled. Above
#: this support size the request goes through pilot -> frozen cells -> CS ->
#: certificate-driven scheduling, which is the method under test. Mirrored in
#: configs/frozen_main.yaml (workload.tiny_full_scan_max_records).
TINY_FULL_SCAN_MAX = 128
from engine.scheduler import (
    EPS_SCHED,
    choose_by_certificate_gain_per_cost,
    pushforward_contrast_bounds,
)
from engine.answer_checker import decide, render_verified, check_consistency
from engine.oracle_interface import BudgetedOracle, OracleFailure, RetryPolicy
from engine.evidence import illustrative_quotes
from engine.verifier import verify_certificate
from engine.renderer import render_answer_text, verify_answer_text
from engine.signed_algebra import (
    deterministic_bounds,
    flip_tolerance,
    perturbation_bound,
)


@runtime_checkable
class Oracle(Protocol):
    def read(self, record_ids: list) -> dict:
        """Return ``{record_id: 0|1}`` for the queried records."""
        ...


SchedulerStrategy = Callable[[list, dict, dict, object], tuple[int, int]]


def _default_strategy(cells, cell_cs, c_j, family, explore_rng=None) -> tuple[int, int]:
    """Kept for callers that expect a plain strategy object.

    It uses the module defaults for gamma / epsilon_sched. Requests that need
    the configured values get :func:`_make_default_strategy` instead -- see the
    note there about why gamma used to be dead by default.
    """
    return choose_by_certificate_gain_per_cost(
        cells, cell_cs, c_j, family, explore_rng=explore_rng
    )


def _make_default_strategy(gamma: float, epsilon_sched: float,
                           cost_model: str = "record",
                           texts: Mapping[str, str] | None = None) -> SchedulerStrategy:
    """Certificate-gain strategy bound to the request's tuning parameters.

    ``answer()`` accepted ``gamma`` since it was written but never forwarded it
    here, so every run silently used ``gamma=1.0`` no matter what was asked
    for: an ablation over gamma would have compared identical trajectories and
    concluded "no effect". Both dev-set hyper-parameters now travel through an
    explicit closure instead of living in module state.

    ``cost_model`` selects the per-record cost used by the gain/cost ratio
    (§18 ablation row): ``"record"`` prices every record identically (the
    frozen main configuration); ``"text_length"`` prices a cell by its mean
    narrative length, so long-text cells are discounted per unit of evidence.
    """
    def strategy(cells, cell_cs, c_j, family, explore: bool = False,
                 explore_rng=None) -> tuple[int, int]:
        cost = _cell_costs(cells, texts, cost_model)
        return choose_by_certificate_gain_per_cost(
            cells, cell_cs, c_j, family,
            gamma=gamma, epsilon_sched=epsilon_sched,
            cost_per_record=cost,
            explore=explore, explore_rng=explore_rng,
        )

    return strategy


def _cell_costs(cells, texts, cost_model: str):
    """Per-cell record cost: 1.0 for the record model, mean text length for
    the text_length model (any positive monotone value works -- the scheduler
    only compares cells against each other)."""
    if cost_model != "text_length" or not texts:
        return 1.0
    out = {}
    for c in cells:
        lens = [len(texts.get(i, "")) for i in c.records] or [1]
        out[c.cell_id] = sum(lens) / len(lens)
    return out or 1.0


def _strategy_accepts_explore(strategy) -> bool:
    """True when the strategy can take an ``explore`` keyword.

    Baselines that only implement the four-argument signature are called
    without it rather than silently losing their exploration rounds.
    """
    try:
        sig = inspect.signature(strategy)
    except (TypeError, ValueError):
        return False
    if any(p.kind is inspect.Parameter.VAR_KEYWORD for p in sig.parameters.values()):
        return True
    return "explore" in sig.parameters


def _strategy_accepts_rng(strategy) -> bool:
    """True when the strategy takes the seeded exploration rng.

    17.3: exploration rounds are part of the run's stochastic trajectory, so
    they must draw from a rng derived from the sampling seed. Strategies that
    predate the rng parameter are called without it; their fallback (a fixed
    Random(0)) is deterministic but seed-independent, which replay will flag.
    """
    try:
        sig = inspect.signature(strategy)
    except (TypeError, ValueError):
        return False
    if any(p.kind is inspect.Parameter.VAR_KEYWORD for p in sig.parameters.values()):
        return True
    return "explore_rng" in sig.parameters


def _call_strategy(
    strategy, cells, cell_cs, c_j, family, explore: bool, step: int,
    explore_rng: random.Random | None = None,
):
    if explore:
        extra = {}
        if _strategy_accepts_explore(strategy):
            extra["explore"] = True
        if _strategy_accepts_rng(strategy):
            extra["explore_rng"] = explore_rng
        return strategy(cells, cell_cs, c_j, family, **extra)
    return strategy(cells, cell_cs, c_j, family)


def fixed_uniform_pilot(active_ids: list, budget_calls: int, seed: int) -> list:
    """Pilot = uniform prefix of a permutation of the active support (scheme 7.1).

    m_pilot = min(256, floor(|I|/10), floor(B/4)); tiny requests may pilot all.
    """
    n = len(active_ids)
    m = min(256, n // 10, budget_calls // 4)
    m = max(0, min(m, n))
    rng = random.Random(seed)
    perm = list(active_ids)
    rng.shuffle(perm)
    return perm[:m]


def compute_pilot_contribution(A, pilot_ids: list, pilot_labels: dict) -> dict:
    """Exact per-coefficient-row pilot contribution c_j (scheme 7.1).

    Labels are indexed directly instead of defaulting to 0: a missing label is
    an execution failure (scheme 11), and silently treating it as 0 would turn
    an unread record into manufactured evidence.
    """
    c_j: dict[int, Fraction] = {}
    for r, row in enumerate(A.rows):
        total = Fraction(0)
        for i in pilot_ids:
            coeff = row.get(i)
            if coeff is None:
                continue
            if pilot_labels[i]:
                total += coeff
        c_j[r] = total
    return c_j


def _fit_proxy_or_fallback(proxy, pilot_ids: list, pilot_labels: dict, seed: int):
    """Fit the proxy on the pilot labels; fall back to the stub if that fails.

    ``fit`` is optional on the Proxy protocol, so a proxy without it is used
    as-is. One that raises -- missing embeddings, a degenerate pilot with a
    single class, a solver that will not converge -- is replaced by the stub and
    the degradation is recorded on the object so the run is auditable rather
    than silently different.

    The degradation is applied IN PLACE (the instance delegates ``score`` to
    the stub) instead of by object replacement: scheduler closures passed by
    the §18 baselines capture this very instance, and an object swap would
    leave them calling the unfitted scorer -- 281 NotFittedError requests in
    the 10-seed main grid (fix_plan_2026-10-07 A1). In-place delegation keeps
    every captured reference working; non-crashed requests are untouched.
    """
    if proxy is None:
        return StubProxy(seed=seed)
    fit = getattr(proxy, "fit", None)
    if fit is None:
        return proxy
    try:
        fitted = fit(pilot_ids, [pilot_labels[i] for i in pilot_ids])
        return fitted if fitted is not None else proxy
    except Exception as exc:  # noqa: BLE001 - degradation, not control flow
        stub = StubProxy(seed=seed)
        stub.fit_failed = f"{type(exc).__name__}: {exc}"
        # delegate in place so closures holding this instance degrade too
        proxy.score = stub.score
        proxy.fit_failed = stub.fit_failed
        return proxy


def deterministic_bounds_already_decide(A, family):
    """Sharp bounds over all completions, before any label is read (scheme 6.3).

    Short-circuits only when the sharp bounds decide the *whole answer
    contract*: every declared decision must have exactly one satisfiable
    certificate. Two satisfiable certificates for one decision is a tie and a
    tie must not be published as a unique winner; a decision with none is
    undecided -- and a multi-judgement bundle with one decided judgement must
    keep spending budget on the rest, not return unresolved for free.
    """
    bounds: dict[int, tuple[Fraction, Fraction]] = {}
    for atom in family.atoms:
        lo, hi = deterministic_bounds(A.rows[atom.row_index], {})
        bounds[atom.index] = (lo, hi)
    satisfied = family.check(bounds)
    for di in family.decision_indices():
        hits = [ci for ci in satisfied if family.certificate_decisions[ci] == di]
        if len(hits) != 1:
            return None
    return bounds, satisfied


def exact_bounds_from_labels(A, family, labels: Mapping[str, int]) -> dict:
    """Point intervals when every active record has been read.

    Labels are read by subscript: completeness is guaranteed by
    ``BudgetedOracle``, and a KeyError here is a bug worth surfacing rather
    than a place to default to zero.
    """
    out: dict[int, tuple[Fraction, Fraction]] = {}
    for atom in family.atoms:
        theta = Fraction(0)
        for i, coef in A.rows[atom.row_index].items():
            if labels[i]:
                theta += coef
        out[atom.index] = (theta, theta)
    return out


def semantic_sensitivity(A, family, bounds, claims) -> list[dict]:
    """How many arbitrary label corrections each certified claim survives (9.2).

    The reported ``tolerated_label_corrections`` is a provable lower bound:
    ``rho(r)`` uses only the magnitudes of the largest coefficients, so it does
    not exploit that a current 1 can only be corrected downwards. An upper atom
    is handled by negating coefficients, thresholds and endpoints, which turns
    ``U < b`` into the same "lower bound clears a threshold" test.
    """
    out: list[dict] = []
    for ci in claims:
        for aid in family.certificates[ci]:
            atom = family._by_index[aid]
            L, U = bounds[aid]
            coefs = list(A.rows[atom.row_index].values())
            if atom.kind == "lower":
                r = flip_tolerance(coefs, L, atom.threshold)
                margin = Fraction(L) - atom.threshold
            else:
                r = flip_tolerance(coefs, -U, -atom.threshold)
                margin = atom.threshold - Fraction(U)
            rho = perturbation_bound(coefs, r)
            out.append(
                {
                    "atom_index": aid,
                    "certificate": ci,
                    "direction": "greater" if atom.kind == "lower" else "less",
                    "margin": str(margin),
                    "tolerated_label_corrections": r,
                    "rho_at_r": str(rho),
                    "semantic_interval_if_r_corrections": [str(L - rho), str(U + rho)],
                    "note": (
                        "lower bound on tolerated arbitrary corrections; "
                        "the actual number of model errors was NOT measured"
                    ),
                }
            )
    return out


def unsupported_certificate(
    reason: str,
    contract: dict | None = None,
    alpha: float = 0.05,
    seed: int = 0,
    snapshot_hash: str = "",
    query_contract_hash: str = "",
    partition_hash: str = "",
    model_and_prompt_hash: str = "",
    semantic_calls: int = 0,
    records_read: int = 0,
    budget_calls: int = 0,
    cost_source: str = "local_counter; no ledger attached",
    extra: dict | None = None,
) -> dict:
    """The full certificate skeleton for a request that was never executed.

    Callers and metric code must not have to special-case a short dict: an
    ``unsupported`` answer has no intervals and no claims, but it is still an
    answer of the same shape, and it stays in the metric denominator
    (scheme 10.5 / 8.3).
    """
    out = {
        "status": "unsupported",
        "reason": reason,
        "snapshot_hash": snapshot_hash,
        "model_and_prompt_hash": model_and_prompt_hash,
        "query_contract_hash": query_contract_hash,
        "partition_hash": partition_hash,
        "cohort_sizes": {},
        "contrast_intervals": [],
        "certified_claim_ids": [],
        "decision_count": _declared_decision_count(contract) if contract else 0,
        "decision_status": [],
        "risk_scope": "fixed-operator, per-request, sampling-only",
        "alpha": alpha,
        "semantic_sensitivity": [],
        "sampling_seed": seed,
        "sampled_record_ids": [],
        "illustrative_quotes": [],
        "charged_cost": {
            "semantic_calls": semantic_calls,
            "records_read": records_read,
            "budget_calls": budget_calls,
            "source": cost_source,
        },
    }
    if extra:
        out.update(extra)
    return out


def _declared_decision_count(contract: dict) -> int:
    """How many judgements the contract asked for, even when it is unsupported.

    Metrics code reads this on rejected requests so an unsupported bundle is
    still counted as one request with N unsettled judgements (scheme 8.3: an
    unresolved request stays in the denominator).
    """
    try:
        return len(normalize_decisions(contract))
    except Exception:
        return 0


def answer(
    contract: dict,
    snapshot,
    oracle: Oracle,
    alpha: float = 0.05,
    budget_calls: int = 1024,
    seed: int = 0,
    scheduler_strategy: SchedulerStrategy | None = None,
    snapshot_hash: str = "",
    query_contract_hash: str = "",
    partition_hash: str = "",
    model_and_prompt_hash: str = "",
    ledger=None,
    request_id: str | None = None,
    vault=None,
    texts: Mapping[str, str] | None = None,
    retry: RetryPolicy | None = None,
    explore_every: int = 4,
    allow_full_scan: bool = True,
    tiny_full_scan_max: int | None = TINY_FULL_SCAN_MAX,
    proxy_prior_kappa: int = 20,
    proxy_mixture_lambda: float = 0.5,
    keep_cancellations: bool = False,
    cost_model: str = "record",
    gamma: float = 1.0,
    epsilon_sched: float = EPS_SCHED,
    max_quotes: int = 3,
    trace: Callable[[dict], None] | None = None,
    cell_factory: Callable[[list, Any], list] | None = None,
    # §18 unsafe-diagnostic hook: swap the per-cell confidence sequence for an
    # alternative with the same interface (e.g. FixedTimeCS). Default keeps the
    # frozen CellCS; no validity-controlled path may pass anything here.
    cell_cs_factory: Callable | None = None,
    use_pilot: bool = True,
    proxy=None,
    render_text: bool = True,
    formal_seed: int | None = None,
) -> dict:
    """Run one certificate request end to end; returns the rendered object.

    On ``ContractUnsupported`` the contract is reported as ``unsupported`` rather
    than executed. On an oracle failure the request ends as ``execution_error``
    with whatever partial result is valid. An exhausted budget yields
    ``unresolved`` and stays in the metric denominator (scheme 8.3).
    """
    # The formal stream must not be the pilot stream. Auto-generated seeds are
    # fresh OS entropy; callers doing paired replay may supply and record an
    # independently generated 256-bit integer instead.
    if formal_seed is None:
        formal_seed = secrets.randbits(256)
        while formal_seed == seed:
            formal_seed = secrets.randbits(256)
    if not isinstance(formal_seed, int) or formal_seed < 0 or formal_seed == seed:
        raise ValueError("formal_seed must be a distinct nonnegative integer")
    strategy = scheduler_strategy or _make_default_strategy(
        gamma, epsilon_sched, cost_model=cost_model, texts=texts)
    reader = BudgetedOracle(
        oracle,
        budget_calls=budget_calls,
        ledger=ledger,
        request_id=request_id,
        vault=vault,
        retry=retry,
    )
    observed_labels: dict = {}
    sampled_record_ids: list = []
    # Labels that were computed after a hard failure: paid for, reported, and
    # deliberately *not* part of the sample (proposal 11).
    stashed_record_ids: list = []

    def _render(bounds, satisfied, reason: str = "", status_override: str = "") -> dict:
        t_render = time.perf_counter()
        cert = render_verified(
            contract, family, bounds, satisfied, alpha, seed, snapshot_hash,
            query_contract_hash, partition_hash, model_and_prompt_hash,
            sampled_record_ids=sampled_record_ids,
            semantic_sensitivity=(
                semantic_sensitivity(A, family, bounds, satisfied) if satisfied else []
            ),
            illustrative_quotes=illustrative_quotes(
                sampled_record_ids, observed_labels, texts, max_quotes=max_quotes
            ),
            bundle_complete=family.bundle_complete(satisfied),
            decision_status=family.per_decision_status(satisfied),
        )
        # 16.3 audit: surface the proxy degradation (if the pilot fit failed and
        # the run fell back to the deterministic stub) on the certificate
        cert["proxy_fit_failed"] = getattr(proxy, "fit_failed", "")
        errors = verify_certificate(cert, family=family, contract=contract)
        if render_text:
            # 10.5: the sentence is only a rendering of the object, and it is
            # checked by a deterministic checker before it ships. A rendering
            # that fails is dropped and reported -- the certificate object is
            # still returned, because a template bug must not destroy a valid
            # answer, but the unreviewed sentence is not published.
            text = render_answer_text(cert, contract)
            text_errors = verify_answer_text(text, cert, contract)
            if text_errors:
                cert["answer_text"] = ""
                cert["text_verify_errors"] = text_errors
            else:
                cert["answer_text"] = text
        if stashed_record_ids:
            # Transparency: these were paid for and thrown away on purpose.
            cert["stashed_record_ids"] = sorted(stashed_record_ids)
        if status_override:
            cert["status"] = status_override
            if reason:
                cert["reason"] = reason
        if errors and status_override not in ("unsupported",):
            cert["status"] = "execution_error"
            cert["verify_errors"] = errors
        # 14.1: rendering is one of the six chargeable phases; record it
        # before computing charged_cost so the cert carries it too.
        render_ms = (time.perf_counter() - t_render) * 1000.0
        if ledger is not None and request_id:
            ledger.record(
                "query", "render", wall_ms=render_ms, cpu_ms=render_ms,
                request_id=request_id, note=f"status={cert.get('status')}",
            )
        charged = (
            ledger.request_cost(request_id)
            if ledger is not None and request_id
            else {
                "semantic_calls": reader.spent,
                "records_read": len(observed_labels),
                "budget_calls": budget_calls,
                "source": "local_counter; no ledger attached",
            }
        )
        # request_cost nests the headline fields under "total"; flatten them to
        # the top level so every consumer reads the same shape. (Discovered in
        # the live-latency dry run: consumers read charged["semantic_calls"],
        # the nesting made it 0, and run_one's sampled-ids fallback masked the
        # mismatch for every vault-based run before this.) Shared helper: the
        # baselines' own render paths (olla/bargain) must emit the same shape.
        charged = flatten_charged_cost(charged)
        cert["charged_cost"] = charged
        cert["randomization"] = {"pilot_seed": str(seed), "formal_seed": str(formal_seed)}
        return cert

    def _unsupported(reason: str) -> dict:
        return unsupported_certificate(
            reason,
            contract=contract,
            alpha=alpha,
            seed=seed,
            snapshot_hash=snapshot_hash,
            query_contract_hash=query_contract_hash,
            partition_hash=partition_hash,
            model_and_prompt_hash=model_and_prompt_hash,
            semantic_calls=reader.spent,
            records_read=len(observed_labels),
            budget_calls=budget_calls,
            cost_source=(
                f"request={request_id}" if ledger is not None and request_id
                else "local_counter; no ledger attached"
            ),
        )

    # --- parse / compile (14.1 phase: parse) ------------------------------
    t0 = time.perf_counter()
    try:
        A, family = compile_signed_decisions(contract, snapshot,
                                             keep_cancellations)
    except ContractUnsupported as e:
        return _unsupported(e.reason)
    parse_ms = (time.perf_counter() - t0) * 1000.0
    if ledger is not None:
        # 23: the dev-set tuning parameters belong in the run record. A table
        # that cannot be traced back to the lambda / gamma / eps that produced
        # it is unreportable, whatever its numbers say.
        ledger.record(
            "query", "parse", wall_ms=parse_ms, cpu_ms=parse_ms, request_id=request_id,
            note=(
                f"gamma={gamma}; lambda={proxy_mixture_lambda}; "
                f"eps_sched={epsilon_sched}; explore_every={explore_every}; "
                f"kappa={proxy_prior_kappa}"
            ),
        )

    # §18 ablation: with keep_cancellations the zero-coefficient shared
    # records the compiler kept in the rows join the sampling population, so
    # the arm actually pays |cohort union| instead of |I_q| (6.2's baseline).
    active_ids = sorted(effective_support(A, keep_cancellations))
    if not active_ids:
        return _render(
            {}, [], reason="no active support: contrast is identically zero",
            status_override="unsupported",
        )

    # --- 6.3: decided by algebra alone, zero semantic calls ---------------
    structural = deterministic_bounds_already_decide(A, family)
    if structural is not None:
        bounds, satisfied = structural
        if trace is not None:
            trace(bounds)
        return _render(bounds, satisfied)

    # --- 7.1: only *tiny* requests are scanned exactly when budget allows ---
    # Above the threshold the request must go through pilot -> cells -> CS ->
    # scheduling; that path is the contribution under test, and an unbounded
    # exact shortcut would silently bypass it for most requests.
    # ``tiny_full_scan_max=None`` lifts the cap entirely: that is what
    # run_full_scan passes -- the exhaustive reference is DEFINED as reading
    # every record of I_q (proposal 16), so the tiny-request fairness gate
    # must not silently turn it back into a sampled run (17.2).
    if (
        allow_full_scan
        and (tiny_full_scan_max is None or len(active_ids) <= tiny_full_scan_max)
        and len(active_ids) <= reader.remaining
    ):
        try:
            labels = reader.read(active_ids, phase="oracle", caller="full_scan")
        except OracleFailure as exc:
            return _render({}, [], reason=str(exc), status_override="execution_error")
        observed_labels.update(labels)
        sampled_record_ids.extend(active_ids)
        bounds = exact_bounds_from_labels(A, family, labels)
        if trace is not None:
            trace(bounds)
        return _render(bounds, decide(family, bounds))

    # --- pilot ------------------------------------------------------------
    # Baselines may opt out of the pilot (scheme 16: Uniform-CS is the "no
    # pilot, allocation-only" competitor). Everything downstream is unchanged:
    # c_j is simply zero and the cells must carry the whole estimation burden.
    pilot_ids = fixed_uniform_pilot(active_ids, budget_calls, seed) if use_pilot else []
    try:
        pilot_labels = reader.read(pilot_ids, phase="pilot", caller="pilot")
    except OracleFailure as exc:
        return _render({}, [], reason=str(exc), status_override="execution_error")
    observed_labels.update(pilot_labels)
    sampled_record_ids.extend(pilot_ids)
    c_j = compute_pilot_contribution(A, pilot_ids, pilot_labels)

    # --- freeze cells + confidence sequences -------------------------------
    # Pseudo-code line 780: the proxy is *fitted on the pilot labels*, not
    # frozen before any evidence exists. A proxy that never sees a label can
    # still order records (that is all stratification needs), but a fitted one
    # is what makes the working prior and the strata worth anything. If fitting
    # fails -- no labels, no embeddings, a solver that will not converge -- the
    # request falls back to the deterministic stub rather than aborting: the
    # stratification degrades, the validity does not (scheme 7.4).
    t_proxy = time.perf_counter()
    proxy = _fit_proxy_or_fallback(proxy, pilot_ids, pilot_labels, seed)
    # 14.1: query-specific proxy training is *build* cost (7.1: "代理训练全部
    # 计费"), booked separately from the six query phases so it can never be
    # conflated with per-request spend.
    if ledger is not None and request_id:
        proxy_ms = (time.perf_counter() - t_proxy) * 1000.0
        ledger.record(
            "build", "proxy_train", wall_ms=proxy_ms, cpu_ms=proxy_ms,
            request_id=request_id,
            note=f"fit_failed={getattr(proxy, 'fit_failed', '')!r}",
        )
    pilot_set = set(pilot_ids)
    post_pilot = [i for i in active_ids if i not in pilot_set]
    if cell_factory is None:
        cells = freeze_coefficient_cells(post_pilot, A, proxy)
    else:
        # Stratification is a plug-in point: baselines differ in *how* they
        # stratify (scheme 16), never in the confidence-sequence kernel.
        cells = cell_factory(post_pilot, A)
    if not cells:
        bounds = exact_bounds_from_labels(A, family, pilot_labels)
        return _render(bounds, decide(family, bounds))
    risk_alloc = allocate_fixed_cell_risk(cells, alpha)
    # 7.3: the proxy component of the working prior is frozen from the unit's
    # mean proxy score, a_h = 1 + floor(kappa * pbar_h), b_h = 1 + kappa -
    # floor(kappa * pbar_h). The base Beta(1,1) component keeps positive
    # support regardless, so a badly wrong proxy costs efficiency, never
    # validity (7.4). Cells whose scores are unavailable fall back to Beta(1,1).
    cell_cs = {}
    for c in cells:
        a_h = b_h = 1.0
        try:
            scores = [float(proxy.score(i)) for i in c.records]
        except Exception:
            scores = []
        if scores:
            f = math.floor(proxy_prior_kappa * (sum(scores) / len(scores)))
            a_h, b_h = float(1 + f), float(1 + proxy_prior_kappa - f)
        # ``lambda`` is the weight of the proxy component in the working prior
        # (scheme 7.3, mixture weight frozen at 0.5 in section 23). lambda=0 is
        # the base-Beta(1,1)-only ablation (scheme 18): it costs efficiency,
        # never validity, and that is exactly what the ablation measures.
        cs_cls = cell_cs_factory or CellCS
        cell_cs[c.cell_id] = cs_cls(
            c.N, float(risk_alloc.get(c.cell_id, Fraction(0))),
            a=a_h, b=b_h, lam=proxy_mixture_lambda,
        )
    perms = independent_uniform_permutations(cells, formal_seed)
    # 17.3: every stochastic choice in the loop must derive from the request
    # seed, including the scheduler's exploration rounds, or the same
    # sampling_seed would not reproduce the same trajectory on replay.
    sched_rng = random.Random(f"{seed}:explore")
    read_cursor = {c.cell_id: 0 for c in cells}

    step = 0
    while reader.remaining > 0:
        contrast_bounds = pushforward_contrast_bounds(c_j, cells, cell_cs, family)
        if not check_consistency(contrast_bounds):
            return _render(
                contrast_bounds, [], reason="certificate_inconsistency",
                status_override="execution_error",
            )
        satisfied = decide(family, contrast_bounds)
        if trace is not None:
            # 17.3: validity is checked over the whole trajectory, not only at
            # the stopping time -- a sequence that dips outside the interval
            # mid-run and recovers is still a violation.
            trace(contrast_bounds)
        if family.bundle_complete(satisfied):
            break  # every declared judgement is settled

        step += 1
        t1 = time.perf_counter()
        explore = explore_every > 0 and step % explore_every == 0
        cell_id, batch = _call_strategy(
            strategy, cells, cell_cs, c_j, family, explore=explore, step=step,
            explore_rng=sched_rng,
        )
        schedule_ms = (time.perf_counter() - t1) * 1000.0
        if ledger is not None:
            ledger.record(
                "query", "schedule", wall_ms=schedule_ms, cpu_ms=schedule_ms,
                request_id=request_id, note=f"step={step}; explore={explore}",
            )
        if cell_id < 0 or batch <= 0:
            break  # every cell finished
        batch = min(batch, reader.remaining, cell_cs[cell_id].N - cell_cs[cell_id].n)
        if batch <= 0:
            break

        start = read_cursor[cell_id]
        ids = perms[cell_id][start: start + batch]
        labels, failure, stashed = reader.read_prefix(
            ids, phase="oracle", caller="scheduler"
        )
        committed = [i for i in ids if i in labels]
        if committed:
            observed_labels.update(labels)
            sampled_record_ids.extend(committed)
            cell_cs[cell_id].update([labels[i] for i in committed])
            read_cursor[cell_id] += len(committed)
        if stashed:
            stashed_record_ids.extend(sorted(stashed))
        if failure is not None:
            # Only the contiguous prefix was committed; the request stops with
            # that valid partial result rather than a certificate built on a
            # hole in the sample.
            return _render(
                pushforward_contrast_bounds(c_j, cells, cell_cs, family), [],
                reason=str(failure), status_override="execution_error",
            )

    t2 = time.perf_counter()
    # 7.3: an empty running intersection is sticky on the CellCS. If a cell
    # went inconsistent mid-run but the loop then exhausted that cell exactly
    # (or the budget died right there), the point bounds would otherwise look
    # resolvable again -- surface the inconsistency instead.
    if any(cs.inconsistent for cs in cell_cs.values()):
        contrast_bounds = pushforward_contrast_bounds(c_j, cells, cell_cs, family)
        return _render(
            contrast_bounds, [], reason="certificate_inconsistency",
            status_override="execution_error",
        )
    contrast_bounds = pushforward_contrast_bounds(c_j, cells, cell_cs, family)
    satisfied = decide(family, contrast_bounds) if check_consistency(contrast_bounds) else []
    certificate_ms = (time.perf_counter() - t2) * 1000.0
    if ledger is not None:
        ledger.record(
            "query", "certificate", wall_ms=certificate_ms, cpu_ms=certificate_ms,
            request_id=request_id, note=f"atoms={len(family.atoms)}",
        )
    return _render(contrast_bounds, satisfied)
