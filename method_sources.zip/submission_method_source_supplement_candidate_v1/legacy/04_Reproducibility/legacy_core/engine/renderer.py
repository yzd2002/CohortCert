"""Constrained surface generation and its deterministic checker (proposal 10.5).

The certificate object is the answer; the sentence is only a rendering of it.
Proposal 10.5 draws the line sharply:

    主实验的生成器输出"已认证差异、区间、范围限定、来源、未解决项"这些槽位。
    ... 最终由确定性检查器核验数值、单位、方向、群组名和来源 ID。

    **仅认证差值，就只报告差值。** 如果共享记录因抵消而未处理，不能顺手输出
    两个未经认证的群组绝对比例。

Two things live here, and they are deliberately separate:

``render_answer_text``
    Fills fixed slots from the certificate. It has no access to anything the
    certificate does not contain, so it cannot invent a number.

``verify_answer_text``
    Re-checks the sentence against the certificate and the contract: every
    quantity it states must be one the certificate actually bounds, every group
    it names must be a group the contract declared, the unit must be stated, the
    direction must match the interval, and every source id must be a record the
    operator really read.

The absolute-proportion rule is enforced as a hard check. A sentence like "the
share of group A complaints is 12%" is refused even when the numbers would be
convenient, because group A's absolute rate was never certified -- only the
*difference* was, and only after the shared records cancelled.
"""
from __future__ import annotations

import re
from fractions import Fraction
from typing import Mapping, Sequence

__all__ = ["render_answer_text", "verify_answer_text", "ALLOWED_UNITS"]

ALLOWED_UNITS = ("proportion_difference",)

_NUM_RE = re.compile(r"-?\d+(?:\.\d+)?")
_ABSOLUTE_CLAIM_RE = re.compile(
    r"(?:share|rate|proportion|percentage)\s+(?:of|for|in)\s+([^,.;]{1,80}?)"
    r"\s+(?:is|was|are|were|equals?|at)\s*(-?\d+(?:\.\d+)?)\s*%?",
    re.I,
)
_UNIT_WORDS = ("percentage points", "proportion difference")


def _pp(x) -> str:
    """Render an exact rational as percentage points without float noise."""
    try:
        v = float(Fraction(str(x)))
    except Exception:  # noqa: BLE001 - defensive formatting only
        return str(x)
    s = f"{v * 100:.4g}"
    return s


def _cohort_labels(contract: Mapping) -> dict:
    return {c["id"]: c.get("label", c["id"]) for c in contract.get("cohorts", [])}


def render_answer_text(cert: Mapping, contract: Mapping) -> str:
    """Render the certificate as constrained natural language.

    Only certified differences are stated as facts; everything else is stated as
    an interval or as unresolved. Nothing here can produce an absolute cohort
    proportion, because no absolute proportion is ever passed in.
    """
    labels = _cohort_labels(contract)
    decisions = contract.get("decisions")
    if decisions is None and "decision" in contract:
        decisions = [contract["decision"]]
    decisions = decisions or []
    status = cert.get("decision_status") or []
    intervals = {
        i["atom_index"]: i.get("interval") for i in cert.get("contrast_intervals", [])
    }

    lines: list[str] = []
    for di, d in enumerate(decisions):
        st = status[di] if di < len(status) else {}
        kind = d.get("type", "")
        if kind in ("compare", "direction"):
            left = labels.get(d.get("left"), d.get("left", "?"))
            right = labels.get(d.get("right"), d.get("right", "?"))
            thr = d.get("threshold", 0)
            if st.get("certified"):
                lines.append(
                    f"Certified: {left} exceeds {right} by more than "
                    f"{_pp(thr)} percentage points."
                )
            else:
                lines.append(
                    f"Not certified: whether {left} exceeds {right} by more than "
                    f"{_pp(thr)} percentage points could not be settled at this budget."
                )
        elif kind == "equivalence":
            left = labels.get(d.get("left"), d.get("left", "?"))
            right = labels.get(d.get("right"), d.get("right", "?"))
            tol = d.get("tolerance", 0)
            if st.get("certified"):
                lines.append(
                    f"Certified: {left} and {right} differ by less than "
                    f"{_pp(tol)} percentage points."
                )
            else:
                lines.append(
                    f"Not certified: whether {left} and {right} differ by less "
                    f"than {_pp(tol)} percentage points is unresolved."
                )
        elif kind in ("top1", "topk"):
            cands = [labels.get(c, c) for c in d.get("candidates", [])]
            if st.get("certified"):
                lines.append(
                    f"Certified: the highest group among {', '.join(cands)} is "
                    f"identified at risk alpha={cert.get('alpha')}."
                )
            else:
                lines.append(
                    f"Not certified: the highest group among {', '.join(cands)} "
                    f"could not be identified at this budget."
                )

    # Intervals are always reported -- an unresolved answer is still an answer.
    for item in cert.get("contrast_intervals", []):
        iv = item.get("interval")
        if iv is None:
            continue
        # The atom's internal label ("A - B > 1/2") is deliberately kept out of
        # the checked part of the line: it is a traceability string for the
        # certificate object, and its rational threshold would otherwise look
        # like an unreported quantity to the checker below.
        lines.append(
            f"Bound: [{_pp(iv[0])}, {_pp(iv[1])}] percentage points "
            f"(contrast {item.get('atom_index')})."
        )

    sens = cert.get("semantic_sensitivity") or []
    if sens:
        worst = min((s.get("tolerated_label_corrections", 0) for s in sens), default=0)
        lines.append(
            f"Semantic sensitivity: the claim survives at least {worst} arbitrary "
            f"label correction(s) by the fixed operator."
        )

    quotes = cert.get("illustrative_quotes") or []
    if quotes:
        ids = ", ".join(str(q.get("record_id")) for q in quotes)
        lines.append(f"Sources read by the operator: {ids}.")

    lines.append(
        f"Scope: {cert.get('risk_scope', '')}; alpha={cert.get('alpha')}; "
        f"unit=proportion_difference; "
        f"{len(status) - sum(1 for s in status if s.get('certified'))} of "
        f"{len(status)} declared judgement(s) unresolved."
    )
    return "\n".join(lines)


def verify_answer_text(
    text: str, cert: Mapping, contract: Mapping
) -> list[str]:
    """Deterministic checks on the rendered sentence; empty means publishable."""
    errors: list[str] = []
    if not text:
        return ["empty answer text"]

    labels = _cohort_labels(contract)
    known_names = set(labels.values()) | set(labels)

    # 1. absolute proportions must never be asserted
    for m in _ABSOLUTE_CLAIM_RE.finditer(text):
        errors.append(
            f"absolute proportion asserted for '{m.group(1).strip()}': "
            "only certified differences may be reported"
        )

    # 2. unit must be stated
    if not any(w in text.lower() for w in _UNIT_WORDS):
        errors.append("answer states numbers without declaring the unit")

    # 3. every number must be one the certificate actually bounds
    def _renderable(x) -> list[float]:
        """Every numeric form the renderer can emit for this quantity.

        The renderer formats percentages with ``{:.4g}`` (see ``_pp``), so a
        non-terminating endpoint such as 61/120 prints as 50.83 while the
        exact value is 50.8333... The checker must accept the *rendered*
        form, not only the exact one -- otherwise any sampled (non-point)
        interval fails its own checker while a full-scan point interval
        happens to pass, which is exactly the inconsistency the sampling
        path exposed on 2026-10-03.
        """
        try:
            exact = float(Fraction(str(x))) * 100.0
        except Exception:  # noqa: BLE001
            return []
        return [exact, float(f"{exact:.4g}")]

    allowed: list[float] = []
    for item in cert.get("contrast_intervals", []):
        iv = item.get("interval")
        if iv is None:
            continue
        for end in iv:
            allowed.extend(_renderable(end))
    decisions = contract.get("decisions") or (
        [contract["decision"]] if "decision" in contract else []
    )
    declared_units = {d.get("unit") for d in decisions if d.get("unit")}
    for u in declared_units:
        if u not in ALLOWED_UNITS:
            errors.append(f"decision unit '{u}' is not an allowed comparison unit")
    for d in decisions:
        for key in ("threshold", "tolerance"):
            if key in d:
                allowed.extend(_renderable(d[key]))
    alpha = cert.get("alpha")
    if alpha is not None:
        try:
            allowed.append(float(alpha))
        except Exception:  # noqa: BLE001
            pass

    # 3. every reported quantity must be one the certificate actually bounds.
    #    Only lines that state a quantity are checked: the scope line carries
    #    alpha and judgement counts, the sources line carries record ids that
    #    may contain digits, and the sensitivity line carries a count of label
    #    corrections. None of those are proportions, and treating them as such
    #    would produce false alarms that train people to ignore the checker.
    checked_lines = [
        ln for ln in text.splitlines()
        if "percentage points" in ln
        and not ln.startswith(("Scope:", "Sources", "Semantic sensitivity"))
    ]
    if not checked_lines and cert.get("contrast_intervals"):
        errors.append("answer states no interval despite having intervals to report")
    for line in checked_lines:
        # Anything after "(" is a traceability annotation (contrast index, atom
        # label), not a reported quantity.
        body = line.split("(", 1)[0]
        for m in _NUM_RE.finditer(body):
            try:
                v = float(m.group(0))
            except ValueError:
                continue
            if any(abs(v - a) < 1e-6 for a in allowed):
                continue
            errors.append(f"number {m.group(0)} is not backed by the certificate")

    # 4. the answer must name the groups of every declared judgement
    for di, d in enumerate(decisions):
        wanted = []
        for key in ("left", "right"):
            if d.get(key):
                wanted.append(labels.get(d[key], d[key]))
        for c in d.get("candidates", []):
            wanted.append(labels.get(c, c))
        for name in wanted:
            if name and name not in text:
                errors.append(
                    f"decision {di} concerns group '{name}' but the answer "
                    f"never names it"
                )

    # 5. sources must be records the operator actually read
    read = set(cert.get("sampled_record_ids") or [])
    for q in cert.get("illustrative_quotes") or []:
        rid = q.get("record_id")
        if rid is not None and rid not in read:
            errors.append(f"quote source {rid} was never read by the operator")

    return errors
