#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Signed contrast algebra over a frozen record population.

Implements 项目方案.md sections 6 and 7.5, plus the sensitivity certificate of
section 9.2.

Why exact rationals
-------------------
Cohort weights are 1/n_g, and a contrast coefficient is a difference of two such
weights. With floats, a pair of equal-size cohorts yields 1/n - 1/n == 0.0 only
by luck, and a coefficient that should be exactly zero silently becomes a tiny
nonzero number - which is precisely the cancellation the whole method depends on
(proposal section 6.1). Every coefficient here is therefore an exact Fraction.

A single sign error invalidates every certificate downstream, so
tests/test_signed_algebra.py checks the sign conventions exhaustively on small
instances.
"""

from __future__ import annotations

from fractions import Fraction
from typing import Iterable, Mapping, Sequence

__all__ = [
    "pairwise_contrast",
    "multi_contrast",
    "effective_support",
    "deterministic_bounds",
    "interval_pushforward",
    "perturbation_bound",
    "flip_tolerance",
    "is_certified_greater",
    "is_certified_less",
    "is_certified_equivalent",
]


def pairwise_contrast(cohort_a: Iterable[int], cohort_b: Iterable[int]) -> dict[int, Fraction]:
    """Signed coefficients a_i = 1/|A| * 1[i in A] - 1/|B| * 1[i in B].

    Records where the two weights cancel are dropped: their label cannot change
    the contrast at all, so the semantic operator need never be called on them.
    Note the caveat from proposal section 6.1 - an intersection only cancels when
    |A| == |B|; otherwise the coefficient is 1/|A| - 1/|B| != 0 and the shared
    records still matter (they just deserve lower priority).
    """
    a = list(cohort_a)
    b = list(cohort_b)
    if not a or not b:
        raise ValueError("empty cohort")
    wa, wb = Fraction(1, len(a)), Fraction(1, len(b))

    coef: dict[int, Fraction] = {}
    for i in a:
        coef[i] = coef.get(i, Fraction(0)) + wa
    for i in b:
        coef[i] = coef.get(i, Fraction(0)) - wb
    return {i: c for i, c in coef.items() if c != 0}


def multi_contrast(cohorts: Mapping[str, Iterable[int]], weights: Mapping[str, Fraction]):
    """Linear combination sum_g weight_g * indicator(g), as exact rationals."""
    coef: dict[int, Fraction] = {}
    for g, members in cohorts.items():
        members = list(members)  # materialize once: a generator would be
        # consumed by len() and the loop below would silently add nothing
        w = Fraction(weights[g]) * Fraction(1, len(members))
        for i in members:
            coef[i] = coef.get(i, Fraction(0)) + w
    return {i: c for i, c in coef.items() if c != 0}


def effective_support(contrasts: Sequence[Mapping[int, Fraction]]) -> set[int]:
    """I_q = records with a nonzero coefficient in at least one pending contrast."""
    out: set[int] = set()
    for c in contrasts:
        out.update(i for i, v in c.items() if v != 0)
    return out


def deterministic_bounds(
    contrast: Mapping[int, Fraction], observed: Mapping[int, int]
) -> tuple[Fraction, Fraction]:
    """Sharp bounds over every completion of the unobserved binary labels.

    proposal section 6.3. The lower bound assigns 1 to every unobserved record
    with a negative coefficient and 0 to the rest; the upper bound does the
    opposite. Both endpoints are attainable, so the interval is sharp.
    """
    known = Fraction(0)
    for i, y in observed.items():
        if i in contrast:
            known += contrast[i] * y

    lo = known
    hi = known
    for i, a in contrast.items():
        if i in observed:
            continue
        if a < 0:
            lo += a
        else:
            hi += a
    return lo, hi


def interval_pushforward(
    cell_coefficients: Mapping[int, Fraction],
    pilot_contribution: Fraction,
    cell_bounds: Mapping[int, tuple[int, int]],
) -> tuple[Fraction, Fraction]:
    """Propagate per-cell count intervals to a contrast interval.

    proposal section 7.5. For coefficient a and count interval [l, u]:
        lower uses a^+ * l + a^- * u
        upper uses a^+ * u + a^- * l
    i.e. the endpoints swap for negative coefficients. Getting this backwards is
    the single most dangerous bug in the whole system.
    """
    lo = Fraction(pilot_contribution)
    hi = Fraction(pilot_contribution)
    for h, a in cell_coefficients.items():
        if h not in cell_bounds:
            raise KeyError(f"cell {h} has no bound")
        l, u = cell_bounds[h]
        if u < l:
            raise ValueError(f"cell {h} has an empty interval ({l}, {u})")
        a_pos = a if a > 0 else Fraction(0)
        a_neg = a if a < 0 else Fraction(0)
        lo += a_pos * l + a_neg * u
        hi += a_pos * u + a_neg * l
    return lo, hi


def perturbation_bound(
    coefficients: Iterable[Fraction], r: int
) -> Fraction:
    """rho_j(r): the most any *r* arbitrary label corrections can move theta_j.

    proposal section 9.2. Sorting the magnitudes and taking the top ``r`` is
    conservative -- it ignores that a current 1 can only be corrected downwards
    and a current 0 only upwards -- so the reported tolerance is a lower bound
    on what the certificate really survives.
    """
    mags = sorted((abs(Fraction(a)) for a in coefficients), reverse=True)
    r = max(0, min(int(r), len(mags)))
    total = Fraction(0)
    for m in mags[:r]:
        total += m
    return total


def flip_tolerance(
    coefficients: Iterable[Fraction], lower: Fraction, threshold: Fraction
) -> int:
    """Largest r such that even r arbitrary label corrections cannot overturn it.

    proposal section 9.2: rho(r) is the sum of the r largest |a_i|, and the claim
    survives while rho(r) < L - b. This is a lower bound on tolerated flips, not
    the exact minimum flip distance - the bound ignores that each current label
    only permits one perturbation direction.
    """
    margin = Fraction(lower) - Fraction(threshold)
    if margin <= 0:
        return 0
    total = Fraction(0)
    r = 0
    for mag in sorted((abs(a) for a in coefficients), reverse=True):
        if total + mag < margin:
            total += mag
            r += 1
        else:
            break
    return r


def is_certified_greater(lower: Fraction, threshold: Fraction) -> bool:
    return lower > threshold


def is_certified_less(upper: Fraction, threshold: Fraction) -> bool:
    return upper < threshold


def is_certified_equivalent(
    lower: Fraction, upper: Fraction, epsilon: Fraction
) -> bool:
    """Interval entirely inside [-eps, +eps].

    Note: failing to prove a difference is NOT proof of equivalence; this only
    returns True when the interval is contained in the tolerance band.
    """
    return lower >= -epsilon and upper <= epsilon
