"""Session-level risk budgeting (proposal 7.6).

Proposal 7.6 makes a distinction that is easy to lose in a system that answers
many queries:

    单元同时覆盖后，不需要再对 J 个预声明对比额外分配 alpha/J。但是多个独立请求
    组成的一整个会话若也要求总体失败率不超过 alpha_session，就必须另行设置
    sum_q alpha_q <= alpha_session；不能把单请求保证直接当成无限会话保证。

Inside one request the contrasts are covered *simultaneously* by the same
sample, so they share the request's alpha. Across requests there is no such
luck: each request spends its own risk, and a hundred requests each at alpha =
0.05 do not together offer a 5% guarantee.

Two regimes are supported, because they need different arithmetic:

* **closed session** -- the number of requests is known. Split the budget
  (equally, or by weights). The sum is exactly alpha_session.
* **open session** -- requests keep arriving. There is no n to divide by, so the
  budget must be *summable*: request ``q`` receives
  ``alpha_session * 2**-(q+1)``, which telescopes to alpha_session over any
  number of requests. The price is that early requests get less, exactly as with
  the OLLA stage budgets -- and for the same reason.

Running out is a real outcome, not an error to swallow: ``take()`` refuses and
the caller must say "this session cannot answer another request at the declared
risk" rather than quietly answering at a worse risk.
"""
from __future__ import annotations

from dataclasses import dataclass, field

__all__ = ["SessionRiskBudget", "closed_session_plan", "open_session_alpha"]


def closed_session_plan(alpha_session: float, n_requests: int,
                        weights=None) -> list[float]:
    """Split ``alpha_session`` over a known number of requests.

    Equal by default; ``weights`` (same length) reallocates proportionally. The
    result always sums to ``alpha_session`` -- no silent rounding drift.
    """
    n = int(n_requests)
    if n <= 0:
        return []
    if weights is None:
        w = [1.0] * n
    else:
        w = [float(x) for x in weights]
        if len(w) != n:
            raise ValueError(f"weights length {len(w)} != n_requests {n}")
        if any(x < 0 for x in w):
            raise ValueError("weights must be non-negative")
        if sum(w) <= 0:
            w = [1.0] * n
    total = sum(w)
    out = [alpha_session * x / total for x in w]
    # Put any floating-point residue on the last request so the sum is exact.
    drift = float(alpha_session) - sum(out)
    out[-1] += drift
    return out


def open_session_alpha(alpha_session: float, index: int) -> float:
    """Budget for request ``index`` of an unbounded session: alpha * 2^-(i+1)."""
    i = int(index)
    if i < 0:
        raise ValueError("index must be >= 0")
    return float(alpha_session) * (2.0 ** -(i + 1))


@dataclass
class SessionRiskBudget:
    """A spendable risk budget for one session of requests.

    ``mode="closed"`` divides a known budget; ``mode="open"`` uses the summable
    geometric schedule so the session can be unbounded. In both cases
    :meth:`spent` plus what is left never exceeds ``alpha_session``.
    """

    alpha_session: float = 0.05
    mode: str = "closed"
    n_requests: int | None = None
    weights: tuple | None = None
    _issued: list = field(default_factory=list, repr=False)

    def __post_init__(self) -> None:
        if self.mode not in ("closed", "open"):
            raise ValueError(f"mode must be 'closed' or 'open', got {self.mode!r}")
        if self.mode == "closed" and self.n_requests is None:
            raise ValueError("closed sessions require n_requests")
        if self.mode == "closed" and self.n_requests is not None:
            self._planned = closed_session_plan(
                self.alpha_session, self.n_requests, self.weights
            )
        else:
            self._planned = None

    @property
    def spent(self) -> float:
        return sum(self._issued)

    @property
    def remaining(self) -> float:
        return max(0.0, float(self.alpha_session) - self.spent)

    @property
    def issued(self) -> list[float]:
        return list(self._issued)

    def take(self) -> float:
        """Allocate the next request's alpha, or raise when the budget is gone.

        Refusing is the honest outcome: answering anyway would mean answering at
        a risk the session never declared.
        """
        if self.mode == "closed":
            idx = len(self._issued)
            if self._planned is None or idx >= len(self._planned):
                raise RuntimeError(
                    f"closed session of {self.n_requests} request(s) is exhausted; "
                    "cannot answer another request at the declared session risk"
                )
            value = self._planned[idx]
        else:
            value = open_session_alpha(self.alpha_session, len(self._issued))
            if value > self.remaining:
                raise RuntimeError(
                    "open session budget exhausted; cannot answer another "
                    "request at the declared session risk"
                )
        self._issued.append(value)
        return value

    def valid(self) -> bool:
        """The invariant proposal 7.6 asks for: sum_q alpha_q <= alpha_session."""
        return self.spent <= float(self.alpha_session) + 1e-12
