"""Answer checker and constrained renderer (scheme 8.3 / 10.5).

Given the per-atom contrast intervals produced by the scheduler/confidence
sequences, this module decides whether the decision contract is *certified* and
renders the output certificate object. It never invents a semantic truth: the
output is bounded by the executed contract and the numeric certificate.

Stop-condition rules (scheme 8.3):
  * lower atom certified iff  L_j >  b_j   (strict)
  * upper atom certified iff  U_j <  b_j   (strict)
  * equivalence requires [L_j, U_j] ⊆ [-eps_j, eps_j]  (both atoms, strict)
  * a request that runs out of budget stays in the metric denominator as
    ``unresolved`` -- never silently dropped.
"""
from __future__ import annotations

from fractions import Fraction
from typing import Any


def decide(family, contrast_bounds: dict[int, tuple | None]):
    """Return the list of satisfied certificate indices, or [] if unresolved."""
    return family.check(contrast_bounds)


def is_complete(family, satisfied: list[int]) -> bool:
    """Whether the request is *completely* certified (scheme 17.1).

    A multi-judgement bundle is complete only when every declared comparison is
    settled; omitting the hardest one is counted as a failure, not as a partial
    success. For a single-decision contract this is ``bool(satisfied)``.
    """
    return family.bundle_complete(satisfied)


def render_verified(
    contract: dict,
    family,
    contrast_bounds: dict[int, tuple | None],
    satisfied: list[int],
    alpha: float,
    seed: int,
    snapshot_hash: str,
    query_contract_hash: str,
    partition_hash: str,
    model_and_prompt_hash: str = "",
    sampled_record_ids: list | None = None,
    semantic_sensitivity: list | None = None,
    charged_cost: dict | None = None,
    illustrative_quotes: list | None = None,
    bundle_complete: bool | None = None,
    decision_status: list | None = None,
) -> dict:
    """Build the output certificate object (scheme 10.5 schema)."""
    complete = bundle_complete if bundle_complete is not None else bool(satisfied)
    status = "certified" if complete else "unresolved"
    intervals = []
    for atom in family.atoms:
        bnd = contrast_bounds.get(atom.index)
        intervals.append(
            {
                "atom_index": atom.index,
                "label": atom.label,
                "kind": atom.kind,
                "threshold": str(atom.threshold),
                "interval": None if bnd is None else [str(bnd[0]), str(bnd[1])],
            }
        )
    return {
        "status": status,
        "snapshot_hash": snapshot_hash,
        "model_and_prompt_hash": model_and_prompt_hash,
        "query_contract_hash": query_contract_hash,
        "cohort_sizes": family.cohort_sizes,
        "contrast_intervals": intervals,
        "certified_claim_ids": satisfied,
        "decision_count": family.decision_count,
        "decision_status": decision_status
        if decision_status is not None
        else family.per_decision_status(satisfied),
        "risk_scope": "fixed-operator, per-request, sampling-only",
        "alpha": alpha,
        "semantic_sensitivity": semantic_sensitivity or [],
        "sampling_seed": seed,
        "partition_hash": partition_hash,
        "sampled_record_ids": sampled_record_ids or [],
        "illustrative_quotes": illustrative_quotes or [],
        "charged_cost": charged_cost or {},
    }


def check_consistency(contrast_bounds: dict[int, tuple | None]) -> bool:
    """False if any atom's interval is inconsistent (empty / None)."""
    for bnd in contrast_bounds.values():
        if bnd is None:
            return False
        if bnd[0] > bnd[1]:
            return False
    return True
