"""Execution-layer metrics (proposal 17.1).

The execution layer asks a narrow question: given the correct DSL and the
complete reference operator, does the certificate machinery report the right
answer within budget? Correctness is therefore computed from *exhaustive*
reference labels, never from the samples the algorithm happened to draw.

Definitions pinned here:

* **CCR(B)** -- complete certification rate: the request finished inside budget
  with every declared judgement certified *and* every claim true. A
  multi-judgement request that settles four of five judgements is not a success
  (17.1: omitting the hardest judgement does not count).
* **FCR** -- false certification rate: at least one certified claim is false.
  This is a per-request event, not an average over atoms (17.1 explicitly
  forbids the atom-average version).
* **conditional error rate** -- errors among *resolved* requests only, reported
  alongside CCR so a method cannot look good by refusing to answer.
* **unresolved / execution error** -- both stay in the denominator.

Nothing here drops a request because it is inconvenient: every query that
started is counted.
"""
from __future__ import annotations

from fractions import Fraction
from typing import Any, Mapping, Sequence

__all__ = [
    "OUTCOMES",
    "reference_bounds",
    "reference_certificates",
    "classify",
    "summarise",
    "budget_curve",
]

#: Every request ends in exactly one of these.
OUTCOMES = (
    "correct_certified",    # complete and every claim true
    "false_certification",  # certified at least one false claim
    "incomplete",           # published as certified but a judgement was missing
    "correct_refusal",      # said nothing, and nothing could be certified
    "unresolved",           # budget exhausted while a certificate was available
    "execution_error",      # operator failure, inconsistent intervals, verifier
    "unsupported",          # contract rejected before execution
)

_RESOLVED = ("correct_certified", "false_certification", "incomplete")
_ERRORS = ("execution_error", "unsupported")


def reference_bounds(A, family, labels: Mapping[str, int]) -> dict:
    """Exact per-atom contrast values under the complete reference operator.

    The reference is a full scan, so every interval is a point. This is the
    "zero numerical error" baseline of proposal 17.2.

    A record with a nonzero coefficient but no reference label is a **broken
    input** (the vault would have refused it as "absent from the vault"),
    never a silent 0: treating it as 0 would corrupt the reference truth
    itself while every CCR/FCR computed from it still looks plausible.
    """
    out: dict[int, tuple[Fraction, Fraction]] = {}
    for atom in family.atoms:
        theta = Fraction(0)
        for i, coef in A.rows[atom.row_index].items():
            if i not in labels:
                raise KeyError(
                    f"reference label missing for record {i!r} (atom "
                    f"{atom.index}); the reference must cover every record "
                    "with a nonzero coefficient -- refusing to count it as 0"
                )
            if labels[i]:
                theta += coef
        out[atom.index] = (theta, theta)
    return out


def reference_certificates(A, family, labels: Mapping[str, int]) -> set:
    """Certificates that are *actually* satisfied by the reference operator."""
    return set(family.check(reference_bounds(A, family, labels)))


def reference_certifiable(A, family, labels: Mapping[str, int]) -> bool:
    """Can this request be certified at all under the reference operator?

    A request whose declared family admits no satisfying certificate bundle
    cannot be answered "yes" by *any* honest keystone -- refusing is the
    correct answer, and scoring that refusal as a failure would cap CCR at the
    share of well-posed queries no matter how good the sampler is. (On cfpb
    dev, 5 of the first 8 queries are of this kind, which is why every method
    reported CCR = 0 even with a full scan.)

    This is deliberately computed from labels *only at evaluation time*: the
    executing pipeline never sees it.
    """
    if family is None or A is None:
        return False
    return family.bundle_complete(sorted(reference_certificates(A, family, labels)))


def classify(cert: Mapping[str, Any], A, family, labels: Mapping[str, int]) -> dict:
    """Judge one rendered certificate against the reference operator.

    Returns ``{outcome, wrong_claims, complete, decisions_certified,
    decisions_total, certifiable}``. ``wrong_claims`` lists certified claims
    that the reference does not support -- a non-empty list is a correctness
    failure even if the rest of the answer is right.

    ``certifiable`` says whether the reference admits a complete certificate
    for this request at all. It separates two things that used to collapse
    into one label: when nothing can be certified, staying silent is the right
    answer (``correct_refusal``); when something *could* have been certified,
    staying silent is a genuine miss (``unresolved``). Both keep their place in
    the denominator -- neither is dropped from any table.
    """
    status = cert.get("status", "")
    total = family.decision_count if family is not None else 0
    certifiable = reference_certifiable(A, family, labels)
    base = {"wrong_claims": [], "decisions_certified": 0, "decisions_total": total,
            "certifiable": certifiable}

    if status == "unsupported":
        return {**base, "outcome": "unsupported", "complete": False}
    if status == "execution_error":
        return {**base, "outcome": "execution_error", "complete": False}
    if family is None or A is None:
        return {**base, "outcome": "execution_error", "complete": False}

    claimed = list(cert.get("certified_claim_ids") or [])
    ref = reference_certificates(A, family, labels)
    wrong = [c for c in claimed if c not in ref]

    complete = family.bundle_complete(claimed)
    settled = {
        family.certificate_decisions[c] for c in claimed if c in ref
    }
    # A false certification is the worse event (FCR is per-request "at least
    # one wrong claim"), so it must not be masked by the milder "incomplete"
    # label when both hold -- wrong takes priority over incomplete.
    if wrong:
        return {
            **base,
            "outcome": "false_certification",
            "wrong_claims": wrong,
            "complete": complete,
            "decisions_certified": len(settled),
        }
    if status == "certified" and not complete:
        # Renderer claimed completeness the claims do not support.
        return {
            **base,
            "outcome": "incomplete",
            "wrong_claims": wrong,
            "complete": False,
            "decisions_certified": len(settled),
        }
    if status == "certified":
        return {
            **base,
            "outcome": "correct_certified",
            "complete": True,
            "decisions_certified": len(settled),
        }
    # Nothing was certified and nothing false was published. Whether that is a
    # hit or a miss depends entirely on what was achievable: having no
    # certificate available makes silence correct, having one available makes
    # silence a failure to find it.
    if not certifiable:
        return {
            **base,
            "outcome": "correct_refusal",
            "complete": False,
            "decisions_certified": len(settled),
        }
    return {
        **base,
        "outcome": "unresolved",
        "complete": False,
        "decisions_certified": len(settled),
    }


def _rate(numerator: int, denominator: int) -> float:
    return numerator / denominator if denominator else 0.0


def summarise(records: Sequence[Mapping[str, Any]]) -> dict:
    """Aggregate per-request records into the proposal's headline metrics."""
    n = len(records)
    counts = {o: 0 for o in OUTCOMES}
    for r in records:
        counts[r.get("outcome", "unresolved")] = counts.get(r.get("outcome", "unresolved"), 0) + 1

    resolved = sum(counts[o] for o in _RESOLVED)
    false_requests = sum(
        1 for r in records if r.get("wrong_claims")
    )
    errors = sum(counts[o] for o in _ERRORS)

    def pct(values: Sequence[float], q: float) -> float:
        if not values:
            return 0.0
        s = sorted(values)
        idx = min(len(s) - 1, max(0, int(round(q * (len(s) - 1)))))
        return float(s[idx])

    calls = [float(r.get("semantic_calls", 0) or 0) for r in records]
    latency = [float(r.get("wall_ms", 0) or 0) for r in records]
    # Requests the reference says cannot be certified at all. For those the
    # ideal answer is silence, so leaving them in a coverage numerator would
    # cap CCR at the share of well-posed queries. They are reported separately,
    # never dropped: a method that certifies one is a false certification.
    unanswerable = [r for r in records if r.get("certifiable") is False]
    answerable = [r for r in records if r.get("certifiable") is not False]
    n_answerable = len(answerable)
    refused_correctly = sum(
        1 for r in unanswerable if r.get("outcome") == "correct_refusal"
    )
    fabricated = sum(
        1 for r in unanswerable if r.get("outcome") == "false_certification"
    )

    return {
        "requests": n,
        "ccr": _rate(counts["correct_certified"], n),
        "fcr": _rate(false_requests, n),
        "resolved_rate": _rate(resolved, n),
        "unresolved_rate": _rate(counts["unresolved"], n),
        "execution_error_rate": _rate(errors, n),
        "conditional_error_rate": _rate(false_requests, resolved),
        "incomplete_rate": _rate(counts["incomplete"], n),
        # well-posed subset: what the coverage curve is actually measuring
        "certifiable_requests": n_answerable,
        "certifiable_rate": _rate(n_answerable, n),
        "ccr_on_certifiable": _rate(
            sum(1 for r in answerable if r.get("outcome") == "correct_certified"),
            n_answerable,
        ),
        "unresolved_on_certifiable": _rate(
            sum(1 for r in answerable if r.get("outcome") == "unresolved"),
            n_answerable,
        ),
        # ill-posed subset: refusing is right, fabricating is not
        "unanswerable_requests": len(unanswerable),
        "refusal_accuracy": _rate(refused_correctly, len(unanswerable)),
        "fabrication_rate": _rate(fabricated, len(unanswerable)),
        "counts": dict(counts),
        "semantic_calls_mean": (sum(calls) / len(calls)) if calls else 0.0,
        "semantic_calls_p50": pct(calls, 0.50),
        "semantic_calls_p95": pct(calls, 0.95),
        "wall_ms_p50": pct(latency, 0.50),
        "wall_ms_p95": pct(latency, 0.95),
    }


def budget_curve(records: Sequence[Mapping[str, Any]],
                 key: str = "budget") -> list:
    """CCR as a function of budget -- the main plot of proposal 17.2.

    Unresolved requests are budget-censored observations and stay in the
    denominator at every budget, so the curve cannot be inflated by quietly
    dropping the hard queries.

    ``key`` lets the x-axis be the *share* of the effective support rather than
    an absolute call count. That matters on the real snapshots: supports range
    from 565 to 3293 records, so "256 calls" is 45% of one request and 8% of
    another, and an absolute-budget curve averages over incomparable workloads.
    A share-relative curve asks the same question of every request.
    """
    by_budget: dict[float, list] = {}
    for r in records:
        value = r.get(key, r.get("budget", 0))
        try:
            b = float(value)
        except (TypeError, ValueError):
            b = float(r.get("budget", 0))
        by_budget.setdefault(b, []).append(r)
    out = []
    for budget in sorted(by_budget):
        part = by_budget[budget]
        s = summarise(part)
        row = {
            key: budget,
            "requests": len(part),
            "ccr": s["ccr"],
            "fcr": s["fcr"],
            "unresolved_rate": s["unresolved_rate"],
            "semantic_calls_mean": s["semantic_calls_mean"],
        }
        if key != "budget":
            # absolute budgets differ per request in share mode; keep a mean so
            # the cost axis stays interpretable
            row["budget_abs_mean"] = float(
                sum(float(r.get("budget", 0) or 0) for r in part) / len(part)
            )
        out.append(row)
    return out
