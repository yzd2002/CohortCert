"""Budget-coverage plots (proposal 17.2).

The main figure is CCR against budget. Unresolved requests are censored
observations and stay in the denominator at every budget, so the curve reflects
what the method delivers rather than what it delivers on easy queries.

The secondary panel reports the false-certification rate: a coverage curve
alone cannot distinguish a careful method from a reckless one.
"""
from __future__ import annotations

import csv
from pathlib import Path

from evaluation.metrics import budget_curve

__all__ = ["write_curve_csv", "plot_budget_curve"]


def write_curve_csv(path: str | Path, records) -> Path:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    rows = budget_curve(records)
    with p.open("w", encoding="utf-8", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=["budget", "requests", "ccr", "fcr",
                                           "unresolved_rate", "semantic_calls_mean"])
        w.writeheader()
        for r in rows:
            w.writerow(r)
    return p


def plot_budget_curve(path: str | Path, series: dict, title: str = "Budget vs CCR",
                      xlabel: str = "semantic-call budget B",
                      key: str = "budget") -> Path:
    """Plot one curve per method.

    ``series`` maps method name -> list of curve rows (from
    :func:`evaluation.metrics.budget_curve`). ``key`` is the x-axis field, so
    the same figure serves both the absolute-budget and the support-share view
    of the same records. Returns the figure path.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)

    fig, axes = plt.subplots(1, 2, figsize=(11, 4.2))
    for name, rows in series.items():
        xs = [r[key] for r in rows]
        axes[0].plot(xs, [r["ccr"] for r in rows], marker="o", label=name)
        axes[1].plot(xs, [r["fcr"] for r in rows], marker="s", label=name)

    axes[0].set_xlabel(xlabel)
    axes[0].set_ylabel("CCR(B)")
    axes[0].set_ylim(0.0, 1.0)
    axes[0].set_title("Complete certification coverage")
    axes[0].grid(alpha=0.3)
    axes[0].legend()

    axes[1].set_xlabel(xlabel)
    axes[1].set_ylabel("FCR")
    axes[1].set_ylim(0.0, 1.0)
    axes[1].set_title("False certification rate")
    axes[1].grid(alpha=0.3)
    axes[1].legend()

    fig.suptitle(title)
    fig.tight_layout()
    fig.savefig(p, dpi=150)
    plt.close(fig)
    return p
