"""Paired comparison statistics with query-clustered bootstrap (proposal 17.3).

The verdict numbers (dev/test grid, 10-seed reinforcement) all rest on this:
a paired difference of call counts between two methods over the SAME
(request, budget) cells, with the 95% interval from resampling *queries* --
not rows. Resampling rows would treat a query's several seeds as independent
evidence and overstate the effective sample size; the cluster bootstrap moves
all observations of a query together.

Point estimates are exact means over the paired observations; only the
interval is simulated, from a seeded RNG so every run of the analysis is
reproducible.
"""
from __future__ import annotations

import random
from collections import defaultdict
from statistics import fmean

__all__ = ["relative_saving", "paired_saving", "cluster_bootstrap_ci"]


def relative_saving(baseline_calls: float, method_calls: float) -> float:
    """Share of baseline calls the method saves: (B - M) / B."""
    if baseline_calls <= 0:
        raise ValueError("baseline_calls must be positive")
    return (baseline_calls - method_calls) / baseline_calls


def paired_saving(pairs: list[tuple[float, float]]) -> float:
    """Mean relative saving over matched pairs of (baseline, method) calls."""
    if not pairs:
        return 0.0
    return fmean(relative_saving(b, m) for b, m in pairs)


def cluster_bootstrap_ci(
    records: list[dict],
    value_of,
    cluster_key,
    n_boot: int = 10_000,
    ci_level: float = 0.95,
    seed: int = 0,
) -> dict:
    """Percentile CI for ``mean(value_of(record))`` with cluster resampling.

    ``records`` are arbitrary rows; ``cluster_key(record)`` groups rows that
    are NOT independent (one query's seeds, one entity's queries). Each
    bootstrap replicate resamples clusters with replacement, pools their rows
    and recomputes the mean. Rows with ``value_of`` None are excluded (e.g.
    unmatched pairs) -- excluded uniformly, before resampling, so they cannot
    bias the interval.
    """
    values_by_cluster: dict = defaultdict(list)
    for r in records:
        v = value_of(r)
        if v is None:
            continue
        values_by_cluster[cluster_key(r)].append(v)
    clusters = list(values_by_cluster.values())
    if not clusters:
        return {"mean": 0.0, "lo": 0.0, "hi": 0.0, "n_clusters": 0, "n_values": 0}

    flat = [v for c in clusters for v in c]
    point = fmean(flat)
    rng = random.Random(seed)
    stats: list[float] = []
    for _ in range(n_boot):
        drawn = [rng.choice(clusters) for _ in range(len(clusters))]
        stats.append(fmean([v for c in drawn for v in c]))
    stats.sort()
    alpha = (1.0 - ci_level) / 2.0
    lo_idx = int(alpha * len(stats))
    hi_idx = int((1.0 - alpha) * len(stats)) - 1
    return {
        "mean": point,
        "lo": stats[max(lo_idx, 0)],
        "hi": stats[min(hi_idx, len(stats) - 1)],
        "n_clusters": len(clusters),
        "n_values": len(flat),
    }
