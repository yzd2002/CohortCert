"""Run a query workload across budgets and seeds (proposal 17.2 / 17.3).

Two properties matter more than convenience here:

* **The reference operator is sealed.** Reference labels live behind a
  read-only vault (proposal 14). The algorithm submits explicit record ids;
  the harness never hands it the label dictionary, and every read is charged.
  Labels are used *afterwards* only to judge the answer.
* **Nothing is dropped.** Unsupported contracts, operator failures and
  budget-exhausted requests all produce a record and all remain in the
  denominator. Reporting accuracy on the subset that succeeded is the bias
  proposal 17.1 warns about.

Latency is measured honestly: wall time includes parsing, scheduling and
rendering, not just the semantic calls.
"""
from __future__ import annotations

import csv
import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from engine.pipeline import answer
from query.compiler import compile_signed_decisions
from query.contract_schema import ContractUnsupported
from evaluation.metrics import classify, summarise, budget_curve

__all__ = ["VaultOracle", "DEFAULT_BUDGETS", "run_one", "run_workload", "write_records"]

DEFAULT_BUDGETS = (64, 128, 256, 512, 1024)


class VaultOracle:
    """Adapt the sealed reference vault to the pipeline's oracle interface.

    The pipeline only ever calls ``read(ids)``; it cannot enumerate the vault
    and it cannot read a label it did not ask for.
    """

    def __init__(self, vault, caller: str = "pipeline", replay: bool = False):
        self.vault = vault
        self.caller = caller
        self.replay = replay

    def read(self, record_ids):
        return self.vault.get(record_ids, caller=self.caller, replay=self.replay)


@dataclass
class RunPlan:
    budgets: tuple = DEFAULT_BUDGETS
    seeds: tuple = (0,)
    alpha: float = 0.05
    replay: bool = False
    #: Optional session-level cap (proposal 7.6). ``None`` means every request
    #: is answered at ``alpha`` and the guarantee is per-request -- which is
    #: what must be reported. Setting it switches the whole run to a shared
    #: budget whose per-request alphas sum to at most ``alpha_session``.
    alpha_session: float | None = None


def run_one(
    spec,
    snapshot,
    oracle,
    reference_labels: Mapping[str, int],
    budget: int,
    seed: int,
    alpha: float = 0.05,
    texts: Mapping[str, str] | None = None,
    ledger=None,
    scheduler_strategy: Callable | None = None,
    method: str | None = None,
    keep_cancellations: bool = False,
    cost_model: str = "record",
    **answer_kwargs,
) -> dict:
    """Run one query once and judge the result against the reference operator.

    ``method`` routes the run through ``registry.run_method`` (proposal 16.3:
    every method gets the same contract, snapshot, oracle, alpha, budget,
    renderer and verifier; only the scheduling/stratification plug-ins
    differ). With ``method=None`` the default CohortCert pipeline runs
    directly -- the two paths must produce the same certificate shape, which
    is what ``classify`` below relies on.

    ``keep_cancellations`` / ``cost_model`` are the §18 ablation switches
    (no signed cancellation / heterogeneous record cost). They only reach
    methods that route through ``pipeline.answer``; when left at their
    defaults they are not forwarded at all, so diagnostics methods keep
    working unchanged.
    """
    try:
        A, family = compile_signed_decisions(spec.contract, snapshot,
                                             keep_cancellations)
    except ContractUnsupported:
        A, family = None, None

    t0 = time.perf_counter()
    # The method name belongs IN the request id. ``ledger.request_cost`` sums
    # every event carrying this id, so a sweep that runs several methods in one
    # process would otherwise charge each request the running total of all
    # previously run methods on the same (query, budget, seed) -- see
    # test_request_cost_is_per_method_not_cumulative. The bug lay dormant
    # while charged_cost lacked the top-level field: the sampled-ids fallback
    # below hid it, and the 10.1 flatten is what exposed it.
    request_id = f"{spec.query_id}:M{method or 'cohortcert'}:B{budget}:S{seed}"
    ablation_kw = {}
    if keep_cancellations:
        ablation_kw["keep_cancellations"] = True
    if cost_model != "record":
        ablation_kw["cost_model"] = cost_model
    try:
        if method is not None:
            from engine.baselines.registry import run_method

            cert = run_method(
                method,
                spec.contract,
                snapshot,
                oracle,
                alpha=alpha,
                budget_calls=budget,
                seed=seed,
                texts=texts,
                ledger=ledger,
                request_id=request_id,
                **ablation_kw,
                **answer_kwargs,
            )
        else:
            cert = answer(
                spec.contract,
                snapshot,
                oracle,
                alpha=alpha,
                budget_calls=budget,
                seed=seed,
                texts=texts,
                ledger=ledger,
                request_id=request_id,
                scheduler_strategy=scheduler_strategy,
                **ablation_kw,
                **answer_kwargs,
            )
    except Exception as exc:  # noqa: BLE001 - one bad query must not kill the sweep
        # The pipeline converts its own failures into execution_error
        # certificates; an exception escaping it means a bug in the method
        # code itself. Record it per request (stays in the denominator) and
        # keep the sweep running -- dropping it would bias the metrics.
        cert = {
            "status": "execution_error",
            "reason": f"harness caught {type(exc).__name__}: {exc}",
            "certified_claim_ids": [],
            "charged_cost": {"semantic_calls": 0, "records_read": 0},
        }
    wall_ms = (time.perf_counter() - t0) * 1000.0

    try:
        verdict = classify(cert, A, family, reference_labels)
    except KeyError as exc:
        # Broken evaluation input (e.g. reference labels do not cover the
        # support) is a harness failure, not a method failure -- but it must
        # be recorded per request, never crash the whole sweep silently.
        verdict = {
            "outcome": "execution_error",
            "complete": False,
            "wrong_claims": [],
            "certifiable": False,
            "decisions_certified": 0,
            "decisions_total": family.decision_count if family is not None else 0,
        }
        cert.setdefault("verify_errors", []).append(f"reference incomplete: {exc}")
    charged = cert.get("charged_cost") or {}
    calls = charged.get("semantic_calls", len(cert.get("sampled_record_ids") or []))
    # The budget is a hard constraint and it is the *same* constraint for every
    # method (16.3 / 5.4). The materialisation baseline sets its own budget to
    # the full support, so at a 25%-of-support budget point it would otherwise
    # be credited with a certification it demonstrably could not afford there
    # -- a free win over the samplers. Publishing something false stays the
    # worse event; only an otherwise-clean success is demoted.
    over_budget = float(calls or 0) > float(budget)
    if over_budget and verdict["outcome"] == "correct_certified":
        verdict = {**verdict, "outcome": "unresolved"}
    return {
        "query_id": spec.query_id,
        "dataset": spec.dataset,
        "split": spec.split,
        "kind": spec.kind,
        "family": spec.family,
        "predicate_id": spec.predicate_id,
        "budget": budget,
        "seed": seed,
        "formal_seed": (cert.get("randomization") or {}).get("formal_seed", ""),
        "alpha": alpha,
        "validity": cert.get("validity", ""),
        "status": cert.get("status", ""),
        "reason": cert.get("reason", ""),
        "proxy_fit_failed": cert.get("proxy_fit_failed", ""),
        "outcome": verdict["outcome"],
        "over_budget": over_budget,
        "complete": verdict["complete"],
        "wrong_claims": verdict["wrong_claims"],
        # False when the reference admits no complete certificate for this
        # request, so refusing is the right answer rather than a miss.
        "certifiable": verdict.get("certifiable", True),
        "decisions_certified": verdict["decisions_certified"],
        "decisions_total": verdict["decisions_total"],
        "semantic_calls": calls,
        "records_read": charged.get("records_read", len(cert.get("sampled_record_ids") or [])),
        "wall_ms": wall_ms,
        "verify_errors": cert.get("verify_errors", []),
    }


def run_workload(
    specs: Sequence,
    snapshots: Mapping[str, Any],
    vault_factory: Callable[[str], Any],
    reference_labels: Mapping[str, Mapping[str, int]],
    plan: RunPlan | None = None,
    texts: Mapping[str, Mapping[str, str]] | None = None,
    scheduler_strategy: Callable | None = None,
    progress: Callable[[int, int], None] | None = None,
) -> list:
    """Run every (query, budget, seed) combination in the plan."""
    plan = plan or RunPlan()
    records: list = []
    total = len(specs) * len(plan.budgets) * len(plan.seeds)
    # 7.6: a session guarantee is a *different* claim from a per-request one.
    # When alpha_session is set the per-request alphas are drawn from the shared
    # budget instead of all being plan.alpha.
    session = None
    if plan.alpha_session is not None:
        from engine.session import SessionRiskBudget

        session = SessionRiskBudget(
            alpha_session=float(plan.alpha_session),
            mode="closed", n_requests=max(total, 1),
        )
    done = 0
    for spec in specs:
        snapshot = snapshots[spec.dataset]
        labels = reference_labels[spec.dataset]
        for budget in plan.budgets:
            for seed in plan.seeds:
                oracle = VaultOracle(
                    vault_factory(spec.dataset), caller="pipeline", replay=plan.replay
                )
                alpha = session.take() if session is not None else plan.alpha
                records.append(
                    run_one(
                        spec, snapshot, oracle, labels, budget, seed,
                        alpha=alpha,
                        texts=(texts or {}).get(spec.dataset),
                        scheduler_strategy=scheduler_strategy,
                    )
                )
                done += 1
                if progress is not None:
                    progress(done, total)
    return records


def write_records(path: str | Path, records: Sequence[Mapping[str, Any]]) -> Path:
    """Write per-request records as CSV (one row per run)."""
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    if not records:
        p.write_text("", encoding="utf-8")
        return p
    fields = list(records[0].keys())
    with p.open("w", encoding="utf-8", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=fields)
        w.writeheader()
        for r in records:
            row = dict(r)
            row["wrong_claims"] = json.dumps(row.get("wrong_claims", []))
            row["verify_errors"] = json.dumps(row.get("verify_errors", []))
            w.writerow(row)
    return p


def write_summary(path: str | Path, records: Sequence[Mapping[str, Any]],
                  budget_key: str = "budget") -> dict:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    # Session-mode splits alpha_session across budgets, so rows at different
    # budgets carry different alphas. Disclose the mapping instead of letting
    # a single number imply one uniform risk level (17.1).
    alpha_by_budget: dict[str, float | None] = {}
    for r in records:
        b = str(r.get(budget_key, r.get("budget")))
        if b not in alpha_by_budget or alpha_by_budget[b] is None:
            alpha_by_budget[b] = r.get("alpha")
    summary = {
        "overall": summarise(records),
        "budget_axis": budget_key,
        "by_budget": budget_curve(records, key=budget_key),
        # numeric ordering: string sort would put "100" between "10" and "25"
        "alpha_by_budget": {
            k: alpha_by_budget[k]
            for k in sorted(alpha_by_budget, key=lambda x: float(x))
        },
        "by_kind": {},
        "by_dataset": {},
    }
    for key, fieldname in (("by_kind", "kind"), ("by_dataset", "dataset")):
        groups: dict[str, list] = {}
        for r in records:
            groups.setdefault(r.get(fieldname, ""), []).append(r)
        summary[key] = {k: summarise(v) for k, v in sorted(groups.items())}
    p.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    return summary
