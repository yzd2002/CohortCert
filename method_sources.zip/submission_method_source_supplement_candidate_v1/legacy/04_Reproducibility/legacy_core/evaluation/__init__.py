"""Evaluation scaffold for the metrics of proposal 17.

Layout
------
metrics.py   per-request judging and aggregation
harness.py   run a workload across budgets and seeds (this file)
replay.py    fixed-oracle multi-seed trajectory checks
plots.py     budget-coverage curves
"""
