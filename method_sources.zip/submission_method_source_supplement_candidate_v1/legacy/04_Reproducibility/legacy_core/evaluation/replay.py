"""Fixed-oracle replay: validity over the whole trajectory (proposal 17.3).

A confidence sequence promises that the true value stays inside the reported
interval at *every* step, not only at the moment the algorithm chose to stop.
Checking just the final interval would miss the realistic failure mode: a
trajectory that dips outside mid-run and happens to recover by the stopping
time. The pipeline exposes a ``trace`` callback for exactly this reason, and
this module turns it into a violation count.

Repeated seeds only measure sampling variation for a *fixed* oracle. They are
not 200 independent business datasets, and the module says so in its output.
"""
from __future__ import annotations

from typing import Any, Callable, Mapping, Sequence

from engine.pipeline import answer
from query.compiler import compile_signed_decisions
from query.contract_schema import ContractUnsupported
from evaluation.metrics import classify, reference_bounds, summarise

__all__ = ["run_trajectory", "replay_seeds", "summarise_replay"]


def run_trajectory(
    spec,
    snapshot,
    oracle,
    reference_labels: Mapping[str, int],
    budget: int,
    seed: int,
    alpha: float = 0.05,
    scheduler_strategy: Callable | None = None,
    proxy=None,
    formal_seed: int | None = None,
) -> dict:
    """Run one (query, seed) and count trajectory coverage violations.

    Validity under replay is proxy-independent (7.4: the mixture prior keeps
    the guarantee for any stratifier); the proxy only changes efficiency, so
    passing the frozen main-config proxy here replicates the deployed
    configuration while the stub remains the worst-case stratifier.
    """
    try:
        A, family = compile_signed_decisions(spec.contract, snapshot)
    except ContractUnsupported:
        A, family = None, None

    truth: dict = {}
    if A is not None:
        truth = reference_bounds(A, family, reference_labels)

    violations: list = []
    steps = 0

    def trace(bounds: dict) -> None:
        nonlocal steps
        steps += 1
        for aid, bnd in bounds.items():
            if bnd is None:
                violations.append({"step": steps, "atom": aid, "reason": "no_interval"})
                continue
            lo, hi = bnd
            true_value = truth.get(aid, (None, None))[0]
            if true_value is None:
                continue
            if true_value < lo or true_value > hi:
                violations.append(
                    {
                        "step": steps,
                        "atom": aid,
                        "true": str(true_value),
                        "interval": [str(lo), str(hi)],
                    }
                )

    cert = answer(
        spec.contract, snapshot, oracle, alpha=alpha, budget_calls=budget,
        seed=seed, formal_seed=formal_seed, trace=trace, scheduler_strategy=scheduler_strategy,
        proxy=proxy,
        request_id=f"{spec.query_id}:replay:B{budget}:S{seed}",
    )
    verdict = classify(cert, A, family, reference_labels)
    return {
        "query_id": spec.query_id,
        "dataset": spec.dataset,
        "split": spec.split,
        "kind": spec.kind,
        "budget": budget,
        "seed": seed,
        "formal_seed": (cert.get("randomization") or {}).get("formal_seed", ""),
        "steps": steps,
        "outcome": verdict["outcome"],
        "wrong_claims": verdict["wrong_claims"],
        "violations": len(violations),
        "violation_detail": violations[:10],
        "status": cert.get("status", ""),
        "semantic_calls": (cert.get("charged_cost") or {}).get(
            "semantic_calls", len(cert.get("sampled_record_ids") or [])
        ),
    }


def replay_seeds(
    specs: Sequence,
    snapshots: Mapping[str, Any],
    vault_factory: Callable[[str], Any],
    reference_labels: Mapping[str, Mapping[str, int]],
    budget: int,
    seeds: Sequence[int],
    alpha: float = 0.05,
    scheduler_strategy: Callable | None = None,
    proxy_factory: Callable[[int], Any] | None = None,
    formal_seed_map: Mapping[str, int] | None = None,
) -> list:
    from evaluation.harness import VaultOracle

    out = []
    for spec in specs:
        labels = reference_labels[spec.dataset]
        for seed in seeds:
            oracle = VaultOracle(vault_factory(spec.dataset), caller="replay", replay=True)
            proxy = proxy_factory(seed) if proxy_factory is not None else None
            out.append(
                run_trajectory(
                    spec, snapshots[spec.dataset], oracle, labels, budget, seed,
                    alpha=alpha, scheduler_strategy=scheduler_strategy,
                    proxy=proxy,
                    formal_seed=(int(formal_seed_map[str(seed)]) if formal_seed_map is not None else None),
                )
            )
    return out


def summarise_replay(records: Sequence[Mapping[str, Any]]) -> dict:
    """Aggregate replay results.

    ``queries_with_violation`` is the coverage-failure rate: how many query
    trajectories ever left the true value outside its interval. The seed count
    is reported alongside so nobody reads it as independent datasets.
    """
    n = len(records)
    with_violation = sum(1 for r in records if r.get("violations"))
    steps = sum(int(r.get("steps", 0)) for r in records)
    return {
        "runs": n,
        "queries_with_violation": with_violation,
        "violation_rate": (with_violation / n) if n else 0.0,
        "total_steps": steps,
        "mean_steps": (steps / n) if n else 0.0,
        "note": (
            "repeated seeds measure sampling variation for a fixed oracle only; "
            "they are not independent business datasets"
        ),
        "outcomes": summarise(records)["counts"],
    }
