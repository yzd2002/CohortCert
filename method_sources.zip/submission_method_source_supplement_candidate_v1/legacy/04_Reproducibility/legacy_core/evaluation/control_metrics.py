"""Metrics for the UCI control-set evaluation (proposal 15.3).

The control set answers one question: how far is the frozen reference
operator from existing human sentiment labels? These are plain confusion-
matrix metrics -- nothing here is a risk-controlled certificate, and none of
these numbers may be mixed with the CCR / FCR sampling metrics of the main
experiments.

All functions take pairs of (human, operator) labels in {0, 1} and are exact
over integer counts; floats appear only in the reported rates.
"""
from __future__ import annotations

__all__ = ["confusion_counts", "accuracy", "macro_f1", "evaluate_pairs"]


def confusion_counts(pairs: list[tuple[int, int]]) -> dict[str, int]:
    """Confusion counts with human as the row truth and operator as the call.

    tp = human 1 & operator 1, fn = human 1 & operator 0,
    fp = human 0 & operator 1, tn = human 0 & operator 0.
    """
    tp = fp = fn = tn = 0
    for human, operator in pairs:
        if human not in (0, 1) or operator not in (0, 1):
            raise ValueError(f"labels must be 0/1, got ({human}, {operator})")
        if human == 1 and operator == 1:
            tp += 1
        elif human == 1 and operator == 0:
            fn += 1
        elif human == 0 and operator == 1:
            fp += 1
        else:
            tn += 1
    return {"tp": tp, "fn": fn, "fp": fp, "tn": tn}


def _prf(tp: int, fp: int, fn: int) -> tuple[float, float, float]:
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    f1 = (2 * precision * recall / (precision + recall)) if precision + recall else 0.0
    return precision, recall, f1


def accuracy(pairs: list[tuple[int, int]]) -> float:
    if not pairs:
        return 0.0
    return sum(1 for h, o in pairs if h == o) / len(pairs)


def macro_f1(pairs: list[tuple[int, int]]) -> float:
    """Unweighted mean of the per-class F1 (classes = the two sentiment labels)."""
    c = confusion_counts(pairs)
    _, _, f1_pos = _prf(c["tp"], c["fp"], c["fn"])
    _, _, f1_neg = _prf(c["tn"], c["fn"], c["fp"])
    return (f1_pos + f1_neg) / 2


def evaluate_pairs(pairs: list[tuple[int, int]]) -> dict:
    """Full per-group report: n, confusion counts, accuracy, macro-F1, per-class P/R/F1."""
    c = confusion_counts(pairs)
    p_pos, r_pos, f1_pos = _prf(c["tp"], c["fp"], c["fn"])
    p_neg, r_neg, f1_neg = _prf(c["tn"], c["fn"], c["fp"])
    return {
        "n": len(pairs),
        "confusion": c,
        "accuracy": accuracy(pairs),
        "macro_f1": macro_f1(pairs),
        "per_class": {
            "positive": {"precision": p_pos, "recall": r_pos, "f1": f1_pos},
            "negative": {"precision": p_neg, "recall": r_neg, "f1": f1_neg},
        },
    }
