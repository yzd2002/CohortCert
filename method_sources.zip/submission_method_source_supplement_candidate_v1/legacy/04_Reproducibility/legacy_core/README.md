# CohortCert: executable fixed-label primary replay

This package contains all execution inputs for the primary 25,600-run grid: the 480 structured contracts (320 test), saved reference-model labels for eight predicates, cohort metadata, precomputed embeddings and indices, pilot/formal seed manifest, the unchanged historical engine, and a CPU replay driver. Corpus narrative/review text and review titles are omitted. Empty text placeholders keep the snapshot interface compatible. Original public record identifiers and grouping metadata are retained; this package is not an anonymity guarantee.

## Scope

The package reruns CohortCert and SharedContrast-CS under the historical saved labels. It does not construct model labels, run language-model inference, recover original narrative quotes, measure real inference latency, reproduce all external-system controls, or supply human truth for the eight predicates. Original model-label snapshots, including their provenance limitations, are preserved unchanged.

Only request-level structured outcomes, label counts and related non-timing fields are compared. Missing text affects illustrative quotes, which are excluded from this comparison. The sampling policy, numerical confidence kernel and reference embeddings are unchanged. The driver uses exact integer-scaled interval propagation and caches immutable compiled queries/reference values; 128 smoke runs check every propagation step against the original rational implementation. Timing across these implementations must not be compared.

## Run

Use Python 3.11 with `pip install -r requirements.txt`. No GPU, model weights, hosted API, or API key is needed for the fixed-label replay. From this package directory:

```sh
PYTHONHASHSEED=0 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 python scripts/replay_main_grid.py --smoke --direct-check --workers 4
PYTHONHASHSEED=0 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 python scripts/replay_main_grid.py --workers 4
python scripts/run_structural_diagnostics.py --workspace . --output structural_results
python scripts/verify_structural_diagnostics.py --workspace . --results structural_results
```

Choose a fresh output directory using `--output` when rerunning the main grid. The reported verification run used 16 workers; memory and CPU needs depend on worker count. On Windows set the same environment variables before running Python. Reference CSVs are kept separately from generated results and are not passed to the scheduler.

The driver independently records the requested IDs, checks budget and support, rejects repeated reads within a request, reconstructs the recorded cell permutations from the formal seed, and verifies every observed within-cell formal sequence is a prefix. This checks the new replay trajectories; original historical read IDs and Python hash seeds were not retained, so equal summary fields do not prove identical historical trajectories. Pseudorandom shuffles remain an approximation to the ideal randomization in the theorem.

## Verified results

`results/portable_full/completion.json`: 25,600 runs, zero discrepancies in the compared historical fields, 25,300 formal-prefix checks, and the same ten execution errors. The remaining runs take non-formal paths. `results/portable_smoke/completion.json`: 128 end-to-end runs with direct rational propagation checks. These are new replays of saved labels, not independent data or new semantic validation.

`PORTABLE_INPUT_MANIFEST.json` records fields removed and hashes. Every retained structured value and row order, all saved labels, and embedding arrays are unchanged from the retained historical inputs. This reproducible execution scope is broader than the separate derived-statistics package, but narrower than full model/data-pipeline reproduction.

## Data and code provenance

OpinRank is by Kavita Ganesan and ChengXiang Zhai, UCI ML Repository, DOI 10.24432/C5QW4W. CFPB metadata describe unverified complaints from a frozen public subset, not a representative sample of consumers. Saved model labels are not human annotations. See the manuscript and original retained source archive for dataset construction and model-label limitations. Corpus licenses and code licenses are separate; no new license over third-party material is asserted by this package. It is prepared locally; no public repository or artifact URL has been created.

The sanitized-input structural run independently verifies 1,200 compiled overlap contrasts, 320 full-label robustness calculations, and all 25,600 primary records. Its three derived CSV files are byte-identical to the manuscript diagnostic outputs. See `structural_results/independent_structural_verification.json`.
