#!/usr/bin/env python3
"""Execute the full fixed-label primary grid without corpus text or a GPU.

Every requested label is counted and checked against support. Output fields
are compared with all retained historical primary-grid records. Timing is not
compared, and quote rendering is intentionally absent when text is omitted.
"""
from __future__ import annotations

import argparse
from collections import Counter
from concurrent.futures import ProcessPoolExecutor, as_completed
import csv
from fractions import Fraction
import hashlib
import importlib.metadata
import json
import math
import os
from pathlib import Path
import random
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

SOURCES = {}
LABELS = {}
COMPILED = {}
REFERENCES = {}
ACTIVE_ORACLE = None
SAMPLING = {}
DIRECT = False


def initialize(root, direct):
    global ROOT, P, H, M, FAST, DIRECT
    ROOT, DIRECT = Path(root), direct
    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))
    import engine.pipeline as P
    import evaluation.harness as H
    import evaluation.metrics as M
    from scripts import exact_integer_bounds as FAST
    FAST.install(direct_check=direct)
    original_compile = P.compile_signed_decisions
    original_reference = M.reference_bounds
    original_permutations = P.independent_uniform_permutations

    def compiled(contract, snapshot, keep_cancellations=False):
        key = id(snapshot), json.dumps(contract, sort_keys=True, separators=(',', ':')), bool(keep_cancellations)
        if key not in COMPILED:
            COMPILED[key] = original_compile(contract, snapshot, keep_cancellations)
        return COMPILED[key]

    def reference(matrix, family, labels):
        key = id(matrix), id(family), id(labels)
        if key not in REFERENCES:
            REFERENCES[key] = original_reference(matrix, family, labels)
        return REFERENCES[key]

    def permutations(cells, seed):
        result = original_permutations(cells, seed)
        SAMPLING.update(pilot_reads=len(ACTIVE_ORACLE.reads), formal_seed=seed,
                        cells=[(cell.cell_id, list(cell.records)) for cell in cells],
                        permutations={key: list(value) for key, value in result.items()})
        return result

    P.compile_signed_decisions = compiled
    H.compile_signed_decisions = compiled
    M.reference_bounds = reference
    P.independent_uniform_permutations = permutations


class CountingOracle:
    def __init__(self, labels):
        self._labels, self.reads = labels, []
    def read(self, ids):
        ids = list(ids)
        self.reads.extend(ids)
        return {rid: self._labels[rid] for rid in ids}


def job(task):
    global ACTIVE_ORACLE
    from engine.oracle_interface import LabelSnapshot
    from engine.proxy import EmbeddingLRProxy
    from engine.baselines.shared_contrast import uniform_strategy
    from query.generator import read_jsonl
    from query.parquet_snapshot import ParquetSnapshot
    ds, predicate, seed, smoke, output_dir = task
    if ds not in SOURCES:
        SOURCES[ds] = (ParquetSnapshot(ROOT/f'data/cohorts/{ds}_snapshot.parquet'),
                       EmbeddingLRProxy(ds, ROOT/'data/embeddings'))
    snapshot, proxy = SOURCES[ds]
    label_key = ds, predicate
    if label_key not in LABELS:
        LABELS[label_key] = LabelSnapshot.load(ROOT/f'data/label_snapshots/{ds}__{predicate}.json', verify_hash=True).labels
    labels = LABELS[label_key]
    formal = int(json.loads((ROOT/'configs/formal_seed_manifest.json').read_text())['seed_pairs'][str(seed)])
    selected = sorted([query for query in read_jsonl(ROOT/'data/queries/all_queries.jsonl')
                       if query.dataset == ds and query.predicate_id == predicate and query.split == 'test'],
                      key=lambda q: q.query_id)
    assert len(selected) == 40
    if smoke:
        selected = selected[:1]
    expected = {}
    for method in ['cohortcert', 'shared_contrast_uniform']:
        with (ROOT/f'reference_results/seed{seed}/{method}__{ds}__{predicate}__test.csv').open(newline='') as handle:
            for row in csv.DictReader(handle):
                expected[(method, row['query_id'], row['budget_share'])] = row
    compare = ['status', 'outcome', 'semantic_calls', 'records_read', 'budget', 'formal_seed',
               'certifiable', 'complete', 'decisions_certified', 'decisions_total', 'over_budget', 'wrong_claims']
    results, mismatches, counts = [], [], Counter()
    started = time.perf_counter()
    for query in selected:
        COMPILED.clear(); REFERENCES.clear(); FAST.cache.clear()
        matrix, _ = P.compile_signed_decisions(query.contract, snapshot)
        support = matrix.rows_with_any_nonzero_coefficient()
        for share in [10.0, 25.0, 50.0, 100.0]:
            budget = max(1, min(len(support), math.ceil(share * len(support) / 100)))
            for method in ['cohortcert', 'shared_contrast_uniform']:
                oracle = CountingOracle(labels)
                ACTIVE_ORACLE = oracle
                SAMPLING.clear()
                row = H.run_one(query, snapshot, oracle, labels, budget, seed, alpha=.05, texts=None,
                                method=None, scheduler_strategy=None if method == 'cohortcert' else uniform_strategy,
                                proxy=proxy.clone_unfitted(), formal_seed=formal)
                row.update(method=method, budget_share=share, support_size=len(support),
                           calls_per_support=row['semantic_calls']/len(support))
                assert len(oracle.reads) == int(row['semantic_calls']) == int(row['records_read'])
                assert len(oracle.reads) == len(set(oracle.reads))
                assert set(oracle.reads) <= support and len(oracle.reads) <= budget
                prefix_cells = 0
                if SAMPLING:
                    rng = random.Random(formal)
                    cell_of, rebuilt = {}, {}
                    for cell_id, records in SAMPLING['cells']:
                        permutation = list(records); rng.shuffle(permutation)
                        rebuilt[cell_id] = permutation
                        assert permutation == SAMPLING['permutations'][cell_id]
                        for rid in records:
                            assert rid not in cell_of
                            cell_of[rid] = cell_id
                    actual = {cell_id: [] for cell_id in rebuilt}
                    for rid in oracle.reads[SAMPLING['pilot_reads']:]:
                        actual[cell_of[rid]].append(rid)
                    for cell_id, sequence in actual.items():
                        assert sequence == rebuilt[cell_id][:len(sequence)]
                    prefix_cells = len(actual)
                    counts['formal_prefix_checked_runs'] += 1
                ref = expected[(method, query.query_id, str(share))]
                differences = {field: [ref[field], str(row[field])] for field in compare if ref[field] != str(row[field])}
                if differences:
                    mismatches.append(dict(query_id=query.query_id, method=method, share=share, fields=differences))
                counts[row['outcome']] += 1
                counts['rows'] += 1
                row.update(read_order_sha256=hashlib.sha256(json.dumps(oracle.reads, separators=(',', ':')).encode()).hexdigest(),
                           acquisition_support_checked=True, prefix_cells_checked=prefix_cells)
                results.append(row)
    dest = Path(output_dir)
    dest.mkdir(parents=True, exist_ok=True)
    name = f'{ds}__{predicate}__seed{seed}'
    path = dest/(name+'.csv')
    with path.open('w', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(results[0]));writer.writeheader();writer.writerows(results)
    summary = dict(dataset=ds,predicate=predicate,seed=seed,rows=len(results),counts=dict(counts),
                   mismatches=mismatches,elapsed_s=time.perf_counter()-started,
                   exact_integer_direct_check=DIRECT)
    (dest/(name+'.json')).write_text(json.dumps(summary,indent=2)+'\n')
    return summary


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--workers',type=int,default=4)
    ap.add_argument('--smoke',action='store_true')
    ap.add_argument('--direct-check',action='store_true')
    ap.add_argument('--output',type=Path)
    args=ap.parse_args()
    if os.environ.get('PYTHONHASHSEED') != '0':
        raise RuntimeError('Run with PYTHONHASHSEED=0 as documented.')
    output=args.output or ROOT/'results'/('portable_smoke' if args.smoke else 'portable_full')
    if output.exists() and any(output.glob('*.csv')):
        raise RuntimeError('Output contains earlier runs; choose a fresh output directory.')
    output.mkdir(parents=True,exist_ok=True)
    from query.generator import read_jsonl
    queries=read_jsonl(ROOT/'data/queries/all_queries.jsonl')
    pairs=sorted({(q.dataset,q.predicate_id) for q in queries if q.split=='test'})
    assert len(pairs)==8
    tasks=[(ds,pred,seed,args.smoke,str(output)) for seed in range(2 if args.smoke else 10) for ds,pred in pairs]
    expected=128 if args.smoke else 25600
    completed=[];started=time.perf_counter()
    print(json.dumps({'mode':'smoke' if args.smoke else 'full','jobs':len(tasks),'expected_rows':expected,'workers':args.workers}),flush=True)
    with ProcessPoolExecutor(max_workers=args.workers,initializer=initialize,initargs=(str(ROOT),args.direct_check)) as pool:
        futures=[pool.submit(job,task) for task in tasks]
        for future in as_completed(futures):
            result=future.result();completed.append(result)
            state=dict(status='running',jobs_complete=len(completed),jobs_expected=len(tasks),
                       rows_complete=sum(x['rows'] for x in completed),mismatches=sum(len(x['mismatches']) for x in completed),
                       elapsed_s=time.perf_counter()-started)
            (output/'progress.json').write_text(json.dumps(state,indent=2)+'\n')
            print(json.dumps(state),flush=True)
    counts=Counter()
    for result in completed:counts.update(result['counts'])
    summary=dict(status='passed' if not any(x['mismatches'] for x in completed) else 'failed',
                 mode='smoke' if args.smoke else 'full',expected_rows=expected,actual_rows=sum(x['rows'] for x in completed),
                 jobs=len(completed),mismatching_runs=sum(len(x['mismatches']) for x in completed),
                 counts=dict(counts),elapsed_s=time.perf_counter()-started,
                 source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                 packages={name:importlib.metadata.version(name) for name in ['numpy','pandas','scipy','scikit-learn','pyarrow','PyYAML']},
                 scope='CPU execution on saved labels and unchanged embeddings with corpus text/title omitted; structured outcomes and record requests checked against every corresponding historical primary row; no live inference or semantic accuracy claim.')
    assert summary['actual_rows']==expected
    (output/'completion.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2),flush=True)
    if summary['status']!='passed':raise SystemExit(1)


if __name__=='__main__':
    main()
