#!/usr/bin/env python3
"""Independent direct-set checks, without importing the CohortCert engine."""
import argparse
from collections import Counter
import csv
from fractions import Fraction as F
import hashlib
import itertools
import json
from pathlib import Path
import random

import pyarrow.parquet as pq


def rows(path):
    with Path(path).open(newline='', encoding='utf-8') as handle:
        return list(csv.DictReader(handle))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace', required=True, type=Path)
    parser.add_argument('--results', type=Path, default=Path(__file__).resolve().parents[1] / 'results')
    args = parser.parse_args()
    root, out = args.workspace.resolve(), args.results
    report = json.loads((out / 'structural_diagnostics.json').read_text())
    protocol = report['protocol']
    labels, metadata, cache = {}, {}, {}
    for ds in protocol['datasets']:
        columns = ['record_id', 'product', 'date_received', 'state', 'issue', 'company'] if ds == 'cfpb' else ['record_id', 'city', 'date_parsed', 'hotel_id']
        metadata[ds] = pq.read_table(root / f'data/cohorts/{ds}_snapshot.parquet', columns=columns).to_pylist()
        labels[ds] = {p.stem.split('__', 1)[1]: json.loads(p.read_text())['labels']
                      for p in sorted((root / 'data/label_snapshots').glob(ds + '__*.json'))}
    stress = rows(out / 'unequal_overlap_cases.csv')
    by_case = {(r['dataset'], r['predicate'], int(r['n_a']), int(r['n_b']), int(r['common']), int(r['repetition'])): r for r in stress}
    assert len(by_case) == 1200
    rng = random.Random(protocol['seed'])
    designs, checked_stress = [], 0
    for ds in protocol['datasets']:
        identifiers = sorted(record['record_id'] for record in metadata[ds])
        for n_a, n_b in protocol['sizes']:
            for common in protocol['intersections']:
                for repetition in range(protocol['repetitions']):
                    draw = rng.sample(identifiers, n_a + n_b - common)
                    a = draw[:n_a]
                    b = draw[:common] + draw[n_a:]
                    designs.append((ds, n_a, n_b, common, repetition, a, b))
                    for predicate, y in labels[ds].items():
                        case = by_case[(ds, predicate, n_a, n_b, common, repetition)]
                        # Direct set means and direct unique-part means; no compiler.
                        exact = F(sum(y[i] for i in a), n_a) - F(sum(y[i] for i in b), n_b)
                        unique_a, unique_b = set(a) - set(b), set(b) - set(a)
                        invalid = F(sum(y[i] for i in unique_a), n_a) - F(sum(y[i] for i in unique_b), n_b)
                        assert F(case['compiled_fraction']) == F(case['direct_fraction']) == exact
                        assert F(case['invalid_shortcut_fraction']) == invalid
                        assert int(case['strict_decision_disagreement']) == int((exact > 0) != (invalid > 0))
                        assert abs(float(case['absolute_error_pp']) - 100 * float(abs(exact - invalid))) < 1e-10
                        expected_support = len(unique_a | unique_b) if n_a == n_b else len(set(a) | set(b))
                        assert int(case['support_size']) == expected_support
                        checked_stress += 1
    assert hashlib.sha256(json.dumps(designs, separators=(',', ':')).encode()).hexdigest() == report['design_sha256']

    def matches(expr, record):
        op, args = next(iter(expr.items()))
        if op == 'and':
            return all(matches(child, record) for child in args)
        if op == 'or':
            return any(matches(child, record) for child in args)
        value = record.get(args[0])
        if value is None:
            return False
        if op == 'eq':
            return value == args[1]
        if op == 'ge':
            return value >= args[1]
        if op == 'le':
            return value <= args[1]
        raise ValueError(op)

    def group(ds, cohort):
        key = ds, json.dumps(cohort['filter_ast'], sort_keys=True)
        if key not in cache:
            cache[key] = {record['record_id'] for record in metadata[ds] if matches(cohort['filter_ast'], record)}
        return cache[key]

    saved = {(r['dataset'], r['predicate'], r['query_id']): r for r in rows(out / 'full_label_robustness.csv')}
    queries = [json.loads(line) for line in (root / 'data/queries/all_queries.jsonl').read_text().splitlines()]
    checked_robustness, atom_cache = 0, {}
    for query in queries:
        if query['split'] != 'test':
            continue
        ds, predicate, contract = query['dataset'], query['predicate_id'], query['contract']
        cohorts = {c['id']: group(ds, c) for c in contract['cohorts']}
        y = labels[ds][predicate]
        support = set()
        def atom(left, right, side, boundary):
            a, b = cohorts[left], cohorts[right]
            key = ds, predicate, frozenset(a), frozenset(b), side, boundary
            wa, wb = F(1, len(a)), F(1, len(b))
            coefficients = {i: (wa if i in a else F(0)) - (wb if i in b else F(0)) for i in a | b}
            coefficients = {i: w for i, w in coefficients.items() if w}
            support.update(coefficients)
            if key not in atom_cache:
                value = F(sum(y[i] for i in a), len(a)) - F(sum(y[i] for i in b), len(b))
                margin = value - boundary if side == 'lower' else boundary - value
                tolerance, total = -1, F(0)
                if margin > 0:
                    tolerance = 0
                    for magnitude in sorted((abs(w) for w in coefficients.values()), reverse=True):
                        total += magnitude
                        if total >= margin:
                            break
                        tolerance += 1
                atom_cache[key] = tolerance
            return atom_cache[key]
        decision_tolerances = []
        for decision in contract['decisions']:
            kind = decision['type']
            if kind in ['compare', 'direction']:
                bound = atom(decision['left'], decision['right'], 'lower', F(str(decision['threshold'])))
            elif kind == 'equivalence':
                eps = F(str(decision['tolerance']))
                bound = min(atom(decision['left'], decision['right'], 'lower', -eps),
                            atom(decision['left'], decision['right'], 'upper', eps))
            elif kind in ['top1', 'topk']:
                candidates = decision['candidates']
                k = 1 if kind == 'top1' else decision['k']
                subsets = [decision['topk_set']] if 'topk_set' in decision else itertools.combinations(candidates, k)
                bound = max(min(atom(a, b, 'lower', F(0)) for a in subset for b in candidates if b not in subset)
                            for subset in subsets)
            else:
                raise ValueError(kind)
            decision_tolerances.append(bound)
        sufficient = min(decision_tolerances)
        expected = saved[(ds, predicate, query['query_id'])]
        assert sufficient == int(expected['safe_flips_full_label'])
        assert len(support) == int(expected['support_size'])
        assert int(sufficient >= 0) == int(expected['certifiable'])
        checked_robustness += 1
    assert checked_robustness == 320

    grid = []
    for path in sorted((Path(__file__).resolve().parents[1] / 'reference_results').glob('seed*/*__test.csv')):
        grid.extend(rows(path))
    assert len(grid) == 25600
    primary = []
    for budget in ['10.0', '25.0', '50.0', '100.0']:
        for method in ['cohortcert', 'shared_contrast_uniform']:
            subset = [row for row in grid if row['budget_share'] == budget and row['method'] == method]
            assert len(subset) == 3200
            outcomes = Counter(row['outcome'] for row in subset)
            certifiable = sum(row['certifiable'].lower() in ['true', '1'] for row in subset)
            assert certifiable == 1100
            assert not outcomes['false_certification']
            primary.append(dict(budget=budget, method=method, correct=outcomes['correct_certified'],
                                denominator=certifiable, execution_errors=outcomes['execution_error']))
    assert sum(row['execution_errors'] for row in primary) == 10
    result = dict(status='passed', overlap_cases_independently_checked=checked_stress,
                  test_contract_robustness_independently_checked=checked_robustness,
                  primary_rows_checked=len(grid), primary_counts=primary,
                  scope='Independent direct cohort means, direct Boolean truth, and expanded magnitude sums; no engine imports.')
    (out / 'independent_structural_verification.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
