#!/usr/bin/env python3
"""Post-hoc, fixed-label diagnostics; no inference or human annotation.

The protocol is saved before any outcomes are computed. All arithmetic used
for truth, coefficients, strict boundaries, and flip budgets is rational.
Use --workspace for the retained CohortCert experimental tree.
"""
from __future__ import annotations

import argparse
from collections import Counter
import csv
from fractions import Fraction as F
import hashlib
import itertools
import json
from pathlib import Path
import platform
import random
import statistics
import sys


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def safe_flips(coefficients, margin):
    """Largest r with sum of r largest magnitudes STRICTLY below margin.

    Returns -1 when the atom is not true; at most len(coefficients) otherwise.
    Zeros need not be included: all workload atoms have nonempty support.
    """
    if margin <= 0:
        return -1
    total, result = F(0), 0
    for weight, count in sorted(Counter(abs(c) for c in coefficients).items(), reverse=True):
        if weight == 0:
            result += count
            continue
        ratio = (margin - total) / weight
        allowed = (ratio.numerator - 1) // ratio.denominator
        take = max(0, min(count, allowed))
        result += take
        total += take * weight
        if take < count:
            return result
    return result


def family_tolerance(atom_tolerances, certificates, decisions):
    """Sufficient tolerance for preserving one fixed witness per decision."""
    return min(max(min(atom_tolerances[j] for j in certificate)
                   for certificate in alternatives)
               for alternatives in decisions)


def verify_robustness_exhaustively():
    """Independent exhaustive truth enumeration, including exact boundaries."""
    rng = random.Random(9371)
    n, families, baselines, perturbations = 6, 48, 0, 0
    for _ in range(families):
        rows = [[F(rng.choice((-3, -2, -1, 1, 2, 3)), 6) for _ in range(n)] for _ in range(4)]
        thresholds = [F(rng.choice((-2, -1, 0, 1, 2)), 6) for _ in rows]
        # (atom0 OR (atom1 AND atom2)) AND (atom2 OR atom3).
        decisions = [[[0], [1, 2]], [[2], [3]]]
        def holds(labels):
            atoms = [sum(c * y for c, y in zip(row, labels)) > b
                     for row, b in zip(rows, thresholds)]
            return all(any(all(atoms[j] for j in cert) for cert in alternatives)
                       for alternatives in decisions)
        for y in itertools.product((0, 1), repeat=n):
            values = [sum(c * v for c, v in zip(row, y)) for row in rows]
            tolerances = [safe_flips(row, value - b) for row, value, b in zip(rows, values, thresholds)]
            bound = family_tolerance(tolerances, None, decisions)
            assert (bound >= 0) == holds(y)
            baselines += 1
            if bound < 0:
                continue
            for z in itertools.product((0, 1), repeat=n):
                if sum(a != b for a, b in zip(y, z)) <= bound:
                    assert holds(z), ('invalid robustness guarantee', y, z, bound)
                    perturbations += 1
    # Exact equality must fail strict comparisons.
    assert safe_flips([F(1, 4)] * 4, F(1, 2)) == 1
    assert safe_flips([F(1, 4)] * 4, F(0)) == -1
    assert safe_flips([F(1, 4)] * 4, F(5, 4)) == 4
    return dict(families=families, baseline_assignments=baselines,
                perturbations_within_claimed_tolerance=perturbations, status='passed')


def write_csv(path, rows):
    with Path(path).open('w', newline='', encoding='utf-8') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace', type=Path)
    parser.add_argument('--output', type=Path, default=Path(__file__).resolve().parents[1] / 'results')
    parser.add_argument('--synthetic-only', action='store_true')
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    protocol = dict(seed=20261031, sizes=[[300, 300], [300, 450], [300, 600]],
                    intersections=[0, 75, 150, 225, 270], repetitions=10,
                    datasets=['cfpb', 'opinrank'], predicates_per_dataset=4,
                    comparison='rate(A) - rate(B) > 0',
                    selection='sorted record identifiers, random sample independent of labels; same groups for all predicates',
                    robustness='all 320 saved test contracts; full-label sufficient tolerance, not online tolerance or measured errors',
                    invalid_shortcut='delete all intersection coefficients, retaining original denominators; diagnostic, not a valid comparator',
                    scope='Post-hoc fixed-label analysis; no new model inference or human annotations.',
                    script_sha256=digest(__file__))
    (args.output / 'structural_protocol.json').write_text(json.dumps(protocol, indent=2) + '\n')
    synthetic = verify_robustness_exhaustively()
    (args.output / 'synthetic_robustness_validation.json').write_text(json.dumps(synthetic, indent=2) + '\n')
    print(json.dumps(synthetic), flush=True)
    if args.synthetic_only:
        return
    if args.workspace is None:
        parser.error('--workspace is required unless --synthetic-only is used')
    workspace = args.workspace.resolve()
    sys.path.insert(0, str(workspace))
    from query.compiler import compile_signed_decisions
    from query.snapshot import MemorySnapshot
    from query.parquet_snapshot import ParquetSnapshot
    from engine.oracle_interface import LabelSnapshot

    inputs = [Path(__file__), workspace / 'data/queries/all_queries.jsonl']
    for directory in ['query', 'engine']:
        inputs.extend(sorted((workspace / directory).glob('*.py')))
    labels_by_dataset = {}
    snapshots = {}
    for dataset in protocol['datasets']:
        paths = sorted((workspace / 'data/label_snapshots').glob(dataset + '__*.json'))
        assert len(paths) == 4
        inputs.extend(paths)
        labels_by_dataset[dataset] = {p.stem.split('__', 1)[1]: LabelSnapshot.load(p, verify_hash=True).labels for p in paths}
        path = workspace / f'data/cohorts/{dataset}_snapshot.parquet'
        inputs.append(path)
        snapshots[dataset] = ParquetSnapshot(path)

    # Draw all synthetic cohort memberships before consulting any label.
    rng = random.Random(protocol['seed'])
    designs = []
    for dataset in protocol['datasets']:
        ids = sorted(snapshots[dataset].record_ids())
        for n_a, n_b in protocol['sizes']:
            for common in protocol['intersections']:
                for repetition in range(protocol['repetitions']):
                    selected = rng.sample(ids, n_a + n_b - common)
                    a = selected[:n_a]
                    b = selected[:common] + selected[n_a:]
                    assert len(set(a) & set(b)) == common
                    designs.append((dataset, n_a, n_b, common, repetition, a, b))
    design_hash = hashlib.sha256(json.dumps(designs, separators=(',', ':')).encode()).hexdigest()
    stress = []
    for dataset, n_a, n_b, common, repetition, a, b in designs:
        overlap = set(a) & set(b)
        snap = MemorySnapshot({i: {} for i in set(a) | set(b)})
        for predicate, labels in labels_by_dataset[dataset].items():
            contract = dict(snapshot_id='structural_diagnostic', predicate_id=predicate,
                            cohorts=[dict(id='a', record_ids=a), dict(id='b', record_ids=b)],
                            decisions=[dict(type='compare', left='a', right='b', threshold=0,
                                            unit='proportion_difference')],
                            population_scope='constructed cohorts from the frozen saved snapshot',
                            risk=dict(alpha=.05, scope='this_request'),
                            budget=dict(max_oracle_record_predicate_calls=n_a + n_b - common))
            matrix, _ = compile_signed_decisions(contract, snap)
            row = matrix.rows[0]
            direct = F(sum(labels[i] for i in a), n_a) - F(sum(labels[i] for i in b), n_b)
            compiled = sum((coefficient * labels[i] for i, coefficient in row.items()), F(0))
            assert direct == compiled
            expected_support = n_a + n_b - 2 * common if n_a == n_b else n_a + n_b - common
            assert len(row) == expected_support
            wrong = sum((coefficient * labels[i] for i, coefficient in row.items() if i not in overlap), F(0))
            discrepancy = abs(direct - wrong)
            stress.append(dict(dataset=dataset, predicate=predicate, n_a=n_a, n_b=n_b,
                               common=common, repetition=repetition, union_size=len(set(a) | set(b)),
                               support_size=len(row), support_fraction=len(row) / len(set(a) | set(b)),
                               direct_fraction=str(direct), compiled_fraction=str(compiled),
                               invalid_shortcut_fraction=str(wrong), absolute_error_pp=100 * float(discrepancy),
                               strict_decision_disagreement=int((direct > 0) != (wrong > 0))))
    write_csv(args.output / 'unequal_overlap_cases.csv', stress)
    stress_summary = []
    for n_a, n_b in protocol['sizes']:
        for common in protocol['intersections']:
            subset = [row for row in stress if (row['n_a'], row['n_b'], row['common']) == (n_a, n_b, common)]
            stress_summary.append(dict(n_a=n_a, n_b=n_b, common=common, cases=len(subset),
                                       support_fraction=subset[0]['support_fraction'],
                                       compiler_mismatches=0,
                                       invalid_shortcut_disagreements=sum(row['strict_decision_disagreement'] for row in subset),
                                       median_absolute_error_pp=statistics.median(row['absolute_error_pp'] for row in subset),
                                       max_absolute_error_pp=max(row['absolute_error_pp'] for row in subset)))
    write_csv(args.output / 'unequal_overlap_summary.csv', stress_summary)
    print(json.dumps({'overlap_cases': len(stress), 'compiler_mismatches': 0}), flush=True)

    # Reference-label robustness. The label snapshot is used only here offline;
    # this value is unavailable to the running scheduler before observations.
    queries = [json.loads(line) for line in (workspace / 'data/queries/all_queries.jsonl').read_text().splitlines()]
    test = [query for query in queries if query['split'] == 'test']
    assert len(test) == 320
    robust = []
    for query in test:
        matrix, family = compile_signed_decisions(query['contract'], snapshots[query['dataset']])
        labels = labels_by_dataset[query['dataset']][query['predicate_id']]
        values = [sum((coefficient * labels[i] for i, coefficient in row.items()), F(0)) for row in matrix.rows]
        atom_r = {}
        for atom in family.atoms:
            value = values[atom.row_index]
            margin = value - atom.threshold if atom.kind == 'lower' else atom.threshold - value
            atom_r[atom.index] = safe_flips(matrix.rows[atom.row_index].values(), margin)
        decisions = [[family.certificates[ci] for ci in family.certificates_of(di)] for di in family.decision_indices()]
        r_safe = family_tolerance(atom_r, family.certificates, decisions)
        bounds = {atom.index: (values[atom.row_index], values[atom.row_index]) for atom in family.atoms}
        assert family.bundle_complete(family.check(bounds)) == (r_safe >= 0)
        support = len(matrix.rows_with_any_nonzero_coefficient())
        robust.append(dict(dataset=query['dataset'], predicate=query['predicate_id'], query_id=query['query_id'],
                           kind=query['kind'], support_size=support, certifiable=int(r_safe >= 0),
                           safe_flips_full_label=r_safe, safe_fraction_full_label=max(0, r_safe) / support))
    assert sum(row['certifiable'] for row in robust) == 110
    write_csv(args.output / 'full_label_robustness.csv', robust)
    robust_summary = []
    for dataset in protocol['datasets'] + ['all']:
        subset = [row for row in robust if row['certifiable'] and (dataset == 'all' or row['dataset'] == dataset)]
        robust_summary.append(dict(dataset=dataset, certifiable_queries=len(subset),
                                   median_safe_flips=statistics.median(row['safe_flips_full_label'] for row in subset),
                                   median_safe_support_pct=100 * statistics.median(row['safe_fraction_full_label'] for row in subset),
                                   zero_flip_tolerance=sum(row['safe_flips_full_label'] == 0 for row in subset),
                                   at_least_1pct=sum(F(row['safe_flips_full_label'], row['support_size']) >= F(1, 100) for row in subset),
                                   at_least_5pct=sum(F(row['safe_flips_full_label'], row['support_size']) >= F(1, 20) for row in subset)))
    report = dict(status='passed', protocol=protocol, design_sha256=design_hash,
                  synthetic_validation=synthetic, overlap_cases=len(stress), compiler_mismatches=0,
                  invalid_shortcut_decision_disagreements=sum(row['strict_decision_disagreement'] for row in stress),
                  nonzero_shared_coefficients_cases=sum(row['n_a'] != row['n_b'] and row['common'] > 0 for row in stress),
                  overlap_summary=stress_summary, robustness_summary=robust_summary,
                  python=platform.python_version(),
                  inputs_sha256={str(path.relative_to(workspace)) if path.is_relative_to(workspace) else path.name: digest(path)
                                 for path in inputs})
    (args.output / 'structural_diagnostics.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({key: value for key, value in report.items() if key not in ['inputs_sha256', 'overlap_summary', 'protocol']}, indent=2), flush=True)


if __name__ == '__main__':
    main()
