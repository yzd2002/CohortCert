"""Exact integer-scaled interval propagation copied from the validated historical wrapper."""
import math
from fractions import Fraction
import engine.pipeline as P
original = P.pushforward_contrast_bounds
cache = {}
counts = {'calls': 0, 'rebuilds': 0, 'fallbacks': 0}
check = False

def integer_pushforward(c_j_by_row, cells, cell_cs, family):
    counts['calls'] += 1
    all_bounds = [(c.cell_id, cell_cs[c.cell_id].bounds) for c in cells]
    if any(b is None for _, b in all_bounds):
        result = {a.index: None for a in family.atoms}
    else:
        signatures = tuple((c.cell_id, tuple(c.signature)) for c in cells)
        offsets = tuple(sorted(c_j_by_row.items()))
        atom_rows = tuple((a.index, a.row_index) for a in family.atoms)
        if (cache.get('cells') is not cells or cache.get('family') is not family or
            cache.get('offsets_obj') is not c_j_by_row or cache.get('signatures') != signatures or
            cache.get('offsets') != offsets or cache.get('atom_rows') != atom_rows):
            rows = {}
            for _, row in atom_rows:
                if row in rows:
                    continue
                base = c_j_by_row.get(row, Fraction(0))
                coeff = [(cid, sig[row]) for cid, sig in signatures if sig[row]]
                if not isinstance(base, (Fraction, int)) or any(not isinstance(x, (Fraction, int)) for _,x in coeff):
                    counts['fallbacks'] += 1
                    return original(c_j_by_row, cells, cell_cs, family)
                base = Fraction(base)
                coeff = [(cid, Fraction(a)) for cid, a in coeff]
                denominator = math.lcm(base.denominator, *(a.denominator for _,a in coeff))
                rows[row] = (denominator, base.numerator * (denominator // base.denominator),
                             [(cid, a.numerator * (denominator // a.denominator)) for cid,a in coeff])
            cache.clear()
            cache.update(cells=cells, family=family, offsets_obj=c_j_by_row, signatures=signatures,
                         offsets=offsets, atom_rows=atom_rows, rows=rows)
            counts['rebuilds'] += 1
        bounds = dict(all_bounds)
        by_row = {}
        for row,(den,base,terms) in cache['rows'].items():
            lo = hi = base
            for cid, a in terms:
                left, right = bounds[cid]
                if a > 0:
                    lo += a * left; hi += a * right
                else:
                    lo += a * right; hi += a * left
            by_row[row] = (Fraction(lo,den), Fraction(hi,den))
        result = {atom_id: by_row[row] for atom_id, row in atom_rows}
    if check and result != original(c_j_by_row, cells, cell_cs, family):
        raise AssertionError('integer-scaled and original signed intervals disagree')
    return result



def install(direct_check=False):
    global check
    check = direct_check
    P.pushforward_contrast_bounds = integer_pushforward
