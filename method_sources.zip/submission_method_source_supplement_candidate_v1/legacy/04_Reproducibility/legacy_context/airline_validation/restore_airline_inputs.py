#!/usr/bin/env python3
"""Restore only local source CSV/private-text inputs, preserving the frozen plan.

No query generation, new seed selection, feature fitting, annotation collection,
or model inference occurs. The exact source bytes and private Parquet hash are
checked against the retained protocol before the restored file is accepted.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path
import shutil
import tempfile
import urllib.request
import zipfile


HERE = Path(__file__).resolve().parent
SOURCE_URL = "https://www.kaggle.com/api/v1/datasets/download/crowdflower/twitter-airline-sentiment"
PROVIDER_PAGE = "https://www.kaggle.com/datasets/crowdflower/twitter-airline-sentiment"
PYARROW_VERSION = "25.0.1"


def sha(path):
    result = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            result.update(block)
    return result.hexdigest()


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def restore_source_csv(archive, destination, expected_sha):
    with zipfile.ZipFile(archive) as source:
        names = [name for name in source.namelist() if Path(name).name == "Tweets.csv"]
        require(len(names) == 1, "Expected exactly one Tweets.csv in the provider archive")
        # Select only this member's bytes; never extract archive paths.
        data = source.read(names[0])
    require(hashlib.sha256(data).hexdigest() == expected_sha,
            "Provider CSV differs from the frozen source; no recorded input was replaced")
    with destination.open("xb") as stream:
        stream.write(data)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--airline-dir", type=Path, default=HERE)
    parser.add_argument("--archive", type=Path, help="Locally downloaded provider ZIP")
    parser.add_argument("--download", action="store_true", help="Download the public provider ZIP if CSV is absent")
    parser.add_argument("--receipt", type=Path, help="Fresh receipt path; defaults to airline-dir/restoration_receipt.json")
    args = parser.parse_args()
    root = args.airline_dir.resolve()
    protocol_path = root / "protocol.json"
    protocol = json.loads(protocol_path.read_text())
    expected_csv = protocol["source_csv_sha256"]
    expected_private = protocol["text_snapshot_sha256"]
    receipt_path = args.receipt.resolve() if args.receipt else root / "restoration_receipt.json"
    require(not receipt_path.exists(), "Use a fresh receipt path; previous receipts are retained")
    protected_names = [
        "protocol.json", "queries.jsonl", "human_labels.json", "prepared_inputs.json",
        "design_before_metadata.json", "analysis_plan_before_execution.json",
        "prepare_airline.py", "label_airline.py", "run_airline_replay.py",
        "data/cohorts/airline_snapshot.parquet", "data/embeddings/airline_emb.npy",
        "data/embeddings/airline_index.parquet", "model_predictions.csv", "inference_completion.json",
    ]
    protected = {name: sha(root / name) for name in protected_names if (root / name).is_file()}
    destination = root / "Tweets.csv"
    archive_hash = None
    recorded_archive_hash = None
    provider_receipt = root / "download_receipt.json"
    if provider_receipt.is_file():
        recorded_archive_hash = json.loads(provider_receipt.read_text()).get("sha256")
    with tempfile.TemporaryDirectory(prefix="cohortcert_airline_download_") as scratch:
        if not destination.exists():
            if args.archive is not None:
                archive = args.archive.resolve()
            else:
                require(args.download, "Supply --archive, --download, or the exact local Tweets.csv")
                archive = Path(scratch) / "provider.zip"
                request = urllib.request.Request(SOURCE_URL, headers={"User-Agent": "CohortCert-reproduction/1.0"})
                with urllib.request.urlopen(request) as response, archive.open("xb") as output:
                    shutil.copyfileobj(response, output)
            archive_hash = sha(archive)
            restore_source_csv(archive, destination, expected_csv)
        require(sha(destination) == expected_csv, "Existing Tweets.csv does not match the frozen source")

    private = root / "private_text_snapshot.parquet"
    created_private = not private.exists()
    arrow_version = None
    if created_private:
        import pyarrow as pa
        import pyarrow.parquet as pq

        arrow_version = pa.__version__
        require(arrow_version == PYARROW_VERSION,
                f"Exact Parquet restoration requires pyarrow=={PYARROW_VERSION}; got {arrow_version}")
        records = []
        with destination.open(newline="", encoding="utf-8-sig") as stream:
            for index, row in enumerate(csv.DictReader(stream)):
                records.append({
                    "record_id": f"airline-row-{index:05d}", "text": row["text"],
                    "company": row["airline"], "date_received": row["tweet_created"][:10],
                    "original_tweet_id": row["tweet_id"],
                })
        require(len(records) == 14640, "Expected every one of the 14,640 source rows")
        with tempfile.NamedTemporaryFile(prefix="private_text_restore_", suffix=".parquet",
                                         dir=root, delete=False) as stream:
            temporary = Path(stream.name)
        try:
            pq.write_table(pa.Table.from_pylist(records), temporary)
            require(sha(temporary) == expected_private,
                    "Rebuilt private snapshot is not byte-identical; retained inputs were not replaced")
            require(not private.exists(), "Private snapshot appeared during restoration")
            temporary.replace(private)
        finally:
            temporary.unlink(missing_ok=True)
    require(sha(private) == expected_private, "Private snapshot does not match the recorded hash")
    require(all(sha(root / name) == value for name, value in protected.items()),
            "A protected recorded input changed during restoration")
    receipt = {
        "status": "passed", "source_url": SOURCE_URL, "provider_page": PROVIDER_PAGE,
        "provider_listed_license": "CC BY-NC-SA 4.0", "source_csv_sha256": sha(destination),
        "archive_sha256": archive_hash, "recorded_archive_sha256": recorded_archive_hash,
        "archive_matches_recorded_wrapper": (archive_hash == recorded_archive_hash
                                              if archive_hash is not None and recorded_archive_hash else None),
        "archive_scope": "Exact CSV bytes are authoritative; ZIP container metadata may differ.",
        "private_text_snapshot_sha256": sha(private), "created_private_snapshot": created_private,
        "pyarrow_version_for_rebuild": arrow_version, "protocol_sha256": sha(protocol_path),
        "protected_files_unchanged": True, "protected_file_sha256": protected,
        "scope": "Source/private-text restoration only; no new seeds, features, labels, inference or replay.",
    }
    with receipt_path.open("x", encoding="utf-8") as stream:
        stream.write(json.dumps(receipt, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps({key: receipt[key] for key in ("status", "source_csv_sha256",
          "private_text_snapshot_sha256", "created_private_snapshot", "protected_files_unchanged")}, indent=2))


if __name__ == "__main__":
    main()
