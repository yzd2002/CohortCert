"""All-case model-source oracle diagnostics after formal reconciliation."""
from collections import Counter
import csv
from fractions import Fraction
import json
from pathlib import Path
from statistics import median

ROOT = Path(__file__).resolve().parent


def fraction(a, b):
    return float(Fraction(a, b)) if b else None


def main():
    original = json.loads((ROOT / "model_oracle_v1/completion.json").read_text())
    precision = json.loads((ROOT / "model_precision_recovery_v2/completion.json").read_text())
    reconciliation = json.loads((ROOT / "model_formal_reconciliation_v1/completion.json").read_text())
    assert original["all_cases_retained"] and precision["all_cases_retained"] and reconciliation["all_cases_retained"]
    old = {row["case_id"]: row for row in original["summary"]}
    recovered = {row["case_id"]: row for row in precision["summary"]}
    final = {row["case_id"]: row for row in reconciliation["summary"]}
    assert set(old) == set(recovered) == set(final) and len(old) == 96
    categories, methods, rows = Counter(), {}, []
    infeasible_cases = []
    for case_id in sorted(old):
        case, extra, reconciled = old[case_id], recovered[case_id], final[case_id]
        metadata = case["case_metadata"]
        cap = (metadata["support_size"] + 1) // 2
        checks = reconciled.get("formal_checks", [])
        matched = len(checks) == 3 and not reconciled.get("formal_missing") and all(
            c["all_six_frozen_hashes_match"] and c["all_formal_action_ids_and_labels_match"] and
            c["all_formal_action_bounds_match"] for c in checks)
        categories["all_cases"] += 1
        categories["all_three_formals_fully_matched"] += matched
        categories["original_independent_artifact_pass"] += case.get("independent_artifact_status") == "passed"
        categories["source_noncoverage_cases_on_full_offline_paths"] += case.get("source_noncoverage_cells", 0) > 0
        categories["sticky_truncated_cases_on_full_offline_paths"] += case.get("sticky_truncated_cells", 0) > 0
        if reconciled["status"] == "verified_infeasible_reconciled":
            classification = "no_source_valid_proof_on_legal_paths"
            lower = upper = None
            capped_lower = capped_upper = cap
            infeasible_cases.append(case_id)
        elif reconciled["status"] == "matched_all_three":
            lower, upper = reconciled["lower_total"], reconciled["upper_total"]
            assert lower <= upper
            classification = ("constructively_feasible" if upper <= cap else
                              "provably_cost_above_cap" if lower > cap else "indeterminate")
            capped_lower, capped_upper = min(lower, cap), min(upper, cap)
            categories["relative_gap_le_005"] += reconciled["certified_relative_total_gap"] <= .05
        else:
            categories["unknown_or_pending_retained"] += 1
            rows.append({"case_id": case_id, "status": reconciled["status"]})
            continue
        categories["oracle_at_cap_" + classification] += 1
        base = {"case_id": case_id, "query_id": case["query_id"], "predicate": metadata["predicate"],
                "kind": metadata["kind"], "support_stratum": metadata["support_stratum"],
                "seed_id": metadata["seed_id"], "source": "model", "support_size": metadata["support_size"],
                "cap": cap, "oracle_lower_total": lower, "oracle_upper_total": upper,
                "oracle_at_cap": classification,
                "certified_relative_total_gap": reconciled.get("certified_relative_total_gap"),
                "v1_status": case["status"], "v1_gap": case.get("certified_relative_total_gap")}
        for check in checks:
            name, correct, calls = check["method"], check["algorithm_correct_complete"], check["algorithm_semantic_calls"]
            charged = calls if correct else cap
            assert charged >= capped_upper
            metrics = methods.setdefault(name, {"cases": 0, "reported_complete": 0, "correct_complete": 0,
                "source_error_runs": 0, "execution_error_runs": 0, "terminal_contrast_noncoverage_runs": 0,
                "missed_constructively_feasible": 0, "not_correct_cost_above_cap": 0,
                "not_correct_no_valid_legal_proof": 0, "not_correct_indeterminate": 0,
                "actual_calls_sum": 0, "cap_charged_calls": 0,
                "oracle_capped_lower_sum": 0, "oracle_capped_upper_sum": 0,
                "correct_calls_sum": 0, "correct_excess_lower_sum": 0, "correct_excess_upper_sum": 0})
            metrics["cases"] += 1
            metrics["reported_complete"] += check["algorithm_status"] == "complete"
            metrics["correct_complete"] += correct
            metrics["source_error_runs"] += check["algorithm_source_error"]
            metrics["execution_error_runs"] += check["algorithm_status"] == "execution_error"
            metrics["terminal_contrast_noncoverage_runs"] += bool(check["terminal_source_noncoverage_atoms"])
            metrics["actual_calls_sum"] += calls
            metrics["cap_charged_calls"] += charged
            metrics["oracle_capped_lower_sum"] += capped_lower
            metrics["oracle_capped_upper_sum"] += capped_upper
            if correct:
                assert upper is not None and upper <= calls <= cap
                metrics["correct_calls_sum"] += calls
                metrics["correct_excess_lower_sum"] += calls - upper
                metrics["correct_excess_upper_sum"] += calls - lower
            else:
                key = {"constructively_feasible": "missed_constructively_feasible",
                       "provably_cost_above_cap": "not_correct_cost_above_cap",
                       "no_source_valid_proof_on_legal_paths": "not_correct_no_valid_legal_proof",
                       "indeterminate": "not_correct_indeterminate"}[classification]
                metrics[key] += 1
            rows.append({**base, "method": name, "reported_status": check["algorithm_status"],
                         "correct_complete": correct, "source_error": check["algorithm_source_error"],
                         "actual_calls": calls, "cap_charged_calls": charged,
                         "correct_excess_calls_lower": calls - upper if correct else None,
                         "correct_excess_calls_upper": calls - lower if correct else None})
    for metrics in methods.values():
        a = metrics["cap_charged_calls"]
        metrics["clairvoyant_capped_saving_fraction_lower"] = fraction(a - metrics["oracle_capped_upper_sum"], a)
        metrics["clairvoyant_capped_saving_fraction_upper"] = fraction(a - metrics["oracle_capped_lower_sum"], a)
        metrics["correct_completed_excess_fraction_lower"] = fraction(metrics["correct_excess_lower_sum"], metrics["correct_calls_sum"])
        metrics["correct_completed_excess_fraction_upper"] = fraction(metrics["correct_excess_upper_sum"], metrics["correct_calls_sum"])
    finite = [row for row in final.values() if row.get("certified_relative_total_gap") is not None]
    output = {"scope": "All same48metadata-selected contracts x2seeds, pinned Qwen source only; operator-relative correctness, not human truth or independent populations",
              "categories": dict(categories), "methods": methods, "verified_infeasible_cases": infeasible_cases,
              "gap_summary": {"finite_brackets": len(finite), "total_declared_cases": 96,
                              "v1_under5pct": sum(r.get("certified_relative_total_gap") is not None and
                                                  r["certified_relative_total_gap"] <= .05 for r in old.values()),
                              "precision_under5pct": sum(r.get("certified_relative_total_gap") is not None and
                                                         r["certified_relative_total_gap"] <= .05 for r in recovered.values()),
                              "reconciled_under5pct": sum(r["certified_relative_total_gap"] <= .05 for r in finite),
                              "finite_reconciled_median": median(r["certified_relative_total_gap"] for r in finite),
                              "finite_reconciled_maximum": max(r["certified_relative_total_gap"] for r in finite),
                              "precision_improved_lower_bounds": sum(r.get("lower_improved", False) for r in recovered.values()),
                              "reconciliation_improved_uppers": sum(r.get("upper_improved", False) for r in final.values())},
              "extra_summed_per_case_times": {
                  "precision": {key: sum(r.get(key, 0) for r in recovered.values()) for key in
                                ("extra_wall_seconds", "extra_cpu_seconds", "lp_wall_seconds", "lp_cpu_seconds",
                                 "rational_wall_seconds", "rational_cpu_seconds")},
                  "reconciliation": {key: sum(r.get(key, 0) for r in final.values()) for key in
                                     ("extra_wall_seconds", "extra_cpu_seconds")}},
              "v1_case_wall_seconds": {"median": median(r["case_wall_seconds"] for r in old.values()),
                                       "maximum": max(r["case_wall_seconds"] for r in old.values())},
              "interpretation": "Cost headroom is acausal, kernel/proof-system conditional and cap charged on failures; it is not a causal efficiency guarantee. All wide, infeasible and adverse cases remain in96."}
    with (ROOT / "model_headroom_analysis_v2.json").open("x") as stream:
        json.dump(output, stream, indent=2); stream.write("\n")
    fields = sorted({key for row in rows for key in row})
    with (ROOT / "model_headroom_cases_v2.csv").open("x", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader(); writer.writerows(rows)
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
