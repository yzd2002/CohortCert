"""Separate offline oracle evaluator. Frozen primary code is imported, not edited.

Development is restricted to the previously examined airline population. Civil
evaluation requires an explicit frozen grid manifest plus the predeclared oracle
selection; metadata-plan mode never opens labels or acquisition outcomes.
"""
from __future__ import annotations

import argparse
from dataclasses import asdict
from fractions import Fraction
import gzip
from hashlib import sha256
import importlib
import json
import math
import os
from pathlib import Path
import sys
import time
import traceback

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parent
for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[key] = "1"

from oracle_core import Problem, proof_at, search


class OfflineInitializationCaptured(Exception):
    """Purposeful offline stop, never a formal execution result."""


class PathGenerationTimeout(TimeoutError):
    def __init__(self, partial):
        super().__init__("Full actual-prefix generation exceeded the case time budget")
        self.partial = partial


def encode(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, allow_nan=False,
                      default=lambda v: str(v) if isinstance(v, (Fraction, Path)) else
                      v.item() if hasattr(v, "item") else (_ for _ in ()).throw(TypeError(type(v).__name__)))


def file_hash(path):
    digest = sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def new_json(path, value):
    with Path(path).open("x", encoding="utf-8") as stream:
        stream.write(encode(value) + "\n")


def new_gzip(path, value):
    with gzip.open(path, "xt", encoding="utf-8", compresslevel=1) as stream:
        stream.write(encode(value) + "\n")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def bootstrap(frozen_root, core_root):
    frozen_root, core_root = Path(frozen_root).resolve(), Path(core_root).resolve()
    expected = json.loads((frozen_root / "SOURCE_SHA256.json").read_text())
    for relative, digest in expected.items():
        require(file_hash(frozen_root / relative) == digest, "Frozen source changed: " + relative)
    sys.path.insert(0, str(frozen_root))
    sys.path.insert(0, str(frozen_root / "system_design"))
    modules = {}
    for name in ("common", "request_repairs", "executor_v2.execution", "executor_v2.frontier_policy",
                 "executor_v2.run_grid", "theory_design.certificate_frontier"):
        module = importlib.import_module(name)
        require(Path(module.__file__).resolve().is_relative_to(frozen_root), "Mixed mutable import: " + name)
        modules[name] = module
    modules["frozen_root"], modules["core_root"] = frozen_root, core_root
    modules["frozen_hashes"] = expected
    from threadpoolctl import threadpool_limits
    modules["thread_limiter"] = threadpool_limits(limits=1)
    return modules


def source_reference(contract, snapshot, labels, family, cells, pilot_constants, modules):
    """Independent cohort means cross-check the signed full-source decomposition."""
    grid = modules["executor_v2.run_grid"]
    derived = grid.independent_family(contract)
    actual_family = {"atoms": [dict(index=a.index, kind=a.kind, threshold=str(a.threshold),
                                    row_index=a.row_index, cohort_pair=list(a.cohort_pair)) for a in family.atoms],
                     "certificates": [sorted(w) for w in family.certificates],
                     "certificate_decisions": list(family.certificate_decisions),
                     "decision_types": list(family.decision_types)}
    expected_family = {**derived, "certificates": [sorted(w) for w in derived["certificates"]]}
    require(encode(actual_family) == encode(expected_family), "Independent witness-family derivation mismatch")
    means = {}
    for cohort in contract["cohorts"]:
        ids = snapshot.cohort_records(cohort)
        require(bool(ids), "Empty source cohort")
        means[cohort["id"]] = Fraction(sum(labels[rid] for rid in ids), len(ids))
    totals = tuple(sum(labels[rid] for rid in cell.records) for cell in cells)
    truth, values = [], []
    for atom in family.atoms:
        left, right = atom.cohort_pair
        value = means[left] - means[right]
        decomposition = pilot_constants.get(atom.row_index, Fraction()) + sum(
            (cell.signature[atom.row_index] * total for cell, total in zip(cells, totals)), Fraction())
        require(value == decomposition, "Full-source signed decomposition differs from independent cohort means")
        values.append(value)
        truth.append(value > atom.threshold if atom.kind == "lower" else value < atom.threshold)
    return tuple(truth), totals, {"cohort_means": means, "atom_source_values": values,
                                  "atom_source_truth": truth, "cell_source_totals": totals,
                                  "independent_family_checked": True}


def capture_initial(query, snapshot, labels, proxy, plan, modules):
    execute = modules["executor_v2.execution"].execute
    holder, attempted = {}, []
    class PilotOnlyReplay:
        def read(self, ids):
            require(not attempted, "Offline initialization unexpectedly requested a second batch")
            attempted.extend(ids)
            return {rid: labels[rid] for rid in ids}
    class NeverPolicy:
        def choose(self, state):
            raise AssertionError("An online policy was invoked during offline initialization capture")
    def observer(state, verdict):
        require(state.step == 0, "Initial state was not captured before formal reads")
        holder["state"] = state
        holder["verdict"] = verdict
        raise OfflineInitializationCaptured("Purposeful offline step0 stop; not a formal run")
    result = execute(query["contract"], snapshot, PilotOnlyReplay(), proxy, NeverPolicy(), plan,
                     core_root=modules["core_root"], observer=observer,
                     policy_spec={"offline_initialization_capture": True},
                     record_actions=True, record_cs_events=True)
    if "state" not in holder:
        return None, result
    framework = result["certificate"].get("framework_exception") or {}
    require(framework.get("class") == "OfflineInitializationCaptured", "Unexpected initialization failure")
    require(not result["actions"] and not result["cs_events"], "Offline initialization consumed a formal prefix")
    require(all(r["phase"] == "pilot" for r in result["read_receipts"]), "Initialization made non-pilot reads")
    require(result["certificate"]["semantic_calls"] == len(attempted) == len(result["observed_labels"]),
            "Offline pilot accounting mismatch")
    require(all(cell.n == cell.s == 0 and cell.lower == 0 and cell.upper == cell.N
                for cell in holder["state"].cells), "Captured state is not an n=0 formal state")
    return holder["state"], result


def reconstruct_partition(query, snapshot, captured, result, plan, modules):
    require(plan.requested_bins == 1, "This evaluator currently requires the frozen one-bin partition")
    common = modules["common"]
    compiler = common.core_module(modules["core_root"], "query.compiler")
    frozen = common.core_module(modules["core_root"], "engine.frozen_cells")
    matrix, _ = compiler.compile_signed_decisions(query["contract"], snapshot)
    support = sorted({rid for row in matrix.rows for rid, value in row.items() if value})
    pilot_ids = sorted(result["observed_labels"])
    pilot_set = set(pilot_ids)
    residual = [rid for rid in support if rid not in pilot_set]
    groups = {}
    for rid in residual:
        signature = tuple(row.get(rid, Fraction()) for row in matrix.rows)
        groups.setdefault((signature, 0), []).append(rid)
    cells = tuple(frozen.Cell(cid, signature, bin_id, sorted(records))
                  for cid, ((signature, bin_id), records) in enumerate(groups.items()))
    require(len(cells) == len(captured.cells), "Reconstructed cell count differs")
    for cell, view in zip(cells, captured.cells):
        require((cell.cell_id, cell.N, tuple(cell.signature)) ==
                (view.cell_id, view.N, tuple(view.coefficients)), "Metadata cell reconstruction differs")
    receipts = result["certificate"]["frozen"]
    reconstructed = {
        "pilot_ids_sha256": common.digest(pilot_ids),
        "pilot_labels_sha256": common.digest(result["observed_labels"]),
        "partition_sha256": common.digest([(cell.cell_id, list(map(str, cell.signature)), cell.bin, cell.records)
                                             for cell in cells]),
        "priors_sha256": common.digest([(cell.cell_id, cell.a, cell.b, cell.lam, cell.alpha)
                                         for cell in captured.cells]),
    }
    permutations = frozen.independent_uniform_permutations(cells, plan.formal_seed)
    reconstructed["permutations_sha256"] = common.digest(permutations)
    for name, value in reconstructed.items():
        require(receipts[name] == value, "Offline reconstruction hash differs: " + name)
    return cells, permutations, {"hashes": receipts, "reconstructed_hashes": reconstructed,
                                 "pilot_ids": pilot_ids, "support_size": len(support),
                                 "metadata_reconstruction_checked": True,
                                 "scores_note": "Frozen bulk-fit score hash comes from step0 capture; no proxy refit during partition reconstruction"}


def compare_formal_record(formal, capture_result, captured, permutations, labels, query, snapshot, modules):
    formal_result = formal.get("result", formal)
    certificate = formal_result["certificate"]
    actual = capture_result["certificate"]
    fields = ("pilot_ids_sha256", "pilot_labels_sha256", "scores_sha256", "partition_sha256",
              "priors_sha256", "permutations_sha256")
    for name in fields:
        require(certificate["frozen"][name] == actual["frozen"][name], "Formal/capture frozen hash mismatch: " + name)
    for name in ("requested_contract_sha256", "effective_contract_sha256", "family_sha256", "settings"):
        require(certificate["plan"][name] == actual["plan"][name], "Formal/capture plan mismatch: " + name)
    prefix = dict.fromkeys((cell.cell_id for cell in captured.cells), 0)
    for action in formal_result["actions"]:
        cid, before, after = action["cell_id"], action["prefix_before"], action["prefix_after"]
        require(before == prefix[cid] and after > before, "Formal action is not a cell prefix")
        require(action["record_ids"] == permutations[cid][before:after], "Formal read IDs differ from offline permutation")
        require(action["labels"] == [labels[rid] for rid in action["record_ids"]], "Formal labels differ from source map")
        prefix[cid] = after
    audit = modules["executor_v2.run_grid"].reference_evaluation(
        query["contract"], snapshot, labels, certificate, {})
    return tuple(prefix[cell.cell_id] for cell in captured.cells), {
        "all_six_frozen_hashes_match": True, "settings_and_contract_match": True,
        "all_formal_action_ids_and_labels_match": True,
        "algorithm_semantic_calls": certificate["semantic_calls"],
        "algorithm_status": certificate["status"],
        "algorithm_correct_complete": audit["correct_complete"],
        "algorithm_source_error": audit["source_error"],
        "algorithm_source_proof_errors": audit["source_proof_errors"],
        "terminal_source_noncoverage_atoms": audit["terminal_source_noncoverage_atoms"],
        "formal_prefixes": prefix,
    }


def actual_paths(captured, cells, permutations, labels, totals, modules, deadline):
    common, repairs = modules["common"], modules["request_repairs"]
    base = common.core_module(modules["core_root"], "engine.finite_population_cs").CellCS
    timings, paths, coverage = common.Timings(), [], []
    for view, cell, total in zip(captured.cells, cells, totals):
        class Sink:
            def append(self, value):
                pass
        cls = repairs.sticky_cs_class(base, Sink(), timings)
        cs = cls(view.N, view.alpha, a=view.a, b=view.b, lam=view.lam)
        cs.audit_cell_id = view.cell_id
        require(cs.bounds == (view.lower, view.upper), "Path did not start from captured interval")
        path = [cs.bounds]
        first_bad = first_empty = None
        nonempty_bad, empty_count = 0, 0
        for n, rid in enumerate(permutations[cell.cell_id], 1):
            if n % 64 == 0 and time.perf_counter() >= deadline:
                raise PathGenerationTimeout({"completed_cell_paths": paths, "completed_coverage": coverage,
                                             "active_cell_id": cell.cell_id, "active_prefix_path": path,
                                             "active_source_total": total,
                                             "active_first_source_noncoverage_prefix": first_bad,
                                             "active_first_sticky_empty_prefix": first_empty,
                                             "coverage_audit_complete": False})
            bounds = cs.update([int(labels[rid])])
            path.append(bounds)
            if bounds is None:
                empty_count += 1
                if first_empty is None:
                    first_empty = n
                if first_bad is None:
                    first_bad = n
            elif not bounds[0] <= total <= bounds[1]:
                nonempty_bad += 1
                if first_bad is None:
                    first_bad = n
        paths.append(tuple(path))
        coverage.append({"cell_id": cell.cell_id, "N": cell.N, "source_total": total,
                         "first_source_noncoverage_prefix": first_bad,
                         "nonempty_source_noncoverage_prefixes": nonempty_bad,
                         "first_sticky_empty_prefix": first_empty,
                         "sticky_empty_prefixes": empty_count,
                         "last_legal_prefix": (first_empty - 1 if first_empty is not None else cell.N),
                         "last_legal_bounds": path[first_empty - 1 if first_empty is not None else cell.N]})
    return tuple(paths), coverage, timings.export()


def state_payload(state):
    return {"cells": [dict(cell_id=c.cell_id, N=c.N, n=c.n, s=c.s, lower=c.lower, upper=c.upper,
                            alpha=c.alpha, a=c.a, b=c.b, lam=c.lam,
                            coefficients=list(map(str, c.coefficients))) for c in state.cells],
            "pilot_constants": {str(k): str(v) for k, v in state.pilot_constants.items()},
            "bounds": {str(k): list(map(str, value)) for k, value in state.bounds.items()},
            "semantics": state.semantics}


def evaluate_case(query, snapshot, labels, proxy, plan, modules, out, formal_records=(),
                  seconds=10., relative_gap=.05, case_metadata=None):
    out = Path(out)
    out.mkdir(parents=True, exist_ok=False)
    started, deadline = time.perf_counter(), time.perf_counter() + seconds
    summary = {"query_id": query["query_id"], "status": "unknown", "case_metadata": case_metadata or {},
               "offline_only": True, "time_budget_seconds": seconds, "relative_gap_target": relative_gap}
    try:
        state, captured = capture_initial(query, snapshot, labels, proxy, plan, modules)
        new_gzip(out / "offline_initialization_capture.json.gz", captured)
        if state is None:
            summary.update(status="not_applicable_structural_or_tiny_scan",
                           initialization_status=captured["certificate"]["status"],
                           initialization_reason=captured["certificate"]["reason"],
                           pilot_cost=captured["certificate"]["semantic_calls"])
            return summary
        new_json(out / "initial_n0_state.json", state_payload(state))
        cells, permutations, reconstruction = reconstruct_partition(query, snapshot, state, captured, plan, modules)
        source_truth, totals, reference = source_reference(query["contract"], snapshot, labels,
                                                         state.family, cells, state.pilot_constants, modules)
        atoms, family, mode, allow_negative = modules["executor_v2.frontier_policy"]._integer_problem(state)
        require(tuple(atom.offset + sum(a * K for a, K in zip(atom.coeff, totals)) > 0 for atom in atoms)
                == source_truth, "Oriented source truth differs from independent reference")
        algorithm_prefixes, algorithm_checks = [], []
        for formal in formal_records:
            prefix, check = compare_formal_record(formal, captured, state, permutations, labels,
                                                  query, snapshot, modules)
            algorithm_prefixes.append(prefix); algorithm_checks.append(check)
        new_json(out / "reconstruction.json", reconstruction)
        new_json(out / "source_reference.json", reference)
        new_json(out / "formal_record_checks.json", algorithm_checks)
        paths, coverage, path_timings = actual_paths(state, cells, permutations, labels, totals, modules, deadline)
        problem = Problem(atoms, family, allow_negative, source_truth, paths,
                          captured["certificate"]["semantic_calls"], mode)
        path_payload = {"atoms": [{"offset": atom.offset, "coeff": atom.coeff} for atom in atoms],
                        "family": family, "allow_negative": allow_negative,
                        "source_truth": source_truth, "mode": mode,
                        "pilot_cost": problem.pilot_cost, "paths": paths,
                        "coverage": coverage, "frozen": captured["certificate"]["frozen"],
                        "source_reference": reference}
        new_gzip(out / "actual_prefix_paths.json.gz", path_payload)
        for prefix, check in zip(algorithm_prefixes, algorithm_checks):
            legal = all(n < len(path) and path[n] is not None for n, path in zip(prefix, paths))
            check["oracle_legal_prefix"] = legal
            check["source_valid_proof_exists_at_algorithm_prefix"] = bool(legal and proof_at(problem, prefix)["complete"])
            require(not check["algorithm_correct_complete"] or check["source_valid_proof_exists_at_algorithm_prefix"],
                    "Correct formal certificate is absent from its reconstructed legal prefixes")
        remaining = max(0., deadline - time.perf_counter())
        result = search(problem, modules["theory_design.certificate_frontier"],
                        seconds=remaining, relative_gap=relative_gap,
                        algorithm_prefixes=algorithm_prefixes)
        lower_certificate = result.pop("lower_certificate", None)
        if lower_certificate is not None:
            new_gzip(out / "verified_lower_bound_certificate.json.gz", lower_certificate)
        new_json(out / "oracle_result.json", result)
        new_json(out / "algorithm_comparison.json", algorithm_checks)
        summary.update(status=result["status"], pilot_cost=problem.pilot_cost,
                       support_size=reconstruction["support_size"], cell_count=len(cells),
                       lower_total=result.get("lower_total"), upper_total=result.get("upper_total"),
                       certified_relative_total_gap=result.get("certified_relative_total_gap"),
                       source_noncoverage_cells=sum(c["first_source_noncoverage_prefix"] is not None for c in coverage),
                       sticky_truncated_cells=sum(c["first_sticky_empty_prefix"] is not None for c in coverage),
                       path_timings=path_timings, formal_record_checks=algorithm_checks,
                       all_requested_formal_records_checked=True)
    except Exception as exc:
        summary.update(status="unknown_retained", failure={"class": type(exc).__name__,
                       "message": str(exc), "traceback": traceback.format_exc()})
        if isinstance(exc, PathGenerationTimeout):
            new_gzip(out / "partial_actual_prefix_paths.json.gz", exc.partial)
            summary["source_coverage_audit_complete"] = False
    finally:
        summary["case_wall_seconds"] = time.perf_counter() - started
        new_json(out / "case_summary.json", summary)
    return summary


def airline_probe(args, modules):
    airline = Path(args.airline).resolve()
    queries = [json.loads(line) for line in (airline / "queries.jsonl").read_text().splitlines() if line]
    query = next(query for query in queries if query["query_id"] == args.query_id)
    payload = (airline / "human_labels.json").read_bytes()
    labels = json.loads(payload)
    common = modules["common"]
    snapshot = common.core_module(modules["core_root"], "query.parquet_snapshot").ParquetSnapshot(
        airline / "data/cohorts/airline_snapshot.parquet")
    for item in sorted(queries, key=lambda q: q["query_id"]):
        for cohort in item["contract"]["cohorts"]:
            snapshot.cohort_records(cohort)
    require(set(labels) == set(snapshot.record_ids()) and all(type(v) is int and v in (0, 1) for v in labels.values()),
            "Old airline reference is not the full fixed binary population")
    proxy = common.core_module(modules["core_root"], "engine.proxy").EmbeddingLRProxy(
        "airline", airline / "data/embeddings")
    formal = json.loads(Path(args.formal_record).read_text())
    result = formal.get("result", formal)
    plan = modules["executor_v2.execution"].Plan(**result["certificate"]["plan"]["settings"])
    args.out.mkdir(parents=True, exist_ok=False)
    new_json(args.out / "driver_manifest.json", {
        "scope": "Post-hoc development on previously examined airline only",
        "frozen_root": str(modules["frozen_root"]), "core_root": str(modules["core_root"]),
        "frozen_sources": modules["frozen_hashes"], "query_id": args.query_id,
        "label_sha256": sha256(payload).hexdigest(), "formal_record": str(args.formal_record),
        "formal_record_sha256": file_hash(args.formal_record), "plan": asdict(plan),
        "oracle_source_sha256": {p.name: file_hash(p) for p in sorted(HERE.glob("*.py"))},
        "budget": {"seconds_per_case_including_capture_and_paths": args.seconds,
                   "relative_total_gap": args.relative_gap}})
    summary = evaluate_case(query, snapshot, labels, proxy, plan, modules,
                            args.out / args.query_id, (formal,), args.seconds, args.relative_gap,
                            {"source": "human", "development_only": True})
    new_json(args.out / "completion.json", {"cases": 1, "summary": [summary]})
    print(encode(summary), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--frozen-root", type=Path, default=PROJECT / "policy_freeze_v1")
    parser.add_argument("--core-root", type=Path, default=Path("/dev/shm/CohortCert_fixed_label_replay_20261031"))
    sub = parser.add_subparsers(dest="command", required=True)
    airline = sub.add_parser("airline-probe")
    airline.add_argument("--airline", type=Path, required=True)
    airline.add_argument("--formal-record", type=Path, required=True)
    airline.add_argument("--query-id", default="airline-0090")
    airline.add_argument("--out", type=Path, required=True)
    airline.add_argument("--seconds", type=float, default=10.)
    airline.add_argument("--relative-gap", type=float, default=.05)
    args = parser.parse_args()
    modules = bootstrap(args.frozen_root, args.core_root)
    if args.command == "airline-probe":
        airline_probe(args, modules)


if __name__ == "__main__":
    main()
