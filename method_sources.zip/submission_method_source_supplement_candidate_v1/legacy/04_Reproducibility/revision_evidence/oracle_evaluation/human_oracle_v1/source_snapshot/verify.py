"""Independent artifact checks: exact arithmetic, no optimization or label calls."""
from fractions import Fraction
import argparse
import gzip
import json
from math import ceil
from pathlib import Path
from types import SimpleNamespace

from oracle_core import Problem, independently_check_lagrange, model_for, proof_at, serialize_model


def read_gzip(path):
    with gzip.open(path, "rt", encoding="utf-8") as stream:
        return json.load(stream)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), default=str)


def verify_case(case_dir, frozen, frozen_manifest=None):
    case_dir = Path(case_dir)
    summary = json.loads((case_dir / "case_summary.json").read_text())
    if not (case_dir / "actual_prefix_paths.json.gz").exists():
        return {"status": "retained_unverifiable_unknown", "case_status": summary["status"]}
    payload = read_gzip(case_dir / "actual_prefix_paths.json.gz")
    state = json.loads((case_dir / "initial_n0_state.json").read_text())
    atoms = tuple(SimpleNamespace(offset=atom["offset"], coeff=tuple(atom["coeff"])) for atom in payload["atoms"])
    paths = tuple(tuple(None if b is None else tuple(b) for b in path) for path in payload["paths"])
    family = tuple(tuple(tuple(w) for w in witnesses) for witnesses in payload["family"])
    problem = Problem(atoms, family, tuple(payload["allow_negative"]), tuple(payload["source_truth"]),
                      paths, payload["pilot_cost"], payload["mode"])
    totals = payload["source_reference"]["cell_source_totals"]
    assert tuple(atom.offset + sum(a * K for a, K in zip(atom.coeff, totals)) > 0 for atom in atoms) == problem.atom_truth
    legal = []
    for cell, path in zip(state["cells"], paths):
        assert len(path) == cell["N"] + 1
        assert path[0] == (cell["lower"], cell["upper"])
        previous, failed, end = path[0], False, len(path) - 1
        for n, interval in enumerate(path[1:], 1):
            if interval is None:
                if not failed:
                    end = n - 1
                failed = True
            else:
                assert not failed
                assert previous[0] <= interval[0] <= interval[1] <= previous[1]
                previous = interval
        legal.append(end)
    result = json.loads((case_dir / "oracle_result.json").read_text())
    if result["status"] == "verified_infeasible_max_legal_prefix":
        maximum = proof_at(problem, tuple(legal))
        assert not maximum["complete"]
        assert canonical(maximum) == canonical(result["infeasibility_proof"])
        return {"status": "passed", "verified_infeasibility": True,
                "scope": "Monotone absence of a source-valid proof at every maximum legal prefix"}
    upper = result["upper_proof"]
    proof = proof_at(problem, tuple(upper["prefixes"]))
    assert proof["complete"] and canonical(proof) == canonical(upper)
    assert proof["total_calls"] == result["upper_total"]
    lower_path = case_dir / "verified_lower_bound_certificate.json.gz"
    if lower_path.exists():
        certificate = read_gzip(lower_path)
        grids = tuple(tuple(grid) for grid in certificate["grids"])
        rebuilt, _, cuts = model_for(problem, grids, frozen, True)
        assert canonical(serialize_model(rebuilt)) == canonical(certificate["model"])
        assert cuts == certificate["truth_cut_names"]
        bound = independently_check_lagrange(certificate["model"], certificate["multipliers"])
        assert bound == Fraction(certificate["rational_lower_bound"])
        formal_lower = max(0, ceil(bound))
    else:
        bound, formal_lower = Fraction(), 0
    assert result["lower_total"] == problem.pilot_cost + formal_lower
    assert result["lower_total"] <= result["upper_total"]
    gap = (result["upper_total"] - result["lower_total"]) / max(1, result["upper_total"])
    assert abs(gap - result["certified_relative_total_gap"]) < 1e-14
    return {"status": "passed", "verified_lower_total": result["lower_total"],
            "verified_upper_total": result["upper_total"], "rational_lagrange_formal_bound": str(bound),
            "pilot_charged_both_sides": problem.pilot_cost, "relative_total_gap": gap,
            "source_truth_cut_matrix_rebuilt": True,
            "scope": "Internal artifact/source-count/model consistency and exact dual/upper proofs; source-file matching is separately recorded by driver"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", type=Path, required=True)
    parser.add_argument("--frozen-root", type=Path, required=True)
    parser.add_argument("--core-root", type=Path, default=Path("/dev/shm/CohortCert_fixed_label_replay_20261031"))
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    from driver import bootstrap, new_json
    modules = bootstrap(args.frozen_root, args.core_root)
    result = verify_case(args.case, modules["theory_design.certificate_frontier"])
    new_json(args.out, result)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
