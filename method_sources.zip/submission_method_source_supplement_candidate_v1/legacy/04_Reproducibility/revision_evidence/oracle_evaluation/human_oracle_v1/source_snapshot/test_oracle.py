"""Exact tiny counterexamples and enumeration against source-valid oracle bounds."""
from fractions import Fraction
from itertools import product
import json
from pathlib import Path

from driver import bootstrap
from oracle_core import Problem, proof_at, search


def main():
    root = Path(__file__).resolve().parents[1]
    modules = bootstrap(root / "policy_freeze_v1", "/dev/shm/CohortCert_fixed_label_replay_20261031")
    frozen = modules["theory_design.certificate_frontier"]
    atom = frozen.Atom(0, (1,))
    family = (((0,),),)
    # Off-coverage interval says false although full source says true. It cannot
    # serve as a cheap false proof in the source-valid benchmark.
    false_exclusion = Problem((atom,), family, (True,), (True,), (((0, 1), (0, 0)),), 2)
    wrong_positive = Problem((atom,), family, (True,), (False,), (((0, 1), (1, 1)),), 2)
    for problem in (false_exclusion, wrong_positive):
        result = search(problem, frozen, seconds=.1)
        assert result["status"] == "verified_infeasible_max_legal_prefix"
    # A sticky empty path is truncated, not repaired by a later exact singleton.
    truncated = Problem((atom,), family, (True,), (True,), (((0, 1), None),), 2)
    assert search(truncated, frozen)["status"] == "verified_infeasible_max_legal_prefix"
    atoms = (frozen.Atom(0, (1, -1)), frozen.Atom(-1, (1, 1)))
    family = (((0,),), ((1,),))
    count = finite = infeasible = 0
    for bits0, bits1 in product(product((0, 1), repeat=2), repeat=2):
        totals = (sum(bits0), sum(bits1))
        paths = (frozen.exact_path(bits0, Fraction(1, 5)), frozen.exact_path(bits1, Fraction(1, 5)))
        truth = tuple(a.offset + sum(c * K for c, K in zip(a.coeff, totals)) > 0 for a in atoms)
        problem = Problem(atoms, family, (True, True), truth, paths, 3)
        exact = None
        for prefixes in product(range(3), repeat=2):
            if any(path[n] is None for path, n in zip(paths, prefixes)):
                continue
            proof = proof_at(problem, prefixes)
            if proof["complete"]:
                cost = 3 + sum(prefixes)
                exact = cost if exact is None else min(exact, cost)
        result = search(problem, frozen, seconds=.5, relative_gap=.05)
        if exact is None:
            assert result["status"] == "verified_infeasible_max_legal_prefix"
            infeasible += 1
        else:
            assert result["lower_total"] <= exact <= result["upper_total"]
            finite += 1
        count += 1
    output = {"status": "passed", "exact_enumerated_tiny_cases": count,
              "finite": finite, "verified_infeasible": infeasible,
              "off_source_false_and_true_proofs_rejected": True,
              "sticky_empty_path_not_repaired": True,
              "scope": "Synthetic mathematical validation, no Civil target access"}
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
