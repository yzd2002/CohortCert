"""Offline-only source-valid certificate frontiers over frozen actual prefixes.

No online executor or policy is edited. The caller supplies the frozen theory
module and realized full-reference path tables. The lower bound is reconstructed
with exact rational arithmetic; floating infeasibility is never an infeasibility
certificate. Source truth cuts belong ONLY in this offline evaluator.
"""
from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from math import ceil, isfinite
from time import perf_counter
import warnings


@dataclass
class Problem:
    atoms: tuple
    family: tuple
    allow_negative: tuple
    atom_truth: tuple
    paths: tuple
    pilot_cost: int
    mode: str = "bidirectional"


def bounds_at(problem, prefixes):
    endpoints = tuple(path[n] for path, n in zip(problem.paths, prefixes))
    if any(endpoint is None for endpoint in endpoints):
        raise ValueError("An oracle plan may not cross a sticky failure")
    bounds = []
    for atom in problem.atoms:
        lo = hi = atom.offset
        for a, (ell, upper) in zip(atom.coeff, endpoints):
            lo += a * (ell if a >= 0 else upper)
            hi += a * (upper if a >= 0 else ell)
        bounds.append((lo, hi))
    return tuple(bounds)


def proof_at(problem, prefixes):
    """Every selected atom assertion must be true under the FULL source labels."""
    bounds = bounds_at(problem, prefixes)
    true_available = tuple(lo >= 1 and truth
                           for (lo, _), truth in zip(bounds, problem.atom_truth))
    false_available = tuple(upper <= 0 and not truth
                            for (_, upper), truth in zip(bounds, problem.atom_truth))
    decisions, blocked = [], []
    for d, witnesses in enumerate(problem.family):
        source_value = any(all(problem.atom_truth[j] for j in w) for w in witnesses)
        positives = [i for i, w in enumerate(witnesses) if all(true_available[j] for j in w)]
        negative_cover = []
        for wi, witness in enumerate(witnesses):
            candidates = [j for j in witness if false_available[j]]
            if candidates:
                negative_cover.append({"witness": wi, "atom": min(candidates)})
        if positives:
            assert source_value
            decisions.append({"decision": d, "value": True,
                              "positive_witness": min(positives), "negative_cover": []})
        elif (problem.mode == "bidirectional" and problem.allow_negative[d]
              and len(negative_cover) == len(witnesses)):
            assert not source_value
            decisions.append({"decision": d, "value": False,
                              "positive_witness": None, "negative_cover": negative_cover})
        else:
            blocked.append(d)
            decisions.append({"decision": d, "value": None,
                              "positive_witness": None, "negative_cover": [],
                              "missing_positive_atoms_by_witness": [
                                  [j for j in w if not true_available[j]] for w in witnesses],
                              "unhit_negative_witnesses": [i for i, w in enumerate(witnesses)
                                                           if not any(false_available[j] for j in w)]})
    return {"complete": not blocked, "blocked_decisions": blocked,
            "prefixes": tuple(prefixes), "formal_calls": sum(prefixes),
            "total_calls": problem.pilot_cost + sum(prefixes),
            "bounds_integer_oriented": bounds, "atom_source_truth": problem.atom_truth,
            "true_atoms_available": true_available, "false_atoms_available": false_available,
            "allow_negative": problem.allow_negative, "decisions": decisions}


def truth_cuts(model, problem):
    cuts = []
    for index, name in enumerate(model.names):
        if name.startswith("true_"):
            atom = int(name.rsplit("_", 1)[1])
            forbidden = not problem.atom_truth[atom]
        elif name.startswith("false_"):
            atom = int(name.rsplit("_", 1)[1])
            forbidden = problem.atom_truth[atom]
        else:
            continue
        if forbidden:
            model.rows.append({index: -1})
            model.rhs.append(0)
            cuts.append(name)
    return cuts


def model_for(problem, grids, frozen, optimistic):
    options = frozen.grid_options(problem.paths, grids, optimistic=optimistic)
    model = frozen.build_model((problem.paths,), options, problem.atoms, problem.family,
                               mode=problem.mode, frontier=True,
                               allow_negative=problem.allow_negative)
    cuts = truth_cuts(model, problem)
    return model, options, cuts


def candidate_for_indices(model, options, indices, problem):
    prefixes = tuple(options[h][index][1] for h, index in enumerate(indices))
    proof = proof_at(problem, prefixes)
    if not proof["complete"]:
        raise ValueError("Allocation lacks a full-source-valid proof")
    candidate = [0] * len(model.names)
    names = {name: i for i, name in enumerate(model.names)}
    for h, index in enumerate(indices):
        candidate[model.xvars[h][index]] = 1
    candidate[model.success_vars[0]] = 1
    for j, value in enumerate(proof["true_atoms_available"]):
        candidate[names[f"true_0_{j}"]] = int(value)
    for j, value in enumerate(proof["false_atoms_available"]):
        candidate[names[f"false_0_{j}"]] = int(value)
    for decision in proof["decisions"]:
        d = decision["decision"]
        if decision["value"]:
            candidate[names[f"positive_0_{d}"]] = 1
            candidate[names[f'witness_0_{d}_{decision["positive_witness"]}']] = 1
        else:
            candidate[names[f"negative_0_{d}"]] = 1
    candidate = tuple(candidate)
    if not model.feasible(candidate):
        raise ValueError("Source-valid allocation failed exact integer-model checking")
    cost = sum(c * bit for c, bit in zip(model.costs, candidate))
    expected = sum(options[h][index][0] for h, index in enumerate(indices))
    if cost != expected:
        raise ValueError("Inconsistent oracle cost encoding")
    return candidate, proof, cost


def coordinate_indices(problem, options, deadline):
    indices = [len(local) - 1 for local in options]
    prefixes = [options[h][i][1] for h, i in enumerate(indices)]
    if not proof_at(problem, prefixes)["complete"]:
        return None
    order = sorted(range(len(options)), key=lambda h: (-options[h][-1][0], h))
    for h in order:
        if perf_counter() >= deadline:
            break
        left, right = 0, indices[h]
        while left < right:
            if perf_counter() >= deadline:
                return tuple(indices)
            middle = (left + right) // 2
            trial = list(prefixes)
            trial[h] = options[h][middle][1]
            if proof_at(problem, trial)["complete"]:
                right = middle
            else:
                left = middle + 1
        indices[h] = left
        prefixes[h] = options[h][left][1]
    return tuple(indices)


def lp_relaxation(model, time_limit):
    """Float LP proposes multipliers; the resulting bound is checked exactly."""
    import numpy as np
    from scipy.optimize import linprog
    from scipy.sparse import coo_matrix
    rows, cols, values = [], [], []
    for i, row in enumerate(model.rows):
        for j, value in row.items():
            rows.append(i); cols.append(j); values.append(value)
    matrix = coo_matrix((np.asarray(values, dtype=float), (rows, cols)),
                        shape=(len(model.rows), len(model.names))).tocsc()
    eq_rows, eq_cols = [], []
    for i, group in enumerate(model.groups):
        eq_rows.extend([i] * len(group)); eq_cols.extend(group)
    equality = coo_matrix((np.ones(len(eq_rows)), (eq_rows, eq_cols)),
                          shape=(len(model.groups), len(model.names))).tocsc()
    start = perf_counter()
    with warnings.catch_warnings(record=True) as recorded:
        warnings.simplefilter("always")
        result = linprog(model.costs, A_ub=-matrix, b_ub=-np.asarray(model.rhs),
                         A_eq=equality, b_eq=np.ones(len(model.groups)),
                         bounds=(0, 1), method="highs",
                         options={"time_limit": max(.001, time_limit), "threads": 1})
    multipliers = [Fraction() for _ in model.rows]
    marginals = getattr(getattr(result, "ineqlin", None), "marginals", None)
    if marginals is not None and len(marginals) == len(multipliers):
        multipliers = [Fraction(str(max(0., -float(value)))).limit_denominator(10000)
                       if isfinite(float(value)) else Fraction() for value in marginals]
    lower = model.rational_lower_bound(multipliers)
    fractional = None
    if result.x is not None and all(isfinite(float(value)) for value in result.x):
        fractional = tuple(map(float, result.x))
    return {"status": int(result.status), "message": result.message,
            "wall_seconds": perf_counter() - start, "fractional": fractional,
            "multipliers": tuple(multipliers), "rational_lower_bound": lower,
            "option_warnings": [str(item.message) for item in recorded],
            "native_threads_requested": 1}


def serialize_model(model):
    return {"names": model.names, "costs": model.costs,
            "rows_ge": [{str(j): value for j, value in row.items()} for row in model.rows],
            "rhs": model.rhs, "onehot_groups": model.groups}


def independently_check_lagrange(model_payload, multipliers):
    """Standard-library duplicate of weak Lagrangian duality, no SciPy required."""
    lam = tuple(Fraction(value) for value in multipliers)
    rows = [{int(j): int(value) for j, value in row.items()}
            for row in model_payload["rows_ge"]]
    if len(lam) != len(rows) or any(value < 0 for value in lam):
        raise ValueError("Invalid rational multipliers")
    reduced = [Fraction(value) for value in model_payload["costs"]]
    bound = sum((value * rhs for value, rhs in zip(lam, model_payload["rhs"])), Fraction())
    for value, row in zip(lam, rows):
        for j, coefficient in row.items():
            reduced[j] -= value * coefficient
    grouped = set()
    for group in model_payload["onehot_groups"]:
        bound += min(reduced[j] for j in group)
        grouped.update(group)
    bound += sum((min(Fraction(), value) for j, value in enumerate(reduced) if j not in grouped), Fraction())
    return bound


def search(problem, frozen, seconds=10., relative_gap=.05, algorithm_prefixes=()):
    start, deadline = perf_counter(), perf_counter() + max(0., seconds)
    legal = tuple(frozen.legal_length(path) for path in problem.paths)
    maximum = proof_at(problem, legal)
    if not maximum["complete"]:
        return {"status": "verified_infeasible_max_legal_prefix", "infeasibility_proof": maximum,
                "lower_total": None, "upper_total": None, "trace": [],
                "search_wall_seconds": perf_counter() - start}
    grids = []
    for h, end in enumerate(legal):
        values = {0, end}
        values.update(n for n in (8, 16, 64, 256) if 0 < n < end)
        values.update(prefix[h] for prefix in algorithm_prefixes if 0 <= prefix[h] <= end)
        grids.append(tuple(sorted(values)))
    best_prefix, best_upper = legal, sum(legal)
    for prefix in algorithm_prefixes:
        if all(0 <= n <= end for n, end in zip(prefix, legal)):
            proof = proof_at(problem, prefix)
            if proof["complete"] and sum(prefix) < best_upper:
                best_prefix, best_upper = tuple(prefix), sum(prefix)
    best_lower, best_bound_certificate, trace = 0, None, []
    iteration = 0
    while perf_counter() < deadline:
        iteration += 1
        row = {"iteration": iteration, "options_per_cell": list(map(len, grids))}
        upper_model, upper_options, _ = model_for(problem, grids, frozen, False)
        warm = coordinate_indices(problem, upper_options, min(deadline, perf_counter() + .25))
        if warm is not None:
            _, proof, cost = candidate_for_indices(upper_model, upper_options, warm, problem)
            if cost < best_upper:
                best_prefix, best_upper = tuple(proof["prefixes"]), cost
        # Always independently verify the retained actual-grid upper incumbent.
        incumbent_indices = tuple(grids[h].index(n) for h, n in enumerate(best_prefix))
        upper_candidate, _, cost = candidate_for_indices(upper_model, upper_options,
                                                       incumbent_indices, problem)
        assert cost == best_upper
        lower_model, lower_options, truth_cut_names = model_for(problem, grids, frozen, True)
        remaining = deadline - perf_counter()
        if remaining <= 0:
            break
        lp = lp_relaxation(lower_model, min(1.5, max(.001, remaining * .35)))
        payload = serialize_model(lower_model)
        verified = independently_check_lagrange(payload, lp["multipliers"])
        assert verified == lp["rational_lower_bound"]
        lower = max(0, ceil(verified))
        row.update(lp_status=lp["status"], lp_message=lp["message"],
                   lp_wall_seconds=lp["wall_seconds"], exact_lp_lagrange_bound=str(verified),
                   exact_integer_formal_lower=lower, native_threads_requested=1,
                   option_warnings=lp["option_warnings"])
        if lower > best_lower or best_bound_certificate is None:
            best_lower = max(best_lower, lower)
            best_bound_certificate = {"model": payload, "multipliers": list(map(str, lp["multipliers"])),
                                      "rational_lower_bound": str(verified),
                                      "integer_formal_lower": lower, "grids": grids,
                                      "truth_cut_names": truth_cut_names,
                                      "model_kind": "optimistic_coarse_grid_source_valid"}
        fractional = lp["fractional"]
        if fractional is not None:
            rounded = []
            for h, group in enumerate(lower_model.xvars):
                options = [lower_options[h][k][1] for k, j in enumerate(group) if fractional[j] > 1e-9]
                rounded.append(max(options, default=0))
            if proof_at(problem, rounded)["complete"] and sum(rounded) < best_upper:
                best_prefix, best_upper = tuple(rounded), sum(rounded)
                row["upper_improved_by_lp_rounding"] = True
        # The LP bound is valid independently of its reported solve status.
        if best_lower > best_upper:
            raise AssertionError("Exact lower bound exceeds a checked actual-path upper")
        total_upper = problem.pilot_cost + best_upper
        total_lower = problem.pilot_cost + best_lower
        gap = (total_upper - total_lower) / max(1, total_upper)
        row.update(best_formal_lower=best_lower, best_formal_upper=best_upper,
                   best_total_lower=total_lower, best_total_upper=total_upper,
                   certified_relative_total_gap=gap)
        trace.append(row)
        if gap <= relative_gap:
            break
        remaining = deadline - perf_counter()
        if remaining > .02:
            # Any checked MIP incumbent can improve U. Its floating bound or
            # infeasible status is NEVER used to increase L or declare no proof.
            upper_model.rows.append({j: -value for j, value in enumerate(upper_model.costs) if value})
            upper_model.rhs.append(-best_upper)
            # LP rounding may have improved U since the earlier warm check.
            # Verify the CURRENT incumbent against the newly added objective cut.
            current_indices = tuple(grids[h].index(n) for h, n in enumerate(best_prefix))
            candidate_for_indices(upper_model, upper_options, current_indices, problem)
            solved = frozen.solve_model(upper_model, time_limit=min(.5, remaining * .25))
            row["mip_status"] = solved["status"]
            row["mip_message"] = solved["message"]
            row["mip_exact_incumbent_verified"] = solved["exact_incumbent_verified"]
            if solved["status"] == 2:
                row["floating_infeasibility_not_trusted"] = True
            if solved["exact_incumbent_verified"]:
                # Upper option indexes equal its actual prefixes; find selected
                # model option indexes from its checked binary allocation.
                indices = tuple(next(k for k, j in enumerate(group) if solved["candidate"][j])
                                for group in upper_model.xvars)
                _, proof, cost = candidate_for_indices(upper_model, upper_options, indices, problem)
                if cost < best_upper:
                    best_prefix, best_upper = tuple(proof["prefixes"]), cost
        priorities = {}
        if fractional is not None:
            for h, group in enumerate(lower_model.xvars):
                for k, j in enumerate(group):
                    left, right = lower_options[h][k]
                    if fractional[j] > 1e-8 and right - left > 1:
                        priorities[h, left, right] = (right - left) * fractional[j]
        if not priorities:
            for h, grid in enumerate(grids):
                for left, right in zip(grid, grid[1:]):
                    if right - left > 1:
                        priorities[h, left, right] = right - left
        if not priorities:
            row["no_refinement_available"] = True
            break
        selected = sorted(priorities, key=lambda key: (-priorities[key], key))[:min(64, max(1, 2 * len(grids)))]
        values = [set(grid) for grid in grids]
        for h, left, right in selected:
            values[h].add((left + right) // 2)
        grids = [tuple(sorted(local)) for local in values]
    upper_proof = proof_at(problem, best_prefix)
    assert upper_proof["complete"]
    total_lower, total_upper = problem.pilot_cost + best_lower, problem.pilot_cost + best_upper
    gap = (total_upper - total_lower) / max(1, total_upper)
    return {"status": "verified_bounds_relative_gap" if gap <= relative_gap else "verified_bounds_budget_or_relaxation_gap",
            "lower_formal": best_lower, "upper_formal": best_upper,
            "pilot_cost": problem.pilot_cost, "lower_total": total_lower, "upper_total": total_upper,
            "certified_relative_total_gap": gap, "upper_proof": upper_proof,
            "certified_relative_formal_gap": (best_upper - best_lower) / max(1, best_upper),
            "lower_certificate": best_bound_certificate, "trace": trace,
            "search_wall_seconds": perf_counter() - start,
            "scope": "Same realized prefixes, frozen CS and atomwise source-valid proof system; no universal inference lower bound"}
