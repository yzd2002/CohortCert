# Offline source-valid prefix oracle

This evaluator is separate from the frozen acquisition policies. It is an
offline, clairvoyant benchmark conditional on the same pilot, residual cells,
numerical confidence kernel, formal permutations, and atomwise Boolean proof
system. It is not an online policy or a universal statistical lower bound.

The metadata selection in `selection_v1.json` fixes 48 queries, two seeds, and two
sources. `human_oracle_v1` contains the human-only 96-case execution. No model map
is opened by that driver. Missing formal records, failures, wide bounds, and
verified infeasible cases stay in the declared case ledger.

## What is checked

The frozen executor runs only through the charged pilot and initial state at
formal n=0. An observer then raises an intentional offline-stop exception. This
initialization receipt is labeled offline and must never be counted as a failed
or successful formal query. One-bin cells are reconstructed from metadata
coefficient signatures and pilot IDs. Pilot IDs/labels, bulk scores, partition,
priors, and regenerated formal permutations are compared with actual formal
records. Every formal action's record IDs and labels are checked against those
permutations and the source map.

The actual source labels are then used offline to generate all cell prefixes
through the identical frozen per-record sticky numerical CS. A first empty
intersection makes all subsequent prefixes unusable. Source count noncoverage
and sticky truncations are reported separately. This equality of numerical paths
does not prove all-input floating-point confidence-sequence correctness.

Every oracle proof must also be source-valid. A true-atom variable is forbidden
when the full source atom is false; a false-atom variable is forbidden when the
source atom is true. Each required decision needs a permitted source-correct
positive or negative witness. Ranking identification, if ever included, requires
an identified positive set; refuting its existential does not answer the rank.

The actual-prefix upper cost has an exactly checked integer proof. The lower
cost comes from an optimistic coarse-grid model and a rational Lagrangian bound.
The reported gap includes grid, LP relaxation, and optimization uncertainty.
Both costs include the same charged pilot. Mandatory exploration/batch choices
are relaxed for the oracle, so it remains optimistic relative to real schedules.

The only infeasibility certificate is absence of a source-valid proof at the
vector of maximum legal prefixes. Monotonicity makes that certificate cover
every legal allocation. Floating solver infeasibility is only a diagnostic.

## Development evidence

`development_airline0090_v1` is development on previously examined data. Its six
frozen hashes and all formal read IDs/labels match. The source-valid oracle total
cost is bracketed by 807 and 848, including 256 pilot calls; the saved Forecast
run used 888. The verified total gap is 4.835%, not an exact optimum. The complete
case took about 1.47 seconds. The independent artifact check rebuilds the
source-truth-cut model and recomputes both proofs with exact arithmetic. Its
original source snapshot is retained.

`synthetic_validation_v1.json` records 16 exact tiny comparisons against
enumeration, plus off-source false/true proof rejection and sticky truncation.
These finite checks are not a general numerical proof.

## Universal precision recovery

V1's bounded-denominator conversion can erase legitimate tiny LP multipliers
when integer contrast coefficients are large. Its resulting rational bounds
remain valid, but can become weak. The running v1 snapshot and all its results
are preserved.

`universal_precision_rule_v2.json` fixes a universal repair: retain each finite
nonnegative float proposal as `Fraction(str(value))` with no denominator cap.
`human_precision_recovery_v2` applies it to every saved human model, retains the
better verified lower bound and the original upper bound, and reports extra LP
and arithmetic wall/CPU time. It does not change grids, labels, policies, case
selection, or v1 artifacts. Extra recovery time is not charged to, or represented
as fitting within, the original ten-second case budget. The same rule is fixed
for any future model-source oracle evaluation.

## Interpretation

For a correctly completed allocation costing A and a valid oracle bracket
[L,U], its pathwise excess cost lies between A-U and A-L. For an unresolved cap B,
L>B rules out completion under this proof system on these paths; U<=B demonstrates
an offline feasible certificate within the cap. Cases with L<=B<U are
indeterminate. Clairvoyant savings need not be attainable by a causal scheduler.

This machinery diagnoses allocation headroom. It must not turn underperformance
against DifficultyGreedy (internal identifier `dual_greedy`) into an optimality
claim or imply that this is the first exact Boolean acquisition optimizer.
