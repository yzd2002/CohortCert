"""Descriptive diagnostics from every declared human oracle case; no new runs."""
from collections import Counter
import csv
from fractions import Fraction
import json
from pathlib import Path
from statistics import median

ROOT = Path(__file__).resolve().parent


def ratio(a, b):
    return float(Fraction(a, b)) if b else None


def main():
    v1root, v2root = ROOT / "human_oracle_v1", ROOT / "human_precision_recovery_v2"
    v1 = json.loads((v1root / "completion.json").read_text())
    v2 = json.loads((v2root / "completion.json").read_text())
    assert v1["all_cases_retained"] and v2["all_cases_retained"]
    original = {row["case_id"]: row for row in v1["summary"]}
    recovered = {row["case_id"]: row for row in v2["summary"]}
    assert set(original) == set(recovered) and len(original) == 96
    rows, aggregate = [], {}
    category = Counter()
    for case_id in sorted(original):
        case, improvement = original[case_id], recovered[case_id]
        metadata = case["case_metadata"]
        cap = (metadata["support_size"] + 1) // 2
        lower, upper = improvement.get("lower_total"), improvement.get("upper_total")
        category["all_cases"] += 1
        category["formal_all_three_matched"] += case.get("formal_validation_status") == "matched_all_three"
        category["independent_artifact_pass"] += case.get("independent_artifact_status") == "passed"
        if lower is None or upper is None:
            category["unknown_or_infeasible_retained"] += 1
            rows.append({"case_id": case_id, "case_status": improvement["status"]})
            continue
        assert lower <= upper
        oracle_cap = "constructively_feasible" if upper <= cap else "provably_infeasible" if lower > cap else "indeterminate"
        category["oracle_at_cap_" + oracle_cap] += 1
        category["relative_gap_le_005"] += improvement["certified_relative_total_gap"] <= .05
        category["source_noncoverage_cases_on_full_offline_paths"] += case["source_noncoverage_cells"] > 0
        category["sticky_truncated_cases_on_full_offline_paths"] += case["sticky_truncated_cells"] > 0
        provenance = json.loads((v1root / "cases" / case_id / "formal_record_provenance.json").read_text())
        assert len(provenance["available"]) == len(case["formal_record_checks"]) == 3
        base = {"case_id": case_id, "query_id": case["query_id"], "predicate": metadata["predicate"],
                "kind": metadata["kind"], "support_stratum": metadata["support_stratum"],
                "seed_id": metadata["seed_id"], "support_size": metadata["support_size"],
                "cap": cap, "pilot_cost": case["pilot_cost"], "oracle_lower_total": lower,
                "oracle_upper_total": upper, "oracle_at_cap": oracle_cap,
                "certified_relative_total_gap": improvement["certified_relative_total_gap"],
                "v1_gap": case["certified_relative_total_gap"], "precision_lower_improved": improvement["lower_improved"]}
        for origin, check in zip(provenance["available"], case["formal_record_checks"]):
            method = origin["method"]
            assert check["all_six_frozen_hashes_match"] and check["all_formal_action_ids_and_labels_match"]
            correct = check["algorithm_correct_complete"]
            calls = check["algorithm_semantic_calls"]
            # In this 50%-cap experiment unresolved requests pay the cap; errors
            # or source-wrong proofs are conservatively cap charged as declared.
            charged = calls if correct else cap
            assert charged >= min(upper, cap)
            metrics = aggregate.setdefault(method, {"cases": 0, "correct_complete": 0,
                "source_errors": 0, "missed_constructively_feasible": 0,
                "unresolved_provably_infeasible": 0, "unresolved_indeterminate": 0,
                "cap_charged_calls": 0, "oracle_capped_lower_sum": 0, "oracle_capped_upper_sum": 0,
                "correct_calls_sum": 0, "correct_excess_lower_sum": 0, "correct_excess_upper_sum": 0})
            metrics["cases"] += 1; metrics["correct_complete"] += int(correct)
            metrics["source_errors"] += int(check["algorithm_source_error"])
            metrics["cap_charged_calls"] += charged
            metrics["oracle_capped_lower_sum"] += min(lower, cap)
            metrics["oracle_capped_upper_sum"] += min(upper, cap)
            if not correct:
                key = {"constructively_feasible": "missed_constructively_feasible",
                       "provably_infeasible": "unresolved_provably_infeasible",
                       "indeterminate": "unresolved_indeterminate"}[oracle_cap]
                metrics[key] += 1
            else:
                assert upper <= calls <= cap
                metrics["correct_calls_sum"] += calls
                metrics["correct_excess_lower_sum"] += calls - upper
                metrics["correct_excess_upper_sum"] += calls - lower
            rows.append({**base, "method": method, "correct_complete": correct,
                         "source_error": check["algorithm_source_error"], "actual_calls": calls,
                         "cap_charged_calls": charged,
                         "correct_excess_calls_lower": calls - upper if correct else None,
                         "correct_excess_calls_upper": calls - lower if correct else None})
    for metrics in aggregate.values():
        a = metrics["cap_charged_calls"]
        metrics["clairvoyant_capped_saving_fraction_lower"] = ratio(a - metrics["oracle_capped_upper_sum"], a)
        metrics["clairvoyant_capped_saving_fraction_upper"] = ratio(a - metrics["oracle_capped_lower_sum"], a)
        metrics["correct_completed_excess_fraction_lower"] = ratio(metrics["correct_excess_lower_sum"], metrics["correct_calls_sum"])
        metrics["correct_completed_excess_fraction_upper"] = ratio(metrics["correct_excess_upper_sum"], metrics["correct_calls_sum"])
    output = {"scope": "All metadata-selected48 related contracts x2 seeds, human source only; descriptive conditional oracle diagnostics, no independent-query confidence interval",
              "categories": dict(category), "methods": aggregate,
              "gap_summary": {"v1_under5pct": sum(r.get("certified_relative_total_gap", 1) <= .05 for r in original.values()),
                              "combined_under5pct": sum(r.get("certified_relative_total_gap", 1) <= .05 for r in recovered.values()),
                              "v1_median": median(r["certified_relative_total_gap"] for r in original.values()),
                              "combined_median": median(r["certified_relative_total_gap"] for r in recovered.values()),
                              "combined_maximum": max(r["certified_relative_total_gap"] for r in recovered.values()),
                              "improved_lower_bounds": sum(r["lower_improved"] for r in recovered.values())},
              "precision_recovery_summed_per_case_time": {name: sum(r.get(name, 0) for r in recovered.values())
                  for name in ("extra_wall_seconds", "extra_cpu_seconds", "lp_wall_seconds", "lp_cpu_seconds",
                               "rational_wall_seconds", "rational_cpu_seconds")},
              "v1_measured_case_wall_seconds": {"median": median(r["case_wall_seconds"] for r in original.values()),
                                                "max": max(r["case_wall_seconds"] for r in original.values())},
              "interpretation": "Headroom is clairvoyant and kernel/proof-system conditional; it is not a promised attainable policy improvement. Wide bounds are retained."
             }
    with (ROOT / "human_headroom_analysis_v2.json").open("x") as stream:
        json.dump(output, stream, indent=2); stream.write("\n")
    fields = sorted({key for row in rows for key in row})
    with (ROOT / "human_headroom_cases_v2.csv").open("x", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader(); writer.writerows(rows)
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
