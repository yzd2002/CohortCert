"""Freeze and run the same96 declared cases for an explicitly selected source.

Source maps are opened only by explicit execution for the manifest-selected source. Missing formal records remain explicit
validation-pending cases. All code runs outside the frozen primary policies.
"""
from __future__ import annotations
import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import asdict
import csv
import gzip
from hashlib import sha256
import json
import math
import multiprocessing as mp
from pathlib import Path
from shutil import copy2
import time
import traceback

from driver import bootstrap, encode, evaluate_case, file_hash, new_json, require
from verify import verify_case

HERE = Path(__file__).resolve().parent
CONTEXT = {}


def freeze(args):
    source = args.source
    grid_path, selection_path = args.run_manifest.resolve(), args.selection.resolve()
    grid, selection = json.loads(grid_path.read_text()), json.loads(selection_path.read_text())
    require(selection["queries_sha256"] == grid["inputs"]["queries"]["sha256"], "Selection/queries mismatch")
    require(len(selection["queries"]) == 48 and selection["seed_ids"] == [0, 1], "Retain the declared 48-by-two cases")
    require(source in selection["sources"] and source in grid["labels"], "Selected source is unavailable")
    require(grid["nonranking_semantics"] == "bidirectional", "Oracle completion differs from primary")
    query_by_id = {q["query_id"]: q for q in grid["query_metadata"]}
    entries = []
    for seed_id in selection["seed_ids"]:
        for q in selection["queries"]:
            metadata = query_by_id[q["query_id"]]
            require(metadata["kind"] != "ranking" and metadata["support_size"] == q["support_size"],
                    "Selection is not the same nonranking metadata support")
            entries.append({**q, "source": source, "seed_id": seed_id,
                            "predicate": metadata["predicate"],
                            "case_id": q["query_id"] + f'__{source}__seed{seed_id:02d}'})
    require(len(entries) == 96 and len({e["case_id"] for e in entries}) == 96, "Missing/duplicate declared cases")
    args.out.mkdir(parents=True, exist_ok=False)
    snapshot = args.out / "source_snapshot"
    snapshot.mkdir()
    sources = {}
    for path in sorted(HERE.glob("*.py")):
        copy2(path, snapshot / path.name)
        sources[path.name] = file_hash(path)
    manifest = {"schema": "cohortcert.source-offline-oracle-v1", "created_unix": time.time(),
                "evaluation_rule": "Same96 metadata cases, v1 grids/time and universal precision recovery as human; missing formal records reconciled later",
                "source": source, "case_count": 96, "cases": entries,
                "selection_path": str(selection_path), "selection_sha256": file_hash(selection_path),
                "master_selection_case_count": selection["oracle_cases"],
                "precision_recovery": "The previously frozen universal v2 exact-decimal pass is applied separately to every saved model; original v1 stays unchanged",
                "grid_manifest_path": str(grid_path), "grid_manifest_sha256": file_hash(grid_path),
                "source_label_bindings": {pred: {"path": grid["labels"][source][pred],
                                                    "sha256": grid["label_sha256"][source][pred]}
                                          for pred in grid["labels"][source]},
                "grid_results": str((args.results or grid_path.parent / "results").resolve()),
                "frozen_root": str(args.frozen_root.resolve()), "core_root": grid["core_root"],
                "oracle_code_sha256": sources, "seconds_per_case": args.seconds,
                "relative_total_gap_target": args.relative_gap, "workers_maximum": 2,
                "call_accounting": "Same charged pilot added to allocator and oracle; all unknown/infeasible/pending cases retained",
                "source_validity": "Forbid true atom variables on source-false atoms and false variables on source-true atoms",
                "infeasibility": "Only exact source-valid proof absence at maximum legal prefixes; no floating infeasibility claim",
                "grid_gap": "Stop only on TOTAL checked U minus rational LP/Lagrange L, not a grid-width-only claim",
                "freeze_access": "Only metadata, protocol and path/hash strings read; no label-map or formal-outcome values opened by freeze"}
    new_json(args.out / "oracle_manifest.json", manifest)
    print(encode({"status": "frozen", "manifest": str(args.out / "oracle_manifest.json"),
                  "sha256": file_hash(args.out / "oracle_manifest.json"), "source": source, "declared_cases": 96,
                  "source_maps_opened_by_freeze": False}))


def initialize(manifest_path):
    global CONTEXT
    manifest_path = Path(manifest_path)
    manifest = json.loads(manifest_path.read_text())
    require(manifest["source"] in ("human", "model") and manifest["case_count"] == 96, "Unknown source or case count")
    for name, expected in manifest["oracle_code_sha256"].items():
        require(file_hash(manifest_path.parent / "source_snapshot" / name) == expected, "Oracle source snapshot changed")
    require(file_hash(manifest["selection_path"]) == manifest["selection_sha256"], "Master selection changed")
    require(file_hash(manifest["grid_manifest_path"]) == manifest["grid_manifest_sha256"], "Primary grid manifest changed")
    grid = json.loads(Path(manifest["grid_manifest_path"]).read_text())
    modules = bootstrap(manifest["frozen_root"], manifest["core_root"])
    modules["executor_v2.run_grid"].verify_frozen_files(grid)
    common = modules["common"]
    snapshot = common.core_module(manifest["core_root"], "query.parquet_snapshot").ParquetSnapshot(grid["inputs"]["snapshot"]["path"])
    queries = {q["query_id"]: q for q in modules["executor_v2.run_grid"].load_queries(grid["inputs"]["queries"]["path"])}
    for query in queries.values():
        for cohort in query["contract"]["cohorts"]:
            snapshot.cohort_records(cohort)
    proxy = common.core_module(manifest["core_root"], "engine.proxy").EmbeddingLRProxy(
        grid["dataset_feature_prefix"], Path(grid["inputs"]["features"]["path"]).parent)
    CONTEXT = {"manifest": manifest, "grid": grid, "modules": modules, "snapshot": snapshot,
               "queries": queries, "proxy": proxy, "labels": {}, "formal_cache": {},
               "selected_ids": {e["query_id"] for e in manifest["cases"]},
               "output": manifest_path.parent / "cases"}


def formal_records(entry):
    context, grid = CONTEXT, CONTEXT["grid"]
    source = context["manifest"]["source"]
    records, provenance, missing = [], [], []
    for method in ("matched", "dual_greedy", "forecast"):
        shards = [s for s in grid["shards"] if s["source"] == source and s["method"] == method
                  and s["seed_id"] == entry["seed_id"] and float(s["budget_share"]) == 50.]
        if len(shards) != 1:
            missing.append({"method": method, "reason": "missing_or_ambiguous_frozen_shard"}); continue
        name = shards[0]["name"]
        root = Path(context["manifest"]["grid_results"])
        progress, raw_path, csv_path = root / "progress" / (name + ".json"), root / "shards" / (name + ".jsonl.gz"), root / "shards" / (name + ".csv")
        if name not in context["formal_cache"]:
            if not progress.exists() or json.loads(progress.read_text()).get("status") != "complete":
                missing.append({"method": method, "reason": "formal_shard_not_complete"}); continue
            expected = {}
            with csv_path.open(newline="", encoding="utf-8") as stream:
                for row in csv.DictReader(stream):
                    if row["query_id"] in context["selected_ids"]:
                        expected[row["query_id"]] = row["raw_record_sha256"]
            retained = {}
            with gzip.open(raw_path, "rb") as stream:
                for line in stream:
                    payload = json.loads(line)
                    qid = payload["query_id"]
                    if qid in context["selected_ids"]:
                        row_hash = sha256(line.rstrip(b"\n")).hexdigest()
                        require(expected.get(qid) == row_hash, "CSV/raw row hash mismatch for " + qid)
                        # Full raw stays in its original immutable shard. These
                        # are exactly the fields needed for hash/read/proof checks.
                        retained[qid] = {"query_id": qid, "source": payload["source"],
                                         "method": method, "seed_id": payload["seed_id"],
                                         "result": {"certificate": payload["result"]["certificate"],
                                                    "actions": payload["result"]["actions"]},
                                         "raw_record_sha256": row_hash}
            context["formal_cache"][name] = {"records": retained, "raw_path": str(raw_path),
                                              "csv_path": str(csv_path), "raw_sha256": file_hash(raw_path),
                                              "csv_sha256": file_hash(csv_path)}
        cached = context["formal_cache"][name]
        if entry["query_id"] not in cached["records"]:
            missing.append({"method": method, "reason": "declared_query_missing_from_completed_formal_shard"}); continue
        record = cached["records"][entry["query_id"]]
        require(record["source"] == source and record["seed_id"] == entry["seed_id"], "Formal record source/seed mismatch")
        records.append(record)
        provenance.append({k: cached[k] for k in ("raw_path", "csv_path", "raw_sha256", "csv_sha256")})
        provenance[-1].update(method=method, raw_record_sha256=record["raw_record_sha256"])
    return records, provenance, missing


def work(entry):
    context, manifest, grid = CONTEXT, CONTEXT["manifest"], CONTEXT["grid"]
    source = manifest["source"]
    out = context["output"] / entry["case_id"]
    try:
        pred = entry["predicate"]
        if pred not in context["labels"]:
            payload = Path(grid["labels"][source][pred]).read_bytes()
            require(sha256(payload).hexdigest() == grid["label_sha256"][source][pred], "Frozen selected-source label-map hash mismatch")
            labels = json.loads(payload)
            require(set(labels) == set(context["snapshot"].record_ids()) and
                    all(type(v) is int and v in (0, 1) for v in labels.values()), "Source map is not the full fixed population")
            context["labels"][pred] = labels
        labels = context["labels"][pred]
        record_start = time.perf_counter()
        formal, provenance, missing = formal_records(entry)
        loading_seconds = time.perf_counter() - record_start
        seed = next(s for s in grid["seed_records"] if s["seed_id"] == entry["seed_id"])
        exploration = context["modules"]["executor_v2.run_grid"].substream(
            seed["exploration_seed"], "cohortcert-v2-exploration-request-v1", entry["query_id"])
        cap = max(1, min(entry["support_size"], math.ceil(.5 * entry["support_size"])))
        plan = context["modules"]["executor_v2.execution"].Plan(
            int(seed["pilot_seed"]), int(seed["formal_seed"]), exploration,
            budget_override=cap, semantics=grid["nonranking_semantics"], **grid["common_plan"])
        metadata = {**entry, "formal_records_missing": missing,
                    "formal_loading_seconds": loading_seconds,
                    "formal_validation_status": "all_three_available" if not missing else "validation_pending",
                    "label_path": grid["labels"][source][pred],
                    "label_sha256": grid["label_sha256"][source][pred]}
        summary = evaluate_case(context["queries"][entry["query_id"]], context["snapshot"], labels,
                                context["proxy"], plan, context["modules"], out, formal,
                                manifest["seconds_per_case"], manifest["relative_total_gap_target"], metadata)
        new_json(out / "formal_record_provenance.json", {"available": provenance, "missing": missing})
        check = verify_case(out, context["modules"]["theory_design.certificate_frontier"])
        new_json(out / "independent_artifact_check.json", check)
        summary["independent_artifact_status"] = check["status"]
        summary["formal_validation_status"] = "matched_all_three" if not missing else "validation_pending"
        return {"case_id": entry["case_id"], **summary}
    except Exception as exc:
        failure = {"case_id": entry["case_id"], "query_id": entry["query_id"],
                   "status": "unknown_retained", "failure": {"class": type(exc).__name__,
                   "message": str(exc), "traceback": traceback.format_exc()}}
        out.mkdir(parents=True, exist_ok=True)
        path = out / "worker_failure.json"
        if not path.exists():
            new_json(path, failure)
        return failure


def run(args):
    manifest_path = args.manifest.resolve()
    manifest = json.loads(manifest_path.read_text())
    require(1 <= args.workers <= 2, "At most two offline workers are authorized")
    out = manifest_path.parent
    (out / "cases").mkdir(exist_ok=False)
    new_json(out / "execution_binding.json", {"manifest_sha256": file_hash(manifest_path),
                                              "workers": args.workers, "source": manifest["source"]})
    summary_path = out / "case_results.jsonl"
    summaries = []
    with summary_path.open("x", encoding="utf-8") as stream:
        with ProcessPoolExecutor(max_workers=args.workers, mp_context=mp.get_context("spawn"),
                                 initializer=initialize, initargs=(str(manifest_path),)) as executor:
            futures = {executor.submit(work, entry): entry for entry in manifest["cases"]}
            for future in as_completed(futures):
                entry = futures[future]
                try:
                    summary = future.result()
                except Exception as exc:
                    summary = {"case_id": entry["case_id"], "status": "unknown_worker_failure_retained",
                               "failure": repr(exc)}
                summaries.append(summary)
                stream.write(encode(summary) + "\n"); stream.flush()
                print(encode({"completed": len(summaries), "expected": 96,
                              "case_id": entry["case_id"], "status": summary["status"],
                              "lower_total": summary.get("lower_total"),
                              "upper_total": summary.get("upper_total"),
                              "formal_validation": summary.get("formal_validation_status")}), flush=True)
    summaries.sort(key=lambda row: row["case_id"])
    new_json(out / "completion.json", {"expected_cases": 96, "retained_cases": len(summaries),
                                       "all_cases_retained": len(summaries) == 96,
                                       "source": manifest["source"], "summary": summaries})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    f = sub.add_parser("freeze")
    f.add_argument("--source", choices=("human", "model"), required=True)
    f.add_argument("--run-manifest", type=Path, required=True)
    f.add_argument("--selection", type=Path, required=True)
    f.add_argument("--frozen-root", type=Path, required=True)
    f.add_argument("--results", type=Path)
    f.add_argument("--out", type=Path, required=True)
    f.add_argument("--seconds", type=float, default=10.)
    f.add_argument("--relative-gap", type=float, default=.05)
    r = sub.add_parser("run")
    r.add_argument("--manifest", type=Path, required=True)
    r.add_argument("--workers", type=int, default=2)
    args = parser.parse_args()
    freeze(args) if args.command == "freeze" else run(args)


if __name__ == "__main__":
    main()
