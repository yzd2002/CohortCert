"""Reconcile ALL saved source-oracle cases with completed formal records.

Original oracle/precision artifacts are immutable. This pass can tighten only U
using an exactly verified source-valid proof at an actual formal prefix. It does
not run a primary policy, refit a proxy, or change the declared case selection.
"""
from __future__ import annotations
import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
from datetime import datetime, timezone
from fractions import Fraction
import gzip
import json
from math import ceil
import multiprocessing as mp
from pathlib import Path
from shutil import copy2
from time import perf_counter, process_time
import traceback
from types import SimpleNamespace

from driver import (compare_formal_record, encode, file_hash, new_gzip, new_json,
                    reconstruct_partition, require)
from oracle_core import Problem, independently_check_lagrange, proof_at
import source_batch_v1 as batch
from verify import verify_case

HERE = Path(__file__).resolve().parent
CONTEXT = {}


def read_gzip(path):
    with gzip.open(path, "rt", encoding="utf-8") as stream:
        return json.load(stream)


def freeze(args):
    oracle_path, recovery_path, rule_path = args.oracle_manifest.resolve(), args.recovery_manifest.resolve(), args.rule.resolve()
    original, recovery, rule = (json.loads(path.read_text()) for path in (oracle_path, recovery_path, rule_path))
    require(original["cases"] == recovery["cases"] and original["case_count"] == 96,
            "Reconciliation must retain the identical96 cases")
    require(original["source"] == recovery["source"] == rule["source"], "Reconciliation source mismatch")
    require(original["selection_sha256"] == rule["selection_sha256"], "Reconciliation changed the selection")
    args.out.mkdir(parents=True, exist_ok=False)
    snapshot = args.out / "source_snapshot"
    snapshot.mkdir()
    sources = {}
    for path in sorted(HERE.glob("*.py")):
        copy2(path, snapshot / path.name)
        sources[path.name] = file_hash(path)
    manifest = {"schema": "cohortcert.source-formal-reconciliation-v1",
                "created_utc": datetime.now(timezone.utc).isoformat(),
                "source": original["source"], "case_count": 96, "cases": original["cases"],
                "oracle_manifest_path": str(oracle_path), "oracle_manifest_sha256": file_hash(oracle_path),
                "recovery_manifest_path": str(recovery_path), "recovery_manifest_sha256": file_hash(recovery_path),
                "rule_path": str(rule_path), "rule_sha256": file_hash(rule_path),
                "oracle_code_sha256": sources, "workers_maximum": 2,
                "scope": "Formal validation and source-valid upper proof only; all original computations retained"}
    new_json(args.out / "reconciliation_manifest.json", manifest)
    print(encode({"status": "frozen", "manifest": str(args.out / "reconciliation_manifest.json"),
                  "sha256": file_hash(args.out / "reconciliation_manifest.json"), "cases": 96}))


def initialize(path):
    global CONTEXT
    path = Path(path)
    manifest = json.loads(path.read_text())
    for name, expected in manifest["oracle_code_sha256"].items():
        require(file_hash(path.parent / "source_snapshot" / name) == expected, "Reconciliation snapshot changed")
    for key in ("oracle_manifest", "recovery_manifest", "rule"):
        require(file_hash(manifest[key + "_path"]) == manifest[key + "_sha256"], "Reconciliation input changed: " + key)
    original = json.loads(Path(manifest["oracle_manifest_path"]).read_text())
    require(original["cases"] == manifest["cases"] and original["source"] == manifest["source"], "Reconciliation case/source mismatch")
    # The source-neutral initializer is byte-identical to the original oracle's
    # source-driver snapshot; no alternate initialization/proxy path is used.
    require(file_hash(batch.__file__) == original["oracle_code_sha256"]["source_batch_v1.py"],
            "Reconciliation source initializer differs from original oracle")
    batch.initialize(manifest["oracle_manifest_path"])
    CONTEXT = {"manifest": manifest, "oracle_root": Path(manifest["oracle_manifest_path"]).parent,
               "recovery_root": Path(manifest["recovery_manifest_path"]).parent,
               "output": path.parent / "cases"}


def work(entry):
    start, cpu_start = perf_counter(), process_time()
    context, original = CONTEXT, batch.CONTEXT
    source = original["manifest"]["source"]
    case_id = entry["case_id"]
    old = context["oracle_root"] / "cases" / case_id
    out = context["output"] / case_id
    out.mkdir(parents=True, exist_ok=False)
    summary = {"case_id": case_id, "source": source, "status": "validation_pending"}
    try:
        modules = original["modules"]
        check = verify_case(old, modules["theory_design.certificate_frontier"])
        summary["original_artifact_check"] = check
        if not (old / "actual_prefix_paths.json.gz").exists():
            summary["status"] = "unknown_original_case_retained"
            return summary
        pred = entry["predicate"]
        grid = original["grid"]
        if pred not in original["labels"]:
            from hashlib import sha256
            data = Path(grid["labels"][source][pred]).read_bytes()
            require(sha256(data).hexdigest() == grid["label_sha256"][source][pred], "Source map changed")
            labels = json.loads(data)
            require(set(labels) == set(original["snapshot"].record_ids()) and
                    all(type(value) is int and value in (0, 1) for value in labels.values()),
                    "Source map is not the complete fixed population")
            original["labels"][pred] = labels
        labels = original["labels"][pred]
        captured = read_gzip(old / "offline_initialization_capture.json.gz")
        state_payload = json.loads((old / "initial_n0_state.json").read_text())
        cells = tuple(SimpleNamespace(**{**cell, "coefficients": tuple(map(Fraction, cell["coefficients"]))})
                      for cell in state_payload["cells"])
        captured_state = SimpleNamespace(cells=cells)
        plan = modules["executor_v2.execution"].Plan(**captured["certificate"]["plan"]["settings"])
        query = original["queries"][entry["query_id"]]
        actual_cells, permutations, reconstruction = reconstruct_partition(
            query, original["snapshot"], captured_state, captured, plan, modules)
        paths_payload = read_gzip(old / "actual_prefix_paths.json.gz")
        paths = tuple(tuple(None if interval is None else tuple(interval) for interval in path)
                      for path in paths_payload["paths"])
        totals = tuple(sum(labels[rid] for rid in cell.records) for cell in actual_cells)
        require(totals == tuple(paths_payload["source_reference"]["cell_source_totals"]),
                "Saved oracle counts do not match the bound source map")
        atoms = tuple(SimpleNamespace(offset=a["offset"], coeff=tuple(a["coeff"])) for a in paths_payload["atoms"])
        family = tuple(tuple(tuple(w) for w in ws) for ws in paths_payload["family"])
        problem = Problem(atoms, family, tuple(paths_payload["allow_negative"]),
                          tuple(paths_payload["source_truth"]), paths, paths_payload["pilot_cost"],
                          paths_payload["mode"])
        records, provenance, missing = batch.formal_records(entry)
        checks, source_valid_candidates = [], []
        position = {cell.cell_id: h for h, cell in enumerate(actual_cells)}
        for record in records:
            prefix, result = compare_formal_record(record, captured, captured_state, permutations,
                                                   labels, query, original["snapshot"], modules)
            result["method"] = record["method"]
            for action in record["result"]["actions"]:
                expected = paths[position[action["cell_id"]]][action["prefix_after"]]
                provided = None if action["bounds"] is None else tuple(action["bounds"])
                require(expected == provided, "Actual formal CS endpoint differs from saved offline path")
            result["all_formal_action_bounds_match"] = True
            legal = all(path[n] is not None for path, n in zip(paths, prefix))
            result["oracle_legal_prefix"] = legal
            valid = proof_at(problem, prefix) if legal else None
            result["source_valid_proof_exists_at_algorithm_prefix"] = bool(valid and valid["complete"])
            require(not result["algorithm_correct_complete"] or result["source_valid_proof_exists_at_algorithm_prefix"],
                    "A correct formal answer lacks a source-valid oracle proof")
            if valid and valid["complete"]:
                source_valid_candidates.append((valid["total_calls"], record["method"], valid))
            checks.append(result)
        original_result = json.loads((old / "oracle_result.json").read_text())
        new_json(out / "formal_validation.json", {"checks": checks, "available": provenance, "missing": missing,
                                                  "reconstructed": reconstruction})
        if original_result["status"] == "verified_infeasible_max_legal_prefix":
            require(not source_valid_candidates, "Formal source-valid certificate contradicts monotone infeasibility")
            summary.update(status="verified_infeasible_reconciled" if not missing else "validation_pending_infeasible",
                           lower_total=None, upper_total=None, formal_checks=checks, formal_missing=missing)
            return summary
        lower, upper = original_result["lower_total"], original_result["upper_total"]
        original_upper = upper
        upper_proof = original_result["upper_proof"]
        upper_origin = "original_oracle"
        recovery_dir = context["recovery_root"] / "cases" / case_id
        recovered = recovery_dir / "recovered_dual_certificate.json.gz"
        if recovered.exists():
            certificate = read_gzip(recovered)
            lower_path = old / "verified_lower_bound_certificate.json.gz"
            require(file_hash(lower_path) == certificate["original_lower_certificate_sha256"], "Recovery binds another model")
            original_lower = read_gzip(lower_path)
            bound = independently_check_lagrange(original_lower["model"], certificate["proposal"]["multipliers"])
            require(bound == Fraction(certificate["proposal"]["rational_bound"]), "Recovered rational certificate mismatch")
            lower = max(lower, problem.pilot_cost + max(0, ceil(bound)))
        for cost, method, proof in source_valid_candidates:
            if cost < upper:
                upper, upper_origin, upper_proof = cost, "validated_" + method + "_prefix", proof
        require(lower <= upper, "Verified lower exceeds a checked source-valid upper after reconciliation")
        new_json(out / "combined_upper_proof.json", {"origin": upper_origin, "proof": upper_proof,
                                                   "original_upper": original_upper, "combined_lower": lower,
                                                   "combined_upper": upper,
                                                   "original_oracle_result_sha256": file_hash(old / "oracle_result.json")})
        summary.update(status="matched_all_three" if not missing else "validation_pending",
                       lower_total=lower, upper_total=upper, original_upper_total=original_upper,
                       upper_improved=upper < original_upper, upper_origin=upper_origin,
                       certified_relative_total_gap=(upper - lower) / max(1, upper),
                       formal_checks=checks, formal_missing=missing,
                       source_noncoverage_cells=sum(c["first_source_noncoverage_prefix"] is not None for c in paths_payload["coverage"]),
                       sticky_truncated_cells=sum(c["first_sticky_empty_prefix"] is not None for c in paths_payload["coverage"]))
    except Exception as exc:
        summary.update(status="unknown_reconciliation_failure_retained", failure={"class": type(exc).__name__,
                       "message": str(exc), "traceback": traceback.format_exc()})
    finally:
        summary["extra_wall_seconds"] = perf_counter() - start
        summary["extra_cpu_seconds"] = process_time() - cpu_start
        new_json(out / "reconciliation_summary.json", summary)
    return summary


def run(args):
    path = args.manifest.resolve()
    manifest = json.loads(path.read_text())
    require(1 <= args.workers <= 2, "At most two reconciliation workers")
    (path.parent / "cases").mkdir(exist_ok=False)
    summary = []
    with (path.parent / "reconciliation_results.jsonl").open("x") as stream:
        with ProcessPoolExecutor(max_workers=args.workers, mp_context=mp.get_context("spawn"),
                                 initializer=initialize, initargs=(str(path),)) as executor:
            futures = {executor.submit(work, entry): entry for entry in manifest["cases"]}
            for future in as_completed(futures):
                entry = futures[future]
                try:
                    row = future.result()
                except Exception as exc:
                    row = {"case_id": entry["case_id"], "status": "unknown_worker_failure_retained", "failure": repr(exc)}
                summary.append(row)
                stream.write(encode(row) + "\n"); stream.flush()
                print(encode({"completed": len(summary), "expected": 96, "case_id": entry["case_id"],
                              "status": row["status"], "lower_total": row.get("lower_total"),
                              "upper_total": row.get("upper_total")}), flush=True)
    summary.sort(key=lambda row: row["case_id"])
    new_json(path.parent / "completion.json", {"expected_cases": 96, "retained_cases": len(summary),
                                               "all_cases_retained": len(summary) == 96,
                                               "source": manifest["source"], "primary_policies_rerun": False,
                                               "summary": summary})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    f = sub.add_parser("freeze")
    f.add_argument("--oracle-manifest", type=Path, required=True)
    f.add_argument("--recovery-manifest", type=Path, required=True)
    f.add_argument("--rule", type=Path, required=True)
    f.add_argument("--out", type=Path, required=True)
    r = sub.add_parser("run")
    r.add_argument("--manifest", type=Path, required=True)
    r.add_argument("--workers", type=int, default=2)
    args = parser.parse_args()
    freeze(args) if args.command == "freeze" else run(args)


if __name__ == "__main__":
    main()
