"""Universal exact-decimal dual recovery on ALL saved oracle cases.

No primary policy, source labels, grids, or upper certificates are changed.
Extra optimization/arithmetic time is reported separately from v1's case budget.
"""
from __future__ import annotations
import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
from datetime import datetime, timezone
from fractions import Fraction
import gzip
import json
from math import ceil, isfinite
import multiprocessing as mp
from pathlib import Path
from shutil import copy2
from time import perf_counter, process_time
import traceback
import warnings

from driver import bootstrap, encode, file_hash, new_gzip, new_json, require
from oracle_core import independently_check_lagrange
from verify import verify_case

HERE = Path(__file__).resolve().parent
CONTEXT = {}


def freeze(args):
    v1path, rulepath = args.v1_manifest.resolve(), args.rule.resolve()
    v1, rule = json.loads(v1path.read_text()), json.loads(rulepath.read_text())
    require(v1["case_count"] == 96 and v1["source"] in ("human", "model"), "Source recovery must retain all96 cases")
    require(v1["selection_sha256"] == rule["selection_sha256"], "Precision rule changed the selection")
    args.out.mkdir(parents=True, exist_ok=False)
    snapshot = args.out / "source_snapshot"
    snapshot.mkdir()
    sources = {}
    for path in sorted(HERE.glob("*.py")):
        copy2(path, snapshot / path.name)
        sources[path.name] = file_hash(path)
    manifest = {"schema": "cohortcert.source-oracle-precision-recovery-v2", "source": v1["source"],
                "created_utc": datetime.now(timezone.utc).isoformat(),
                "v1_manifest_path": str(v1path), "v1_manifest_sha256": file_hash(v1path),
                "rule_path": str(rulepath), "rule_sha256": file_hash(rulepath),
                "case_count": 96, "cases": v1["cases"],
                "frozen_root": v1["frozen_root"], "core_root": v1["core_root"],
                "oracle_code_sha256": sources, "lp_seconds": rule["lp_seconds_per_saved_model"],
                "workers_maximum": 2, "native_threads": 1,
                "read_scope": "Saved oracle models, proofs and path artifacts only; no label map or primary raw rerun",
                "preservation": "All v1 files untouched; original U retained; best verified L retained"}
    new_json(args.out / "recovery_manifest.json", manifest)
    print(encode({"status": "frozen", "manifest": str(args.out / "recovery_manifest.json"),
                  "sha256": file_hash(args.out / "recovery_manifest.json"), "cases": 96}))


def initialize(path):
    global CONTEXT
    path = Path(path)
    manifest = json.loads(path.read_text())
    for name, expected in manifest["oracle_code_sha256"].items():
        require(file_hash(path.parent / "source_snapshot" / name) == expected, "Recovery source snapshot changed")
    require(file_hash(manifest["v1_manifest_path"]) == manifest["v1_manifest_sha256"], "V1 oracle manifest changed")
    require(file_hash(manifest["rule_path"]) == manifest["rule_sha256"], "Universal precision rule changed")
    v1 = json.loads(Path(manifest["v1_manifest_path"]).read_text())
    require(v1["cases"] == manifest["cases"] and v1["source"] == manifest["source"], "Recovery changed declared cases/source")
    completion = json.loads((Path(manifest["v1_manifest_path"]).parent / "completion.json").read_text())
    require(completion["all_cases_retained"] and completion["retained_cases"] == 96, "Wait for all v1 cases")
    CONTEXT = {"manifest": manifest, "modules": bootstrap(manifest["frozen_root"], manifest["core_root"]),
               "v1": Path(manifest["v1_manifest_path"]).parent,
               "out": path.parent / "cases"}


def propose(payload, seconds):
    import numpy as np
    from scipy.optimize import linprog
    from scipy.sparse import coo_matrix
    rr, cc, dd = [], [], []
    for i, row in enumerate(payload["rows_ge"]):
        for j, value in row.items():
            rr.append(i); cc.append(int(j)); dd.append(value)
    matrix = coo_matrix((np.asarray(dd, dtype=float), (rr, cc)),
                        shape=(len(payload["rows_ge"]), len(payload["names"]))).tocsc()
    er, ec = [], []
    for i, group in enumerate(payload["onehot_groups"]):
        er.extend([i] * len(group)); ec.extend(group)
    equality = coo_matrix((np.ones(len(er)), (er, ec)),
                          shape=(len(payload["onehot_groups"]), len(payload["names"]))).tocsc()
    wall, cpu = perf_counter(), process_time()
    with warnings.catch_warnings(record=True) as recorded:
        warnings.simplefilter("always")
        result = linprog(payload["costs"], A_ub=-matrix, b_ub=-np.asarray(payload["rhs"]),
                         A_eq=equality, b_eq=np.ones(len(payload["onehot_groups"])),
                         bounds=(0, 1), method="highs",
                         options={"time_limit": seconds, "threads": 1})
    lp_wall, lp_cpu = perf_counter() - wall, process_time() - cpu
    wall, cpu = perf_counter(), process_time()
    marginals = getattr(getattr(result, "ineqlin", None), "marginals", None)
    nonfinite = 0
    multipliers = [Fraction() for _ in payload["rows_ge"]]
    if marginals is not None:
        require(len(marginals) == len(multipliers), "LP multiplier count mismatch")
        multipliers = []
        for value in marginals:
            proposal = -float(value)
            if not isfinite(proposal):
                multipliers.append(Fraction()); nonfinite += 1
            else:
                multipliers.append(Fraction(str(max(0., proposal))))
    bound = independently_check_lagrange(payload, multipliers)
    return {"status": int(result.status), "message": result.message,
            "multipliers": list(map(str, multipliers)), "rational_bound": str(bound),
            "nonfinite_proposals_zeroed": nonfinite,
            "lp_wall_seconds": lp_wall, "lp_cpu_seconds": lp_cpu,
            "rational_wall_seconds": perf_counter() - wall,
            "rational_cpu_seconds": process_time() - cpu,
            "native_threads_requested": 1,
            "option_warnings": [str(item.message) for item in recorded]}


def work(entry):
    context, manifest = CONTEXT, CONTEXT["manifest"]
    start, cpu_start = perf_counter(), process_time()
    case_id = entry["case_id"]
    source = context["v1"] / "cases" / case_id
    out = context["out"] / case_id
    out.mkdir(parents=True, exist_ok=False)
    summary = {"case_id": case_id, "status": "unknown_retained", "source": manifest["source"]}
    try:
        summary["v1_artifact_check"] = verify_case(source, context["modules"]["theory_design.certificate_frontier"])
        result_path = source / "oracle_result.json"
        if not result_path.exists():
            summary.update(status="unchanged_v1_unknown_no_oracle_result")
            return summary
        v1 = json.loads(result_path.read_text())
        if v1["status"] == "verified_infeasible_max_legal_prefix":
            summary.update(status="unchanged_verified_infeasible", lower_total=None, upper_total=None)
            return summary
        summary.update(v1_lower_total=v1["lower_total"], original_upper_total=v1["upper_total"])
        certificate_path = source / "verified_lower_bound_certificate.json.gz"
        if not certificate_path.exists():
            summary.update(status="unchanged_no_saved_model", lower_total=v1["lower_total"],
                           upper_total=v1["upper_total"])
            return summary
        with gzip.open(certificate_path, "rt") as stream:
            certificate = json.load(stream)
        proposal = propose(certificate["model"], manifest["lp_seconds"])
        bound = Fraction(proposal["rational_bound"])
        lower = max(v1["lower_total"], v1["pilot_cost"] + max(0, ceil(bound)))
        upper = v1["upper_total"]
        require(lower <= upper, "Recovered exact lower exceeds a source-valid upper")
        # Independently invoke the frozen model's exact evaluator on the same
        # rational vector; neither floating solve status nor feasibility is used.
        frozen = context["modules"]["theory_design.certificate_frontier"]
        payload = certificate["model"]
        model = frozen.IntegerModel(payload["names"], payload["costs"],
                                    [{int(j): value for j, value in row.items()} for row in payload["rows_ge"]],
                                    payload["rhs"], payload["onehot_groups"], payload["onehot_groups"], (), [])
        require(model.rational_lower_bound(proposal["multipliers"]) == bound, "Independent exact evaluator mismatch")
        provenance = {"original_lower_certificate_path": str(certificate_path),
                      "original_lower_certificate_sha256": file_hash(certificate_path),
                      "original_oracle_result_path": str(result_path),
                      "original_oracle_result_sha256": file_hash(result_path),
                      "rule": "Exact Fraction of finite float decimal, no denominator cap",
                      "proposal": proposal, "combined_lower_total": lower, "unchanged_upper_total": upper,
                      "matrix_unchanged": True, "grids_unchanged": True,
                      "no_primary_or_source_labels_read": True}
        new_gzip(out / "recovered_dual_certificate.json.gz", provenance)
        summary.update(status="verified_combined_bounds", lower_total=lower, upper_total=upper,
                       lower_improved=lower > v1["lower_total"],
                       certified_relative_total_gap=(upper - lower) / max(1, upper),
                       lp_wall_seconds=proposal["lp_wall_seconds"], lp_cpu_seconds=proposal["lp_cpu_seconds"],
                       rational_wall_seconds=proposal["rational_wall_seconds"],
                       rational_cpu_seconds=proposal["rational_cpu_seconds"],
                       lp_status_diagnostic=proposal["status"])
    except Exception as exc:
        summary["failure"] = {"class": type(exc).__name__, "message": str(exc), "traceback": traceback.format_exc()}
    finally:
        summary["extra_wall_seconds"] = perf_counter() - start
        summary["extra_cpu_seconds"] = process_time() - cpu_start
        new_json(out / "recovery_summary.json", summary)
    return summary


def run(args):
    path = args.manifest.resolve()
    manifest = json.loads(path.read_text())
    require(1 <= args.workers <= 2, "At most two recovery workers")
    v1root = Path(manifest["v1_manifest_path"]).parent
    require((v1root / "completion.json").exists(), "Wait for v1 to finish; do not overlap two more workers")
    (path.parent / "cases").mkdir(exist_ok=False)
    summary = []
    with (path.parent / "recovery_results.jsonl").open("x") as stream:
        with ProcessPoolExecutor(max_workers=args.workers, mp_context=mp.get_context("spawn"),
                                 initializer=initialize, initargs=(str(path),)) as executor:
            futures = {executor.submit(work, entry): entry for entry in manifest["cases"]}
            for future in as_completed(futures):
                entry = futures[future]
                try:
                    row = future.result()
                except Exception as exc:
                    row = {"case_id": entry["case_id"], "status": "unknown_worker_failure_retained", "failure": repr(exc)}
                summary.append(row)
                stream.write(encode(row) + "\n"); stream.flush()
                print(encode({"completed": len(summary), "expected": 96, **row}), flush=True)
    summary.sort(key=lambda row: row["case_id"])
    new_json(path.parent / "completion.json", {"expected_cases": 96, "retained_cases": len(summary),
                                               "all_cases_retained": len(summary) == 96,
                                               "primary_policies_rerun": False,
                                               "model_maps_opened": False, "summary": summary})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    f = sub.add_parser("freeze")
    f.add_argument("--v1-manifest", type=Path, required=True)
    f.add_argument("--rule", type=Path, required=True)
    f.add_argument("--out", type=Path, required=True)
    r = sub.add_parser("run")
    r.add_argument("--manifest", type=Path, required=True)
    r.add_argument("--workers", type=int, default=2)
    args = parser.parse_args()
    freeze(args) if args.command == "freeze" else run(args)


if __name__ == "__main__":
    main()
