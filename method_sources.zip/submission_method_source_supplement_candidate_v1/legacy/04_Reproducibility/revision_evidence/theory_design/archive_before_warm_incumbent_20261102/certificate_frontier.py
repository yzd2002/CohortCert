"""Research prototype: exact finite-prefix certificate optimization.

Only synthetic path tables are used by the accompanying validation.  A path table
is permitted to inspect future labels ONLY in an offline evaluator or when its
labels are newly simulated from a working predictive law.  Never pass a real
unrevealed permutation to an online planner.

Core status/enumeration/dual verification uses only the standard library.
The optional optimizer imports SciPy locally.  Float solver status is not an exact
proof; every returned allocation is checked with integer arithmetic, and LP lower
bounds are reconstructed from arbitrary nonnegative rational multipliers.
"""

from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from itertools import product
from math import ceil, prod
from typing import Sequence


Interval = tuple[int, int]
Path = tuple[Interval | None, ...]
Family = tuple[tuple[tuple[int, ...], ...], ...]


@dataclass(frozen=True)
class Atom:
    """Integer-oriented atom offset + sum(coeff[h] * K[h]) > 0."""

    offset: int
    coeff: tuple[int, ...]


def atom_bounds(atoms: Sequence[Atom], endpoints: Sequence[Interval]):
    bounds = []
    for atom in atoms:
        lo = hi = atom.offset
        for a, (ell, upper) in zip(atom.coeff, endpoints):
            lo += a * (ell if a >= 0 else upper)
            hi += a * (upper if a >= 0 else ell)
        bounds.append((lo, hi))
    return tuple(bounds)


def decision_statuses(atoms: Sequence[Atom], family: Family,
                      endpoints: Sequence[Interval]):
    bounds = atom_bounds(atoms, endpoints)
    true_atoms = tuple(lo >= 1 for lo, _ in bounds)
    false_atoms = tuple(hi <= 0 for _, hi in bounds)
    statuses = []
    for witnesses in family:
        is_true = any(all(true_atoms[j] for j in witness)
                      for witness in witnesses)
        is_false = all(any(false_atoms[j] for j in witness)
                       for witness in witnesses)
        assert not (is_true and is_false)
        statuses.append(True if is_true else False if is_false else None)
    return tuple(statuses)


def complete(atoms: Sequence[Atom], family: Family,
             endpoints: Sequence[Interval], mode="bidirectional"):
    statuses = decision_statuses(atoms, family, endpoints)
    if mode == "positive":
        return all(value is True for value in statuses)
    if mode != "bidirectional":
        raise ValueError(mode)
    return all(value is not None for value in statuses)


def monotone_gains(atoms: Sequence[Atom], base: Sequence[Interval],
                   endpoints: Sequence[Interval]):
    """Per-atom positive/negative gains, retaining shared per-cell columns."""
    plus, minus = [], []
    for atom in atoms:
        gp, gm = [], []
        for a, (ell0, u0), (ell, upper) in zip(atom.coeff, base, endpoints):
            if not ell0 <= ell <= upper <= u0:
                raise ValueError("The theorem requires nested nonempty intervals")
            gp.append(a * (ell - ell0) if a >= 0 else -a * (u0 - upper))
            gm.append(a * (u0 - upper) if a >= 0 else -a * (ell - ell0))
        plus.append(tuple(gp))
        minus.append(tuple(gm))
    return tuple(plus), tuple(minus)


def gain_statuses(atoms: Sequence[Atom], family: Family,
                  base: Sequence[Interval], endpoints: Sequence[Interval]):
    """Independent algebraic reconstruction for exact-cover verification."""
    initial = atom_bounds(atoms, base)
    gp, gm = monotone_gains(atoms, base, endpoints)
    true_atoms = [sum(row) >= max(0, 1 - lo)
                  for row, (lo, _) in zip(gp, initial)]
    false_atoms = [sum(row) >= max(0, hi)
                   for row, (_, hi) in zip(gm, initial)]
    return tuple(True if any(all(true_atoms[j] for j in w) for w in ws)
                 else False if all(any(false_atoms[j] for j in w) for w in ws)
                 else None for ws in family)


def legal_length(path: Path):
    for k, endpoint in enumerate(path):
        if endpoint is None:
            return k - 1
    return len(path) - 1


def checked_paths(paths: Sequence[Path]):
    for path in paths:
        if not path or path[0] is None:
            raise ValueError("A valid current cell state is required")
        previous = path[0]
        failed = False
        for endpoint in path[1:]:
            if endpoint is None:
                failed = True
                continue
            if failed:
                raise ValueError("Failure must be sticky")
            if not previous[0] <= endpoint[0] <= endpoint[1] <= previous[1]:
                raise ValueError("Non-nested interval path")
            previous = endpoint


def enumerate_frontier(paths: Sequence[Path], atoms: Sequence[Atom],
                       family: Family, mode="bidirectional"):
    checked_paths(paths)
    best, plan = None, None
    for prefix in product(*(range(legal_length(path) + 1) for path in paths)):
        cost = sum(prefix)
        if best is not None and cost >= best:
            continue
        endpoints = tuple(path[n] for path, n in zip(paths, prefix))
        if complete(atoms, family, endpoints, mode):
            best, plan = cost, prefix
    return best, plan


def grid_options(paths: Sequence[Path], grids: Sequence[Sequence[int]], optimistic=False):
    """Return (cost,prefix) options. Optimism grants the next endpoint early."""
    options = []
    for path, grid in zip(paths, grids):
        grid = tuple(grid)
        if grid[0] != 0 or grid[-1] != legal_length(path):
            raise ValueError("Grid must include 0 and the last legal prefix")
        if any(a >= b for a, b in zip(grid, grid[1:])):
            raise ValueError("Grid must increase")
        if optimistic:
            local = [(grid[i], grid[i + 1]) for i in range(len(grid) - 1)]
            local.append((grid[-1], grid[-1]))
        else:
            local = [(n, n) for n in grid]
        options.append(tuple(local))
    return tuple(options)


def enumerate_options(paths: Sequence[Path], options, atoms, family, mode):
    best, chosen = None, None
    for indices in product(*(range(len(local)) for local in options)):
        cost = sum(options[h][k][0] for h, k in enumerate(indices))
        if best is not None and cost >= best:
            continue
        endpoints = tuple(paths[h][options[h][k][1]] for h, k in enumerate(indices))
        if complete(atoms, family, endpoints, mode):
            best, chosen = cost, indices
    return best, chosen


@dataclass
class IntegerModel:
    names: list[str]
    costs: list[int]
    rows: list[dict[int, int]]
    rhs: list[int]
    # Each group is exactly one. All variables outside these groups lie in [0,1].
    groups: list[tuple[int, ...]]
    xvars: list[tuple[int, ...]]
    options: tuple
    success_vars: list[int]

    def feasible(self, candidate):
        if len(candidate) != len(self.names):
            return False
        if any(value not in (0, 1) for value in candidate):
            return False
        if any(sum(candidate[j] for j in group) != 1 for group in self.groups):
            return False
        return all(sum(a * candidate[j] for j, a in row.items()) >= b
                   for row, b in zip(self.rows, self.rhs))

    def rational_lower_bound(self, multipliers):
        """Exact Lagrangian bound valid for ANY nonnegative rational vector."""
        multipliers = tuple(Fraction(value) for value in multipliers)
        if len(multipliers) != len(self.rows) or any(v < 0 for v in multipliers):
            raise ValueError("One nonnegative multiplier per >= constraint")
        reduced = [Fraction(c) for c in self.costs]
        bound = sum((lam * b for lam, b in zip(multipliers, self.rhs)), Fraction())
        for lam, row in zip(multipliers, self.rows):
            for j, a in row.items():
                reduced[j] -= lam * a
        grouped = set()
        for group in self.groups:
            bound += min(reduced[j] for j in group)
            grouped.update(group)
        bound += sum((min(Fraction(), value) for j, value in enumerate(reduced)
                      if j not in grouped), Fraction())
        return bound


def build_model(scenarios: Sequence[Sequence[Path]], options, atoms: Sequence[Atom],
                family: Family, mode="bidirectional", budget=None, frontier=False):
    """Compact dual-Boolean formulation. Options share costs/prefixes across S.

    frontier=True minimizes cost and requires success on every supplied scenario
    (normally exactly one realized path). Otherwise maximizes the scenario count.
    All scenarios must begin from the identical actual observed interval state.
    """
    if mode not in ("positive", "bidirectional"):
        raise ValueError(mode)
    if not scenarios:
        raise ValueError("At least one scenario is required")
    for paths in scenarios:
        checked_paths(paths)
    base = tuple(path[0] for path in scenarios[0])
    if any(tuple(path[0] for path in paths) != base for paths in scenarios):
        raise ValueError("Scenarios must share the current observed state")
    names, costs, rows, rhs, groups, xvars, success_vars = [], [], [], [], [], [], []

    def var(name, cost=0):
        index = len(names)
        names.append(name)
        costs.append(cost)
        return index

    def ge(row, bound):
        rows.append({j: a for j, a in row.items() if a})
        rhs.append(bound)

    for h, local in enumerate(options):
        group = tuple(var(f"x_{h}_{k}", cost if frontier else 0)
                      for k, (cost, _) in enumerate(local))
        groups.append(group)
        xvars.append(group)
    if budget is not None:
        ge({xvars[h][k]: -cost for h, local in enumerate(options)
            for k, (cost, _) in enumerate(local)}, -budget)
    initial = atom_bounds(atoms, base)
    for sidx, paths in enumerate(scenarios):
        success = var(f"success_{sidx}", 0 if frontier else -1)
        success_vars.append(success)
        if frontier:
            ge({success: 1}, 1)
        true_vars = [var(f"true_{sidx}_{j}") for j in range(len(atoms))]
        false_vars = [var(f"false_{sidx}_{j}") for j in range(len(atoms))]
        for h, local in enumerate(options):
            invalid = {xvars[h][k]: -1 for k, (_, n) in enumerate(local)
                       if n >= len(paths[h]) or paths[h][n] is None}
            if invalid:
                invalid[success] = -1
                ge(invalid, -1)
        for j, atom in enumerate(atoms):
            gp, gm = {}, {}
            for h, local in enumerate(options):
                a = atom.coeff[h]
                ell0, u0 = base[h]
                for k, (_, n) in enumerate(local):
                    if n >= len(paths[h]) or paths[h][n] is None:
                        continue
                    ell, upper = paths[h][n]
                    gp[xvars[h][k]] = (a * (ell - ell0) if a >= 0
                                      else -a * (u0 - upper))
                    gm[xvars[h][k]] = (a * (u0 - upper) if a >= 0
                                      else -a * (ell - ell0))
            gp[true_vars[j]] = -max(0, 1 - initial[j][0])
            gm[false_vars[j]] = -max(0, initial[j][1])
            ge(gp, 0)
            ge(gm, 0)
            ge({true_vars[j]: -1, false_vars[j]: -1, success: 1}, 0)
        for didx, witnesses in enumerate(family):
            pos = var(f"positive_{sidx}_{didx}")
            neg = var(f"negative_{sidx}_{didx}")
            ge({pos: 1, neg: 1, success: -1}, 0)
            ge({pos: -1, neg: -1, success: 1}, 0)
            if mode == "positive":
                ge({neg: -1}, 0)
            witness_vars = []
            for widx, witness in enumerate(witnesses):
                wvar = var(f"witness_{sidx}_{didx}_{widx}")
                witness_vars.append(wvar)
                ge({wvar: -1, success: 1}, 0)
                for j in witness:
                    ge({wvar: -1, true_vars[j]: 1}, 0)
                falsifier = {false_vars[j]: 1 for j in set(witness)}
                falsifier[neg] = -1
                ge(falsifier, 0)
            positive_row = {j: 1 for j in witness_vars}
            positive_row[pos] = -1
            ge(positive_row, 0)
    return IntegerModel(names, costs, rows, rhs, groups, xvars,
                        tuple(options), success_vars)


def solve_model(model: IntegerModel, time_limit=1.0, relaxation=False):
    """Optional SciPy solve with exact incumbent and rational-bound checking."""
    import numpy as np
    from scipy.optimize import Bounds, LinearConstraint, linprog, milp
    from scipy.sparse import coo_matrix

    rr, cc, dd = [], [], []
    for i, row in enumerate(model.rows):
        for j, a in row.items():
            rr.append(i)
            cc.append(j)
            dd.append(a)
    mat = coo_matrix((np.asarray(dd, dtype=float), (rr, cc)),
                     shape=(len(model.rows), len(model.names))).tocsc()
    er, ec = [], []
    for i, group in enumerate(model.groups):
        er.extend([i] * len(group))
        ec.extend(group)
    eq = coo_matrix((np.ones(len(er)), (er, ec)),
                    shape=(len(model.groups), len(model.names))).tocsc()
    if relaxation:
        result = linprog(model.costs, A_ub=-mat, b_ub=-np.asarray(model.rhs),
                         A_eq=eq, b_eq=np.ones(len(model.groups)),
                         bounds=(0, 1), method="highs",
                         options={"time_limit": time_limit})
        if result.success:
            multipliers = [Fraction(str(max(0.0, -float(value)))).limit_denominator(10**6)
                           for value in result.ineqlin.marginals]
        else:
            multipliers = [Fraction() for _ in model.rows]
        lower = model.rational_lower_bound(multipliers)
        return {"status": int(result.status), "message": result.message,
                "rational_lower_bound": lower,
                "integer_objective_lower_bound": ceil(lower),
                "multipliers": multipliers}
    constraints = [LinearConstraint(mat, np.asarray(model.rhs), np.inf),
                   LinearConstraint(eq, 1, 1)]
    result = milp(np.asarray(model.costs, dtype=float),
                  integrality=np.ones(len(model.names)), bounds=Bounds(0, 1),
                  constraints=constraints,
                  options={"time_limit": time_limit, "mip_rel_gap": 0.0})
    candidate = None if result.x is None else tuple(int(round(v)) for v in result.x)
    valid = candidate is not None and model.feasible(candidate)
    if not valid:
        candidate = None
    plan = None
    if candidate is not None:
        plan = tuple(model.options[h][next(k for k, j in enumerate(group) if candidate[j])][1]
                     for h, group in enumerate(model.xvars))
    return {"status": int(result.status), "message": result.message,
            "exact_incumbent_verified": valid, "candidate": candidate,
            "plan": plan,
            "exact_objective": None if candidate is None else
                sum(a * value for a, value in zip(model.costs, candidate)),
            "solver_reported_bound_unverified": getattr(result, "mip_dual_bound", None),
            "solver_reported_gap_unverified": getattr(result, "mip_gap", None)}


def saa_epsilon(number_scenarios, number_plans, delta):
    """Uniform q-model error; small S commonly makes this bound vacuous."""
    from math import log, sqrt
    return sqrt(log(2 * number_plans / delta) / (2 * number_scenarios))


def exact_path(labels, alpha=Fraction(1, 20), priors=((1, 1, Fraction(1)),)):
    """Tiny exact finite-population mixture CS; never intended for full data."""
    N = len(labels)
    ell, upper, s = 0, N, 0
    path = [(ell, upper)]
    failed = False
    for n, label in enumerate(labels, 1):
        s += label
        if failed:
            path.append(None)
            continue
        q = predictive_mass(n, s, priors)
        accepted = []
        for K in range(s, N - n + s + 1):
            p = Fraction(_fall(K, s) * _fall(N - K, n - s), _fall(N, n))
            if p > alpha * q:
                accepted.append(K)
        # Exhaustion is still an intersection; never overwrite prior evidence.
        accepted = [K for K in accepted if ell <= K <= upper]
        if n == N:
            accepted = [K for K in accepted if K == s]
        if not accepted:
            failed = True
            path.append(None)
        else:
            ell, upper = min(accepted), max(accepted)
            path.append((ell, upper))
    return tuple(path)


def _fall(a, n):
    return prod(a - k for k in range(n))


def _rise(a, n):
    return prod(a + k for k in range(n))


def predictive_mass(n, s, priors):
    """Ordered-sequence probability under an integer Beta-mixture prior."""
    return sum((weight * Fraction(_rise(a, s) * _rise(b, n - s), _rise(a + b, n))
                for a, b, weight in priors), Fraction())


def predict_next(n, s, priors):
    denominator = predictive_mass(n, s, priors)
    probs = tuple(predictive_mass(n + 1, s + bit, priors) / denominator
                  for bit in (0, 1))
    assert sum(probs) == 1
    return probs
