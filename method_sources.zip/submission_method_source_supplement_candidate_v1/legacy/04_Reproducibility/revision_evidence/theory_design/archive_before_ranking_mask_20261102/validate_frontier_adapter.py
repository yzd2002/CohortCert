"""Synthetic read-only adapter checks; no dataset or inference API is used."""
from fractions import Fraction
from dataclasses import replace
from itertools import product
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from executor_v2.state import AcquisitionState, AtomView, CellView, Choice, FamilyView
from executor_v2.frontier_policy import ForecastFrontierPolicy, ScenarioFrontierPolicy, _forecast_grid, _grid
import executor_v2.frontier_policy as frontier_module
from theory_design.certificate_frontier import _fall, predictive_mass


class ExactTinyCS:
    def __init__(self, N, alpha, a, b, lam):
        self.N, self.alpha = N, Fraction(str(alpha))
        self.a, self.b, self.lam = int(a), int(b), Fraction(str(lam))
        self.n = self.s = 0

    def _accepts(self, K):
        if not self.s <= K <= self.N - self.n + self.s:
            return False
        p = Fraction(_fall(K, self.s) * _fall(self.N - K, self.n - self.s),
                     _fall(self.N, self.n))
        q = predictive_mass(self.n, self.s, ((1, 1, 1 - self.lam),
                                           (self.a, self.b, self.lam)))
        return p > self.alpha * q


class StubFallback:
    def choose(self, state):
        cell = next(cell for cell in state.cells if cell.n < cell.N)
        return Choice(cell.cell_id, min(state.batch_size, state.remaining_calls, cell.N - cell.n),
                      {"policy": "synthetic_stub"})


def fixture():
    cells = tuple(CellView(h, N, 0, 0, 0, N, .05, 1., 1., .5,
                           tuple(Fraction(i == h) for i in range(3)))
                  for h, N in enumerate((1, 1, 3)))
    atoms = tuple(AtomView(i, "lower", Fraction(2 if i == 2 else 0), i, str(i), ())
                  for i in range(3))
    family = FamilyView(atoms, ((0, 1), (2,)), (0, 0), ("synthetic",))
    return AcquisitionState(cells, family,
                            {0: (Fraction(0), Fraction(1)),
                             1: (Fraction(0), Fraction(1)),
                             2: (Fraction(0), Fraction(3))},
                            {0: Fraction(), 1: Fraction(), 2: Fraction()},
                            2, 0, 1, "positive_only", {h: 1 for h in range(3)})


def shared_cover_fixture():
    coeffs = ((1, 1), (1, 0), (0, 1))
    cells = tuple(CellView(h, 1, 0, 0, 0, 1, .05, 1., 1., .5,
                           tuple(Fraction(a) for a in coeffs[h])) for h in range(3))
    atoms = tuple(AtomView(j, "lower", Fraction(), j, str(j), ()) for j in range(2))
    family = FamilyView(atoms, ((0, 1),), (0,), ("synthetic_shared_cover",))
    return AcquisitionState(cells, family, {j: (Fraction(), Fraction(2)) for j in range(2)},
                            {j: Fraction() for j in range(2)}, 2, 0, 1,
                            "positive_only", {h: 1 for h in range(3)})


def warm_incumbent_checks():
    shared = shared_cover_fixture()
    solver_success = ForecastFrontierPolicy(time_limit=.1, max_wall_seconds=1,
                                           fallback=StubFallback()).choose(shared)
    assert solver_success.diagnostics["warm_greedy_cost"] == 2
    assert solver_success.diagnostics["mip_incumbent_cost"] == 1
    assert solver_success.diagnostics["allocation_source"] == "checked_mip_incumbent"
    assert solver_success.cell_id == 0
    original = frontier_module.solve_model
    def no_incumbent(*args, **kwargs):
        return {"status": 1, "message": "synthetic forced no-incumbent timeout",
                "exact_incumbent_verified": False,
                "solver_reported_bound_unverified": None,
                "solver_reported_gap_unverified": None}
    try:
        frontier_module.solve_model = no_incumbent
        warm_only = ForecastFrontierPolicy(max_wall_seconds=1, fallback=StubFallback()).choose(shared)
    finally:
        frontier_module.solve_model = original
    assert warm_only.cell_id in (1, 2)
    assert warm_only.diagnostics["warm_model_candidate_verified"]
    assert warm_only.diagnostics["exact_incumbent_verified"]
    assert warm_only.diagnostics["mip_no_incumbent_action"] == "use_checked_warm_plan"
    assert warm_only.diagnostics["allocation_source"] == "warm_coordinate_plan"
    assert warm_only.diagnostics["fallback_reason"] is None
    return {"scope": "constructed sharing and forced-timeout checks, not empirical efficacy",
            "mip_beats_coordinate_plan": dict(solver_success.diagnostics),
            "no_mip_incumbent_uses_verified_warm_plan": dict(warm_only.diagnostics)}


def main():
    state = fixture()
    policy = ScenarioFrontierPolicy(ExactTinyCS, seed=11203, S=16, horizon=8,
                                    time_limit=.1, max_wall_seconds=1,
                                    fallback=StubFallback())
    choice = policy.choose(state)
    assert choice.cell_id in (0, 1) and choice.batch == 1
    assert choice.diagnostics["exact_incumbent_verified"]
    assert choice.diagnostics["empirical_completed_scenarios"] > 0
    assert choice.diagnostics["planned_cell_prefixes"] == {"0": 1, "1": 1, "2": 0}
    success = dict(choice.diagnostics)
    # A planning timeout retains a previously feasible allocation, then uses an
    # explicit fallback when no prior allocation exists.
    policy.max_wall_seconds = 0
    retained = policy.choose(state)
    assert retained.diagnostics["fallback_policy"] == "retained_frontier_allocation"
    cold = ScenarioFrontierPolicy(ExactTinyCS, seed=1, max_wall_seconds=0,
                                  fallback=StubFallback()).choose(state)
    assert cold.diagnostics["fallback_policy"] == "StubFallback"
    # Analytical hypergeometric mode agrees with full integer enumeration.
    checked = 0
    diagnostic = {"raw_cache_hits": 0, "raw_interval_computations": 0}
    for N in range(2, 9):
        cell = CellView(N, N, 0, 0, 0, N, .2, 2., 5., .5, (Fraction(1),))
        for n in range(1, N):
            for s in range(n + 1):
                probe = ExactTinyCS(N, .2, 2., 5., .5)
                probe.n, probe.s = n, s
                accepted = [K for K in range(s, N - n + s + 1) if probe._accepts(K)]
                expected = None if not accepted else (min(accepted), max(accepted))
                assert policy._raw(cell, n, s, diagnostic) == expected
                checked += 1
    forecast = ForecastFrontierPolicy(time_limit=.1, max_wall_seconds=1,
                                      fallback=StubFallback())
    first = forecast.choose(state)
    assert first.diagnostics["exact_incumbent_verified"]
    assert first.diagnostics["planned_cell_prefixes"] == {"0": 1, "1": 1, "2": 0}
    assert first.cell_id in (0, 1)
    observed_cells = tuple(replace(cell, n=1, s=1, lower=1, upper=1)
                           if cell.cell_id == first.cell_id else cell for cell in state.cells)
    observed_bounds = dict(state.bounds)
    observed_bounds[first.cell_id] = (Fraction(1), Fraction(1))
    observed = replace(state, cells=observed_cells, bounds=observed_bounds,
                       step=1, remaining_calls=1)
    second = forecast.choose(observed)
    assert second.cell_id == 1 - first.cell_id
    assert second.diagnostics["reused_allocation"]
    nested = 0
    for N, n, s, lo, hi in ((1000, 16, 8, 8, 992), (1000, 999, 200, 200, 201),
                            (10, 0, 0, 0, 10), (8, 8, 3, 3, 3)):
        cell = CellView(0, N, n, s, lo, hi, .05, 4., 7., .5, (Fraction(1),))
        grid = _grid(N - n, 16, 6)
        endpoints, center = _forecast_grid(cell, grid)
        assert endpoints[0] == (lo, hi)
        assert endpoints[-1] == (center, center)
        assert all(a <= c <= d <= b for (a, b), (c, d) in zip(endpoints, endpoints[1:]))
        nested += 1
    receipt = {"scope": "synthetic adapter/timeout/feasibility checks only",
               "success": success, "retained_timeout": dict(retained.diagnostics),
               "cold_timeout": dict(cold.diagnostics),
               "analytical_mode_vs_exact_raw_intervals_checked": checked,
               "forecast_first": dict(first.diagnostics),
               "forecast_reused_after_actual_observation": dict(second.diagnostics),
               "forecast_nested_grid_fixtures": nested,
               "warm_incumbent_checks": warm_incumbent_checks()}
    out = ROOT / "theory_design" / "frontier_adapter_validation.json"
    out.write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
