"""Read-only reconciliation; no executor, planner, confidence update or solver imports."""
from pathlib import Path
from decimal import Decimal
from collections import Counter
import csv
import gzip
import hashlib
import json
import statistics
import datetime

ROOT = Path('/root/autodl-tmp/cohortcert_strong_revision_20261102')
OUT = Path(__file__).resolve().parent
SNAP = OUT / 'read_snapshot'
claimed = json.loads((SNAP / 'SUMMARY.json').read_text())
records = [json.loads(line) for line in (SNAP / 'all_192_cases.jsonl').read_text().splitlines()]
by_key = {(r['source'], r['query_id'], r['seed_id']): r for r in records}
assert len(records) == len(by_key) == 192
errors = []
checked = []
read_hashes = {}

def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()

for rel, expected in claimed['source_sha256'].items():
    actual = sha(ROOT / rel)
    read_hashes[rel] = actual
    if actual != expected:
        errors.append({'source_hash_mismatch': rel})

tables = {}
for source in ['human', 'model']:
    with (ROOT / 'oracle_evaluation' / f'{source}_headroom_cases_v2.csv').open() as handle:
        for row in csv.DictReader(handle):
            if row['method'] == 'forecast':
                tables[(source, row['query_id'], int(row['seed_id']))] = row
assert set(tables) == set(by_key)

for rel in sorted(claimed['source_sha256']):
    if 'results/shards/' not in rel:
        continue
    with gzip.open(ROOT / rel, 'rb') as handle:
        for raw_line in handle:
            raw = json.loads(raw_line)
            key = (raw['source'], raw['query_id'], raw['seed_id'])
            if key not in by_key:
                continue
            report = by_key[key]
            table = tables[key]
            source, query, seed = key
            case_path = ROOT / 'oracle_evaluation' / f'{source}_oracle_v1/cases' / report['case_id'] / 'case_summary.json'
            case = json.loads(case_path.read_text())
            result = raw['result']
            pilot = sum(r['submitted'] for r in result['read_receipts'] if r['phase'] == 'pilot')
            formal = [r for r in result['read_receipts'] if r['phase'] != 'pilot']
            assert len(formal) == len(result['actions'])
            assert sum(r['submitted'] for r in result['read_receipts']) == result['certificate']['semantic_calls']
            before = pilot
            prefixes = {}
            first = None
            for index, action in enumerate(result['actions']):
                diagnostics = action.get('diagnostics') or {}
                if (action['source'] == 'policy' and diagnostics.get('exact_incumbent_verified')
                        and not diagnostics.get('reused_allocation')
                        and type(diagnostics.get('predicted_required_calls_incumbent')) is int):
                    assert before == pilot + sum(prefixes.values())
                    assert before == pilot + sum(r['submitted'] for r in formal[:index])
                    extra = diagnostics['predicted_required_calls_incumbent']
                    assert extra == sum(diagnostics['planned_cell_prefixes'].values())
                    first = {'action_index': index, 'allocation_source': diagnostics.get('allocation_source'),
                             'prior_charged_calls': before, 'predicted_additional_calls': extra,
                             'predicted_total': before + extra}
                    break
                assert formal[index]['submitted'] == len(action['record_ids'])
                before += formal[index]['submitted']
                prefixes[action['cell_id']] = action['prefix_after']
            assert first == report['first_fresh_feasible_forecast']
            lower = Decimal(table['oracle_lower_total']) if table['oracle_lower_total'] else None
            upper = Decimal(table['oracle_upper_total']) if table['oracle_upper_total'] else None
            assert (None if lower is None else float(lower)) == report['oracle_lower_total']
            assert (None if upper is None else float(upper)) == report['oracle_upper_total']
            coverage = case['source_noncoverage_cells'] == 0
            assert coverage == report['full_path_source_coverage']
            finite_under = first is not None and lower is not None and lower.is_finite() and Decimal(first['predicted_total']) < lower
            assert finite_under == report['finite_understatement']
            no_proof = case['status'] == 'verified_infeasible_max_legal_prefix'
            assert no_proof == report['no_source_valid_proof']
            assert result['certificate']['semantic_calls'] == report['actual_calls'] == int(table['actual_calls'])
            assert report['actual_correct_complete'] == (table['correct_complete'] == 'True')
            checked.append({'case_id': report['case_id'], 'source': source, 'covered': coverage,
                            'first_plan': first, 'finite_understatement': finite_under,
                            'explicit_verified_no_proof': no_proof,
                            'raw_record_sha256': hashlib.sha256(raw_line).hexdigest()})
assert len(checked) == len({x['case_id'] for x in checked}) == 192

counts = {}
for source in ['human', 'model']:
    rr = [r for r in checked if r['source'] == source]
    clean = [r for r in rr if r['covered']]
    counts[source] = {'all_cases': len(rr), 'covered': len(clean),
                      'covered_with_plan': sum(r['first_plan'] is not None for r in clean),
                      'covered_finite_understatements': sum(r['finite_understatement'] for r in clean),
                      'off_coverage': sum(not r['covered'] for r in rr),
                      'off_coverage_finite_understatements': sum(not r['covered'] and r['finite_understatement'] for r in rr),
                      'explicit_verified_no_proof': sum(r['explicit_verified_no_proof'] for r in rr)}
    assert counts[source]['covered_finite_understatements'] == claimed['summary'][source]['covered_finite_cost_understatements']
    assert counts[source]['covered'] == claimed['summary'][source]['source_covered_cases']

policy = ROOT / 'policy_freeze_v1/executor_v2/frontier_policy.py'
read_hashes[str(policy.relative_to(ROOT))] = sha(policy)
receipt = {'checked_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'scope': 'Independently reconciled all192 first-plan costs, prior receipt and prefix ledgers, recorded plan sums, CSV bounds, coverage flags and explicit no-proof status; did not reverify underlying CS or rational bound proofs.',
           'raw_records_reconciled': len(checked), 'declared_source_hashes_checked': len(claimed['source_sha256']),
           'discrepancies': errors, 'counts': counts, 'read_sha256': read_hashes,
           'model_forwards': 0, 'policy_invocations': 0, 'solver_invocations': 0}
(OUT / 'INDEPENDENT_UNITS_AUDIT.json').write_text(json.dumps(receipt, indent=2) + '\n')
(OUT / 'independent_checked_cases.jsonl').write_text(''.join(json.dumps(r, sort_keys=True) + '\n' for r in checked))
print(json.dumps({'status': 'passed' if not errors else 'failed', 'records': len(checked), 'hashes': len(claimed['source_sha256']), 'counts': counts, 'errors': errors}, indent=2))
