from pathlib import Path
import json,csv,gzip,hashlib,statistics,math
ROOT=Path(__file__).resolve().parent.parent;OUT=Path(__file__).resolve().parent
hashes={}
def loadjson(p):
 b=p.read_bytes();hashes[str(p.relative_to(ROOT))]=hashlib.sha256(b).hexdigest();return json.loads(b)
protocol=loadjson(OUT/'POSTHOC_PROTOCOL_BEFORE_COMPUTATION.json')
rows={};details={}
for source in ['human','model']:
 p=ROOT/'oracle_evaluation'/f'{source}_headroom_cases_v2.csv';hashes[str(p.relative_to(ROOT))]=hashlib.sha256(p.read_bytes()).hexdigest()
 for r in csv.DictReader(p.open()):
  if r['method']=='forecast':rows[(source,r['query_id'],int(r['seed_id']))]=r
 for p in (ROOT/'oracle_evaluation'/f'{source}_oracle_v1/cases').glob('*/case_summary.json'):
  d=loadjson(p);details[(source,d['case_metadata']['query_id'],int(d['case_metadata']['seed_id']))]=d
assert len(rows)==len(details)==192
out=[]
for source in ['human','model']:
 m=loadjson(ROOT/f'grid_{source}50_v1/run_manifest.json')
 for s in m['shards']:
  if s['method']!='forecast' or s['seed_id'] not in [0,1]:continue
  path=ROOT/f'grid_{source}50_v1/results/shards'/(s['name']+'.jsonl.gz')
  hashes[str(path.relative_to(ROOT))]=hashlib.sha256(path.read_bytes()).hexdigest()
  with gzip.open(path,'rb') as f:
   for b in f:
    p=json.loads(b);key=(source,p['query_id'],p['seed_id'])
    if key not in rows:continue
    r=rows[key];d=details[key];result=p['result']
    before=sum(x['submitted'] for x in result['read_receipts'] if x['phase']=='pilot')
    found=None
    for ai,a in enumerate(result['actions']):
     diag=a.get('diagnostics') or {}
     if a['source']=='policy' and diag.get('exact_incumbent_verified') and not diag.get('reused_allocation') and type(diag.get('predicted_required_calls_incumbent')) is int:
      found={'action_index':ai,'prior_charged_calls':before,'predicted_additional_calls':diag['predicted_required_calls_incumbent'],'predicted_total':before+diag['predicted_required_calls_incumbent'],'allocation_source':diag.get('allocation_source')};break
     before+=len(a['record_ids'])
    L=float(r['oracle_lower_total']);U=float(r['oracle_upper_total'])
    cov=d.get('source_noncoverage_cells',0)==0
    record={'case_id':r['case_id'],'source':source,'query_id':p['query_id'],'seed_id':p['seed_id'],'full_path_source_coverage':cov,'noncoverage_cells':d.get('source_noncoverage_cells',0),'oracle_lower_total':None if not math.isfinite(L) else L,'oracle_upper_total':None if not math.isfinite(U) else U,'no_source_valid_proof':not math.isfinite(U),'first_fresh_feasible_forecast':found,'finite_understatement':bool(found and math.isfinite(L) and found['predicted_total']<L),'oracle_relative_total_gap':float(r['certified_relative_total_gap']) if math.isfinite(float(r['certified_relative_total_gap'])) else None,'actual_calls':int(r['actual_calls']),'actual_correct_complete':r['correct_complete']=='True','cap':int(r['cap'])}
    out.append(record)
assert len(out)==len(set(x['case_id'] for x in out))==192
summary={}
for source in ['human','model']:
 rr=[r for r in out if r['source']==source];clean=[r for r in rr if r['full_path_source_coverage']];planned=[r for r in clean if r['first_fresh_feasible_forecast']];uncov=[r for r in rr if not r['full_path_source_coverage']]
 summary[source]={'all_cases':len(rr),'source_covered_cases':len(clean),'covered_with_plan':len(planned),'covered_without_plan':len(clean)-len(planned),'covered_finite_cost_understatements':sum(x['finite_understatement'] for x in clean),'covered_not_demonstrably_understated':sum(not x['finite_understatement'] for x in planned),'covered_planned_median_oracle_total_relative_gap':statistics.median(x['oracle_relative_total_gap'] for x in planned),'off_coverage_cases':len(uncov),'off_coverage_finite_understatements':sum(x['finite_understatement'] for x in uncov),'off_coverage_no_source_proof':sum(x['no_source_valid_proof'] for x in uncov),'all_no_plan_cases':sum(x['first_fresh_feasible_forecast'] is None for x in rr)}
report={'scope':protocol,'case_count':len(out),'summary':summary,'source_sha256':hashes,'model_forwards':0,'policy_calls':0,'solver_calls':0}
(OUT/'all_192_cases.jsonl').write_text(''.join(json.dumps(x,sort_keys=True,allow_nan=False)+'\n' for x in sorted(out,key=lambda r:r['case_id'])))
(OUT/'SUMMARY.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n');print(json.dumps(summary,indent=2))
