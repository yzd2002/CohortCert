"""Pinned-environment check of SciPy forwarding and native HiGHS acceptance."""
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import scipy
from scipy.optimize import _milp, _linprog_highs
from scipy.optimize._highspy import _core
from theory_design.certificate_frontier import Atom, build_model, solve_model


def main():
    native = _core._Highs()
    status = native.setOptionValue("threads", 1)
    get_status, value = native.getOptionValue("threads")
    assert status == get_status == _core.HighsStatus.kOk and value == 1
    captured = []
    originals = (_milp._highs_wrapper, _linprog_highs._highs_wrapper)
    def wrapper(original, label):
        def call(*args, **kwargs):
            options = kwargs.get("options", args[-1] if args else {})
            captured.append({"call": label, "native_threads_forwarded": options.get("threads")})
            return original(*args, **kwargs)
        return call
    _milp._highs_wrapper = wrapper(originals[0], "milp")
    _linprog_highs._highs_wrapper = wrapper(originals[1], "linprog")
    try:
        model = build_model(((((0, 1), (1, 1)),),), (((0, 0), (1, 1)),),
                            (Atom(0, (1,)),), (((0,),),), mode="positive", frontier=True)
        mip = solve_model(model)
        lp = solve_model(model, relaxation=True)
    finally:
        _milp._highs_wrapper, _linprog_highs._highs_wrapper = originals
    assert len(captured) == 2 and all(item["native_threads_forwarded"] == 1 for item in captured)
    assert mip["exact_incumbent_verified"] and mip["exact_objective"] == 1
    assert lp["rational_lower_bound"] <= 1
    assert mip["solver_native_threads_requested"] == lp["solver_native_threads_requested"] == 1
    receipt = {
        "scope": "Pinned local option acceptance and forwarding, not a general concurrency guarantee",
        "scipy_version": scipy.__version__,
        "native_set_option_status": str(status),
        "native_get_option_status": str(get_status),
        "native_threads_after_set": value,
        "wrapper_calls": captured,
        "mip_exact_incumbent": mip["exact_objective"],
        "lp_exact_rational_lower_bound": str(lp["rational_lower_bound"]),
        "mip_recorded_warning": mip["solver_option_warnings"],
        "lp_recorded_warning": lp["solver_option_warnings"],
        "intent": "All project MILP/LP solves request native threads=1, even though SciPy warns and forwards it verbatim",
    }
    (ROOT / "theory_design" / "native_solver_threads_validation.json").write_text(
        json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
