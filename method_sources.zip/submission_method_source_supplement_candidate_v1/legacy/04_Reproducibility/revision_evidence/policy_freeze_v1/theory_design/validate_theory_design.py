"""Small exhaustive mathematical checks; no engine imports or real labels."""

from __future__ import annotations

from fractions import Fraction
from hashlib import sha256
from itertools import product
from math import prod
from pathlib import Path
import json

from certificate_frontier import (
    Atom, atom_bounds, build_model, complete, decision_statuses, enumerate_frontier,
    enumerate_options, exact_path, gain_statuses, grid_options, legal_length,
    monotone_gains, predictive_mass, saa_epsilon, solve_model,
    negative_completion_mask,
)


HERE = Path(__file__).resolve().parent
ATOMS = (
    Atom(0, (1, -1)),
    Atom(0, (-1, 1)),
    Atom(-2, (1, 1)),
    Atom(1, (-1, 0)),
)
FAMILY = (((0,), (1,)), ((2, 3),))


def all_paths(N, alpha=Fraction(1, 5)):
    return [(bits, exact_path(bits, alpha)) for bits in product((0, 1), repeat=N)]


def status_and_grid_checks():
    counts = {"path_pairs": 0, "prefix_allocations": 0, "covered_status_checks": 0,
              "masked_completion_allocations_checked": 0,
              "finite_grid_frontiers": 0}
    retained = []
    for (bits0, p0), (bits1, p1) in product(all_paths(2), all_paths(3)):
        paths = (p0, p1)
        base = (p0[0], p1[0])
        truth_endpoints = ((sum(bits0), sum(bits0)), (sum(bits1), sum(bits1)))
        truth = decision_statuses(ATOMS, FAMILY, truth_endpoints)
        counts["path_pairs"] += 1
        for n0, n1 in product(range(legal_length(p0) + 1), range(legal_length(p1) + 1)):
            endpoints = (p0[n0], p1[n1])
            observed = decision_statuses(ATOMS, FAMILY, endpoints)
            assert observed == gain_statuses(ATOMS, FAMILY, base, endpoints)
            plus, minus = monotone_gains(ATOMS, base, endpoints)
            assert all(value >= 0 for rows in (plus, minus) for row in rows for value in row)
            counts["prefix_allocations"] += 1
            for mask in product((False, True), repeat=len(FAMILY)):
                expected = tuple(None if value is False and not allow else value
                                 for value, allow in zip(observed, mask))
                assert decision_statuses(ATOMS, FAMILY, endpoints, allow_negative=mask) == expected
                assert gain_statuses(ATOMS, FAMILY, base, endpoints, allow_negative=mask) == expected
                assert complete(ATOMS, FAMILY, endpoints, "bidirectional", allow_negative=mask) == all(
                    value is not None for value in expected)
                assert complete(ATOMS, FAMILY, endpoints, "positive", allow_negative=mask) == all(
                    value is True for value in observed)
                counts["masked_completion_allocations_checked"] += 1
            covered = all(lo <= total <= upper for (lo, upper), total in
                          zip(endpoints, (sum(bits0), sum(bits1))))
            if covered:
                for value, true_value in zip(observed, truth):
                    if value is not None:
                        assert value == true_value
                        counts["covered_status_checks"] += 1
        grids = tuple(tuple(sorted({0, legal_length(path) // 2, legal_length(path)}))
                      for path in paths)
        for mode in ("positive", "bidirectional"):
            exact, _ = enumerate_frontier(paths, ATOMS, FAMILY, mode)
            opt_options = grid_options(paths, grids, optimistic=True)
            actual_options = grid_options(paths, grids, optimistic=False)
            lower, selected = enumerate_options(paths, opt_options, ATOMS, FAMILY, mode)
            upper, _ = enumerate_options(paths, actual_options, ATOMS, FAMILY, mode)
            if exact is None:
                assert lower is None and upper is None
                continue
            gap = sum(max((b - a for a, b in zip(grid, grid[1:])), default=0)
                      for grid in grids)
            assert lower <= exact <= upper <= lower + gap
            rounded_cost = sum(opt_options[h][k][1] for h, k in enumerate(selected))
            selected_gap = rounded_cost - lower
            assert upper <= rounded_cost <= lower + gap
            counts["finite_grid_frontiers"] += 1
            if len(retained) < 6:
                retained.append((paths, mode, exact, grids, lower, upper, selected_gap))
    return counts, retained


def mip_and_dual_checks(retained):
    checks = []
    for paths, mode, exact, grids, enum_lower, enum_upper, selected_gap in retained:
        opt_options = grid_options(paths, grids, optimistic=True)
        lower_model = build_model((paths,), opt_options, ATOMS, FAMILY,
                                  mode=mode, frontier=True)
        lower_mip = solve_model(lower_model, time_limit=2)
        lower_lp = solve_model(lower_model, time_limit=2, relaxation=True)
        assert lower_mip["exact_incumbent_verified"]
        assert lower_mip["exact_objective"] == enum_lower
        assert lower_lp["rational_lower_bound"] <= enum_lower <= exact
        # Deliberately arbitrary multipliers must ALSO yield valid lower bounds.
        arbitrary = [Fraction(i % 7, 13) for i in range(len(lower_model.rows))]
        assert lower_model.rational_lower_bound(arbitrary) <= enum_lower
        upper_options = grid_options(paths, grids, optimistic=False)
        upper_model = build_model((paths,), upper_options, ATOMS, FAMILY,
                                  mode=mode, frontier=True)
        upper_mip = solve_model(upper_model, time_limit=2)
        assert upper_mip["exact_incumbent_verified"]
        assert upper_mip["exact_objective"] == enum_upper
        assert complete(ATOMS, FAMILY,
                        tuple(path[n] for path, n in zip(paths, upper_mip["plan"])), mode)
        checks.append({"mode": mode, "exact_frontier": exact,
                       "optimistic_mip_exact_objective": enum_lower,
                       "feasible_mip_exact_objective": enum_upper,
                       "exact_rational_lp_bound": str(lower_lp["rational_lower_bound"]),
                       "exact_rational_lp_integer_bound": lower_lp["integer_objective_lower_bound"],
                       "rounding_cost_for_selected_optimistic_plan": selected_gap})
    return checks


def scenario_checks():
    # Synthetic independent q scenarios. This is optimization validation, not
    # a claim that eight scenarios statistically establish acquisition quality.
    candidates = [((p0, p1), (bits0, bits1)) for (bits0, p0), (bits1, p1) in
                  product(all_paths(2), all_paths(3))]
    indices = (0, 3, 7, 12, 17, 21, 26, 31)
    scenarios = tuple(candidates[i][0] for i in indices)
    options = (tuple((n, n) for n in range(3)), tuple((n, n) for n in range(4)))
    checks = []
    for mode in ("positive", "bidirectional"):
        for budget in (0, 2, 3, 5):
            exact_count = 0
            for allocation in product(range(3), range(4)):
                if sum(allocation) > budget:
                    continue
                count = 0
                for paths in scenarios:
                    endpoints = tuple(path[n] for path, n in zip(paths, allocation))
                    if any(endpoint is None for endpoint in endpoints):
                        continue
                    count += complete(ATOMS, FAMILY, endpoints, mode)
                exact_count = max(exact_count, count)
            model = build_model(scenarios, options, ATOMS, FAMILY,
                                mode=mode, budget=budget)
            solved = solve_model(model, time_limit=3)
            assert solved["exact_incumbent_verified"]
            assert -solved["exact_objective"] == exact_count
            checks.append({"mode": mode, "budget": budget,
                           "enumerated_best_scenarios": exact_count,
                           "mip_best_scenarios": -solved["exact_objective"]})
    return {"scenarios": len(scenarios), "plans": 12,
            "uniform_q_error_epsilon_at_delta_005": saa_epsilon(8, 12, 0.05),
            "small_sample_bound_is_vacuous": saa_epsilon(8, 12, 0.05) > 0.5,
            "checks": checks}


def masked_decision_checks():
    # Decision 0 requires an identified positive witness. Decision 1 may be
    # answered false. The bad scenario refutes decision 0 and must not complete.
    atoms = (Atom(0, (1, 0)), Atom(0, (0, 1)))
    family = (((0,),), ((1,),))
    good = (exact_path((1,)), exact_path((0,)))
    bad = (exact_path((0,)), exact_path((0,)))
    options = (((0, 0), (1, 1)), ((0, 0), (1, 1)))
    mask = (False, True)
    assert complete(atoms, family, (good[0][-1], good[1][-1]), allow_negative=mask)
    assert complete(atoms, family, (bad[0][-1], bad[1][-1]))
    assert not complete(atoms, family, (bad[0][-1], bad[1][-1]), allow_negative=mask)
    logical = solve_model(build_model((good, bad), options, atoms, family, budget=2))
    restricted = solve_model(build_model((good, bad), options, atoms, family,
                                         budget=2, allow_negative=mask))
    assert logical["exact_incumbent_verified"] and logical["exact_objective"] == -2
    assert restricted["exact_incumbent_verified"] and restricted["exact_objective"] == -1
    infeasible = solve_model(build_model((bad,), options, atoms, family,
                                        frontier=True, allow_negative=mask))
    assert infeasible["status"] == 2 and not infeasible["exact_incumbent_verified"]
    # Direct top1 tie fixture: neither strict winner witness holds. Refuting the
    # existential may evaluate a logical formula, but does not identify a winner.
    rank_atoms = (Atom(0, (1, -1)), Atom(0, (-1, 1)))
    rank_family = (((0,), (1,)),)
    assert complete(rank_atoms, rank_family, ((0, 0), (0, 0)))
    assert not complete(rank_atoms, rank_family, ((0, 0), (0, 0)), allow_negative=(False,))
    assert negative_completion_mask(family, "positive", (True, True)) == (False, False)
    return {"mixed_mask": list(mask), "generic_logical_completed_scenarios": 2,
            "identified_rank_plus_false_comparison_completed_scenarios": 1,
            "all_false_rank_masked_frontier_infeasible": True,
            "tied_strict_ranking_refutation_does_not_identify_a_winner": True,
            "positive_mode_cannot_enable_negative_answers": True}


def counterexamples():
    # A OR/AND witness deficit is monotone but its progress is not submodular.
    # Witnesses {a,b} and {c}; each atom requires one independent fixed gain.
    def progress(S):
        deficit = min(2 - len({"a", "b"} & S), 1 - int("c" in S))
        return 1 - deficit
    empty, a, b, ab = (progress(S) for S in (set(), {"a"}, {"b"}, {"a", "b"}))
    assert b - empty == 0 < ab - a == 1
    # Same final count does not determine the per-record running intersection.
    first = exact_path((1, 0, 1, 0), alpha=Fraction(1, 2))
    second = exact_path((0, 1, 1, 0), alpha=Fraction(1, 2))
    assert first[2] != second[2]
    assert first[-1] == second[-1] == (2, 2)
    return {
        "non_submodular_witness_progress": {"P_empty": empty, "P_a": a,
                                             "P_b": b, "P_ab": ab},
        "dependent_wor_not_adaptive_submodular": {
            "N": 2, "K": 1, "expected_positive_gain_initial": "1/2",
            "expected_gain_after_observing_zero": "1"},
        "within_batch_order_matters": {
            "N": 4, "alpha": "1/2", "both_prefixes_n": 2,
            "both_prefixes_s": 1, "prefix_10_interval": first[2],
            "prefix_01_interval": second[2],
            "both_full_paths_true_K": 2, "both_full_paths_remain_nonfailed": True},
    }


def complementarity_planner_check():
    atoms = (Atom(0, (1, 0, 0)), Atom(0, (0, 1, 0)), Atom(-2, (0, 0, 1)))
    family = (((0, 1), (2,)),)
    paths = (exact_path((1,)), exact_path((1,)), exact_path((1, 1, 1)))
    options = tuple(tuple((n, n) for n in range(len(path))) for path in paths)
    model = build_model((paths,), options, atoms, family, budget=2)
    solved = solve_model(model, time_limit=2)
    assert solved["exact_incumbent_verified"] and -solved["exact_objective"] == 1
    assert solved["plan"] == (1, 1, 0)
    # Even a MONOTONE scalar deficit can make a one-step greedy decision fail:
    # sum capped normalized deficits within a witness; min over alternatives.
    targets = (1, 1, 3)
    initial = atom_bounds(atoms, tuple(path[0] for path in paths))
    def deficit(prefix):
        endpoints = tuple(path[n] for path, n in zip(paths, prefix))
        current = atom_bounds(atoms, endpoints)
        residual = tuple(Fraction(max(0, 1 - lo), target)
                         for (lo, _), target in zip(current, targets))
        return min(residual[0] + residual[1], residual[2])
    prefix = (0, 0, 0)
    for _ in range(2):
        current = deficit(prefix)
        candidates = []
        for h in range(3):
            if prefix[h] + 1 < len(paths[h]):
                advanced = tuple(n + int(i == h) for i, n in enumerate(prefix))
                candidates.append((current - deficit(advanced), -h, advanced))
        prefix = max(candidates)[2]
    assert prefix == (0, 0, 2)
    assert not complete(atoms, family,
                        tuple(path[n] for path, n in zip(paths, prefix)))
    return {"kind": "constructed synthetic mechanism, not empirical efficacy",
            "budget": 2, "global_scenario_plan": solved["plan"],
            "global_scenario_plan_completes": True,
            "one_step_monotone_deficit_greedy_plan": prefix,
            "one_step_monotone_deficit_greedy_completes": False}


def prior_normalization_checks():
    checked = []
    for N in range(1, 7):
        priors = ((1, 1, Fraction(1, 2)), (2, 5, Fraction(1, 2)))
        total = sum((predictive_mass(N, sum(bits), priors)
                     for bits in product((0, 1), repeat=N)), Fraction())
        assert total == 1
        checked.append(N)
    return {"enumerated_population_sizes": checked, "all_exact_prior_masses_sum_to_one": True}


def main():
    counts, retained = status_and_grid_checks()
    receipt = {
        "purpose": "Synthetic exhaustive checks of the proposed mathematics and compact MILP",
        "not": "Real-data execution, model inference, empirical calibration, or a general numerical proof",
        "status_and_grid": counts,
        "mip_and_exact_dual": mip_and_dual_checks(retained),
        "scenario_optimizer": scenario_checks(),
        "per_decision_negative_answer_mask": masked_decision_checks(),
        "counterexamples": counterexamples(),
        "complementarity_planner": complementarity_planner_check(),
        "working_prior": prior_normalization_checks(),
        "source_sha256": {name: sha256((HERE / name).read_bytes()).hexdigest()
                          for name in ("certificate_frontier.py", "validate_theory_design.py")},
    }
    (HERE / "synthetic_validation_receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
