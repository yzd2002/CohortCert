#!/usr/bin/env python3
"""Prepare a label-blind runtime SELECTION, not an executable GPU protocol.

Reads only structured contracts, population metadata, and the old protocol's
operator/seed declarations. It never opens model predictions, crowd labels, old
run outcomes, or text contents. A final shared completion checker and policy
definition must be frozen before this selection becomes an execution protocol.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import importlib.metadata
import json
import math
import os
from pathlib import Path
import secrets
import subprocess

from common import core_module, digest, file_hash, write_new

HERE = Path(__file__).resolve().parent
DEFAULT_CORE = Path("/dev/shm/CohortCert_fixed_label_replay_20261031")
DEFAULT_AIRLINE = Path("/root/autodl-tmp/cohortcert_revision_20261101/airline_validation")
DEFAULT_MODEL = Path("/root/autodl-tmp/models/Qwen3-8B-b968826d9c46")
SALT = "CohortCert-real-runtime-metadata-selection-20261102-v1"


def command(args):
    try:
        done = subprocess.run(args, capture_output=True, text=True, timeout=10)
        return {"args": args, "returncode": done.returncode, "stdout": done.stdout,
                "stderr": done.stderr}
    except Exception as exc:
        return {"args": args, "error": f"{type(exc).__name__}: {exc}"}


def prepare(core, airline, model, output):
    core, airline, model, output = [Path(p).resolve() for p in (core, airline, model, output)]
    if output.exists():
        raise FileExistsError("Retain the existing selection; do not reroll seeds or query IDs")
    protocol = json.loads((airline / "protocol.json").read_text())
    queries = [json.loads(line) for line in (airline / "queries.jsonl").read_text().splitlines() if line]
    if len(queries) != 234 or len({q["query_id"] for q in queries}) != 234:
        raise ValueError("Expected all 234 distinct original airline contracts")
    snapshot = core_module(core, "query.parquet_snapshot").ParquetSnapshot(
        airline / "data/cohorts/airline_snapshot.parquet")
    compile_fn = core_module(core, "query.compiler").compile_signed_decisions
    descriptions, by_id = [], {q["query_id"]: q for q in queries}
    for q in queries:
        matrix, family = compile_fn(q["contract"], snapshot)
        descriptions.append({"query_id": q["query_id"], "kind": q["kind"],
                             "support_size": len(matrix.rows_with_any_nonzero_coefficient()),
                             "declared_decisions": family.decision_count,
                             "atom_count": len(family.atoms),
                             "witness_count": len(family.certificates),
                             "candidate_count": len(q["contract"]["cohorts"]),
                             "contract_sha256": digest(q["contract"])})
    selected = []
    for kind in sorted({q["kind"] for q in descriptions}):
        population = sorted([q for q in descriptions if q["kind"] == kind],
                            key=lambda q: (q["support_size"], q["query_id"]))
        for quartile in range(4):
            group = population[len(population)*quartile//4:len(population)*(quartile+1)//4]
            chosen = min(group, key=lambda q: digest([SALT, q["query_id"]]))
            selected.append({**chosen, "support_quartile": quartile+1,
                             "eligible_in_stratum": len(group),
                             "selection_key": digest([SALT, chosen["query_id"]])})
    selected.sort(key=lambda q: q["selection_key"])
    old_pilot = {int(x["pilot_seed"]) for x in protocol["seed_pairs"]}
    old_formal = {int(x["formal_seed"]) for x in protocol["seed_pairs"]}
    seed_pairs = []
    used = old_pilot | old_formal
    for i in range(2):
        pilot, formal = secrets.randbits(64), secrets.randbits(256)
        while pilot in used:
            pilot = secrets.randbits(64)
        used.add(pilot)
        while formal in used:
            formal = secrets.randbits(256)
        used.add(formal)
        seed_pairs.append({"id": i, "pilot_seed": str(pilot), "formal_seed": str(formal)})
    query_map = {q["query_id"]: q for q in descriptions}
    smoke = [query_map[qid] for qid in protocol["smoke_query_ids"]]
    warm = []
    for query in selected:
        arms = ["certificate_policy_PENDING", "matched_one_bin"]
        if query["kind"] == "ranking":
            arms.append("boundary_one_bin")
        rng = __import__("random").Random(digest([SALT, query["query_id"], "method-order"]))
        rng.shuffle(arms)
        for pair in seed_pairs:
            for pos, method in enumerate(arms if pair["id"] == 0 else list(reversed(arms))):
                warm.append({"query_id": query["query_id"], "seed_id": pair["id"],
                             "method": method, "order_position": pos,
                             "budget_share": 50, "support_size": query["support_size"],
                             "budget": math.ceil(query["support_size"]/2)})
    cold = []
    for query in smoke:
        arms = ["certificate_policy_PENDING", "matched_one_bin"]
        if query["kind"] == "ranking":
            arms.append("boundary_one_bin")
        __import__("random").Random(digest([SALT, query["query_id"], "cold-order"])).shuffle(arms)
        for pos, method in enumerate(arms):
            cold.append({"query_id": query["query_id"], "seed_id": 0, "method": method,
                         "order_position": pos, "budget_share": 50,
                         "support_size": query["support_size"], "budget": math.ceil(query["support_size"]/2)})
    paths = {"queries": airline / "queries.jsonl", "metadata": airline / "data/cohorts/airline_snapshot.parquet",
             "features": airline / "data/embeddings/airline_emb.npy",
             "feature_index": airline / "data/embeddings/airline_index.parquet",
             "operator_declaration": airline / "protocol.json"}
    input_hashes = {name: file_hash(path) for name, path in paths.items()}
    if input_hashes["queries"] != protocol["queries_sha256"] or input_hashes["metadata"] != protocol["metadata_sha256"]:
        raise ValueError("Original label-blind query/metadata inputs changed")
    warm_calls, cold_calls = sum(x["budget"] for x in warm), sum(x["budget"] for x in cold)
    # A previously published aggregate is used solely to estimate run feasibility.
    # Do not open the label table or outcome tables to refine this estimate.
    historical_seconds_per_record = 353.6496424879879 / 14640
    plan = {"status": "DRAFT_NOT_EXECUTABLE", "created_utc": datetime.now(timezone.utc).isoformat(),
            "selection_status": "commit these metadata-selected IDs and fresh seeds before any new timing or outcomes",
            "blocked_finalization": "Shared bidirectional per-decision checker and new certificate policy are under design; every arm must use the identical final checker. Do not launch this draft.",
            "scope": "New prospective timing on a previously analyzed population; neither unseen data nor a new corpus",
            "selection_rule": "Within each of pairwise/summary/ranking, order by metadata-only effective support and query ID, split into four rank quartiles, choose the minimum salted SHA-256 ID in each stratum",
            "selection_salt": SALT, "selected_queries": selected, "all_query_metadata": descriptions,
            "all_query_metadata_sha256": digest(descriptions), "seed_pairs": seed_pairs,
            "seed_independence": "Fresh OS entropy for distinct pilot/formal streams, never reused from prior airline manifest",
            "methods": {"completion_checker": "PENDING_SAME_FOR_ALL_ARMS", "certificate_policy": "PENDING",
                        "matched": "one-bin matched 8/16 batch and fourth-round exploration",
                        "boundary": "LUCB-inspired wider boundary-group interval; ranking-only one-bin adaptation"},
            "primary_budget_share": 50, "alpha_per_request": 0.05,
            "warm_schedule": warm, "process_cold_schedule": cold,
            "order_rule": "Query blocks are salted-hash ordered; method order is randomly permuted per block and reversed for fresh seed pair 1",
            "model": {**protocol["model"], "persistent_path": str(model),
                      "available_ram_copy": "/dev/shm/cohortcert_qwen3_8b_b968826d"},
            "paths": {"core": str(core), "airline": str(airline), **{k: str(v) for k, v in paths.items()}},
            "input_sha256": input_hashes,
            "selection_code_sha256": file_hash(__file__),
            "source_sha256": {p.name: file_hash(p) for p in sorted(HERE.glob("*.py"))},
            "counts": {"warm_requests": len(warm), "cold_requests": len(cold),
                       "warm_max_requested_records": warm_calls, "cold_max_requested_records": cold_calls,
                       "materialized_full_scan_records": 14640},
            "planning_time_estimate": {"evidence": "Historical public aggregate, not a new measurement: 353.649642s for 14640 single-record forward calls; 12.144973s load",
                                       "historical_seconds_per_record": historical_seconds_per_record,
                                       "nominal_forward_seconds_at_all_caps_including_materialization": historical_seconds_per_record*(warm_calls+cold_calls+14640),
                                       "nominal_load_seconds": 12.144973311573267*(1+len(cold)),
                                       "conservative_multiplier_for_query_cpu_drift_and_io": 1.5,
                                       "policy": "Hard 3-hour formal collection window; finish the current complete query/seed/method block, retain all planned but unexecuted keys as administrative missing; never replace a query. A full-run claim requires all planned keys."},
            "hardware_control": {"cpu_threads": 1, "cpu_affinity_preference": [52, 53, 54, 55],
                                 "reason": "nvidia-smi topo identifies GPU locality as NUMA node 1",
                                 "environment": {"PYTHONHASHSEED": "0", "CUBLAS_WORKSPACE_CONFIG": ":4096:8",
                                                 "OMP_NUM_THREADS": "1", "OPENBLAS_NUM_THREADS": "1", "MKL_NUM_THREADS": "1"},
                                 "require_idle_gpu": True, "max_start_temperature_c": 75,
                                 "fixed_power_limit_w": "record current hardware value; do not silently retune",
                                 "clocks": "record before/after each block; no claim of externally locked clocks"},
            "versions": {n: importlib.metadata.version(n) for n in ("torch", "transformers", "numpy", "scipy", "pyarrow", "scikit-learn")},
            "hardware_read_only": [command(["nvidia-smi", "--query-gpu=name,memory.total,memory.used,temperature.gpu,power.limit,clocks.current.sm,clocks.current.memory,utilization.gpu", "--format=csv,noheader"]),
                                   command(["nvidia-smi", "--query-compute-apps=pid,process_name,used_memory", "--format=csv,noheader"]),
                                   command(["nvidia-smi", "topo", "-m"])],
            "parent_model_runs_launched": 0}
    write_new(output, plan)
    print(json.dumps({"status": plan["status"], "output": str(output), "sha256": file_hash(output),
                      "selected_query_ids": [q["query_id"] for q in selected], "counts": plan["counts"],
                      "nominal_forward_minutes": plan["planning_time_estimate"]["nominal_forward_seconds_at_all_caps_including_materialization"]/60}, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--core", type=Path, default=DEFAULT_CORE)
    parser.add_argument("--airline", type=Path, default=DEFAULT_AIRLINE)
    parser.add_argument("--model", type=Path, default=DEFAULT_MODEL)
    parser.add_argument("--output", type=Path, default=HERE / "DRAFT_SELECTION.json")
    args = parser.parse_args()
    prepare(args.core, args.airline, args.model, args.output)
