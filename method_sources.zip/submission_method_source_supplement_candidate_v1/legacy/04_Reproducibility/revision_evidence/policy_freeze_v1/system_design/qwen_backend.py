"""Real, uncached Qwen forward for each requested row; imported only by run mode."""
from __future__ import annotations

from collections import defaultdict
import time


class QwenBackend:
    def __init__(self, model_path, model_config, texts):
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer
        self.torch, self.config, self.texts = torch, model_config, texts
        torch.set_num_threads(1)
        torch.set_num_interop_threads(1)
        torch.manual_seed(0)
        torch.use_deterministic_algorithms(True)
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = False
        torch.backends.cudnn.benchmark = False
        torch.backends.cudnn.deterministic = True
        wall, cpu = time.perf_counter_ns(), time.process_time_ns()
        self.tokenizer = AutoTokenizer.from_pretrained(model_path, local_files_only=True, trust_remote_code=False)
        self.model = AutoModelForCausalLM.from_pretrained(
            model_path, local_files_only=True, trust_remote_code=False, dtype=torch.bfloat16,
            device_map={"": "cuda:0"}, attn_implementation="sdpa")
        self.model.eval()
        torch.cuda.synchronize()
        self.setup = {"model_load_wall_ms": (time.perf_counter_ns()-wall)/1e6,
                      "model_load_cpu_ms": (time.process_time_ns()-cpu)/1e6,
                      "precision": "bfloat16", "attention": "sdpa", "batch_records": 1,
                      "cuda": torch.version.cuda, "gpu": torch.cuda.get_device_name(0)}
        one = self.tokenizer.encode("1", add_special_tokens=False)
        zero = self.tokenizer.encode("0", add_special_tokens=False)
        if len(one) != 1 or len(zero) != 1 or one == zero:
            raise ValueError("Answer-token encoding does not satisfy the frozen operator")
        self.one, self.zero = one[0], zero[0]
        self.seen, self.disagreements = {}, []
        self.reset_request()

    def reset_request(self):
        self.cost = defaultdict(float)
        self.forward_events = []
        self.torch.cuda.reset_peak_memory_stats()

    def _label(self, text, rid):
        torch = self.torch
        started = time.perf_counter_ns()
        prompt = self.config["prompt"].format(text=text)
        formatted = self.tokenizer.apply_chat_template(
            [{"role": "user", "content": prompt}], tokenize=False,
            add_generation_prompt=True, enable_thinking=False)
        encoded = self.tokenizer(formatted, return_tensors="pt", add_special_tokens=False)
        n = int(encoded["input_ids"].shape[-1])
        self.cost["tokenize_wall_ms"] += (time.perf_counter_ns()-started)/1e6
        if n > int(self.config["max_context_tokens"]):
            raise RuntimeError("Prompt exceeds frozen context; no truncation is allowed")
        transfer = time.perf_counter_ns()
        inputs = {k: v.to("cuda:0") for k, v in encoded.items()}
        torch.cuda.synchronize()
        self.cost["transfer_wall_ms"] += (time.perf_counter_ns()-transfer)/1e6
        begin, end = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
        self.cost["forward_attempts"] += 1
        self.cost["input_tokens"] += n
        begin.record()
        with torch.inference_mode():
            logits = self.model(**inputs, use_cache=False, logits_to_keep=1).logits[0, -1]
        end.record()
        end.synchronize()
        gpu_ms = begin.elapsed_time(end)
        self.cost["cuda_forward_ms"] += gpu_ms
        self.cost["forward_completions"] += 1
        margin = float((logits[self.one].float()-logits[self.zero].float()).item())
        label = int(margin >= 0)
        self.forward_events.append({"record_id": rid, "label": label, "input_tokens": n,
                                    "cuda_forward_ms": gpu_ms, "logit_margin": margin})
        if rid in self.seen and self.seen[rid] != label:
            event = {"record_id": rid, "previous": self.seen[rid], "current": label}
            self.disagreements.append(event)
            raise RuntimeError("Repeated fixed-operator record changed label; retain result and stop formal phase")
        self.seen[rid] = label  # Stability observation only; never returned as a cache.
        return label

    def read(self, ids):
        start = time.perf_counter_ns()
        try:
            return {rid: self._label(self.texts[rid], rid) for rid in ids}
        finally:
            self.cost["backend_wall_ms"] += (time.perf_counter_ns()-start)/1e6

    def warmup(self):
        canaries = [("Thank you airline for a wonderful flight and excellent service!", 0),
                    ("Terrible airline. They canceled my flight and refused to help.", 1)] * 8
        wall = time.perf_counter_ns()
        labels = [self._label(text, f"canary-{i}") for i, (text, _) in enumerate(canaries)]
        if labels != [expected for _, expected in canaries]:
            raise RuntimeError("Technical canary failed; no formal result is collected")
        self.setup["canary_warmup_wall_ms"] = (time.perf_counter_ns()-wall)/1e6
        self.setup["canary_cost"] = dict(self.cost)
        self.reset_request()

    def export(self):
        return {**dict(self.cost), "peak_allocated_bytes": self.torch.cuda.max_memory_allocated(),
                "peak_reserved_bytes": self.torch.cuda.max_memory_reserved(),
                "repeated_label_disagreements": list(self.disagreements)}
