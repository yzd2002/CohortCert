"""Separate fail-closed request candidate, never installed into the frozen core.

This uses the historical float likelihood calculation. Sticky intersections,
per-record updates, receipt retention, and authority resolution are engineering
repairs, not a proof that floating point interval inversion is correct for all
inputs. One Candidate serializes its requests; different Candidate objects do
not share mutable pipeline globals.
"""
from __future__ import annotations

import importlib.util
from pathlib import Path
import threading
import time
from types import MappingProxyType

from common import Timings, core_module, digest, file_hash
from request_repairs import (CAP_KEY, VERSION, no_fallback_reader_class,
                             resolve_plan, sticky_cs_class)


class AuditedOracle:
    """Charge a requested batch before inference, retain failed attempt IDs."""
    def __init__(self, backend, support, cap, timings):
        self.backend, self.support, self.cap, self.timings = backend, set(support), cap, timings
        self.attempted_ids, self.observed, self.events = [], {}, []
        self.failed = False

    def read(self, ids):
        ids = list(ids)
        if self.failed:
            raise RuntimeError("Request has already failed; no fallback reread is permitted")
        if len(ids) != len(set(ids)) or set(ids) & set(self.attempted_ids):
            raise ValueError("Duplicate attempt in a no-retry request")
        if not set(ids) <= self.support or len(self.attempted_ids) + len(ids) > self.cap:
            raise ValueError("Support or authoritative cap violated before backend access")
        self.attempted_ids.extend(ids)
        event = {"record_ids": ids, "status": "attempted"}
        self.events.append(event)
        try:
            with self.timings.span("oracle_backend"):
                raw = self.backend.read(ids)
            if set(raw) != set(ids) or any(type(y) is not int or y not in (0, 1) for y in raw.values()):
                raise ValueError("Backend must return exactly the requested binary labels")
            self.observed.update(raw)
            event.update(status="complete", labels=[raw[i] for i in ids])
            return raw
        except Exception as exc:
            self.failed = True
            event.update(status="failed", error_type=type(exc).__name__, error=str(exc))
            raise


def matched_uniform(cells, cell_cs, c_j, family, explore=False, explore_rng=None):
    from engine.scheduler import _choose_batch
    active = [c for c in cells if cell_cs[c.cell_id].n < c.N]
    if not active:
        return -1, 0
    if explore:
        if explore_rng is None:
            raise ValueError("Exploration needs the request RNG")
        chosen = explore_rng.choice(active)
    else:
        fresh = [c for c in active if cell_cs[c.cell_id].n == 0]
        chosen = (max(fresh, key=lambda c: (c.N, c.cell_id)) if fresh
                  else min(active, key=lambda c: (cell_cs[c.cell_id].n, c.cell_id)))
    return chosen.cell_id, _choose_batch(cell_cs[chosen.cell_id])


class Candidate:
    def __init__(self, core_root):
        self.root = Path(core_root).resolve()
        base = core_module(self.root, "engine.pipeline")
        oi = core_module(self.root, "engine.oracle_interface")
        spec = importlib.util.spec_from_file_location(
            "cohortcert_isolated_candidate_pipeline", self.root / "engine/pipeline.py")
        self.pipeline = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.pipeline)

        self.pipeline.BudgetedOracle = no_fallback_reader_class(oi.BudgetedOracle, oi.OracleFailure)
        self.base_cs = core_module(self.root, "engine.finite_population_cs").CellCS
        self.lock = threading.Lock()
        self.core_identity = digest({str(p.relative_to(self.root)): file_hash(p)
                                     for d in ("engine", "query") for p in sorted((self.root / d).rglob("*.py"))})
        self._base = base

    def execute(self, contract, snapshot, backend, *, proxy=None, method="C1", seed=1,
                formal_seed=2, alpha_override=None, budget_override=None,
                snapshot_hash="", operator_hash="", asset_manifest_hash=""):
        with self.lock:
            return self._execute(contract, snapshot, backend, proxy=proxy, method=method,
                                 seed=seed, formal_seed=formal_seed,
                                 alpha_override=alpha_override, budget_override=budget_override,
                                 snapshot_hash=snapshot_hash, operator_hash=operator_hash,
                                 asset_manifest_hash=asset_manifest_hash)

    def _execute(self, contract, snapshot, backend, **options):
        start_wall, start_cpu = time.perf_counter_ns(), time.process_time_ns()
        timings = Timings()
        effective, plan = timings.call("resolve_authority", resolve_plan, contract,
                                      alpha_override=options["alpha_override"],
                                      budget_override=options["budget_override"])
        if type(options["seed"]) is not int or type(options["formal_seed"]) is not int:
            raise ValueError("Seed pair must contain independent nonnegative integers")
        if min(options["seed"], options["formal_seed"]) < 0 or options["seed"] == options["formal_seed"]:
            raise ValueError("Pilot/formal seeds must be distinct and nonnegative")
        plan.update(core_source_identity=self.core_identity,
                    snapshot_sha256=options["snapshot_hash"], operator_sha256=options["operator_hash"],
                    asset_manifest_sha256=options["asset_manifest_hash"],
                    candidate_version=VERSION, method=options["method"], bins=1,
                    pilot_seed=str(options["seed"]), formal_seed=str(options["formal_seed"]),
                    update_granularity="every revealed record; stop checks at batch ends",
                    retries=0, semantics="strict, fixed-operator, per-request sampling risk")
        p = self.pipeline
        # Bind functions only on this private module, under the instance lock.
        originals = {n: getattr(p, n) for n in ("compile_signed_decisions", "_fit_proxy_or_fallback",
                     "pushforward_contrast_bounds", "decide", "render_verified", "verify_certificate",
                     "freeze_coefficient_cells", "independent_uniform_permutations")}
        for name, stage in (("compile_signed_decisions", "compile"), ("_fit_proxy_or_fallback", "proxy_fit"),
                            ("pushforward_contrast_bounds", "propagate"), ("decide", "check_witnesses"),
                            ("render_verified", "render_structured"), ("verify_certificate", "verify_structured")):
            fn = originals[name]
            def measured(*a, _fn=fn, _stage=stage, **kw):
                return timings.call(_stage, _fn, *a, **kw)
            setattr(p, name, measured)
        cs_states, cells, permutations, cs_events = [], [], {}, []

        def freeze(ids, matrix, fitted_proxy):
            result = timings.call("freeze_cells", originals["freeze_coefficient_cells"],
                                  ids, matrix, fitted_proxy, n_bins=1)
            cells.extend(result)
            return result

        def permute(frozen, formal):
            result = timings.call("draw_permutations", originals["independent_uniform_permutations"], frozen, formal)
            permutations.update(result)
            return result

        cls = sticky_cs_class(self.base_cs, cs_events, timings)

        def cs_factory(*a, **kw):
            cs = cls(*a, **kw)
            cs.audit_cell_id = cells[len(cs_states)].cell_id
            cs_states.append(cs)
            return cs

        p.freeze_coefficient_cells, p.independent_uniform_permutations = freeze, permute
        oracle, certificate, error = None, None, None
        try:
            matrix, family = p.compile_signed_decisions(effective, snapshot)
            support = matrix.rows_with_any_nonzero_coefficient()
            oracle = AuditedOracle(backend, support, effective["budget"][CAP_KEY], timings)
            if not support:
                bounds = p.exact_bounds_from_labels(matrix, family, {})
                satisfied = p.decide(family, bounds)
                certificate = p.render_verified(
                    effective, family, bounds, satisfied, effective["risk"]["alpha"], options["seed"],
                    options["snapshot_hash"], plan["effective_contract_sha256"], "", options["operator_hash"],
                    sampled_record_ids=[], charged_cost={"semantic_calls": 0},
                    semantic_sensitivity=[], bundle_complete=family.bundle_complete(satisfied),
                    decision_status=family.per_decision_status(satisfied))
                failures = p.verify_certificate(certificate, family=family, contract=effective)
                if failures:
                    raise ValueError("Zero-support structured validation failed: " + str(failures))
            else:
                method = options["method"]
                if method == "C1":
                    strategy = p._make_default_strategy(1.0, p.EPS_SCHED)
                elif method == "M1":
                    strategy = matched_uniform
                elif method == "B1":
                    from boundary_allocation import BoundaryAllocator
                    blocks = core_module(self.root, "query.contract_schema").normalize_decisions(effective)
                    if len(blocks) != 1 or blocks[0]["type"] not in ("top1", "topk"):
                        raise ValueError("Boundary arm supports single disjoint-cohort ranking only")
                    groups = {c["id"]: set(snapshot.cohort_records(c)) for c in effective["cohorts"]}
                    block = blocks[0]
                    if set(block["candidates"]) != set(groups) or "topk_set" in block:
                        raise ValueError("Boundary candidates require ordinary disjoint-group ranking")
                    strategy = BoundaryAllocator(groups, 1 if block["type"] == "top1" else block["k"],
                                                 lambda: MappingProxyType(oracle.observed), record_actions=False)
                else:
                    raise ValueError("Unknown method " + str(method))

                def measured_strategy(*a, **kw):
                    return timings.call("schedule", strategy, *a, **kw)

                certificate = p.answer(
                    effective, snapshot, oracle, alpha=effective["risk"]["alpha"],
                    budget_calls=effective["budget"][CAP_KEY], seed=options["seed"],
                    formal_seed=options["formal_seed"], scheduler_strategy=measured_strategy,
                    proxy=options["proxy"], cell_cs_factory=cs_factory,
                    retry=core_module(self.root, "engine.oracle_interface").RetryPolicy(max_attempts=1),
                    render_text=False, texts=None, snapshot_hash=options["snapshot_hash"],
                    query_contract_hash=plan["effective_contract_sha256"], model_and_prompt_hash=options["operator_hash"])
                if any(c.inconsistent for c in cs_states):
                    certificate["status"] = "execution_error"
                    certificate["reason"] = "sticky_confidence_intersection_empty"
                self._audit_prefix(oracle, cells, permutations, options["seed"], effective["budget"][CAP_KEY])
                if certificate.get("charged_cost", {}).get("semantic_calls") != len(oracle.attempted_ids):
                    raise ValueError("Engine charges disagree with actual requested attempt batches")
        except Exception as exc:
            error = {"type": type(exc).__name__, "message": str(exc)}
            certificate = {"status": "execution_error", "reason": "candidate_exception", "error": error,
                           "certified_claim_ids": [], "contrast_intervals": []}
        finally:
            for name, original in originals.items():
                setattr(p, name, original)
        attempted = [] if oracle is None else oracle.attempted_ids
        observed = {} if oracle is None else oracle.observed
        certificate["charged_cost"] = {"semantic_calls": len(attempted), "records_read": len(observed),
                                       "budget_calls": effective["budget"][CAP_KEY], "source": "independent attempted-batch ledger"}
        # Do not publish claim IDs from an error path, even if the old renderer retained them.
        if certificate["status"] == "execution_error":
            certificate["certified_claim_ids"] = []
            certificate["decision_status"] = []
        record = {"version": VERSION, "effective_contract": effective, "execution_plan": plan,
                  "execution_plan_sha256": digest(plan), "certificate": certificate,
                  "wall_ms": (time.perf_counter_ns()-start_wall)/1e6,
                  "process_cpu_ms": (time.process_time_ns()-start_cpu)/1e6,
                  "stages": timings.export(), "attempted_record_ids": attempted,
                  "observed_label_sha256": digest(observed),
                  "read_events": [] if oracle is None else oracle.events,
                  "cell_updates": cs_events,
                  "partition": [{"id": c.cell_id, "signature": [str(x) for x in c.signature],
                                 "records": c.records} for c in cells],
                  "permutation_sha256": digest(permutations),
                  "partition_sha256": digest([(c.cell_id, c.signature.__str__(), c.records) for c in cells]),
                  "priors_sha256": digest([(c.N, c.alpha, c.a, c.b, c.lam) for c in cs_states]),
                  "error": error}
        stage_wall = sum(v["wall_ms"] for v in record["stages"].values())
        record["unattributed_wall_ms"] = record["wall_ms"] - stage_wall
        return record

    def _audit_prefix(self, oracle, cells, permutations, seed, cap):
        successful = list(oracle.observed)
        if not cells:
            return
        residual = set().union(*(set(c.records) for c in cells))
        support = sorted(oracle.support)
        pilot = self.pipeline.fixed_uniform_pilot(support, cap, seed)
        if set(pilot) != oracle.support-residual:
            raise ValueError("Residual cells do not equal support minus the charged pilot")
        if successful[:len(pilot)] != pilot:
            raise ValueError("Charged pilot is not the uniformly selected support prefix")
        cell_of = {rid: c.cell_id for c in cells for rid in c.records}
        for c in cells:
            reads = [rid for rid in successful[len(pilot):] if cell_of[rid] == c.cell_id]
            if reads != permutations[c.cell_id][:len(reads)]:
                raise ValueError("Formal observations violate the frozen per-cell prefix")
