"""Synthetic CPU contract/failure probes; no corpus outcomes or model import."""
from copy import deepcopy
from itertools import product
import os
from pathlib import Path
import unittest

from common import Timings, core_module
from contract_candidate import Candidate
from request_repairs import CAP_KEY, no_fallback_reader_class, resolve_plan, sticky_cs_class

CORE = Path(os.environ.get("COHORTCERT_CORE_ROOT", "/dev/shm/CohortCert_fixed_label_replay_20261031"))
CellCS = core_module(CORE, "engine.finite_population_cs").CellCS
MemorySnapshot = core_module(CORE, "query.snapshot").MemorySnapshot
oi = core_module(CORE, "engine.oracle_interface")


def contract(cap=2, alpha=0.01, identical=False, equivalence=False):
    return {"snapshot_id": "synthetic", "predicate_id": "synthetic_v1",
            "population_scope": "two records", "risk": {"alpha": alpha, "scope": "this_request"},
            "budget": {CAP_KEY: cap}, "cohorts": [{"id": "a", "record_ids": ["x"]},
                                                    {"id": "b", "record_ids": ["x" if identical else "y"]}],
            "decision": {"type": "equivalence" if equivalence else "compare", "left": "a", "right": "b",
                         "unit": "proportion_difference", **({"tolerance": 0.2} if equivalence else {"threshold": 0})}}


class Backend:
    def __init__(self, labels=None, fail=False):
        self.labels, self.fail, self.attempts = labels or {}, fail, []

    def read(self, ids):
        self.attempts.extend(ids)
        if self.fail:
            raise RuntimeError("synthetic oracle failure")
        return {rid: self.labels[rid] for rid in ids}


class RepairsTests(unittest.TestCase):
    def test_authority_and_invalid_fields(self):
        source = contract(cap=1)
        original = deepcopy(source)
        effective, plan = resolve_plan(source, alpha_override=0.001)
        self.assertEqual(source, original)
        self.assertEqual(effective["budget"][CAP_KEY], 1)
        self.assertEqual(effective["risk"]["alpha"], 0.001)
        self.assertEqual(plan["authority"][CAP_KEY], "serialized")
        for invalid in (0, True, -1, 1.0):
            with self.assertRaises(ValueError):
                resolve_plan(contract(cap=invalid))
        for invalid in (0, 1, float("nan"), float("inf"), True):
            with self.assertRaises(ValueError):
                resolve_plan(contract(alpha=invalid))

    def test_every_short_path_is_independent_of_batch_grouping(self):
        for N in range(1, 8):
            for labels in product((0, 1), repeat=N):
                a_sink, b_sink = [], []
                A, B = sticky_cs_class(CellCS, a_sink, Timings()), sticky_cs_class(CellCS, b_sink, Timings())
                a, b = A(N, 0.05), B(N, 0.05)
                a.audit_cell_id = b.audit_cell_id = 0
                a.update(list(labels))
                for y in labels:
                    b.update([y])
                self.assertEqual(a_sink, b_sink)
                self.assertEqual(a.bounds, b.bounds)
                for previous, current in zip(a_sink, a_sink[1:]):
                    if previous["bounds"] and current["bounds"]:
                        self.assertGreaterEqual(current["bounds"][0], previous["bounds"][0])
                        self.assertLessEqual(current["bounds"][1], previous["bounds"][1])

    def test_empty_running_intersection_cannot_recover_at_exhaustion(self):
        class AdverseCS(CellCS):
            def _current_set(self):
                return (2, 2) if self.n == 1 else (0, 1)
        sink = []
        cls = sticky_cs_class(AdverseCS, sink, Timings())
        cs = cls(4, 0.05)
        cs.audit_cell_id = 0
        cs.update([0, 0])
        self.assertTrue(cs.inconsistent)
        self.assertIsNone(cs.bounds)
        cs.update([0, 0])
        self.assertIsNone(cs.bounds)
        self.assertTrue(sink[-1]["inconsistent"])

    def test_exhaustion_singleton_must_intersect_previous_interval(self):
        cls = sticky_cs_class(CellCS, [], Timings())
        cs = cls(2, 0.05)
        cs.audit_cell_id = 0
        cs.n, cs.s, cs.low, cs.high = 1, 0, 1, 2
        cs.update([0])
        self.assertTrue(cs.inconsistent)
        self.assertIsNone(cs.bounds)

    def test_failed_batch_is_charged_once_and_is_not_retried_by_prefix_fallback(self):
        backend = Backend(fail=True)
        cls = no_fallback_reader_class(oi.BudgetedOracle, oi.OracleFailure)
        reader = cls(backend, budget_calls=10, retry=oi.RetryPolicy(max_attempts=1))
        values, failure, stash = reader.read_prefix(["x", "y"])
        self.assertEqual(values, {})
        self.assertIsNotNone(failure)
        self.assertEqual(stash, {})
        self.assertEqual(backend.attempts, ["x", "y"])
        self.assertEqual(reader.spent, 2)

    def test_one_sided_integration_honors_cap_and_zero_support(self):
        candidate = Candidate(CORE)
        snapshot = MemorySnapshot({"x": {}, "y": {}})
        backend = Backend({"x": 1, "y": 0})
        result = candidate.execute(contract(cap=1), snapshot, backend, seed=100, formal_seed=200)
        self.assertEqual(result["certificate"]["status"], "unresolved")
        self.assertEqual(result["certificate"]["charged_cost"]["semantic_calls"], 1)
        self.assertEqual(len(backend.attempts), 1)
        for equivalence, expected in ((True, "certified"), (False, "unresolved")):
            backend = Backend()
            result = candidate.execute(contract(identical=True, equivalence=equivalence), snapshot,
                                       backend, seed=100, formal_seed=200)
            self.assertEqual(result["certificate"]["status"], expected)
            self.assertFalse(backend.attempts)

    def test_one_sided_failure_receipt_keeps_cost_and_clears_claims(self):
        candidate = Candidate(CORE)
        backend = Backend(fail=True)
        result = candidate.execute(contract(cap=2), MemorySnapshot({"x": {}, "y": {}}),
                                   backend, seed=100, formal_seed=200)
        cert = result["certificate"]
        self.assertEqual(cert["status"], "execution_error")
        self.assertEqual(cert["certified_claim_ids"], [])
        self.assertEqual(cert["charged_cost"]["semantic_calls"], 2)
        self.assertEqual(result["attempted_record_ids"], ["x", "y"])
        self.assertEqual(result["read_events"][0]["status"], "failed")

    def test_schema_invalid_zero_cap_is_rejected_before_oracle_access(self):
        backend = Backend({"x": 1, "y": 0})
        with self.assertRaises(ValueError):
            Candidate(CORE).execute(contract(cap=0), MemorySnapshot({"x": {}, "y": {}}),
                                    backend, seed=100, formal_seed=200)
        self.assertFalse(backend.attempts)

    def test_three_allocators_share_frozen_plan_on_a_nontrivial_synthetic_request(self):
        ids = [f"r{i:03d}" for i in range(480)]
        c = contract(cap=200)
        c["cohorts"] = [{"id": f"g{g}", "record_ids": ids[160*g:160*(g+1)]} for g in range(3)]
        c["decision"] = {"type": "top1", "candidates": ["g0", "g1", "g2"]}
        snapshot = MemorySnapshot({rid: {} for rid in ids})
        labels = {rid: int(i % 5 == 0) for i, rid in enumerate(ids)}
        candidate = Candidate(CORE)
        results = [candidate.execute(c, snapshot, Backend(labels), seed=100, formal_seed=200, method=method)
                   for method in ("C1", "M1", "B1")]
        for result in results:
            self.assertIsNone(result["error"])
            self.assertLessEqual(len(result["attempted_record_ids"]), 200)
            self.assertEqual(result["certificate"]["status"], "unresolved")
            self.assertEqual(len(result["cell_updates"]), 200-48)
        for name in ("partition_sha256", "priors_sha256", "permutation_sha256"):
            self.assertEqual(len({result[name] for result in results}), 1)
        self.assertEqual(len({tuple(result["attempted_record_ids"][:48]) for result in results}), 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
