"""Post-hoc LUCB-inspired boundary allocation, not the canonical LUCB algorithm.

Only metadata, already observed pilot labels, and cell CS state enter selection.
The original LUCB paper (ICML 2012, Sections 3.1–3.2) samples both boundary
arms; this controlled adaptation advances the wider of their two group-mean
intervals in the unchanged finite-population CohortCert executor.
"""
from fractions import Fraction as F


class BoundaryAllocator:
    def __init__(self, groups, k, observed_getter, direct_check=False, record_actions=True):
        self.groups = {str(g): frozenset(ids) for g, ids in groups.items()}
        self.k = int(k)
        self.observed_getter = observed_getter
        self.direct_check = direct_check
        self.record_actions = record_actions
        self.record_group = {}
        for g, ids in self.groups.items():
            if not ids:
                raise ValueError('Empty ranking group: ' + g)
            for rid in ids:
                if rid in self.record_group:
                    raise ValueError('Overlapping ranking cohorts cannot map to one cell per group')
                self.record_group[rid] = g
        if not 0 < self.k < len(self.groups):
            raise ValueError('Ranking k outside supported range')
        self.mapping = None
        self.actions = []
        self.bound_checks = 0

    def bind(self, cells):
        """Bind cells to known cohort membership after the charged pilot."""
        if self.mapping is not None:
            return
        by_group = {}
        residual = set()
        for c in cells:
            if not c.records:
                raise ValueError('Empty cell unexpectedly retained')
            gs = {self.record_group[rid] for rid in c.records}
            if len(gs) != 1:
                raise ValueError('A cell maps to multiple cohorts')
            g = next(iter(gs))
            if g in by_group:
                raise ValueError('More than one cell per ranking group')
            if residual.intersection(c.records):
                raise ValueError('Cell populations overlap')
            by_group[g] = c
            residual.update(c.records)
        observed = self.observed_getter()
        pilot = set(self.record_group) - residual
        if set(observed) != pilot:
            raise ValueError('Initial observed labels differ from the metadata-derived pilot')
        self.pilot_by_group = {g: tuple(sorted(ids & pilot)) for g, ids in self.groups.items()}
        self.pilot_positive = {g: sum(observed[rid] for rid in ids)
                               for g, ids in self.pilot_by_group.items()}
        for g, ids in self.groups.items():
            expected = ids - pilot
            if expected:
                if g not in by_group or set(by_group[g].records) != expected:
                    raise ValueError('One-bin residual cell does not equal its cohort minus pilot')
            elif g in by_group:
                raise ValueError('Fully pilot-observed group unexpectedly has a residual cell')
        self.mapping = by_group

    def group_states(self, cells, cell_cs):
        self.bind(cells)
        observed = self.observed_getter()
        out = {}
        for g, ids in self.groups.items():
            n_group = len(ids)
            p = self.pilot_positive[g]
            c = self.mapping.get(g)
            if c is None:
                lo = hi = mean = F(p, n_group)
                n = s = residual_n = 0
                cid = None
            else:
                cs = cell_cs[c.cell_id]
                if cs.bounds is None:
                    raise ValueError('Framework passed inconsistent confidence bounds to allocation')
                l, u = cs.bounds
                lo, hi = F(p + l, n_group), F(p + u, n_group)
                n, s, residual_n, cid = cs.n, cs.s, c.N, c.cell_id
                # n=0 occurs only during initialization; its midpoint is not
                # used by the boundary rule until every residual cell is read.
                mean = F(p, n_group) + F(c.N, n_group) * (F(s, n) if n else F(1, 2))
                if self.direct_check:
                    read_ids = set(c.records).intersection(observed)
                    if len(read_ids) != n or sum(observed[rid] for rid in read_ids) != s:
                        raise AssertionError('Cell n/s disagree with actually observed labels')
            if self.direct_check:
                if sum(observed[rid] for rid in self.pilot_by_group[g]) != p:
                    raise AssertionError('Pilot contribution changed')
            out[g] = dict(mean=mean, lower=lo, upper=hi, width=hi-lo,
                          original_n=n_group, pilot_n=len(self.pilot_by_group[g]),
                          pilot_positive=p, residual_n=residual_n, n=n, s=s, cell_id=cid)
        return out

    def __call__(self, cells, cell_cs, c_j, family, explore=False, explore_rng=None):
        from engine.scheduler import _choose_batch, pushforward_contrast_bounds
        active = [c for c in cells if cell_cs[c.cell_id].n < cell_cs[c.cell_id].N]
        if not active:
            return -1, 0
        states = self.group_states(cells, cell_cs)
        if self.direct_check:
            direct = pushforward_contrast_bounds(c_j, cells, cell_cs, family)
            for a in family.atoms:
                g, h = a.cohort_pair
                expected = (states[g]['lower']-states[h]['upper'],
                            states[g]['upper']-states[h]['lower'])
                if direct[a.index] != expected:
                    raise AssertionError('Absolute group intervals disagree with direct signed propagation')
                self.bound_checks += 1
        inside = weakest = strongest = None
        if explore:
            if explore_rng is None:
                raise ValueError('Seeded exploration RNG missing')
            chosen = explore_rng.choice(active)
            phase = 'exploration'
        else:
            fresh = [c for c in active if cell_cs[c.cell_id].n == 0]
            if fresh:
                chosen = max(fresh, key=lambda c: (c.N, c.cell_id))
                phase = 'initialization'
            else:
                ordered = sorted(states, key=lambda g: (-states[g]['mean'], g))
                inside = ordered[:self.k]
                outside = ordered[self.k:]
                weakest = min(inside, key=lambda g: (states[g]['lower'], g))
                strongest = min(outside, key=lambda g: (-states[g]['upper'], g))
                active_ids = {c.cell_id for c in active}
                candidates = [g for g in [weakest, strongest]
                              if states[g]['cell_id'] in active_ids]
                if candidates:
                    g = min(candidates, key=lambda g: (-states[g]['width'], g))
                    chosen = self.mapping[g]
                    phase = 'boundary'
                else:
                    # Keep ordinary budget/stopping behavior if an exact
                    # boundary tie is already known but other cells remain.
                    chosen = max(active, key=lambda c: (c.N, c.cell_id))
                    phase = 'exhausted_boundary_fallback'
        proposed = _choose_batch(cell_cs[chosen.cell_id])
        if self.record_actions:
            self.actions.append(dict(step=len(self.actions)+1, phase=phase, explore=bool(explore),
                                     cell_id=chosen.cell_id, proposed_batch=proposed,
                                     observed_count=len(self.observed_getter()), inside=inside,
                                     weakest=weakest, strongest=strongest,
                                     groups={g:{k:(str(v) if isinstance(v,F) else v) for k,v in d.items()}
                                             for g,d in states.items()}))
        return chosen.cell_id, proposed
