#!/usr/bin/env python3
"""Optional synthetic CPU scaling scaffold for the historical reference policy.

No model, labels, query outcomes, or final new-policy checker is used. These are
constructed overhead measurements, never end-to-end performance evidence. Add
the final optimized policy as a separate implementation only after action/bound
parity checks; this script deliberately makes no comparison with that policy.
"""
from __future__ import annotations

import argparse
from fractions import Fraction
import itertools
from pathlib import Path
import statistics
import time
from types import SimpleNamespace

from common import core_module, file_hash, write_new


def measurement(fn, repetitions):
    result = fn()  # One deterministic warmup, separately outside the samples.
    wall, cpu = [], []
    for _ in range(repetitions):
        w, c = time.perf_counter_ns(), time.process_time_ns()
        result = fn()
        wall.append((time.perf_counter_ns()-w)/1e6)
        cpu.append((time.process_time_ns()-c)/1e6)
    return {"wall_ms": wall, "cpu_ms": cpu,
            "median_wall_ms": statistics.median(wall), "median_cpu_ms": statistics.median(cpu)}, result


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--core", type=Path, default=Path("/dev/shm/CohortCert_fixed_label_replay_20261031"))
    ap.add_argument("--output", type=Path, required=True)
    ap.add_argument("--repetitions", type=int, default=7)
    ap.add_argument("--quick", action="store_true", help="Only the smallest smoke fixture; never the scaling table")
    args = ap.parse_args()
    if args.output.exists():
        raise FileExistsError("Refusing to overwrite a CPU timing receipt")
    snapshot_cls = core_module(args.core, "query.snapshot").MemorySnapshot
    compiler = core_module(args.core, "query.compiler").compile_signed_decisions
    frozen = core_module(args.core, "engine.frozen_cells")
    proxy_cls = core_module(args.core, "engine.proxy").StubProxy
    scheduler = core_module(args.core, "engine.scheduler")
    logic = core_module(args.core, "query.certificate_family")
    rows = []
    sizes = (2048,) if args.quick else (2048, 8192, 32768)
    groups_grid = (3,) if args.quick else (3, 4, 6, 8)
    for N, G in itertools.product(sizes, groups_grid):
        ids = [f"r{i:06d}" for i in range(N)]
        cohorts = [{"id": f"g{g}", "record_ids": ids[N*g//G:N*(g+1)//G]} for g in range(G)]
        snapshot = snapshot_cls({rid: {} for rid in ids})
        contract = {"snapshot_id": "synthetic", "predicate_id": "synthetic_v1",
                    "population_scope": "constructed overhead fixture", "risk": {"alpha": .05, "scope": "this_request"},
                    "budget": {"max_oracle_record_predicate_calls": N}, "cohorts": cohorts,
                    "decision": {"type": "topk", "candidates": [c["id"] for c in cohorts], "k": G//2}}
        compiled, (matrix, family) = measurement(lambda: compiler(contract, snapshot), args.repetitions)
        proxy = proxy_cls(seed=431)
        freezing, cells = measurement(lambda: frozen.freeze_coefficient_cells(ids, matrix, proxy, n_bins=1), args.repetitions)
        states = {c.cell_id: SimpleNamespace(N=c.N, n=max(1, c.N//4), s=c.N//8,
                                            bounds=(c.N//4, 3*c.N//4), width=c.N//2) for c in cells}
        timing, chosen = measurement(lambda: scheduler.choose_by_certificate_gain_per_cost(cells, states, {}, family), args.repetitions)
        rows.append({"fixture": "compiled_topk", "support": N, "groups": G,
                     "cells": len(cells), "atoms": len(family.atoms), "witnesses": len(family.certificates),
                     "compile": compiled, "freeze": freezing, "historical_schedule": timing,
                     "chosen_cell_batch": chosen})
    if not args.quick:
        for H, J, W in itertools.product((1, 4, 16, 64), (8, 32, 56), (1, 8, 70)):
            atoms = [logic.Atom(j, "lower", Fraction(0), j, str(j), ("a", "b")) for j in range(J)]
            witnesses = [list(x) for x in itertools.islice(itertools.combinations(range(J), 4), W)]
            family = logic.CertificateFamily(atoms, witnesses, decision_type="synthetic_or")
            cells = [frozen.Cell(h, tuple(Fraction(1 if (h+j)%2 else -1, 1024) for j in range(J)),
                                 0, [f"h{h}r{i}" for i in range(1024)]) for h in range(H)]
            states = {c.cell_id: SimpleNamespace(N=c.N, n=256, s=128, bounds=(256, 768), width=512) for c in cells}
            timing, chosen = measurement(lambda: scheduler.choose_by_certificate_gain_per_cost(cells, states, {}, family), args.repetitions)
            rows.append({"fixture": "scheduler_factor_grid", "cells": H, "atoms": J,
                         "witnesses": len(witnesses), "historical_schedule": timing,
                         "chosen_cell_batch": chosen})
    write_new(args.output, {"scope": "Synthetic historical-reference CPU overhead only; no real runtime/scientific outcome",
                            "quick_smoke": args.quick, "driver_sha256": file_hash(__file__),
                            "repetitions": args.repetitions, "rows": rows,
                            "interpretation": "Top-k naturally couples J and witnesses. The explicit scheduler grid varies them separately using constructed logical families and valid-shaped metadata states, not realized confidence trajectories."})
    print(f"Wrote {len(rows)} constructed CPU fixtures to {args.output}")


if __name__ == "__main__":
    main()
