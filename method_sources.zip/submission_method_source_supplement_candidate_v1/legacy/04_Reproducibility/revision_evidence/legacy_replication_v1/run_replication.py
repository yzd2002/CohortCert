"""Post-hoc replication on all 320 ORIGINAL test contracts; never tune policies.

The immutable v2 executor/policies and generic audit helpers are imported by path.
Saved original labels retain their unpinned-upstream-operator limitation.
This driver changes the evaluated completion semantics and is NOT an overwrite
or a validation of historical experiment paths.
"""
from __future__ import annotations
import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
import csv
from dataclasses import asdict
from datetime import datetime, timezone
import gzip
import hashlib
import json
import math
import multiprocessing as mp
import os
from pathlib import Path
import sys
import time

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
FROZEN = WORK/'policy_freeze_v1'
sys.path.insert(0,str(FROZEN))
from executor_v2.run_grid import (encode, file_hash, new_json, atomic_json,
    core_module, runtime_sources, substream, seed_records, independent_family,
    reference_evaluation, result_invariants, SealedReplay, require, digest)
from executor_v2.execution import Plan, execute
from executor_v2.baseline_policies import MatchedLeastSampled, DualGreedy
from executor_v2.frontier_policy import ForecastFrontierPolicy

DATA = {}
FIELDS = ['dataset','query_id','predicate','kind','method','seed_id','semantics',
          'status','reason','correct_complete','correct_complete_vector_only',
          'source_error','wrong_true_claims','wrong_false_claims','source_proof_errors',
          'terminal_source_noncoverage_atoms','semantic_calls','support_size','budget',
          'calls_per_support','conservative_cap_charge','executor_wall_ms','executor_cpu_ms',
          'policy_build_wall_ms','pilot_ids_sha256','pilot_labels_sha256','scores_sha256',
          'partition_sha256','priors_sha256','permutations_sha256','raw_record_sha256']


def active_contract(contract):
    """Reference-only removal of irrelevant declared cohorts, not execution edits."""
    used=set()
    for d in contract['decisions']:
        used.update([d['left'],d['right']] if d['type'] in ('compare','direction','equivalence') else d['candidates'])
    return {**contract,'cohorts':[c for c in contract['cohorts'] if c['id'] in used]}


def initialize(manifest,stop):
    global DATA
    for p,h in manifest['source_sha256'].items():require(file_hash(p)==h,'Changed frozen runtime dependency: '+p)
    for p,h in manifest['input_sha256'].items():require(file_hash(p)==h,'Changed replication input: '+p)
    from threadpoolctl import threadpool_limits
    limiter=threadpool_limits(1)
    core=Path(manifest['core_root'])
    compiler=core_module(core,'query.compiler')
    qs=[json.loads(s) for s in (core/'data/queries/all_queries.jsonl').read_text().splitlines() if s.strip()]
    qs={q['query_id']:q for q in qs if q['split']=='test'}
    snapshots={};proxies={};labels={}
    for ds in ('cfpb','opinrank'):
        snapshots[ds]=core_module(core,'query.parquet_snapshot').ParquetSnapshot(core/f'data/cohorts/{ds}_snapshot.parquet')
        proxies[ds]=core_module(core,'engine.proxy').EmbeddingLRProxy(ds,core/'data/embeddings')
        loader=core_module(core,'engine.oracle_interface').LabelSnapshot
        labels[ds]={p.stem.split('__',1)[1]:loader.load(p,verify_hash=True).labels for p in sorted((core/'data/label_snapshots').glob(ds+'__*.json'))}
        require(len(labels[ds])==4,'Expected all four original predicate maps')
    DATA={'manifest':manifest,'stop':stop,'limiter':limiter,'queries':qs,'snapshots':snapshots,
          'proxies':proxies,'labels':labels,'compiler':compiler}


def run_shard(shard):
    manifest=DATA['manifest'];stop=DATA['stop'];ds=shard['dataset'];method=shard['method'];seed=shard['seed']
    out=Path(manifest['_result_dir']);name=shard['name'];rows=0;failure=None;started=time.perf_counter()
    snapshot=DATA['snapshots'][ds];population=set(snapshot.record_ids());proxy=DATA['proxies'][ds]
    with gzip.open(out/(name+'.jsonl.gz'),'xt',compresslevel=1,encoding='utf-8') as raw, (out/(name+'.csv')).open('x',newline='') as table:
        writer=csv.DictWriter(table,fieldnames=FIELDS);writer.writeheader()
        for qid in shard['query_ids']:
            if stop.is_set():break
            q=DATA['queries'][qid];labels=DATA['labels'][ds][q['predicate_id']]
            matrix,_=DATA['compiler'].compile_signed_decisions(q['contract'],snapshot)
            support=len({rid for row in matrix.rows for rid,a in row.items() if a})
            cap=max(1,math.ceil(support*.5));semantics='positive_only' if q['kind']=='ranking' else 'bidirectional'
            planning=substream(seed['planning_seed'],'legacy-planning-v1',qid)
            exploration=substream(seed['exploration_seed'],'legacy-exploration-v1',qid)
            start=time.perf_counter()
            policy=(MatchedLeastSampled() if method=='matched' else DualGreedy() if method=='dual_greedy' else
                    ForecastFrontierPolicy(seed=planning,replan_steps=8,grid_points=6,time_limit=.05,max_wall_seconds=.15,max_cells=256))
            build_ms=(time.perf_counter()-start)*1000
            plan=Plan(int(seed['pilot_seed']),int(seed['formal_seed']),exploration,
                      alpha_override=.05,budget_override=cap,semantics=semantics)
            oracle=SealedReplay(labels,population,cap)
            result=execute(q['contract'],snapshot,oracle,proxy,policy,plan,
                           core_root=manifest['core_root'],policy_spec={'name':method,'frozen_primary_v1':True,'posthoc_legacy_replication':True})
            cert=result['certificate'];fatal=cert.get('framework_exception')
            try:
                result_invariants(result,oracle,support,cap)
                evaluation=reference_evaluation(active_contract(q['contract']),snapshot,labels,cert)
            except Exception as e:
                fatal={'audit_exception':repr(e)};evaluation=None
            if fatal:
                failure={'query_id':qid,'detail':fatal,'attempted':len(oracle.attempted)};stop.set()
            payload={'scope':manifest['scope'],'manifest_sha256':manifest['_manifest_sha256'],
                     'dataset':ds,'query_id':qid,'method':method,'seed':seed,'plan':asdict(plan),
                     'result':result,'reference_evaluation':evaluation,'failure':failure}
            encoded=encode(payload);raw.write(encoded+'\n');raw.flush()
            if evaluation is None:
                row={'dataset':ds,'query_id':qid,'predicate':q['predicate_id'],'kind':q['kind'],'method':method,
                     'seed_id':seed['seed_id'],'semantics':semantics,'status':'framework_failure',
                     'reason':repr(failure),'correct_complete':False,'semantic_calls':len(oracle.attempted),
                     'support_size':support,'budget':cap,'conservative_cap_charge':cap}
            else:
                bad=evaluation['source_error'];f=cert.get('frozen',{})
                row={'dataset':ds,'query_id':qid,'predicate':q['predicate_id'],'kind':q['kind'],'method':method,
                     'seed_id':seed['seed_id'],'semantics':semantics,'status':cert['status'],'reason':cert['reason'],
                     'correct_complete':evaluation['correct_complete'],'correct_complete_vector_only':evaluation['correct_complete_vector_only'],
                     'source_error':bad,'wrong_true_claims':len(evaluation['wrong_true_claims']),
                     'wrong_false_claims':len(evaluation['wrong_false_claims']),'source_proof_errors':len(evaluation['source_proof_errors']),
                     'terminal_source_noncoverage_atoms':len(evaluation['terminal_source_noncoverage_atoms']),
                     'semantic_calls':cert['semantic_calls'],'support_size':support,'budget':cap,
                     'calls_per_support':cert['semantic_calls']/support if support else 0,
                     'conservative_cap_charge':cap if bad or cert['status']=='execution_error' else cert['semantic_calls'],
                     'executor_wall_ms':result['total']['wall_ms'],'executor_cpu_ms':result['total']['cpu_ms'],
                     'policy_build_wall_ms':build_ms,**{key:f.get(key,'') for key in FIELDS if key.endswith('_sha256') and key!='raw_record_sha256'}}
            row['raw_record_sha256']=hashlib.sha256(encoded.encode()).hexdigest();writer.writerow(row);table.flush();rows+=1
            atomic_json(out/(name+'.progress.json'),{'status':'failed' if failure else 'running','rows':rows,'expected':len(shard['query_ids']),'failure':failure})
            if failure:break
    receipt={'status':'failed' if failure else 'complete' if rows==len(shard['query_ids']) else 'stopped_partial',
             'shard':name,'rows':rows,'expected':len(shard['query_ids']),'failure':failure,'elapsed_seconds':time.perf_counter()-started}
    atomic_json(out/(name+'.progress.json'),receipt);return receipt


def freeze(args):
    core=args.core.resolve();out=args.out.resolve();out.mkdir(exist_ok=False,parents=True)
    qs=[json.loads(s) for s in (core/'data/queries/all_queries.jsonl').read_text().splitlines() if s.strip()]
    qs=[q for q in qs if q['split']=='test'];require(len(qs)==320,'Require all 320 original test contracts')
    require(len({q['query_id'] for q in qs})==320,'Duplicate original test query IDs')
    protocol=json.loads((WORK/'natural_overlap/protocol_hcap256_scenario_seeds_before_annotation_access.json').read_text())
    seeds=seed_records(protocol)
    deps=runtime_sources(core);deps[str(Path(__file__).resolve())]=file_hash(__file__)
    inputs=[core/'data/queries/all_queries.jsonl']
    for ds in ('cfpb','opinrank'):
        inputs.extend([core/f'data/cohorts/{ds}_snapshot.parquet',core/f'data/embeddings/{ds}_emb.npy',core/f'data/embeddings/{ds}_index.parquet'])
        inputs.extend(sorted((core/'data/label_snapshots').glob(ds+'__*.json')))
    shards=[{'dataset':ds,'method':method,'seed':seed,'name':f'{ds}__{method}__seed{seed["seed_id"]:02d}',
             'query_ids':sorted(q['query_id'] for q in qs if q['dataset']==ds)}
            for ds in ('cfpb','opinrank') for method in ('matched','dual_greedy','forecast') for seed in seeds]
    manifest={'version':'posthoc-legacy-replication-v1','created_utc':datetime.now(timezone.utc).isoformat(),
              'scope':'Post-hoc saved-reference replication on all original 320 test contracts; final new policy frozen; no human validation of these eight predicates; original upstream model unpinned; differs from historical execution semantics/kernel.',
              'outcome_access':'Existing original outcomes already known; root also saw new Civil human primary outcomes before deciding this replication. No policy or query tuning permitted.',
              'core_root':str(core),'workers':args.workers,'source_sha256':deps,
              'input_sha256':{str(p):file_hash(p) for p in inputs},'primary_spec_sha256':file_hash(WORK/'primary_run_spec_v1.json'),
              'shards':shards,'expected_rows':9600,'cap_percent':50,'semantics':'bidirectional nonrank; positive-only strict rank identification',
              'pairing':'Ten frozen seed streams; same pilot/formalprefixes and source labels across all three allocation methods',
              'thread_environment':{'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1','PYTHONHASHSEED':'0'}}
    new_json(out/'manifest.json',manifest);print(encode({'manifest':str(out/'manifest.json'),'sha256':file_hash(out/'manifest.json'),'expected_rows':9600,'runs_launched':0}))


def run(args):
    p=args.manifest.resolve();h=file_hash(p);require(h==args.expect_sha256,'Manifest hash changed')
    manifest=json.loads(p.read_text());out=p.parent/('probe_results' if args.mode=='probe' else 'results');out.mkdir(exist_ok=False)
    manifest.update(_manifest_sha256=h,_result_dir=str(out));os.environ.update(manifest['thread_environment'])
    shards=manifest['shards']
    if args.mode=='probe':
        shards=[{**s,'name':s['name']+'__probe','query_ids':s['query_ids'][:1]} for s in shards if s['seed']['seed_id']==0]
    context=mp.get_context('spawn');receipts=[]
    with context.Manager() as manager:
        stop=manager.Event()
        with ProcessPoolExecutor(max_workers=min(manifest['workers'],len(shards)),mp_context=context,initializer=initialize,initargs=(manifest,stop)) as pool:
            futures=[pool.submit(run_shard,s) for s in shards]
            for f in as_completed(futures):
                try:receipt=f.result()
                except Exception as e:stop.set();receipt={'status':'uncaught_worker_failure','failure':repr(e),'rows':0}
                receipts.append(receipt);atomic_json(out/'progress.json',{'completed_shards':len(receipts),'expected_shards':len(shards),'receipts':receipts})
                print(encode(receipt),flush=True)
    expected=sum(len(s['query_ids']) for s in shards);written=sum(r['rows'] for r in receipts)
    complete=all(r['status']=='complete' for r in receipts) and written==expected
    # Independently compare paired frozen identities after all complete shards.
    identity={};pairing_fail=[]
    for p in sorted(out.glob('*.csv')):
        for r in csv.DictReader(p.open()):
            if r['status']=='framework_failure':continue
            key=(r['dataset'],r['query_id'],r['seed_id']);value=tuple(r[k] for k in ('pilot_ids_sha256','pilot_labels_sha256','scores_sha256','partition_sha256','priors_sha256','permutations_sha256'))
            if key in identity and value!=identity[key]:pairing_fail.append(key)
            identity[key]=value
    complete=complete and not pairing_fail
    receipt={'status':'complete' if complete else 'incomplete_preserved','manifest_sha256':h,'expected_rows':expected,'written_rows':written,'pairing_failures':pairing_fail,'shards':receipts,'scope':manifest['scope'],'new_model_forwards':0}
    new_json(out/'completion.json',receipt);print(encode({k:v for k,v in receipt.items() if k!='shards'}));return 0 if complete else 1


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--mode',choices=('freeze','probe','execute'),required=True)
    p.add_argument('--core',type=Path);p.add_argument('--out',type=Path);p.add_argument('--workers',type=int,default=16)
    p.add_argument('--manifest',type=Path);p.add_argument('--expect-sha256');args=p.parse_args()
    if args.mode=='freeze':freeze(args);return 0
    return run(args)


if __name__=='__main__':raise SystemExit(main())
