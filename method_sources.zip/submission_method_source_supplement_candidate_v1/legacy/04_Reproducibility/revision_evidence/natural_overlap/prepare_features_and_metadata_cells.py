#!/usr/bin/env python3
"""Freeze target-blind text features and exact metadata coefficient-cell counts."""
from pathlib import Path
from collections import Counter,defaultdict
from fractions import Fraction
from itertools import combinations
import json,hashlib,time,os,sys,importlib.metadata
for name in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:
    os.environ[name]='1'
import numpy as np
import pyarrow as pa, pyarrow.parquet as pq
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import TruncatedSVD
from sklearn.preprocessing import normalize
ROOT=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    assert not (ROOT/'text_features_and_cells_receipt.json').exists()
    protocol=json.loads((ROOT/'protocol_bidirectional_before_annotation_access.json').read_text())
    receipt=json.loads((ROOT/'metadata_preparation_receipt.json').read_text())
    assert receipt['target_score_values_converted_or_accessed'] is False
    assert receipt['metadata_feasibility_pass']
    assert sha(ROOT/'text_metadata_snapshot.parquet')==receipt['snapshot_sha256']
    rows=pq.read_table(ROOT/'text_metadata_snapshot.parquet').to_pylist()
    groups=protocol['cohorts'];names={g:i for i,g in enumerate(groups)}
    pattern_counts=Counter(tuple(r[f'mentions_{g}'] for g in groups) for r in rows)
    denominators={g:sum(count*int(pat[i]) for pat,count in pattern_counts.items()) for i,g in enumerate(groups)}
    cell_rows=[]
    queries=[json.loads(x) for x in (ROOT/'queries_before_annotation_access.jsonl').read_text().splitlines()]
    for q in queries:
        contract=q['contract']
        mapping={g['id']:g['filter_ast']['eq'][0][len('mentions_'):] for g in contract['cohorts']}
        pairs=[]
        for d in contract['decisions']:
            if d['type'] in ['compare','equivalence']:
                pairs.append((mapping[d['left']],mapping[d['right']]))
            else:
                pairs.extend(combinations([mapping[x] for x in d['candidates']],2))
        pairs=list(dict.fromkeys(pairs))
        counts=Counter();union=0
        for pat,count in pattern_counts.items():
            if any(pat[names[g]] for g in mapping.values()):union+=count
            sig=tuple(Fraction(int(pat[names[a]]),denominators[a])-Fraction(int(pat[names[b]]),denominators[b]) for a,b in pairs)
            if any(sig):counts[sig]+=count
        support=sum(counts.values())
        h=len(counts);upper=sum(min(4,n) for n in counts.values())
        cell_rows.append({'query_id':q['query_id'],'predicate_id':q['predicate_id'],'kind':q['kind'],'summary_subtype':q.get('summary_subtype'),'union_size':union,'support_size':support,'zero_coefficient_union_rows':union-support,'coefficient_cell_count_b1':h,'four_bin_maximum_cell_count':upper,'four_bin_can_exceed_H64':upper>64,'min_signature_size':min(counts.values()),'max_signature_size':max(counts.values())})
    (ROOT/'metadata_coefficient_cells.jsonl').write_text(''.join(json.dumps(r,separators=(',',':'))+'\n' for r in cell_rows))
    summaries={}
    for kind in ['pairwise','equivalence','summary','ranking']:
        rs=[r for r in cell_rows if r['kind']==kind]
        summaries[kind]={'queries':len(rs),'b1_H_min':min(r['coefficient_cell_count_b1'] for r in rs),'b1_H_max':max(r['coefficient_cell_count_b1'] for r in rs),'b1_H_counts':dict(sorted(Counter(r['coefficient_cell_count_b1'] for r in rs).items())),'b4_H_upper_max':max(r['four_bin_maximum_cell_count'] for r in rs),'b4_H_upper_exceeds_64_queries':sum(r['four_bin_can_exceed_H64'] for r in rs),'support_min':min(r['support_size'] for r in rs),'support_max':max(r['support_size'] for r in rs)}
    start=time.perf_counter()
    tf=TfidfVectorizer(max_features=10000,min_df=2,ngram_range=(1,2),sublinear_tf=True,dtype=np.float32)
    X=tf.fit_transform([r['text'] for r in rows])
    svd=TruncatedSVD(n_components=128,n_iter=5,random_state=431)
    emb=normalize(svd.fit_transform(X),norm='l2').astype(np.float32)
    out=ROOT/'data'/'embeddings';out.mkdir(parents=True,exist_ok=True)
    np.save(out/'civilcomments_emb.npy',emb)
    pq.write_table(pa.table({'record_id':[r['record_id'] for r in rows],'emb_row':range(len(rows))}),out/'civilcomments_index.parquet')
    feature_s=time.perf_counter()-start
    result={'protocol_sha256':sha(ROOT/'protocol_bidirectional_before_annotation_access.json'),'snapshot_sha256':receipt['snapshot_sha256'],'features_shape':list(emb.shape),'tfidf_shape':list(X.shape),'feature_build_wall_s':feature_s,'feature_sha256':sha(out/'civilcomments_emb.npy'),'index_sha256':sha(out/'civilcomments_index.parquet'),'metadata_cells_sha256':sha(ROOT/'metadata_coefficient_cells.jsonl'),'cell_summary':summaries,'cell_scope':'B1 H is exact before pilot subtraction. B4 is the metadata-only maximum sum(min(4, signature size)); actual proxy bins depend on future charged pilot labels and are not computed. No labels are needed for any reported cell count.','target_scores_accessed':False,'model_or_acquisition_replay_launched':False,'packages':{n:importlib.metadata.version(n) for n in ['numpy','scipy','scikit-learn','pyarrow','requests']},'python':sys.version,'script_sha256':sha(__file__)}
    (ROOT/'text_features_and_cells_receipt.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()

