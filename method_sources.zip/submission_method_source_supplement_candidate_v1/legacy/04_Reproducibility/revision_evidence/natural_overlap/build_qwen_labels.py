#!/usr/bin/env python3
"""Portable, gated four-predicate Qwen3-8B materialization; no annotation input.

Dry-run loads only tokenizer/configuration and frozen text. Full mode scores one
record and one predicate per forward, without KV/result reuse or generation.
"""
from pathlib import Path
import argparse,csv,hashlib,io,json,math,os,platform,sys,time,importlib.metadata
from label_build_common import PREDICATES,sha,require,utc,atomic_json,load_plan,load_snapshot,verify_code_freeze,verify_gate,ensure_out

FIELDS=['record_id','source_row_ordinal','predicate','model_label','input_tokens','logit_0','logit_1','cuda_forward_ms','row_wall_ms','text_sha256','operator_plan_sha256']
def text_hash(text):return hashlib.sha256(text.encode('utf-8')).hexdigest()
def check_model_files(ws,plan,model_dir,full_hash):
    manifest=json.loads((ws/plan['model']['expected_file_manifest']).read_text())
    require(manifest['model']==plan['model']['name'] and manifest['revision']==plan['model']['revision'],'Wrong expected model release.')
    expected_names={item['name'] for item in manifest['files']}
    for candidate in model_dir.iterdir():
        loader_override=(candidate.suffix in ('.safetensors','.bin','.model','.jinja') or candidate.name in ('added_tokens.json','special_tokens_map.json','chat_templates'))
        require(not loader_override or candidate.name in expected_names,'Unpinned model/tokenizer override: '+candidate.name)
    result=[]
    for item in manifest['files']:
        p=model_dir/item['name']
        require(p.is_file() and p.stat().st_size==item['bytes'],'Missing/wrong model file: '+item['name'])
        checked=full_hash or not item['name'].endswith('.safetensors')
        if checked:require(sha(p)==item['sha256'],'Model file hash mismatch: '+item['name'])
        result.append({'name':item['name'],'bytes':item['bytes'],'expected_sha256':item['sha256'],'sha256_verified':checked})
    return result
def tokenizer_and_ids(model_dir):
    from transformers import AutoTokenizer
    tok=AutoTokenizer.from_pretrained(model_dir,local_files_only=True,trust_remote_code=False)
    ids={}
    for s in ['0','1']:
        v=tok.encode(s,add_special_tokens=False);require(len(v)==1,'Each label must be a single token.');ids[s]=v[0]
    require(ids['0']!=ids['1'],'Label token IDs collide.')
    return tok,ids
def formatted(tok,plan,pred,text):
    return tok.apply_chat_template([{'role':'user','content':plan['prompts'][pred].format(text=text)}],tokenize=False,add_generation_prompt=True,enable_thinking=False)
def token_preflight(tok,plan,rows):
    result={}
    for pred in PREDICATES:
        lengths=[];h=hashlib.sha256()
        # Batch tokenization is tokenizer-only; no inference batching/reuse.
        for start in range(0,len(rows),256):
            part=rows[start:start+256]
            texts=[formatted(tok,plan,pred,r['text']) for r in part]
            encoded=tok(texts,add_special_tokens=False,truncation=False,padding=False)['input_ids']
            for r,s,ids in zip(part,texts,encoded):
                require(len(ids)<=plan['model']['max_context_tokens'],'Context overflow; do not truncate or replace frozen rows.')
                lengths.append(len(ids));h.update(r['record_id'].encode()+b'\0'+s.encode()+b'\n')
        canary_lengths=[len(tok.encode(formatted(tok,plan,pred,c['text']),add_special_tokens=False)) for c in plan['canaries'][pred]]
        require(all(n<=plan['model']['max_context_tokens'] for n in canary_lengths),'Canary context overflow.')
        result[pred]={'rows':len(lengths),'input_tokens_total':sum(lengths),'min_input_tokens':min(lengths),'max_input_tokens':max(lengths),'formatted_inputs_ordered_sha256':h.hexdigest(),'canary_input_token_lengths':canary_lengths}
    return result
def encode_csv_row(values,header=False):
    s=io.StringIO(newline='');w=csv.DictWriter(s,fieldnames=FIELDS,lineterminator='\n')
    if header:w.writeheader()
    else:w.writerow(values)
    return s.getvalue().encode('utf-8')
def read_prefix(path,pred,rows,plan_sha):
    labels={};seen={};disagreements=[];completed=0
    if not path.exists():return labels,seen,disagreements,completed
    with path.open('rb') as f:
        f.seek(0,os.SEEK_END);size=f.tell()
        require(size>0,'Empty existing prediction file.')
        f.seek(-1,os.SEEK_END);require(f.read(1)==b'\n','Incomplete CSV tail; preserve output and review before resuming.')
    with path.open(newline='',encoding='utf-8') as f:
        reader=csv.DictReader(f);require(reader.fieldnames==FIELDS,'Prediction schema changed.')
        for i,item in enumerate(reader):
            require(i<len(rows),'Existing predictions exceed frozen population.')
            r=rows[i];h=text_hash(r['text'])
            require(item['record_id']==r['record_id'] and int(item['source_row_ordinal'])==r['source_row_ordinal'],'Prediction prefix has wrong row order.')
            require(item['predicate']==pred and item['text_sha256']==h and item['operator_plan_sha256']==plan_sha,'Prediction prefix belongs to another operator/snapshot.')
            require(item['model_label'] in ['0','1'],'Nonbinary prior prediction.')
            a,b=float(item['logit_0']),float(item['logit_1'])
            require(math.isfinite(a) and math.isfinite(b),'Nonfinite prior logits.')
            value=int(item['model_label']);require(value==int(b>=a),'Prior label does not match saved logits.')
            require(0<int(item['input_tokens'])<=4096,'Invalid prior context length.')
            if h in seen and seen[h]!=value:disagreements.append(r['record_id'])
            seen[h]=value;labels[r['record_id']]=value;completed=i+1
    return labels,seen,disagreements,completed
def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--workspace',type=Path,required=True)
    ap.add_argument('--model-dir',type=Path,required=True)
    ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--mode',choices=['dry-run','full'],default='dry-run')
    ap.add_argument('--device',default='cuda:0')
    ap.add_argument('--gate-file',type=Path)
    ap.add_argument('--authorize-model-label-build',metavar='OPERATOR_PLAN_SHA256')
    ap.add_argument('--resume',action='store_true')
    args=ap.parse_args()
    ws,plan,plan_sha=load_plan(args.workspace);freeze_sha=verify_code_freeze(ws,plan_sha)
    rows=load_snapshot(ws,plan);model_dir=args.model_dir.resolve()
    require(plan['model']['dtype']=='bfloat16' and plan['model']['attention']=='sdpa' and plan['model']['batch_size']==1 and plan['model']['use_cache'] is False,'Frozen model mode changed.')
    if args.mode=='dry-run':
        require(not args.resume and args.authorize_model_label_build is None,'Dry-run cannot authorize or resume inference.')
        out=ensure_out(args.out);start=time.perf_counter()
        files=check_model_files(ws,plan,model_dir,False)
        tok,ids=tokenizer_and_ids(model_dir);inputs=token_preflight(tok,plan,rows)
        result={'status':'dry_run_only','created_utc':utc(),'operator_plan_sha256':plan_sha,'protocol_sha256':plan['protocol_sha256'],'snapshot_sha256':plan['snapshot_sha256'],'code_freeze_sha256':freeze_sha,'rows':len(rows),'predicates':list(PREDICATES),'label_token_ids':ids,'input_preflight':inputs,'model_files':files,'large_weights_sha256_verified':False,'model_weights_loaded':False,'model_forward_calls':0,'source_annotations_opened':False,'target_score_values_interpreted':False,'wall_seconds':time.perf_counter()-start,'script_sha256':sha(__file__)}
        atomic_json(out/'model_build_dry_run.json',result)
        print(json.dumps({k:result[k] for k in ['status','operator_plan_sha256','rows','label_token_ids','input_preflight','model_weights_loaded','model_forward_calls','source_annotations_opened','wall_seconds']},indent=2));return
    gate=verify_gate(args.gate_file,ws,plan,plan_sha,'allow_model_label_build',args.authorize_model_label_build)
    require(os.environ.get('PYTHONHASHSEED')=='0','Set PYTHONHASHSEED=0 before launching the interpreter.')
    require(os.environ.get('CUBLAS_WORKSPACE_CONFIG')==':4096:8','Set CUBLAS_WORKSPACE_CONFIG=:4096:8 before launch.')
    require(args.device.startswith('cuda:'),'Full frozen BF16 label build requires a CUDA device.')
    for name in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[name]='1'
    out=ensure_out(args.out,resume=args.resume)
    binding={'operator_plan_sha256':plan_sha,'protocol_sha256':plan['protocol_sha256'],'snapshot_sha256':plan['snapshot_sha256'],'code_freeze_sha256':freeze_sha,'model_revision':plan['model']['revision']}
    if args.resume:
        require((out/'build_binding.json').exists(),'Resume directory lacks its fixed build binding.')
        old=json.loads((out/'build_binding.json').read_text())
        require(all(old[k]==v for k,v in binding.items()),'Resume inputs/operator/code changed.')
        for failure in out.glob('failure_*.json'):
            require(json.loads(failure.read_text()).get('phase')!='canary','Failed canary requires root review; this output cannot silently resume.')
    else:atomic_json(out/'build_binding.json',binding|{'created_utc':utc(),**gate})
    session=len(list(out.glob('runtime_session_*.json')))
    phase='model_verification';current=None;pred=None;session_start=time.perf_counter()
    try:
        files=check_model_files(ws,plan,model_dir,True)
        import torch
        from transformers import AutoModelForCausalLM
        torch.set_num_threads(1);torch.set_num_interop_threads(1)
        torch.manual_seed(plan['model']['seed']);torch.cuda.manual_seed_all(plan['model']['seed'])
        torch.use_deterministic_algorithms(True)
        torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False;torch.backends.cudnn.benchmark=False
        require(torch.cuda.is_available(),'CUDA is unavailable.')
        torch.cuda.set_device(args.device)
        require(torch.cuda.is_bf16_supported(),'CUDA BF16 support unavailable.')
        tok,ids=tokenizer_and_ids(model_dir)
        phase='token_preflight';preflight=token_preflight(tok,plan,rows)
        phase='model_load';load_start=time.perf_counter()
        model=AutoModelForCausalLM.from_pretrained(model_dir,local_files_only=True,trust_remote_code=False,use_safetensors=True,dtype=torch.bfloat16,device_map={'':args.device},attn_implementation='sdpa')
        model.eval();model.config.use_cache=False;torch.cuda.synchronize(args.device)
        load_wall=time.perf_counter()-load_start
        runtime={'session_id':session,'started_utc':utc(),**binding,**gate,'model_files':files,'all_expected_model_file_hashes_verified':True,'model_load_wall_seconds':load_wall,'device':args.device,'gpu':torch.cuda.get_device_name(args.device),'cuda':torch.version.cuda,'python':platform.python_version(),'packages':{n:importlib.metadata.version(n) for n in ['torch','transformers','tokenizers','numpy','pyarrow','safetensors']},'input_preflight':preflight,'model_mode':plan['model']}
        atomic_json(out/f'runtime_session_{session:03d}.json',runtime)
        def score(pred,text):
            begin=time.perf_counter();s=formatted(tok,plan,pred,text)
            inputs=tok(s,return_tensors='pt',add_special_tokens=False,truncation=False)
            n=inputs['input_ids'].shape[-1]
            require(n<=plan['model']['max_context_tokens'],'Context overflow: no truncation is permitted.')
            inputs={k:v.to(args.device) for k,v in inputs.items()}
            a,b=torch.cuda.Event(enable_timing=True),torch.cuda.Event(enable_timing=True)
            a.record(torch.cuda.current_stream(args.device))
            with torch.inference_mode():
                logits=model(**inputs,use_cache=False,logits_to_keep=1).logits[0,-1]
            b.record(torch.cuda.current_stream(args.device));b.synchronize()
            zero,one=float(logits[ids['0']].item()),float(logits[ids['1']].item())
            require(math.isfinite(zero) and math.isfinite(one),'Nonfinite model logits.')
            return {'model_label':int(one>=zero),'input_tokens':n,'logit_0':zero,'logit_1':one,'cuda_forward_ms':a.elapsed_time(b),'row_wall_ms':1000*(time.perf_counter()-begin)}
        completed_predicates={}
        for pred in PREDICATES:
            directory=out/pred;directory.mkdir(exist_ok=True)
            predictions=directory/'model_predictions.csv'
            labels,seen,disagreements,completed=read_prefix(predictions,pred,rows,plan_sha)
            # A complete prefix is preserved on resume, never reused to infer a
            # different row/predicate. Every unfinished row gets a fresh forward.
            if completed<len(rows):
                phase='canary';canary_results=[]
                for repeat in range(2):
                    for canary in plan['canaries'][pred]:
                        current={'canary_id':canary['id'],'repeat':repeat}
                        result=score(pred,canary['text'])
                        canary_results.append({'canary_id':canary['id'],'repeat':repeat,'expected_label':canary['expected_label'],**result})
                        atomic_json(directory/f'canaries_session_{session:03d}.json',{'provenance':plan['canary_policy']['provenance'],'operator_plan_sha256':plan_sha,'results':canary_results})
                require(all(r['model_label']==r['expected_label'] for r in canary_results),'A priori canary failed. Preserve outputs and stop before corpus inference.')
                phase='corpus'
                existing=predictions.exists()
                with predictions.open('ab' if existing else 'xb') as stream:
                    if not existing:stream.write(encode_csv_row({},header=True))
                    for i in range(completed,len(rows)):
                        r=rows[i];current={'record_id':r['record_id'],'source_row_ordinal':r['source_row_ordinal'],'row_index':i}
                        result=score(pred,r['text']);h=text_hash(r['text']);value=result['model_label']
                        if h in seen and seen[h]!=value:disagreements.append(r['record_id'])
                        seen[h]=value;labels[r['record_id']]=value
                        item={'record_id':r['record_id'],'source_row_ordinal':r['source_row_ordinal'],'predicate':pred,**result,'text_sha256':h,'operator_plan_sha256':plan_sha}
                        stream.write(encode_csv_row(item))
                        if (i+1)%plan['checkpoint_every_rows']==0 or i+1==len(rows):
                            stream.flush();os.fsync(stream.fileno())
                            progress={'status':'running','predicate':pred,'completed_rows_current_predicate':i+1,'expected_rows_per_predicate':len(rows),'completed_predicates':list(completed_predicates),'current_csv_bytes':predictions.stat().st_size,'current_csv_prefix_sha256':sha(predictions),'operator_plan_sha256':plan_sha,'snapshot_sha256':plan['snapshot_sha256'],'session_id':session,'session_wall_seconds':time.perf_counter()-session_start}
                            atomic_json(out/'build_progress.json',progress);print(json.dumps(progress),flush=True)
            require(len(labels)==len(rows) and set(labels)=={r['record_id'] for r in rows},'Predicate label coverage is incomplete.')
            label_map=directory/f'model_labels_{pred}_v1.json';atomic_json(label_map,labels)
            result={'predicate':pred,'rows':len(rows),'prediction_csv_sha256':sha(predictions),'model_label_map_sha256':sha(label_map),'repeat_text_disagreement_record_ids':disagreements,'operator_plan_sha256':plan_sha,'snapshot_sha256':plan['snapshot_sha256'],'source_annotations_opened':False}
            atomic_json(directory/'completion.json',result);completed_predicates[pred]=result
        complete={'status':'complete' if not any(r['repeat_text_disagreement_record_ids'] for r in completed_predicates.values()) else 'complete_with_repeat_disagreements','completed_utc':utc(),**binding,'predicates':completed_predicates,'rows_per_predicate':len(rows),'total_fixed_model_labels':len(rows)*len(PREDICATES),'last_session_wall_seconds':time.perf_counter()-session_start,'source_annotations_opened':False,'accuracy_or_prevalence_computed':False,'interpretation':'Saved fixed model-defined labels; no new human annotation or query-latency claim.'}
        atomic_json(out/'build_completion.json',complete);atomic_json(out/'build_progress.json',complete)
        print(json.dumps({'status':complete['status'],'total_fixed_model_labels':complete['total_fixed_model_labels'],'operator_plan_sha256':plan_sha},indent=2))
        if complete['status']!='complete':
            phase='repeat_stability';raise SystemExit(2)
    except BaseException as error:
        atomic_json(out/f'failure_session_{session:03d}.json',{'status':'failed','time_utc':utc(),'phase':phase,'predicate':pred,'current':current,'error_type':type(error).__name__,'message':str(error),**binding,'partial_outputs_preserved':True,'source_annotations_opened':False})
        raise

if __name__=='__main__':main()

