#!/usr/bin/env python3
"""Append independent scenario-planning/exploration seeds; preserve old plans."""
from pathlib import Path
import json,secrets,hashlib,datetime
ROOT=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
base=ROOT/'protocol_hcap256_before_annotation_access.json'
protocol=json.loads(base.read_text())
used={int(r[k]) for r in protocol['seed_pairs'] for k in ['pilot_seed','formal_seed']}
seeds=[]
for r in protocol['seed_pairs']:
    pair={'seed_id':r['seed_id']}
    for name in ['planning_seed','exploration_seed']:
        value=secrets.randbits(256)
        while value in used:value=secrets.randbits(256)
        used.add(value);pair[name]=str(value)
    seeds.append(pair)
protocol['planning_exploration_seed_amendment']={
 'frozen_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'base_protocol_sha256':sha(base),'seed_pairs':seeds,
 'independence':'Fresh independent256-bit secrets draws, disjoint from every preserved pilot/formal seed and from each other. No source target score or model outcome was accessed.',
 'sharing':'Match the same seed_id across all arms, predicates, caps and completion semantics; do not derive planning/exploration randomness from formal permutation seeds.',
 'planning_scope':'Scenario simulations use only the frozen/pilot-fitted model and acquired evidence. No unread label or future permutation position is an input.',
 'substreams':'If per-request/per-step substreams are needed, derive namespaced SHA256 streams from the corresponding planning or exploration seed and public request/step identifiers only.',
 'existing_seed_records_unchanged':True,'query_change':False
}
out=ROOT/'protocol_hcap256_scenario_seeds_before_annotation_access.json'
with out.open('x') as f:f.write(json.dumps(protocol,indent=2)+'\n')
old=ROOT/'label_build_plan_before_annotation_access.json';plan=json.loads(old.read_text())
plan['preserved_operator_plan_sha256']=sha(old)
plan['protocol_file']=out.name;plan['protocol_sha256']=sha(out)
plan['planning_seed_amendment_note']='Only the protocol binding changed; prompts, canaries, snapshot, source threshold and model settings are unchanged.'
new=ROOT/'label_build_plan_with_scenario_seeds_before_annotation_access.json'
with new.open('x') as f:f.write(json.dumps(plan,indent=2,ensure_ascii=False)+'\n')
receipt={'protocol_sha256':sha(out),'operator_plan_sha256':sha(new),'preserved_Hcap_protocol_sha256':sha(base),'preserved_operator_plan_sha256':sha(old),'pilot_formal_seeds_unchanged':protocol['seed_pairs']==json.loads(base.read_text())['seed_pairs'],'planning_seed_count':10,'exploration_seed_count':10,'target_scores_interpreted':False,'model_inference_launched':False}
with (ROOT/'scenario_seed_freeze_receipt.json').open('x') as f:f.write(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))

