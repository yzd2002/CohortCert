#!/usr/bin/env python3
"""Recover exact pinned source BYTES using verified CodaLab identity byte ranges.

This is transport only: no CSV/annotation parsing, no frozen builder changes.
The prior partial is read/copied, never modified; only the final exact SHA256
permits publication at the new destination.
"""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import argparse,hashlib,json,os,requests,shutil,threading,time,datetime

EXPECTED_BYTES=272774548
EXPECTED_SHA='5fbf41b9903e6a8f78a3c2e5ea3a659621336538a48c1be8d051d50082b5af79'
URL='https://worksheets.codalab.org/rest/bundles/0x8cd3de0634154aeaad2ee6eb96723c6e/contents/blob/all_data_with_identities.csv'
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()
def atomic(path,value):
    p=Path(path);tmp=p.with_name(p.name+'.tmp')
    with tmp.open('w') as f:json.dump(value,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
    tmp.replace(p)
def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--preserved-partial',type=Path,required=True)
    ap.add_argument('--destination',type=Path,required=True)
    ap.add_argument('--receipts',type=Path,required=True)
    ap.add_argument('--workers',type=int,default=3)
    ap.add_argument('--range-bytes',type=int,default=8*1024*1024)
    ap.add_argument('--max-attempts-per-range',type=int,default=8)
    args=ap.parse_args()
    partial=args.preserved_partial.resolve();dest=args.destination.resolve();out=args.receipts.resolve()
    assert partial.is_file() and not dest.exists()
    assert 1<=args.workers<=6 and 1024<=args.range_bytes<=16*1024*1024
    assert not out.exists();out.mkdir(parents=True);dest.parent.mkdir(parents=True,exist_ok=True)
    temporary=dest.with_name(dest.name+'.assembling');assert not temporary.exists()
    partial_size=partial.stat().st_size;assert 0<partial_size<EXPECTED_BYTES
    partial_sha=sha(partial);start=time.perf_counter();local=threading.local()
    def session():
        if not hasattr(local,'session'):
            local.session=requests.Session();local.session.headers['Accept-Encoding']='identity'
        return local.session
    def fetch(a,b):
        errors=[]
        for attempt in range(1,args.max_attempts_per_range+1):
            try:
                with session().get(URL,headers={'Range':f'bytes={a}-{b}','Accept-Encoding':'identity'},stream=True,timeout=(30,90)) as r:
                    r.raise_for_status()
                    assert r.status_code in [200,206]
                    assert r.headers.get('Content-Encoding','identity')=='identity'
                    assert int(r.headers.get('Content-Length','-1'))==b-a+1
                    assert int(r.headers.get('X-Codalab-Target-Size','-1'))==EXPECTED_BYTES
                    data=b''.join(r.iter_content(1024*1024))
                    assert len(data)==b-a+1
                    return data,{'start':a,'end_inclusive':b,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'http_status':r.status_code,'attempts':attempt,'previous_errors':errors}
            except Exception as error:
                errors.append({'attempt':attempt,'type':type(error).__name__,'message':str(error)})
                if attempt==args.max_attempts_per_range:raise RuntimeError(json.dumps({'range':[a,b],'errors':errors})) from error
                time.sleep(min(2**(attempt-1),10))
    # Prove nonstandard status200 Range offsets before trusting the prefix copy.
    first,_=fetch(0,2047);overlap,_=fetch(1024,2047);assert first[1024:]==overlap
    check_size=min(8192,partial_size)
    tail,_=fetch(partial_size-check_size,partial_size-1)
    with partial.open('rb') as f:f.seek(partial_size-check_size);assert f.read()==tail
    with partial.open('rb') as source,temporary.open('xb') as target:
        shutil.copyfileobj(source,target,1024*1024);target.flush();os.fsync(target.fileno())
    ranges=[(a,min(EXPECTED_BYTES-1,a+args.range_bytes-1)) for a in range(partial_size,EXPECTED_BYTES,args.range_bytes)]
    receipt={'status':'running','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_url':URL,'expected_bytes':EXPECTED_BYTES,'expected_sha256':EXPECTED_SHA,'preserved_partial':str(partial),'preserved_partial_bytes':partial_size,'preserved_partial_sha256':partial_sha,'destination':str(dest),'temporary':str(temporary),'range_offset_overlap_verified':True,'partial_tail_verified':True,'source_csv_parsed':False,'completed_ranges':[],'completed_bytes':partial_size,'range_count':len(ranges),'workers':args.workers,'helper_sha256':sha(__file__)}
    atomic(out/'transport_progress.json',receipt)
    fd=os.open(temporary,os.O_RDWR)
    try:
        os.ftruncate(fd,EXPECTED_BYTES)
        def work(pair):
            a,b=pair;data,record=fetch(a,b);written=0
            while written<len(data):
                n=os.pwrite(fd,data[written:],a+written);assert n>0;written+=n
            return record
        with ThreadPoolExecutor(max_workers=args.workers) as pool:
            futures=[pool.submit(work,pair) for pair in ranges]
            for future in as_completed(futures):
                record=future.result();receipt['completed_ranges'].append(record);receipt['completed_bytes']+=record['bytes'];receipt['wall_seconds']=time.perf_counter()-start
                os.fsync(fd);atomic(out/'transport_progress.json',receipt)
                print(json.dumps({'status':'running','completed_bytes':receipt['completed_bytes'],'expected_bytes':EXPECTED_BYTES,'completed_ranges':len(receipt['completed_ranges']),'ranges':len(ranges),'wall_seconds':receipt['wall_seconds']}),flush=True)
        os.fsync(fd)
    except BaseException as error:
        receipt.update(status='failed',error_type=type(error).__name__,message=str(error),wall_seconds=time.perf_counter()-start)
        atomic(out/'transport_failure.json',receipt);raise
    finally:os.close(fd)
    actual_sha=sha(temporary);assert temporary.stat().st_size==EXPECTED_BYTES
    assert actual_sha==EXPECTED_SHA, 'Recovered whole-file SHA mismatch; assembling file preserved. Do not convert it.'
    assert sha(partial)==partial_sha and partial.stat().st_size==partial_size,'Original partial changed.'
    assert not dest.exists();temporary.replace(dest)
    receipt.update(status='complete',completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),actual_bytes=dest.stat().st_size,actual_sha256=actual_sha,preserved_partial_unchanged=True,wall_seconds=time.perf_counter()-start)
    receipt['completed_ranges']=sorted(receipt['completed_ranges'],key=lambda r:r['start'])
    atomic(out/'transport_completion.json',receipt);atomic(out/'transport_progress.json',receipt)
    print(json.dumps({k:receipt[k] for k in ['status','destination','actual_bytes','actual_sha256','preserved_partial_unchanged','wall_seconds']},indent=2),flush=True)
if __name__=='__main__':main()

