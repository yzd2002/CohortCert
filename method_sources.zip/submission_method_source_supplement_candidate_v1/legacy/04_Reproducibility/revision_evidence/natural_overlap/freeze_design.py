#!/usr/bin/env python3
"""Freeze all target-blind selection and query rules; no corpus rows are read."""
from pathlib import Path
from itertools import combinations, permutations
from collections import Counter
import hashlib, json, secrets, datetime

ROOT=Path(__file__).resolve().parent
GROUPS=['male','female','LGBTQ','christian','muslim','other_religions','black','white']
PREDICATES=['toxicity','insult','identity_attack','obscene']
def canonical(x): return json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False)
def digest(x): return hashlib.sha256(canonical(x).encode()).hexdigest()
def choose(xs,n,salt):
    return sorted(xs,key=lambda x:(hashlib.sha256((salt+'\0'+canonical(x)).encode()).hexdigest(),canonical(x)))[:n]
def main():
    path=ROOT/'protocol_before_annotation_access.json'
    assert not path.exists(), 'Frozen protocol exists; never overwrite it.'
    ROOT.mkdir(parents=True,exist_ok=True)
    design={
      'protocol_id':'cohortcert-natural-overlap-civilcomments-wilds-v1-20261102',
      'frozen_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
      'phase':'Before reading target annotation values, model outcomes, or replay outcomes. Only source documentation, source code and the CSV header were inspected.',
      'source':{
        'provider':'CivilComments/Jigsaw, redistributed as CivilComments-WILDS v1.0',
        'bundle_uuid':'0x8cd3de0634154aeaad2ee6eb96723c6e',
        'csv_url':'https://worksheets.codalab.org/rest/bundles/0x8cd3de0634154aeaad2ee6eb96723c6e/contents/blob/all_data_with_identities.csv',
        'archive_url':'https://worksheets.codalab.org/rest/bundles/0x8cd3de0634154aeaad2ee6eb96723c6e/contents/blob/',
        'csv_expected_bytes':272774548,
        'archive_reported_compressed_bytes':90910086,
        'wilds_loader_commit':'e79f7f4f3cd4633e7274af82abd8fd3095e77f18',
        'wilds_loader_url':'https://github.com/p-lambda/wilds/blob/e79f7f4f3cd4633e7274af82abd8fd3095e77f18/wilds/datasets/civilcomments_dataset.py',
        'license':'CC0 1.0, including underlying comment text per TensorFlow and WILDS providers',
        'canonical_fallback_url':'https://storage.googleapis.com/jigsaw-unintended-bias-in-toxicity-classification/civil_comments_v1.2.zip',
        'canonical_fallback_expected_bytes':448174578,
        'canonical_fallback_sha256':'89a60573acbbfaf189b2c77278115eefcbc1654dbd8235dd8fbecc1b83f1585c',
        'canonical_fallback_status':'Anonymous HEAD returned HTTP 403 on 2026-11-02; do not silently substitute a different corpus.'
      },
      'population':{
        'snapshot_id':'civilcomments_wilds_mention_test_30k_v1',
        'source_split':'test',
        'size':30000,
        'eligibility':'WILDS split equals test; comment_text is a nonempty UTF-8 string after whitespace stripping; at least one of the eight fixed mention scores is >= 0.5. No target-score, annotation-confidence, toxicity-count, text-length, or outcome filtering.',
        'selection':'Take the 30000 eligible source rows with smallest SHA256 of snapshot_salt + NUL + zero-based CSV data-row ordinal + NUL + original id, tie by source row ordinal. Do not try another salt or snapshot after seeing labels or outcomes.',
        'snapshot_salt':'cohortcert-civilcomments-20261102-snapshot-v1',
        'record_id':'civilcomments-wilds-v1-row-{zero-based CSV data-row ordinal:06d}',
        'unit':'A retained source comment row, not a unique author or unique discussion. Retain duplicate texts and duplicate original IDs as separate source rows.',
        'membership':'Eight existing WILDS mention columns thresholded at >=0.5; no artificial intersections, disjointification, balancing or padding.',
        'membership_scope':'Comment mentions an identity according to existing crowd annotations. This is not the identity of the commenter, target, author or reader.',
        'source_scope':'The provider selected/enriched the identity-annotated subset, and WILDS changed source splits. Inference is only for this frozen finite subset; no claim that it represents all online comments.',
        'metadata_feasibility_rule':'Before target access, require 30000 eligible rows, >=6 of the 8 groups with n>=500, >=6 nonempty pairwise intersections and >=5% of selected rows belonging to >=2 groups. If it fails, retain the evidence and report the design as infeasible; no outcome-based repair.'
      },
      'cohorts':GROUPS,
      'predicate_columns':PREDICATES,
      'reference':{
        'binary_mapping':'For each fixed predicate, source decimal score >=0.5 maps to 1; lower scores map to 0. Exactly 0.5 is positive. Parse with Decimal, retaining the raw decimal string for audit.',
        'scope':'Existing crowd-reference labels, not objective ground truth or new human annotations. Different raters and subjective judgments can disagree. Original CohortCert eight predicates remain unvalidated.',
        'no_missing_value_selection':'After freezing the selected row IDs and query contracts, validate all four source fields. Any missing/nonfinite/out-of-range score fails preparation; retain the failure instead of dropping/replacing rows or predicates.',
        'annotator_count_scope':'identity_annotator_count and toxicity_annotator_count are metadata diagnostics. Do not infer that toxicity_annotator_count is a predicate-specific denominator for every subtype.',
        'fractional_scores':'Retain for optional descriptive disagreement diagnostics; primary Bernoulli oracle uses the fixed threshold only. No post-hoc threshold sweep or high-confidence subset.'
      },
      'query_design':{
        'per_predicate':{'pairwise':56,'equivalence':28,'summary':32,'ranking':16},
        'summary_subtypes':{'dominance_3':16,'mixed_3':16},
        'pairwise':'All 56 directed pairs among eight groups, threshold 0.',
        'equivalence':'All 28 unordered pairs, strict absolute rate difference <0.05.',
        'summary_dominance':'16 SHA256-selected candidates among all eight pivots and all three-element subsets of the other seven groups; require all three pivot>other judgments.',
        'summary_mixed':'16 SHA256-selected permutations of six distinct groups; require g1>g2 and |g3-g4|<0.05 and |g5-g6|<0.05. All three judgments are predeclared and must settle.',
        'ranking':'16 SHA256-selected (four-group subset, k in {1,2}) contracts among all 140 possibilities; strict top-k; secondary family.',
        'hash_salts':{'dominance':'civilcomments-query-dominance-v1','mixed':'civilcomments-query-mixed-v1','ranking':'civilcomments-query-ranking-v1'},
        'total_queries':528,
        'primary_family':'Non-ranking requests (pairwise, equivalence and summaries), 464 queries; 64 rankings are secondary.',
        'declaration':'Every contract is generated before metadata row selection and before target annotation access. No certifiability, margin, significant-effect or overlap-based query selection.'
      },
      'alpha':0.05,
      'budget_shares':[10,25,50,100],
      'primary_budget_share':50,
      'primary_arms':['certificate_b1','matched_b1'],
      'secondary_arms':['certificate_b4','matched_b4'],
      'ranking_secondary_controls':['boundary_b1','betting_b1'],
      'configuration':'Use the audited new implementation, retain coefficient signatures, pilot-fitted proxy and mixture weight 0.5. Freeze implementation hashes and all effective runtime fields before any replay. C/M within each bin count share charged pilot, partition, prior and formal permutations.',
      'features':'Text-only TF-IDF unigram/bigram max_features=10000 min_df=2 sublinear_tf=True, SVD 128 n_iter=5 random_state=431, L2 normalized float32. Fit without target labels on the frozen text snapshot. Predicate-specific logistic proxy may use only the charged pilot. No identity/target annotation as a predictive feature.',
      'seed_pairs':[{'seed_id':i,'pilot_seed':str(secrets.randbits(256)),'formal_seed':str(secrets.randbits(256))} for i in range(10)],
      'model_followup':{
        'status':'Not launched; optional secondary oracle, cannot replace the crowd-reference primary experiment.',
        'name':'Qwen/Qwen3-8B',
        'revision':'b968826d9c46dd6066d109eabc6255188de91218',
        'precision':'bfloat16','attention':'sdpa','enable_thinking':False,'batch_chunks':1,
        'scoring':'Compare 0 and 1 next-token scores; positive on exact tie; full comment only, no parent context; 4096-token context; input-overflow/error remains an error, no selective truncation or replacement.',
        'prompts':{
          'toxicity':'Decide whether the following comment contains toxic language: disrespectful, abusive, or unreasonable wording likely to drive someone out of a discussion. Return 1 if yes and 0 if no. Judge the words in the comment, independently of any identity it mentions. Return only 1 or 0.\n\nComment:\n{text}\n\nLabel:',
          'insult':'Decide whether the following comment contains an insult or a personal attack on a person or group. Return 1 if yes and 0 if no. Judge the words in the comment, independently of any identity it mentions. Return only 1 or 0.\n\nComment:\n{text}\n\nLabel:',
          'identity_attack':'Decide whether the following comment attacks, demeans, or expresses hatred toward a person or group because of identity, such as religion, ethnicity, gender or sexual orientation. Mere mention or neutral discussion of an identity is not an attack. Return 1 if yes and 0 if no. Return only 1 or 0.\n\nComment:\n{text}\n\nLabel:',
          'obscene':'Decide whether the following comment contains obscene, profane, or vulgar language. Return 1 if yes and 0 if no. Judge the words in the comment, independently of any identity it mentions. Return only 1 or 0.\n\nComment:\n{text}\n\nLabel:'
        },
        'interpretation':'Measure agreement and decision disagreement with existing crowd references per predicate/cohort. No human-truth, new-annotation, pretraining-independence or live-speedup claim.'
      },
      'primary_estimands':[
        'At 50% support cap: C1-minus-M1 correctly completed request fraction across ALL 464 non-ranking queries x 10 paired seeds; average first within predicate and query family, then equally across 4 predicates and 3 non-ranking families.',
        'At the same cap: relative reduction in mean charged calls/support across all non-ranking units, including unresolved, reference-uncertifiable and error outcomes.',
        'Report per-family, per-predicate and micro-averaged counts/costs as fixed breakdowns. No independent-query or independent-seed significance claim.'
      ],
      'secondary_estimands':['All-unit and reference-certifiable complete coverage curves at the four fixed caps','Conditional paired costs with paired-unit and distinct-query denominators','Natural intersection sizes, size ratios, cancellation counts and unique-read reuse','False certificates, terminal and anytime source noncoverage, numerical inconsistency, source/model disagreement and all execution errors','One/four bin partition intervention and secondary ranking controls; no claim that adapted controls are full external systems'],
      'audit_requirements':['Save every charged read ID, cell, source row ID, pilot/formal seed, order fingerprint, selected/effective cap, prior/partition hash, terminal bounds and every inconsistency state','A separate exact-rational evaluator derives source cohort rates, satisfiable certificate sets and every claimed conclusion without importing the acquisition engine','Retain reference-uncertifiable, exact-boundary, failed and unresolved requests; no retries with changed labels/seeds; source coverage failures remain distinct from model disagreement','Report dependence from shared records/queries/seeds; any bootstrap intervals are descriptive query-cluster summaries'],
      'run_counts':{'primary_2_arms_all_caps':42240,'with_4_partition_arms_all_caps':84480,'ranking_controls_2_arms_all_caps_additional':5120,'with_all_secondary_controls':89600},
      'stopping_scope':'Current preparation stops after source evidence, protocol and metadata-only projection. Do not parse the four target-score fields or launch model labeling/acquisition replays in this task.'
    }
    templates=[]
    def add(kind,names,decisions,subtype=None):
        templates.append({'kind':kind,'names':names,'decisions':decisions,**({'summary_subtype':subtype} if subtype else {})})
    def comp(l,r):return {'type':'compare','left':l,'right':r,'threshold':0,'unit':'proportion_difference'}
    def equiv(l,r):return {'type':'equivalence','left':l,'right':r,'tolerance':0.05,'unit':'proportion_difference'}
    for a in GROUPS:
        for b in GROUPS:
            if a!=b:add('pairwise',[a,b],[comp('g1','g2')])
    for a,b in combinations(GROUPS,2):add('equivalence',[a,b],[equiv('g1','g2')])
    dom=[[p,*xs] for p in GROUPS for xs in combinations([g for g in GROUPS if g!=p],3)]
    for names in choose(dom,16,design['query_design']['hash_salts']['dominance']):
        add('summary',names,[comp('g1','g2'),comp('g1','g3'),comp('g1','g4')],'dominance_3')
    for names in choose([list(x) for x in permutations(GROUPS,6)],16,design['query_design']['hash_salts']['mixed']):
        add('summary',names,[comp('g1','g2'),equiv('g3','g4'),equiv('g5','g6')],'mixed_3')
    ranks=[{'groups':list(gs),'k':k} for gs in combinations(GROUPS,4) for k in [1,2]]
    for item in choose(ranks,16,design['query_design']['hash_salts']['ranking']):
        k=item['k'];add('ranking',item['groups'],[{'type':'top1' if k==1 else 'topk','candidates':['g1','g2','g3','g4'],**({'k':2} if k==2 else {})}])
    queries=[]
    for pred in PREDICATES:
        for t in templates:
            queries.append({
             'dataset':'civilcomments_wilds','predicate_id':f'civilcomments_{pred}_v1','split':'test',
             'query_id':f'civilcomments-{pred}-{len(queries):04d}','kind':t['kind'],
             **({'summary_subtype':t['summary_subtype']} if 'summary_subtype' in t else {}),
             'contract':{
               'snapshot_id':design['population']['snapshot_id'],'predicate_id':f'civilcomments_{pred}_v1',
               'population_scope':design['population']['unit'],
               'risk':{'alpha':0.05,'scope':'this_request'},
               'budget':{'max_oracle_record_predicate_calls':512},
               'cohorts':[{'id':f'g{i+1}','filter_ast':{'eq':[f'mentions_{g}',True]},'label':f'Comment mentions {g}'} for i,g in enumerate(t['names'])],
               'decisions':t['decisions']}})
    assert len(templates)==132 and len(queries)==528
    assert Counter(q['kind'] for q in queries)=={'pairwise':224,'equivalence':112,'summary':128,'ranking':64}
    qpath=ROOT/'queries_before_annotation_access.jsonl'
    assert not qpath.exists()
    qpath.write_text(''.join(canonical(q)+'\n' for q in queries),encoding='utf-8')
    design['queries_sha256']=hashlib.sha256(qpath.read_bytes()).hexdigest()
    design['freeze_script_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    path.write_text(json.dumps(design,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    receipt={'protocol_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'queries_sha256':design['queries_sha256'],'query_counts':dict(Counter(q['kind'] for q in queries)),'target_annotation_fields_read':False,'model_or_replay_launched':False}
    (ROOT/'freeze_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))
if __name__=='__main__':main()

