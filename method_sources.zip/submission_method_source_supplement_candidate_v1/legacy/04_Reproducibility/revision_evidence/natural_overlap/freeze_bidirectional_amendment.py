#!/usr/bin/env python3
"""Add a target-blind prospective completion-semantics amendment; preserve v1."""
from pathlib import Path
import json, hashlib, datetime
ROOT=Path(__file__).resolve().parent
p=ROOT/'protocol_before_annotation_access.json'
q=ROOT/'queries_before_annotation_access.jsonl'
out=ROOT/'protocol_bidirectional_before_annotation_access.json'
assert not out.exists()
base=json.loads(p.read_text())
assert hashlib.sha256(q.read_bytes()).hexdigest()==base['queries_sha256']
amendment={
 'amendment_id':'civilcomments-bidirectional-per-decision-v2-before-target-access',
 'frozen_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'base_protocol_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
 'base_queries_sha256':base['queries_sha256'],
 'source_and_query_selection':'Exactly the preserved v1 protocol; no source target value, model output or acquisition result has been inspected.',
 'primary_semantics':{
  'scope':'All 464 non-ranking queries; every predeclared comparison/equivalence judgment is answered true, false, or unresolved.',
  'bundle_completion':'A summary completes when every one of its three judgments is resolved. Preserve and evaluate the whole three-bit answer vector, including mixed true/false outcomes. No requirement that all three judgments be true.',
  'compare':'For theta>b: true only if L>b; false only if U<=b. The source truth is theta>b, including false when theta=b.',
  'equivalence':'For |theta|<epsilon: true only if L>-epsilon and U<epsilon; false if U<=-epsilon or L>=epsilon. Exact boundary values are false. No replacement of strict true semantics.',
  'risk':'The same simultaneous time-uniform contrast confidence event covers both polarities. All arms share exactly the same checker and interval kernel; implement before target-value access/replay.',
  'ranking_scope':'The 64 secondary ranking requests retain strict exact-top-k identification, with unresolved for non-identifiable strict ties. They are reported separately and do not enter the primary binary-decision completion denominator.',
  'cost_scope':'All charged reads, pilot and errors remain in all-unit costs. Failed/unresolved/non-full completions are not discarded.'
 },
 'comparators':'Certificate, matched and any boundary/betting control must use the same bidirectional checker on non-ranking requests; do not compare a bidirectional method with a one-sided comparator.',
 'historical_semantics_control':'Also retain the old all-positive-witness completion mode as a separately named historical-semantics sensitivity grid on the SAME contracts, seeds, cohorts, caps and oracle. Never pool its outcomes or denominator with the bidirectional primary grid.',
 'primary_denominators':{
  'nonranking_query_count':464,'seed_pairs':10,'units_per_arm_per_cap':4640,
  'pairwise_queries':224,'equivalence_queries':112,'summary_queries':128,
  'reference_certifiable_filter':'None for primary bidirectional metrics. All source judgments have an exact Boolean truth; errors/unresolved remain in the denominator.',
  'primary_aggregation':'Equal weight across the four fixed predicates and three fixed non-ranking families after averaging query-seed units within each cell; also report exact micro-averaged counts.'
 },
 'required_new_outputs':['Per-decision answer vector and confidence witness polarity','Correct complete query fraction at all four caps','Partial number/fraction of resolved judgments as secondary, never counted as whole-query completion','False true-claims and false false-claims separately, plus mixed-vector error','Full source-side truth vector computed by an independent rational evaluator after protocol approval'],
 'freeze_and_execution_gate':'Root must approve this frozen protocol before the four target-score columns are interpreted. Metadata-only feasibility projection may proceed; model labeling and full acquisition experiments remain unlaunched in this task.',
 'no_posthoc_selection':'Do not drop queries whose all-positive witness was false, choose favorable polarities from reference labels, change thresholds/epsilon, choose another sample/seed, or select a subset after seeing results.'
}
out.write_text(json.dumps(base|{'bidirectional_amendment':amendment},indent=2,ensure_ascii=False)+'\n')
receipt={'amended_protocol_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'base_protocol_sha256':amendment['base_protocol_sha256'],'queries_sha256':base['queries_sha256'],'target_annotations_interpreted':False,'root_approval_pending':True}
(ROOT/'bidirectional_freeze_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))

