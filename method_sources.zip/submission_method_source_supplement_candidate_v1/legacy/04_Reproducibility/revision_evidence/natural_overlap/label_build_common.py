"""Portable integrity, snapshot and explicit execution gates for label builders."""
from pathlib import Path
import hashlib,json,os,datetime

PREDICATES=('toxicity','insult','identity_attack','obscene')
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()
def require(value,message):
    if not value:raise ValueError(message)
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def atomic_json(path,value):
    path=Path(path);temporary=path.with_name(path.name+'.tmp')
    with temporary.open('w',encoding='utf-8') as f:
        json.dump(value,f,indent=2,ensure_ascii=False,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
    temporary.replace(path)
def load_plan(workspace):
    ws=Path(workspace).resolve();path=ws/'label_build_plan_with_scenario_seeds_before_annotation_access.json'
    plan=json.loads(path.read_text())
    require(tuple(plan['predicate_order'])==PREDICATES,'Unexpected frozen predicate order.')
    require(plan['reference_threshold']=={'operator':'>=','decimal':'0.5','ties':'positive','missing_or_invalid':'fail, preserve evidence; never drop or replace rows'},'Reference threshold changed.')
    require(sha(ws/plan['protocol_file'])==plan['protocol_sha256'],'Protocol hash changed.')
    require(sha(ws/plan['snapshot_file'])==plan['snapshot_sha256'],'Text snapshot hash changed.')
    require(sha(ws/plan['selected_source_rows_file'])==plan['selected_source_rows_sha256'],'Selected row IDs changed.')
    require(sha(ws/plan['model']['expected_file_manifest'])==plan['model']['expected_file_manifest_sha256'],'Expected model manifest changed.')
    return ws,plan,sha(path)
def load_snapshot(ws,plan):
    import pyarrow.parquet as pq
    rows=pq.read_table(ws/plan['snapshot_file'],columns=['record_id','text','source_row_ordinal','original_comment_id']).to_pylist()
    require(len(rows)==plan['expected_rows']==30000,'Expected the complete frozen30,000-row snapshot.')
    require(len({r['record_id'] for r in rows})==len(rows),'Duplicate row IDs.')
    require(all(type(r['source_row_ordinal']) is int and isinstance(r['text'],str) and r['text'].strip() for r in rows),'Invalid frozen row metadata.')
    require([r['source_row_ordinal'] for r in rows]==sorted(r['source_row_ordinal'] for r in rows),'Snapshot source-row ordering changed.')
    selected=[json.loads(s) for s in (ws/plan['selected_source_rows_file']).read_text().splitlines()]
    require(len(selected)==len(rows),'Selected row count changed.')
    for row,expected in zip(rows,selected):
        require(all(row[k]==expected[k] for k in ['record_id','source_row_ordinal','original_comment_id']),'Selected row mapping changed.')
    return rows
def verify_code_freeze(ws,plan_sha):
    path=ws/'label_build_code_freeze.json';freeze=json.loads(path.read_text())
    require(freeze['operator_plan_sha256']==plan_sha,'Code freeze refers to another plan.')
    code_root=Path(__file__).resolve().parent
    required={'label_build_common.py','convert_source_annotations.py','build_qwen_labels.py'}
    require(set(freeze['scripts'])==required,'Incomplete builder code freeze.')
    for name,expected in freeze['scripts'].items():
        require(sha(code_root/name)==expected,'Builder changed after freeze: '+name)
    return sha(path)
def verify_gate(path,ws,plan,plan_sha,action,token):
    require(token==plan_sha,'Explicit unseal/authorize token must equal the frozen operator-plan SHA256.')
    require(path is not None,'Root-requested policy-freeze gate is required for this action.')
    gate_path=Path(path).resolve();gate=json.loads(gate_path.read_text())
    require(gate.get('schema')=='cohortcert-execution-gate-v1','Unsupported execution gate schema.')
    require(gate.get('policy_frozen') is True,'Theory/online policy is not marked frozen.')
    require(gate.get(action) is True,'Root gate does not authorize '+action+'.')
    require(gate.get('operator_plan_sha256')==plan_sha,'Execution gate refers to another operator plan.')
    require(gate.get('protocol_sha256')==plan['protocol_sha256'],'Execution gate refers to another protocol.')
    require(gate.get('label_build_code_freeze_sha256')==verify_code_freeze(ws,plan_sha),'Execution gate does not bind the builder code freeze.')
    artifacts=gate.get('frozen_policy_artifacts',[])
    require(isinstance(artifacts,list) and artifacts,'Execution gate must bind at least one frozen theory/online-policy artifact.')
    for item in artifacts:
        artifact=Path(item['path'])
        if not artifact.is_absolute():artifact=gate_path.parent/artifact
        require(artifact.is_file() and sha(artifact)==item['sha256'],'A frozen policy artifact changed or is unavailable.')
    return {'gate_sha256':sha(gate_path),'gate_file':str(gate_path),'approved_action':action,'policy_artifact_count':len(artifacts)}
def ensure_out(path,resume=False):
    out=Path(path).resolve()
    require(not out.exists() or (resume and out.is_dir()),'Output directory exists; choose a fresh directory or explicitly resume a model build.')
    out.mkdir(parents=True,exist_ok=resume)
    return out

