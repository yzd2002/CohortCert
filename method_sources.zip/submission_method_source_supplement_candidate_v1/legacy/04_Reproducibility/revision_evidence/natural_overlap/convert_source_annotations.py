#!/usr/bin/env python3
"""Explicitly gated, hash-pinned conversion of existing crowd-reference scores.

Default dry-run never opens or downloads a source CSV. Conversion preserves the
complete original CSV, fixes all selected rows, maps four decimal scores >=0.5,
and produces no prevalence, accuracy or query-selection statistics.
"""
from pathlib import Path
from decimal import Decimal,InvalidOperation
import argparse,csv,hashlib,json,os,sys,time
from label_build_common import PREDICATES,sha,require,utc,atomic_json,load_plan,load_snapshot,verify_code_freeze,verify_gate,ensure_out

def source_csv(path,plan,download):
    path=Path(path).resolve()
    if not path.exists():
        require(download,'Source CSV is missing; pass --download only after explicit unsealing.')
        import requests
        path.parent.mkdir(parents=True,exist_ok=True)
        temporary=path.with_name(path.name+'.download-part')
        require(not temporary.exists(),'Partial source download exists; preserve it and choose a fresh destination.')
        h=hashlib.sha256();size=0
        with requests.get(plan['source_csv_url'],stream=True,timeout=(30,120)) as response:
            response.raise_for_status()
            with temporary.open('xb') as f:
                for block in response.iter_content(1024*1024):
                    if block:f.write(block);h.update(block);size+=len(block)
                f.flush();os.fsync(f.fileno())
        require(size==plan['source_csv_bytes'] and h.hexdigest()==plan['source_csv_sha256'],'Downloaded source bytes/hash mismatch; partial original preserved.')
        require(not path.exists(),'Destination appeared during download; preserving partial.')
        temporary.replace(path)
    require(path.is_file() and path.stat().st_size==plan['source_csv_bytes'],'Source CSV byte count mismatch.')
    require(sha(path)==plan['source_csv_sha256'],'Source CSV SHA256 mismatch; never convert another release.')
    return path

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--workspace',type=Path,required=True)
    ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--mode',choices=['dry-run','convert'],default='dry-run')
    ap.add_argument('--source-csv',type=Path)
    ap.add_argument('--download',action='store_true')
    ap.add_argument('--gate-file',type=Path)
    ap.add_argument('--unseal-source-annotations',metavar='OPERATOR_PLAN_SHA256')
    args=ap.parse_args()
    ws,plan,plan_sha=load_plan(args.workspace);freeze_sha=verify_code_freeze(ws,plan_sha)
    rows=load_snapshot(ws,plan)
    if args.mode=='dry-run':
        require(not args.download and args.unseal_source_annotations is None,'Dry-run cannot download or unseal source labels.')
        out=ensure_out(args.out)
        result={'status':'dry_run_only','created_utc':utc(),'expected_rows':len(rows),'predicates':list(PREDICATES),'operator_plan_sha256':plan_sha,'protocol_sha256':plan['protocol_sha256'],'builder_code_freeze_sha256':freeze_sha,'source_csv_opened_or_downloaded':False,'target_score_values_interpreted':False,'reference_mapping':'Decimal(score)>=Decimal(0.5), including ties','script_sha256':sha(__file__)}
        atomic_json(out/'source_conversion_dry_run.json',result);print(json.dumps(result,indent=2));return
    require(args.source_csv is not None,'--source-csv is required for conversion, including a new download destination.')
    gate=verify_gate(args.gate_file,ws,plan,plan_sha,'allow_source_annotation_conversion',args.unseal_source_annotations)
    out=ensure_out(args.out);start=time.perf_counter()
    binding={'created_utc':utc(),'operator_plan_sha256':plan_sha,'protocol_sha256':plan['protocol_sha256'],'code_freeze_sha256':freeze_sha,'snapshot_sha256':plan['snapshot_sha256'],'selected_source_rows_sha256':plan['selected_source_rows_sha256'],'source_csv_expected_sha256':plan['source_csv_sha256'],**gate}
    atomic_json(out/'conversion_binding.json',binding)
    labels={p:{} for p in PREDICATES};selected={r['source_row_ordinal']:r for r in rows};matched=set()
    try:
        source=source_csv(args.source_csv,plan,args.download)
        # No annotation score is interpreted until the COMPLETE original file's
        # byte count and SHA256 have been checked above.
        raw_scores=out/'selected_raw_annotation_scores.jsonl'
        source_rows=0
        with source.open(newline='',encoding='utf-8-sig') as f,raw_scores.open('x',encoding='utf-8') as audit:
            reader=csv.DictReader(f);require(all(p in reader.fieldnames for p in PREDICATES),'Source annotation columns missing.')
            for ordinal,row in enumerate(reader):
                source_rows+=1
                if ordinal not in selected:continue
                frozen=selected[ordinal]
                require(row['id']==frozen['original_comment_id'] and row['comment_text']==frozen['text'],'Source row differs from frozen ID/text.')
                record_id=frozen['record_id'];require(record_id not in matched,'Duplicate selected source row.')
                decimal_scores={}
                for pred in PREDICATES:
                    score=row[pred]
                    try:value=Decimal(score)
                    except (InvalidOperation,TypeError):raise ValueError(f'Invalid score at source row {ordinal}, predicate {pred}.')
                    require(value.is_finite() and Decimal(0)<=value<=Decimal(1),f'Out-of-range/missing score at source row {ordinal}, predicate {pred}.')
                    labels[pred][record_id]=int(value>=Decimal('0.5'));decimal_scores[pred]=score
                matched.add(record_id)
                audit.write(json.dumps({'record_id':record_id,'source_row_ordinal':ordinal,'original_comment_id':frozen['original_comment_id'],'scores_decimal_as_published':decimal_scores},ensure_ascii=False,separators=(',',':'))+'\n')
                if len(matched)%128==0:
                    audit.flush();os.fsync(audit.fileno())
                    atomic_json(out/'conversion_progress.json',{'status':'converting','selected_rows_converted':len(matched),'expected_rows':len(rows),'source_rows_traversed':source_rows,'source_csv_sha256':plan['source_csv_sha256'],'operator_plan_sha256':plan_sha})
            audit.flush();os.fsync(audit.fileno())
        require(source_rows==plan['source_csv_row_count'],'Source row count mismatch.')
        require(matched=={r['record_id'] for r in rows},'Selected annotation coverage is incomplete.')
        outputs={}
        for pred in PREDICATES:
            require(len(labels[pred])==plan['expected_rows'] and all(type(v) is int and v in [0,1] for v in labels[pred].values()),'Nonbinary/incomplete output map.')
            path=out/f'human_labels_{pred}_v1.json';atomic_json(path,labels[pred]);outputs[pred]={'file':path.name,'sha256':sha(path),'rows':len(labels[pred])}
        result={'status':'complete','completed_utc':utc(),'rows_per_predicate':len(rows),'source_csv_file':str(source),'source_csv_sha256':plan['source_csv_sha256'],'source_csv_bytes':source.stat().st_size,'source_original_preserved':True,'operator_plan_sha256':plan_sha,'protocol_sha256':plan['protocol_sha256'],'snapshot_sha256':plan['snapshot_sha256'],'code_freeze_sha256':freeze_sha,'target_score_values_interpreted':True,'reference_threshold':'>=0.5; ties positive','label_maps':outputs,'raw_selected_score_audit_sha256':sha(raw_scores),'wall_seconds':time.perf_counter()-start,'statistics_scope':'No prevalence, human/model accuracy, query certifiability, cohort outcome or selection statistics computed. Existing crowd reference, not new human annotation.',**gate}
        atomic_json(out/'conversion_completion.json',result);atomic_json(out/'conversion_progress.json',result)
        print(json.dumps({'status':'complete','rows_per_predicate':len(rows),'predicate_maps':list(outputs),'operator_plan_sha256':plan_sha},indent=2))
    except BaseException as error:
        atomic_json(out/'conversion_failure.json',{'status':'failed','time_utc':utc(),'error_type':type(error).__name__,'message':str(error),'selected_rows_converted':len(matched),'expected_rows':len(rows),'operator_plan_sha256':plan_sha,'source_csv_expected_sha256':plan['source_csv_sha256'],'partial_outputs_preserved':True})
        raise

if __name__=='__main__':main()

