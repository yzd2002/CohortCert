#!/usr/bin/env python3
"""Read source bytes once and retain only metadata/text, never target scores."""
from pathlib import Path
from collections import Counter
from itertools import combinations
from decimal import Decimal
import csv, io, requests, json, hashlib, heapq, time, datetime, math
ROOT=Path(__file__).resolve().parent

class HashedRaw(io.RawIOBase):
    def __init__(self,raw):
        self.raw=raw; self.sha=hashlib.sha256(); self.size=0
    def readable(self):return True
    def readinto(self,b):
        data=self.raw.read(len(b),decode_content=True)
        if not data:return 0
        self.sha.update(data);self.size+=len(data);b[:len(data)]=data
        return len(data)

def main():
    protocol_path=ROOT/'protocol_bidirectional_before_annotation_access.json'
    protocol=json.loads(protocol_path.read_text())
    assert not (ROOT/'metadata_preparation_receipt.json').exists(), 'Do not overwrite frozen metadata.'
    assert hashlib.sha256((ROOT/'queries_before_annotation_access.jsonl').read_bytes()).hexdigest()==protocol['queries_sha256']
    groups=protocol['cohorts'];k=protocol['population']['size'];salt=protocol['population']['snapshot_salt']
    start=time.perf_counter(); heap=[]; split_counts=Counter();eligible_counts=Counter()
    raw_size=None;raw_sha=None; first_header=None; rows=0; source_headers=None
    url=protocol['source']['csv_url']
    with requests.get(url,timeout=(30,120),stream=True) as response:
        response.raise_for_status();source_headers=dict(response.headers)
        raw=HashedRaw(response.raw)
        with io.TextIOWrapper(io.BufferedReader(raw,buffer_size=1024*1024),encoding='utf-8-sig',newline='') as stream:
            reader=csv.DictReader(stream);first_header=reader.fieldnames
            required=['id','comment_text','split',*groups,'identity_annotator_count','toxicity_annotator_count']
            assert all(x in first_header for x in required)
            for ordinal,row in enumerate(reader):
                rows+=1
                split=row['split'];split_counts[split]+=1
                if split!=protocol['population']['source_split']:continue
                text=row['comment_text']
                if not text.strip():continue
                mentions={g:Decimal(row[g])>=Decimal('0.5') for g in groups}
                if not any(mentions.values()):continue
                eligible_counts[split]+=1
                original_id=row['id']
                rank=hashlib.sha256((salt+'\0'+str(ordinal)+'\0'+original_id).encode()).digest()
                key=(-int.from_bytes(rank,'big'),-ordinal)
                if len(heap)>=k and key<=heap[0][:2]:continue
                metadata={'record_id':f'civilcomments-wilds-v1-row-{ordinal:06d}','source_row_ordinal':ordinal,'original_comment_id':original_id,'text':text,'source_split':split,
                  'created_date':row['created_date'],'publication_id':row['publication_id'],'article_id':row['article_id'],
                  'identity_annotator_count':row['identity_annotator_count'],'toxicity_annotator_count':row['toxicity_annotator_count'],
                  **{f'mentions_{g}':v for g,v in mentions.items()}}
                item=(*key,metadata)
                if len(heap)<k:heapq.heappush(heap,item)
                else:heapq.heapreplace(heap,item)
            raw_size=raw.size;raw_sha=raw.sha.hexdigest()
    assert raw_size==protocol['source']['csv_expected_bytes'],(raw_size,protocol['source']['csv_expected_bytes'])
    assert len(heap)==k, 'Fewer than 30000 eligible comments: report infeasible; never replace source/seed.'
    metadata=sorted([x[2] for x in heap],key=lambda x:x['source_row_ordinal'])
    n={g:sum(r[f'mentions_{g}'] for r in metadata) for g in groups}
    intersections={f'{a}|{b}':sum(r[f'mentions_{a}'] and r[f'mentions_{b}'] for r in metadata) for a,b in combinations(groups,2)}
    multiplicity=Counter(sum(r[f'mentions_{g}'] for g in groups) for r in metadata)
    feasible=sum(v>=500 for v in n.values())>=6 and sum(v>0 for v in intersections.values())>=6 and sum(v for m,v in multiplicity.items() if m>=2)>=.05*k and all(n.values())
    import pyarrow as pa,pyarrow.parquet as pq
    pq.write_table(pa.Table.from_pylist(metadata),ROOT/'text_metadata_snapshot.parquet')
    pq.write_table(pa.Table.from_pylist([{**r,'text':''} for r in metadata]),ROOT/'metadata_only_snapshot.parquet')
    ids=[r['record_id'] for r in metadata]
    (ROOT/'selected_source_rows.jsonl').write_text(''.join(json.dumps({'record_id':r['record_id'],'source_row_ordinal':r['source_row_ordinal'],'original_comment_id':r['original_comment_id']},separators=(',',':'))+'\n' for r in metadata))
    def qsummary(field):
        vals=sorted(Decimal(r[field]) for r in metadata)
        return {'min':str(vals[0]),'q25':str(vals[len(vals)//4]),'median':str(vals[len(vals)//2]),'q75':str(vals[3*len(vals)//4]),'max':str(vals[-1]),'at_least_2':sum(v>=2 for v in vals)}
    receipt={
      'prepared_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
      'protocol_sha256':hashlib.sha256(protocol_path.read_bytes()).hexdigest(),
      'source_url':url,'source_csv_sha256':raw_sha,'source_csv_bytes':raw_size,'source_response_headers':source_headers,'source_header':first_header,
      'source_row_count':rows,'source_split_counts':dict(split_counts),'eligible_source_counts':dict(eligible_counts),
      'selected_rows':len(metadata),'cohort_sizes':n,'pairwise_intersection_sizes':intersections,
      'membership_multiplicity_counts':dict(sorted(multiplicity.items())),
      'multiple_mention_rows':sum(v for m,v in multiplicity.items() if m>=2),
      'duplicate_text_rows':len(metadata)-len({r['text'] for r in metadata}),
      'duplicate_original_id_rows':len(metadata)-len({r['original_comment_id'] for r in metadata}),
      'identity_annotator_count_summary':qsummary('identity_annotator_count'),
      'toxicity_annotator_count_summary':qsummary('toxicity_annotator_count'),
      'annotator_count_warning':'Counts are metadata, not target scores. The toxicity count does not establish a separate denominator for each subtype.',
      'metadata_feasibility_pass':bool(feasible),
      'download_and_projection_wall_s':time.perf_counter()-start,
      'target_score_values_converted_or_accessed':False,
      'target_columns_note':'The CSV parser lexically traverses source rows. No target score column is accessed, converted, used in selection or saved in either projected snapshot.',
      'model_or_acquisition_replay_launched':False,
      'snapshot_sha256':hashlib.sha256((ROOT/'text_metadata_snapshot.parquet').read_bytes()).hexdigest(),
      'metadata_only_snapshot_sha256':hashlib.sha256((ROOT/'metadata_only_snapshot.parquet').read_bytes()).hexdigest(),
      'selected_source_rows_sha256':hashlib.sha256((ROOT/'selected_source_rows.jsonl').read_bytes()).hexdigest(),
      'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    }
    (ROOT/'metadata_preparation_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({key:receipt[key] for key in ['source_csv_sha256','source_csv_bytes','source_row_count','source_split_counts','eligible_source_counts','selected_rows','cohort_sizes','membership_multiplicity_counts','multiple_mention_rows','metadata_feasibility_pass','download_and_projection_wall_s','target_score_values_converted_or_accessed']},indent=2))
    assert feasible,'Metadata-only feasibility rule failed; preserve this result and do not adapt.'
if __name__=='__main__':main()

