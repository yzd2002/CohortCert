#!/usr/bin/env python3
"""Independent synthetic API/math/accounting audit; no corpus/GPU access."""
from pathlib import Path
from types import SimpleNamespace
from fractions import Fraction
from dataclasses import asdict
import hashlib,json,math,random,sys,time
HERE=Path(__file__).resolve().parent
SNAPSHOT=HERE/'frozen_executor_snapshot'
CORE=Path('/dev/shm/CohortCert_fixed_label_replay_20261031')
sys.path.insert(0,str(SNAPSHOT))
from executor_v2.execution import Plan,execute,IntegerPushforward
from executor_v2.state import Choice
from common import core_module
MemorySnapshot=core_module(CORE,'query.snapshot').MemorySnapshot
compiler=core_module(CORE,'query.compiler')
rng=random.Random(2026110201)

class Replay:
    def __init__(self,labels):self.labels=labels;self.requests=[]
    def read(self,ids):
        self.requests.append(list(ids));return {i:self.labels[i] for i in ids}
class Least:
    def __init__(self):self.states=[]
    def choose(self,state):
        self.states.append(state)
        cell=min((c for c in state.cells if c.n<c.N),key=lambda c:(c.n,c.cell_id))
        return Choice(cell.cell_id,state.batch_size)
class SpyProxy:
    def __init__(self,log):self.log=log
    def clone_unfitted(self):self.log.append(('clone',));return SpyProxy(self.log)
    def fit(self,ids,ys):self.log.append(('fit',list(ids),list(ys)))
    def score(self,rid):
        self.log.append(('score',rid));return (int(rid[1:])%11+.5)/12

def request(ids,decisions=None,cohorts=None,cap=None):
    if cohorts is None:
        n=len(ids);cohorts=[{'id':'a','record_ids':ids[:3*n//5]},{'id':'b','record_ids':ids[n//4:]},{'id':'c','record_ids':ids[::2]}]
    if decisions is None:
        decisions=[{'type':'compare','left':'a','right':'b','threshold':0,'unit':'proportion_difference'},
                   {'type':'equivalence','left':'a','right':'c','tolerance':.15,'unit':'proportion_difference'},
                   {'type':'compare','left':'b','right':'c','threshold':.05,'unit':'proportion_difference'}]
    return {'snapshot_id':'independent_synthetic_v1','predicate_id':'synthetic_predicate_v1','population_scope':'Synthetic fixed rows only','cohorts':cohorts,'decisions':decisions,'risk':{'alpha':.05,'scope':'this_request'},'budget':{'max_oracle_record_predicate_calls':cap or len(ids)}}
def truth_vector(q,labels):
    means={g['id']:sum(Fraction(labels[i],len(g['record_ids'])) for i in g['record_ids']) for g in q['cohorts']}
    out=[]
    for d in q['decisions']:
        theta=means[d['left']]-means[d['right']]
        out.append(theta>Fraction(str(d['threshold'])) if d['type']=='compare' else abs(theta)<Fraction(str(d['tolerance'])))
    return out
def basic_assertions(result,oracle,cap):
    c=result['certificate'];submitted=[i for rs in oracle.requests for i in rs]
    assert c['semantic_calls']==len(submitted)<=cap
    assert len(submitted)==len(set(submitted))
    assert c['unique_successful_returns']==len(result['observed_labels'])
    assert c['declared_judgments']==len(c['family']['decision_types'])
    assert not c['framework_exception']
    for a in result['actions']:
        assert a['prefix_after']-a['prefix_before']==len(a['record_ids'])==len(a['labels'])
    return c

def main():
    start=time.perf_counter();report={'source_annotations_accessed':False,'gpu_forwards':0,'reviewed_snapshot':str(SNAPSHOT)}
    # Exact propagation is compared with a separate Fraction implementation.
    propagated=0
    for trial in range(2000):
        J=rng.randint(1,8);H=rng.randint(0,12)
        cells=[];counts={}
        for h in range(H):
            sig=tuple(Fraction(rng.randint(-9,9),rng.randint(1,37)) for _ in range(J))
            lo=rng.randint(0,30);hi=rng.randint(lo,40)
            cells.append(SimpleNamespace(cell_id=h,signature=sig));counts[h]=SimpleNamespace(bounds=(lo,hi))
        pilot={j:Fraction(rng.randint(-17,17),rng.randint(1,53)) for j in range(J)}
        family=SimpleNamespace(atoms=[SimpleNamespace(index=i,row_index=i) for i in range(J)])
        actual=IntegerPushforward(cells,pilot,family).bounds(cells,counts)
        for j in range(J):
            lo=hi=pilot[j]
            for c in cells:
                a=c.signature[j];lower,upper=counts[c.cell_id].bounds
                lo+=a*(lower if a>=0 else upper);hi+=a*(upper if a>=0 else lower)
            assert actual[j]==(lo,hi);propagated+=1
    report['exact_integer_vs_Fraction_rows']=propagated
    # Conservative down-rounding, including subnormal underflow to zero.
    risk_cases=0
    for alpha in [.05,.01,.1,.9999999999999999,1e-10,1e-100,5e-324]:
        for H in range(1,1025):
            exact=Fraction(str(alpha))/H;value=float(exact)
            if Fraction.from_float(value)>exact:value=math.nextafter(value,0.0)
            assert Fraction.from_float(value)<=exact
            assert H*Fraction.from_float(value)<=Fraction(str(alpha));risk_cases+=1
    report['exact_risk_downround_cases']=risk_cases
    # General overlapping finite execution, partial/full budgets and tiny scan.
    executions=covered_claims=noncoverage=execution_errors=0
    for trial in range(180):
        N=rng.randint(15,64);ids=[f'r{i:03d}' for i in range(N)]
        snapshot=MemorySnapshot({i:{'text':''} for i in ids})
        labels={i:rng.randint(0,1) for i in ids};cap=rng.randint(1,N)
        q=request(ids,cap=cap);oracle=Replay(labels);events=[]
        result=execute(q,snapshot,oracle,None,Least(),Plan(1000+trial,90000+trial,700000+trial,
              requested_bins=1 if trial%2 else 4,pilot_cap=0 if trial%3 else 8,
              tiny_scan_max=128 if trial%4==0 else 0,initial_batch=1+trial%4,batch_size=1+trial%7,
              explore_every=0 if trial%5 else 4),core_root=CORE,observer=lambda s,d:events.append((s,d)))
        c=basic_assertions(result,oracle,cap);direct=truth_vector(q,labels)
        # Independently reconstruct real remaining cell totals from revealed IDs.
        matrix,_=compiler.compile_signed_decisions(q,snapshot)
        pilot_ids=set(next((r['record_ids'] for r in result['read_receipts'] if r['phase']=='pilot'),[]))
        residual=sorted({i for row in matrix.rows for i,a in row.items() if a}-pilot_ids)
        sig_groups={}
        for rid in residual:
            sig=tuple(row.get(rid,Fraction(0)) for row in matrix.rows)
            sig_groups.setdefault(sig,[]).append(rid)
        # No proxy -> constant scores -> no bin split. Count IDs match group order.
        true_counts={h:sum(labels[i] for i in rs) for h,rs in enumerate(sig_groups.values())}
        covered=all(e['bounds'] is not None and e['bounds'][0]<=true_counts[e['cell_id']]<=e['bounds'][1] for e in result['cs_events'])
        noncoverage+=not covered
        if c['status']=='execution_error':execution_errors+=1
        if covered:
            for emitted,truth in zip(c['decisions'],direct):
                assert emitted['value'] is None or emitted['value']==truth;covered_claims+=1
        for state,_ in events:
            assert not {'labels','oracle','record_ids','permutations','formal_seed'}&set(vars(state))
            assert sum(Fraction.from_float(cell.alpha) for cell in state.cells)<=Fraction('0.05')
            for atom in state.family.atoms:
                lo=hi=state.pilot_constants.get(atom.row_index,Fraction(0))
                for cell in state.cells:
                    a=cell.coefficients[atom.row_index]
                    lo+=a*(cell.lower if a>=0 else cell.upper);hi+=a*(cell.upper if a>=0 else cell.lower)
                assert state.bounds[atom.index]==(lo,hi)
        executions+=1
    report['overlap_execution_cases']=executions;report['covered_claims_checked']=covered_claims
    report['source_noncoverage_cases_retained']=noncoverage;report['execution_errors_retained']=execution_errors
    ids=[f'r{i:03d}' for i in range(40)];snapshot=MemorySnapshot({i:{'text':''} for i in ids});q=request(ids,cap=13)
    labels={i:int(j%2) for j,i in enumerate(ids)};oracle=Replay(labels);log=[];policy=Least()
    result=execute(q,snapshot,oracle,SpyProxy(log),policy,Plan(37,98531,77219,tiny_scan_max=0,initial_batch=1,batch_size=2,explore_every=0),core_root=CORE)
    c=basic_assertions(result,oracle,13)
    pilot=next(r for r in result['read_receipts'] if r['phase']=='pilot')
    fit=[e for e in log if e[0]=='fit']
    if len(set(pilot['labels']))==2:
        assert len(fit)==1 and fit[0][1]==pilot['record_ids'] and fit[0][2]==pilot['labels']
        expected=set(ids)-set(pilot['record_ids']);assert {e[1] for e in log if e[0]=='score'}==expected
    else:assert not fit
    # Future-label noninterference: change only labels never acquired by run1.
    altered={i:(v if i in result['observed_labels'] else 1-v) for i,v in labels.items()}
    oracle2=Replay(altered);result2=execute(q,snapshot,oracle2,SpyProxy([]),Least(),Plan(37,98531,77219,tiny_scan_max=0,initial_batch=1,batch_size=2,explore_every=0),core_root=CORE)
    assert [r['record_ids'] for r in result['read_receipts']]==[r['record_ids'] for r in result2['read_receipts']]
    assert result['certificate']['decisions']==result2['certificate']['decisions']
    assert result['certificate']['frozen']==result2['certificate']['frozen']
    report['pilot_only_proxy_fit']=True;report['unread_label_flip_noninterference']=True
    # Real permutation changes cannot enter policy-visible state/choices when
    # observed values remain the same.
    identical=dict.fromkeys(ids,0);paths=[]
    for formal in [192835,712983]:
        o=Replay(identical);r=execute(request(ids,cap=20),snapshot,o,None,Least(),Plan(37,formal,77219,tiny_scan_max=0,initial_batch=1,batch_size=2,explore_every=0),core_root=CORE)
        paths.append([(a['cell_id'],a['prefix_before'],a['prefix_after'],a['source']) for a in r['actions']])
    assert paths[0]==paths[1];report['future_permutation_choice_noninterference']=True
    # Backend failure and malformed batches: charge submitted size exactly once.
    backend_cases=0
    class Bad:
        def __init__(self,mode):self.mode=mode;self.requests=[]
        def read(self,items):
            self.requests.append(list(items))
            if self.mode=='raise':raise RuntimeError('synthetic backend failure')
            if self.mode=='partial':return {items[0]:0}
            if self.mode=='bool':return {i:False for i in items}
            return {i:2 for i in items}
    for mode in ['raise','partial','bool','nonbinary']:
        b=Bad(mode);r=execute(request(ids,cap=20),snapshot,b,None,Least(),Plan(37,98531,77219,tiny_scan_max=0),core_root=CORE)
        cert=r['certificate'];assert cert['status']=='execution_error' and cert['framework_exception'] is None
        assert len(b.requests)==1 and cert['semantic_calls']==len(b.requests[0]) and cert['unique_successful_returns']==0
        backend_cases+=1
    report['failed_or_malformed_backend_once_cases']=backend_cases
    # Policy programming exceptions retain already charged calls.
    class BrokenPolicy:
        def choose(self,state):raise RuntimeError('synthetic policy failure')
    o=Replay(labels);r=execute(request(ids),snapshot,o,None,BrokenPolicy(),Plan(37,98531,77219,tiny_scan_max=0,initial_batch=1,batch_size=2,explore_every=0),core_root=CORE)
    assert r['certificate']['framework_exception']['class']=='RuntimeError'
    assert r['certificate']['semantic_calls']==sum(map(len,o.requests))>0
    report['policy_failure_accounting_retained']=True
    # A structurally false D does not complete an unresolved other D.
    decisions=[{'type':'compare','left':'a','right':'b','threshold':1,'unit':'proportion_difference'}, {'type':'compare','left':'b','right':'c','threshold':0,'unit':'proportion_difference'}]
    o=Replay(labels);r=execute(request(ids,decisions=decisions,cap=1),snapshot,o,None,Least(),Plan(37,98531,77219,tiny_scan_max=0),core_root=CORE)
    assert r['certificate']['status']=='unresolved' and r['certificate']['resolved_judgments']==1
    assert [d['value'] for d in r['certificate']['decisions']]==[False,None]
    report['every_declared_decision_required']=True
    # Patched strict-ranking behavior: ties remain unresolved even in dual mode.
    cohorts=[{'id':'a','record_ids':ids[:12]},{'id':'b','record_ids':ids[12:25]},{'id':'c','record_ids':ids[25:]}]
    rank=[{'type':'top1','candidates':['a','b','c']}]
    o=Replay(identical);r=execute(request(ids,decisions=rank,cohorts=cohorts),snapshot,o,None,Least(),Plan(1,2,3,tiny_scan_max=128),core_root=CORE)
    assert r['certificate']['status']=='unresolved' and r['certificate']['decisions'][0]['value'] is None
    report['strict_ranking_tie_mask_passed']=True
    # Post-acquisition verification/render failures are outside the accounting
    # catch. This intentionally faulty diagnostic observer demonstrates the gap.
    seen={'n':0}
    def mutating_observer(state,verdict):
        seen['n']+=1;verdict['complete']=True
    o=Replay(labels)
    try:
        execute(request(ids,cap=20),snapshot,o,None,Least(),Plan(37,98531,77219,tiny_scan_max=0),core_root=CORE,observer=mutating_observer)
    except ValueError as error:
        assert 'Invalid request completion' in str(error)
        report['render_accounting_escape_reproducer']={'reproduced':True,'submitted_calls_before_uncaught_error':sum(map(len,o.requests)),'error':str(error),'source':'Mutable diagnostic verdict can reach render verification outside framework-failure catch.'}
    else:raise AssertionError('Expected render-accounting gap was not reproduced.')
    report['wall_seconds']=time.perf_counter()-start
    report['result']='Checks passed; one reproducible post-acquisition render-accounting API gap reported.'
    (HERE/'synthetic_execution_audit.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
if __name__=='__main__':main()

