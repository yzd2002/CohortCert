#!/usr/bin/env python3
"""Finite exact-rational checks of raw CS inversion and sticky prefix handling."""
from pathlib import Path
from fractions import Fraction
from itertools import product
from types import SimpleNamespace
import importlib.util,json,math,hashlib,sys,time
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'frozen_executor_snapshot/system_design'))
from common import Timings
from request_repairs import sticky_cs_class
SOURCE=Path('/dev/shm/CohortCert_fixed_label_replay_20261031/engine/finite_population_cs.py')
spec=importlib.util.spec_from_file_location('independent_original_cs',SOURCE);m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
def rising(x,n):return math.prod(range(x,x+n))
def exact_q(n,s,a,b,lam):
    base=Fraction(1,(n+1)*math.comb(n,s))
    proxy=Fraction(rising(a,s)*rising(b,n-s),rising(a+b,n))
    return (1-lam)*base+lam*proxy
def accepted(N,n,s,a,b,lam,alpha):
    q=exact_q(n,s,a,b,lam);result=[]
    for K in range(s,N-n+s+1):
        p=Fraction(math.comb(N-n,K-s),math.comb(N,K))
        if q*alpha<p or alpha==0:result.append(K)
    return result
def main():
    start=time.perf_counter();states=0;candidates=0;outward_extra=0
    configs=[(1,1,Fraction(0),.05),(2,21,Fraction(1,2),.05/256),(21,1,Fraction(1,2),1e-10),(3,8,Fraction(1),.99),(1,1,Fraction(1,2),0.)]
    for N in [1,2,3,4,5,8,16,24,32,48,64]:
        for a,b,lam,alpha in configs:
            cs=m.CellCS(N,alpha,a=a,b=b,lam=float(lam));exact_alpha=Fraction.from_float(alpha)
            for n in range(N+1):
                for s in range(n+1):
                    cs.n,cs.s=n,s;actual=cs._current_set();expected=accepted(N,n,s,a,b,lam,exact_alpha)
                    assert not expected or (actual is not None and actual[0]<=min(expected)<=max(expected)<=actual[1]),(N,n,s,a,b,lam,alpha,expected,actual)
                    states+=1;candidates+=len(expected)
                    if actual is not None:outward_extra+=len(set(range(actual[0],actual[1]+1))-set(expected))
    # Running intersection, exact exhaustion and sticky empty sets.
    events=[];Sticky=sticky_cs_class(m.CellCS,events,Timings());paths=0;prefixes=0
    for a,b in [(1,21),(21,1)]:
        for bits in product([0,1],repeat=8):
            cs=Sticky(8,.05,a=a,b=b,lam=.5);cs.audit_cell_id=0;exact=set(range(9));ever_empty=False
            n=s=0
            for y in bits:
                n+=1;s+=y
                exact &= set(accepted(8,n,s,a,b,Fraction(1,2),Fraction.from_float(.05)))
                old=cs.bounds;cs.update([y]);actual=cs.bounds
                if ever_empty:assert actual is None
                if actual is None:ever_empty=True
                assert not exact or (actual is not None and actual[0]<=min(exact)<=max(exact)<=actual[1])
                prefixes+=1
            paths+=1
    report={'status':'passed','raw_state_cases':states,'exactly_accepted_candidates_covered':candidates,'outward_extra_candidates_allowed':outward_extra,'sequential_label_paths':paths,'sequential_record_prefixes':prefixes,'kernel_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'wall_seconds':time.perf_counter()-start,'scope':'Finite exact integer/rational checks; no universal floating-point inversion proof. Includes zero per-cell alpha and sticky exhaustion. No source corpus/model access.'}
    (HERE/'exact_cs_audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if __name__=='__main__':main()

