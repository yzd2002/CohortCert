"""Small dependency-free helpers for the separate runtime candidate."""
from __future__ import annotations

from collections import defaultdict
from contextlib import contextmanager
import hashlib
import importlib
import json
from pathlib import Path
import sys
import time


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False,
                      allow_nan=False, separators=(",", ":"))


def digest(value):
    return hashlib.sha256(canonical(value).encode("utf-8")).hexdigest()


def file_hash(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def write_new(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False, allow_nan=False)
        stream.write("\n")


def core_module(root, name):
    root = Path(root).resolve()
    if not (root / "engine/pipeline.py").is_file():
        raise ImportError("Core root must directly contain engine/ and query/")
    if str(root) not in sys.path:
        sys.path.insert(0, str(root))
    module = importlib.import_module(name)
    if not Path(module.__file__).resolve().is_relative_to(root):
        raise ImportError(f"{name} imported from outside configured core")
    # An individually correct module can still have imported a cached sibling
    # package from another checkout. Reject that mixed-core state as well.
    for loaded_name, loaded in list(sys.modules.items()):
        if loaded_name in ("engine", "query") or loaded_name.startswith(("engine.", "query.")):
            source = getattr(loaded, "__file__", None)
            if source and not Path(source).resolve().is_relative_to(root):
                raise ImportError(f"Mixed core import: {loaded_name} came from outside configured core")
    return module


class Timings:
    """Disjoint named spans, with process CPU time measured independently."""
    def __init__(self):
        self.values = defaultdict(lambda: {"wall_ms": 0.0, "cpu_ms": 0.0, "calls": 0})

    @contextmanager
    def span(self, name):
        wall, cpu = time.perf_counter_ns(), time.process_time_ns()
        try:
            yield
        finally:
            value = self.values[name]
            value["wall_ms"] += (time.perf_counter_ns() - wall) / 1e6
            value["cpu_ms"] += (time.process_time_ns() - cpu) / 1e6
            value["calls"] += 1

    def call(self, name, fn, *args, **kwargs):
        with self.span(name):
            return fn(*args, **kwargs)

    def export(self):
        return {k: dict(v) for k, v in self.values.items()}
