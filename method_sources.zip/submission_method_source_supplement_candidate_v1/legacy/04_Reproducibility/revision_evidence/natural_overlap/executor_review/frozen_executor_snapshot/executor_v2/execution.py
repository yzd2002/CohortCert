"""Versioned, fail-closed acquisition executor for per-judgment decisions.

Historical compiler/count-sequence sources are imported from an explicit core.
No historical engine file is modified.  All arms share this execution loop,
pilot, partition, prefix sampler, checker and accounting.  Policies receive only
the read-only state in state.py, never a real future permutation or label vault.
"""
from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path
import random
import sys
import time
import traceback
from types import MappingProxyType

HERE = Path(__file__).resolve().parent
REPAIRS = HERE.parent / 'system_design'
if str(REPAIRS) not in sys.path:
    sys.path.insert(0, str(REPAIRS))
from common import Timings, canonical, core_module, digest
from request_repairs import resolve_plan, sticky_cs_class

try:
    from .dual_certificate import evaluate, verify
    from .state import AcquisitionState, CellView, FamilyView
except ImportError:
    from dual_certificate import evaluate, verify
    from state import AcquisitionState, CellView, FamilyView

VERSION = 'cohortcert.executor.v2.dual-record-prefix'


@dataclass(frozen=True)
class Plan:
    pilot_seed: int
    formal_seed: int
    exploration_seed: int
    alpha_override: float | None = None
    budget_override: int | None = None
    semantics: str = 'bidirectional'
    requested_bins: int = 1
    max_cells: int = 256
    pilot_cap: int = 256
    initial_batch: int = 8
    batch_size: int = 16
    explore_every: int = 4
    prior_weight: float = 0.5
    prior_strength: int = 20
    tiny_scan_max: int = 128


class ReadFailure(Exception):
    pass


class Reader:
    """Count submitted row-label attempts; fail a batch once, with no fallback.

    Physical GPU forwards are reported separately by a live backend.  A failed
    submitted batch can have an unexecuted tail; it is never silently retried or
    consumed as a valid prefix.  All submitted requests stay in cap accounting.
    """
    def __init__(self, oracle, cap, timings):
        self.oracle, self.cap, self.timings = oracle, cap, timings
        self.spent, self.observed, self.receipts = 0, {}, []

    @property
    def remaining(self):
        return self.cap - self.spent

    def read(self, ids, phase):
        ids = list(ids)
        if len(ids) != len(set(ids)) or any(rid in self.observed for rid in ids):
            raise ReadFailure('Duplicate within-request acquisition')
        if len(ids) > self.remaining:
            raise ReadFailure('Acquisition would exceed the authoritative cap')
        self.spent += len(ids)
        receipt = {'phase': phase, 'record_ids': ids, 'submitted': len(ids), 'success': False}
        self.receipts.append(receipt)
        if not ids:
            receipt['success'] = True
            return {}
        try:
            raw = self.timings.call('oracle', self.oracle.read, ids)
            if not isinstance(raw, dict) or set(raw) != set(ids):
                raise ValueError('Backend did not return the complete submitted batch')
            if any(type(value) is not int or value not in (0, 1) for value in raw.values()):
                raise ValueError('Backend returned a non-binary label')
        except Exception as exc:
            receipt['error'] = repr(exc)
            raise ReadFailure(str(exc)) from exc
        self.observed.update(raw)
        receipt.update(success=True, labels=[raw[rid] for rid in ids])
        return raw


def _deterministic_bounds(matrix, family):
    rows = []
    for row in matrix.rows:
        rows.append((sum((a for a in row.values() if a < 0), Fraction(0)),
                     sum((a for a in row.values() if a > 0), Fraction(0))))
    return {atom.index: rows[atom.row_index] for atom in family.atoms}


class IntegerPushforward:
    """Exact signed propagation; all arithmetic in the loop is integer."""
    def __init__(self, cells, pilot, family):
        self.family = family
        count = len(cells[0].signature) if cells else (max(pilot, default=-1) + 1)
        self.scales, self.coefficients, self.constants = [], [], []
        for row in range(count):
            scale = math.lcm(pilot.get(row, Fraction(0)).denominator,
                             *(c.signature[row].denominator for c in cells))
            self.scales.append(scale)
            self.coefficients.append([int(c.signature[row] * scale) for c in cells])
            self.constants.append(int(pilot.get(row, Fraction(0)) * scale))

    def bounds(self, cells, counts):
        if any(counts[c.cell_id].bounds is None for c in cells):
            return None
        row_bounds = []
        for coefficients, constant, scale in zip(self.coefficients, self.constants, self.scales):
            lower = upper = constant
            for coefficient, cell in zip(coefficients, cells):
                lo, hi = counts[cell.cell_id].bounds
                lower += coefficient * (lo if coefficient >= 0 else hi)
                upper += coefficient * (hi if coefficient >= 0 else lo)
            row_bounds.append((Fraction(lower, scale), Fraction(upper, scale)))
        return {atom.index: row_bounds[atom.row_index] for atom in self.family.atoms}


def _fitted_scores(proxy, ids, pilot_ids, labels, timings):
    """One per-request fit and one frozen score pass; no reference-label input."""
    fallback = None
    if not pilot_ids or len({labels[rid] for rid in pilot_ids}) < 2 or proxy is None:
        fallback = 'empty_or_single_class_pilot' if proxy is not None else 'no_proxy'
    if fallback is None:
        try:
            with timings.span('proxy_fit'):
                fitted = proxy.clone_unfitted() if hasattr(proxy, 'clone_unfitted') else proxy
                fitted.fit(pilot_ids, [labels[rid] for rid in pilot_ids])
            with timings.span('proxy_scores'):
                # This is a new, recorded vectorized scoring path, shared by
                # every arm; it does not claim historical bit equivalence.
                if hasattr(fitted, '_emb') and hasattr(fitted, '_model'):
                    rows = [fitted._row_of[str(rid)] for rid in ids]
                    values = fitted._model.predict_proba(fitted._emb[rows])[:, 1]
                    scores = dict(zip(ids, map(float, values)))
                else:
                    scores = {rid: float(fitted.score(rid)) for rid in ids}
            if any(not math.isfinite(p) or not 0 <= p <= 1 for p in scores.values()):
                raise ValueError('Invalid proxy score')
            return scores, {'fallback': None, 'scoring': 'one_frozen_pass'}
        except Exception as exc:
            fallback = 'proxy_fit_or_score_failure: ' + repr(exc)
    value = (sum(labels.values()) + 0.5) / (len(labels) + 1)
    return dict.fromkeys(ids, value), {'fallback': fallback, 'constant_probability': value}


def execute(contract, snapshot, oracle, proxy, policy, plan: Plan, *, core_root,
            record_actions=True, record_cs_events=True, observer=None, policy_spec=None):
    start_wall, start_cpu = time.perf_counter_ns(), time.process_time_ns()
    timings = Timings()
    effective, binding = resolve_plan(contract, alpha_override=plan.alpha_override,
                                      budget_override=plan.budget_override)
    if plan.semantics not in ('positive_only', 'bidirectional'):
        raise ValueError('Unknown decision completion mode')
    if not 1 <= plan.requested_bins <= 4 or not 1 <= plan.max_cells <= 1024:
        raise ValueError('Invalid fixed partition limits')
    if any(type(value) is not int or value < 1 for value in (plan.initial_batch, plan.batch_size)):
        raise ValueError('Batches must be positive integers')
    if any(type(value) is not int or value < 0 for value in (plan.pilot_cap, plan.tiny_scan_max,
                                                          plan.explore_every, plan.prior_strength)):
        raise ValueError('Invalid nonnegative execution setting')
    if not math.isfinite(plan.prior_weight) or not 0 <= plan.prior_weight <= 1:
        raise ValueError('Invalid frozen working-prior mixture')
    for decision in effective['decisions']:
        if 'topk_set' in decision and len(set(decision['topk_set'])) != len(decision['topk_set']):
            raise ValueError('Explicit top-k set contains duplicate IDs')
    compiler = core_module(core_root, 'query.compiler')
    frozen = core_module(core_root, 'engine.frozen_cells')
    base_cs = core_module(core_root, 'engine.finite_population_cs').CellCS
    reader = Reader(oracle, effective['budget']['max_oracle_record_predicate_calls'], timings)
    alpha = effective['risk']['alpha']
    with timings.span('compile'):
        matrix, original_family = compiler.compile_signed_decisions(effective, snapshot)
        family = FamilyView.freeze(original_family)
        support = sorted({rid for row in matrix.rows for rid, value in row.items() if value})
    family_payload = {'atoms': [dict(index=a.index, kind=a.kind, threshold=str(a.threshold),
                                     row_index=a.row_index, cohort_pair=a.cohort_pair) for a in family.atoms],
                      'certificates': family.certificates,
                      'certificate_decisions': family.certificate_decisions,
                      'decision_types': family.decision_types}
    execution_plan = {**binding, 'version': VERSION,
                      'settings': {key: value for key, value in vars(plan).items()},
                      'policy': policy_spec or {'class': type(policy).__module__ + '.' + type(policy).__qualname__},
                      'family_sha256': digest(family_payload)}
    execution_plan['execution_plan_sha256'] = digest(execution_plan)
    actions, cs_events, cells, counts, pilot_constants = [], [], [], {}, {}
    proxy_receipt = None
    frozen_receipts = {}
    current_bounds = _deterministic_bounds(matrix, family)
    decision_result = evaluate(family, current_bounds, mode=plan.semantics)
    reason, status, framework_exception = '', 'unresolved', None

    def checked_state(step):
        return AcquisitionState(
            cells=tuple(CellView(c.cell_id, c.N, counts[c.cell_id].n, counts[c.cell_id].s,
                                 counts[c.cell_id].low, counts[c.cell_id].high,
                                 counts[c.cell_id].alpha, counts[c.cell_id].a,
                                 counts[c.cell_id].b, counts[c.cell_id].lam,
                                 tuple(c.signature)) for c in cells),
            family=family, bounds=MappingProxyType(dict(current_bounds)),
            pilot_constants=MappingProxyType(dict(pilot_constants)),
            remaining_calls=reader.remaining, step=step, batch_size=plan.batch_size,
            semantics=plan.semantics,
            unit_costs=MappingProxyType({c.cell_id: 1.0 for c in cells}))

    try:
        if decision_result['complete']:
            status, reason = 'complete', 'structural'
        elif len(support) <= plan.tiny_scan_max and len(support) <= reader.remaining:
            labels = reader.read(support, 'tiny_scan')
            rows = [sum((a * labels[rid] for rid, a in row.items()), Fraction(0)) for row in matrix.rows]
            current_bounds = {a.index: (rows[a.row_index], rows[a.row_index]) for a in family.atoms}
            decision_result = evaluate(family, current_bounds, mode=plan.semantics)
            status = 'complete' if decision_result['complete'] else 'unresolved'
            reason = 'tiny_scan'
        else:
            pilot_size = min(plan.pilot_cap, len(support) // 10, reader.cap // 4)
            pilot_ids = sorted(random.Random(plan.pilot_seed).sample(support, pilot_size))
            pilot_labels = reader.read(pilot_ids, 'pilot')
            pilot_set = set(pilot_ids)
            with timings.span('pilot_contribution'):
                pilot_constants = {row: sum((a * pilot_labels[rid] for rid, a in values.items()
                                             if rid in pilot_set), Fraction(0))
                                   for row, values in enumerate(matrix.rows)}
            residual = [rid for rid in support if rid not in pilot_set]
            scores, proxy_receipt = _fitted_scores(proxy, residual, pilot_ids, pilot_labels, timings)
            frozen_proxy = type('FrozenScores', (), {'score': lambda self, rid: scores[rid]})()
            with timings.span('partition'):
                cells = frozen.freeze_coefficient_cells(residual, matrix, frozen_proxy,
                                                       n_bins=plan.requested_bins, max_cells=plan.max_cells)
            class Sink:
                def append(self, value):
                    if record_cs_events:
                        cs_events.append(value)
            cs_class = sticky_cs_class(base_cs, Sink(), timings)
            with timings.span('initialize_inference'):
                exact_cell_risk = Fraction(str(alpha)) / len(cells) if cells else Fraction(0)
                cell_risk = float(exact_cell_risk)
                if Fraction.from_float(cell_risk) > exact_cell_risk:
                    cell_risk = math.nextafter(cell_risk, 0.0)
                for cell in cells:
                    probability = sum(scores[rid] for rid in cell.records) / cell.N
                    amount = math.floor(plan.prior_strength * probability)
                    cs = cs_class(cell.N, cell_risk, a=1 + amount,
                                  b=1 + plan.prior_strength - amount, lam=plan.prior_weight)
                    cs.audit_cell_id = cell.cell_id
                    counts[cell.cell_id] = cs
                permutations = frozen.independent_uniform_permutations(cells, plan.formal_seed)
                frozen_receipts = {
                    'pilot_ids_sha256': digest(pilot_ids), 'pilot_labels_sha256': digest(pilot_labels),
                    'scores_sha256': digest(scores),
                    'partition_sha256': digest([(c.cell_id, list(map(str, c.signature)), c.bin, c.records) for c in cells]),
                    'priors_sha256': digest([(c.cell_id, counts[c.cell_id].a, counts[c.cell_id].b,
                                              counts[c.cell_id].lam, counts[c.cell_id].alpha) for c in cells]),
                    'permutations_sha256': digest(permutations),
                }
                push = IntegerPushforward(cells, pilot_constants, family)
            explore_rng = random.Random(plan.exploration_seed)
            step = 0
            while True:
                with timings.span('certificate'):
                    current_bounds = push.bounds(cells, counts)
                    if current_bounds is None or any(cs.inconsistent for cs in counts.values()):
                        status, reason = 'execution_error', 'sticky_certificate_inconsistency'
                        decision_result = None
                        break
                    decision_result = evaluate(family, current_bounds, mode=plan.semantics)
                if observer is not None:
                    observer(checked_state(step), decision_result)
                if decision_result['complete']:
                    status, reason = 'complete', 'all_declared_judgments_resolved'
                    break
                unfinished = [c for c in cells if counts[c.cell_id].n < c.N]
                if reader.remaining <= 0 or not unfinished:
                    reason = 'budget_exhausted' if reader.remaining <= 0 else 'population_exhausted'
                    break
                step += 1
                with timings.span('schedule'):
                    unvisited = [c for c in unfinished if counts[c.cell_id].n == 0]
                    if plan.explore_every and step % plan.explore_every == 0:
                        chosen = explore_rng.choice(unfinished)
                        selected, batch, source, diagnostic = chosen.cell_id, (
                            plan.initial_batch if counts[chosen.cell_id].n == 0 else plan.batch_size), 'exploration', None
                    elif unvisited:
                        chosen = max(unvisited, key=lambda c: (c.N, c.cell_id))
                        selected, batch, source, diagnostic = chosen.cell_id, plan.initial_batch, 'initialization', None
                    else:
                        choice = policy.choose(checked_state(step))
                        selected, batch, source, diagnostic = choice.cell_id, choice.batch, 'policy', choice.diagnostics
                    if selected not in counts or type(batch) is not int or batch <= 0:
                        raise ReadFailure('Policy returned an invalid cell or batch')
                    before = counts[selected].n
                    batch = min(batch, reader.remaining, counts[selected].N - before)
                    if batch <= 0:
                        raise ReadFailure('Policy selected an exhausted cell')
                    ids = permutations[selected][before:before + batch]
                labels = reader.read(ids, 'formal')
                counts[selected].update([labels[rid] for rid in ids])
                if record_actions:
                    actions.append({'step': step, 'source': source, 'cell_id': selected,
                                    'prefix_before': before, 'prefix_after': counts[selected].n,
                                    'record_ids': ids, 'labels': [labels[rid] for rid in ids],
                                    'bounds': counts[selected].bounds, 'diagnostics': diagnostic})
    except ReadFailure as exc:
        status, reason = 'execution_error', str(exc)
        decision_result = None
    except Exception as exc:
        # Preserve calls and receipts on a programming/backend failure. A grid
        # harness must treat this explicit marker as an audit failure and stop,
        # rather than silently accepting a zero-cost failed row.
        status, reason = 'execution_error', 'framework_exception'
        framework_exception = {'class': type(exc).__name__, 'message': str(exc),
                               'traceback': traceback.format_exc()}
        decision_result = None
    if reader.spent > reader.cap or len(reader.observed) != len(set(reader.observed)):
        raise AssertionError('Internal budget/unique-return invariant failed')
    with timings.span('render'):
        if decision_result is not None:
            verify(family, current_bounds, decision_result)
        claims = []
        for decision in (decision_result or {}).get('decisions', []):
            item = dict(decision)
            item['decision_type'] = family.decision_types[item['decision']]
            if item['value'] is True and item['decision_type'] in ('top1', 'topk'):
                aids = family.certificates[item['positive_certificate']]
                item['selected_cohorts'] = sorted({family._by_index[aid].cohort_pair[0] for aid in aids})
            claims.append(item)
        certificate = {
            'version': VERSION, 'status': status, 'reason': reason,
            'semantics': plan.semantics, 'plan': execution_plan,
            'support_size': len(support), 'semantic_calls': reader.spent,
            'unique_successful_returns': len(reader.observed),
            'declared_judgments': len(family.decision_types),
            'resolved_judgments': (decision_result or {}).get('resolved_decisions', 0),
            'decisions': claims,
            'contrast_intervals': None if current_bounds is None else {
                str(k): list(map(str, interval)) for k, interval in current_bounds.items()},
            'cell_count': len(cells), 'proxy': proxy_receipt, 'frozen': frozen_receipts,
            'framework_exception': framework_exception,
            'sampled_ids_sha256': digest(list(reader.observed)),
            'successful_labels_sha256': digest(reader.observed),
            'family': family_payload,
        }
        canonical(certificate)  # Actual response serialization is part of query work.
    total = {'wall_ms': (time.perf_counter_ns() - start_wall) / 1e6,
             'cpu_ms': (time.process_time_ns() - start_cpu) / 1e6}
    return {'certificate': certificate, 'timings': timings.export(), 'total': total,
            'actions': actions, 'cs_events': cs_events, 'read_receipts': reader.receipts,
            'observed_labels': reader.observed}
