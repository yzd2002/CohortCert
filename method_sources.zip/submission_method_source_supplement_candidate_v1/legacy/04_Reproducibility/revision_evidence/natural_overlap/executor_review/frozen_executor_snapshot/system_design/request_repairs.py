"""Portable request/CS repairs for either one-sided or bidirectional executors.

No engine imports occur at module import time. The caller supplies the frozen
base CellCS, the cost recorder, and the receipt sink. This file makes no claim
about the correctness of an external checker or floating-point inversion.
"""
from __future__ import annotations

from copy import deepcopy
import math

from common import digest

CAP_KEY = "max_oracle_record_predicate_calls"
VERSION = "cohortcert.runtime-candidate.v2-record-prefix"


def resolve_plan(contract, *, alpha_override=None, budget_override=None):
    requested = deepcopy(contract)
    alpha = requested["risk"]["alpha"]
    cap = requested["budget"][CAP_KEY]
    for a in (alpha, alpha if alpha_override is None else alpha_override):
        if type(a) not in (int, float) or not math.isfinite(a) or not 0 < a < 1:
            raise ValueError("Risk alpha must be finite and strictly between 0 and 1")
    for b in (cap, cap if budget_override is None else budget_override):
        if type(b) is not int or b <= 0:
            raise ValueError("Record-call cap must be a positive integer, as required by the core schema")
    effective = deepcopy(requested)
    effective["risk"]["alpha"] = float(alpha if alpha_override is None else alpha_override)
    effective["budget"][CAP_KEY] = cap if budget_override is None else budget_override
    plan = {"version": VERSION, "requested_contract_sha256": digest(requested),
            "effective_contract_sha256": digest(effective),
            "requested": {"alpha": alpha, CAP_KEY: cap},
            "effective": {"alpha": effective["risk"]["alpha"], CAP_KEY: effective["budget"][CAP_KEY]},
            "authority": {"alpha": "serialized" if alpha_override is None else "explicit_override",
                          CAP_KEY: "serialized" if budget_override is None else "explicit_override"}}
    return effective, plan


def sticky_cs_class(base, sink, timings):
    """Use every record prefix; never erase a failed running intersection.

    Assign audit_cell_id before update(). Successful acquisition of a batch
    still does not imply a per-record stopping check by the caller. The CS path
    within that batch depends only on the cell's revealed ordered labels.
    """
    class StickyRecordCS(base):
        def update(self, labels):
            labels = list(labels)
            if any(type(y) is not int or y not in (0, 1) for y in labels):
                raise ValueError("Labels must be binary integers")
            if self.n + len(labels) > self.N:
                raise ValueError("Read exceeds cell population")
            with timings.span("cs_update"):
                for y in labels:
                    old = self.bounds
                    next_n, next_s = self.n + 1, self.s + y
                    if self.inconsistent or old is None:
                        self.n, self.s = next_n, next_s
                        self.inconsistent = True
                        self.low, self.high = 1, 0
                    elif next_n == self.N:
                        self.n, self.s = next_n, next_s
                        if old[0] <= next_s <= old[1]:
                            self.low = self.high = next_s
                        else:
                            self.inconsistent = True
                            self.low, self.high = 1, 0
                    else:
                        super().update([y])
                        if self.bounds is None:
                            self.inconsistent = True
                            self.low, self.high = 1, 0
                    sink.append({"cell_id": self.audit_cell_id, "N": self.N,
                                 "alpha": self.alpha, "a": self.a, "b": self.b, "lam": self.lam,
                                 "n": self.n, "s": self.s, "bounds": self.bounds,
                                 "inconsistent": bool(self.inconsistent)})
            return self.bounds
    return StickyRecordCS


def no_fallback_reader_class(base, oracle_failure):
    """Historical read_prefix performs extra reads after max_attempts=1.

    This reader commits a whole returned batch or terminates on its failure.
    Any physically completed prefix retained in the backend receipt is charged
    and not consumed as evidence. base.read must already charge failed batches.
    """
    class NoFallbackBudgetedOracle(base):
        def read_prefix(self, ids, phase="oracle", caller=""):
            try:
                return self.read(ids, phase=phase, caller=caller), None, {}
            except oracle_failure as exc:
                return {}, exc, {}
    return NoFallbackBudgetedOracle
