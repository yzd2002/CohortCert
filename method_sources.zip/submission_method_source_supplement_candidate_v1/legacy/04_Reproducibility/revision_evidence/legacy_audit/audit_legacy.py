#!/usr/bin/env python3
"""Independent read-only audit of the completed 9,600-row legacy replication.

No executor, engine, query compiler, allocator, confidence-update implementation
or optimizer is imported or run. Generic metadata AST evaluation and coefficient
signatures are derived here. Only pure interval/proof verification methods are
reused from independent_analysis/reference.py; its Civil-specific initializer
and compiler are never called. All artifacts are written in this new folder.
"""
from __future__ import annotations
from collections import Counter, defaultdict
from copy import deepcopy
from fractions import Fraction
import argparse
import csv
import gzip
import hashlib
import importlib.util
from itertools import combinations
import json
import math
from pathlib import Path
import random
import sys
import time
import traceback

EXPECTED_MANIFEST = "1853b1373d710cc8f47bef4a0a44c6be7e315f6432e9af122eeefbf505ed5cf7"
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
REFERENCE = ROOT/"independent_analysis/reference.py"
spec = importlib.util.spec_from_file_location("legacy_independent_pure_reference", REFERENCE)
pure = importlib.util.module_from_spec(spec); spec.loader.exec_module(pure)
F, digest, sha, require = pure.F, pure.digest, pure.sha, pure.require


def write(path, value):
    with Path(path).open("x", encoding="utf-8") as f:
        json.dump(value, f, indent=2, ensure_ascii=False, allow_nan=False, default=str); f.write("\n")


def fields_in(ast):
    op, args = (ast["op"], ast.get("args", [])) if "op" in ast else next(iter(ast.items()))
    if op in ("and", "or", "not"):
        return set().union(*(fields_in(a) for a in args))
    return {args[0]}


def evaluate_ast(ast, record):
    require(isinstance(ast, dict), "AST must be an object")
    op, args = (ast["op"], ast.get("args", [])) if "op" in ast else next(iter(ast.items()))
    if op in ("and", "or"):
        require(bool(args), "Empty metadata Boolean AST is unsupported")
        values = [evaluate_ast(a, record) for a in args]
        return all(values) if op == "and" else any(values)
    if op == "not":
        require(len(args) == 1, "not requires one metadata subexpression")
        return not evaluate_ast(args[0], record)
    field, value = args
    require(field in record, "Unknown metadata field: "+field)
    actual = record[field]
    if op == "eq": return actual == value
    if op == "ne": return actual is not None and actual != value
    if op == "in": return actual in set(value)
    require(op in ("ge", "le", "gt", "lt"), "Unknown metadata AST operator: "+op)
    if actual is None or value is None: return False
    try:
        if op == "ge": return actual >= value
        if op == "le": return actual <= value
        if op == "gt": return actual > value
        return actual < value
    except TypeError:
        return False


class GenericReference(pure.Reference):
    def __init__(self, manifest):
        import pyarrow.parquet as pq
        self.manifest, self.core = manifest, Path(manifest["core_root"])
        queries = [json.loads(s) for s in (self.core/"data/queries/all_queries.jsonl").read_text().splitlines() if s]
        self.queries = {q["query_id"]: q for q in queries if q["split"] == "test"}
        require(len(self.queries) == 320, "Expected all original 320 test contracts")
        self.records, self.labels, self.memberships, self.templates, self.means = {}, {}, {}, {}, {}
        env_fields = ("model_revision", "tokenizer_revision", "prompt_template_hash", "chunk_rule", "record_result_rule",
                      "decode_rule", "precision", "max_context_tokens", "batch_size", "environment_id")
        self.label_content_hashes = {}
        for dataset in ("cfpb", "opinrank"):
            needed = {"record_id"}
            for q in self.queries.values():
                if q["dataset"] == dataset:
                    for cohort in q["contract"]["cohorts"]:
                        if "filter_ast" in cohort: needed.update(fields_in(cohort["filter_ast"]))
            rows = pq.read_table(self.core/f"data/cohorts/{dataset}_snapshot.parquet", columns=sorted(needed)).to_pylist()
            self.records[dataset] = {r["record_id"]: r for r in rows}
            require(len(rows) == len(self.records[dataset]), "Duplicate population row IDs")
            self.labels[dataset] = {}
            for path in sorted((self.core/"data/label_snapshots").glob(dataset+"__*.json")):
                snapshot = json.loads(path.read_text()); labels = snapshot["labels"]
                require(set(labels) == set(self.records[dataset]) and all(type(v) is int and v in (0,1) for v in labels.values()), "Incomplete binary snapshot")
                payload = {"predicate_id": snapshot["predicate_id"], "snapshot_hash": snapshot["snapshot_hash"],
                           "env": {k: snapshot.get("env", {}).get(k) for k in env_fields},
                           "labels": {k: labels[k] for k in sorted(labels)}}
                content_hash = hashlib.sha256(json.dumps(payload, ensure_ascii=False, sort_keys=True).encode()).hexdigest()
                require(content_hash == snapshot["content_hash"], "LabelSnapshot content hash failed")
                self.label_content_hashes[path.name] = content_hash
                self.labels[dataset][snapshot["predicate_id"]] = labels
            require(len(self.labels[dataset]) == 4, "Expected all four original source predicates")
        self.compiled = {qid: self.compile(q) for qid, q in self.queries.items()}
        self.contexts = {}

    def cohort(self, dataset, cohort):
        key = dataset, digest({k:v for k,v in cohort.items() if k != "label"})
        if key not in self.memberships:
            if "record_ids" in cohort:
                members = set(cohort["record_ids"])
                require(members <= set(self.records[dataset]), "Unknown explicit record ID")
            else:
                members = {rid for rid, row in self.records[dataset].items() if evaluate_ast(cohort["filter_ast"], row)}
            require(bool(members), "Empty active cohort")
            self.memberships[key] = members
        return self.memberships[key]

    def compile(self, query):
        contract, dataset = query["contract"], query["dataset"]
        used = set()
        for decision in contract["decisions"]:
            used.update((decision["left"], decision["right"]) if decision["type"] in ("compare", "direction", "equivalence") else decision["candidates"])
        cohorts = {c["id"]: self.cohort(dataset, c) for c in contract["cohorts"] if c["id"] in used}
        require(set(cohorts) == used, "Declared cohort mapping is incomplete")
        denominators = {g: len(ids) for g, ids in cohorts.items()}
        rows, atoms, witnesses, targets, types = [], [], [], [], []
        def atom(kind, threshold, left, right):
            pair = left, right
            if pair not in rows: rows.append(pair)
            index = len(atoms)
            atoms.append({"index":index,"kind":kind,"threshold":F(threshold),"row_index":rows.index(pair),"cohort_pair":pair})
            return index
        for di, decision in enumerate(contract["decisions"]):
            typ, start = decision["type"], len(witnesses); types.append(typ)
            if typ in ("compare", "direction"):
                witnesses.append([atom("lower", decision["threshold"], decision["left"], decision["right"])])
            elif typ == "equivalence":
                epsilon = F(decision["tolerance"])
                witnesses.append([atom("lower", -epsilon, decision["left"], decision["right"]), atom("upper", epsilon, decision["left"], decision["right"])])
            else:
                require(typ in ("top1", "topk"), "Unknown request decision")
                names = decision["candidates"]
                pairs = {(g,h): atom("lower", 0, g,h) for g in names for h in names if g != h}
                k = 1 if typ == "top1" else decision["k"]
                subsets = [decision["topk_set"]] if "topk_set" in decision else combinations(names,k)
                for subset in subsets:
                    chosen = set(subset)
                    witnesses.append([pairs[g,h] for g in names if g in chosen for h in names if h not in chosen])
            targets.extend([di]*(len(witnesses)-start))
        template = digest({"dataset": dataset, "cohorts": [{k:v for k,v in c.items() if k != "label"} for c in contract["cohorts"] if c["id"] in used], "rows": rows})
        if template not in self.templates:
            names = list(cohorts); signatures, groups = {}, {}
            union = set().union(*cohorts.values())
            for rid in sorted(union):
                pattern = tuple(rid in cohorts[g] for g in names)
                if pattern not in signatures:
                    membership = dict(zip(names, pattern))
                    signatures[pattern] = tuple(Fraction(int(membership[g]),denominators[g])-Fraction(int(membership[h]),denominators[h]) for g,h in rows)
                signature = signatures[pattern]
                if any(signature): groups.setdefault(signature, []).append(rid)
            support = sorted(rid for members in groups.values() for rid in members)
            self.templates[template] = {"groups":list(groups.items()), "support":support,
                                        "signature_by_record":{rid:sig for sig,members in groups.items() for rid in members}}
        return {"query":query,"dataset":dataset,"predicate":query["predicate_id"],"cohorts":cohorts,
                "denominators":denominators,"rows":rows,"atoms":atoms,"certificates":witnesses,"targets":targets,"types":types,
                "template":template,"structure":self.templates[template]}

    def truth(self, source, comp):
        labels = self.labels[comp["dataset"]][comp["predicate"]]
        means = {}
        for g, members in comp["cohorts"].items():
            key = comp["dataset"], comp["predicate"], digest(sorted(members))
            if key not in self.means: self.means[key] = Fraction(sum(labels[rid] for rid in members),len(members))
            means[g] = self.means[key]
        values = {a["index"]: means[a["cohort_pair"][0]]-means[a["cohort_pair"][1]] for a in comp["atoms"]}
        atoms = {a["index"]: values[a["index"]]>a["threshold"] if a["kind"] == "lower" else values[a["index"]]<a["threshold"] for a in comp["atoms"]}
        truths, selected = [], {}
        for di,d in enumerate(comp["query"]["contract"]["decisions"]):
            terms = [w for w,target in zip(comp["certificates"],comp["targets"]) if target == di]
            truths.append(any(all(atoms[j] for j in term) for term in terms))
            if d["type"] in ("top1","topk"):
                ordered = sorted(d["candidates"],key=lambda g:(-means[g],g)); k=1 if d["type"] == "top1" else d["k"]
                selected[di] = sorted(ordered[:k]) if means[ordered[k-1]]>means[ordered[k]] else None
        return means, values, atoms, truths, selected

    def context(self, comp, plan):
        key = comp["query"]["query_id"],plan["pilot_seed"],plan["formal_seed"],plan["budget_override"]
        if key not in self.contexts:
            support = comp["structure"]["support"]
            m = min(plan["pilot_cap"],len(support)//10,plan["budget_override"]//4)
            pilot = sorted(random.Random(plan["pilot_seed"]).sample(support,m))
            cells = self.cells(comp,pilot)
            rng, permutations = random.Random(plan["formal_seed"]), {}
            for cell in cells:
                permutation=list(cell["records"]);rng.shuffle(permutation);permutations[cell["cell_id"]]=permutation
            labels = self.labels[comp["dataset"]][comp["predicate"]]
            positives = {c["cell_id"]:sum(labels[rid] for rid in c["records"]) for c in cells}
            constants = [sum((comp["structure"]["signature_by_record"][rid][r]*labels[rid] for rid in pilot),Fraction()) for r in range(len(comp["rows"]))]
            self.contexts[key] = {"pilot":pilot,"cells":cells,"permutations":permutations,"positives":positives,"constants":constants}
        return self.contexts[key]


def exact_true_count_test(event, K):
    """Exact rational likelihood test at a known source count; no CS imported."""
    N,n,s = event["N"],event["n"],event["s"]
    a,b = int(event["a"]),int(event["b"])
    require(a==event["a"] and b==event["b"] and a>0 and b>0, "Noninteger prior shapes")
    require(s<=K<=N-n+s, "Source labels make their own true count infeasible")
    base = Fraction(1,(n+1)*math.comb(n,s))
    proxy = Fraction((a+b-1)*math.comb(a+b-2,a-1),(a+b+n-1)*math.comb(a+b+n-2,a+s-1))
    lam = F(event["lam"]); q = (1-lam)*base+lam*proxy
    p = Fraction(math.comb(K,s)*math.comb(N-K,n-s), math.comb(N,n)*math.comb(n,s))
    ratio = q/p; alpha = Fraction.from_float(float(event["alpha"]))
    return {"exact_M_times_alpha_ge_1":ratio*alpha>=1,"approx_log_M":math.log(ratio.numerator)-math.log(ratio.denominator),
            "nominal_log_threshold":-math.log(event["alpha"]),"ratio_numerator_bits":ratio.numerator.bit_length(),
            "ratio_denominator_bits":ratio.denominator.bit_length(),"ratio_approx":float(ratio),
            "classification":"exact_likelihood_threshold_crossing_at_true_source_count" if ratio*alpha>=1 else "exact_source_count_accepted_numerical_exclusion_requires_investigation"}


def propagate(comp, context, bounds):
    if any(v is None for v in bounds.values()): return None
    result = {}
    for atom in comp["atoms"]:
        r = atom["row_index"]; lo=hi=context["constants"][r]
        for cell in context["cells"]:
            a=cell["signature"][r]; l,u=bounds[cell["cell_id"]]
            lo+=a*(l if a>=0 else u);hi+=a*(u if a>=0 else l)
        result[str(atom["index"])]=[str(lo),str(hi)]
    return result


def audit_receipt(ref, payload, summary):
    qid, ds, method = payload["query_id"],payload["dataset"],payload["method"]
    comp, result = ref.compiled[qid],payload["result"]
    certificate, plan = result["certificate"],payload["plan"]
    labels=ref.labels[ds][comp["predicate"]];support=comp["structure"]["support"];cap=max(1,math.ceil(len(support)/2))
    require(certificate["support_size"]==len(support) and plan["budget_override"]==cap,"Support/cap mismatch")
    require(plan["semantics"]==("positive_only" if comp["query"]["kind"]=="ranking" else "bidirectional"),"Completion semantics changed")
    require(certificate["plan"]["settings"]==plan,"Raw/effective plan settings differ")
    bound_plan=deepcopy(certificate["plan"]);recorded=bound_plan.pop("execution_plan_sha256")
    require(digest(bound_plan)==recorded,"Execution plan hash mismatch")
    require(digest(certificate["family"])==certificate["plan"]["family_sha256"],"Family hash mismatch")
    contract=comp["query"]["contract"];effective=deepcopy(contract);effective["risk"]["alpha"]=.05;effective["budget"]["max_oracle_record_predicate_calls"]=cap
    require(digest(contract)==bound_plan["requested_contract_sha256"] and digest(effective)==bound_plan["effective_contract_sha256"],"Contract binding mismatch")
    reads=result["read_receipts"];read_ids=[rid for read in reads for rid in read["record_ids"]]
    calls=sum(read["submitted"] for read in reads)
    require(calls==certificate["semantic_calls"]==len(read_ids)<=cap and len(set(read_ids))==len(read_ids),"Read charges/uniqueness/cap mismatch")
    require(set(read_ids)<=set(support),"Record outside exact nonzero support")
    observed={}
    for read in reads:
        require(read["submitted"]==len(read["record_ids"]) and read["success"],"Unexpected failed/malformed saved-label batch")
        require(read["labels"]==[labels[rid] for rid in read["record_ids"]],"Returned label differs from source map")
        observed.update(zip(read["record_ids"],read["labels"]))
    require(observed==result["observed_labels"] and len(observed)==certificate["unique_successful_returns"],"Successful-return map mismatch")
    require(digest(list(observed))==certificate["sampled_ids_sha256"] and digest(observed)==certificate["successful_labels_sha256"],"Read/label fingerprint mismatch")
    context, first_noncoverage, noncovered_cells = None,None,set()
    if certificate["frozen"]:
        context=ref.context(comp,plan);frozen=certificate["frozen"]
        pilot=[rid for read in reads if read["phase"]=="pilot" for rid in read["record_ids"]]
        require(pilot==context["pilot"],"Pilot is not the recorded uniformly drawn prefix")
        require(digest(pilot)==frozen["pilot_ids_sha256"] and digest({rid:labels[rid] for rid in pilot})==frozen["pilot_labels_sha256"],"Pilot fingerprints differ")
        require(digest(context["permutations"])==frozen["permutations_sha256"],"Independent uniform permutations differ")
        partition=[(c["cell_id"],list(map(str,c["signature"])),0,c["records"]) for c in context["cells"]]
        require(digest(partition)==frozen["partition_sha256"] and len(partition)==certificate["cell_count"],"Independent one-bin partition differs")
        formal_reads=[rid for read in reads if read["phase"]=="formal" for rid in read["record_ids"]]
        require([rid for action in result["actions"] for rid in action["record_ids"]]==formal_reads,"Actions and actual formal reads differ")
        positions=defaultdict(int);positive_prefix=defaultdict(int);last={c["cell_id"]:(0,c["N"]) for c in context["cells"]};sticky=set();priors={};cell_by_id={c["cell_id"]:c for c in context["cells"]}
        event_position=0
        risk=Fraction(1,20)/len(context["cells"]);expected_risk=float(risk)
        if Fraction.from_float(expected_risk)>risk:expected_risk=math.nextafter(expected_risk,0.0)
        for action in result["actions"]:
            cid=action["cell_id"];cell=cell_by_id[cid];before=positions[cid];ids=action["record_ids"]
            require(action["prefix_before"]==before and action["prefix_after"]==before+len(ids),"Action cursor mismatch")
            require(ids==context["permutations"][cid][before:before+len(ids)] and action["labels"]==[labels[rid] for rid in ids],"Nonuniform cell-prefix action or wrong label")
            for rid in ids:
                event=result["cs_events"][event_position];event_position+=1
                positions[cid]+=1;positive_prefix[cid]+=labels[rid]
                require(event["cell_id"]==cid and event["N"]==cell["N"] and event["n"]==positions[cid] and event["s"]==positive_prefix[cid],"Per-record CS n/s/order mismatch")
                require(event["alpha"]==expected_risk and event["a"]+event["b"]==22 and event["lam"]==.5,"Risk/prior parameters changed")
                prior=(event["a"],event["b"],event["lam"],event["alpha"])
                require(cid not in priors or priors[cid]==prior,"Within-request frozen prior changed")
                priors[cid]=prior
                current=None if event["bounds"] is None else tuple(event["bounds"])
                require(cid not in sticky or event["inconsistent"] and current is None,"Inconsistency recovered")
                if event["inconsistent"]:sticky.add(cid);require(current is None,"Inconsistent cell emitted bounds")
                if current is not None:
                    require(last[cid] is not None and last[cid][0]<=current[0]<=current[1]<=last[cid][1],"CS is not a nested integer interval")
                    if event["n"]==cell["N"]:require(current==(event["s"],event["s"]),"Exhausted cell not exact")
                K=context["positives"][cid]
                if current is None or not current[0]<=K<=current[1]:
                    noncovered_cells.add(cid)
                    if first_noncoverage is None:
                        first_noncoverage={"cell_id":cid,"true_count":K,"event":event,"record_id":rid,
                                           "formal_prefix_ids":context["permutations"][cid][:event["n"]],
                                           "exact_test":exact_true_count_test(event,K)}
                last[cid]=current
            require(action["bounds"]==list(last[cid]) if last[cid] is not None else action["bounds"] is None,"Action terminal bounds differ from final per-record event")
        require(event_position==len(result["cs_events"]),"CS receipt has missing/extra updates")
        propagated=propagate(comp,context,last)
        require(propagated==certificate["contrast_intervals"],"Terminal contrast interval differs from independent exact cell propagation")
        if len(priors)==len(context["cells"]):
            prior_payload=[(c["cell_id"],*priors[c["cell_id"]]) for c in context["cells"]]
            require(digest(prior_payload)==frozen["priors_sha256"],"Prior fingerprint differs from all recorded cell parameters")
    verdict=ref.verdict(ds,comp,certificate)
    comparisons={"correct_complete":verdict["correct_complete"],"correct_complete_vector_only":verdict["correct_complete_vector_only"],
                 "source_error":verdict["source_error"],"wrong_true_claims":len(verdict["wrong_true_claims"]),"wrong_false_claims":len(verdict["wrong_false_claims"]),
                 "source_proof_errors":len(verdict["source_invalid_proofs"]),"terminal_source_noncoverage_atoms":len(verdict["terminal_source_noncoverage_atoms"]),
                 "semantic_calls":calls,"support_size":len(support),"budget":cap,
                 "conservative_cap_charge":cap if verdict["source_error"] or certificate["status"]=="execution_error" else calls}
    for key,value in comparisons.items():
        require(summary[key]==str(value),"Saved CSV field differs from independent audit: "+key)
    require(abs(float(summary["calls_per_support"])-calls/len(support))<1e-12,"Normalized cost differs")
    record={"dataset":ds,"query_id":qid,"predicate":comp["predicate"],"kind":comp["query"]["kind"],"method":method,
            "seed_id":payload["seed"]["seed_id"],"status":certificate["status"],**comparisons,
            "source_cell_noncoverage":bool(noncovered_cells),"source_cell_noncoverage_cells":len(noncovered_cells),
            "calls_per_support":calls/len(support),"conservative_calls_per_support":comparisons["conservative_cap_charge"]/len(support)}
    adverse=None
    if first_noncoverage or verdict["source_error"] or certificate["status"]=="execution_error":
        adverse={**record,"first_source_cell_noncoverage":first_noncoverage,"verdict":verdict,
                 "terminal_intervals":certificate["contrast_intervals"],"decisions":certificate["decisions"],"reason":certificate["reason"]}
    return record,adverse


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument("--manifest",type=Path,default=ROOT/"legacy_replication_v1/full_grid_v1/manifest.json");p.add_argument("--out",type=Path,default=HERE/"audit_v1")
    args=p.parse_args();require(sha(args.manifest)==EXPECTED_MANIFEST,"Wrong immutable replication manifest")
    manifest=json.loads(args.manifest.read_text())
    inputs={**manifest["source_sha256"],**manifest["input_sha256"]}
    for path,expected in inputs.items():require(sha(path)==expected,"Changed frozen source/input: "+path)
    args.out.mkdir(exist_ok=False,parents=True)
    forbidden=lambda:[name for name in sys.modules if name=="engine" or name=="query" or name.startswith(("engine.","query.","executor_v2"))]
    require(not forbidden(),"Forbidden runtime module imported before independent audit")
    ref=GenericReference(manifest)
    result_dir=args.manifest.parent/"results"
    raw_identities={};row_keys=set();paired={};records=[];adverse_count=0;discrepancies=[];shard_reports=[];started=time.monotonic()
    with gzip.open(args.out/"adverse_cases.jsonl.gz","xt",encoding="utf-8",compresslevel=1) as adverse_stream:
        for shard in manifest["shards"]:
            table=result_dir/(shard["name"]+".csv");raw=result_dir/(shard["name"]+".jsonl.gz")
            raw_identities[str(table)]=sha(table);raw_identities[str(raw)]=sha(raw)
            summaries=list(csv.DictReader(table.open(newline="")))
            require(len(summaries)==len(shard["query_ids"]),"CSV shard row count mismatch")
            raw_count=0
            with gzip.open(raw,"rt",encoding="utf-8") as stream:
                for line,summary in zip(stream,summaries):
                    raw_count+=1;encoded=line.rstrip("\n");payload=json.loads(encoded)
                    try:
                        require(hashlib.sha256(encoded.encode()).hexdigest()==summary["raw_record_sha256"],"Raw row content hash mismatch")
                        require(payload["manifest_sha256"]==EXPECTED_MANIFEST and payload["failure"] is None,"Raw row lacks matching successful manifest binding")
                        require(payload["dataset"]==shard["dataset"] and payload["method"]==shard["method"] and payload["seed"]==shard["seed"],"Shard identity changed")
                        qid=payload["query_id"];require(qid==shard["query_ids"][raw_count-1]==summary["query_id"],"Query order/key mismatch")
                        key=payload["dataset"],qid,payload["method"],payload["seed"]["seed_id"]
                        require(key not in row_keys,"Duplicate run key");row_keys.add(key)
                        require(payload["plan"]["pilot_seed"]==int(payload["seed"]["pilot_seed"]) and payload["plan"]["formal_seed"]==int(payload["seed"]["formal_seed"]),"Pilot/formal seed mismatch")
                        require(payload["plan"]["exploration_seed"]==int(digest(["legacy-exploration-v1",str(payload["seed"]["exploration_seed"]),qid]),16),"Exploration substream mismatch")
                        record,adverse=audit_receipt(ref,payload,summary);records.append(record)
                        identity=tuple(payload["result"]["certificate"]["frozen"].get(k,"") for k in ("pilot_ids_sha256","pilot_labels_sha256","scores_sha256","partition_sha256","priors_sha256","permutations_sha256"))
                        paired_key=payload["dataset"],qid,payload["seed"]["seed_id"]
                        require(paired_key not in paired or paired[paired_key]==identity,"Between-method frozen identities differ");paired[paired_key]=identity
                        if adverse:adverse_stream.write(json.dumps(adverse,default=str,separators=(",",":"))+"\n");adverse_count+=1
                    except Exception as exc:
                        discrepancies.append({"shard":shard["name"],"row":raw_count,"query_id":payload.get("query_id"),"error":repr(exc),"traceback":traceback.format_exc()})
                require(not stream.readline(),"Extra raw JSONL rows")
            require(raw_count==len(summaries),"Raw shard ended before CSV")
            shard_reports.append({"name":shard["name"],"rows":raw_count,"discrepancies_so_far":len(discrepancies)})
            temp=args.out/"progress.tmp.json";temp.write_text(json.dumps({"shards":len(shard_reports),"rows":len(records),"discrepancies":len(discrepancies)}));temp.replace(args.out/"progress.json")
            print(json.dumps(shard_reports[-1]),flush=True)
    require(not forbidden(),"Forbidden runtime/compiler module imported during audit")
    summary=[]
    for dataset in ("cfpb","opinrank"):
        for method in ("matched","dual_greedy","forecast"):
            units=[r for r in records if r["dataset"]==dataset and r["method"]==method]
            summary.append({"dataset":dataset,"method":method,"units":len(units),"correct_complete":sum(r["correct_complete"] for r in units),
                            "source_error":sum(r["source_error"] for r in units),"wrong_true_claims":sum(r["wrong_true_claims"] for r in units),"wrong_false_claims":sum(r["wrong_false_claims"] for r in units),
                            "source_invalid_proofs":sum(r["source_proof_errors"] for r in units),"execution_errors":sum(r["status"]=="execution_error" for r in units),
                            "terminal_noncoverage_records":sum(r["terminal_source_noncoverage_atoms"]>0 for r in units),"cell_noncoverage_records":sum(r["source_cell_noncoverage"] for r in units),
                            "mean_calls_per_support":sum(r["calls_per_support"] for r in units)/len(units) if units else None,
                            "mean_conservative_calls_per_support":sum(r["conservative_calls_per_support"] for r in units)/len(units) if units else None})
    for path,expected in {**inputs,**raw_identities}.items():require(sha(path)==expected,"Source/result mutated during read-only audit: "+path)
    report={"status":"passed" if not discrepancies and len(records)==9600 else "discrepancies_found","manifest_sha256":EXPECTED_MANIFEST,
            "checked_rows":len(records),"unique_run_keys":len(row_keys),"expected_rows":9600,"checked_raw_and_csv_file_hashes":raw_identities,
            "input_source_hash_count":len(inputs),"paired_units":len(paired),"adverse_records":adverse_count,"discrepancies":discrepancies,
            "summary":summary,"label_snapshot_content_hashes":ref.label_content_hashes,"elapsed_seconds":time.monotonic()-started,
            "independence":{"generic_metadata_AST":True,"direct_source_cohort_means":True,"independent_coefficient_cells_and_uniform_prefixes":True,
                            "per_record_n_s_and_nested_sticky_bounds":True,"terminal_exact_propagation":True,"executor_or_compiler_imports":forbidden(),
                            "interval_proof_methods_reused_from":str(REFERENCE),"interval_proof_reference_sha256":sha(REFERENCE),
                            "proxy_scores_not_recomputed":True,"scope":"Opaque score hashes checked for cross-method equality; recorded priors checked against events and hashes when all cells visited; no policy rerun"},
            "limitations":"Post-hoc original saved labels, upstream operator unpinned, no human validation of eight predicates, changed v2 completion/kernel. Cell/source failures across methods may be the same prefix event and are not independent risk trials."}
    write(args.out/"AUDIT_REPORT.json",report)
    if records:
        with (args.out/"checked_rows.csv").open("x",newline="") as f:
            writer=csv.DictWriter(f,fieldnames=list(records[0]));writer.writeheader();writer.writerows(records)
    print(json.dumps({"status":report["status"],"checked_rows":len(records),"discrepancies":len(discrepancies),"summary":summary},indent=2))


if __name__=="__main__":main()
