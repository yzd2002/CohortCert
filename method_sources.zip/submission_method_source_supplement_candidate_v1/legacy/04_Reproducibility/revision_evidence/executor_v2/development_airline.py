"""Post-hoc development ONLY on the already examined airline population.

Does not access CivilComments labels, model outputs, or acquisition outcomes.
It checks the new runtime and planner before the prospective policy freeze.
"""
import csv
import hashlib
from dataclasses import asdict
from fractions import Fraction
import json
import math
from pathlib import Path
import sys
import time

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from executor_v2.execution import Plan, execute
from executor_v2.baseline_policies import MatchedLeastSampled, DualGreedy
from executor_v2.frontier_policy import ForecastFrontierPolicy
from common import core_module


def main():
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--airline', type=Path, required=True)
    parser.add_argument('--core-root', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--queries', nargs='+', default=['airline-0000', 'airline-0090', 'airline-0150', 'airline-0233'])
    parser.add_argument('--replan-steps', type=int, default=4)
    parser.add_argument('--methods', nargs='+', choices=['matched', 'dual_greedy', 'forecast'],
                        default=['matched', 'dual_greedy', 'forecast'])
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=False)
    paths = [HERE/name for name in ['execution.py','state.py','dual_certificate.py',
                                    'baseline_policies.py','frontier_policy.py','development_airline.py']]
    paths.extend([HERE.parent/'theory_design/certificate_frontier.py',
                  HERE.parent/'system_design/request_repairs.py', HERE.parent/'system_design/common.py'])
    (args.out/'development_manifest.json').write_text(json.dumps({
        'scope':'Post-hoc existing-data development, not prospective performance evidence',
        'replan_steps':args.replan_steps,'methods':args.methods,'query_ids':args.queries,
        'source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}},indent=2)+'\n')
    queries = [json.loads(line) for line in (args.airline/'queries.jsonl').read_text().splitlines()]
    queries = [q for q in queries if q['query_id'] in args.queries]
    labels = json.loads((args.airline/'human_labels.json').read_text())
    snapshot = core_module(args.core_root, 'query.parquet_snapshot').ParquetSnapshot(
        args.airline/'data/cohorts/airline_snapshot.parquet')
    compiler = core_module(args.core_root, 'query.compiler')
    proxy = core_module(args.core_root, 'engine.proxy').EmbeddingLRProxy(
        'airline', args.airline/'data/embeddings')
    class Replay:
        def read(self, ids): return {rid: int(labels[rid]) for rid in ids}
    summary, bound_checks = [], 0
    for query in queries:
        matrix, _ = compiler.compile_signed_decisions(query['contract'], snapshot)
        support = len({rid for row in matrix.rows for rid, value in row.items() if value})
        cap = math.ceil(.5*support)
        policies = {'matched': MatchedLeastSampled, 'dual_greedy': DualGreedy,
                    'forecast': lambda: ForecastFrontierPolicy(seed=394572, replan_steps=args.replan_steps)}
        for name in args.methods:
            policy = policies[name]()
            def observe(state, verdict):
                nonlocal bound_checks
                for atom in state.family.atoms:
                    lower = upper = state.pilot_constants.get(atom.row_index, Fraction(0))
                    for cell in state.cells:
                        coefficient = cell.coefficients[atom.row_index]
                        lower += coefficient * (cell.lower if coefficient >= 0 else cell.upper)
                        upper += coefficient * (cell.upper if coefficient >= 0 else cell.lower)
                    assert state.bounds[atom.index] == (lower, upper)
                    bound_checks += 1
            result = execute(query['contract'], snapshot, Replay(), proxy, policy,
                             Plan(0, 1273546630, 62735241, budget_override=cap),
                             core_root=args.core_root, observer=observe,
                             policy_spec={'name': name, 'development': True,
                                          'replan_steps':args.replan_steps if name=='forecast' else None})
            cert = result['certificate']
            if cert['framework_exception']:
                (args.out/'failed_result.json').write_text(json.dumps(result, default=str, indent=2)+'\n')
                raise RuntimeError(cert['framework_exception'])
            assert cert['semantic_calls'] <= cap
            policy_actions = [a for a in result['actions'] if a['source']=='policy']
            diagnostics = [a['diagnostics'] or {} for a in policy_actions]
            row = {'query_id': query['query_id'], 'policy': name, 'status': cert['status'],
                   'calls': cert['semantic_calls'], 'cap': cap,
                   'resolved': cert['resolved_judgments'], 'declared': cert['declared_judgments'],
                   'values': [d['value'] for d in cert['decisions']],
                   'wall_ms': result['total']['wall_ms'], 'cells': cert['cell_count'],
                   'policy_actions': len(policy_actions),
                   'forecast_verified_plans': sum(d.get('exact_incumbent_verified') is True for d in diagnostics),
                   'forecast_reused_plans': sum(d.get('reused_allocation') is True for d in diagnostics),
                   'fallback_actions': sum(bool(d.get('fallback_reason')) for d in diagnostics),
                   'planning_wall_ms': sum(d.get('planning_wall_ms',0) for d in diagnostics),
                   'scope': 'Post-hoc development, not prospective performance evidence'}
            summary.append(row)
            (args.out/f'{query["query_id"]}_{name}.json').write_text(json.dumps(result, default=str)+'\n')
            print(json.dumps(row), flush=True)
    report={'status':'passed','runs':len(summary),'direct_fraction_pushforward_checks':bound_checks,
            'scope':'Existing airline data only; prospective labels remain sealed','summary':summary}
    (args.out/'development_completion.json').write_text(json.dumps(report,indent=2)+'\n')


if __name__ == '__main__': main()
