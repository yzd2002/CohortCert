"""Finite, independently checked execution/contract/receipt probes."""
import itertools
import json
from fractions import Fraction
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from executor_v2.execution import Plan, execute
import executor_v2.execution as execution_module
from executor_v2.state import Choice

CORE = Path('/dev/shm/CohortCert_fixed_label_replay_20261031')
sys.path.insert(0, str(CORE))
from query.snapshot import MemorySnapshot


class Replay:
    def __init__(self, labels):
        self.labels, self.calls = labels, []
    def read(self, ids):
        self.calls.extend(ids)
        return {rid: self.labels[rid] for rid in ids}


class Least:
    def choose(self, state):
        cell = min((c for c in state.cells if c.n < c.N), key=lambda c: (c.n, c.cell_id))
        return Choice(cell.cell_id, state.batch_size)


def contract(decisions, cohorts, budget=64):
    return {'snapshot_id': 'synthetic_v1', 'predicate_id': 'synthetic_v1', 'cohorts': cohorts,
            'population_scope': 'Eight fixed synthetic records',
            'decisions': decisions, 'risk': {'alpha': .05, 'scope': 'this_request'},
            'budget': {'max_oracle_record_predicate_calls': budget}}


def main():
    ids = [f'r{i}' for i in range(8)]
    snapshot = MemorySnapshot({rid: {'text': ''} for rid in ids})
    a, b, c = ids[:5], ids[2:], ids[::2]
    cohorts = [{'id': name, 'record_ids': members} for name, members in [('a', a), ('b', b), ('c', c)]]
    decisions = [{'type': 'compare', 'left': 'a', 'right': 'b', 'threshold': 0,
                  'unit': 'proportion_difference'},
                 {'type': 'equivalence', 'left': 'a', 'right': 'c', 'tolerance': .2,
                  'unit': 'proportion_difference'}]
    request = contract(decisions, cohorts, len(ids))
    runs = covered = errors = noncoverage = 0
    for bits in itertools.product((0, 1), repeat=8):
        labels = dict(zip(ids, bits)); oracle = Replay(labels)
        result = execute(request, snapshot, oracle, None, Least(),
                         Plan(2, 987631, 52911, pilot_cap=0, tiny_scan_max=0,
                              initial_batch=1, batch_size=2), core_root=CORE)
        cert = result['certificate']; assert cert['framework_exception'] is None
        assert cert['semantic_calls'] == len(oracle.calls) <= len(ids)
        assert len(set(oracle.calls)) == len(oracle.calls)
        cell_of = {}
        for action in result['actions']:
            assert action['prefix_after'] - action['prefix_before'] == len(action['record_ids'])
            for rid in action['record_ids']:
                cell_of[rid] = action['cell_id']
        # Full source labels are used only by this post-execution observer.
        # Reconstruct coefficient-cell memberships directly from cohort means.
        signature = {}
        for rid in ids:
            signature[rid] = (Fraction(rid in a, len(a)) - Fraction(rid in b, len(b)),
                              Fraction(rid in a, len(a)) - Fraction(rid in c, len(c)))
        groups = {}
        for rid in ids: groups.setdefault(signature[rid], []).append(rid)
        # Frozen cells use sorted active IDs and insertion order of signatures.
        actual_counts = {i: sum(labels[rid] for rid in members)
                         for i, members in enumerate(groups.values())}
        coverage = all(event['bounds'] is not None and
                       event['bounds'][0] <= actual_counts[event['cell_id']] <= event['bounds'][1]
                       for event in result['cs_events'])
        if cert['status'] == 'execution_error': errors += 1
        else:
            means = {name: sum(Fraction(labels[rid], len(members)) for rid in members)
                     for name, members in [('a', a), ('b', b), ('c', c)]}
            direct = [means['a'] > means['b'], abs(means['a'] - means['c']) < Fraction(1, 5)]
            if coverage:
                for emitted, truth in zip(cert['decisions'], direct):
                    assert emitted['value'] is None or emitted['value'] == truth
                covered += 1
        noncoverage += not coverage
        runs += 1
    # Exact zero-support judgments require no backend calls.
    same = [{'id': 'a', 'record_ids': ids}, {'id': 'b', 'record_ids': ids}]
    for decision, expected in [(decisions[0], False),
                               ({'type': 'equivalence', 'left': 'a', 'right': 'b',
                                 'tolerance': .2, 'unit': 'proportion_difference'}, True)]:
        o = Replay(dict.fromkeys(ids, 0))
        r = execute(contract([decision], same), snapshot, o, None, Least(),
                    Plan(1, 2, 3), core_root=CORE)['certificate']
        assert r['status'] == 'complete' and r['semantic_calls'] == 0
        assert r['decisions'][0]['value'] is expected
    # A failed submitted batch is retained/charged once and never reread.
    class Failed:
        def __init__(self): self.requests = []
        def read(self, requested): self.requests.append(list(requested)); raise RuntimeError('fixture_failure')
    failed = Failed()
    r = execute(request, snapshot, failed, None, Least(),
                Plan(1, 2, 3, tiny_scan_max=0), core_root=CORE)['certificate']
    assert r['status'] == 'execution_error' and r['semantic_calls'] == len(failed.requests[0])
    assert len(failed.requests) == 1 and r['framework_exception'] is None
    # State exposes no future record IDs, permutations, labels, or oracle object.
    observed = []
    execute(request, snapshot, Replay(dict(zip(ids, [0, 1]*4))), None, Least(),
            Plan(1, 2, 3, tiny_scan_max=0, initial_batch=1, batch_size=1), core_root=CORE,
            observer=lambda state, _: observed.append(set(vars(state))))
    assert observed and not any({'oracle', 'permutations', 'record_ids', 'labels'} & x for x in observed)
    # Observers receive a defensive verdict copy; render/verification failures
    # still return their actual charged counts rather than escaping the API.
    def mutate_observer(state, verdict):
        verdict['complete'] = True
        verdict['decisions'].clear()
    retained = execute(request, snapshot, Replay(dict(zip(ids, [0, 1]*4))), None, Least(),
                       Plan(1, 2, 3, tiny_scan_max=0), core_root=CORE, observer=mutate_observer)
    assert retained['certificate']['framework_exception'] is None
    old_verify = execution_module.verify
    def fail_verification(*args, **kwargs): raise RuntimeError('injected_verifier_failure')
    try:
        execution_module.verify = fail_verification
        retained = execute(request, snapshot, Replay(dict(zip(ids, [0, 1]*4))), None, Least(),
                           Plan(1, 2, 3, tiny_scan_max=0), core_root=CORE)
    finally:
        execution_module.verify = old_verify
    assert retained['certificate']['reason'] == 'certificate_render_failure'
    assert retained['certificate']['semantic_calls'] > 0 and not retained['certificate']['decisions']
    assert retained['certificate']['framework_exception']['class'] == 'RuntimeError'
    record = {'status': 'passed', 'exhaustive_eight_record_label_worlds': runs,
              'coverage_event_nonerror_decision_checks': covered,
              'realized_source_noncoverage_worlds': noncoverage, 'execution_errors_retained': errors,
              'zero_support_probes': 2, 'failed_batch_once': True, 'read_only_interface': True,
              'observer_copy_isolation': True, 'failed_render_retains_actual_charges': True,
              'scope': 'Finite synthetic execution; source noncoverage is retained, not assumed impossible.'}
    (HERE/'execution_validation.json').write_text(json.dumps(record, indent=2)+'\n')
    print(json.dumps(record, indent=2))


if __name__ == '__main__': main()
