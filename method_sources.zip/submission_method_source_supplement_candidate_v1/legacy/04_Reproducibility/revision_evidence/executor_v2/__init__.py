"""Separate research executor; historical evaluated sources remain immutable."""
