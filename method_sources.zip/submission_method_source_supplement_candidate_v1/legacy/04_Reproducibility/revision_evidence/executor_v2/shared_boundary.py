"""LUCB-inspired relative-boundary allocation for unequal overlapping groups.

This is a component adaptation, not canonical LUCB and not an optimal policy.
It uses only AcquisitionState. The common executor owns initialization,
exploration, actual reads, inference, and strict ranking identification.

For the lexicographically first group o, define theta_hat(o)=0 and
theta_hat(g)=c_(g,o)+sum_h a_(g,o),h N_h s_h/n_h. All residual cells must already
be initialized. Group-relative intervals are the actual contrast intervals
for (g,o); the anchor has [0,0]. Order groups by theta_hat, choose the empirical
top k, then its smallest relative lower bound h and the outside group's largest
relative upper bound l. Advance the cell maximizing
  |a_(h,l),c| [v_c-v_pred(c,b)] / [b * unit_cost_c],
where b=min(common batch, remaining calls, N_c-n_c) and the ordinary finite-
population width forecast is shared with other controls. This DIRECT contrast
can depend on any cell, including cells containing the anchor or multiple
groups. Signed coefficients already encode overlap and unequal denominators.
No attempt is made to assign one cell to one cohort or to recover absolute
cohort means. The reference origin is a scheduling choice, not an inferential
assumption. Relative-boundary selection can be conservative or inefficient.

Plug-in potentials, their coherence checks and boundary ordering use exact
Fractions. Width forecasts/gain-per-cost use Python float64 solely for
scheduling. Gain ties within 1e-12*max(1,abs(best)) choose the smallest cell ID;
nonpositive gain chooses largest population N, then smallest ID. Returned batch
is always the common nominal batch; forecast/pricing use its actual clipped
size. Invalid/unsupported single-decision ranking shapes fall back explicitly
to DualGreedy and retain the fallback reason. No new state fields or labels,
record IDs, model draws, or future permutation positions are accessed.

`python -B shared_boundary.py --self-test` checks finite synthetic OVERLAP
states against an independent direct cohort calculation. It opens no corpus,
target map, or model and writes no files.
"""
from __future__ import annotations

from fractions import Fraction
from functools import lru_cache
import itertools
import math

try:
    from .state import Choice
    from .dual_certificate import evaluate
    from .baseline_policies import DualGreedy
except ImportError:
    from state import Choice
    from dual_certificate import evaluate
    from baseline_policies import DualGreedy


def _fraction(value):
    return value if isinstance(value, Fraction) else Fraction(str(value))


@lru_cache(maxsize=128)
def _shape(family):
    if len(family.decision_types) != 1 or family.decision_types[0] not in ("top1", "topk"):
        raise ValueError("one ordinary ranking decision is required")
    atoms = tuple(family.atoms)
    if not atoms or any(a.kind != "lower" or _fraction(a.threshold) != 0 or len(a.cohort_pair) != 2 for a in atoms):
        raise ValueError("ranking must use strict zero-margin group contrasts")
    groups = tuple(sorted({g for atom in atoms for g in atom.cohort_pair}))
    if len(groups) < 2 or not all(isinstance(g, str) for g in groups):
        raise ValueError("ranking requires distinct string group IDs")
    pair_atoms = {tuple(atom.cohort_pair): atom for atom in atoms}
    if len(pair_atoms) != len(atoms) or set(pair_atoms) != {(g, h) for g in groups for h in groups if g != h}:
        raise ValueError("every ordered group pair must occur once")
    if len(family.certificate_decisions) != len(family.certificates) or any(d != 0 for d in family.certificate_decisions):
        raise ValueError("witnesses must belong to the single ranking decision")
    by_id = {atom.index: atom for atom in atoms}
    if len(by_id) != len(atoms):
        raise ValueError("duplicate atom IDs")
    subsets = []
    for witness in family.certificates:
        pairs = [tuple(by_id[j].cohort_pair) for j in witness]
        left, right = frozenset(g for g, _ in pairs), frozenset(h for _, h in pairs)
        if not left or right != set(groups)-left or len(pairs) != len(set(pairs)) or set(pairs) != {(g, h) for g in left for h in right}:
            raise ValueError("witness is not one complete top-k crossing")
        subsets.append(left)
    if not subsets or len({len(subset) for subset in subsets}) != 1:
        raise ValueError("ranking witnesses do not determine k")
    k = len(subsets[0])
    if len(subsets) != len(set(subsets)) or set(subsets) != {frozenset(s) for s in itertools.combinations(groups, k)}:
        raise ValueError("all ordinary candidate top-k sets are required")
    if family.decision_types[0] == "top1" and k != 1:
        raise ValueError("top1 witness cardinality mismatch")
    return groups, pair_atoms, k


class SharedBoundaryPolicy:
    def __init__(self, fallback=None, tie_tolerance=1e-12):
        self.fallback = DualGreedy() if fallback is None else fallback
        self.tie_tolerance = float(tie_tolerance)
        if not math.isfinite(self.tie_tolerance) or self.tie_tolerance < 0:
            raise ValueError("tie tolerance must be finite and nonnegative")

    def _analyze(self, state):
        groups, pair_atoms, k = _shape(state.family)
        if state.batch_size <= 0 or state.remaining_calls < 0:
            raise ValueError("invalid common batch or remaining cap")
        if len({c.cell_id for c in state.cells}) != len(state.cells):
            raise ValueError("duplicate cell IDs")
        anchor = groups[0]
        relative_coefficients, estimates, intervals = {}, {anchor: Fraction(0)}, {anchor: (Fraction(0), Fraction(0))}
        for cell in state.cells:
            if not 0 <= cell.n <= cell.N or not 0 <= cell.s <= cell.n or not 0 <= cell.lower <= cell.upper <= cell.N:
                raise ValueError("invalid revealed cell state")
            if cell.N > 0 and cell.n == 0:
                raise ValueError("common post-initialization state is required")
        for group in groups:
            if group == anchor:
                relative_coefficients[group] = tuple(Fraction(0) for _ in state.cells)
                continue
            atom = pair_atoms[group, anchor]
            coefficients = tuple(_fraction(c.coefficients[atom.row_index]) for c in state.cells)
            relative_coefficients[group] = coefficients
            estimate = _fraction(state.pilot_constants.get(atom.row_index, 0))
            for coefficient, cell in zip(coefficients, state.cells):
                if cell.N:
                    estimate += coefficient*cell.N*Fraction(cell.s, cell.n)
            estimates[group] = estimate
            bounds = state.bounds.get(atom.index)
            if bounds is None:
                raise ValueError("relative contrast has no valid interval")
            lower, upper = map(_fraction, bounds)
            if lower > upper:
                raise ValueError("reversed relative interval")
            intervals[group] = lower, upper
        # Ordinary rank rows are differences of the same relative potentials.
        # Check this using public coefficients/constants, not cohort identities
        # or hidden memberships. It allows arbitrary overlap signatures.
        origin_constants = {anchor: Fraction(0), **{
            g: _fraction(state.pilot_constants.get(pair_atoms[g, anchor].row_index, 0)) for g in groups if g != anchor}}
        for (g, h), atom in pair_atoms.items():
            constant = _fraction(state.pilot_constants.get(atom.row_index, 0))
            if constant != origin_constants[g]-origin_constants[h]:
                raise ValueError("pilot constants lack coherent relative group potentials")
            lower = upper = constant
            for i, cell in enumerate(state.cells):
                coefficient = _fraction(cell.coefficients[atom.row_index])
                if coefficient != relative_coefficients[g][i]-relative_coefficients[h][i]:
                    raise ValueError("coefficient rows lack coherent relative group potentials")
                lower += coefficient*(cell.lower if coefficient >= 0 else cell.upper)
                upper += coefficient*(cell.upper if coefficient >= 0 else cell.lower)
            observed = state.bounds.get(atom.index)
            if observed is None or tuple(map(_fraction, observed)) != (lower, upper):
                raise ValueError("supplied contrast bounds differ from exact signed cell propagation")
        order = sorted(groups, key=lambda g: (-estimates[g], g))
        inside, outside = order[:k], order[k:]
        weakest = min(inside, key=lambda g: (intervals[g][0], g))
        strongest = min(outside, key=lambda g: (-intervals[g][1], g))
        target = pair_atoms[weakest, strongest]
        candidates = []
        for cell in sorted(state.cells, key=lambda c: c.cell_id):
            if cell.n >= cell.N or state.remaining_calls <= 0:
                continue
            batch = min(state.batch_size, state.remaining_calls, cell.N-cell.n)
            cost = state.unit_costs.get(cell.cell_id, 1.0)
            if isinstance(cost, bool) or not math.isfinite(float(cost)) or float(cost) <= 0:
                raise ValueError("unit cost must be finite and positive")
            if cell.n+batch >= cell.N:
                reduction = float(cell.width)
            else:
                factor = math.sqrt(cell.n*(cell.N-cell.n-batch)/((cell.n+batch)*(cell.N-cell.n)))
                reduction = float(cell.width)*(1.0-factor)
            coefficient = abs(float(cell.coefficients[target.row_index]))
            gain = coefficient*reduction
            score = gain/(batch*float(cost))
            if not math.isfinite(score):
                raise ValueError("nonfinite direct-contrast gain/cost")
            candidates.append({"cell": cell, "effective_batch": batch, "width_reduction": reduction,
                               "absolute_coefficient": coefficient, "predicted_contrast_width_gain": gain,
                               "gain_per_cost": score})
        return {"anchor": anchor, "k": k, "estimates": estimates, "intervals": intervals,
                "inside": inside, "weakest_inside": weakest, "strongest_outside": strongest,
                "target_atom": target.index, "target_pair": [weakest, strongest], "candidates": candidates}

    def score_candidates(self, state):
        result = self._analyze(state)
        return {**{key: value for key, value in result.items() if key != "candidates"},
                "candidates": [{"cell_id": value["cell"].cell_id,
                                **{k: v for k, v in value.items() if k != "cell"}} for value in result["candidates"]]}

    def choose(self, state):
        if state.remaining_calls <= 0 or not any(c.n < c.N for c in state.cells):
            return Choice(-1, 0, {"policy": "shared_relative_boundary_v1", "reason": "no_available_calls_or_cells"})
        if evaluate(state.family, state.bounds, mode=state.semantics)["complete"]:
            return Choice(-1, 0, {"policy": "shared_relative_boundary_v1", "reason": "already_identified"})
        try:
            result = self._analyze(state)
        except (ValueError, IndexError, KeyError, ZeroDivisionError, TypeError) as exc:
            choice = self.fallback.choose(state)
            return Choice(choice.cell_id, choice.batch,
                          {**dict(choice.diagnostics or {}), "requested_policy": "shared_relative_boundary_v1",
                           "boundary_fallback": str(exc)})
        best = max(item["gain_per_cost"] for item in result["candidates"])
        if best > 0:
            tolerance = self.tie_tolerance*max(1., abs(best))
            eligible = [item for item in result["candidates"] if item["gain_per_cost"] >= best-tolerance]
            chosen = min(eligible, key=lambda item: item["cell"].cell_id)
            reason = "maximum_direct_boundary_contrast_width_gain_per_cost"
        else:
            chosen = min(result["candidates"], key=lambda item: (-item["cell"].N, item["cell"].cell_id))
            reason = "zero_boundary_gain_largest_population"
        diagnostics = {"policy": "shared_relative_boundary_v1", "reason": reason,
                       "scope": "LUCB-inspired relative-boundary adaptation; no canonical LUCB/optimality claim",
                       "anchor": result["anchor"], "k": result["k"], "empirical_inside": result["inside"],
                       "weakest_inside": result["weakest_inside"], "strongest_outside": result["strongest_outside"],
                       "target_pair": result["target_pair"], "target_atom": result["target_atom"],
                       "gain_per_cost": chosen["gain_per_cost"], "effective_batch": chosen["effective_batch"],
                       "relative_estimates": {g: str(v) for g, v in result["estimates"].items()},
                       "relative_intervals": {g: list(map(str, v)) for g, v in result["intervals"].items()},
                       "active_cells_considered": len(result["candidates"]), "tie_tolerance": self.tie_tolerance}
        return Choice(chosen["cell"].cell_id, state.batch_size, diagnostics)


def run_self_tests():
    """Independent synthetic overlap potential/score checks, no corpus reads."""
    import random
    from types import MappingProxyType
    try:
        from .state import AcquisitionState, AtomView, CellView, FamilyView
    except ImportError:
        from state import AcquisitionState, AtomView, CellView, FamilyView
    groups = ("a", "b", "c")
    patterns = tuple(range(1, 8))
    populations = (61, 89, 38, 47, 27, 59, 35)
    # Each membership signature also contributes two pilot records, of which
    # one is positive. These values exist ONLY in the test, never the policy.
    sizes = [sum(N+2 for pattern, N in zip(patterns, populations) if pattern & (1 << g)) for g in range(3)]
    pilot_positive = [sum(1 for pattern in patterns if pattern & (1 << g)) for g in range(3)]
    atoms, pair_index = [], {}
    for g in groups:
        for h in groups:
            if g != h:
                j = len(atoms); pair_index[g, h] = j
                atoms.append(AtomView(j, "lower", Fraction(0), j, str(j), (g, h)))
    rng, policy, dual = random.Random(268471), SharedBoundaryPolicy(), DualGreedy()
    checked, score_checks, different, anchor_reads, overlapping_reads, fallbacks = 0, 0, 0, 0, 0, 0
    for k in (1, 2):
        witnesses = []
        for subset in itertools.combinations(groups, k):
            witnesses.append(tuple(pair_index[g, h] for g in groups if g in subset for h in groups if h not in subset))
        family = FamilyView(tuple(atoms), tuple(witnesses), tuple(0 for _ in witnesses), ("top1" if k == 1 else "topk",))
        for case in range(64):
            cells, actual_counts = [], []
            for cid, (pattern, N) in enumerate(zip(patterns, populations)):
                n = rng.randrange(8, 20); s = rng.randrange(0, n+1)
                lower = s+(N-n)//5
                upper = s+4*(N-n)//5
                coefficients = tuple((Fraction(1, sizes[groups.index(a.cohort_pair[0])]) if pattern & (1 << groups.index(a.cohort_pair[0])) else Fraction(0))-
                                     (Fraction(1, sizes[groups.index(a.cohort_pair[1])]) if pattern & (1 << groups.index(a.cohort_pair[1])) else Fraction(0)) for a in atoms)
                cells.append(CellView(cid, N, n, s, lower, upper, .01, 1., 1., .5, coefficients))
                actual_counts.append((lower+upper)//2)
            constants = {a.row_index: Fraction(pilot_positive[groups.index(a.cohort_pair[0])], sizes[groups.index(a.cohort_pair[0])])-
                          Fraction(pilot_positive[groups.index(a.cohort_pair[1])], sizes[groups.index(a.cohort_pair[1])]) for a in atoms}
            bounds = {}
            for a in atoms:
                lower = upper = constants[a.row_index]
                for c in cells:
                    coefficient = c.coefficients[a.row_index]
                    lower += coefficient*(c.lower if coefficient >= 0 else c.upper)
                    upper += coefficient*(c.upper if coefficient >= 0 else c.lower)
                bounds[a.index] = lower, upper
            costs = {cid: (1., 1.5, .75)[cid % 3] for cid in range(7)}
            state = AcquisitionState(tuple(cells), family, MappingProxyType(bounds), MappingProxyType(constants),
                                     (7, 16, 100)[case % 3], 9, 16, "positive_only", MappingProxyType(costs))
            before = repr(state)
            scored, selected = policy.score_candidates(state), policy.choose(state)
            assert not selected.diagnostics.get("boundary_fallback")
            absolute_estimates = []
            source_means = []
            for gi in range(3):
                estimate = Fraction(pilot_positive[gi], sizes[gi])
                source = Fraction(pilot_positive[gi], sizes[gi])
                for pattern, c, actual in zip(patterns, cells, actual_counts):
                    if pattern & (1 << gi):
                        estimate += Fraction(c.N*c.s, c.n*sizes[gi])
                        source += Fraction(actual, sizes[gi])
                absolute_estimates.append(estimate); source_means.append(source)
            for gi, group in enumerate(groups):
                assert scored["estimates"][group] == absolute_estimates[gi]-absolute_estimates[0]
            for atom in atoms:
                gi, hi = map(groups.index, atom.cohort_pair)
                direct = constants[atom.row_index]+sum((c.coefficients[atom.row_index]*c.N*Fraction(c.s, c.n) for c in cells), Fraction(0))
                assert direct == absolute_estimates[gi]-absolute_estimates[hi]
                assert bounds[atom.index][0] <= source_means[gi]-source_means[hi] <= bounds[atom.index][1]
            target = atoms[scored["target_atom"]]
            direct_scores = {}
            for c in cells:
                b = min(16, state.remaining_calls, c.N-c.n)
                future = 0.0 if c.n+b == c.N else float(c.upper-c.lower)*math.sqrt((c.n/(c.n+b))*((c.N-c.n-b)/(c.N-c.n)))
                direct_scores[c.cell_id] = abs(float(c.coefficients[target.row_index]))*(float(c.upper-c.lower)-future)/(b*costs[c.cell_id])
            for item in scored["candidates"]:
                assert math.isclose(item["gain_per_cost"], direct_scores[item["cell_id"]], rel_tol=1e-12, abs_tol=1e-14)
                score_checks += 1
            best = max(direct_scores.values()); tol = 1e-12*max(1., abs(best))
            expected = min(cid for cid, value in direct_scores.items() if value >= best-tol)
            assert selected.cell_id == expected and selected.batch == 16
            different += selected.cell_id != dual.choose(state).cell_id
            anchor_reads += bool(patterns[selected.cell_id] & 1)
            overlapping_reads += patterns[selected.cell_id].bit_count() > 1
            assert repr(state) == before
            checked += 1
    assert different > 0 and anchor_reads > 0 and overlapping_reads > 0
    # Multiple declared judgments and explicit target sets are not silently
    # presented as this single ordinary-ranking control.
    from dataclasses import replace
    mixed = replace(state, family=replace(state.family, decision_types=("topk", "compare")))
    assert policy.choose(mixed).diagnostics.get("boundary_fallback")
    return {"status": "passed", "synthetic_overlap_states": checked, "independent_candidate_score_checks": score_checks,
            "different_cell_from_dual_greedy": different, "selected_anchor_containing_cell": anchor_reads,
            "selected_multi_group_cell": overlapping_reads, "explicit_structural_fallback_probe": True,
            "exact_relative_potential_and_source_interval_checks": True, "state_unchanged": True,
            "scope": "Finite synthetic unequal-overlap arithmetic checks, not performance dominance or optimality; no targets/model opened"}


if __name__ == "__main__":
    import argparse
    import json
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--self-test", action="store_true")
    args = p.parse_args()
    if not args.self_test:
        p.error("Only --self-test is executable")
    print(json.dumps(run_self_tests(), indent=2))
