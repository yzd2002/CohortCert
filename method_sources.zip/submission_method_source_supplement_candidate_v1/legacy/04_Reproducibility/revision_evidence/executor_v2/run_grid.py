#!/usr/bin/env python3
"""Frozen saved-label grid runner; DEFAULT IS METADATA-ONLY DRY RUN.

No target map is opened, hashed, globbed, or stat'ed in dry-run mode. No GPU or
model loading route exists. A separate explicit freeze hashes provided target
map files without deriving outcomes; execute verifies that immutable manifest
before interpreting maps. No extra approval mechanism is imposed by this tool.
The caller is responsible for authorizing the explicit freeze/execute commands.

Civil defaults: all 528 preserved contracts, 10 recorded pilot/formal/planning/
exploration seed records, cap50, matched/dual_greedy/forecast, human+model sources:
31,680 runs. The 464 non-ranking requests are primary bidirectional judgments;
64 rankings are secondary positive_only strict identification (ties unresolved).
Optional boundary runs are ranking-only: 1,280 additional runs for two sources.
Other caps/positive_only sensitivities require their own fresh frozen manifest.

Typical commands, from any working directory:
  python -B run_grid.py --workspace /PATH/natural_overlap
  python -B run_grid.py --mode freeze --workspace /PATH/natural_overlap \
    --labels-dir human=/PATH/source_reference_labels \
    --labels-dir model=/PATH/qwen_four_predicate_labels --out /NEW/grid50
  python -B run_grid.py --mode execute --manifest /NEW/grid50/run_manifest.json \
    --expect-manifest-sha256 HASH

Explicit paths override directory patterns, e.g.
  --label-map human:toxicity=/PATH/human_toxicity.json
  --label-map model:toxicity=/PATH/model_toxicity.json
Repeat for all required maps. Directory patterns match the frozen builders:
human_labels_{predicate}_v1.json; {predicate}/model_labels_{predicate}_v1.json.
--label-paths accepts a JSON index {source:{predicate:"path/to/map.json"}}, not
a target map. In dry-run that optional index is metadata; indexed maps are not
touched. Relative index paths resolve relative to the index file.

Per source/method/seed/cap shard: a compact CSV plus gzip JSONL retaining the
complete certificate, actions, per-record CS events, read IDs/labels and
independent post-execution rational truth/proof checks. Raw files use exclusive
creation. Atomic progress is the only intentionally replaced output. There is
no silent resume or overwrite. Framework/invariant failures stop new requests;
already running requests finish and every partial shard is retained. Alpha
events (wrong source conclusions/proofs, terminal source noncoverage, sticky CS
inconsistency) are retained without stopping the grid.

All inference/policy calls finish before full-reference truth evaluation.
Policies receive only AcquisitionState through execution.execute. The separate
reference evaluator derives means and witnesses directly from the contract and
metadata sets, without the compiler, executor, or dual checker. Reference truth
is never used to select/filter queries or supplied to the policy. CPU replay
wall time is not live model query latency; no new forwards are claimed.
"""
from __future__ import annotations

import argparse
from collections import Counter
from concurrent.futures import ProcessPoolExecutor, wait, FIRST_COMPLETED
from copy import deepcopy
from dataclasses import asdict
from datetime import datetime, timezone
from fractions import Fraction
import csv
import gzip
import hashlib
import importlib.metadata
import itertools
import json
import math
import multiprocessing as mp
import os
from pathlib import Path
import sys
import time
import traceback

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parent
if str(PROJECT) not in sys.path:
    sys.path.insert(0, str(PROJECT))
if str(PROJECT / "system_design") not in sys.path:
    sys.path.insert(0, str(PROJECT / "system_design"))

from common import core_module, digest, file_hash
from executor_v2.execution import Plan, execute

VERSION = "cohortcert.saved-label-grid.v2"
PROTOCOL_NAME = "protocol_hcap256_scenario_seeds_before_annotation_access.json"
PREDICATES = ("toxicity", "insult", "identity_attack", "obscene")
METHODS = ("matched", "dual_greedy", "forecast", "boundary")
THREAD_ENV = {"OMP_NUM_THREADS": "1", "OPENBLAS_NUM_THREADS": "1", "MKL_NUM_THREADS": "1",
              "NUMEXPR_NUM_THREADS": "1", "VECLIB_MAXIMUM_THREADS": "1", "PYTHONHASHSEED": "0"}
DEFAULT_FORECAST = {"grid_points": 6, "time_limit": .05, "replan_steps": 8,
                    "max_wall_seconds": .15, "max_cells": 256}
CSV_FIELDS = [
    "run_key", "run_manifest_sha256", "source", "method", "query_id", "predicate", "kind", "summary_subtype", "family_scope",
    "semantics", "seed_id", "pilot_seed", "formal_seed", "planning_seed", "exploration_seed",
    "budget_share", "budget", "support_size", "requested_bins", "actual_cells", "alpha",
    "status", "reason", "outcome", "reported_complete", "correct_complete", "correct_complete_vector_only",
    "declared_judgments", "resolved_judgments", "truth_vector", "answer_vector", "wrong_true_claims",
    "wrong_false_claims", "partial_wrong_claims", "source_proof_errors", "source_error",
    "terminal_source_noncoverage_atoms", "semantic_calls", "calls_per_support", "conservative_cap_charge",
    "executor_wall_ms", "executor_cpu_ms", "policy_build_wall_ms", "reference_evaluation_wall_ms",
    "policy_actions", "fallback_actions", "verified_planning_actions", "planning_wall_ms",
    "allocation_sources", "proxy_fallback", "execution_plan_sha256", "pilot_ids_sha256",
    "pilot_labels_sha256", "scores_sha256", "partition_sha256", "priors_sha256", "permutations_sha256",
    "framework_exception", "invariants_valid", "raw_record_sha256",
]
_WORKER = {}


class InvariantFailure(RuntimeError):
    pass


def utc():
    return datetime.now(timezone.utc).isoformat()


def require(condition, message):
    if not condition:
        raise InvariantFailure(message)


def absolute(path):
    # This is lexical path handling, deliberately no Path.resolve/stat on maps.
    return os.path.abspath(os.path.expanduser(os.fspath(path)))


def encode(value):
    def default(obj):
        if isinstance(obj, (Fraction, Path)):
            return str(obj)
        if hasattr(obj, "item"):
            return obj.item()
        raise TypeError(f"Unserializable receipt value: {type(obj).__name__}")
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"),
                      allow_nan=False, default=default)


def new_json(path, value):
    with Path(path).open("x", encoding="utf-8") as stream:
        stream.write(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False)+"\n")
        stream.flush(); os.fsync(stream.fileno())


def atomic_json(path, value):
    path = Path(path)
    temporary = path.with_name(path.name+f".tmp.{os.getpid()}")
    with temporary.open("w", encoding="utf-8") as stream:
        stream.write(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False)+"\n")
        stream.flush(); os.fsync(stream.fileno())
    os.replace(temporary, path)


def load_queries(path):
    queries = [json.loads(line) for line in Path(path).read_text().splitlines() if line.strip()]
    ids = [q["query_id"] for q in queries]
    require(len(ids) == len(set(ids)), "Duplicate query IDs")
    return sorted(queries, key=lambda q: q["query_id"])


def predicate_column(query):
    candidates = [p for p in PREDICATES if query["predicate_id"] == f"civilcomments_{p}_v1"]
    require(len(candidates) == 1 and query["contract"]["predicate_id"] == query["predicate_id"],
            "Unrecognized or mismatched pinned predicate ID")
    return candidates[0]


def seed_records(protocol):
    paired = {int(s["seed_id"]): dict(s) for s in protocol["seed_pairs"]}
    extra = {int(s["seed_id"]): s for s in protocol["planning_exploration_seed_amendment"]["seed_pairs"]}
    require(set(paired) == set(extra) == set(range(10)), "Exactly the ten recorded four-stream seed records are required")
    records = []
    for sid in sorted(paired):
        record = {"seed_id": sid, **{name: str(int((paired[sid] if name in paired[sid] else extra[sid])[name]))
                                    for name in ("pilot_seed", "formal_seed", "planning_seed", "exploration_seed")}}
        records.append(record)
    all_values = [record[k] for record in records for k in ("pilot_seed", "formal_seed", "planning_seed", "exploration_seed")]
    require(len(all_values) == len(set(all_values)), "The forty recorded random streams must be distinct")
    return records


def substream(base, namespace, query_id):
    return int(digest([namespace, str(base), query_id]), 16)


def label_paths(args, sources):
    directories, explicit = {}, {}
    for entry in args.labels_dir or []:
        name, separator, path = entry.partition("=")
        if separator:
            require(name in ("human", "model"), "--labels-dir prefix must be human= or model=")
            require(name not in directories, "Repeated label directory authority")
            directories[name] = absolute(path)
        else:
            for source in sources:
                require(source not in directories, "Repeated label directory authority")
                directories[source] = absolute(entry)
    if args.label_paths:
        index_path = Path(args.label_paths)
        index = json.loads(index_path.read_text())
        require(isinstance(index, dict) and set(index) <= {"human", "model"}, "Label path index must map source -> predicate -> path")
        for source, mapping in index.items():
            require(isinstance(mapping, dict) and set(mapping) <= set(PREDICATES), "Unknown predicate in path index")
            for pred, value in mapping.items():
                require(isinstance(value, str), "Path index contains a target value instead of a filename")
                explicit[source, pred] = absolute(index_path.parent / value)
    for entry in args.label_map or []:
        key, separator, value = entry.partition("=")
        source, colon, pred = key.partition(":")
        require(separator and colon and source in ("human", "model") and pred in PREDICATES,
                "--label-map must be SOURCE:PREDICATE=PATH")
        require((source, pred) not in explicit, "Repeated explicit label-map authority")
        explicit[source, pred] = absolute(value)
    result = {}
    for source in sources:
        result[source] = {}
        for pred in PREDICATES:
            if (source, pred) in explicit:
                result[source][pred] = explicit[source, pred]
            elif source in directories:
                relative = f"human_labels_{pred}_v1.json" if source == "human" else f"{pred}/model_labels_{pred}_v1.json"
                result[source][pred] = absolute(Path(directories[source]) / relative)
            else:
                result[source][pred] = None
    return result


def runtime_sources(core):
    code = [HERE/name for name in ("run_grid.py", "execution.py", "state.py", "dual_certificate.py",
                                  "baseline_policies.py", "frontier_policy.py", "shared_boundary.py")]
    code += [PROJECT/"theory_design/certificate_frontier.py", PROJECT/"system_design/common.py",
             PROJECT/"system_design/request_repairs.py"]
    code += [p for d in ("engine", "query") for p in sorted((Path(core)/d).rglob("*.py"))]
    require(all(p.is_file() for p in code), "A runtime dependency source file is missing")
    return {absolute(p): file_hash(p) for p in code}


def prepare(args):
    workspace = Path(args.workspace or PROJECT/"natural_overlap").resolve()
    core = Path(args.core_root or "/dev/shm/CohortCert_fixed_label_replay_20261031").resolve()
    paths = {"protocol": absolute(args.protocol or workspace/PROTOCOL_NAME),
             "queries": absolute(args.queries or workspace/"queries_before_annotation_access.jsonl"),
             "snapshot": absolute(args.snapshot or workspace/"metadata_only_snapshot.parquet"),
             "metadata_cells": absolute(args.metadata_cells or workspace/"metadata_coefficient_cells.jsonl"),
             "features": absolute(Path(args.embeddings or workspace/"data/embeddings")/"civilcomments_emb.npy"),
             "feature_index": absolute(Path(args.embeddings or workspace/"data/embeddings")/"civilcomments_index.parquet")}
    protocol = json.loads(Path(paths["protocol"]).read_text())
    queries = load_queries(paths["queries"])
    require(len(queries) == protocol["query_design"]["total_queries"] == 528, "Retain all 528 fixed Civil contracts")
    require(Counter(q["kind"] for q in queries) == {"pairwise": 224, "equivalence": 112, "summary": 128, "ranking": 64},
            "Original query family counts changed")
    require(file_hash(paths["queries"]) == protocol["queries_sha256"], "Queries changed after metadata-only freeze")
    for q in queries:
        predicate_column(q)
    metadata = [json.loads(line) for line in Path(paths["metadata_cells"]).read_text().splitlines() if line]
    by_id = {row["query_id"]: row for row in metadata}
    require(len(by_id) == len(metadata) == len(queries) and set(by_id) == {q["query_id"] for q in queries},
            "Metadata-only support table does not match all fixed queries")
    query_metadata = []
    for q in queries:
        row = by_id[q["query_id"]]
        require(row["kind"] == q["kind"] and row["predicate_id"] == q["predicate_id"], "Support metadata key mismatch")
        require(type(row["support_size"]) is int and row["support_size"] > 0, "Invalid metadata support size")
        query_metadata.append({"query_id": q["query_id"], "kind": q["kind"], "predicate": predicate_column(q),
                               "summary_subtype": row.get("summary_subtype"), "support_size": row["support_size"],
                               "H_b1_before_pilot": row["coefficient_cell_count_b1"],
                               "contract_sha256": digest(q["contract"])})
    sources = args.source or ["human", "model"]
    methods = args.methods or ["matched", "dual_greedy", "forecast"]
    caps = args.caps or [50]
    require(len(sources) == len(set(sources)) and len(methods) == len(set(methods)) and len(caps) == len(set(caps)),
            "Do not repeat sources, methods or caps")
    require(all(0 < cap <= 100 and math.isfinite(cap) for cap in caps), "Caps are percentages in (0,100]")
    require(all(cap in protocol["budget_shares"] for cap in caps), "Cap was not declared in the base protocol")
    workers = 20 if args.workers is None else args.workers
    require(type(workers) is int and 1 <= workers <= 20, "Use between 1 and 20 worker processes")
    common = {"alpha_override": float(protocol["alpha"]), "requested_bins": args.bins or 1,
              "max_cells": int(protocol["metadata_only_Hcap_amendment"]["max_cells"]),
              "pilot_cap": 256, "initial_batch": 8, "batch_size": 16, "explore_every": 4,
              "prior_weight": .5, "prior_strength": 20, "tiny_scan_max": 128}
    forecast = dict(DEFAULT_FORECAST)
    for key in forecast:
        value = getattr(args, "forecast_"+key)
        if value is not None:
            forecast[key] = value
    semantics = args.semantics or "bidirectional"
    ranking_semantics = args.ranking_semantics or "positive_only"
    seeds = seed_records(protocol)
    shards = []
    for source, method, seed, cap in itertools.product(sources, methods, seeds, caps):
        eligible = [q for q in query_metadata if method != "boundary" or q["kind"] == "ranking"]
        name = f'{source}__{method}__seed{seed["seed_id"]:02d}__cap{str(cap).replace(".","p")}'
        shards.append({"name": name, "source": source, "method": method, "seed_id": seed["seed_id"],
                       "budget_share": cap, "query_ids": [q["query_id"] for q in eligible],
                       "expected_rows": len(eligible), "order_key": digest([VERSION, "shard-order", name])})
    shards.sort(key=lambda shard: shard["order_key"])
    dependencies = runtime_sources(core)
    inputs = {name: {"path": path, "sha256": file_hash(path)} for name, path in paths.items()}
    if args.label_paths:
        inputs["label_path_index"] = {"path": absolute(args.label_paths), "sha256": file_hash(args.label_paths)}
    counts = Counter()
    for shard in shards:
        eligible = [q for q in query_metadata if q["query_id"] in set(shard["query_ids"])]
        counts["all_runs"] += len(eligible)
        counts["primary_nonranking_runs"] += sum(q["kind"] != "ranking" for q in eligible)
        counts["secondary_ranking_runs"] += sum(q["kind"] == "ranking" for q in eligible)
        counts["maximum_charged_calls"] += sum(max(1, min(q["support_size"], math.ceil(shard["budget_share"]*q["support_size"]/100))) for q in eligible)
    manifest = {"version": VERSION, "created_utc": utc(), "status": "metadata_only_plan",
                "measurement": "fixed-label CPU acquisition replay; no new model forwards or live model query latency",
                "workspace": str(workspace), "core_root": str(core), "dataset_feature_prefix": "civilcomments",
                "inputs": inputs, "source_sha256": dependencies,
                "labels": label_paths(args, sources), "label_sha256": None,
                "dry_run_map_access": "No target-map stat, open, glob, hash or value interpretation",
                "seed_records": seeds,
                "substreams": {"planning": "SHA256([cohortcert-v2-planning-request-v1, recorded planning seed, query_id])",
                               "exploration": "SHA256([cohortcert-v2-exploration-request-v1, recorded exploration seed, query_id])",
                               "sharing": "Same per-request substream across methods, sources, caps and completion sensitivities; never derived from formal seeds"},
                "common_plan": common, "forecast": forecast, "dual_greedy": {"gamma": 1., "epsilon": 1e-4},
                "methods": methods, "sources": sources, "caps": caps,
                "nonranking_semantics": semantics, "ranking_semantics": ranking_semantics,
                "family_scope": {"primary": "464 non-ranking queries, all exact Boolean judgments; no certifiability filter",
                                 "secondary": "64 rankings, strict identification with ties unresolved in positive_only"},
                "phase": "primary50" if caps == [50] and semantics == "bidirectional" else "separately_frozen_sensitivity",
                "query_metadata": query_metadata, "shards": shards, "counts": dict(counts),
                "worker_count": workers, "thread_environment": THREAD_ENV,
                "packages": {name: importlib.metadata.version(name) for name in
                             ("numpy", "scipy", "scikit-learn", "pyarrow", "pandas", "threadpoolctl")},
                "evaluation": "Independent full-label rational evaluation only after execute returns. Source errors/partial wrong claims retained; framework/invariant failures stop.",
                "output": {"summary": "one CSV per source/method/seed/cap", "raw": "gzip JSONL compresslevel1; complete unabridged engine result + independent audit",
                           "overwrite": "No overwrites or implicit resumes. Only atomic progress replaces earlier progress.",
                           "serialization": "Compact strict JSON; nonfinite values are framework errors, never silently deleted"}}
    return manifest


def freeze(args, manifest):
    require(args.out is not None, "--out must name a new freeze directory")
    label_hashes = {}
    for source, mapping in manifest["labels"].items():
        label_hashes[source] = {}
        for pred, path in mapping.items():
            require(path is not None, f"Provide --labels-dir or --label-map for {source}:{pred}")
            label_hashes[source][pred] = file_hash(path)  # Bytes only; no outcomes or prevalence.
    out = Path(args.out).resolve()
    out.mkdir(parents=True, exist_ok=False)
    manifest["status"], manifest["label_sha256"] = "frozen_before_grid_execution", label_hashes
    manifest["freeze_note"] = "Target maps hashed for immutable identity; no target values interpreted and no grid executed by freezing"
    path = out/"run_manifest.json"
    new_json(path, manifest)
    print(json.dumps({"status": manifest["status"], "manifest": str(path), "sha256": file_hash(path),
                      "counts": manifest["counts"], "grid_runs_launched": 0}, indent=2))


def independent_family(contract):
    """Derive contract witnesses directly, with no acquisition-engine imports."""
    atoms, witnesses, mapping, types, row_numbers = [], [], [], [], {}
    def add(kind, threshold, left, right):
        pair = (left, right)
        if pair not in row_numbers:
            row_numbers[pair] = len(row_numbers)
        index = len(atoms)
        atoms.append({"index": index, "kind": kind, "threshold": str(Fraction(str(threshold))),
                      "row_index": row_numbers[pair], "cohort_pair": [left, right]})
        return index
    for di, decision in enumerate(contract["decisions"]):
        typ, start = decision["type"], len(witnesses)
        types.append(typ)
        if typ in ("compare", "direction"):
            witnesses.append([add("lower", decision["threshold"], decision["left"], decision["right"])])
        elif typ == "equivalence":
            epsilon = Fraction(str(decision["tolerance"]))
            witnesses.append([add("lower", -epsilon, decision["left"], decision["right"]),
                              add("upper", epsilon, decision["left"], decision["right"])])
        elif typ in ("top1", "topk"):
            candidates = decision["candidates"]
            pair_atoms = {(g, h): add("lower", 0, g, h) for g in candidates for h in candidates if g != h}
            k = 1 if typ == "top1" else decision["k"]
            subsets = [tuple(decision["topk_set"])] if "topk_set" in decision else itertools.combinations(candidates, k)
            for subset in subsets:
                chosen = set(subset)
                witnesses.append([pair_atoms[g, h] for g in candidates if g in chosen for h in candidates if h not in chosen])
        else:
            raise InvariantFailure("Unsupported reference decision type: "+str(typ))
        mapping.extend([di]*(len(witnesses)-start))
    return {"atoms": atoms, "certificates": witnesses, "certificate_decisions": mapping, "decision_types": types}


def interval_atom_state(atom, interval):
    if interval is None:
        return None
    lower, upper = map(Fraction, interval)
    require(lower <= upper, "Reversed terminal interval")
    threshold = Fraction(atom["threshold"])
    if atom["kind"] == "lower":
        return True if lower > threshold else False if upper <= threshold else None
    return True if upper < threshold else False if lower >= threshold else None


def reference_evaluation(contract, snapshot, labels, certificate, means_cache=None):
    """Called after execute; full-reference means, Boolean vectors and proofs."""
    means_cache = {} if means_cache is None else means_cache
    means = {}
    for cohort in contract["cohorts"]:
        key = digest(cohort)
        if key not in means_cache:
            ids = snapshot.cohort_records(cohort)
            require(bool(ids), "Empty reference cohort")
            means_cache[key] = Fraction(sum(labels[rid] for rid in ids), len(ids))
        means[cohort["id"]] = means_cache[key]
    family = independent_family(contract)
    # Conjunction order has no semantics. The historical compiler iterates a
    # Python set within top-k witnesses; accept only that harmless reordering,
    # retaining witness indices and decision assignments for proof validation.
    emitted_family = deepcopy(certificate["family"])
    emitted_family["certificates"] = [sorted(term) for term in emitted_family["certificates"]]
    expected_family = deepcopy(family)
    expected_family["certificates"] = [sorted(term) for term in expected_family["certificates"]]
    require(encode(emitted_family) == encode(expected_family), "Emitted witness family differs from the independent contract derivation")
    values, truths = {}, {}
    for atom in family["atoms"]:
        left, right = atom["cohort_pair"]
        value, threshold = means[left]-means[right], Fraction(atom["threshold"])
        values[atom["index"]] = value
        truths[atom["index"]] = value > threshold if atom["kind"] == "lower" else value < threshold
    truth_vector = []
    expected_sets = {}
    for di, decision in enumerate(contract["decisions"]):
        terms = [family["certificates"][i] for i, d in enumerate(family["certificate_decisions"]) if d == di]
        truth_vector.append(any(all(truths[j] for j in term) for term in terms))
        if decision["type"] in ("top1", "topk"):
            candidates = decision["candidates"]
            k = 1 if decision["type"] == "top1" else decision["k"]
            ordered = sorted(candidates, key=lambda g: (-means[g], g))
            if means[ordered[k-1]] > means[ordered[k]]:
                expected_sets[di] = sorted(ordered[:k])
    require(certificate["declared_judgments"] == len(truth_vector), "Declared-judgment count differs from the contract")
    intervals = certificate.get("contrast_intervals")
    interval_states = {atom["index"]: interval_atom_state(atom, None if intervals is None else intervals.get(str(atom["index"])))
                       for atom in family["atoms"]}
    noncoverage = [aid for aid, value in values.items() if intervals is not None and intervals.get(str(aid)) is not None
                   and not Fraction(intervals[str(aid)][0]) <= value <= Fraction(intervals[str(aid)][1])]
    supplied = certificate.get("decisions", [])
    by_decision = {item["decision"]: item for item in supplied}
    require(len(by_decision) == len(supplied) and set(by_decision) <= set(range(len(truth_vector))), "Duplicate/unknown emitted decision")
    if certificate["status"] != "execution_error":
        require(set(by_decision) == set(range(len(truth_vector))), "Non-error response omitted declared judgments")
    wrong_true, wrong_false, source_proof_errors, answers, checks = [], [], [], [], []
    for di, truth in enumerate(truth_vector):
        item = by_decision.get(di, {"value": None, "positive_certificate": None, "negative_cover": []})
        answer = item["value"]
        require(answer is None or type(answer) is bool, "Decision value must be true/false/null")
        answers.append(answer)
        terms = [i for i, d in enumerate(family["certificate_decisions"]) if d == di]
        positive_terminal = [i for i in terms if all(interval_states[j] is True for j in family["certificates"][i])]
        negative_terminal = all(any(interval_states[j] is False for j in family["certificates"][i]) for i in terms)
        negative_allowed = certificate["semantics"] == "bidirectional" and family["decision_types"][di] not in ("top1", "topk")
        expected_terminal = True if positive_terminal else False if negative_allowed and negative_terminal else None
        if certificate["status"] != "execution_error":
            require(answer is expected_terminal, "Emitted answer is not justified by its exact terminal intervals")
        bad_source_proofs = []
        if answer is True:
            wi = item.get("positive_certificate")
            require(type(wi) is int and wi in terms, "Positive witness belongs to another decision")
            require(all(interval_states[j] is True for j in family["certificates"][wi]), "Positive proof contradicts terminal intervals")
            bad_source_proofs = [j for j in family["certificates"][wi] if not truths[j]]
            wrong_selected = family["decision_types"][di] in ("top1", "topk") and item.get("selected_cohorts") != expected_sets.get(di)
            if not truth or wrong_selected:
                wrong_true.append(di)
        elif answer is False:
            cover = item.get("negative_cover", [])
            covered = [part["certificate"] for part in cover]
            require(len(covered) == len(set(covered)) and set(covered) == set(terms), "Negative proof does not hit every positive witness exactly once")
            for part in cover:
                wi, aid = part["certificate"], part["atom"]
                require(aid in family["certificates"][wi] and interval_states[aid] is False, "Negative hit is not an interval-false atom in its witness")
                if truths[aid]:
                    bad_source_proofs.append(aid)
            if truth:
                wrong_false.append(di)
        else:
            require(item.get("positive_certificate") is None and not item.get("negative_cover"), "Unresolved judgment carries a proof")
        if bad_source_proofs:
            source_proof_errors.append({"decision": di, "atom_ids": sorted(set(bad_source_proofs))})
        checks.append({"decision": di, "source_truth": truth, "answer": answer,
                       "source_proof_wrong_atoms": sorted(set(bad_source_proofs))})
    all_resolved = all(value is not None for value in answers)
    require(certificate["resolved_judgments"] == sum(value is not None for value in answers), "Resolved-judgment count mismatch")
    require(certificate["status"] != "complete" or all_resolved, "Claimed completion omitted a judgment")
    vector_correct = all_resolved and not wrong_true and not wrong_false
    correct_complete = certificate["status"] == "complete" and vector_correct and not source_proof_errors
    return {"truth_vector": truth_vector, "answer_vector": answers, "per_decision": checks,
            "cohort_means": {g: str(value) for g, value in means.items()},
            "atomic_reference_values": {str(j): str(v) for j, v in values.items()},
            "wrong_true_claims": wrong_true, "wrong_false_claims": wrong_false,
            "source_proof_errors": source_proof_errors, "terminal_source_noncoverage_atoms": noncoverage,
            "terminal_reference_atoms_assessed": sum(intervals is not None and intervals.get(str(aid)) is not None for aid in values),
            "correct_complete": bool(correct_complete),
            "correct_complete_vector_only": bool(certificate["status"] == "complete" and vector_correct),
            "partial_wrong_claims": len(wrong_true)+len(wrong_false),
            "source_error": bool(wrong_true or wrong_false or source_proof_errors), "invariants_valid": True}


class SealedReplay:
    """The only oracle handle passed to execute; policies never receive it."""
    def __init__(self, labels, population_ids, budget):
        self.__labels = labels
        self.__population = population_ids
        self.budget, self.attempted, self.receipts, self.invariant_failure = budget, [], [], None

    def read(self, ids):
        ids = list(ids)
        try:
            require(len(ids) == len(set(ids)) and not set(ids).intersection(self.attempted), "Independent oracle detects duplicate requests")
            require(set(ids) <= self.__population, "Independent oracle detects a record outside the frozen population")
            require(len(self.attempted)+len(ids) <= self.budget, "Independent oracle detects cap overrun")
            self.attempted.extend(ids)
            raw = {rid: self.__labels[rid] for rid in ids}
            self.receipts.append({"record_ids": ids, "labels": [raw[rid] for rid in ids]})
            return raw
        except Exception as exc:
            self.invariant_failure = repr(exc)
            raise


def result_invariants(result, oracle, expected_support, budget):
    certificate = result["certificate"]
    require(not oracle.invariant_failure, "Independent oracle invariant failed: "+str(oracle.invariant_failure))
    require(certificate["support_size"] == expected_support, "Executed support differs from frozen metadata-only support")
    require(certificate["semantic_calls"] == len(oracle.attempted) <= budget, "Charged calls disagree with independent attempts/cap")
    receipts = result["read_receipts"]
    require(sum(r["submitted"] for r in receipts) == certificate["semantic_calls"], "Read receipts do not sum to charges")
    require([rid for r in receipts for rid in r["record_ids"]] == oracle.attempted, "Executor/independent read-ID order differs")
    observed = result["observed_labels"]
    require(len(observed) == certificate["unique_successful_returns"] and set(observed) <= set(oracle.attempted), "Successful-return ledger mismatch")
    require(digest(list(observed)) == certificate["sampled_ids_sha256"] and digest(observed) == certificate["successful_labels_sha256"], "Returned label/read fingerprint mismatch")
    plan = dict(certificate["plan"])
    recorded_hash = plan.pop("execution_plan_sha256")
    require(digest(plan) == recorded_hash, "Execution plan hash is invalid")
    require(digest(certificate["family"]) == certificate["plan"]["family_sha256"], "Serialized family differs from its bound execution-plan identity")
    return True


def verify_frozen_files(manifest):
    for path, expected in manifest["source_sha256"].items():
        require(file_hash(path) == expected, "Runtime source changed after freeze: "+path)
    for entry in manifest["inputs"].values():
        require(file_hash(entry["path"]) == entry["sha256"], "Metadata/feature input changed after freeze: "+entry["path"])
    for name, expected in manifest["packages"].items():
        require(importlib.metadata.version(name) == expected, "Runtime package version changed: "+name)


def worker_initialize(manifest, results_dir, stop):
    global _WORKER
    os.environ.update(manifest["thread_environment"])
    from threadpoolctl import threadpool_limits
    limiter = threadpool_limits(limits=1)
    verify_frozen_files(manifest)
    snapshot = core_module(manifest["core_root"], "query.parquet_snapshot").ParquetSnapshot(manifest["inputs"]["snapshot"]["path"])
    ids = set(snapshot.record_ids())
    require(len(ids) == 30000, "Frozen population no longer has 30,000 distinct row IDs")
    queries = {q["query_id"]: q for q in load_queries(manifest["inputs"]["queries"]["path"])}
    # Preload the exact membership columns before any oracle request.
    for query in queries.values():
        for cohort in query["contract"]["cohorts"]:
            snapshot.cohort_records(cohort)
    proxy = core_module(manifest["core_root"], "engine.proxy").EmbeddingLRProxy(
        manifest["dataset_feature_prefix"], Path(manifest["inputs"]["features"]["path"]).parent)
    _WORKER = {"manifest": manifest, "results": Path(results_dir), "stop": stop,
               "snapshot": snapshot, "population_ids": ids, "queries": queries, "proxy": proxy,
               "labels": {}, "reference_means": {}, "limiter": limiter,
               "metadata": {q["query_id"]: q for q in manifest["query_metadata"]}}


def load_label_map(source, pred):
    cache = _WORKER["labels"]
    if (source, pred) not in cache:
        manifest = _WORKER["manifest"]
        path = manifest["labels"][source][pred]
        payload = Path(path).read_bytes()
        require(hashlib.sha256(payload).hexdigest() == manifest["label_sha256"][source][pred], "Actually loaded target-map bytes differ from freeze")
        labels = json.loads(payload)
        require(isinstance(labels, dict) and set(labels) == _WORKER["population_ids"], "Target map does not cover exactly the frozen population")
        require(all(type(v) is int and v in (0, 1) for v in labels.values()), "Target map is not a complete binary integer map")
        cache[source, pred] = labels
    return cache[source, pred]


def policy_for(method, seed, manifest):
    from executor_v2.baseline_policies import MatchedLeastSampled, DualGreedy
    if method == "matched":
        return MatchedLeastSampled()
    fallback = DualGreedy(**manifest["dual_greedy"])
    if method == "dual_greedy":
        return fallback
    if method == "boundary":
        from executor_v2.shared_boundary import SharedBoundaryPolicy
        return SharedBoundaryPolicy(fallback=fallback)
    from executor_v2.frontier_policy import ForecastFrontierPolicy
    return ForecastFrontierPolicy(seed=seed, fallback=fallback, **manifest["forecast"])


def run_shard(shard):
    state, manifest = _WORKER, _WORKER["manifest"]
    root, stop = state["results"], state["stop"]
    csv_path, raw_path = root/"shards"/(shard["name"]+".csv"), root/"shards"/(shard["name"]+".jsonl.gz")
    progress_path = root/"progress"/(shard["name"]+".json")
    seed = next(s for s in manifest["seed_records"] if s["seed_id"] == shard["seed_id"])
    completed, outcomes, failure = 0, Counter(), None
    current, started = None, time.perf_counter()
    try:
        with csv_path.open("x", newline="", encoding="utf-8") as summary, gzip.open(raw_path, "xt", compresslevel=1, encoding="utf-8") as raw:
            writer = csv.DictWriter(summary, fieldnames=CSV_FIELDS)
            writer.writeheader(); summary.flush()
            for qid in shard["query_ids"]:
                if stop.is_set():
                    break
                current = qid
                # Do not attach a previous query's result/charges if this
                # request fails before execute returns.
                run = result = evaluation = oracle = None
                row_written, budget, support = False, None, None
                query, metadata = state["queries"][qid], state["metadata"][qid]
                pred, source = metadata["predicate"], shard["source"]
                support = metadata["support_size"]
                budget = max(1, min(support, math.ceil(shard["budget_share"]*support/100)))
                labels = load_label_map(source, pred)
                semantics = manifest["ranking_semantics"] if query["kind"] == "ranking" else manifest["nonranking_semantics"]
                planning = substream(seed["planning_seed"], "cohortcert-v2-planning-request-v1", qid)
                exploration = substream(seed["exploration_seed"], "cohortcert-v2-exploration-request-v1", qid)
                plan = Plan(int(seed["pilot_seed"]), int(seed["formal_seed"]), exploration,
                            budget_override=budget, semantics=semantics, **manifest["common_plan"])
                build_start = time.perf_counter()
                policy = policy_for(shard["method"], planning, manifest)
                build_ms = 1000*(time.perf_counter()-build_start)
                oracle = SealedReplay(labels, state["population_ids"], budget)
                manifest_identity = manifest["_runtime_manifest_sha256"]
                key = digest([VERSION, manifest_identity, source, shard["method"], qid, seed["seed_id"], shard["budget_share"], semantics])
                run = {"run_key": key, "run_manifest_sha256": manifest_identity, "source": source, "method": shard["method"], "query_id": qid,
                       "predicate": pred, "kind": query["kind"], "semantics": semantics,
                       "seed_id": seed["seed_id"], "budget_share": shard["budget_share"]}
                result = execute(query["contract"], state["snapshot"], oracle, state["proxy"], policy, plan,
                                 core_root=manifest["core_root"], record_actions=True, record_cs_events=True,
                                 policy_spec={"method": shard["method"], "planning_seed": str(planning),
                                              "forecast": manifest["forecast"] if shard["method"] == "forecast" else None})
                certificate = result["certificate"]
                evaluation_start = time.perf_counter()
                result_invariants(result, oracle, support, budget)
                means_cache = state["reference_means"].setdefault((source, pred), {})
                evaluation = reference_evaluation(query["contract"], state["snapshot"], labels, certificate, means_cache)
                evaluation_ms = 1000*(time.perf_counter()-evaluation_start)
                framework = certificate.get("framework_exception")
                invariant_reason = certificate.get("reason", "").lower()
                if framework or any(marker in invariant_reason for marker in ("duplicate", "policy returned an invalid", "selected an exhausted", "would exceed the authoritative")):
                    failure = {"kind": "framework_or_invariant_failure", "query_id": qid, "detail": framework or certificate["reason"]}
                    stop.set()
                bad = evaluation["source_error"]
                outcome = ("execution_error" if certificate["status"] == "execution_error" else
                           "source_wrong_claim_or_proof" if bad else "correct_complete" if evaluation["correct_complete"] else "unresolved")
                payload = {**run, "budget": budget, "policy_build_wall_ms": build_ms,
                           "result": result, "reference_evaluation": evaluation,
                           "reference_evaluation_wall_ms": evaluation_ms, "failure": failure}
                encoded = encode(payload)
                raw_hash = hashlib.sha256(encoded.encode()).hexdigest()
                raw.write(encoded+"\n"); raw.flush()
                actions = [a for a in result["actions"] if a["source"] == "policy"]
                diagnostics = [a.get("diagnostics") or {} for a in actions]
                frozen = certificate.get("frozen", {})
                row = {**run, "summary_subtype": metadata["summary_subtype"],
                       "family_scope": "secondary_ranking" if query["kind"] == "ranking" else "primary_nonranking",
                       "pilot_seed": seed["pilot_seed"], "formal_seed": seed["formal_seed"],
                       "planning_seed": str(planning), "exploration_seed": str(exploration),
                       "budget": budget, "support_size": support, "requested_bins": plan.requested_bins,
                       "actual_cells": certificate["cell_count"], "alpha": plan.alpha_override,
                       "status": certificate["status"], "reason": certificate["reason"], "outcome": outcome,
                       "reported_complete": certificate["status"] == "complete",
                       "correct_complete": evaluation["correct_complete"], "correct_complete_vector_only": evaluation["correct_complete_vector_only"],
                       "declared_judgments": certificate["declared_judgments"], "resolved_judgments": certificate["resolved_judgments"],
                       "truth_vector": encode(evaluation["truth_vector"]), "answer_vector": encode(evaluation["answer_vector"]),
                       "wrong_true_claims": len(evaluation["wrong_true_claims"]), "wrong_false_claims": len(evaluation["wrong_false_claims"]),
                       "partial_wrong_claims": evaluation["partial_wrong_claims"], "source_proof_errors": len(evaluation["source_proof_errors"]),
                       "source_error": bad, "terminal_source_noncoverage_atoms": len(evaluation["terminal_source_noncoverage_atoms"]),
                       "semantic_calls": certificate["semantic_calls"], "calls_per_support": certificate["semantic_calls"]/support,
                       "conservative_cap_charge": budget if bad or certificate["status"] == "execution_error" else certificate["semantic_calls"],
                       "executor_wall_ms": result["total"]["wall_ms"], "executor_cpu_ms": result["total"]["cpu_ms"],
                       "policy_build_wall_ms": build_ms, "reference_evaluation_wall_ms": evaluation_ms,
                       "policy_actions": len(actions), "fallback_actions": sum(bool(d.get("fallback_reason") or d.get("boundary_fallback")) for d in diagnostics),
                       "verified_planning_actions": sum(any(d.get(k) is True for k in ("exact_incumbent_verified", "warm_model_candidate_verified", "mip_incumbent_exactly_verified")) for d in diagnostics),
                       "planning_wall_ms": sum(d.get("planning_wall_ms", 0) for d in diagnostics),
                       "allocation_sources": encode(dict(Counter(d.get("allocation_source", "none") for d in diagnostics))),
                       "proxy_fallback": (certificate.get("proxy") or {}).get("fallback"),
                       "execution_plan_sha256": certificate["plan"]["execution_plan_sha256"],
                       **{k: frozen.get(k, "") for k in ("pilot_ids_sha256", "pilot_labels_sha256", "scores_sha256", "partition_sha256", "priors_sha256", "permutations_sha256")},
                       "framework_exception": bool(framework), "invariants_valid": True, "raw_record_sha256": raw_hash}
                writer.writerow(row); summary.flush(); row_written = True
                completed += 1; outcomes[outcome] += 1
                atomic_json(progress_path, {"status": "failed" if failure else "running", "shard": shard["name"],
                                           "completed": completed, "expected": shard["expected_rows"], "last_query_id": qid,
                                           "outcomes": dict(outcomes), "failure": failure, "elapsed_seconds": time.perf_counter()-started})
                if failure:
                    break
            summary.flush(); os.fsync(summary.fileno())
    except Exception as exc:
        stop.set()
        failure = {"kind": "uncaught_grid_framework_or_invariant_failure", "query_id": current,
                   "class": type(exc).__name__, "message": str(exc), "traceback": traceback.format_exc()}
        # Preserve the complete in-memory offending result/attempts even if its
        # invariant check or summary serialization failed. Never zero-charge it.
        diagnostic = {"shard": shard, "failure": failure, "completed_rows": completed}
        for name in ("run", "result", "evaluation"):
            if locals().get(name) is not None:
                diagnostic[name] = locals()[name]
        if locals().get("oracle") is not None:
            diagnostic["independent_attempted_record_ids"] = oracle.attempted
        try:
            with gzip.open(root/"shards"/(shard["name"]+".failure.json.gz"), "xt", compresslevel=1, encoding="utf-8") as stream:
                stream.write(encode(diagnostic)+"\n")
        except Exception:
            # The compact failure is still persisted if a bad diagnostic value
            # made the full response unserializable.
            diagnostic = {"shard": shard["name"], "failure": failure,
                          "attempted_records": len(oracle.attempted) if locals().get("oracle") is not None else 0}
            new_json(root/"shards"/(shard["name"]+".failure.json"), diagnostic)
        # An offending request is still a row, with independently observed
        # charges even when the executor never returned a certificate.
        if current is not None and not locals().get("row_written", False) and csv_path.exists():
            attempts = len(oracle.attempted) if locals().get("oracle") is not None else 0
            fatal_row = {"run_key": (run or {}).get("run_key", digest([shard["name"], current])),
                         "run_manifest_sha256": manifest["_runtime_manifest_sha256"],
                         "source": shard["source"], "method": shard["method"], "query_id": current,
                         "seed_id": shard["seed_id"], "budget_share": shard["budget_share"],
                         "status": "execution_error", "reason": "grid_framework_or_invariant_failure",
                         "outcome": "execution_error", "framework_exception": True, "invariants_valid": False,
                         "semantic_calls": attempts, "support_size": support, "budget": budget,
                         "calls_per_support": attempts/support if support else None,
                         "conservative_cap_charge": budget, "reported_complete": False, "correct_complete": False}
            if locals().get("metadata") is not None:
                fatal_row.update(predicate=metadata["predicate"], kind=metadata["kind"], summary_subtype=metadata["summary_subtype"],
                                 family_scope="secondary_ranking" if metadata["kind"] == "ranking" else "primary_nonranking")
            with csv_path.open("a", newline="", encoding="utf-8") as stream:
                csv.DictWriter(stream, fieldnames=CSV_FIELDS).writerow(fatal_row)
                stream.flush(); os.fsync(stream.fileno())
            completed += 1; outcomes["execution_error"] += 1
    final = {"status": "failed" if failure else "complete" if completed == shard["expected_rows"] else "stopped_partial",
             "shard": shard["name"], "completed": completed, "expected": shard["expected_rows"],
             "outcomes": dict(outcomes), "failure": failure, "elapsed_seconds": time.perf_counter()-started}
    atomic_json(progress_path, final)
    return final


def audit_finished_shard(results, shard, paired):
    rows = 0
    path = Path(results)/"shards"/(shard["name"]+".csv")
    if not path.exists():
        return 0
    with path.open(newline="") as stream:
        for row in csv.DictReader(stream):
            if row["framework_exception"] == "True" or row["invariants_valid"] != "True":
                rows += 1
                continue
            key = tuple(row[k] for k in ("source", "query_id", "budget_share", "seed_id", "semantics"))
            identity = tuple(row[k] for k in ("pilot_ids_sha256", "pilot_labels_sha256", "scores_sha256", "partition_sha256", "priors_sha256", "permutations_sha256"))
            require(key not in paired or paired[key] == identity, "Compared methods do not share pilot/partition/prior/permutations: "+str(key))
            paired[key] = identity
            rows += 1
    return rows


def execute_manifest(args):
    require(args.manifest is not None, "--manifest is required for explicit execution")
    path = Path(args.manifest).resolve()
    manifest_hash = file_hash(path)
    if args.expect_manifest_sha256:
        require(manifest_hash == args.expect_manifest_sha256, "Requested frozen manifest hash differs")
    manifest = json.loads(path.read_text())
    require(manifest["version"] == VERSION and manifest["status"] == "frozen_before_grid_execution", "Manifest is not an executable frozen grid")
    require(args.workers is None or args.workers == manifest["worker_count"], "Worker count changed; freeze a separate manifest")
    verify_frozen_files(manifest)
    for source, maps in manifest["labels"].items():
        for pred, label_path in maps.items():
            require(file_hash(label_path) == manifest["label_sha256"][source][pred], "Target map identity differs from freeze")
    root = path.parent/"results"
    root.mkdir(exist_ok=False)
    (root/"shards").mkdir(); (root/"progress").mkdir()
    new_json(root/"execution_binding.json", {"manifest": str(path), "sha256": manifest_hash,
                                            "started_utc": utc(), "worker_count": manifest["worker_count"]})
    manifest["_runtime_manifest_sha256"] = manifest_hash
    os.environ.update(manifest["thread_environment"])
    finished, paired, failure = {}, {}, None
    started = time.perf_counter()
    context = mp.get_context("spawn")
    with context.Manager() as manager:
        stop = manager.Event()
        pool = ProcessPoolExecutor(max_workers=manifest["worker_count"], mp_context=context,
                                   initializer=worker_initialize, initargs=(manifest, str(root), stop))
        futures = {pool.submit(run_shard, shard): shard for shard in manifest["shards"]}
        pending = set(futures)
        try:
            while pending:
                done, pending = wait(pending, timeout=5, return_when=FIRST_COMPLETED)
                for future in done:
                    shard = futures[future]
                    try:
                        result = future.result()
                        audit_finished_shard(root, shard, paired)
                        finished[shard["name"]] = result
                        if result["failure"]:
                            failure = failure or result["failure"]; stop.set()
                    except Exception as exc:
                        failure = failure or {"kind": "worker_or_pairing_invariant_failure", "shard": shard["name"],
                                              "class": type(exc).__name__, "message": str(exc), "traceback": traceback.format_exc()}
                        stop.set()
                progress = {"status": "stopping_after_failure" if failure else "running", "manifest_sha256": manifest_hash,
                            "completed_shards": len(finished), "expected_shards": len(manifest["shards"]),
                            "finished_shard_rows": sum(v["completed"] for v in finished.values()),
                            "expected_rows": manifest["counts"]["all_runs"], "failure": failure,
                            "elapsed_seconds": time.perf_counter()-started}
                atomic_json(root/"progress.json", progress)
                if done:
                    print(json.dumps(progress), flush=True)
                if failure:
                    for future in pending:
                        future.cancel()
        except KeyboardInterrupt:
            stop.set()
            failure = {"kind": "user_interruption", "partial_outputs_preserved": True}
        finally:
            pool.shutdown(wait=True, cancel_futures=True)
        # Worker atomic progress includes every gracefully stopped partial shard.
        states = [json.loads(p.read_text()) for p in sorted((root/"progress").glob("*.json"))]
    complete = not failure and len(states) == len(manifest["shards"]) and all(s["status"] == "complete" for s in states)
    result = {"status": "complete" if complete else "incomplete_preserved", "manifest_sha256": manifest_hash,
              "expected_rows": manifest["counts"]["all_runs"], "written_rows": sum(s["completed"] for s in states),
              "missing_planned_rows": manifest["counts"]["all_runs"]-sum(s["completed"] for s in states),
              "shards": states, "failure": failure, "elapsed_seconds": time.perf_counter()-started,
              "no_query_or_error_filtering": True, "new_model_forwards": 0}
    new_json(root/"completion.json", result)
    atomic_json(root/"progress.json", result)
    print(json.dumps(result, indent=2))
    return 0 if complete else 1


def self_test():
    """Synthetic eight-row tests, never Civil labels or a formal grid."""
    global _WORKER, execute
    from executor_v2.baseline_policies import MatchedLeastSampled
    core = Path("/dev/shm/CohortCert_fixed_label_replay_20261031")
    snapshot = core_module(core, "query.snapshot").MemorySnapshot({f"r{i}": {} for i in range(8)})
    contract = {"snapshot_id": "synthetic", "predicate_id": "synthetic_v1", "population_scope": "eight synthetic rows",
                "risk": {"alpha": .05}, "budget": {"max_oracle_record_predicate_calls": 8},
                "cohorts": [{"id": "a", "record_ids": [f"r{i}" for i in range(4)]},
                            {"id": "b", "record_ids": [f"r{i}" for i in range(4, 8)]}],
                "decisions": [{"type": "compare", "left": "a", "right": "b", "threshold": 0, "unit": "proportion_difference"},
                              {"type": "equivalence", "left": "a", "right": "b", "tolerance": .05, "unit": "proportion_difference"}]}
    labels = {f"r{i}": int(i >= 4) for i in range(8)}
    oracle = SealedReplay(labels, set(labels), 8)
    result = execute(contract, snapshot, oracle, None, MatchedLeastSampled(), Plan(1, 2, 3, budget_override=8), core_root=core)
    assert result_invariants(result, oracle, 8, 8)
    evaluation = reference_evaluation(contract, snapshot, labels, result["certificate"])
    assert evaluation["truth_vector"] == [False, False] and evaluation["correct_complete"]
    # A source-relative alpha event has an internally valid proof and must be
    # retained, not mislabeled as a framework/invariant failure.
    wrong = deepcopy(result["certificate"])
    wrong["contrast_intervals"] = {str(a["index"]): ["1/4", "1/3"] for a in wrong["family"]["atoms"]}
    wrong["decisions"][0].update(value=True, status="true", positive_certificate=0, negative_cover=[])
    wrong["decisions"][1].update(value=False, status="false", positive_certificate=None,
                                  negative_cover=[{"certificate": 1, "atom": 2}])
    audit = reference_evaluation(contract, snapshot, labels, wrong)
    assert audit["wrong_true_claims"] == [0] and audit["source_error"] and audit["invariants_valid"]
    # Top-k conjunction ordering is irrelevant, and an identified set must be
    # checked against the exact group means, not merely existence of some set.
    ranking = deepcopy(contract)
    ranking["cohorts"] = [{"id": g, "record_ids": [f"r{2*i}", f"r{2*i+1}"]} for i, g in enumerate(("a", "b", "c", "d"))]
    ranking["decisions"] = [{"type": "topk", "candidates": ["a", "b", "c", "d"], "k": 2}]
    rank_labels = {f"r{i}": int(i in (0, 1, 2)) for i in range(8)}
    rank_oracle = SealedReplay(rank_labels, set(rank_labels), 8)
    ranked = execute(ranking, snapshot, rank_oracle, None, MatchedLeastSampled(),
                     Plan(1, 2, 3, budget_override=8, semantics="positive_only"), core_root=core)
    assert result_invariants(ranked, rank_oracle, 8, 8)
    rank_audit = reference_evaluation(ranking, snapshot, rank_labels, ranked["certificate"])
    assert rank_audit["correct_complete"] and ranked["certificate"]["decisions"][0]["selected_cohorts"] == ["a", "b"]
    reordered = deepcopy(ranked["certificate"])
    reordered["family"]["certificates"] = [list(reversed(term)) for term in reordered["family"]["certificates"]]
    assert reference_evaluation(ranking, snapshot, rank_labels, reordered)["correct_complete"]
    bad = deepcopy(result); bad["certificate"]["semantic_calls"] += 1
    try:
        result_invariants(bad, oracle, 8, 8)
    except InvariantFailure:
        pass
    else:
        raise AssertionError("Accounting mismatch was accepted")
    # No file existence or reading is permitted merely to resolve map names.
    a = argparse.Namespace(labels_dir=["human=/nonexistent/human", "model=/nonexistent/model"], label_paths=None,
                           label_map=["human:toxicity=/nonexistent/override.json"])
    resolved = label_paths(a, ["human", "model"])
    assert resolved["human"]["toxicity"] == "/nonexistent/override.json"
    assert resolved["model"]["insult"].endswith("insult/model_labels_insult_v1.json")
    # Exercise real compressed shard output/progress and an uncaught executor
    # exception using synthetic in-memory labels only. No Civil maps or formal
    # schedule are opened. The failed request must keep its one real attempt.
    import tempfile
    import threading
    saved_worker, saved_execute = _WORKER, execute
    with tempfile.TemporaryDirectory(prefix="cohortcert-grid-synthetic-") as temporary:
        root = Path(temporary)
        (root/"shards").mkdir(); (root/"progress").mkdir()
        synthetic_query = {"query_id": "synthetic-query", "kind": "summary", "contract": contract}
        common = {name: value for name, value in asdict(Plan(1, 2, 3, alpha_override=.05)).items()
                  if name not in ("pilot_seed", "formal_seed", "exploration_seed", "budget_override", "semantics")}
        synthetic_manifest = {"seed_records": [{"seed_id": 0, "pilot_seed": "1", "formal_seed": "2", "planning_seed": "4", "exploration_seed": "3"}],
                              "nonranking_semantics": "bidirectional", "ranking_semantics": "positive_only",
                              "common_plan": common, "dual_greedy": {"gamma": 1., "epsilon": 1e-4},
                              "forecast": DEFAULT_FORECAST, "core_root": str(core),
                              "_runtime_manifest_sha256": "synthetic-only"}
        try:
            _WORKER = {"manifest": synthetic_manifest, "results": root, "stop": threading.Event(),
                       "queries": {"synthetic-query": synthetic_query}, "snapshot": snapshot, "population_ids": set(labels),
                       "proxy": None, "labels": {("human", "toxicity"): labels}, "reference_means": {},
                       "metadata": {"synthetic-query": {"predicate": "toxicity", "kind": "summary", "summary_subtype": "synthetic", "support_size": 8}}}
            shard = {"name": "synthetic-normal", "source": "human", "method": "matched", "seed_id": 0,
                     "budget_share": 100, "query_ids": ["synthetic-query"], "expected_rows": 1}
            report = run_shard(shard)
            assert report["status"] == "complete" and report["completed"] == 1
            with gzip.open(root/"shards/synthetic-normal.jsonl.gz", "rt") as stream:
                complete_receipt = json.loads(stream.readline())
            assert complete_receipt["reference_evaluation"]["correct_complete"]
            def failed_execute(contract, snapshot, oracle, *unused, **kwargs):
                oracle.read(["r0"])
                raise RuntimeError("Synthetic framework failure after a charged request")
            execute = failed_execute
            _WORKER["stop"] = threading.Event()
            fatal = run_shard({**shard, "name": "synthetic-fatal"})
            assert fatal["status"] == "failed" and _WORKER["stop"].is_set()
            with (root/"shards/synthetic-fatal.csv").open(newline="") as stream:
                fatal_rows = list(csv.DictReader(stream))
            assert len(fatal_rows) == 1 and fatal_rows[0]["semantic_calls"] == "1" and fatal_rows[0]["framework_exception"] == "True"
            with gzip.open(root/"shards/synthetic-fatal.failure.json.gz", "rt") as stream:
                failure_receipt = json.loads(stream.read())
            assert failure_receipt["independent_attempted_record_ids"] == ["r0"]
        finally:
            _WORKER, execute = saved_worker, saved_execute
    print(json.dumps({"status": "passed", "synthetic_executor_runs": 3, "synthetic_failure_injections": 1,
                      "source_false_vector": [False, False], "strict_topk_set_and_conjunction_order": True,
                      "source_wrong_claim_retained_without_invariant_failure": True,
                      "accounting_mismatch_rejected": True, "label_path_resolution_without_access": True,
                      "compressed_shard_and_atomic_progress": True, "fatal_request_keeps_attempt_charge": True,
                      "civil_target_labels_opened": False, "formal_grid_runs": 0}, indent=2))


def parser():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--mode", choices=("dry-run", "freeze", "execute"), default="dry-run")
    p.add_argument("--workspace", type=Path)
    p.add_argument("--core-root", type=Path)
    p.add_argument("--protocol", type=Path)
    p.add_argument("--queries", type=Path)
    p.add_argument("--snapshot", type=Path)
    p.add_argument("--metadata-cells", type=Path)
    p.add_argument("--embeddings", type=Path)
    p.add_argument("--labels-dir", action="append", help="SOURCE=DIR, or one DIR for selected sources")
    p.add_argument("--label-map", action="append", help="SOURCE:PREDICATE=PATH")
    p.add_argument("--label-paths", type=Path, help="Metadata JSON index of source/predicate -> map filename")
    p.add_argument("--source", nargs="+", choices=("human", "model"))
    p.add_argument("--methods", nargs="+", choices=METHODS)
    p.add_argument("--caps", nargs="+", type=float)
    p.add_argument("--bins", type=int, choices=(1, 4))
    p.add_argument("--semantics", choices=("bidirectional", "positive_only"))
    p.add_argument("--ranking-semantics", choices=("positive_only", "bidirectional"))
    p.add_argument("--workers", type=int)
    p.add_argument("--forecast-grid-points", type=int)
    p.add_argument("--forecast-time-limit", type=float)
    p.add_argument("--forecast-replan-steps", type=int)
    p.add_argument("--forecast-max-wall-seconds", type=float)
    p.add_argument("--forecast-max-cells", type=int)
    p.add_argument("--out", type=Path)
    p.add_argument("--manifest", type=Path)
    p.add_argument("--expect-manifest-sha256")
    p.add_argument("--self-test", action="store_true")
    return p


def main():
    args = parser().parse_args()
    if args.self_test:
        self_test(); return 0
    if args.mode == "execute":
        configurable = ("workspace", "core_root", "protocol", "queries", "snapshot", "metadata_cells", "embeddings",
                        "labels_dir", "label_map", "label_paths", "source", "methods", "caps", "bins", "semantics",
                        "ranking_semantics", "out", "forecast_grid_points", "forecast_time_limit", "forecast_replan_steps",
                        "forecast_max_wall_seconds", "forecast_max_cells")
        require(not any(getattr(args, name) is not None for name in configurable), "Execution uses only its frozen manifest; do not provide competing configuration arguments")
        return execute_manifest(args)
    require(args.manifest is None and args.expect_manifest_sha256 is None, "Manifest execution arguments are only valid with --mode execute")
    manifest = prepare(args)
    if args.mode == "freeze":
        freeze(args, manifest); return 0
    if args.out:
        out = Path(args.out).resolve(); out.mkdir(parents=True, exist_ok=False)
        new_json(out/"metadata_only_plan.json", manifest)
    print(json.dumps({"status": "metadata_only_dry_run", "counts": manifest["counts"],
                      "shards": len(manifest["shards"]), "sources": manifest["sources"], "methods": manifest["methods"],
                      "caps": manifest["caps"], "seed_records": len(manifest["seed_records"]),
                      "nonranking_semantics": manifest["nonranking_semantics"], "ranking_semantics": manifest["ranking_semantics"],
                      "forecast": manifest["forecast"], "target_maps_touched": False, "formal_runs": 0,
                      "metadata_plan_out": str(args.out) if args.out else None}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
