"""Exact positive and negative witnesses for every declared Boolean judgment.

This module is independent of sampling and inference.  Inputs are the immutable
compiled family and exact contrast intervals.  A negative witness hits EVERY
positive certificate of one decision; the negative DNF is never enumerated.
Resolving one false decision does not resolve the other requested decisions.
"""
from __future__ import annotations

from fractions import Fraction


def _fraction(value):
    return value if isinstance(value, Fraction) else Fraction(str(value))


def atom_state(atom, bounds):
    """Return True, False, or None for a strict atom and its logical complement."""
    if bounds is None:
        return None
    lower, upper = map(_fraction, bounds)
    if lower > upper:
        raise ValueError('Reversed interval is an execution error, never evidence')
    threshold = _fraction(atom.threshold)
    if atom.kind == 'lower':
        return True if lower > threshold else False if upper <= threshold else None
    if atom.kind == 'upper':
        return True if upper < threshold else False if lower >= threshold else None
    raise ValueError(f'Unsupported atomic relation: {atom.kind}')


def evaluate(family, bounds, *, mode='bidirectional'):
    """Produce checkable per-decision witnesses, retaining unresolved entries.

    ``positive_only`` preserves the old completion semantics for a separately
    labeled comparison.  Under ``bidirectional``, every declared judgment must
    resolve individually; the truth of the conjunction is not the completion
    criterion.  No oracle labels, estimates, or future sample positions enter.
    """
    if mode not in ('bidirectional', 'positive_only'):
        raise ValueError('Unknown completion semantics')
    by_index = {atom.index: atom for atom in family.atoms}
    if len(by_index) != len(family.atoms):
        raise ValueError('Duplicate atom identifiers')
    if len(family.certificates) != len(family.certificate_decisions):
        raise ValueError('Certificate/decision mapping is incomplete')
    states = {index: atom_state(atom, bounds.get(index))
              for index, atom in by_index.items()}
    decision_ids = tuple(family.decision_indices())
    if any(index not in decision_ids for index in family.certificate_decisions):
        raise ValueError('Witness refers to an undeclared decision')
    if any(aid not in by_index for cert in family.certificates for aid in cert):
        raise ValueError('Witness refers to an undeclared atom')
    decisions = []
    for decision in decision_ids:
        types = getattr(family, 'decision_types', ())
        decision_type = types[decision] if decision < len(types) else ''
        # A top-k request asks for the set itself. Refuting existence of a
        # strict winner (for example a tie) is not successful identification.
        allow_negative = mode == 'bidirectional' and decision_type not in ('top1', 'topk')
        witnesses = [index for index, target in enumerate(family.certificate_decisions)
                     if target == decision]
        positive = [index for index in witnesses
                    if all(states[aid] is True for aid in family.certificates[index])]
        negative = []
        for index in witnesses:
            false_atoms = sorted(aid for aid in family.certificates[index]
                                 if states[aid] is False)
            if false_atoms:
                negative.append({'certificate': index, 'atom': false_atoms[0]})
        negative_complete = len(negative) == len(witnesses)
        if positive and negative_complete:
            raise ValueError('Contradictory positive/negative witnesses')
        if positive:
            value, status = True, 'true'
            proof = {'positive_certificate': min(positive), 'negative_cover': []}
        elif allow_negative and negative_complete:
            value, status = False, 'false'
            proof = {'positive_certificate': None, 'negative_cover': negative}
        else:
            value, status = None, 'unresolved'
            proof = {'positive_certificate': None, 'negative_cover': []}
        decisions.append({'decision': decision, 'value': value, 'status': status, **proof})
    return {
        'semantics': mode,
        'complete': all(item['value'] is not None for item in decisions),
        'resolved_decisions': sum(item['value'] is not None for item in decisions),
        'declared_decisions': len(decisions),
        'decisions': decisions,
        'atom_states': states,
    }


def verify(family, bounds, result):
    """Verify a serialized witness without trusting its claimed status/value."""
    reference = evaluate(family, bounds, mode=result['semantics'])
    if len(result['decisions']) != len(reference['decisions']):
        raise ValueError('Missing or duplicate declared decisions')
    for emitted, checked in zip(result['decisions'], reference['decisions']):
        for field in ('decision', 'value', 'status', 'positive_certificate', 'negative_cover'):
            if emitted[field] != checked[field]:
                raise ValueError(f'Invalid decision witness: {field}')
    for field in ('complete', 'resolved_decisions', 'declared_decisions'):
        if result[field] != reference[field]:
            raise ValueError(f'Invalid request completion: {field}')
    return True
