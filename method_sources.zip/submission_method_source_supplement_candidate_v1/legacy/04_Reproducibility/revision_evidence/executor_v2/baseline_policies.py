"""Read-only allocation controls for the shared v2 completion executor.

MatchedLeastSampled preserves the historical post-initialization rule: minimum
absolute n, NOT minimum n/N. The executor owns largest-first 8-record
initialization and fourth-round seeded exploration for every policy.

DualGreedy is a heuristic, not a cost-optimal policy or a new confidence bound.
For atom j, let W_j=U_j-L_j, m_j=(L_j+U_j)/2, and let g_j^+ be m_j-b_j for a
lower atom and b_j-m_j for an upper atom; g_j^-=-g_j^+. For currently unresolved
atoms define r_j^+/-=W_j/[2 max(g_j^+/-, epsilon)]. Already resolved atom states
are obtained with EXACT rational comparisons, including the weak false
complement of a strict atom. Define LME_gamma(x)=log(mean(exp(gamma*x)))/gamma.

For each unresolved decision d:
  P_d = min over positive witnesses containing no false atom of
        LME_gamma(r_j^+ : currently unresolved j in that witness).
  F_d = LME_gamma(min(r_j^- : currently unresolved j in w) :
                 positive witnesses w not yet hit by a false atom).
The bidirectional objective is sum_d min(P_d,F_d) for binary judgments;
top1/topk always require the positive identification direction, including in a
mixed bidirectional request. positive_only uses sum_d P_d for every decision.
Resolved decisions do not contribute. In positive_only, a decision whose every
positive witness already has a false atom is permanently blocked; it contributes
a constant zero to allocation and is reported separately, while the shared
checker correctly keeps it incomplete. If no useful gain remains the policy
uses a deterministic data-free fallback. An empty conjunction is a true witness;
an empty disjunction is false. The exact checker handles both cases.

The open-atom and unhit-witness sets above are FROZEN for a single choose() call.
Predictions do not reclassify atoms. This smooth extension of old C3 avoids
pretending that a predicted interval is observed proof, and makes the
width-only surrogate monotone within one lookahead. It may still choose badly.
For cell h, predicted count width is v_h sqrt[n_h(N_h-n_h-b)/
((n_h+b)(N_h-n_h))], or zero at exhaustion. n=0 predicts no shrinkage; common
initialization handles those cells. A hypothetical reduction delta_h changes
atom bounds by (+|a_jh| delta_h/2, -|a_jh| delta_h/2), holding midpoints fixed.
All candidates are scored together in float64 NumPy arrays with stable LME.
Only the exact common checker may certify. No heuristic float is evidence.

Choice.batch is always state.batch_size (normally 16). Prediction and pricing
use b=min(batch_size,remaining_calls,N-n), matching common executor clipping.
Gain is divided by b*unit_cost[h], with positive finite unit costs. Gain/cost
ties within 1e-12*max(1,abs(best)) go to the smallest cell ID. Nonpositive gain
falls back to largest population N, then smallest ID. Matched ties use smallest
ID. No labels, future permutations, record IDs, or mutable engine state enter.

RankingBoundary reconstructs one-bin disjoint-group ranking intervals from
coefficient signatures and pilot row constants. Pilot means are recovered up
to one shared additive constant, sufficient for ranking. Unsupported structures
fall back explicitly to DualGreedy. The same shared true/false checker always
determines per-decision completion.

Run `python -B baseline_policies.py --self-test` for an independent slow-loop
arithmetic comparison on finite synthetic states; this loads no corpus/model
and writes no files.
"""
from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from functools import lru_cache
import itertools
import math
from types import MappingProxyType

import numpy as np
from scipy.special import logsumexp

try:
    from .state import AcquisitionState, AtomView, CellView, Choice, FamilyView
    from .dual_certificate import evaluate
except ImportError:
    from state import AcquisitionState, AtomView, CellView, Choice, FamilyView
    from dual_certificate import evaluate


def _fraction(value):
    return value if isinstance(value, Fraction) else Fraction(str(value))


def _active(state):
    if state.semantics not in ("bidirectional", "positive_only"):
        raise ValueError("Unknown completion semantics")
    if type(state.batch_size) is not int or state.batch_size <= 0:
        raise ValueError("Common batch size must be a positive integer")
    if type(state.remaining_calls) is not int or state.remaining_calls < 0:
        raise ValueError("Remaining calls must be a nonnegative integer")
    ids = [cell.cell_id for cell in state.cells]
    if len(ids) != len(set(ids)):
        raise ValueError("Duplicate cell IDs")
    for cell in state.cells:
        if not 0 <= cell.n <= cell.N or not 0 <= cell.s <= cell.n:
            raise ValueError("Invalid cell count state")
        if not 0 <= cell.lower <= cell.upper <= cell.N:
            raise ValueError("Invalid confidence count interval")
    return tuple(sorted((c for c in state.cells if c.n < c.N), key=lambda c: c.cell_id)) if state.remaining_calls else ()


def _effective_batch(state, cell):
    return min(state.batch_size, state.remaining_calls, cell.N-cell.n)


def _unit_cost(state, cell):
    value = state.unit_costs.get(cell.cell_id, 1.0)
    if isinstance(value, bool) or not math.isfinite(float(value)) or float(value) <= 0:
        raise ValueError("Unit costs must be positive finite numbers")
    return float(value)


def _width_reduction(cell, batch):
    if batch <= 0 or cell.n == 0:
        return 0.0
    if cell.n+batch >= cell.N:
        return float(cell.width)
    fraction = cell.n*(cell.N-cell.n-batch)/((cell.n+batch)*(cell.N-cell.n))
    return float(cell.width)*(1.0-math.sqrt(max(0.0, fraction)))


def _fallback(active, state, reason, **diagnostics):
    if not active:
        return Choice(-1, 0, {"reason": reason, **diagnostics})
    chosen = min(active, key=lambda c: (-c.N, c.cell_id))
    return Choice(chosen.cell_id, state.batch_size,
                  {"reason": reason, "effective_batch": _effective_batch(state, chosen), **diagnostics})


class MatchedLeastSampled:
    """Historical min absolute n after common init/exploration; no n/N rule."""
    def choose(self, state: AcquisitionState) -> Choice:
        active = _active(state)
        if not active:
            return Choice(-1, 0, {"policy": "MatchedLeastSampled", "reason": "no_available_calls_or_cells"})
        chosen = min(active, key=lambda c: (c.n, c.cell_id))
        return Choice(chosen.cell_id, state.batch_size,
                      {"policy": "MatchedLeastSampled", "rule": "minimum absolute n, then cell_id",
                       "effective_batch": _effective_batch(state, chosen)})


@dataclass(frozen=True)
class _Layout:
    atoms: tuple
    rows: np.ndarray
    membership: np.ndarray
    decision_witnesses: tuple


@lru_cache(maxsize=128)
def _layout(family):
    atoms = tuple(family.atoms)
    positions = {atom.index: i for i, atom in enumerate(atoms)}
    if len(positions) != len(atoms):
        raise ValueError("Duplicate atom IDs")
    if any(atom.kind not in ("lower", "upper") for atom in atoms):
        raise ValueError("Unknown atomic comparison")
    if len(family.certificates) != len(family.certificate_decisions):
        raise ValueError("Incomplete witness/decision mapping")
    membership = np.zeros((len(family.certificates), len(atoms)), dtype=bool)
    for wi, witness in enumerate(family.certificates):
        for aid in witness:
            if aid not in positions:
                raise ValueError("Witness references an unknown atom")
            membership[wi, positions[aid]] = True
    decisions = tuple(tuple(i for i, d in enumerate(family.certificate_decisions) if d == di)
                      for di in family.decision_indices())
    if any(d not in family.decision_indices() for d in family.certificate_decisions):
        raise ValueError("Witness references an unknown decision")
    rows = np.asarray([a.row_index for a in atoms], dtype=np.int64)
    if np.any(rows < 0):
        raise ValueError("Negative coefficient row index")
    rows.setflags(write=False)
    membership.setflags(write=False)
    return _Layout(atoms, rows, membership, decisions)


def _lme(values, gamma):
    """Stable row-wise normalized log-sum-exp, requiring a nonempty last axis."""
    if values.shape[-1] == 0:
        return np.zeros(values.shape[:-1], dtype=np.float64)
    maximum = np.max(values, axis=-1, keepdims=True)
    with np.errstate(over="ignore", under="ignore"):
        return maximum[..., 0] + (logsumexp(gamma*(values-maximum), axis=-1)-math.log(values.shape[-1]))/gamma


def _masked_witness_lme(ratios, membership, gamma):
    """T x J values, W x J open masks -> T x W normalized smooth maxima."""
    if membership.shape[0] == 0 or membership.shape[1] == 0:
        return np.zeros((ratios.shape[0], membership.shape[0]), dtype=np.float64)
    counts = membership.sum(axis=1)
    values = np.where(membership[None, :, :], ratios[:, None, :], -np.inf)
    maximum = np.max(values, axis=-1)
    maximum[:, counts == 0] = 0.0
    with np.errstate(over="ignore", under="ignore"):
        offsets = np.where(membership[None, :, :], values-maximum[:, :, None], -np.inf)
        result = maximum+(logsumexp(gamma*offsets, axis=-1)-np.log(np.maximum(1, counts))[None, :])/gamma
    result[:, counts == 0] = 0.0
    return result


class DualGreedy:
    """Vectorized midpoint-fixed dual-witness greedy control, without optimality."""
    def __init__(self, gamma=1.0, epsilon=1e-4, tie_tolerance=1e-12):
        self.gamma, self.epsilon, self.tie_tolerance = map(float, (gamma, epsilon, tie_tolerance))
        if not math.isfinite(self.gamma) or self.gamma <= 0:
            raise ValueError("gamma must be positive and finite")
        if not math.isfinite(self.epsilon) or self.epsilon <= 0:
            raise ValueError("epsilon must be positive and finite")
        if not math.isfinite(self.tie_tolerance) or self.tie_tolerance < 0:
            raise ValueError("tie tolerance must be finite and nonnegative")

    def _score(self, state, active):
        layout = _layout(state.family)
        exact = evaluate(state.family, state.bounds, mode=state.semantics)
        statuses = np.asarray([1 if exact["atom_states"][a.index] is True else
                               -1 if exact["atom_states"][a.index] is False else 0 for a in layout.atoms], dtype=np.int8)
        widths, true_gaps = [], []
        for atom in layout.atoms:
            bounds = state.bounds.get(atom.index)
            if bounds is None:
                raise ValueError("A scoring atom has no valid contrast interval")
            lo, hi = map(_fraction, bounds)
            if lo > hi:
                raise ValueError("Reversed contrast interval")
            mid, threshold = (lo+hi)/2, _fraction(atom.threshold)
            widths.append(float(hi-lo))
            true_gaps.append(float(mid-threshold if atom.kind == "lower" else threshold-mid))
        widths = np.asarray(widths, dtype=np.float64)
        true_gaps = np.asarray(true_gaps, dtype=np.float64)
        if not np.isfinite(widths).all() or not np.isfinite(true_gaps).all():
            raise ValueError("Contrast scores cannot be represented by finite float64")
        batches = np.asarray([_effective_batch(state, c) for c in active], dtype=np.int64)
        prices = np.asarray([int(b)*_unit_cost(state, c) for b, c in zip(batches, active)], dtype=np.float64)
        deltas = np.asarray([_width_reduction(c, int(b)) for b, c in zip(batches, active)], dtype=np.float64)
        try:
            coefficients = np.asarray([[abs(float(c.coefficients[a.row_index])) for a in layout.atoms]
                                       for c in active], dtype=np.float64).reshape(len(active), len(layout.atoms))
        except IndexError as exc:
            raise ValueError("Cell signature omits a required coefficient row") from exc
        candidate_widths = np.maximum(0.0, widths[None, :]-deltas[:, None]*coefficients)
        all_widths = np.concatenate((widths[None, :], candidate_widths), axis=0)
        with np.errstate(over="raise", divide="raise", invalid="raise"):
            true_ratios = all_widths/(2*np.maximum(self.epsilon, true_gaps))[None, :]
            false_ratios = all_widths/(2*np.maximum(self.epsilon, -true_gaps))[None, :]
        if not np.isfinite(true_ratios).all() or not np.isfinite(false_ratios).all():
            raise ValueError("Nonfinite heuristic atom difficulty")
        open_atoms = layout.membership & (statuses == 0)[None, :]
        false_hit = np.any(layout.membership & (statuses == -1)[None, :], axis=1)
        positive_witness = _masked_witness_lme(true_ratios, open_atoms, self.gamma)
        positive_witness[:, false_hit] = np.inf
        if len(layout.atoms):
            negative_witness = np.min(np.where(open_atoms[None, :, :], false_ratios[:, None, :], np.inf), axis=-1)
        else:
            negative_witness = np.full((len(active)+1, len(state.family.certificates)), np.inf)
        negative_witness[:, false_hit] = 0.0
        total = np.zeros(len(active)+1, dtype=np.float64)
        decision_diagnostics, blocked = [], []
        for di, witness_indices in enumerate(layout.decision_witnesses):
            if exact["decisions"][di]["value"] is not None:
                continue
            eligible = [wi for wi in witness_indices if not false_hit[wi]]
            if not eligible:
                # Positive-only semantics and strict ranking identification can
                # leave a refuted existential/positive side unresolved.
                blocked.append(di)
                decision_diagnostics.append({"decision": di, "positive": None, "negative": 0.0,
                                             "preferred_side": "blocked_strict_identification" if state.family.decision_types[di] in ("top1", "topk") else "blocked_positive_only"})
                continue
            p = np.min(positive_witness[:, eligible], axis=1)
            if state.semantics == "bidirectional" and state.family.decision_types[di] not in ("top1", "topk"):
                f = _lme(negative_witness[:, eligible], self.gamma)
                score = np.minimum(p, f)
                side = "true" if p[0] <= f[0] else "false"
                negative = float(f[0])
            else:
                score, side, negative = p, "true", None
            if not np.isfinite(score).all():
                raise ValueError("An unresolved decision has no finite surrogate direction")
            total += score
            decision_diagnostics.append({"decision": di, "positive": float(p[0]),
                                         "negative": negative, "preferred_side": side})
        gains = total[0]-total[1:]
        # Only outward harmless rounding differences are tolerated; do not create gain.
        if np.any(gains < -1e-9*np.maximum(1.0, np.abs(total[0]))):
            raise ArithmeticError("Width reduction increased a monotone frozen-mask surrogate")
        gains = np.maximum(0.0, gains)
        profits = gains/prices if len(active) else np.zeros(0, dtype=np.float64)
        if not np.isfinite(profits).all():
            raise ValueError("Nonfinite gain/cost")
        return {"exact_complete": exact["complete"], "current": float(total[0]), "predicted": total[1:],
                "gain": gains, "gain_per_cost": profits, "effective_batches": batches,
                "decisions": decision_diagnostics, "blocked_positive_only": blocked}

    def score_candidates(self, state):
        """Serializable diagnostics useful for independent reference checks."""
        active = _active(state)
        scores = self._score(state, active)
        return {"current_difficulty": scores["current"], "exact_complete": scores["exact_complete"],
                "decisions": scores["decisions"], "blocked_positive_only": scores["blocked_positive_only"],
                "candidates": [{"cell_id": c.cell_id, "predicted_difficulty": float(pred),
                                "gain": float(gain), "gain_per_cost": float(profit), "effective_batch": int(batch)}
                               for c, pred, gain, profit, batch in zip(active, scores["predicted"], scores["gain"],
                                                                       scores["gain_per_cost"], scores["effective_batches"])]}

    def choose(self, state: AcquisitionState) -> Choice:
        active = _active(state)
        if not active:
            return Choice(-1, 0, {"policy": "DualGreedy", "reason": "no_available_calls_or_cells"})
        scores = self._score(state, active)
        common = {"policy": "DualGreedy", "arithmetic": "float64 heuristic; exact checker atom states",
                  "current_difficulty": scores["current"], "blocked_positive_only": scores["blocked_positive_only"],
                  "gamma": self.gamma, "epsilon": self.epsilon, "tie_tolerance": self.tie_tolerance}
        if scores["exact_complete"]:
            return Choice(-1, 0, {**common, "reason": "already_complete"})
        best = float(np.max(scores["gain_per_cost"]))
        if best <= 0:
            return _fallback(active, state, "no_positive_gain_largest_population", **common)
        tolerance = self.tie_tolerance*max(1.0, abs(best))
        eligible = [i for i, p in enumerate(scores["gain_per_cost"]) if float(p) >= best-tolerance]
        index = min(eligible, key=lambda i: active[i].cell_id)
        return Choice(active[index].cell_id, state.batch_size,
                      {**common, "reason": "maximum_predicted_dual_gain_per_cost",
                       "predicted_difficulty": float(scores["predicted"][index]),
                       "gain_per_cost": float(scores["gain_per_cost"][index]),
                       "effective_batch": int(scores["effective_batches"][index])})


class RankingBoundary:
    """Wider LUCB-inspired boundary interval; same exact true/false checker."""
    def __init__(self, fallback=None):
        self.fallback = DualGreedy() if fallback is None else fallback

    def _group_states(self, state):
        family = state.family
        if len(family.decision_types) != 1 or family.decision_types[0] not in ("top1", "topk"):
            raise ValueError("only one ordinary ranking decision is supported")
        atoms = tuple(family.atoms)
        if not atoms or any(a.kind != "lower" or _fraction(a.threshold) != 0 or len(a.cohort_pair) != 2 for a in atoms):
            raise ValueError("ordinary zero-margin group ranking atoms are required")
        groups = tuple(sorted({g for a in atoms for g in a.cohort_pair}, key=str))
        pairs = {tuple(a.cohort_pair): a for a in atoms}
        if len(pairs) != len(atoms) or set(pairs) != {(g, h) for g in groups for h in groups if g != h}:
            raise ValueError("all ordered group pairs are required")
        by_index = {a.index: a for a in atoms}
        candidate_sets = []
        for witness in family.certificates:
            left = frozenset(by_index[aid].cohort_pair[0] for aid in witness)
            right = frozenset(by_index[aid].cohort_pair[1] for aid in witness)
            observed_pairs = {tuple(by_index[aid].cohort_pair) for aid in witness}
            if not left or right != set(groups)-left or observed_pairs != {(g, h) for g in left for h in right}:
                raise ValueError("witness is not a complete top-k cross-boundary comparison")
            candidate_sets.append(left)
        if not candidate_sets or len({len(x) for x in candidate_sets}) != 1:
            raise ValueError("ranking witnesses do not identify one k")
        k = len(candidate_sets[0])
        if set(candidate_sets) != {frozenset(x) for x in itertools.combinations(groups, k)}:
            raise ValueError("explicit target-set/subset ranking is not this boundary control")
        if family.decision_types[0] == "top1" and k != 1:
            raise ValueError("top1 witness cardinality is inconsistent")
        # c_(g,h) = pilot_mean_g - pilot_mean_h. Fix one arbitrary origin.
        origin = groups[0]
        offsets = {origin: Fraction(0)}
        for group in groups[1:]:
            atom = pairs[(group, origin)]
            offsets[group] = _fraction(state.pilot_constants.get(atom.row_index, 0))
        for atom in atoms:
            g, h = atom.cohort_pair
            if offsets[g]-offsets[h] != _fraction(state.pilot_constants.get(atom.row_index, 0)):
                raise ValueError("pilot row constants are not consistent group differences")
        mapping = {}
        for cell in state.cells:
            fits = []
            for group in groups:
                coefficient = None
                for atom in atoms:
                    g, h = atom.cohort_pair
                    sign = 1 if group == g else -1 if group == h else 0
                    actual = _fraction(cell.coefficients[atom.row_index])
                    if sign == 0:
                        if actual:
                            break
                    else:
                        value = actual/sign
                        if value <= 0 or (coefficient is not None and value != coefficient):
                            break
                        coefficient = value
                else:
                    if coefficient is not None:
                        fits.append((group, coefficient))
            if len(fits) != 1:
                raise ValueError("cell is not one disjoint-group coefficient signature")
            group, coefficient = fits[0]
            original_N = 1/coefficient
            if original_N.denominator != 1 or original_N < cell.N or group in mapping:
                raise ValueError("one-bin group denominator/residual population mismatch")
            mapping[group] = (cell, coefficient)
        result = {}
        for group in groups:
            if group not in mapping:
                lo = hi = mean = offsets[group]
                cell = None
            else:
                cell, coefficient = mapping[group]
                lo, hi = offsets[group]+coefficient*cell.lower, offsets[group]+coefficient*cell.upper
                mean = offsets[group]+coefficient*cell.N*(Fraction(cell.s, cell.n) if cell.n else Fraction(1, 2))
            result[group] = {"lower": lo, "upper": hi, "mean": mean, "width": hi-lo, "cell": cell}
        return result, k

    def choose(self, state: AcquisitionState) -> Choice:
        active = _active(state)
        if not active:
            return Choice(-1, 0, {"policy": "RankingBoundary", "reason": "no_available_calls_or_cells"})
        if evaluate(state.family, state.bounds, mode=state.semantics)["complete"]:
            return Choice(-1, 0, {"policy": "RankingBoundary", "reason": "already_complete"})
        try:
            groups, k = self._group_states(state)
        except (ValueError, IndexError, KeyError) as exc:
            choice = self.fallback.choose(state)
            return Choice(choice.cell_id, choice.batch,
                          {**dict(choice.diagnostics or {}), "requested_policy": "RankingBoundary",
                           "boundary_fallback": f"unsupported structure: {exc}"})
        ordered = sorted(groups, key=lambda g: (-groups[g]["mean"], str(g)))
        inside, outside = ordered[:k], ordered[k:]
        weakest = min(inside, key=lambda g: (groups[g]["lower"], str(g)))
        strongest = min(outside, key=lambda g: (-groups[g]["upper"], str(g)))
        active_ids = {c.cell_id for c in active}
        candidates = [g for g in (weakest, strongest)
                      if groups[g]["cell"] is not None and groups[g]["cell"].cell_id in active_ids]
        if not candidates:
            return _fallback(active, state, "exhausted_boundary_largest_population", policy="RankingBoundary")
        chosen_group = min(candidates, key=lambda g: (-groups[g]["width"], str(g)))
        chosen = groups[chosen_group]["cell"]
        return Choice(chosen.cell_id, state.batch_size,
                      {"policy": "RankingBoundary", "reason": "wider_active_boundary_group_interval",
                       "inside": [str(g) for g in inside], "weakest": str(weakest), "strongest": str(strongest),
                       "chosen_group": str(chosen_group), "effective_batch": _effective_batch(state, chosen),
                       "pilot_origin": "relative common additive constant; no pilot labels accessed"})


BoundaryPolicy = RankingBoundary


def slow_reference_scores(state, *, gamma=1.0, epsilon=1e-4):
    """Independent direct loops for finite validation, not a timed baseline.

    Deliberately does not call DualGreedy, its layout/mask helpers, NumPy,
    the common exact checker, or the vectorized width prediction.
    """
    atoms = {a.index: a for a in state.family.atoms}
    atom_truth, base_widths, gaps = {}, {}, {}
    for aid, atom in atoms.items():
        lo, hi = map(_fraction, state.bounds[aid])
        threshold = _fraction(atom.threshold)
        if atom.kind == "lower":
            truth = True if lo > threshold else False if hi <= threshold else None
            gap = (lo+hi)/2-threshold
        else:
            truth = True if hi < threshold else False if lo >= threshold else None
            gap = threshold-(lo+hi)/2
        atom_truth[aid], base_widths[aid], gaps[aid] = truth, float(hi-lo), float(gap)
    active = sorted([c for c in state.cells if c.n < c.N], key=lambda c: c.cell_id) if state.remaining_calls else []

    def mean_log_exp(values):
        if not values:
            return 0.0
        maximum = max(values)
        return maximum+math.log(sum(math.exp(gamma*(v-maximum)) for v in values)/len(values))/gamma

    def objective(widths):
        score = 0.0
        for decision in state.family.decision_indices():
            terms = [tuple(state.family.certificates[i]) for i, d in enumerate(state.family.certificate_decisions) if d == decision]
            is_true = any(all(atom_truth[j] is True for j in w) for w in terms)
            is_false = all(any(atom_truth[j] is False for j in w) for w in terms)
            negative_allowed = state.semantics == "bidirectional" and state.family.decision_types[decision] not in ("top1", "topk")
            if is_true or (negative_allowed and is_false):
                continue
            eligible = [w for w in terms if not any(atom_truth[j] is False for j in w)]
            if not eligible:
                continue  # Permanently blocked positive_only decision, constant objective.
            positive = min(mean_log_exp([widths[j]/(2*max(gaps[j], epsilon)) for j in w if atom_truth[j] is None]) for w in eligible)
            if not negative_allowed:
                score += positive
            else:
                negative = mean_log_exp([min(widths[j]/(2*max(-gaps[j], epsilon)) for j in w if atom_truth[j] is None) for w in eligible])
                score += min(positive, negative)
        return score

    current, candidates = objective(base_widths), []
    for cell in active:
        b = min(state.batch_size, state.remaining_calls, cell.N-cell.n)
        if cell.n == 0:
            reduction = 0.0
        elif cell.n+b == cell.N:
            reduction = float(cell.upper-cell.lower)
        else:
            after = (cell.upper-cell.lower)*math.sqrt((cell.n/(cell.n+b))*((cell.N-cell.n-b)/(cell.N-cell.n)))
            reduction = float(cell.upper-cell.lower)-after
        predicted_widths = {aid: max(0.0, width-abs(float(cell.coefficients[atom.row_index]))*reduction)
                            for aid, (atom, width) in ((aid, (atoms[aid], base_widths[aid])) for aid in atoms)}
        predicted = objective(predicted_widths)
        gain = max(0.0, current-predicted)
        candidates.append({"cell_id": cell.cell_id, "predicted_difficulty": predicted,
                           "gain": gain, "gain_per_cost": gain/(b*float(state.unit_costs.get(cell.cell_id, 1.0))),
                           "effective_batch": b})
    return {"current_difficulty": current, "candidates": candidates}


def _self_test_family(terms_by_decision, kinds=None):
    count = max((j for terms in terms_by_decision for w in terms for j in w), default=-1)+1
    atoms = tuple(AtomView(j, (kinds or {}).get(j, "lower"), Fraction(0), j, str(j), ("a", "b")) for j in range(count))
    terms, mapping = [], []
    for di, witnesses in enumerate(terms_by_decision):
        for witness in witnesses:
            terms.append(tuple(witness)); mapping.append(di)
    return FamilyView(atoms, tuple(terms), tuple(mapping), tuple("synthetic" for _ in terms_by_decision))


def run_self_tests():
    """Independent finite arithmetic/selection checks; returns JSON-ready counts."""
    import random
    import dataclasses
    requests = ([[[0], [1, 2]]], [[[0, 1], [1, 2], [0, 2]]],
                [[[0, 1]], [[1], [2]]], [[[0]], [[1]], [[2]]],
                [[[]], [[0], [1, 2]]], [[], [[0]]])
    checked, compared = 0, 0
    rng = random.Random(92167701)
    policy = DualGreedy()
    for terms in requests:
        family = _self_test_family(terms, {1: "upper"})
        J = len(family.atoms)
        for partial in itertools.product((False, True, None), repeat=J):
            cells = tuple(CellView(cid, 211+17*i, 31+3*i, 12+i, 20+i, 150+i,
                                   .01, 1., 1., .5,
                                   tuple(Fraction(rng.choice((-2, -1, 1, 2)), 512) for _ in range(J)))
                          for i, cid in enumerate((11, 2, 29)))
            bounds = {}
            for j, truth in enumerate(partial):
                atom = family.atoms[j]
                positive = (Fraction(1, 8), Fraction(3, 8))
                negative = (Fraction(-1, 4), Fraction(0))
                if atom.kind == "upper":
                    positive, negative = (-positive[1], -positive[0]), (-negative[1], -negative[0])
                bounds[j] = positive if truth is True else negative if truth is False else (Fraction(-1, 3), Fraction(1, 3))
            for semantics in ("bidirectional", "positive_only"):
                remaining = (1, 7, 16, 100)[checked % 4]
                state = AcquisitionState(cells, family, MappingProxyType(bounds), MappingProxyType({}),
                                         remaining, 9, 16, semantics,
                                         MappingProxyType({11: 1.0, 2: 1.5, 29: .75}))
                frozen = repr(state)
                vector, direct = policy.score_candidates(state), slow_reference_scores(state)
                assert math.isclose(vector["current_difficulty"], direct["current_difficulty"], rel_tol=2e-12, abs_tol=2e-10)
                for a, b in zip(vector["candidates"], direct["candidates"]):
                    assert a["cell_id"] == b["cell_id"] and a["effective_batch"] == b["effective_batch"]
                    for key in ("predicted_difficulty", "gain", "gain_per_cost"):
                        assert math.isclose(a[key], b[key], rel_tol=3e-11, abs_tol=2e-10), (key, a, b)
                    compared += 1
                actual = policy.choose(state)
                if vector["exact_complete"]:
                    expected = -1
                else:
                    best = max(c["gain_per_cost"] for c in direct["candidates"])
                    if best <= 0:
                        expected = min(cells, key=lambda c: (-c.N, c.cell_id)).cell_id
                    else:
                        tol = 1e-12*max(1., abs(best))
                        expected = min(c["cell_id"] for c in direct["candidates"] if c["gain_per_cost"] >= best-tol)
                assert actual.cell_id == expected, (actual, expected, direct)
                assert repr(state) == frozen
                checked += 1
    # Absolute n differs deliberately from fraction n/N.
    tiny_family = _self_test_family([[[0]]])
    c0 = CellView(9, 1000, 20, 10, 10, 990, .01, 1., 1., .5, (Fraction(1, 1000),))
    c1 = CellView(4, 20, 10, 5, 5, 15, .01, 1., 1., .5, (Fraction(-1, 20),))
    state = AcquisitionState((c0, c1), tiny_family, MappingProxyType({0: (Fraction(-1), Fraction(1))}),
                             MappingProxyType({}), 100, 9, 16, "bidirectional", MappingProxyType({}))
    assert MatchedLeastSampled().choose(state).cell_id == 4
    assert MatchedLeastSampled().choose(state).batch == 16
    # Unit-costs must not silently yield infinities or negative prices.
    for bad in (0, -1, float("inf"), True):
        bad_state = dataclasses.replace(state, unit_costs=MappingProxyType({9: bad}))
        try:
            policy.choose(bad_state)
        except ValueError:
            pass
        else:
            raise AssertionError("Invalid cost accepted")
    # Read-only relative group reconstruction, including a fully pilot-read group.
    G, original_N, residual_N = ("g0", "g1", "g2"), (200, 300, 400), (180, 270, 350)
    pilot = tuple(Fraction(p, n) for p, n in zip((2, 5, 7), original_N))
    atoms, pairs = [], {}
    for g in G:
        for h in G:
            if g != h:
                j = len(atoms); pairs[g, h] = j
                atoms.append(AtomView(j, "lower", Fraction(0), j, str(j), (g, h)))
    family = FamilyView(tuple(atoms), tuple(tuple(pairs[g, h] for h in G if h != g) for g in G),
                        (0, 0, 0), ("top1",))
    cells = []
    for i, (cid, n, s, lo, hi) in enumerate(((7, 40, 10, 80, 150), (3, 50, 30, 100, 170), (10, 60, 40, 110, 240))):
        coefficients = tuple(Fraction(1, original_N[i]) if a.cohort_pair[0] == G[i]
                             else Fraction(-1, original_N[i]) if a.cohort_pair[1] == G[i] else Fraction(0) for a in atoms)
        cells.append(CellView(cid, residual_N[i], n, s, lo, hi, .01, 1., 1., .5, coefficients))
    constants = {a.row_index: pilot[G.index(a.cohort_pair[0])]-pilot[G.index(a.cohort_pair[1])] for a in atoms}
    bounds = {}
    for atom in atoms:
        low = high = constants[atom.row_index]
        for c in cells:
            a = c.coefficients[atom.row_index]
            low += a*(c.lower if a >= 0 else c.upper)
            high += a*(c.upper if a >= 0 else c.lower)
        bounds[atom.index] = low, high
    state = AcquisitionState(tuple(cells), family, MappingProxyType(bounds), MappingProxyType(constants),
                             100, 9, 16, "bidirectional", MappingProxyType({}))
    boundary = RankingBoundary()
    groups, k = boundary._group_states(state)
    assert k == 1 and boundary.choose(state).cell_id == 7
    for i, g in enumerate(G):
        assert groups[g]["lower"] == pilot[i]+Fraction(cells[i].lower, original_N[i])-pilot[0]
        assert groups[g]["upper"] == pilot[i]+Fraction(cells[i].upper, original_N[i])-pilot[0]
    groups, _ = boundary._group_states(dataclasses.replace(state, cells=tuple(cells[:2])))
    assert groups["g2"]["lower"] == groups["g2"]["upper"] == pilot[2]-pilot[0]
    # Even a bidirectional mixed request requires a real strict ranking set.
    # At an exact tie both positive ranking witnesses are refuted; this must
    # remain unresolved while the other binary judgment can resolve true.
    mixed = FamilyView((AtomView(0, "lower", Fraction(0), 0, "a>b", ("a", "b")),
                        AtomView(1, "lower", Fraction(0), 1, "b>a", ("b", "a")),
                        AtomView(2, "lower", Fraction(0), 2, "binary", ("a", "b"))),
                       ((0,), (1,), (2,)), (0, 0, 1), ("top1", "compare"))
    tied_cells = (CellView(0, 20, 10, 5, 5, 15, .01, 1., 1., .5,
                          (Fraction(1, 20), Fraction(-1, 20), Fraction(1, 20))),)
    for binary_bounds in ((Fraction(-1), Fraction(1)), (Fraction(1), Fraction(2))):
        tied = AcquisitionState(tied_cells, mixed,
                                MappingProxyType({0: (Fraction(0), Fraction(0)), 1: (Fraction(0), Fraction(0)), 2: binary_bounds}),
                                MappingProxyType({}), 16, 9, 16, "bidirectional", MappingProxyType({}))
        vector, direct = policy.score_candidates(tied), slow_reference_scores(tied)
        assert not vector["exact_complete"] and policy.choose(tied).cell_id == 0
        assert math.isclose(vector["current_difficulty"], direct["current_difficulty"], rel_tol=1e-12, abs_tol=1e-10)
        assert vector["decisions"][0]["preferred_side"] == "blocked_strict_identification"
    return {"status": "passed", "finite_states_checked": checked,
            "candidate_score_comparisons": compared, "choice_parity": True,
            "exact_false_boundaries_included": True, "upper_atoms_included": True,
            "empty_logical_families_included": True, "both_semantics": True,
            "absolute_n_matched_rule": True, "boundary_relative_group_checks": 7,
            "mixed_bidirectional_rank_tie_requires_identification": True,
            "read_only_state_unchanged": True,
            "scope": "Finite independent arithmetic/selection fixtures only; no corpus/model, optimality, or all-input numeric proof"}


if __name__ == "__main__":
    import argparse
    import json
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if not args.self_test:
        parser.error("Only --self-test is executable; no model/corpus benchmark is provided here")
    print(json.dumps(run_self_tests(), indent=2))
