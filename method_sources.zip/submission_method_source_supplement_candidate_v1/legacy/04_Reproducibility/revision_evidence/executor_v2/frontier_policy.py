"""Bounded working-model scenario optimization over shared Boolean certificates.

Input is the read-only acquisition state.  The optimizer never receives actual
unrevealed labels, record IDs, permutations, or their seeds.  Simulated labels
come from the frozen Beta-mixture's posterior predictive working law.  This law
need not describe the fixed reference labels; optimization has no frequentist
efficiency guarantee.  The executor alone performs inference and stopping.

All returned allocations pass the integer feasibility checker.  The solver's
floating bound/gap is diagnostic only.  Simulation, model size, and solver time
are capped, but a numerical-library call is not a hard real-time interrupt.
"""
from __future__ import annotations

from fractions import Fraction
from math import ceil, exp, floor, gcd, lgamma, log, log1p, sqrt
import random
from time import perf_counter, process_time

from .state import Choice
from theory_design.certificate_frontier import (Atom, atom_bounds, build_model, complete,
                                               negative_completion_mask, solve_model)


def _lcm(a, b):
    return a // gcd(a, b) * b


def _log_beta(a, b):
    return lgamma(a) + lgamma(b) - lgamma(a + b)


def _integer_problem(state):
    """Orient strict atoms and use their exact rational lattice."""
    atoms = []
    by_index = {atom.index: i for i, atom in enumerate(state.family.atoms)}
    for source in state.family.atoms:
        sign = 1 if source.kind == "lower" else -1 if source.kind == "upper" else None
        if sign is None:
            raise ValueError("Unknown strict atomic relation")
        constant = Fraction(state.pilot_constants.get(source.row_index, 0))
        offset = sign * (constant - Fraction(source.threshold))
        coeff = tuple(sign * Fraction(cell.coefficients[source.row_index])
                      for cell in state.cells)
        denominator = offset.denominator
        for value in coeff:
            denominator = _lcm(denominator, value.denominator)
        scaled = Atom(int(offset * denominator),
                      tuple(int(value * denominator) for value in coeff))
        current_lo = scaled.offset + sum(a * (cell.lower if a >= 0 else cell.upper)
                                         for a, cell in zip(scaled.coeff, state.cells))
        current_hi = scaled.offset + sum(a * (cell.upper if a >= 0 else cell.lower)
                                         for a, cell in zip(scaled.coeff, state.cells))
        source_lo, source_hi = state.bounds[source.index]
        expected = ((Fraction(source_lo) - source.threshold) * denominator,
                    (Fraction(source_hi) - source.threshold) * denominator)
        if sign < 0:
            expected = (-expected[1], -expected[0])
        if (current_lo, current_hi) != expected:
            raise ValueError("Planning row/cell bounds differ from the supplied actual state")
        # Integer arithmetic defines the model. Reject scaling too large to be
        # represented exactly as a float coefficient in the optional optimizer.
        initial_values = [abs(scaled.offset)] + [abs(a) * cell.N
                                              for a, cell in zip(scaled.coeff, state.cells)]
        if sum(initial_values) > 2**48:
            raise ValueError("Integer scaling exceeds the planning coefficient limit")
        atoms.append(scaled)
    family = tuple(tuple(tuple(by_index[j] for j in state.family.certificates[w])
                         for w in state.family.certificates_of(d))
                   for d in state.family.decision_indices())
    mode = "positive" if state.semantics == "positive_only" else "bidirectional"
    if state.semantics not in ("positive_only", "bidirectional"):
        raise ValueError("Unknown completion semantics")
    allow_negative = negative_completion_mask(
        family, mode,
        tuple(decision_type not in ("top1", "topk") for decision_type in state.family.decision_types))
    return tuple(atoms), family, mode, allow_negative


def _grid(remaining, batch, points):
    if remaining <= 0:
        return (0,)
    values = {0, remaining}
    value = min(batch, remaining)
    while len(values) < points and value < remaining:
        values.add(value)
        value *= 2
    # A geometric grid is fixed before seeing simulated outcomes. Its endpoint
    # is always feasible even when the residual cell is shorter than a batch.
    return tuple(sorted(values))


class ScenarioFrontierPolicy:
    def __init__(self, base_cs, seed, S=8, grid_points=6, time_limit=.05,
                 horizon=128, max_wall_seconds=.20, fallback=None,
                 max_cells=8, max_cache=100_000):
        if S < 1 or grid_points < 2 or horizon < 1 or time_limit <= 0:
            raise ValueError("Invalid frozen planner configuration")
        self.base_cs = base_cs
        self.seed = int(seed)
        self.rng = random.Random(self.seed)
        self.S = int(S)
        self.grid_points = int(grid_points)
        self.time_limit = float(time_limit)
        self.horizon = int(horizon)
        self.max_wall_seconds = float(max_wall_seconds)
        self.max_cells = int(max_cells)
        self.max_cache = int(max_cache)
        self.fallback = fallback
        self._cache = {}
        self._probes = {}
        self._incumbent = {}
        self.calls = 0
        # Optional solver imports are ordinary setup work; callers should charge
        # policy construction separately when reporting cold execution cost.
        import scipy.optimize  # noqa: F401

    def _probe(self, cell):
        key = (cell.cell_id, cell.N, cell.alpha, cell.a, cell.b, cell.lam)
        if key not in self._probes:
            self._probes[key] = self.base_cs(N=cell.N, alpha=cell.alpha,
                                           a=cell.a, b=cell.b, lam=cell.lam)
        return key, self._probes[key]

    def _raw(self, cell, n, s, diagnostics):
        key, probe = self._probe(cell)
        cache_key = key, n, s
        if cache_key in self._cache:
            diagnostics["raw_cache_hits"] += 1
            return self._cache[cache_key]
        diagnostics["raw_interval_computations"] += 1
        probe.n, probe.s = n, s
        low_min, high_max = s, cell.N - n + s
        # p_K has a mode floor(s*(N+1)/n), with the adjacent integer also a mode
        # when the quotient is integral. q is independent of K. This avoids the
        # historical O(N) feasible-point scan in a virtual planning trajectory.
        mode = max(low_min, min(high_max, s * (cell.N + 1) // n))
        candidates = sorted({max(low_min, min(high_max, mode + delta))
                             for delta in (0, -1, 1)})
        feasible = next((value for value in candidates if probe._accepts(value)), None)
        if feasible is None:
            value = None
        else:
            lo, hi = low_min, feasible
            while lo < hi:
                mid = (lo + hi) // 2
                if probe._accepts(mid):
                    hi = mid
                else:
                    lo = mid + 1
            left = lo
            lo, hi = feasible, high_max
            while lo < hi:
                mid = (lo + hi + 1) // 2
                if probe._accepts(mid):
                    lo = mid
                else:
                    hi = mid - 1
            value = (left, lo)
        if len(self._cache) >= self.max_cache:
            self._cache.clear()
        self._cache[cache_key] = value
        return value

    def _draw_probability(self, cell):
        n, s = cell.n, cell.s
        if cell.lam == 0:
            return self.rng.betavariate(1 + s, 1 + n - s)
        if cell.lam == 1:
            return self.rng.betavariate(cell.a + s, cell.b + n - s)
        base = log1p(-cell.lam) + _log_beta(1 + s, 1 + n - s)
        proxy = log(cell.lam) + _log_beta(cell.a + s, cell.b + n - s) - _log_beta(cell.a, cell.b)
        shift = max(base, proxy)
        proxy_weight = exp(proxy - shift) / (exp(base - shift) + exp(proxy - shift))
        if self.rng.random() < proxy_weight:
            return self.rng.betavariate(cell.a + s, cell.b + n - s)
        return self.rng.betavariate(1 + s, 1 + n - s)

    def _scenario_path(self, cell, length, deadline, diagnostics):
        ell, upper, positives = cell.lower, cell.upper, cell.s
        path = [(ell, upper)]
        probability = self._draw_probability(cell)
        failed = False
        for extra in range(1, length + 1):
            if extra % 8 == 1 and perf_counter() >= deadline:
                raise TimeoutError("virtual_prefix_generation")
            diagnostics["simulated_record_prefixes"] += 1
            if failed:
                path.append(None)
                continue
            positives += int(self.rng.random() < probability)
            n = cell.n + extra
            raw = (positives, positives) if n == cell.N else self._raw(cell, n, positives, diagnostics)
            if raw is None:
                failed = True
                path.append(None)
                continue
            ell, upper = max(ell, raw[0]), min(upper, raw[1])
            if ell > upper:
                failed = True
                path.append(None)
            else:
                path.append((ell, upper))
        return tuple(path)

    def _incumbent_choice(self, state):
        choices = []
        for cell in state.cells:
            planned = min(cell.N, self._incumbent.get(cell.cell_id, cell.n)) - cell.n
            if planned > 0 and cell.N > cell.n:
                choices.append((Fraction(planned, cell.N - cell.n), planned,
                                -cell.cell_id, cell.cell_id))
        if not choices:
            return None
        cell_id = max(choices)[-1]
        cell = next(cell for cell in state.cells if cell.cell_id == cell_id)
        batch = min(state.batch_size, state.remaining_calls, cell.N - cell.n,
                    self._incumbent[cell_id] - cell.n)
        return Choice(cell_id, batch)

    def _fallback_choice(self, state, diagnostics, reason, started):
        diagnostics["fallback_reason"] = reason
        choice = self._incumbent_choice(state)
        if choice is not None:
            diagnostics["fallback_policy"] = "retained_frontier_allocation"
        else:
            if self.fallback is None:
                from .baseline_policies import DualGreedy
                self.fallback = DualGreedy()
            choice = self.fallback.choose(state)
            diagnostics["fallback_policy"] = type(self.fallback).__name__
            if choice.diagnostics:
                diagnostics["fallback_diagnostics"] = dict(choice.diagnostics)
        diagnostics["planning_wall_ms"] = (perf_counter() - started) * 1000
        return Choice(choice.cell_id, choice.batch, diagnostics)

    def choose(self, state):
        started = perf_counter()
        self.calls += 1
        diagnostics = {"policy": "scenario_frontier_v1", "planner_call": self.calls,
                       "S_requested": self.S, "grid_points": self.grid_points,
                       "horizon_requested": self.horizon, "solver_time_limit_s": self.time_limit,
                       "raw_interval_computations": 0, "raw_cache_hits": 0,
                       "simulated_record_prefixes": 0, "exact_incumbent_verified": False,
                       "model_efficiency_scope": "working_predictive_law_only"}
        if sum(cell.n < cell.N for cell in state.cells) > self.max_cells:
            return self._fallback_choice(state, diagnostics, "active_cell_limit", started)
        try:
            atoms, family, mode, allow_negative = _integer_problem(state)
            diagnostics["allow_negative_by_decision"] = list(allow_negative)
            horizon = min(self.horizon, state.remaining_calls)
            lengths = tuple(min(cell.N - cell.n, horizon) for cell in state.cells)
            options = tuple(tuple((n, n) for n in _grid(length, state.batch_size, self.grid_points))
                            for length in lengths)
            diagnostics["horizon_effective"] = horizon
            diagnostics["prefix_options"] = [len(local) for local in options]
            # Reserve the configured optimization time. Generation timeout is a
            # real logged fallback, never a fabricated zero-value solution.
            deadline = started + max(0.001, self.max_wall_seconds - self.time_limit)
            scenarios = tuple(tuple(self._scenario_path(cell, length, deadline, diagnostics)
                                    for cell, length in zip(state.cells, lengths))
                              for _ in range(self.S))
            diagnostics["scenario_generation_ms"] = (perf_counter() - started) * 1000
            if perf_counter() >= started + self.max_wall_seconds:
                raise TimeoutError("scenario_model_build")
            model = build_model(scenarios, options, atoms, family,
                                mode=mode, budget=horizon, allow_negative=allow_negative)
            # Lexicographic empirical completion, then fewer planned record
            # requests. An extra completed scenario outweighs the entire budget.
            for h, group in enumerate(model.xvars):
                for k, index in enumerate(group):
                    model.costs[index] = options[h][k][0]
            for index in model.success_vars:
                model.costs[index] = -(horizon + 1)
            diagnostics["model_variables"] = len(model.names)
            diagnostics["model_inequalities"] = len(model.rows)
            remaining_time = started + self.max_wall_seconds - perf_counter()
            if remaining_time <= 0:
                raise TimeoutError("scenario_solver_start")
            solved = solve_model(model, time_limit=min(self.time_limit, remaining_time))
            diagnostics["solver_status"] = solved["status"]
            diagnostics["solver_message"] = solved["message"]
            diagnostics["solver_reported_bound_unverified"] = solved["solver_reported_bound_unverified"]
            diagnostics["solver_reported_gap_unverified"] = solved["solver_reported_gap_unverified"]
            diagnostics["solver_native_threads_requested"] = solved.get("solver_native_threads_requested", 1)
            diagnostics["solver_option_warnings"] = solved.get("solver_option_warnings", [])
            diagnostics["exact_incumbent_verified"] = solved["exact_incumbent_verified"]
            if not solved["exact_incumbent_verified"]:
                return self._fallback_choice(state, diagnostics, "no_verified_solver_incumbent", started)
            plan = solved["plan"]
            empirical = 0
            for paths in scenarios:
                endpoints = tuple(path[n] for path, n in zip(paths, plan))
                if all(endpoint is not None for endpoint in endpoints):
                    empirical += int(complete(atoms, family, endpoints, mode,
                                              allow_negative=allow_negative))
            diagnostics["empirical_completed_scenarios"] = empirical
            diagnostics["S_completed"] = len(scenarios)
            diagnostics["planned_additional_calls"] = sum(plan)
            diagnostics["planned_cell_prefixes"] = {str(cell.cell_id): n
                                                     for cell, n in zip(state.cells, plan)}
            if empirical == 0 or sum(plan) == 0:
                return self._fallback_choice(state, diagnostics, "zero_scenario_completion", started)
            self._incumbent = {cell.cell_id: cell.n + additional
                               for cell, additional in zip(state.cells, plan)}
            choice = self._incumbent_choice(state)
            if choice is None:
                return self._fallback_choice(state, diagnostics, "empty_selected_allocation", started)
            diagnostics["fallback_reason"] = None
            diagnostics["planning_wall_ms"] = (perf_counter() - started) * 1000
            return Choice(choice.cell_id, choice.batch, diagnostics)
        except Exception as exc:
            diagnostics["planner_exception"] = type(exc).__name__
            diagnostics["planner_exception_message"] = str(exc)[:300]
            return self._fallback_choice(state, diagnostics,
                                         f"planner_exception:{type(exc).__name__}", started)


def _posterior_mean_probability(cell):
    base_mean = (1 + cell.s) / (2 + cell.n)
    proxy_mean = (cell.a + cell.s) / (cell.a + cell.b + cell.n)
    if cell.lam == 0:
        return base_mean
    if cell.lam == 1:
        return proxy_mean
    base = log1p(-cell.lam) + _log_beta(1 + cell.s, 1 + cell.n - cell.s)
    proxy = (log(cell.lam) + _log_beta(cell.a + cell.s, cell.b + cell.n - cell.s)
             - _log_beta(cell.a, cell.b))
    shift = max(base, proxy)
    proxy_weight = exp(proxy - shift) / (exp(base - shift) + exp(proxy - shift))
    return (1 - proxy_weight) * base_mean + proxy_weight * proxy_mean


def _forecast_grid(cell, prefixes):
    """A nested acquisition-efficiency surrogate, never a valid future CS.

    The integer total-count center is the rounded posterior mean, clipped to the
    actual current CS. Width uses the old finite-population shrink prediction.
    Prefix zero remains the ENTIRE actual current interval; later predicted
    intervals are intersections around the fixed center. At virtual exhaustion
    they become that center's singleton, not an observed exact count.
    """
    remaining = cell.N - cell.n
    posterior_total = cell.s + remaining * _posterior_mean_probability(cell)
    center = max(cell.lower, min(cell.upper, int(floor(posterior_total + .5))))
    endpoints = [(cell.lower, cell.upper)]
    ell, upper = cell.lower, cell.upper
    for additional in prefixes[1:]:
        if additional == remaining:
            width = 0.
        elif cell.n > 0:
            fraction = (cell.n * (cell.N - cell.n - additional)
                        / ((cell.n + additional) * (cell.N - cell.n)))
            width = cell.width * sqrt(max(0., fraction))
        else:
            # Initialization normally handles this case; the explicit fallback
            # law is a scheduling forecast, not an inference statement.
            width = cell.width * (remaining - additional) / max(1, remaining)
        ell = max(ell, int(ceil(center - width / 2)))
        upper = min(upper, int(floor(center + width / 2)))
        if not cell.lower <= ell <= center <= upper <= cell.upper:
            raise ValueError("Non-nested forecast interval")
        endpoints.append((ell, upper))
    return tuple(endpoints), center


def _complete_integer_bounds(bounds, family, mode, allow_negative=None):
    """Exact incremental warm-plan test, independent of the endpoint checker."""
    true_atoms = tuple(lo >= 1 for lo, _ in bounds)
    false_atoms = tuple(upper <= 0 for _, upper in bounds)
    mask = negative_completion_mask(family, mode, allow_negative)
    for d, witnesses in enumerate(family):
        is_true = any(all(true_atoms[j] for j in witness) for witness in witnesses)
        if is_true:
            continue
        is_false = all(any(false_atoms[j] for j in witness) for witness in witnesses)
        if not mask[d] or not is_false:
            return False
    return True


def _coordinate_warm_plan(paths, grids, atoms, family, mode, deadline, allow_negative=None):
    """Feasible full-endpoint plan, then one deadline-limited reduction pass.

    Completion is monotone in each nested prefix coordinate, so a binary search
    finds the cheapest feasible grid index while holding other coordinates fixed.
    This is a deterministic coordinate heuristic, not a global approximation or
    optimality theorem. A deadline returns the last exactly verified plan.
    """
    wall_start, cpu_start = perf_counter(), process_time()
    mask = negative_completion_mask(family, mode, allow_negative)
    indices = [len(path) - 1 for path in paths]
    full_endpoints = tuple(path[index] for path, index in zip(paths, indices))
    feasible = all(endpoint is not None for endpoint in full_endpoints) and complete(
        atoms, family, full_endpoints, mode, allow_negative=mask)
    diagnostics = {
        "warm_full_endpoint_feasible": bool(feasible),
        "warm_full_endpoint_cost": sum(grid[index] for grid, index in zip(grids, indices)),
        "warm_coordinate_checks": 0,
        "warm_coordinates_processed": 0,
        "warm_coordinate_pass_completed": False,
    }
    if not feasible:
        diagnostics["warm_greedy_cost"] = None
        diagnostics["warm_greedy_wall_ms"] = (perf_counter() - wall_start) * 1000
        diagnostics["warm_greedy_cpu_ms"] = (process_time() - cpu_start) * 1000
        return None, diagnostics
    contributions = []
    for h, path in enumerate(paths):
        if perf_counter() >= deadline:
            break
        local = []
        for ell, upper in path:
            local.append((tuple(atom.coeff[h] * (ell if atom.coeff[h] >= 0 else upper)
                                for atom in atoms),
                          tuple(atom.coeff[h] * (upper if atom.coeff[h] >= 0 else ell)
                                for atom in atoms)))
        contributions.append(tuple(local))
    if len(contributions) == len(paths):
        bounds = atom_bounds(atoms, full_endpoints)
        lower, upper = [x[0] for x in bounds], [x[1] for x in bounds]
        order = sorted(range(len(paths)), key=lambda h: (-grids[h][-1], h))
        for h in order:
            if perf_counter() >= deadline:
                break
            old = indices[h]
            old_lo, old_hi = contributions[h][old]
            left, right = 0, old
            finished = True
            while left < right:
                if perf_counter() >= deadline:
                    finished = False
                    break
                middle = (left + right) // 2
                trial_lo, trial_hi = contributions[h][middle]
                trial = tuple((lo - old_l + new_l, hi - old_u + new_u)
                              for lo, hi, old_l, old_u, new_l, new_u in
                              zip(lower, upper, old_lo, old_hi, trial_lo, trial_hi))
                diagnostics["warm_coordinate_checks"] += 1
                if _complete_integer_bounds(trial, family, mode, allow_negative=mask):
                    right = middle
                else:
                    left = middle + 1
            if not finished:
                break
            new_lo, new_hi = contributions[h][left]
            lower = [lo - old_l + new_l for lo, old_l, new_l in zip(lower, old_lo, new_lo)]
            upper = [hi - old_u + new_u for hi, old_u, new_u in zip(upper, old_hi, new_hi)]
            indices[h] = left
            diagnostics["warm_coordinates_processed"] += 1
        diagnostics["warm_coordinate_pass_completed"] = (
            diagnostics["warm_coordinates_processed"] == len(paths))
    endpoints = tuple(path[index] for path, index in zip(paths, indices))
    if not complete(atoms, family, endpoints, mode, allow_negative=mask):
        raise ValueError("Coordinate warm plan failed independent endpoint verification")
    diagnostics["warm_greedy_cost"] = sum(grid[index] for grid, index in zip(grids, indices))
    diagnostics["warm_greedy_wall_ms"] = (perf_counter() - wall_start) * 1000
    diagnostics["warm_greedy_cpu_ms"] = (process_time() - cpu_start) * 1000
    diagnostics["warm_endpoint_plan_exactly_verified"] = True
    return tuple(indices), diagnostics


def _forecast_model_candidate(model, paths, indices, atoms, family, mode, allow_negative=None):
    """Build actual binary witnesses and verify every integer model constraint."""
    mask = negative_completion_mask(family, mode, allow_negative)
    candidate = [0] * len(model.names)
    by_name = {name: i for i, name in enumerate(model.names)}
    for h, index in enumerate(indices):
        candidate[model.xvars[h][index]] = 1
    candidate[model.success_vars[0]] = 1
    bounds = atom_bounds(atoms, tuple(path[index] for path, index in zip(paths, indices)))
    true_atoms = tuple(lo >= 1 for lo, _ in bounds)
    false_atoms = tuple(upper <= 0 for _, upper in bounds)
    for j in range(len(atoms)):
        candidate[by_name[f"true_0_{j}"]] = int(true_atoms[j])
        candidate[by_name[f"false_0_{j}"]] = int(false_atoms[j])
    for d, witnesses in enumerate(family):
        positive = [w for w, witness in enumerate(witnesses)
                    if all(true_atoms[j] for j in witness)]
        if positive:
            candidate[by_name[f"positive_0_{d}"]] = 1
            candidate[by_name[f"witness_0_{d}_{positive[0]}"]] = 1
        elif mask[d] and all(any(false_atoms[j] for j in witness) for witness in witnesses):
            candidate[by_name[f"negative_0_{d}"]] = 1
        else:
            raise ValueError("Warm allocation lacks an exact decision witness")
    candidate = tuple(candidate)
    if not model.feasible(candidate):
        raise ValueError("Warm allocation failed full integer-model verification")
    return candidate


class ForecastFrontierPolicy(ScenarioFrontierPolicy):
    """Global minimum-cost covering of deterministic forecast endpoints.

    This is the bounded primary candidate. Its objective is a declared
    efficiency surrogate. It has no model-based or distribution-free statistical
    efficiency guarantee. The exact checker verifies only this finite surrogate
    allocation; actual certificates always use the executor's real CS.
    """

    def __init__(self, seed=0, grid_points=6, time_limit=.05, replan_steps=4,
                 max_wall_seconds=.15, fallback=None, max_cells=256):
        super().__init__(None, seed, S=1, grid_points=grid_points,
                         time_limit=time_limit, horizon=1,
                         max_wall_seconds=max_wall_seconds, fallback=fallback,
                         max_cells=max_cells)
        if replan_steps < 1:
            raise ValueError("replan_steps must be positive")
        self.replan_steps = int(replan_steps)
        self._next_replan_step = -1

    def choose(self, state):
        started = perf_counter()
        self.calls += 1
        diagnostics = {"policy": "forecast_frontier_v2_warm", "planner_call": self.calls,
                       "grid_points": self.grid_points, "replan_steps": self.replan_steps,
                       "solver_time_limit_s": self.time_limit,
                       "model_efficiency_scope": "deterministic_forecast_surrogate_only",
                       "forecast_intervals_are_inference_bounds": False,
                       "exact_incumbent_verified": False}
        retained = self._incumbent_choice(state)
        if retained is not None and state.step < self._next_replan_step:
            diagnostics["reused_allocation"] = True
            diagnostics["next_replan_step"] = self._next_replan_step
            diagnostics["fallback_reason"] = None
            diagnostics["planning_wall_ms"] = (perf_counter() - started) * 1000
            return Choice(retained.cell_id, retained.batch, diagnostics)
        diagnostics["reused_allocation"] = False
        if sum(cell.n < cell.N for cell in state.cells) > self.max_cells:
            return self._fallback_choice(state, diagnostics, "active_cell_limit", started)
        try:
            atoms, family, mode, allow_negative = _integer_problem(state)
            diagnostics["allow_negative_by_decision"] = list(allow_negative)
            grids = tuple(_grid(cell.N - cell.n, state.batch_size, self.grid_points)
                          for cell in state.cells)
            predicted = tuple(_forecast_grid(cell, grid)
                              for cell, grid in zip(state.cells, grids))
            paths = tuple(item[0] for item in predicted)
            # A path index addresses a FORECAST GRID STATE, not an actual record
            # count. Its separately recorded cost is the real prefix length.
            options = tuple(tuple((additional, index) for index, additional in enumerate(grid))
                            for grid in grids)
            diagnostics["forecast_centers"] = {str(cell.cell_id): item[1]
                                                for cell, item in zip(state.cells, predicted)}
            diagnostics["prefix_options"] = [len(grid) for grid in grids]
            warm_deadline = started + max(.001, self.max_wall_seconds - self.time_limit - .02)
            warm_indices, warm_diagnostics = _coordinate_warm_plan(
                paths, grids, atoms, family, mode, warm_deadline, allow_negative=allow_negative)
            diagnostics.update(warm_diagnostics)
            if warm_indices is None:
                return self._fallback_choice(state, diagnostics,
                                             "full_forecast_endpoints_not_complete", started)
            warm_plan = tuple(grid[index] for grid, index in zip(grids, warm_indices))
            # Retain the current exactly checked forecast allocation even if
            # later model construction or optimization exceeds its deadline.
            self._incumbent = {cell.cell_id: cell.n + additional
                               for cell, additional in zip(state.cells, warm_plan)}
            self._next_replan_step = state.step + self.replan_steps
            diagnostics["allocation_source"] = "warm_coordinate_plan"
            diagnostics["predicted_required_calls_incumbent"] = sum(warm_plan)
            diagnostics["planned_cell_prefixes"] = {str(cell.cell_id): n
                                                     for cell, n in zip(state.cells, warm_plan)}
            if perf_counter() >= started + self.max_wall_seconds:
                return self._fallback_choice(state, diagnostics, "warm_plan_only_planning_budget", started)
            # Full-support planning can target a long certificate even when no
            # plan fits the current call cap. Its hypothetical extra cost is NOT
            # permission to exceed that cap; the executor clips real actions.
            model = build_model((paths,), options, atoms, family,
                                mode=mode, frontier=True, allow_negative=allow_negative)
            # This is an incumbent upper-bound cut, NOT a solver warm-start API.
            # It preserves every solution cheaper than the known feasible plan.
            model.rows.append({index: -cost for index, cost in enumerate(model.costs) if cost})
            model.rhs.append(-sum(warm_plan))
            warm_candidate = _forecast_model_candidate(model, paths, warm_indices, atoms, family,
                                                       mode, allow_negative=allow_negative)
            diagnostics["warm_model_candidate_verified"] = True
            diagnostics["exact_incumbent_verified"] = True
            diagnostics["model_variables"] = len(model.names)
            diagnostics["model_inequalities"] = len(model.rows)
            remaining_time = started + self.max_wall_seconds - perf_counter()
            if remaining_time <= .005:
                return self._fallback_choice(state, diagnostics, "warm_plan_only_solver_budget", started)
            solved = solve_model(model, time_limit=min(self.time_limit, max(.001, remaining_time - .005)))
            diagnostics["solver_status"] = solved["status"]
            diagnostics["solver_message"] = solved["message"]
            diagnostics["solver_reported_bound_unverified"] = solved["solver_reported_bound_unverified"]
            diagnostics["solver_reported_gap_unverified"] = solved["solver_reported_gap_unverified"]
            diagnostics["solver_native_threads_requested"] = solved.get("solver_native_threads_requested", 1)
            diagnostics["solver_option_warnings"] = solved.get("solver_option_warnings", [])
            diagnostics["mip_incumbent_exactly_verified"] = solved["exact_incumbent_verified"]
            indices = warm_indices
            diagnostics["mip_incumbent_cost"] = None
            if solved["exact_incumbent_verified"]:
                mip_indices = solved["plan"]
                mip_endpoints = tuple(path[index] for path, index in zip(paths, mip_indices))
                if complete(atoms, family, mip_endpoints, mode, allow_negative=allow_negative):
                    mip_cost = sum(grid[index] for grid, index in zip(grids, mip_indices))
                    diagnostics["mip_incumbent_cost"] = mip_cost
                    if mip_cost < sum(warm_plan):
                        indices = mip_indices
                        diagnostics["allocation_source"] = "checked_mip_incumbent"
                else:
                    diagnostics["mip_boolean_verification_failed"] = True
            else:
                diagnostics["mip_no_incumbent_action"] = "use_checked_warm_plan"
            plan = tuple(grid[index] for grid, index in zip(grids, indices))
            endpoints = tuple(path[index] for path, index in zip(paths, indices))
            if not complete(atoms, family, endpoints, mode, allow_negative=allow_negative):
                raise ValueError("Forecast allocation failed independent Boolean verification")
            diagnostics["predicted_required_calls_incumbent"] = sum(plan)
            diagnostics["predicted_plan_within_remaining_cap"] = sum(plan) <= state.remaining_calls
            diagnostics["planned_cell_prefixes"] = {str(cell.cell_id): n
                                                     for cell, n in zip(state.cells, plan)}
            if not any(plan):
                return self._fallback_choice(state, diagnostics, "empty_forecast_allocation", started)
            self._incumbent = {cell.cell_id: cell.n + additional
                               for cell, additional in zip(state.cells, plan)}
            self._next_replan_step = state.step + self.replan_steps
            choice = self._incumbent_choice(state)
            if choice is None:
                raise ValueError("No unfinished selected forecast cell")
            diagnostics["fallback_reason"] = None
            diagnostics["planning_wall_ms"] = (perf_counter() - started) * 1000
            return Choice(choice.cell_id, choice.batch, diagnostics)
        except Exception as exc:
            diagnostics["planner_exception"] = type(exc).__name__
            diagnostics["planner_exception_message"] = str(exc)[:300]
            return self._fallback_choice(state, diagnostics,
                                         f"planner_exception:{type(exc).__name__}", started)
