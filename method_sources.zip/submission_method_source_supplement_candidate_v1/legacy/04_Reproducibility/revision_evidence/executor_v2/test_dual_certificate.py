"""Independent Boolean-completion enumeration and exact boundary probes."""
import itertools
import json
from fractions import Fraction as F
from pathlib import Path
from types import SimpleNamespace

from dual_certificate import evaluate, verify


def family(terms_by_decision, kinds=None):
    count = max((a for terms in terms_by_decision for term in terms for a in term), default=-1) + 1
    atoms = [SimpleNamespace(index=i, threshold=F(0), kind=(kinds or {}).get(i, 'lower'))
             for i in range(count)]
    certs, mapping = [], []
    for decision, terms in enumerate(terms_by_decision):
        for term in terms:
            certs.append(term)
            mapping.append(decision)
    return SimpleNamespace(atoms=atoms, certificates=certs, certificate_decisions=mapping,
                           decision_indices=lambda: list(range(len(terms_by_decision))))


def main():
    requests = [
        [[[0], [1, 2]]],
        [[[0, 1], [1, 2], [0, 2]]],
        [[[0, 1]], [[1], [2]]],
        [[[0]], [[1]], [[2]]],
        [[[]], [[0], [1, 2]]],
        [[], [[0]]],
    ]
    checks = 0
    for terms in requests:
        compiled = family(terms)
        n = len(compiled.atoms)
        for partial in itertools.product((False, True, None), repeat=n):
            bounds = {i: ((F(1), F(2)) if value is True else
                          (F(-1), F(0)) if value is False else (F(-1), F(1)))
                      for i, value in enumerate(partial)}
            result = evaluate(compiled, bounds)
            worlds = [world for world in itertools.product((False, True), repeat=n)
                      if all(value is None or world[i] == value for i, value in enumerate(partial))]
            direct = []
            for decision_terms in terms:
                possible = {any(all(world[atom] for atom in term) for term in decision_terms)
                            for world in worlds}
                direct.append(next(iter(possible)) if len(possible) == 1 else None)
            assert [d['value'] for d in result['decisions']] == direct
            assert result['complete'] == all(value is not None for value in direct)
            assert verify(compiled, bounds, result)
            checks += 1
    # Strict equality belongs to the false complement, for both atom directions.
    for kind in ('lower', 'upper'):
        f = family([[[0]]], {0: kind})
        assert evaluate(f, {0: (F(0), F(0))})['decisions'][0]['value'] is False
    # Equivalence is strict on both sides, and zero support can settle it.
    eq = family([[[0, 1]]], {0: 'lower', 1: 'upper'})
    eq.atoms[0].threshold, eq.atoms[1].threshold = F(-1, 20), F(1, 20)
    assert evaluate(eq, {0: (F(0), F(0)), 1: (F(0), F(0))})['complete']
    for point in (F(-1, 20), F(1, 20)):
        result = evaluate(eq, {0: (point, point), 1: (point, point)})
        assert result['decisions'][0]['value'] is False
    # A false first decision does NOT settle the remaining requested judgment.
    f = family([[[0]], [[1]]])
    r = evaluate(f, {0: (F(-1), F(0)), 1: (F(-1), F(1))})
    assert r['decisions'][0]['value'] is False and not r['complete']
    legacy = evaluate(f, {0: (F(-1), F(0)), 1: (F(1), F(1))}, mode='positive_only')
    assert not legacy['complete'] and legacy['decisions'][0]['value'] is None
    # Strict set identification keeps a tie/no-winner unresolved, even in a
    # mixed request whose ordinary comparison is settled negatively.
    f.decision_types = ['compare', 'top1']
    ranking = evaluate(f, {0: (F(0), F(0)), 1: (F(0), F(0))})
    assert ranking['decisions'][0]['value'] is False
    assert ranking['decisions'][1]['value'] is None and not ranking['complete']
    try:
        evaluate(f, {0: (F(1), F(0))})
    except ValueError:
        pass
    else:
        raise AssertionError('Reversed bounds accepted')
    record = {'status': 'passed', 'independent_boolean_partial_world_checks': checks,
              'strict_boundary_probes': 4, 'zero_support_equivalence': True,
              'every_declared_decision_required': True, 'positive_only_mode_separate': True,
              'strict_ranking_identification_keeps_refuted_existence_unresolved': True,
              'scope': 'Finite independent truth enumeration; no empirical data or sampling proof.'}
    (Path(__file__).parent / 'dual_checker_validation.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record, indent=2))


if __name__ == '__main__':
    main()
