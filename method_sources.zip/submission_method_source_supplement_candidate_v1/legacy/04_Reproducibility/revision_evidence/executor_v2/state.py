"""Read-only acquisition interface; no unrevealed record order or labels."""
from dataclasses import dataclass
from fractions import Fraction
from types import MappingProxyType
from typing import Mapping


@dataclass(frozen=True)
class AtomView:
    index: int
    kind: str
    threshold: Fraction
    row_index: int
    label: str
    cohort_pair: tuple


@dataclass(frozen=True)
class FamilyView:
    atoms: tuple
    certificates: tuple
    certificate_decisions: tuple
    decision_types: tuple

    @classmethod
    def freeze(cls, family):
        return cls(tuple(AtomView(a.index, a.kind, Fraction(a.threshold), a.row_index,
                                  a.label, tuple(a.cohort_pair)) for a in family.atoms),
                   tuple(tuple(c) for c in family.certificates),
                   tuple(family.certificate_decisions), tuple(family.decision_types))

    def decision_indices(self):
        return tuple(range(len(self.decision_types)))

    def certificates_of(self, decision):
        return tuple(i for i, d in enumerate(self.certificate_decisions) if d == decision)

    @property
    def _by_index(self):
        return MappingProxyType({a.index: a for a in self.atoms})


@dataclass(frozen=True)
class CellView:
    cell_id: int
    N: int
    n: int
    s: int
    lower: int
    upper: int
    alpha: float
    a: float
    b: float
    lam: float
    coefficients: tuple

    @property
    def width(self):
        return self.upper - self.lower


@dataclass(frozen=True)
class AcquisitionState:
    cells: tuple[CellView, ...]
    family: FamilyView
    bounds: Mapping
    pilot_constants: Mapping
    remaining_calls: int
    step: int
    batch_size: int
    semantics: str
    unit_costs: Mapping


@dataclass(frozen=True)
class Choice:
    cell_id: int
    batch: int
    diagnostics: Mapping | None = None
