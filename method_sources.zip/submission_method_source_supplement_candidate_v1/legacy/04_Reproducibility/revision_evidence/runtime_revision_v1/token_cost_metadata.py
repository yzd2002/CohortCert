#!/usr/bin/env python3
"""Tokenizer-only input counts for the COMMITTED set; records no timing data.

Loads no model weights, makes no CUDA calls, reads no target/reference map, and
cannot change/reselect queries. Counts every selected support's exact formatted
prompts, then bounds an arbitrary at-cap record subset by its largest B lengths.
"""
from pathlib import Path
import argparse
import json
import math

from runtime_common import frozen_api, sha, write_new
from runtime_backend import operator_specs

HERE = Path(__file__).resolve().parent


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--selection", type=Path, default=HERE/"DRAFT_SELECTION.json")
    p.add_argument("--out", type=Path, default=HERE/"TOKEN_COSTS.json")
    a = p.parse_args()
    if a.out.exists():
        raise FileExistsError("Retain the existing metadata receipt")
    selection = json.loads(a.selection.read_text())
    frozen_api(selection["policy_root"])
    from common import core_module
    import pyarrow.parquet as pq
    from transformers import AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(selection["model_dir"], local_files_only=True, trust_remote_code=False)
    model, operators = operator_specs(selection)
    sources = {}
    for dataset, spec in selection["datasets"].items():
        rows = pq.read_table(spec["texts"], columns=["record_id", "text"]).to_pylist()
        sources[dataset] = {"snapshot": core_module(selection["core_root"], "query.parquet_snapshot").ParquetSnapshot(spec["metadata"]),
                            "texts": {r["record_id"]: r["text"] for r in rows}}
    compiler = core_module(selection["core_root"], "query.compiler")
    cache, results = {}, []
    for query in selection["selected"]:
        dataset, predicate = query["dataset"], query["predicate"]
        matrix, _ = compiler.compile_signed_decisions(query["query"]["contract"], sources[dataset]["snapshot"])
        support = sorted(matrix.rows_with_any_nonzero_coefficient())
        if len(support) != query["support_size"]:
            raise RuntimeError("Committed metadata support changed")
        lengths = []
        prompt = operators[dataset, predicate]["prompt"]
        for start in range(0, len(support), 256):
            ids = support[start:start+256]
            formatted = [tokenizer.apply_chat_template([{"role": "user", "content": prompt.format(text=sources[dataset]["texts"][rid])}],
                         tokenize=False, add_generation_prompt=True, enable_thinking=False) for rid in ids]
            encoded = tokenizer(formatted, add_special_tokens=False, truncation=False, padding=False)["input_ids"]
            lengths.extend(len(tokens) for tokens in encoded)
        if max(lengths) > model["max_context_tokens"]:
            raise RuntimeError("Context overflow; retain selected row/query and report infeasibility")
        ordered = sorted(lengths)
        results.append({"query_id": query["query"]["query_id"], "dataset": dataset, "predicate": predicate,
                        "support": len(support), "budget": query["budget"], "formatted_tokens_total_support": sum(lengths),
                        "mean_formatted_tokens": sum(lengths)/len(lengths), "median_formatted_tokens": ordered[len(ordered)//2],
                        "p95_formatted_tokens": ordered[math.ceil(.95*len(ordered))-1], "max_formatted_tokens": max(lengths),
                        "top_B_token_sum_bound": sum(ordered[-query["budget"]:]),
                        "uniform_mean_at_cap_tokens_planning_only": query["budget"]*sum(lengths)/len(lengths)})
    by_id = {r["query_id"]: r for r in results}
    bound = sum(by_id[row["query_id"]]["top_B_token_sum_bound"] for row in selection["schedule"])
    nominal = sum(by_id[row["query_id"]]["uniform_mean_at_cap_tokens_planning_only"] for row in selection["schedule"])
    record = {"selection_sha256": sha(a.selection), "scope": "Metadata/tokenizer counts only; no GPU, model weights, target maps or timing observations",
              "queries": results, "all_scheduled_corpus_input_tokens_upper_bound": bound,
              "all_scheduled_mean_at_cap_tokens_planning_only": nominal,
              "historical_token_linear_minutes_at_upper_bound": bound/selection["historical_planning_only"]["airline_tokens_per_second"]/60,
              "historical_token_linear_minutes_at_selected_means": nominal/selection["historical_planning_only"]["airline_tokens_per_second"]/60,
              "tokenizer_json_sha256": sha(Path(selection["model_dir"])/"tokenizer.json"),
              "query_selection_changed": False, "model_weights_loaded": False, "model_forward_calls": 0,
              "note": "Upper bound permits any arbitrary B-record subset, stronger than assuming uniformly chosen lengths; token-linear time is only an old-corpus planning extrapolation"}
    write_new(a.out, record)
    print(json.dumps(record, indent=2))


if __name__ == "__main__":
    main()
