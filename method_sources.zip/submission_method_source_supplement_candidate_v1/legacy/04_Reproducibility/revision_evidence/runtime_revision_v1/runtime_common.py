"""Local utilities; importing this file never imports torch or an executor."""
from __future__ import annotations
from datetime import datetime, timezone
import hashlib
import importlib
import json
import os
from pathlib import Path
import subprocess
import sys


def utc():
    return datetime.now(timezone.utc).isoformat()


def canonical(value):
    def default(obj):
        if hasattr(obj, "item"):
            return obj.item()
        return str(obj)
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False, default=default)


def digest(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(4*1024*1024), b""):
            h.update(block)
    return h.hexdigest()


def write_new(path, value):
    with Path(path).open("x", encoding="utf-8") as stream:
        stream.write(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False)+"\n")


def atomic(path, value):
    path = Path(path)
    temp = path.with_name(path.name+f".tmp.{os.getpid()}")
    temp.write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False)+"\n")
    os.replace(temp, path)


def frozen_api(policy_root):
    root = Path(policy_root).resolve()
    frozen = json.loads((root/"SOURCE_SHA256.json").read_text())
    for relative, expected in frozen.items():
        if sha(root/relative) != expected:
            raise RuntimeError("Frozen primary source changed: "+relative)
    for name, module in list(sys.modules.items()):
        if name == "common" or name == "request_repairs" or name.startswith(("executor_v2", "theory_design")):
            source = getattr(module, "__file__", None)
            if source and not Path(source).resolve().is_relative_to(root):
                raise ImportError("An incompatible mutable policy module is already imported: "+name)
    for directory in (root, root/"system_design"):
        if str(directory) not in sys.path:
            sys.path.insert(0, str(directory))
    return importlib.import_module("executor_v2.execution"), importlib.import_module("executor_v2.run_grid")


def process_blockers(processes, blocked_pids, project_root=None, runtime_root=None):
    """Pure classifier, separately tested without probing or waiting."""
    result = []
    for pid, argv in processes:
        if pid in blocked_pids:
            result.append({"pid": pid, "reason": "explicitly named active primary CPU process"})
        elif any(Path(arg).name == "build_qwen_labels.py" for arg in argv) and "full" in argv:
            result.append({"pid": pid, "reason": "fixed-label GPU build"})
        elif any(Path(arg).name == "run_grid.py" for arg in argv) and "execute" in argv:
            result.append({"pid": pid, "reason": "primary CPU acquisition grid"})
        elif any(Path(arg).name == "run_replication.py" for arg in argv) and "execute" in argv:
            result.append({"pid": pid, "reason": "post-hoc legacy replication CPU grid"})
        elif project_root and any("python" in Path(arg).name for arg in argv[:1]):
            # Also exclude analysis/oracle masters, including python -c code
            # with project imports. Their spawned workers are covered by the
            # live master. A root-provided PID can cover an orphaned worker.
            runtime_driver = any(runtime_root and str(runtime_root) in arg and Path(arg).name == "run_runtime.py" for arg in argv[1:])
            project_refs = [arg for arg in argv[1:] if str(project_root) in arg]
            if project_refs and not runtime_driver:
                result.append({"pid": pid, "reason": "other Python research-project work (analysis/oracle/replication)"})
    return result


def assert_quiescent(blocked_pids=(73397,), allowed_gpu_pid=None):
    """Fail immediately; never wait, schedule, kill, or start primary jobs."""
    processes = []
    for directory in Path("/proc").iterdir():
        if not directory.name.isdigit() or int(directory.name) == os.getpid():
            continue
        try:
            argv = (directory/"cmdline").read_bytes().decode(errors="replace").split("\0")
            processes.append((int(directory.name), [arg for arg in argv if arg]))
        except (OSError, PermissionError):
            pass
    runtime_root = Path(__file__).resolve().parent
    blockers = process_blockers(processes, set(blocked_pids), runtime_root.parent, runtime_root)
    if blockers:
        raise RuntimeError("Timing prohibited while primary work is active: "+canonical(blockers))
    query = subprocess.run(["nvidia-smi", "--query-compute-apps=pid", "--format=csv,noheader,nounits"],
                           check=True, capture_output=True, text=True, timeout=10)
    other = [int(line.strip()) for line in query.stdout.splitlines() if line.strip().isdigit()
             and int(line.strip()) != allowed_gpu_pid]
    if other:
        raise RuntimeError("Timing prohibited while another GPU compute process is active: "+str(other))
    return {"primary_processes_absent": True, "other_gpu_processes_absent": True}
