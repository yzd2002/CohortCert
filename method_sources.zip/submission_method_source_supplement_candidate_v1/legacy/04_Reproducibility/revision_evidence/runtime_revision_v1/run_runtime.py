#!/usr/bin/env python3
"""Separate real-forward runtime candidate. Default dry-run never loads labels/GPU.

Modes: dry-run; freeze (future explicit root action, map hashes only); run
(future explicit action, refuses active primary jobs); worker (internal fresh
process); audit (post-collection reference validation and materialized lookups).
Nothing is scheduled automatically. No file under policy_freeze_v1 is written.
"""
from __future__ import annotations

import argparse
from collections import Counter
import csv
import gzip
import importlib.metadata
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback

from runtime_common import assert_quiescent, atomic, canonical, digest, frozen_api, sha, utc, write_new

HERE = Path(__file__).resolve().parent
ENVIRONMENT = {"PYTHONHASHSEED": "0", "CUBLAS_WORKSPACE_CONFIG": ":4096:8", "OMP_NUM_THREADS": "1",
               "OPENBLAS_NUM_THREADS": "1", "MKL_NUM_THREADS": "1", "NUMEXPR_NUM_THREADS": "1"}


def break_even(online_startup_ms, materialized_startup_ms, mean_online_ms, mean_lookup_ms):
    """Cost equation only; completion/validity must be reported alongside it."""
    values = (online_startup_ms, materialized_startup_ms, mean_online_ms, mean_lookup_ms)
    if any(not math.isfinite(v) or v < 0 for v in values):
        raise ValueError("Break-even costs must be finite nonnegative disjoint wall costs")
    slope = mean_online_ms-mean_lookup_ms
    intercept = materialized_startup_ms-online_startup_ms
    if slope == 0 or intercept/slope < 0:
        return {"crossing_requests": None, "reason": "no nonnegative finite crossing"}
    return {"crossing_requests": intercept/slope,
            "lower_cost_after_crossing": "materialized" if slope > 0 else "online",
            "is_latency_or_utility_superiority_claim": False}


def verify_inputs(selection):
    if sha(Path(selection["policy_root"])/"SOURCE_SHA256.json") != selection["policy_freeze_manifest_sha256"]:
        raise RuntimeError("Primary policy freeze manifest changed")
    for dataset in selection["input_identity"].values():
        for item in dataset.values():
            if sha(item["path"]) != item["sha256"]:
                raise RuntimeError("Runtime input changed: "+item["path"])
    if sha(selection["model_expected_manifest"]) != selection["model_expected_manifest_sha256"]:
        raise RuntimeError("Expected model-file manifest changed")


def load_manifest(path, expected=None):
    if expected and sha(path) != expected:
        raise RuntimeError("Frozen runtime manifest hash differs")
    manifest = json.loads(Path(path).read_text())
    if manifest["status"] != "frozen_for_later_explicit_runtime_launch":
        raise RuntimeError("This draft is not an executable frozen runtime protocol")
    for name, expected_hash in manifest["runtime_sources"].items():
        if sha(HERE/name) != expected_hash:
            raise RuntimeError("Runtime source changed after freeze: "+name)
    for name, version in manifest["packages"].items():
        if importlib.metadata.version(name) != version:
            raise RuntimeError("Runtime package differs from freeze: "+name)
    verify_inputs(manifest["selection"])
    return manifest


def freeze(args, selection):
    if args.out is None:
        raise ValueError("--out must name a new runtime freeze directory")
    verify_inputs(selection)
    deadline_path = HERE/"RESOURCE_DEADLINE_AMENDMENT.json"
    deadline_amendment = json.loads(deadline_path.read_text())
    if deadline_amendment["selection_sha256"] != sha(args.selection):
        raise ValueError("Resource-only amendment refers to another query selection")
    frozen_api(selection["policy_root"])
    references = {dataset: spec["reference_paths"] for dataset, spec in selection["datasets"].items()}
    if args.reference_paths:
        references = json.loads(args.reference_paths.read_text())
        references = {dataset: {pred: str((args.reference_paths.parent/Path(path)).resolve()) for pred, path in maps.items()}
                      for dataset, maps in references.items()}
    hashes = {dataset: {pred: sha(path) for pred, path in maps.items()} for dataset, maps in references.items()}
    out = args.out.resolve(); out.mkdir(parents=True, exist_ok=False)
    manifest = {"schema": "cohortcert.runtime-freeze-v1", "status": "frozen_for_later_explicit_runtime_launch",
                "created_utc": utc(), "selection_file_sha256": sha(args.selection), "selection": selection,
                "resource_deadline_amendment": deadline_amendment, "resource_deadline_amendment_sha256": sha(deadline_path),
                "references": references, "reference_sha256": hashes,
                "runtime_sources": {p.name: sha(p) for p in sorted(HERE.glob("*.py"))},
                "packages": {n: importlib.metadata.version(n) for n in
                             ("torch", "transformers", "tokenizers", "numpy", "scipy", "scikit-learn", "pyarrow", "safetensors")},
                "provenance": "Metadata query selection committed before this agent received root's primary outcome summary; root knew primary outcomes before final runtime freeze. Internal hash commitment, not external blind preregistration.",
                "environment": ENVIRONMENT, "feature_regime": "shipped immutable precomputed features; construction charged separately",
                "materialization_costs": str(args.materialization_costs) if args.materialization_costs else None,
                "materialization_costs_sha256": sha(args.materialization_costs) if args.materialization_costs else None,
                "token_cost_metadata": str(args.token_costs) if args.token_costs else None,
                "token_cost_metadata_sha256": sha(args.token_costs) if args.token_costs else None,
                "target_values_interpreted_by_freeze": False, "new_model_forwards": 0}
    write_new(out/"runtime_manifest.json", manifest)
    print(json.dumps({"manifest": str(out/"runtime_manifest.json"), "sha256": sha(out/"runtime_manifest.json"),
                      "new_model_forwards": 0, "status": manifest["status"]}, indent=2))


def load_datasets(selection, needed):
    import pyarrow.parquet as pq
    from common import core_module
    datasets, setup = {}, {}
    for name in needed:
        spec = selection["datasets"][name]
        wall, cpu = time.perf_counter(), time.process_time()
        snapshot = core_module(selection["core_root"], "query.parquet_snapshot").ParquetSnapshot(spec["metadata"])
        ids = set(snapshot.record_ids())
        rows = pq.read_table(spec["texts"], columns=["record_id", "text"]).to_pylist()
        texts = {row["record_id"]: row["text"] for row in rows}
        if set(texts) != ids or len(rows) != len(ids):
            raise RuntimeError("Metadata/text populations differ")
        for query in selection["selected"]:
            if query["dataset"] == name:
                for cohort in query["query"]["contract"]["cohorts"]:
                    snapshot.cohort_records(cohort)
        proxy = core_module(selection["core_root"], "engine.proxy").EmbeddingLRProxy(spec["feature_prefix"], spec["features"])
        datasets[name] = {"snapshot": snapshot, "texts": texts, "ids": ids, "proxy": proxy}
        setup[name] = {"metadata_text_feature_load_wall_ms": 1000*(time.perf_counter()-wall),
                       "metadata_text_feature_load_cpu_ms": 1000*(time.process_time()-cpu), "population_rows": len(ids)}
    return datasets, setup


def worker(args, manifest):
    selection = manifest["selection"]
    # Crucially before importing torch, measuring setup, or constructing a model.
    guard = assert_quiescent(selection["blocked_primary_pids"])
    start, cpu = time.perf_counter(), time.process_time()
    execution, grid = frozen_api(selection["policy_root"])
    from runtime_backend import FixedQwen, LiveOracle
    indexes = args.indexes
    rows = [selection["schedule"][i] for i in indexes]
    needed = sorted({row["dataset"] for row in rows})
    out = args.results
    label = f'{rows[0]["phase"]}_{indexes[0]:03d}'
    setup, backend, completed, failure = {"guard": guard}, None, [], None
    deadline = min(time.monotonic()+args.remaining_seconds, args.deadline_monotonic)
    try:
        datasets, setup["dataset_setup"] = load_datasets(selection, needed)
        backend = FixedQwen(selection, {name: data["texts"] for name, data in datasets.items()}, deadline)
        # The complete fixed pack is operational setup, charged separately.
        backend.canaries()
        setup.update(backend=backend.setup, setup_wall_ms=1000*(time.perf_counter()-start),
                     setup_cpu_ms=1000*(time.process_time()-cpu))
        write_new(out/f"setup_{label}.json", setup)
        queries = {q["query"]["query_id"]: q for q in selection["selected"]}
        for index, row in zip(indexes, rows):
            result, oracle = None, None
            assert_quiescent(selection["blocked_primary_pids"], allowed_gpu_pid=os.getpid())
            if time.monotonic() >= deadline:
                failure = {"reason": "administrative_deadline_before_request", "next_index": index}; break
            query = queries[row["query_id"]]
            seed = query["seeds"]
            plan = execution.Plan(int(seed["pilot"]), int(seed["formal"]), int(seed["exploration"]),
                                  budget_override=query["budget"], semantics=query["semantics"], **selection["common_plan"])
            data = datasets[query["dataset"]]
            backend.reset()
            oracle = LiveOracle(backend, query["dataset"], query["predicate"], data["ids"], query["budget"])
            backend.torch.cuda.synchronize()
            before, process_cpu = time.perf_counter(), time.process_time()
            build = time.perf_counter()
            policy = grid.policy_for(row["method"], int(seed["planning"]),
                                     {"dual_greedy": {"gamma": 1., "epsilon": 1e-4}, "forecast": selection["forecast"]})
            policy_build_ms = 1000*(time.perf_counter()-build)
            result = execution.execute(query["query"]["contract"], data["snapshot"], oracle, data["proxy"], policy, plan,
                                       core_root=selection["core_root"], record_actions=True, record_cs_events=True,
                                       policy_spec={"name": row["method"], "runtime_revision": 1, "planning_seed": seed["planning"]})
            backend.torch.cuda.synchronize()
            query_wall_ms, query_cpu_ms = 1000*(time.perf_counter()-before), 1000*(time.process_time()-process_cpu)
            grid.result_invariants(result, oracle, query["support_size"], query["budget"])
            certificate = result["certificate"]
            physical = backend.export()
            if physical.get("physical_forward_attempts", 0) > len(oracle.attempted):
                raise RuntimeError("Physical forwards exceed submitted no-retry records")
            receipt = {"index": index, "schedule": row, "query_wall_ms": query_wall_ms, "query_cpu_ms": query_cpu_ms,
                       "policy_build_wall_ms": policy_build_ms, "backend_cost": physical, "forward_events": backend.events,
                       "result": result, "operator_reference_evaluated": False,
                       "measurement": "Actual new forward for each physically executed requested record; no label/KV cache"}
            writing = time.perf_counter()
            with gzip.open(out/f"run_{index:03d}.jsonl.gz", "xt", compresslevel=1, encoding="utf-8") as stream:
                stream.write(canonical(receipt)+"\n")
            completed.append({"index": index, "status": certificate["status"], "calls": certificate["semantic_calls"],
                              "physical_forwards": physical.get("physical_forward_attempts", 0), "query_wall_ms": query_wall_ms,
                              "receipt_write_wall_ms": 1000*(time.perf_counter()-writing)})
            atomic(out/f"progress_{label}.json", {"status": "running", "completed": completed})
            if certificate.get("framework_exception") or backend.disagreements or "collection window expired" in certificate.get("reason", ""):
                failure = {"reason": "framework_operator_or_deadline_failure", "index": index,
                           "framework_exception": certificate.get("framework_exception"), "certificate_reason": certificate.get("reason")}; break
    except Exception as exc:
        failure = {"reason": "worker_exception", "class": type(exc).__name__, "message": str(exc), "traceback": traceback.format_exc()}
        # Preserve partial forward evidence and attempts even on a failed batch.
        failed = {"failure": failure, "setup": setup, "completed": completed,
                  "backend_setup": backend.setup if backend is not None else None,
                  "backend_cost": backend.export() if backend is not None else None,
                  "forward_events": backend.events if backend is not None else [],
                  "attempted_record_ids": oracle.attempted if "oracle" in locals() and oracle is not None else [],
                  "result": result if "result" in locals() else None}
        with gzip.open(out/f"failure_{label}.json.gz", "xt", compresslevel=1, encoding="utf-8") as stream:
            stream.write(canonical(failed)+"\n")
    report = {"status": "complete" if len(completed) == len(rows) and not failure else "incomplete_preserved",
              "completed": completed, "failure": failure, "worker_wall_ms": 1000*(time.perf_counter()-start)}
    write_new(out/f"worker_{label}.json", report)
    return 0 if report["status"] == "complete" else 1


def run(args, manifest):
    selection = manifest["selection"]
    assert_quiescent(selection["blocked_primary_pids"])
    results = args.manifest.resolve().parent/"results"
    results.mkdir(exist_ok=False)
    started = time.monotonic(); measurements = []
    warm = [i for i, row in enumerate(selection["schedule"]) if row["phase"] == "warm"]
    cold = [[i] for i, row in enumerate(selection["schedule"]) if row["phase"] == "cold"]
    for indexes in [warm]+cold:
        assert_quiescent(selection["blocked_primary_pids"])
        effective_seconds = manifest["resource_deadline_amendment"]["effective_collection_seconds"]
        remaining = effective_seconds-(time.monotonic()-started)
        if remaining <= 0:
            break
        command = [sys.executable, "-B", str(Path(__file__).resolve()), "--mode", "worker", "--manifest", str(args.manifest.resolve()),
                   "--results", str(results), "--remaining-seconds", str(remaining),
                   "--deadline-monotonic", str(started+effective_seconds), "--indexes", *map(str, indexes)]
        env = dict(os.environ, **manifest["environment"])
        before, cpu = time.perf_counter(), time.process_time()
        forced_timeout = False
        with (results/f"worker_{indexes[0]:03d}.log").open("x") as log:
            try:
                child = subprocess.run(command, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=remaining+1)
                returncode = child.returncode
            except subprocess.TimeoutExpired:
                # subprocess.run terminates the child. Completed receipts stay;
                # an in-flight uncheckpointed tail is explicitly unknown, not0.
                returncode, forced_timeout = -9, True
        measurements.append({"indexes": indexes, "process_wall_ms": 1000*(time.perf_counter()-before),
                             "parent_cpu_ms": 1000*(time.process_time()-cpu), "returncode": returncode,
                             "forced_timeout": forced_timeout, "uncheckpointed_physical_work_unknown": forced_timeout})
        atomic(results/"process_measurements.json", measurements)
        if returncode:
            break
    written = sorted(int(p.name.split("_")[1].split(".")[0]) for p in results.glob("run_*.jsonl.gz"))
    missing = sorted(set(range(len(selection["schedule"]))) - set(written))
    failed_process = any(item["returncode"] != 0 for item in measurements)
    report = {"status": "complete_pending_reference_audit" if not missing and not failed_process else "incomplete_or_invalid_preserved",
              "manifest_sha256": sha(args.manifest), "completed_indexes": written, "missing_planned_indexes": missing,
              "elapsed_seconds": time.monotonic()-started, "process_measurements": measurements,
              "planned_executions": len(selection["schedule"]), "automatic_reference_audit": False,
              "no_replacement_or_query_selection": True}
    write_new(results/"collection_completion.json", report)
    print(json.dumps(report, indent=2))
    return 0 if not missing and not failed_process else 1


def read_reference(path, population):
    path = Path(path)
    if path.suffix == ".csv":
        with path.open(newline="") as stream:
            rows = list(csv.DictReader(stream))
        labels = {r["record_id"]: int(r["model_label"]) for r in rows}
        if len(rows) != len(labels):
            raise RuntimeError("Duplicate record ID in model reference")
    else:
        labels = json.loads(path.read_text())
    if set(labels) != population or any(type(v) is not int or v not in (0, 1) for v in labels.values()):
        raise RuntimeError("Reference map is not a complete fixed binary population")
    return labels


def audit(args, manifest):
    # Includes measured CPU materialized lookups, so respects the same idle rule.
    selection = manifest["selection"]
    assert_quiescent(selection["blocked_primary_pids"])
    execution, grid = frozen_api(selection["policy_root"])
    root = args.manifest.resolve().parent/"results"
    if (root/"audit.json").exists():
        raise FileExistsError("Retain the previous audit; do not overwrite")
    datasets, _ = load_datasets(selection, list(selection["datasets"]))
    references = {}
    for dataset, maps in manifest["references"].items():
        for pred, path in maps.items():
            if sha(path) != manifest["reference_sha256"][dataset][pred]:
                raise RuntimeError("Fixed model-reference bytes changed")
            references[dataset, pred] = read_reference(path, datasets[dataset]["ids"])
    queries = {q["query"]["query_id"]: q for q in selection["selected"]}
    rows, missing, operator_drift, framework_failures = [], [], [], []
    for index, planned in enumerate(selection["schedule"]):
        query = queries[planned["query_id"]]
        path = root/f"run_{index:03d}.jsonl.gz"
        if not path.exists():
            missing.append(index); rows.append({"index": index, **planned, "status": "administrative_missing", "correct_complete": False,
                                               "conservative_cap_charge": planned["budget"], "time_to_correct_completion": None}); continue
        with gzip.open(path, "rt") as stream:
            receipt = json.loads(stream.readline())
        labels = references[query["dataset"], query["predicate"]]
        result = receipt["result"]
        if result["certificate"].get("framework_exception"):
            framework_failures.append(index)
        observed = result["observed_labels"]
        drift = [rid for rid, value in observed.items() if labels[rid] != value]
        # Physically completed but uncommitted failure tails are also checked.
        drift += [event["record_id"] for event in receipt["forward_events"] if event["status"] == "complete" and event["label"] != labels[event["record_id"]]]
        drift = sorted(set(drift))
        evaluation = grid.reference_evaluation(query["query"]["contract"], datasets[query["dataset"]]["snapshot"], labels, result["certificate"])
        if drift:
            operator_drift.append({"index": index, "record_ids": drift})
        correct = evaluation["correct_complete"] and not drift
        rows.append({"index": index, **planned, "status": result["certificate"]["status"], "correct_complete": bool(correct),
                     "query_wall_ms": receipt["query_wall_ms"], "query_cpu_ms": receipt["query_cpu_ms"],
                     "semantic_calls": result["certificate"]["semantic_calls"], "backend_cost": receipt["backend_cost"],
                     "reference_evaluation": evaluation, "operator_disagreements": drift,
                     "conservative_cap_charge": planned["budget"] if drift or evaluation["source_error"] or result["certificate"]["status"] == "execution_error" else result["certificate"]["semantic_calls"],
                     "time_to_correct_completion": receipt["query_wall_ms"] if correct else None})
    # Exact materialized lookup work uses the same checker, with a full support
    # lookup. It performs ZERO new Qwen forwards; its build cost is separate.
    lookups = []
    for query in selection["selected"]:
        dataset = datasets[query["dataset"]]
        labels = references[query["dataset"], query["predicate"]]
        oracle = grid.SealedReplay(labels, dataset["ids"], query["support_size"])
        config = dict(selection["common_plan"]); config["tiny_scan_max"] = query["support_size"]
        seed = query["seeds"]
        plan = execution.Plan(int(seed["pilot"]), int(seed["formal"]), int(seed["exploration"]),
                              budget_override=query["support_size"], semantics=query["semantics"], **config)
        policy = grid.policy_for("matched", int(seed["planning"]), {"dual_greedy": {"gamma": 1., "epsilon": 1e-4}, "forecast": selection["forecast"]})
        result = execution.execute(query["query"]["contract"], dataset["snapshot"], oracle, None, policy, plan,
                                   core_root=selection["core_root"], record_actions=False, record_cs_events=False,
                                   policy_spec={"name": "exact_materialized_lookup", "new_model_forwards": 0})
        evaluation = grid.reference_evaluation(query["query"]["contract"], dataset["snapshot"], labels, result["certificate"])
        lookups.append({"query_id": query["query"]["query_id"], "dataset": query["dataset"], "lookup_wall_ms": result["total"]["wall_ms"],
                        "lookup_cpu_ms": result["total"]["cpu_ms"], "rows_looked_up": result["certificate"]["semantic_calls"],
                        "new_model_forwards": 0, "correct_complete": evaluation["correct_complete"]})
    result = {"status": "complete" if not missing and not operator_drift and not framework_failures else "incomplete_or_invalid",
              "all_planned_denominator": len(rows), "correct_complete": sum(r["correct_complete"] for r in rows),
              "rows": rows, "missing_indexes": missing, "operator_disagreements": operator_drift,
              "framework_failure_indexes": framework_failures,
              "materialized_lookup_rows": lookups,
              "break_even_equation": "S_online + m*mean_online_cost vs S_materialized + m*mean_exact_lookup; crossing=(S_materialized-S_online)/(mean_online_cost-mean_lookup). Report achieved completion beside costs; no claim of equal utility when online withholds.",
              "materialization_cost_input": manifest["materialization_costs"],
              "materialization_build_note": "Reuse the already performed pinned 120k label build only with its complete verified cost ledger; do not call map lookup free cold setup. No new full scan was performed here.",
              "scope": "Small metadata-stratified runtime audit, not broad superiority; one sampling realization per query and three chronological windows"}
    if manifest["materialization_costs"]:
        if sha(manifest["materialization_costs"]) != manifest["materialization_costs_sha256"]:
            raise RuntimeError("Supplied materialization cost ledger changed")
        costs = json.loads(Path(manifest["materialization_costs"]).read_text())
        result["materialization_cost_ledger"] = costs
        # Required caller-supplied end-to-end startup numbers have explicit
        # provenance; do not infer them from a partial/resumed build session.
        if "mixed_materialization_total_wall_ms" in costs and "online_shared_startup_wall_ms" in costs and not missing and not operator_drift and not framework_failures:
            mean_lookup = sum(row["lookup_wall_ms"] for row in lookups)/len(lookups)
            result["break_even_by_method"] = {}
            for method in ("matched", "dual_greedy", "forecast"):
                records = [r for r in rows if r["phase"] == "warm" and r["method"] == method]
                if len(records) == len(selection["selected"]):
                    entry = break_even(costs["online_shared_startup_wall_ms"], costs["mixed_materialization_total_wall_ms"],
                                       sum(r["query_wall_ms"] for r in records)/len(records), mean_lookup)
                    entry["observed_correct_complete_fraction"] = sum(r["correct_complete"] for r in records)/len(records)
                    entry["materialized_correct_complete_fraction"] = sum(r["correct_complete"] for r in lookups)/len(lookups)
                    result["break_even_by_method"][method] = entry
    write_new(root/"audit.json", result)
    print(json.dumps({k: result[k] for k in ("status", "all_planned_denominator", "correct_complete", "missing_indexes", "operator_disagreements")}, indent=2))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--mode", choices=("dry-run", "freeze", "run", "worker", "audit"), default="dry-run")
    p.add_argument("--selection", type=Path, default=HERE/"DRAFT_SELECTION.json")
    p.add_argument("--manifest", type=Path)
    p.add_argument("--expect-manifest-sha256")
    p.add_argument("--reference-paths", type=Path, help="Metadata index dataset -> predicate -> map filename")
    p.add_argument("--materialization-costs", type=Path)
    p.add_argument("--token-costs", type=Path, default=HERE/"TOKEN_COSTS.json")
    p.add_argument("--out", type=Path)
    p.add_argument("--results", type=Path)
    p.add_argument("--indexes", type=int, nargs="+")
    p.add_argument("--remaining-seconds", type=float)
    p.add_argument("--deadline-monotonic", type=float)
    a = p.parse_args()
    if a.mode in ("run", "worker", "audit"):
        if a.manifest is None:
            p.error("--manifest is required for an explicit later execution/audit")
        manifest = load_manifest(a.manifest, a.expect_manifest_sha256)
        if a.mode == "run":
            return run(a, manifest)
        if a.mode == "worker":
            if not a.indexes or a.results is None or a.remaining_seconds is None or a.deadline_monotonic is None:
                p.error("Internal worker arguments are incomplete")
            return worker(a, manifest)
        audit(a, manifest); return 0
    selection = json.loads(a.selection.read_text())
    verify_inputs(selection)
    if a.mode == "freeze":
        freeze(a, selection); return 0
    print(json.dumps({"status": "dry_run_only", "selection_sha256": sha(a.selection), "counts": selection["counts"],
                      "historical_planning_only": selection["historical_planning_only"], "policy_root": selection["policy_root"],
                      "target_maps_opened_or_hashed": False, "torch_imported": "torch" in sys.modules,
                      "model_weights_loaded": False, "physical_forwards": 0, "no_schedule_or_wait_created": True}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
