#!/usr/bin/env python3
"""Commit a metadata-only timing set; no labels, model, CUDA or timing runs."""
from __future__ import annotations
import argparse
from itertools import permutations
import json
import math
from pathlib import Path
import secrets
import sys

from runtime_common import digest, frozen_api, sha, utc, write_new

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parent
SALT = "cohortcert-real-query-runtime-v1-20261102-metadata-only"
STRATA = (("civil_pair", "toxicity", "pairwise", None, 0),
          ("civil_equiv", "insult", "equivalence", None, 0),
          ("civil_dominance", "identity_attack", "summary", "dominance_3", 1),
          ("civil_mixed", "obscene", "summary", "mixed_3", 0),
          ("civil_rank", "toxicity", "ranking", None, 0))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--civil", type=Path, default=PROJECT/"natural_overlap")
    p.add_argument("--airline", type=Path, default=Path("/root/autodl-tmp/cohortcert_revision_20261101/airline_validation"))
    p.add_argument("--policy-root", type=Path, default=PROJECT/"policy_freeze_v1")
    p.add_argument("--core-root", type=Path, default=Path("/dev/shm/CohortCert_fixed_label_replay_20261031"))
    p.add_argument("--model-dir", type=Path, default=Path("/root/autodl-tmp/models/Qwen3-8B-b968826d9c46"))
    p.add_argument("--out", type=Path, default=HERE/"DRAFT_SELECTION.json")
    a = p.parse_args()
    if a.out.exists():
        raise FileExistsError("Retain the committed query IDs/seeds; never reroll after outcomes")
    execution, grid = frozen_api(a.policy_root)
    from common import core_module
    civil_queries = {q["query_id"]: q for q in grid.load_queries(a.civil/"queries_before_annotation_access.jsonl")}
    metadata = [json.loads(line) for line in (a.civil/"metadata_coefficient_cells.jsonl").read_text().splitlines()]
    selected = []
    for label, pred, kind, subtype, quartile in STRATA:
        eligible = sorted((q for q in metadata if q["predicate_id"] == f"civilcomments_{pred}_v1" and q["kind"] == kind
                           and (subtype is None or q.get("summary_subtype") == subtype)), key=lambda q: (q["support_size"], q["query_id"]))
        stratum = eligible[len(eligible)*quartile//4:len(eligible)*(quartile+1)//4]
        chosen = min(stratum, key=lambda q: digest([SALT, label, q["query_id"]]))
        query = civil_queries[chosen["query_id"]]
        selected.append({"selection_label": label, "dataset": "civil", "predicate": pred,
                         "query": query, "support_size": chosen["support_size"], "quartile": quartile,
                         "metadata_candidates": len(eligible), "eligible_stratum_size": len(stratum)})
    airline_queries = {q["query_id"]: q for q in grid.load_queries(a.airline/"queries.jsonl")}
    airline_query = airline_queries["airline-0150"]  # Original pre-outcome smoke selection, not a completed-case selection.
    snapshot = core_module(a.core_root, "query.parquet_snapshot").ParquetSnapshot(a.airline/"data/cohorts/airline_snapshot.parquet")
    matrix, _ = core_module(a.core_root, "query.compiler").compile_signed_decisions(airline_query["contract"], snapshot)
    selected.append({"selection_label": "old_airline_context", "dataset": "airline", "predicate": "negative_sentiment",
                     "query": airline_query, "support_size": len(matrix.rows_with_any_nonzero_coefficient()),
                     "selection_scope": "Previously examined population; fixed original smoke ID, no new-corpus inference"})
    selected.sort(key=lambda q: digest([SALT, "window-order", q["query"]["query_id"]]))
    orders = list(permutations(("matched", "dual_greedy", "forecast")))
    used = set()
    seeds = []
    for q in selected:
        record = {}
        for name in ("pilot", "formal", "planning", "exploration"):
            value = secrets.randbits(256)
            while value in used:
                value = secrets.randbits(256)
            used.add(value); record[name] = str(value)
        seeds.append(record)
    schedule = []
    for i, q in enumerate(selected):
        q["budget"] = math.ceil(q["support_size"]/2)
        q["semantics"] = "positive_only" if q["query"]["kind"] == "ranking" else "bidirectional"
        q["seeds"] = seeds[i]
        q["window"] = i//2
        methods = list(orders[i])
        if q["query"]["kind"] == "ranking":
            methods.insert(0 if q["dataset"] == "civil" else 3, "boundary")
        for pos, method in enumerate(methods):
            schedule.append({"phase": "warm", "window": i//2, "query_id": q["query"]["query_id"],
                             "dataset": q["dataset"], "method": method, "position": pos, "budget": q["budget"]})
    cold = next(q for q in selected if q["selection_label"] == "civil_pair")
    cold_order = min(orders, key=lambda order: digest([SALT, "cold-order", order]))
    for pos, method in enumerate(cold_order):
        schedule.append({"phase": "cold", "window": 3, "query_id": cold["query"]["query_id"], "dataset": "civil",
                         "method": method, "position": pos, "budget": cold["budget"]})
    datasets = {
        "civil": {"metadata": str(a.civil/"metadata_only_snapshot.parquet"), "texts": str(a.civil/"text_metadata_snapshot.parquet"),
                  "features": str(a.civil/"data/embeddings"), "feature_prefix": "civilcomments",
                  "operator": str(a.civil/"label_build_plan_with_scenario_seeds_before_annotation_access.json"),
                  "token_metadata": str(a.civil/"qwen_dry_run_20261102/model_build_dry_run.json"),
                  "reference_paths": {p: str(a.civil/f"qwen_four_predicate_labels_v1/{p}/model_labels_{p}_v1.json")
                                      for p in ("toxicity", "insult", "identity_attack", "obscene")}},
        "airline": {"metadata": str(a.airline/"data/cohorts/airline_snapshot.parquet"), "texts": str(a.airline/"private_text_snapshot.parquet"),
                    "features": str(a.airline/"data/embeddings"), "feature_prefix": "airline", "operator": str(a.airline/"protocol.json"),
                    "reference_paths": {"negative_sentiment": str(a.airline/"model_predictions.csv")}}}
    inputs = {}
    for dataset, spec in datasets.items():
        files = {key: spec[key] for key in ("metadata", "texts", "operator")}
        files.update(features=str(Path(spec["features"])/(spec["feature_prefix"]+"_emb.npy")),
                     feature_index=str(Path(spec["features"])/(spec["feature_prefix"]+"_index.parquet")))
        inputs[dataset] = {key: {"path": path, "sha256": sha(path)} for key, path in files.items()}
    civil_tokens = json.loads(Path(datasets["civil"]["token_metadata"]).read_text())["input_preflight"]
    operator = json.loads(Path(datasets["civil"]["operator"]).read_text())
    manifest_path = a.civil/operator["model"]["expected_file_manifest"]
    warm_calls = sum(row["budget"] for row in schedule if row["phase"] == "warm")
    cold_calls = sum(row["budget"] for row in schedule if row["phase"] == "cold")
    by_id = {q["query"]["query_id"]: q for q in selected}
    mean_tokens = 0
    for row in schedule:
        q = by_id[row["query_id"]]
        mean = civil_tokens[q["predicate"]]["input_tokens_total"]/30000 if q["dataset"] == "civil" else 1458180/14640
        mean_tokens += row["budget"]*mean
    plan = {"schema": "cohortcert.real-runtime-revision-v1", "status": "DRAFT_NOT_EXECUTABLE", "created_utc": utc(),
            "selection_salt": SALT, "selection_rule": "Fixed predicate/family/subtype/support-quartile strata; minimum salted metadata-only hash; no labels, reference margins, completed cases or query outcomes consulted",
            "selected": selected, "schedule": schedule, "datasets": datasets, "input_identity": inputs,
            "policy_root": str(a.policy_root.resolve()), "policy_freeze_manifest_sha256": sha(a.policy_root/"SOURCE_SHA256.json"),
            "primary_spec_sha256": sha(a.policy_root/"primary_run_spec_v1.json"), "core_root": str(a.core_root.resolve()),
            "model_dir": str(a.model_dir.resolve()), "model_expected_manifest": str(manifest_path), "model_expected_manifest_sha256": sha(manifest_path),
            "counts": {"selected_queries": len(selected), "warm_executions": sum(r["phase"] == "warm" for r in schedule),
                       "cold_executions": sum(r["phase"] == "cold" for r in schedule), "warm_max_requested_forwards": warm_calls,
                       "cold_max_requested_forwards": cold_calls, "corpus_max_requested_forwards": warm_calls+cold_calls,
                       "setup_canaries_per_model_process": 32+16, "model_processes": 4},
            "historical_planning_only": {"airline_record_seconds": 353.6496424879879/14640,
                                         "airline_tokens_per_second": 1458180/353.6496424879879,
                                         "estimated_tokens_using_global_predicate_means": mean_tokens,
                                         "token_linear_minutes": mean_tokens/(1458180/353.6496424879879)/60,
                                         "not_new_measurement": True,
                                         "scope": "Mean token counts are label-blind corpus metadata; no guarantee that adaptive reads have this token distribution or throughput"},
            "max_collection_seconds": 7200, "blocked_primary_pids": [73397],
            "busy_guard": "No timing when named PID exists, build_qwen_labels.py --mode full/run_grid.py --mode execute exists, or any other GPU compute process exists; fail immediately, no wait/scheduling",
            "cold_regime": "Fresh Python/CUDA/model process with potentially warm OS filesystem cache; persistent model files; model verification/load, metadata/features load, canaries, policy build and full query all charged",
            "feature_build_regime": "Existing immutable label-blind feature assets are loaded; actual feature-construction cost is separately charged from its source receipt or an explicit later quiescent rebuild. No physical-storage cold claim.",
            "forecast": {"grid_points": 6, "time_limit": .05, "replan_steps": 8, "max_wall_seconds": .15, "max_cells": 256},
            "common_plan": {"alpha_override": .05, "requested_bins": 1, "max_cells": 256, "pilot_cap": 256, "initial_batch": 8,
                            "batch_size": 16, "explore_every": 4, "prior_weight": .5, "prior_strength": 20, "tiny_scan_max": 128},
            "comparison": "Same frozen primary engine and policies for all arms. Three fixed chronological windows, complete method groups; all six primary-method permutations used once. One sampling seed pair per query, no timing-repeat precision claim.",
            "source_sha256_at_selection": {p.name: sha(p) for p in sorted(HERE.glob("*.py"))},
            "target_maps_accessed": False, "model_weights_loaded": False, "new_model_forwards": 0}
    write_new(a.out, plan)
    print(json.dumps({"selection": str(a.out), "sha256": sha(a.out), "counts": plan["counts"],
                      "historical_planning_only": plan["historical_planning_only"],
                      "selected": [{"id": q["query"]["query_id"], "stratum": q["selection_label"], "support": q["support_size"], "cap": q["budget"], "window": q["window"]} for q in selected],
                      "target_maps_accessed": False, "model_forwards": 0}, indent=2))


if __name__ == "__main__":
    main()
