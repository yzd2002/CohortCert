"""Exact single-record fixed-builder scoring path, with no label/KV cache."""
from __future__ import annotations
from collections import defaultdict
import hashlib
import math
import os
from pathlib import Path
import time

from runtime_common import sha


class DeadlineExceeded(RuntimeError):
    pass


def operator_specs(selection):
    import json
    civil = json.loads(Path(selection["datasets"]["civil"]["operator"]).read_text())
    airline = json.loads(Path(selection["datasets"]["airline"]["operator"]).read_text())
    result = {("civil", p): {"prompt": civil["prompts"][p], "canaries": civil["canaries"][p], "canary_repeats": 2}
              for p in civil["predicate_order"]}
    result["airline", "negative_sentiment"] = {
        "prompt": airline["model"]["prompt"], "canary_repeats": 8,
        "canaries": [{"id": "airline-positive", "text": "Thank you airline for a wonderful flight and excellent service!", "expected_label": 0},
                     {"id": "airline-negative", "text": "Terrible airline. They canceled my flight and refused to help.", "expected_label": 1}]}
    return civil["model"], result


def verify_model_files(model_dir, expected):
    expected_names = {row["name"] for row in expected["files"]}
    for path in Path(model_dir).iterdir():
        override = path.suffix in (".safetensors", ".bin", ".model", ".jinja") or path.name in ("added_tokens.json", "special_tokens_map.json", "chat_templates")
        if override and path.name not in expected_names:
            raise ValueError("Unpinned model/tokenizer override: "+path.name)
    for row in expected["files"]:
        path = Path(model_dir)/row["name"]
        if not path.is_file() or path.stat().st_size != row["bytes"] or sha(path) != row["sha256"]:
            raise ValueError("Pinned model verification failed: "+row["name"])


class FixedQwen:
    def __init__(self, selection, texts, deadline):
        import json
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer
        self.torch, self.texts, self.deadline = torch, texts, deadline
        self.model_spec, self.operators = operator_specs(selection)
        self.seen, self.disagreements = {}, []
        self.setup = {}
        if os.environ.get("PYTHONHASHSEED") != "0" or os.environ.get("CUBLAS_WORKSPACE_CONFIG") != ":4096:8":
            raise ValueError("Launch the fresh worker with the frozen hash/CUBLAS environment")
        if self.model_spec["dtype"] != "bfloat16" or self.model_spec["batch_size"] != 1 or self.model_spec["attention"] != "sdpa" or self.model_spec["use_cache"] is not False:
            raise ValueError("Fixed materialization operator configuration changed")
        torch.set_num_threads(1); torch.set_num_interop_threads(1)
        torch.manual_seed(self.model_spec["seed"]); torch.cuda.manual_seed_all(self.model_spec["seed"])
        torch.use_deterministic_algorithms(True)
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = False
        torch.backends.cudnn.benchmark = False
        torch.cuda.set_device("cuda:0")
        expected = json.loads(Path(selection["model_expected_manifest"]).read_text())
        before, cpu = time.perf_counter(), time.process_time()
        verify_model_files(selection["model_dir"], expected)
        self.setup["model_verification_wall_ms"] = 1000*(time.perf_counter()-before)
        self.setup["model_verification_cpu_ms"] = 1000*(time.process_time()-cpu)
        before, cpu = time.perf_counter(), time.process_time()
        self.tokenizer = AutoTokenizer.from_pretrained(selection["model_dir"], local_files_only=True, trust_remote_code=False)
        self.model = AutoModelForCausalLM.from_pretrained(
            selection["model_dir"], local_files_only=True, trust_remote_code=False, use_safetensors=True,
            dtype=torch.bfloat16, device_map={"": "cuda:0"}, attn_implementation="sdpa")
        self.model.eval(); self.model.config.use_cache = False
        torch.cuda.synchronize()
        self.setup.update(model_load_wall_ms=1000*(time.perf_counter()-before), model_load_cpu_ms=1000*(time.process_time()-cpu),
                          gpu=torch.cuda.get_device_name(0), cuda=torch.version.cuda,
                          batch_size=1, use_cache=False, dtype="bfloat16", attention="sdpa")
        self.ids = {key: self.tokenizer.encode(key, add_special_tokens=False) for key in ("0", "1")}
        if any(len(v) != 1 for v in self.ids.values()) or self.ids["0"] == self.ids["1"]:
            raise ValueError("Frozen 0/1 next-token encoding failed")
        self.ids = {k: v[0] for k, v in self.ids.items()}
        self.reset()

    def reset(self):
        self.cost, self.events = defaultdict(float), []
        self.torch.cuda.reset_peak_memory_stats()

    def score_text(self, dataset, predicate, rid, text):
        if time.monotonic() >= self.deadline:
            raise DeadlineExceeded("Predeclared total collection window expired before this forward")
        torch = self.torch
        started, cpu = time.perf_counter(), time.process_time()
        prompt = self.operators[dataset, predicate]["prompt"].format(text=text)
        formatted = self.tokenizer.apply_chat_template([{"role": "user", "content": prompt}],
                    tokenize=False, add_generation_prompt=True, enable_thinking=False)
        inputs = self.tokenizer(formatted, return_tensors="pt", add_special_tokens=False, truncation=False)
        n = int(inputs["input_ids"].shape[-1])
        self.cost["tokenize_wall_ms"] += 1000*(time.perf_counter()-started)
        if n > self.model_spec["max_context_tokens"]:
            raise RuntimeError("Context overflow; no truncation/replacement is permitted")
        transfer = time.perf_counter()
        inputs = {k: v.to("cuda:0") for k, v in inputs.items()}
        self.cost["transfer_submit_wall_ms"] += 1000*(time.perf_counter()-transfer)
        event = {"dataset": dataset, "predicate": predicate, "record_id": rid, "input_tokens": n,
                 "formatted_input_sha256": hashlib.sha256(formatted.encode()).hexdigest(), "status": "forward_attempted"}
        self.events.append(event)
        self.cost["physical_forward_attempts"] += 1
        self.cost["input_tokens_submitted"] += n
        a, b = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
        a.record(torch.cuda.current_stream("cuda:0"))
        with torch.inference_mode():
            logits = self.model(**inputs, use_cache=False, logits_to_keep=1).logits[0, -1]
        b.record(torch.cuda.current_stream("cuda:0")); b.synchronize()
        zero, one = float(logits[self.ids["0"]].item()), float(logits[self.ids["1"]].item())
        if not math.isfinite(zero) or not math.isfinite(one):
            raise RuntimeError("Nonfinite fixed-operator logits")
        value, gpu_ms = int(one >= zero), a.elapsed_time(b)
        event.update(status="complete", label=value, logit_0=zero, logit_1=one, cuda_forward_ms=gpu_ms)
        self.cost["physical_forward_completions"] += 1
        self.cost["cuda_forward_ms"] += gpu_ms
        self.cost["score_wall_ms"] += 1000*(time.perf_counter()-started)
        self.cost["score_cpu_ms"] += 1000*(time.process_time()-cpu)
        key = dataset, predicate, rid
        if key in self.seen and self.seen[key] != value:
            self.disagreements.append({"dataset": dataset, "predicate": predicate, "record_id": rid,
                                       "previous": self.seen[key], "current": value})
            raise RuntimeError("Fixed-operator repeat changed label; retain and stop, never reuse prior label")
        self.seen[key] = value  # Diagnostic only, consulted AFTER every new forward.
        return value

    def canaries(self):
        before = time.perf_counter()
        results = []
        for (dataset, pred), spec in self.operators.items():
            for repeat in range(spec["canary_repeats"]):
                for canary in spec["canaries"]:
                    rid = f'canary:{canary["id"]}'
                    value = self.score_text(dataset, pred, rid, canary["text"])
                    results.append({"dataset": dataset, "predicate": pred, "id": canary["id"],
                                    "repeat": repeat, "expected": canary["expected_label"], "actual": value})
                    if value != canary["expected_label"]:
                        self.setup["canaries"] = results
                        raise RuntimeError("A fixed builder canary failed; no corpus timing permitted")
        self.setup.update(canaries=results, canary_wall_ms=1000*(time.perf_counter()-before), canary_cost=dict(self.cost))
        self.reset()

    def export(self):
        return {**dict(self.cost), "peak_allocated_bytes": self.torch.cuda.max_memory_allocated(),
                "peak_reserved_bytes": self.torch.cuda.max_memory_reserved(), "repeat_disagreements": list(self.disagreements)}


class LiveOracle:
    def __init__(self, backend, dataset, predicate, population_ids, budget):
        self.backend, self.dataset, self.predicate = backend, dataset, predicate
        self.population, self.budget = population_ids, budget
        self.attempted, self.invariant_failure = [], None

    def read(self, ids):
        ids = list(ids)
        if len(ids) != len(set(ids)) or set(ids).intersection(self.attempted) or not set(ids) <= self.population or len(self.attempted)+len(ids) > self.budget:
            self.invariant_failure = "Independent live oracle support/unique/cap violation"
            raise RuntimeError(self.invariant_failure)
        self.attempted.extend(ids)  # Charge the submitted batch, including any unexecuted failure tail.
        return {rid: self.backend.score_text(self.dataset, self.predicate, rid, self.backend.texts[self.dataset][rid]) for rid in ids}
