"""Finite fake-backend/guard fixtures only; no real forward, labels or timing."""
from __future__ import annotations
from pathlib import Path
import sys
import unittest

from runtime_common import frozen_api, process_blockers
from runtime_backend import DeadlineExceeded, LiveOracle, operator_specs

HERE = Path(__file__).resolve().parent
execution, grid = frozen_api(HERE.parent/"policy_freeze_v1")
from common import core_module
CORE = Path("/dev/shm/CohortCert_fixed_label_replay_20261031")


class FakeBackend:
    def __init__(self, labels, fail_after=None):
        self.labels, self.fail_after = labels, fail_after
        self.texts = {"synthetic": {rid: "synthetic text" for rid in labels}}
        self.calls = []

    def score_text(self, dataset, predicate, rid, text):
        if self.fail_after is not None and len(self.calls) >= self.fail_after:
            raise DeadlineExceeded("Predeclared total collection window expired before this forward")
        self.calls.append(rid)
        return self.labels[rid]


def request():
    return {"snapshot_id": "synthetic", "predicate_id": "synthetic_v1", "risk": {"alpha": .05},
            "budget": {"max_oracle_record_predicate_calls": 8}, "population_scope": "eight synthetic records",
            "cohorts": [{"id": "a", "record_ids": [f"r{i}" for i in range(4)]},
                        {"id": "b", "record_ids": [f"r{i}" for i in range(4, 8)]}],
            "decisions": [{"type": "compare", "left": "a", "right": "b", "threshold": 0, "unit": "proportion_difference"}]}


class RuntimeTests(unittest.TestCase):
    def test_cost_crossing_is_a_cost_equation_not_a_completion_claim(self):
        from run_runtime import break_even
        cost = break_even(1000, 2000, 100, 10)
        self.assertAlmostEqual(cost["crossing_requests"], 1000/90)
        self.assertFalse(cost["is_latency_or_utility_superiority_claim"])
        self.assertIsNone(break_even(1000, 2000, 10, 10)["crossing_requests"])
        import json
        from runtime_common import sha
        amendment = json.loads((HERE/"RESOURCE_DEADLINE_AMENDMENT.json").read_text())
        self.assertEqual(amendment["effective_collection_seconds"], 10800)
        self.assertEqual(amendment["selection_sha256"], sha(HERE/"DRAFT_SELECTION.json"))

    def test_guards_cover_primary_replication_and_project_analysis(self):
        project, runtime = Path("/research/project"), Path("/research/project/runtime_revision_v1")
        processes = [(10, ["python", "/x/build_qwen_labels.py", "--mode", "full"]),
                     (11, ["python", "/x/run_grid.py", "--mode", "execute"]),
                     (12, ["python", "/x/run_replication.py", "--mode", "execute"]),
                     (13, ["python", "/research/project/offline_oracle/run_oracle.py"]),
                     (14, ["python", "-c", "sys.path.insert(0,'/research/project'); analyze()"]),
                     (15, ["python", "/research/project/runtime_revision_v1/run_runtime.py", "--mode", "worker", "--manifest", "/research/project/elsewhere/manifest.json"]),
                     (16, ["python", "/unrelated/read.py"]), (73397, [])]
        self.assertEqual({b["pid"] for b in process_blockers(processes, {73397}, project, runtime)}, {10,11,12,13,14,73397})

    def test_no_cross_request_label_reuse(self):
        labels = {"a": 1, "b": 0}; backend = FakeBackend(labels)
        for _ in range(2):
            oracle = LiveOracle(backend, "synthetic", "p", set(labels), 2)
            self.assertEqual(oracle.read(["a", "b"]), labels)
        self.assertEqual(backend.calls, ["a", "b", "a", "b"])

    def test_same_frozen_engine_counts_physical_work_and_submissions(self):
        labels = {f"r{i}": int(i < 4) for i in range(8)}
        backend = FakeBackend(labels)
        oracle = LiveOracle(backend, "synthetic", "p", set(labels), 8)
        snapshot = core_module(CORE, "query.snapshot").MemorySnapshot({rid: {} for rid in labels})
        policy = grid.policy_for("matched", 4, {"dual_greedy": {"gamma": 1., "epsilon": 1e-4}, "forecast": {}})
        result = execution.execute(request(), snapshot, oracle, None, policy, execution.Plan(1,2,3,budget_override=8), core_root=CORE)
        self.assertTrue(grid.result_invariants(result, oracle, 8, 8))
        self.assertEqual(result["certificate"]["status"], "complete")
        self.assertEqual(len(backend.calls), len(oracle.attempted))
        self.assertEqual(len(backend.calls), 8)

    def test_failed_batch_retains_charge_and_uncommitted_physical_prefix(self):
        labels = {f"r{i}": int(i < 4) for i in range(8)}
        backend = FakeBackend(labels, fail_after=1)
        oracle = LiveOracle(backend, "synthetic", "p", set(labels), 8)
        snapshot = core_module(CORE, "query.snapshot").MemorySnapshot({rid: {} for rid in labels})
        policy = grid.policy_for("matched", 4, {"dual_greedy": {"gamma": 1., "epsilon": 1e-4}, "forecast": {}})
        result = execution.execute(request(), snapshot, oracle, None, policy, execution.Plan(1,2,3,budget_override=8), core_root=CORE)
        self.assertTrue(grid.result_invariants(result, oracle, 8, 8))
        self.assertEqual(result["certificate"]["semantic_calls"], 8)
        self.assertEqual(result["certificate"]["status"], "execution_error")
        self.assertEqual(len(backend.calls), 1)
        self.assertEqual(result["observed_labels"], {})

    def test_fixed_operator_pack_uses_builder_prompts_and_canaries(self):
        import json
        selection = json.loads((HERE/"DRAFT_SELECTION.json").read_text())
        model, specs = operator_specs(selection)
        self.assertEqual(model["batch_size"], 1)
        self.assertFalse(model["use_cache"])
        self.assertEqual(sum(len(s["canaries"])*s["canary_repeats"] for s in specs.values()), 48)
        self.assertEqual(specs["civil", "toxicity"]["prompt"], json.loads(Path(selection["datasets"]["civil"]["operator"]).read_text())["prompts"]["toxicity"])
        self.assertEqual(specs["airline", "negative_sentiment"]["canary_repeats"], 8)


if __name__ == "__main__":
    unittest.main(verbosity=2)
