"""Independent ledger/prefix/CS audit of saved raw traces; no engine imports."""
from fractions import Fraction
from collections import Counter
import math,random
from reference import F,canonical,digest,require

def ideal_accepts(event,K):
    N,n,s=event['N'],event['n'],event['s'];a,b=event['a'],event['b']
    if int(a)!=a or int(b)!=b:return None
    a,b=int(a),int(b);lam=F(event['lam']);alpha=Fraction.from_float(float(event['alpha']))
    if not s<=K<=N-n+s:return False
    base=Fraction(1,(n+1)*math.comb(n,s))
    proxy=Fraction(math.comb(s+a-1,a-1)*math.comb(n-s+b-1,b-1),math.comb(n+a+b-1,a+b-1)*math.comb(n,s))
    q=(1-lam)*base+lam*proxy;p=Fraction(math.comb(N-n,K-s),math.comb(N,K))
    return bool(q*alpha<p)
def audit_trace(ref,manifest,payload,detail=False):
    source,qid=payload['source'],payload['query_id'];comp=ref.compiled[qid];result=payload['result'];c=result['certificate']
    labels=ref.labels[source][comp['predicate']];plan=manifest['common_plan'];seed=next(x for x in manifest['seed_records'] if x['seed_id']==payload['seed_id'])
    support=comp['structure']['support'];support_set=set(support);N=len(support)
    cap=max(1,min(N,math.ceil(F(payload['budget_share'])*N/100)))
    require(payload['budget']==cap and c['support_size']==N,'Support/cap mismatch.')
    receipts=result['read_receipts'];attempts=[];observed={};pilot=[]
    for receipt in receipts:
        ids=receipt['record_ids'];require(receipt['submitted']==len(ids),'Receipt submitted count mismatch.')
        require(len(ids)==len(set(ids)) and not set(ids).intersection(attempts),'Repeated source read.')
        require(set(ids)<=support_set,'Read outside exact coefficient support.')
        attempts.extend(ids)
        if receipt['phase']=='pilot':require(not pilot,'Multiple pilot batches.');pilot=ids
        if receipt['success']:
            require(len(receipt['labels'])==len(ids),'Missing successful batch labels.')
            for rid,y in zip(ids,receipt['labels']):
                require(type(y) is int and y==labels[rid],'Returned label differs from pinned source.');observed[rid]=y
    require(len(attempts)==c['semantic_calls']<=cap,'Charged attempt/cap mismatch.')
    require(observed==result['observed_labels'] and len(observed)==c['unique_successful_returns'],'Successful-label ledger mismatch.')
    require(digest(list(observed))==c['sampled_ids_sha256'] and digest(observed)==c['successful_labels_sha256'],'Read/label fingerprint mismatch.')
    ep=dict(c['plan']);ep_hash=ep.pop('execution_plan_sha256');require(digest(ep)==ep_hash,'Execution plan fingerprint mismatch.')
    require(digest(c['family'])==ep['family_sha256'],'Family fingerprint mismatch.')
    expected_semantics=manifest['ranking_semantics'] if comp['query']['kind']=='ranking' else manifest['nonranking_semantics']
    require(c['semantics']==payload['semantics']==expected_semantics,'Wrong completion semantics.')
    require(ep['effective']['alpha']==plan['alpha_override'] and ep['effective']['max_oracle_record_predicate_calls']==cap,'Authoritative risk/cap differs.')
    expected_pilot=sorted(random.Random(int(seed['pilot_seed'])).sample(support,min(plan['pilot_cap'],N//10,cap//4)))
    formal=[r for r in receipts if r['phase']=='formal']
    if receipts and receipts[0]['phase']=='tiny_scan':
        require(N<=plan['tiny_scan_max'] and attempts==support,'Invalid tiny scan.')
        return {'anytime_source_noncoverage':False,'cs_events':0,'detail_checked':False,'first_cell_exclusions':[],'terminal_propagation_checked':False}
    if c['reason']=='structural':require(not attempts,'Structural result acquired labels.');return {'anytime_source_noncoverage':False,'cs_events':0,'detail_checked':False,'first_cell_exclusions':[],'terminal_propagation_checked':False}
    require(pilot==expected_pilot,'Pilot differs from its frozen seed/rule.')
    cells=ref.cells(comp,pilot);H=len(cells)
    require(c['cell_count']==H,'Residual cell count mismatch.')
    require(manifest['common_plan']['requested_bins']==1,'Independent cell reconstruction currently requires the frozen one-bin primary design.')
    partition=[(cell['cell_id'],list(map(str,cell['signature'])),0,cell['records']) for cell in cells]
    frozen=c['frozen'];require(digest(pilot)==frozen['pilot_ids_sha256'] and digest({i:labels[i] for i in pilot})==frozen['pilot_labels_sha256'],'Pilot fingerprint mismatch.')
    require(digest(partition)==frozen['partition_sha256'],'Exact coefficient partition differs.')
    permutations={};rng=random.Random(int(seed['formal_seed']))
    for cell in cells:
        ids=list(cell['records']);rng.shuffle(ids);permutations[cell['cell_id']]=ids
    require(digest(permutations)==frozen['permutations_sha256'],'Formal permutation fingerprint mismatch.')
    n={h:0 for h in range(H)};s={h:0 for h in range(H)};action_pairs=[]
    require([i for r in formal for i in r['record_ids']]==[i for a in result['actions'] for i in a['record_ids']],'Formal receipt/action IDs differ.')
    for action in result['actions']:
        h=action['cell_id'];require(type(h) is int and h in n,'Invalid action cell ID.')
        ids=action['record_ids'];before=n[h]
        require(action['prefix_before']==before and action['prefix_after']==before+len(ids),'Action prefix counters differ.')
        require(ids==permutations[h][before:before+len(ids)],'Read does not advance the frozen uniform prefix.')
        require(action['labels']==[labels[i] for i in ids],'Action source labels differ.')
        n[h]+=len(ids);s[h]+=sum(labels[i] for i in ids)
        if detail:action_pairs.extend((h,labels[i]) for i in ids)
    true_K={h:sum(labels[i] for i in cell['records']) for h,cell in enumerate(cells)}
    exact_risk=F(plan['alpha_override'])/H if H else Fraction(0);risk=float(exact_risk)
    if Fraction.from_float(risk)>exact_risk:risk=math.nextafter(risk,0.)
    last={h:(0,cell['N']) for h,cell in enumerate(cells)};last_ns={h:(0,0) for h in range(H)}
    prior={};bad={};event_count=0;sticky=set();event_n={h:0 for h in range(H)};event_s={h:0 for h in range(H)}
    events=result['cs_events']
    require(not detail or len(action_pairs)==len(events),'Per-record action/CS event count differs.')
    for k,event in enumerate(events):
        h=event['cell_id'];require(h in last and event['N']==cells[h]['N'],'CS cell population mismatch.')
        require(event['alpha']==risk,'Cell risk is not the exact downward allocation.')
        require(event['a']>=1 and event['b']>=1 and event['a']+event['b']==2+plan['prior_strength'] and event['lam']==plan['prior_weight'],'Working-prior shape differs.')
        params=(event['a'],event['b'],event['lam'],event['alpha'])
        require(h not in prior or prior[h]==params,'Cell prior changes during formal acquisition.');prior[h]=params
        bounds=event['bounds'];previous=last[h]
        if bounds is not None:
            lo,hi=bounds;require(type(lo) is int and type(hi) is int and 0<=lo<=hi<=event['N'],'Invalid count bounds.')
            require(previous is not None and previous[0]<=lo<=hi<=previous[1],'Running CS widened or recovered from empty.')
            covered=lo<=true_K[h]<=hi
        else:covered=False;require(event['inconsistent'] is True,'Empty CS lacks sticky inconsistency marker.')
        if not covered and h not in bad:
            bad[h]={'cell_id':h,'N':event['N'],'K':true_K[h],'n':event['n'],'s':event['s'],'bounds':bounds,'a':event['a'],'b':event['b'],'lam':event['lam'],'alpha':event['alpha']}
        if h in sticky:require(bounds is None and event['inconsistent'],'Inconsistency was erased.')
        if event['inconsistent']:sticky.add(h)
        if detail:
            eh,y=action_pairs[k];require(eh==h,'CS event attached to wrong action.')
            event_n[h]+=1;event_s[h]+=y
            require((event['n'],event['s'])==(event_n[h],event_s[h]),'CS n/s differs from actual revealed labels.')
        last[h]=tuple(bounds) if bounds is not None else None;last_ns[h]=(event['n'],event['s']);event_count+=1
    require(all(last_ns[h]==(n[h],s[h]) for h in range(H)),'Final cell counts differ from actions.')
    if len(prior)==H:
        priors=[(h,*prior[h]) for h in range(H)];require(digest(priors)==frozen['priors_sha256'],'Frozen prior fingerprint mismatch.')
    # Build exact pilot contribution and integer/fraction pushforward independently.
    constants=[]
    for a,b in comp['rows']:
        left,right=comp['fields'][a],comp['fields'][b];na,nb=comp['denominators'][a],comp['denominators'][b]
        constants.append(sum((Fraction(int(ref.records[i][left]),na)-Fraction(int(ref.records[i][right]),nb))*labels[i] for i in pilot))
    row_bounds=[]
    if all(x is not None for x in last.values()):
        for j,constant in enumerate(constants):
            lo=hi=constant
            for cell in cells:
                coefficient=cell['signature'][j];l,u=last[cell['cell_id']]
                lo+=coefficient*(l if coefficient>=0 else u);hi+=coefficient*(u if coefficient>=0 else l)
            row_bounds.append((lo,hi))
    intervals=c.get('contrast_intervals');propagation=False
    if intervals is not None and row_bounds:
        for atom in comp['atoms']:
            require(tuple(map(F,intervals[str(atom['index'])]))==row_bounds[atom['row_index']],'Terminal exact propagation differs from raw cell bounds.')
        propagation=True
    elif any(x is None for x in last.values()):
        require(c['status']=='execution_error' and intervals is None,'Empty cell CS produced an available/certified terminal interval.')
    if detail:
        for item in bad.values():
            item['ideal_exact_accepts_true_K']=ideal_accepts(item,item['K'])
    return {'anytime_source_noncoverage':bool(bad),'cs_events':event_count,'detail_checked':detail,'first_cell_exclusions':list(bad.values()),'terminal_propagation_checked':propagation}

def planner_stats(result):
    allocation=Counter();raw_allocation=Counter();totals=Counter();comparisons=[]
    for action in result['actions']:
        if action['source']!='policy':continue
        d=action.get('diagnostics') or {};totals['policy_actions']+=1
        raw_allocation[d.get('allocation_source','none')]+=1
        allocation['reused_allocation' if d.get('reused_allocation') else d.get('allocation_source','none')]+=1
        totals['fallback_actions']+=bool(d.get('fallback_reason') or d.get('boundary_fallback'))
        for key in ['planning_wall_ms','warm_greedy_wall_ms','warm_greedy_cpu_ms','scenario_generation_ms']:
            if d.get(key) is not None:totals[key]+=float(d[key])
        for key in ['exact_incumbent_verified','warm_model_candidate_verified','mip_incumbent_exactly_verified','warm_endpoint_plan_exactly_verified','mip_boolean_verification_failed','reused_allocation']:
            totals[key]+=d.get(key) is True
        if d.get('warm_greedy_cost') is not None and d.get('mip_incumbent_cost') is not None:
            warm,mip=d['warm_greedy_cost'],d['mip_incumbent_cost']
            require(type(warm) is int and type(mip) is int and warm>=0 and mip>=0,'Invalid surrogate integer costs.')
            comparisons.append({'step':action['step'],'warm_cost':warm,'mip_cost':mip,'gap':warm-mip,'mip_exactly_verified':d.get('mip_incumbent_exactly_verified') is True,'chosen':d.get('allocation_source')=='checked_mip_incumbent'})
            if d.get('allocation_source')=='checked_mip_incumbent':require(mip<warm,'MIP chosen without strict recorded warm-cost improvement.')
    timings=result.get('timings',{}).get('schedule',{})
    totals['schedule_wall_ms']=float(timings.get('wall_ms',0));totals['schedule_cpu_ms']=float(timings.get('cpu_ms',0))
    return {'totals':dict(totals),'allocation_sources':dict(allocation),'raw_allocation_sources':dict(raw_allocation),'same_state_cost_comparisons':comparisons}

