#!/usr/bin/env python3
"""Mandatory detailed source-error audit; cases selected by the frozen adverse rule."""
from pathlib import Path
import json,gzip,copy,hashlib,sys
from reference import Reference,sha
from trace_audit import audit_trace
ROOT=Path(__file__).resolve().parent.parent
OUT=Path(__file__).resolve().parent
m=json.loads((ROOT/'grid_model50_v1/run_manifest.json').read_text());h=json.loads((ROOT/'grid_human50_v1/run_manifest.json').read_text())
merged=copy.deepcopy(m);merged['labels']['human']=h['labels']['human'];merged['label_sha256']['human']=h['label_sha256']['human'];ref=Reference(merged)
locations=json.loads((OUT/'model_source_error_record_locations.json').read_text());results=[]
for location in locations:
    with gzip.open(location['raw_file'],'rb') as stream:
        for index,line in enumerate(stream):
            if index==location['row_index']:p=json.loads(line);break
        else:raise ValueError('Missing adverse raw record.')
    assert p['run_key']==location['run_key']
    comp=ref.compiled[p['query_id']];c=p['result']['certificate']
    verdict=ref.verdict('model',comp,c);alternate=ref.verdict('human',comp,c);trace=audit_trace(ref,m,p,detail=True)
    means,values,truths,vector,sets=ref.truth('model',comp);hm,hv,_,hvector,_=ref.truth('human',comp)
    results.append({'run_key':p['run_key'],'method':p['method'],'query_id':p['query_id'],'seed_id':p['seed_id'],'semantics':p['semantics'],'decisions':comp['query']['contract']['decisions'],'cohorts':comp['query']['contract']['cohorts'],'calls':c['semantic_calls'],'support':c['support_size'],'cap':p['budget'],'source_truth_vector':vector,'answer_vector':verdict['answer_vector'],'wrong_true_claims':verdict['wrong_true_claims'],'wrong_false_claims':verdict['wrong_false_claims'],'source_invalid_selected_proofs':verdict['source_invalid_proofs'],'source_cohort_means':{k:str(v) for k,v in means.items()},'source_atom_values':{str(k):str(v) for k,v in values.items()},'terminal_contrast_intervals':c['contrast_intervals'],'selected_decision_proofs':c['decisions'],'source_terminal_noncoverage_atoms':verdict['terminal_source_noncoverage_atoms'],'trajectory_audit':trace,'crowd_truth_vector':hvector,'crowd_atom_values':{str(k):str(v) for k,v in hv.items()},'crowd_wrong_false_claims':alternate['wrong_false_claims'],'frozen_receipts':c['frozen'],'raw_record_sha256':hashlib.sha256(line.rstrip(b'\n')).hexdigest(),'framework_invariants_passed':True,'classification':'Realized model-source interval noncoverage and false equivalence-refutation, not semantic-reference disagreement alone or a framework failure.'})
report={'cases':results,'scope':'Three method-indexed outcomes for one query/seed and paired cell permutation family; not three independent statistical failures. Independent source arithmetic, valid terminal proof structure, all read-prefix/label/cap invariants and first cell exclusion q/p diagnostics are checked.','model_manifest_sha256':sha(ROOT/'grid_model50_v1/run_manifest.json'),'source_error_selection_rule':'All source_error records, predeclared mandatory adverse-case audit.'}
(OUT/'model_false_certificate_detailed_audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(results,indent=2))

