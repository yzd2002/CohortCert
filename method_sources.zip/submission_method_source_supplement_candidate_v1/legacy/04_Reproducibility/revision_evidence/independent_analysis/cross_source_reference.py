#!/usr/bin/env python3
"""Secondary fixed-map agreement; existing crowd references are not error-free truth."""
from pathlib import Path
from collections import defaultdict
import argparse,csv,json,copy
from reference import Reference,sha,require
HUMAN_SHA='04fc85f81f7fe2855f95b7d48284d934b7ac21dfb1d8dfb8a4fc06632404f8ba'
MODEL_SHA='508a7c2b7c3ab88b995ef94763dd75d750a3b056a682d909b8612fbd69fc222f'
def divide(a,b):return a/b if b else None
def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--human-manifest',type=Path,required=True);ap.add_argument('--model-manifest',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args()
    require(sha(a.human_manifest)==HUMAN_SHA and sha(a.model_manifest)==MODEL_SHA,'Unexpected manifest identity.')
    h=json.loads(a.human_manifest.read_text());m=json.loads(a.model_manifest.read_text());merged=copy.deepcopy(m)
    for key in ['queries','snapshot']:require(h['inputs'][key]['sha256']==m['inputs'][key]['sha256'],'Sources use different workload/population.')
    merged['labels']['human']=h['labels']['human'];merged['label_sha256']['human']=h['label_sha256']['human'];ref=Reference(merged)
    tables=[]
    for pred in ['toxicity','insult','identity_attack','obscene']:
        human=ref.labels['human'][pred];model=ref.labels['model'][pred]
        for group,ids in [('ALL_FROZEN_ROWS',ref.ids)]+[(f,self_group) for f,self_group in sorted(ref.field_groups.items())]:
            tp=sum(human[i]==1 and model[i]==1 for i in ids);tn=sum(human[i]==0 and model[i]==0 for i in ids);fp=sum(human[i]==0 and model[i]==1 for i in ids);fn=sum(human[i]==1 and model[i]==0 for i in ids)
            sensitivity=divide(tp,tp+fn);specificity=divide(tn,tn+fp)
            tables.append({'predicate':pred,'comment_mention_group':group,'n':len(ids),'TP':tp,'TN':tn,'FP':fp,'FN':fn,'agreement_accuracy_relative_crowd':(tp+tn)/len(ids),'crowd_positive_rate':(tp+fn)/len(ids),'model_positive_rate':(tp+fp)/len(ids),'precision_relative_crowd':divide(tp,tp+fp),'recall_relative_crowd':sensitivity,'specificity_relative_crowd':specificity,'F1_relative_crowd':divide(2*tp,2*tp+fp+fn),'balanced_accuracy_relative_crowd':(sensitivity+specificity)/2 if sensitivity is not None and specificity is not None else None})
    query_rows=[];aggregates=defaultdict(lambda:{'queries':0,'changed_answer_target':0,'changed_boolean_truth_vector':0})
    for qid,comp in ref.compiled.items():
        _,_,_,hv,hs=ref.truth('human',comp);_,_,_,mv,ms=ref.truth('model',comp)
        ht=[hs.get(i) if typ in ['top1','topk'] else hv[i] for i,typ in enumerate(comp['types'])]
        mt=[ms.get(i) if typ in ['top1','topk'] else mv[i] for i,typ in enumerate(comp['types'])]
        item={'query_id':qid,'predicate':comp['predicate'],'kind':comp['query']['kind'],'summary_subtype':comp['query'].get('summary_subtype'),'crowd_answer_target':ht,'model_answer_target':mt,'answer_target_changed':ht!=mt,'boolean_truth_changed':hv!=mv}
        query_rows.append(item);g=aggregates[comp['predicate'],'ranking' if comp['query']['kind']=='ranking' else 'nonranking'];g['queries']+=1;g['changed_answer_target']+=ht!=mt;g['changed_boolean_truth_vector']+=hv!=mv
    report={'scope':'Secondary agreement/accuracy relative to EXISTING crowd-reference threshold maps. Crowd labels are subjective and fallible; neither new human annotations nor objective human-truth accuracy. Cohorts denote COMMENT MENTIONS, never commenter/author identity; groups overlap. No independent-row confidence interval is supplied.','human_manifest_sha256':HUMAN_SHA,'model_manifest_sha256':MODEL_SHA,'source_label_sha256':merged['label_sha256'],'row_count':30000,'all_fixed_maps_and_cohorts':tables,'full_contract_answer_target_changes':[{'predicate':p,'scope':s,**v} for (p,s),v in sorted(aggregates.items())],'query_target_rows':query_rows}
    (a.out/'cross_source_reference_agreement.json').write_text(json.dumps(report,indent=2)+'\n')
    with (a.out/'cross_source_reference_agreement.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(tables[0]));w.writeheader();w.writerows(tables)
    print(json.dumps({'overall_fixed_row_agreement':[x for x in tables if x['comment_mention_group']=='ALL_FROZEN_ROWS'],'contract_changes':report['full_contract_answer_target_changes']},indent=2))
if __name__=='__main__':main()

