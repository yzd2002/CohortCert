#!/usr/bin/env python3
"""Alternate-crowd checks on every model unit and model-proof-valid subset."""
from pathlib import Path
from collections import defaultdict
import argparse,json,sqlite3,csv
def summarize(rows,expected):
    n=len(rows);source_complete=[r for r in rows if r['proof_valid_correct_complete']]
    def values(rs):
        return {'n':len(rs),'crowd_vector_consistent_complete':sum(r['alternate_crowd_reference']['vector_only_correct_complete'] for r in rs),'crowd_selected_witness_source_consistent_complete':sum(r['alternate_crowd_reference']['proof_valid_correct_complete'] for r in rs),'any_crowd_wrong_conclusion_or_selected_proof':sum(r['alternate_crowd_reference']['any_wrong_conclusion_or_proof'] for r in rs),'any_wrong_crowd_conclusion':sum(r['alternate_crowd_reference']['wrong_true_claims']+r['alternate_crowd_reference']['wrong_false_claims']>0 for r in rs),'crowd_wrong_true_claim_incidences':sum(r['alternate_crowd_reference']['wrong_true_claims'] for r in rs),'crowd_wrong_false_claim_incidences':sum(r['alternate_crowd_reference']['wrong_false_claims'] for r in rs),'crowd_inconsistent_selected_proof_runs':sum(r['alternate_crowd_reference']['source_invalid_proofs']>0 for r in rs),'terminal_model_interval_excludes_a_crowd_contrast':sum(r['alternate_crowd_reference']['terminal_model_interval_excludes_crowd_contrast'] for r in rs),'terminal_intervals_available':sum(r['alternate_crowd_reference']['terminal_bounds_available'] for r in rs)}
    return {'expected_all_units':expected,'observed_verified_units':n,'missing_units':expected-n,'model_source_proof_valid_complete':len(source_complete),'model_source_wrong_claim_or_proof_runs':sum(r['source_error'] for r in rows),'model_source_terminal_noncoverage_runs':sum(r['terminal_noncoverage'] for r in rows),'all_model_units':values(rows),'conditional_model_source_proof_valid_complete':values(source_complete)}
def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args();out=a.out;db=sqlite3.connect(out/'independent_audit.sqlite')
    rows=[json.loads(x[0]) for x in db.execute("SELECT body FROM runs WHERE source='model'")];db.close()
    assert all(r['audit_status']=='passed' and 'alternate_crowd_reference' in r for r in rows)
    tables=[]
    for method in sorted({r['method'] for r in rows}):
        sub=[r for r in rows if r['method']==method]
        for scope,group,expected in [('all528',sub,5280),('primary_nonranking',[r for r in sub if r['kind']!='ranking'],4640),('secondary_ranking',[r for r in sub if r['kind']=='ranking'],640)]:
            if method=='boundary' and scope!='secondary_ranking':continue
            tables.append({'method':method,'scope':scope,**summarize(group,expected)})
    by_pred=[]
    for method in sorted({r['method'] for r in rows}):
        for pred in ['toxicity','insult','identity_attack','obscene']:
            group=[r for r in rows if r['method']==method and r['predicate']==pred]
            if group:by_pred.append({'method':method,'predicate':pred,**summarize(group,160 if method=='boundary' else 1320)})
    report={'scope':'Secondary alternate-reference checks on ALL model units and separately model-source proof-valid completed units. A model interval excluding a crowd contrast is alternate-reference disagreement, not a source-relative CS/framework failure. Source-consistent selected witness means its atomic inequalities agree with the saved crowd values; it does not give that model-derived interval a human-rate coverage guarantee. Crowd references are fallible, not objective human truth. Original eight predicates remain human-unvalidated.','all_unit_and_conditional_tables':tables,'all_predicate_tables':by_pred}
    (out/'cross_source_model_conclusion_check.json').write_text(json.dumps(report,indent=2)+'\n')
    flat=[]
    for r in tables:
        base={k:r[k] for k in ['method','scope','expected_all_units','observed_verified_units','missing_units','model_source_proof_valid_complete','model_source_wrong_claim_or_proof_runs','model_source_terminal_noncoverage_runs']}
        for denominator in ['all_model_units','conditional_model_source_proof_valid_complete']:
            flat.append({**base,'denominator_scope':denominator,**r[denominator]})
    if flat:
        with (out/'cross_source_model_conclusion_check.csv').open('w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(flat[0]));w.writeheader();w.writerows(flat)
    print(json.dumps(tables,indent=2))
if __name__=='__main__':main()

