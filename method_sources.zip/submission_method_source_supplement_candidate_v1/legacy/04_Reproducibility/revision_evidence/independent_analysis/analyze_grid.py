#!/usr/bin/env python3
"""Read-only independent audit of closed saved-label shards. No job execution."""
from pathlib import Path
from collections import Counter
import argparse,datetime,gzip,json,os,sqlite3,sys,time,traceback,fcntl,copy
from reference import Reference,F,canonical,digest,sha,require
from trace_audit import audit_trace,planner_stats
HERE=Path(__file__).resolve().parent

def atomic(path,obj):
    p=Path(path);tmp=p.with_name(p.name+'.tmp');tmp.write_text(json.dumps(obj,indent=2,ensure_ascii=False,allow_nan=False)+'\n');tmp.replace(p)
def sql_init(path):
    db=sqlite3.connect(path);db.execute('PRAGMA journal_mode=WAL')
    db.executescript('CREATE TABLE IF NOT EXISTS runs(run_key TEXT PRIMARY KEY,manifest_sha TEXT,source TEXT,method TEXT,qid TEXT,seed INTEGER,cap REAL,kind TEXT,predicate TEXT,subtype TEXT,body TEXT); CREATE TABLE IF NOT EXISTS shards(manifest_sha TEXT,name TEXT,raw_sha TEXT,csv_sha TEXT,rows INTEGER,PRIMARY KEY(manifest_sha,name)); CREATE TABLE IF NOT EXISTS manifests(sha TEXT PRIMARY KEY,path TEXT,body TEXT); CREATE TABLE IF NOT EXISTS audit_revisions(run_key TEXT,revision_utc TEXT,previous_body TEXT);')
    return db
def csv_rows(path):
    import csv
    with path.open(newline='') as stream:return list(csv.DictReader(stream))
def boolean(x):return x=='True'
def run_audit(manifest_path,out,db,cross_human_manifest=None):
    m=json.loads(manifest_path.read_text());mh=sha(manifest_path)
    require(m['status']=='frozen_before_grid_execution','Unfrozen grid manifest.')
    protocol=json.loads((out/'analysis_protocol_before_outcomes.json').read_text())
    if m['sources']==['human'] and m['methods']==['matched','dual_greedy','forecast']:
        require(mh==protocol['human_manifest_sha256'],'Unexpected primary human manifest.')
    db.execute('INSERT OR IGNORE INTO manifests VALUES(?,?,?)',(mh,str(manifest_path),canonical(m)));db.commit()
    reference_manifest=copy.deepcopy(m)
    if cross_human_manifest is not None:
        require(m['sources']==['model'],'Alternate human reference is only for model-source audit.')
        require(sha(cross_human_manifest)==protocol['human_manifest_sha256'],'Unexpected alternate human manifest.')
        human=json.loads(Path(cross_human_manifest).read_text())
        for field in ['queries','snapshot']:require(m['inputs'][field]['sha256']==human['inputs'][field]['sha256'],'Alternate reference has a different workload/population.')
        reference_manifest['labels']['human']=human['labels']['human']
        reference_manifest['label_sha256']['human']=human['label_sha256']['human']
    ref=Reference(reference_manifest)
    reference_path=out/('reference_definitions_'+mh[:12]+'.json')
    if not reference_path.exists():
        definitions=[]
        for source in m['sources']:
            for qid,comp in ref.compiled.items():
                means,values,atoms,truths,sets=ref.truth(source,comp)
                definitions.append({'source':source,'query_id':qid,'predicate':comp['predicate'],'kind':comp['query']['kind'],'template':comp['template'],'cohort_means':{g:str(v) for g,v in means.items()},'atom_values':{str(k):str(v) for k,v in values.items()},'atom_truths':atoms,'truth_vector':truths,'strict_ranking_sets':sets,'support_size':len(comp['structure']['support'])})
        atomic(reference_path,{'manifest_sha256':mh,'method_outcomes_used':False,'source':'Exact independent Fraction cohort counts and frozen contract AST; no engine/checker import.','queries':definitions})
    selected={tuple(x[k] for k in ['source','method','query_id','seed_id','budget_share']) for x in json.loads((out/'trajectory_selected_keys_before_outcomes.json').read_text())}
    completed=0;new=0;issues=0;wait=0;start=time.perf_counter();roots=manifest_path.parent/'results'
    for shard in m['shards']:
        name=shard['name'];state_path=roots/'progress'/(name+'.json')
        if not state_path.exists():wait+=1;continue
        state=json.loads(state_path.read_text())
        if state['status'] not in ['complete','failed','stopped_partial']:wait+=1;continue
        raw_path=roots/'shards'/(name+'.jsonl.gz');csv_path=roots/'shards'/(name+'.csv')
        if not raw_path.exists() or not csv_path.exists():wait+=1;continue
        done=db.execute('SELECT raw_sha,csv_sha,rows FROM shards WHERE manifest_sha=? AND name=?',(mh,name)).fetchone()
        if done:
            require(sha(raw_path)==done[0] and sha(csv_path)==done[1],'Audited primary shard changed.')
            prior_rows=csv_rows(csv_path)
            retry=False
            for old in prior_rows:
                stored=db.execute('SELECT body FROM runs WHERE run_key=?',(old['run_key'],)).fetchone()
                if stored is not None and json.loads(stored[0]).get('audit_status')!='passed':retry=True;break
            if not retry:completed+=1;continue
        rows=csv_rows(csv_path);by_key={r['run_key']:r for r in rows};require(len(rows)==len(by_key),'Duplicate CSV run key.')
        audited=0
        with gzip.open(raw_path,'rb') as stream:
            for rawline in stream:
                require(rawline.endswith(b'\n'),'Closed shard has an incomplete raw line.')
                data=rawline[:-1]
                # A prior successful audit binds this exact closed-shard row
                # by its raw hash. Re-auditing only repaired error rows need
                # not parse every already-verified CS trajectory again.
                if audited<len(rows):
                    expected_row=rows[audited]
                    stored=db.execute('SELECT body FROM runs WHERE run_key=?',(expected_row['run_key'],)).fetchone()
                    if stored and json.loads(stored[0]).get('audit_status')=='passed':
                        require(__import__('hashlib').sha256(data).hexdigest()==expected_row['raw_record_sha256'],'Previously audited raw row changed.')
                        audited+=1;continue
                p=json.loads(data);key=p['run_key'];row=by_key.get(key)
                require(row is not None,'Raw record lacks a CSV row.')
                existing=db.execute('SELECT body FROM runs WHERE run_key=?',(key,)).fetchone()
                if existing and json.loads(existing[0]).get('audit_status')=='passed':audited+=1;continue
                body=None
                try:
                    require(p['run_manifest_sha256']==mh and row['run_manifest_sha256']==mh,'Manifest identity mismatch.')
                    require(__import__('hashlib').sha256(data).hexdigest()==row['raw_record_sha256'],'Raw record fingerprint mismatch.')
                    comp=ref.compiled[p['query_id']]
                    expected=digest([m['version'],mh,p['source'],p['method'],p['query_id'],p['seed_id'],p['budget_share'],p['semantics']])
                    require(expected==key,'Run key differs from declared identity.')
                    require(p['source']==shard['source'] and p['method']==shard['method'] and p['seed_id']==shard['seed_id'] and p['query_id'] in shard['query_ids'],'Run lies outside planned shard.')
                    verdict=ref.verdict(p['source'],comp,p['result']['certificate'])
                    alternate=ref.verdict('human',comp,p['result']['certificate']) if cross_human_manifest is not None else None
                    chosen=(p['source'],p['method'],p['query_id'],p['seed_id'],p['budget_share']) in selected
                    adverse=verdict['source_error'] or bool(verdict['terminal_source_noncoverage_atoms']) or p['result']['certificate']['status']=='execution_error'
                    audit=audit_trace(ref,m,p,detail=chosen or adverse)
                    if audit['anytime_source_noncoverage'] and not audit['detail_checked']:
                        # Predeclared adverse-case supplement, distinct from the
                        # independent hash-selected trajectory denominator.
                        audit=audit_trace(ref,m,p,detail=True);adverse=True
                    require(not (verdict['terminal_source_noncoverage_atoms'] and not audit['anytime_source_noncoverage'] and audit['cs_events']),'Terminal noncoverage without any raw count-CS source exclusion.')
                    planner=planner_stats(p['result']);certificate=p['result']['certificate']
                    checks={'correct_complete':verdict['correct_complete'],'correct_complete_vector_only':verdict['correct_complete_vector_only'],'source_error':verdict['source_error']}
                    for field,value in checks.items():require(boolean(row[field])==value,'Independent/CSV verdict differs: '+field)
                    require(json.loads(row['truth_vector'])==verdict['truth_vector'] and json.loads(row['answer_vector'])==verdict['answer_vector'],'Independent/CSV truth or answer vector differs.')
                    for field,value in [('wrong_true_claims',len(verdict['wrong_true_claims'])),('wrong_false_claims',len(verdict['wrong_false_claims'])),('source_proof_errors',len(verdict['source_invalid_proofs'])),('terminal_source_noncoverage_atoms',len(verdict['terminal_source_noncoverage_atoms']))]:
                        require(int(row[field])==value,'Independent/CSV error count differs: '+field)
                    require(int(row['semantic_calls'])==certificate['semantic_calls'] and int(row['budget'])==p['budget'],'CSV/raw costs differ.')
                    require(abs(float(row['calls_per_support'])-certificate['semantic_calls']/certificate['support_size'])<1e-14,'CSV normalized cost differs.')
                    pt=planner['totals'];require(int(row['policy_actions'])==pt.get('policy_actions',0),'Policy action count differs.')
                    require(json.loads(row['allocation_sources'])==planner['raw_allocation_sources'],'Raw allocation-source count differs.')
                    expected_cap_charge=p['budget'] if verdict['source_error'] or certificate['status']=='execution_error' else certificate['semantic_calls']
                    require(int(row['conservative_cap_charge'])==expected_cap_charge,'Conservative failure charge differs.')
                    body={'audit_status':'passed','source':p['source'],'method':p['method'],'query_id':p['query_id'],'seed_id':p['seed_id'],'budget_share':p['budget_share'],'predicate':comp['predicate'],'kind':comp['query']['kind'],'summary_subtype':comp['query'].get('summary_subtype'),'template':comp['template'],'status':certificate['status'],'reason':certificate['reason'],'framework_exception':certificate['framework_exception'] is not None,'calls':certificate['semantic_calls'],'support':certificate['support_size'],'budget':p['budget'],'conservative_cap_charge':expected_cap_charge,'calls_per_support':certificate['semantic_calls']/certificate['support_size'],'proof_valid_correct_complete':verdict['correct_complete'],'vector_only_correct_complete':verdict['correct_complete_vector_only'],'wrong_true_claims':len(verdict['wrong_true_claims']),'wrong_false_claims':len(verdict['wrong_false_claims']),'source_invalid_proofs':len(verdict['source_invalid_proofs']),'source_error':verdict['source_error'],'terminal_noncoverage':bool(verdict['terminal_source_noncoverage_atoms']),'terminal_noncoverage_atoms':len(verdict['terminal_source_noncoverage_atoms']),'terminal_bounds_available':verdict['terminal_bounds_available'],'anytime_noncoverage':audit['anytime_source_noncoverage'],'cs_event_count':audit['cs_events'],'hash_selected_trajectory':chosen,'adverse_trajectory':bool(adverse),'detailed_trajectory_checked':audit['detail_checked'],'first_cell_exclusions':audit['first_cell_exclusions'],'terminal_propagation_checked':audit['terminal_propagation_checked'],'frozen':certificate['frozen'],'planner':planner,'executor_wall_ms':p['result']['total']['wall_ms'],'executor_cpu_ms':p['result']['total']['cpu_ms'],'policy_build_wall_ms':p['policy_build_wall_ms'],'raw_sha256':row['raw_record_sha256'],'raw_shard':str(raw_path),'manifest_sha256':mh}
                    if alternate is not None:
                        body['alternate_crowd_reference']={'proof_valid_correct_complete':alternate['correct_complete'],'vector_only_correct_complete':alternate['correct_complete_vector_only'],'wrong_true_claims':len(alternate['wrong_true_claims']),'wrong_false_claims':len(alternate['wrong_false_claims']),'source_invalid_proofs':len(alternate['source_invalid_proofs']),'terminal_model_interval_excludes_crowd_contrast':bool(alternate['terminal_source_noncoverage_atoms']),'terminal_crowd_noncoverage_atoms':len(alternate['terminal_source_noncoverage_atoms']),'terminal_bounds_available':alternate['terminal_bounds_available'],'any_wrong_conclusion_or_proof':alternate['source_error'],'scope':'Alternate-reference semantic disagreement, not model-source CS failure.'}
                    if adverse:
                        witness={'run_key':key,'source':p['source'],'method':p['method'],'query_id':p['query_id'],'seed_id':p['seed_id'],'verdict':{k:v for k,v in verdict.items() if k!='reference_values'},'trajectory':audit,'certificate':certificate}
                        with (out/'adverse_case_witnesses.jsonl').open('a') as f:f.write(canonical(witness)+'\n')
                        print(canonical({'event':'adverse_source_or_error_record','run_key':key,'source':p['source'],'method':p['method'],'query_id':p['query_id'],'source_error':verdict['source_error'],'terminal_noncoverage':body['terminal_noncoverage'],'anytime_noncoverage':body['anytime_noncoverage']}),flush=True)
                except Exception as error:
                    issues+=1;body={'audit_status':'invariant_failure_or_auditor_error','message':str(error),'traceback':traceback.format_exc(),'source':p.get('source'),'method':p.get('method'),'query_id':p.get('query_id'),'seed_id':p.get('seed_id'),'budget_share':p.get('budget_share'),'raw_sha256':__import__('hashlib').sha256(data).hexdigest(),'raw_shard':str(raw_path),'manifest_sha256':mh}
                    with (out/'audit_discrepancies.jsonl').open('a') as f:f.write(canonical({'run_key':key,**body})+'\n')
                    if issues<=10:print(canonical({'event':'AUDIT_DISCREPANCY','run_key':key,'message':str(error)}),flush=True)
                if existing:
                    db.execute('INSERT INTO audit_revisions VALUES(?,?,?)',(key,datetime.datetime.now(datetime.timezone.utc).isoformat(),existing[0]))
                db.execute('INSERT OR REPLACE INTO runs VALUES(?,?,?,?,?,?,?,?,?,?,?)',(key,mh,p['source'],p['method'],p['query_id'],p['seed_id'],p['budget_share'],p['kind'],p['predicate'],comp['query'].get('summary_subtype'),canonical(body)))
                audited+=1;new+=1
                if new%25==0:
                    db.commit();atomic(out/'audit_progress.json',{'status':'running','manifest_sha256':mh,'new_rows':new,'completed_shards_this_pass':completed,'issues_this_pass':issues,'wall_seconds':time.perf_counter()-start})
                    if new%200==0:print(canonical({'event':'audit_progress','new_rows':new,'issues':issues,'wall_seconds':time.perf_counter()-start}),flush=True)
        require(audited==len(rows),'Closed raw/CSV record counts differ; fatal diagnostic may require a separate audit.')
        require(len(rows)==state['completed'],'Atomic shard progress count differs.')
        db.execute('INSERT OR REPLACE INTO shards VALUES(?,?,?,?,?)',(mh,name,sha(raw_path),sha(csv_path),audited));db.commit();completed+=1
        print(canonical({'event':'shard_audited','name':name,'rows':audited,'new_total':new,'issues':issues}),flush=True)
    total=db.execute('SELECT COUNT(*) FROM runs WHERE manifest_sha=?',(mh,)).fetchone()[0]
    report={'status':'complete' if completed==len(m['shards']) and total==m['counts']['all_runs'] and not issues else 'incomplete_or_discrepancies','manifest_sha256':mh,'audited_records':total,'expected_records':m['counts']['all_runs'],'completed_audited_shards':completed,'expected_shards':len(m['shards']),'not_ready_shards':wait,'new_rows_this_pass':new,'issues_this_pass':issues,'wall_seconds':time.perf_counter()-start,'read_only_primary':True}
    atomic(out/('audit_completion_'+mh[:12]+'.json'),report);atomic(out/'audit_progress.json',report);print(json.dumps(report,indent=2),flush=True)
    return report
def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--manifest',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--cross-human-manifest',type=Path);args=ap.parse_args()
    out=args.out.resolve();require((out/'analysis_protocol_before_outcomes.json').exists(),'Analysis protocol must precede outcome access.')
    with (out/'analysis.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        try:os.nice(10)
        except OSError:pass
        db=sql_init(out/'independent_audit.sqlite');run_audit(args.manifest.resolve(),out,db,args.cross_human_manifest);db.close()
if __name__=='__main__':main()

