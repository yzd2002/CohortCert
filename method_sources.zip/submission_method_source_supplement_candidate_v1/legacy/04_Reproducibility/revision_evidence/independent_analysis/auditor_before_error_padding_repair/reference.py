"""Independent exact contract/source semantics; imports no executor/compiler."""
from collections import defaultdict
from fractions import Fraction
from itertools import combinations
from pathlib import Path
import hashlib,json,math,random

def canonical(value):return json.dumps(value,sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False)
def digest(value):return hashlib.sha256(canonical(value).encode()).hexdigest()
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def require(ok,message):
    if not ok:raise ValueError(message)
def F(value):return value if isinstance(value,Fraction) else Fraction(str(value))

class Reference:
    def __init__(self,manifest):
        import pyarrow.parquet as pq
        self.manifest=manifest;self.ws=Path(manifest['workspace'])
        for entry in manifest['inputs'].values():require(sha(entry['path'])==entry['sha256'],'Frozen input hash mismatch: '+entry['path'])
        metadata=pq.read_table(manifest['inputs']['snapshot']['path']).to_pylist()
        self.records={r['record_id']:r for r in metadata};self.ids=sorted(self.records)
        require(len(self.ids)==len(metadata)==30000,'Population ID mismatch.')
        fields=sorted(k for k in metadata[0] if k.startswith('mentions_'))
        original=pq.read_table(self.ws/'text_metadata_snapshot.parquet',columns=['record_id',*fields]).to_pylist()
        require(set(r['record_id'] for r in original)==set(self.ids),'Original snapshot IDs changed.')
        require(all(all(r[k]==self.records[r['record_id']][k] for k in fields) for r in original),'Membership differs from originally frozen text snapshot.')
        self.field_groups={f:{i for i in self.ids if self.records[i][f] is True} for f in fields}
        self.queries={q['query_id']:q for q in [json.loads(s) for s in Path(manifest['inputs']['queries']['path']).read_text().splitlines()]}
        self.labels={};self.field_means={};self.compiled={};self.templates={}
        for source,paths in manifest['labels'].items():
            self.labels[source]={};self.field_means[source]={}
            for pred,path in paths.items():
                require(sha(path)==manifest['label_sha256'][source][pred],'Label map hash mismatch.')
                labels=json.loads(Path(path).read_text());require(set(labels)==set(self.ids) and all(type(v) is int and v in [0,1] for v in labels.values()),'Incomplete/nonbinary source map.')
                self.labels[source][pred]=labels
                self.field_means[source][pred]={f:Fraction(sum(labels[i] for i in members),len(members)) for f,members in self.field_groups.items()}
        for qid,q in self.queries.items():self.compiled[qid]=self.compile(q)
    def compile(self,q):
        c=q['contract'];fields={}
        for g in c['cohorts']:
            ast=g['filter_ast'];require(list(ast)==['eq'] and ast['eq'][1] is True,'Unexpected frozen cohort AST.')
            field=ast['eq'][0];require(field in self.field_groups,'Unknown cohort field.');fields[g['id']]=field
        denominators={g:len(self.field_groups[f]) for g,f in fields.items()}
        rows=[];atoms=[];certs=[];targets=[];types=[]
        def row(a,b):
            pair=(a,b)
            if pair not in rows:rows.append(pair)
            return rows.index(pair)
        def atom(kind,threshold,a,b):
            index=len(atoms);atoms.append({'index':index,'kind':kind,'threshold':F(threshold),'row_index':row(a,b),'cohort_pair':(a,b)});return index
        for di,d in enumerate(c['decisions']):
            typ=d['type'];types.append(typ);first=len(certs)
            if typ in ['compare','direction']:certs.append([atom('lower',d['threshold'],d['left'],d['right'])])
            elif typ=='equivalence':
                eps=F(d['tolerance']);certs.append([atom('lower',-eps,d['left'],d['right']),atom('upper',eps,d['left'],d['right'])])
            else:
                require(typ in ['top1','topk'],'Unknown decision.')
                names=d['candidates'];pairs={(a,b):atom('lower',0,a,b) for a in names for b in names if a!=b};k=1 if typ=='top1' else d['k']
                subsets=[d['topk_set']] if 'topk_set' in d else combinations(names,k)
                for subset in subsets:
                    chosen=set(subset);certs.append([pairs[a,b] for a in names if a in chosen for b in names if b not in chosen])
            targets.extend([di]*(len(certs)-first))
        template=digest({'fields':fields,'decisions':c['decisions']})
        if template not in self.templates:
            # Group exact coefficient signatures in original sorted-ID order.
            pattern_signature={}
            for rid in self.ids:
                pattern=tuple(self.records[rid][f] for f in fields.values())
                if pattern not in pattern_signature:
                    present=dict(zip(fields,pattern))
                    pattern_signature[pattern]=tuple(Fraction(int(present[a]),denominators[a])-Fraction(int(present[b]),denominators[b]) for a,b in rows)
            groups={}
            for rid in self.ids:
                pattern=tuple(self.records[rid][f] for f in fields.values());sig=pattern_signature[pattern]
                if any(sig):groups.setdefault(sig,[]).append(rid)
            self.templates[template]={'groups':list(groups.items()),'support':sorted(i for members in groups.values() for i in members)}
        pred=q['predicate_id'][len('civilcomments_'):-3]
        return {'query':q,'fields':fields,'denominators':denominators,'rows':rows,'atoms':atoms,'certificates':certs,'targets':targets,'types':types,'template':template,'predicate':pred,'structure':self.templates[template]}
    def truth(self,source,comp):
        means={g:self.field_means[source][comp['predicate']][f] for g,f in comp['fields'].items()}
        values={a['index']:means[a['cohort_pair'][0]]-means[a['cohort_pair'][1]] for a in comp['atoms']}
        atoms={a['index']:(values[a['index']]>a['threshold'] if a['kind']=='lower' else values[a['index']]<a['threshold']) for a in comp['atoms']}
        truths=[];sets={}
        for di,d in enumerate(comp['query']['contract']['decisions']):
            witnesses=[i for i,target in enumerate(comp['targets']) if target==di]
            truth=any(all(atoms[j] for j in comp['certificates'][i]) for i in witnesses);truths.append(truth)
            if comp['types'][di] in ['top1','topk']:
                names=d['candidates'];k=1 if d['type']=='top1' else d['k']
                ordered=sorted(names,key=lambda g:(-means[g],g));chosen=ordered[:k]
                sets[di]=sorted(chosen) if min(means[g] for g in chosen)>max(means[g] for g in ordered[k:]) else None
        return means,values,atoms,truths,sets
    def cells(self,comp,pilot):
        pilot=set(pilot);cells=[]
        for sig,members in comp['structure']['groups']:
            rest=[i for i in members if i not in pilot]
            if rest:cells.append({'signature':sig,'records':rest,'N':len(rest)})
        cells.sort(key=lambda c:c['records'][0])
        for i,c in enumerate(cells):c['cell_id']=i
        return cells
    def verify_family(self,comp,family):
        require(family['decision_types']==comp['types'],'Decision types differ from contract.')
        require(family['certificate_decisions']==comp['targets'],'Witness/D mapping differs from contract.')
        require(len(family['atoms'])==len(comp['atoms']),'Atom count differs from contract.')
        for expected,item in zip(comp['atoms'],family['atoms']):
            for key in ['index','kind','row_index']:require(item[key]==expected[key],'Atom definition mismatch: '+key)
            require(F(item['threshold'])==expected['threshold'] and tuple(item['cohort_pair'])==expected['cohort_pair'],'Atom threshold/cohort mismatch.')
        require([sorted(x) for x in family['certificates']]==[sorted(x) for x in comp['certificates']],'Witness family differs from contract.')
    def verdict(self,source,comp,certificate):
        self.verify_family(comp,certificate['family'])
        means,values,truths,truth_vector,selected=self.truth(source,comp)
        intervals=certificate.get('contrast_intervals');states={};noncoverage=[]
        for a in comp['atoms']:
            aid=a['index'];raw=(intervals or {}).get(str(aid))
            if raw is None:states[aid]=None;continue
            lo,hi=map(F,raw);require(lo<=hi,'Reversed terminal interval.')
            if not lo<=values[aid]<=hi:noncoverage.append(aid)
            states[aid]=(True if lo>a['threshold'] else False if hi<=a['threshold'] else None) if a['kind']=='lower' else (True if hi<a['threshold'] else False if lo>=a['threshold'] else None)
        items=certificate['decisions'];error=certificate['status']=='execution_error'
        require(error or len(items)==len(comp['types']),'Missing declared decision.')
        wrong_true=[];wrong_false=[];bad_proofs=[];answers=[];interval_errors=[]
        for di,item in enumerate(items):
            require(item['decision']==di and item.get('decision_type')==comp['types'][di],'Decision identity mismatch.')
            answer=item['value'];require(answer is None or type(answer) is bool,'Nonboolean answer.')
            answers.append(answer);terms=[i for i,d in enumerate(comp['targets']) if d==di]
            positive=[i for i in terms if all(states[j] is True for j in comp['certificates'][i])]
            negative=all(any(states[j] is False for j in comp['certificates'][i]) for i in terms)
            allow_negative=certificate['semantics']=='bidirectional' and comp['types'][di] not in ['top1','topk']
            expected=True if positive else False if allow_negative and negative else None
            require(error or answer is expected,'Answer not supported by terminal bounds.')
            require(item['status']==('unresolved' if answer is None else 'true' if answer else 'false'),'Decision status mismatch.')
            source_bad=[]
            if answer is True:
                wi=item['positive_certificate'];require(type(wi) is int and wi in terms and wi in positive,'Invalid positive witness.')
                require(not item.get('negative_cover'),'Positive answer carries negative cover.')
                source_bad=[j for j in comp['certificates'][wi] if not truths[j]]
                if not truth_vector[di] or (comp['types'][di] in ['top1','topk'] and item.get('selected_cohorts')!=selected[di]):wrong_true.append(di)
            elif answer is False:
                require(allow_negative,'Forbidden negative answer for ranking/positive-only.')
                require(item.get('positive_certificate') is None,'Negative answer carries positive witness.')
                cover=item['negative_cover'];hits=[part['certificate'] for part in cover]
                require(len(hits)==len(set(hits)) and set(hits)==set(terms),'Negative cover does not hit every witness exactly once.')
                for part in cover:
                    wi,j=part['certificate'],part['atom'];require(j in comp['certificates'][wi] and states[j] is False,'Invalid negative witness atom.')
                    if truths[j]:source_bad.append(j)
                if truth_vector[di]:wrong_false.append(di)
            else:require(item.get('positive_certificate') is None and not item.get('negative_cover'),'Unresolved decision carries evidence.')
            if source_bad:bad_proofs.append({'decision':di,'atoms':sorted(set(source_bad))})
        require(certificate['declared_judgments']==len(comp['types']),'Declared D count mismatch.')
        require(certificate['resolved_judgments']==sum(a is not None for a in answers),'Resolved D count mismatch.')
        all_resolved=len(answers)==len(comp['types']) and all(a is not None for a in answers)
        require(certificate['status']!='complete' or all_resolved,'Completion omits a D.')
        vector=certificate['status']=='complete' and all_resolved and not wrong_true and not wrong_false
        return {'truth_vector':truth_vector,'answer_vector':answers,'correct_complete_vector_only':bool(vector),'correct_complete':bool(vector and not bad_proofs),'wrong_true_claims':wrong_true,'wrong_false_claims':wrong_false,'source_invalid_proofs':bad_proofs,'source_error':bool(wrong_true or wrong_false or bad_proofs),'terminal_source_noncoverage_atoms':noncoverage,'terminal_bounds_available':intervals is not None,'reference_values':values}

