#!/usr/bin/env python3
"""Descriptive all-unit and paired whole-seed-block summaries of audited rows."""
from pathlib import Path
from collections import Counter,defaultdict
import argparse,csv,json,math,sqlite3,statistics
import numpy as np
from reference import canonical,require
HERE=Path(__file__).resolve().parent
def mean(xs):return statistics.fmean(xs) if xs else None
def stats(rows,expected):
    valid=[r for r in rows if r.get('audit_status')=='passed'];n=len(valid)
    return {'expected_units':expected,'audited_units':len(rows),'verified_units':n,'missing_units':expected-len(rows),'audit_failure_units':len(rows)-n,'proof_valid_correct_complete':sum(r['proof_valid_correct_complete'] for r in valid),'vector_only_correct_complete':sum(r['vector_only_correct_complete'] for r in valid),'reported_complete':sum(r['status']=='complete' for r in valid),'wrong_true_claims':sum(r['wrong_true_claims'] for r in valid),'wrong_false_claims':sum(r['wrong_false_claims'] for r in valid),'source_invalid_proof_runs':sum(r['source_invalid_proofs']>0 for r in valid),'execution_error_runs':sum(r['status']=='execution_error' for r in valid),'framework_exception_runs':sum(r['framework_exception'] for r in valid),'sticky_CS_error_runs':sum(r['reason']=='sticky_certificate_inconsistency' for r in valid),'unresolved_runs':sum(r['status']=='unresolved' for r in valid),'terminal_source_noncoverage_runs':sum(r['terminal_noncoverage'] for r in valid),'terminal_bounds_available_runs':sum(r['terminal_bounds_available'] for r in valid),'anytime_count_CS_noncoverage_runs':sum(r['anytime_noncoverage'] for r in valid),'CS_event_count':sum(r['cs_event_count'] for r in valid),'hash_selected_detailed_trajectories':sum(r['hash_selected_trajectory'] and r['detailed_trajectory_checked'] for r in valid),'adverse_detailed_trajectories':sum(r['adverse_trajectory'] and r['detailed_trajectory_checked'] for r in valid),'mean_calls_per_support':mean([r['calls_per_support'] for r in valid]),'mean_cap_charged_calls_per_support':mean([r['conservative_cap_charge']/r['support'] for r in valid]),'total_semantic_calls':sum(r['calls'] for r in valid),'mean_executor_wall_ms':mean([r['executor_wall_ms'] for r in valid]),'mean_executor_CPU_ms':mean([r['executor_cpu_ms'] for r in valid])}
def macro(rows,field,seed=None):
    values=defaultdict(list)
    for r in rows:
        if r['kind']=='ranking' or (seed is not None and r['seed_id']!=seed):continue
        value=r[field] if field!='cap_cost' else r['conservative_cap_charge']/r['support']
        values[r['predicate'],r['kind']].append(float(value))
    require(len(values)==12,'Incomplete4predicate x3family macro cells.')
    return mean([mean(v) for v in values.values()])
def percentile(xs):return list(map(float,np.quantile(xs,[.025,.975],method='linear')))
def paired(rows,source,target,control,scope,bootstrap):
    chosen=[r for r in rows if r['source']==source and r['audit_status']=='passed' and ((r['kind']=='ranking') if scope=='secondary_ranking' else (r['kind']!='ranking'))]
    a={(r['query_id'],r['seed_id'],r['budget_share']):r for r in chosen if r['method']==target}
    b={(r['query_id'],r['seed_id'],r['budget_share']):r for r in chosen if r['method']==control}
    keys=sorted(set(a)&set(b));expected=640 if scope=='secondary_ranking' else 4640
    if not keys:return None
    pairs=[(a[k],b[k]) for k in keys]
    for x,y in pairs:
        for name in ['pilot_ids_sha256','pilot_labels_sha256','scores_sha256','partition_sha256','priors_sha256','permutations_sha256']:
            require(x['frozen'].get(name)==y['frozen'].get(name),'Paired method frozen identity differs: '+name)
    joint=[(x,y) for x,y in pairs if x['proof_valid_correct_complete'] and y['proof_valid_correct_complete']]
    conditional=[];zero=0
    for x,y in joint:
        if y['calls']>0:conditional.append((y['calls']-x['calls'])/y['calls'])
        else:zero+=1
    control_mean=mean([y['calls_per_support'] for x,y in pairs]);target_mean=mean([x['calls_per_support'] for x,y in pairs])
    gaps=[int(x['proof_valid_correct_complete'])-int(y['proof_valid_correct_complete']) for x,y in pairs]
    result={'source':source,'scope':scope,'target':target,'control':control,'expected_paired_units':expected,'available_paired_units':len(pairs),'target_correct_complete':sum(x['proof_valid_correct_complete'] for x,y in pairs),'control_correct_complete':sum(y['proof_valid_correct_complete'] for x,y in pairs),'micro_completion_gap_percentage_points':100*mean(gaps),'target_mean_calls_per_support':target_mean,'control_mean_calls_per_support':control_mean,'micro_all_unit_call_reduction_percent':100*(control_mean-target_mean)/control_mean if control_mean else None,'added_complete_units':sum(g>0 for g in gaps),'lost_complete_units':sum(g<0 for g in gaps),'jointly_correct_pairs':len(joint),'conditional_distinct_query_ids':len({x['query_id'] for x,y in joint}),'conditional_distinct_templates':len({x['template'] for x,y in joint}),'conditional_zero_control_cost_pairs':zero,'conditional_mean_relative_call_saving_percent':100*mean(conditional) if conditional else None,'uncertainty_scope':'Paired whole-workload seed blocks, descriptive conditional repeated-sampling variability; query/population generalization not supported.'}
    if len(pairs)==expected:
        seed=[]
        for s in range(10):
            local=[(x,y) for x,y in pairs if x['seed_id']==s];xs=[x for x,y in local];ys=[y for x,y in local]
            item={'seed_id':s,'units':len(local),'micro_completion_gap':mean([int(x['proof_valid_correct_complete'])-int(y['proof_valid_correct_complete']) for x,y in local]),'target_cost':mean([x['calls_per_support'] for x in xs]),'control_cost':mean([y['calls_per_support'] for y in ys]),'target_cap_cost':mean([x['conservative_cap_charge']/x['support'] for x in xs]),'control_cap_cost':mean([y['conservative_cap_charge']/y['support'] for y in ys])}
            if scope!='secondary_ranking':
                item.update(macro_completion_gap=macro(xs,'proof_valid_correct_complete')-macro(ys,'proof_valid_correct_complete'),macro_target_cost=macro(xs,'calls_per_support'),macro_control_cost=macro(ys,'calls_per_support'))
            seed.append(item)
        result['seed_block_estimates']=seed
        micro=np.array([x['micro_completion_gap'] for x in seed]);tc=np.array([x['target_cost'] for x in seed]);cc=np.array([x['control_cost'] for x in seed])
        result['micro_completion_gap_seedblock95_percentage_points']=percentile(100*micro[bootstrap].mean(axis=1))
        result['micro_all_unit_call_reduction_seedblock95_percent']=percentile(100*(cc[bootstrap].mean(axis=1)-tc[bootstrap].mean(axis=1))/cc[bootstrap].mean(axis=1))
        cap_t=np.array([x['target_cap_cost'] for x in seed]);cap_c=np.array([x['control_cap_cost'] for x in seed])
        result['micro_failure_cap_charge_reduction_percent']=100*(cap_c.mean()-cap_t.mean())/cap_c.mean()
        if scope!='secondary_ranking':
            mg=np.array([x['macro_completion_gap'] for x in seed]);mt=np.array([x['macro_target_cost'] for x in seed]);mc=np.array([x['macro_control_cost'] for x in seed])
            result.update(balanced_macro_completion_gap_percentage_points=100*mg.mean(),balanced_macro_completion_gap_seedblock95_percentage_points=percentile(100*mg[bootstrap].mean(axis=1)),balanced_macro_all_unit_call_reduction_percent=100*(mc.mean()-mt.mean())/mc.mean(),balanced_macro_all_unit_call_reduction_seedblock95_percent=percentile(100*(mc[bootstrap].mean(axis=1)-mt[bootstrap].mean(axis=1))/mc[bootstrap].mean(axis=1)))
    return result
def planner_summary(rows):
    by=defaultdict(list)
    for r in rows:
        if r.get('audit_status')=='passed':by[r['source'],r['method']].append(r)
    out=[]
    for (source,method),rs in sorted(by.items()):
        totals=Counter();allocation=Counter();raw=Counter();pairs=[]
        for r in rs:
            d=r['planner'];totals.update(d['totals']);allocation.update(d['allocation_sources']);raw.update(d['raw_allocation_sources']);pairs.extend(d['same_state_cost_comparisons'])
        gains=[p['gap'] for p in pairs]
        verified=[p for p in pairs if p['mip_exactly_verified']]
        out.append({'source':source,'method':method,'audited_runs':len(rs),'totals':dict(totals),'allocation_sources_with_reuse_separate':dict(allocation),'raw_allocation_sources':dict(raw),'states_with_both_warm_and_MIP_cost':len(pairs),'states_with_verified_MIP_cost':len(verified),'MIP_strictly_improved_recorded_warm_cost_states':sum(p['gap']>0 for p in verified),'MIP_same_cost_states':sum(p['gap']==0 for p in verified),'MIP_worse_cost_states':sum(p['gap']<0 for p in verified),'MIP_selected_states':sum(p['chosen'] for p in pairs),'mean_same_state_verified_cost_improvement':mean([p['gap'] for p in verified]),'max_same_state_verified_cost_improvement':max([p['gap'] for p in verified],default=None),'mean_planner_wall_ms_per_run':totals.get('planning_wall_ms',0)/len(rs),'mean_schedule_CPU_ms_per_run':totals.get('schedule_cpu_ms',0)/len(rs),'CPU_scope':'schedule CPU includes common init/exploration; warm_greedy_cpu is separately available. Full planner-only CPU was not recorded.','interpretation':'Recorded checked-warm versus MIP costs concern the same-state surrogate. These are not counterfactual policy performance effects or independent solver-optimality verification.'})
    return out
def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--out',type=Path,required=True);args=ap.parse_args();out=args.out
    protocol=json.loads((out/'analysis_protocol_before_outcomes.json').read_text())
    db=sqlite3.connect(out/'independent_audit.sqlite')
    rows=[json.loads(x[0]) for x in db.execute('SELECT body FROM runs')];db.close()
    failures=[r for r in rows if r.get('audit_status')!='passed']
    complete=[r for r in rows if r.get('audit_status')=='passed']
    # Duplicate logical units across manifests are never silently pooled.
    keys=[(r['source'],r['method'],r['query_id'],r['seed_id'],r['budget_share']) for r in complete]
    require(len(keys)==len(set(keys)),'Duplicate logical units across manifests.')
    tables=[];macros=[];strata=[]
    for source in sorted({r['source'] for r in complete}):
        for method in sorted({r['method'] for r in complete if r['source']==source}):
            rs=[r for r in rows if r.get('source')==source and r.get('method')==method]
            for scope,sub,expected in [('all528',rs,5280),('primary_nonranking',[r for r in rs if r.get('kind')!='ranking'],4640),('secondary_ranking',[r for r in rs if r.get('kind')=='ranking'],640)]:
                if method=='boundary' and scope!='secondary_ranking':continue
                tables.append({'source':source,'scope':scope,'method':method,**stats(sub,expected)})
            primary=[r for r in rs if r.get('kind')!='ranking' and r.get('audit_status')=='passed']
            if len(primary)==4640:macros.append({'source':source,'method':method,'underlying_primary_units':len(primary),'weights':'Each4predicates1/4; each3nonrankingfamilies1/3; each query/seed equally within cell.','balanced_macro_proof_valid_completion':macro(primary,'proof_valid_correct_complete'),'balanced_macro_vector_completion':macro(primary,'vector_only_correct_complete'),'balanced_macro_mean_calls_per_support':macro(primary,'calls_per_support'),'balanced_macro_failure_cap_mean_calls_per_support':macro(primary,'cap_cost')})
            groups=defaultdict(list)
            for r in rs:
                if r.get('audit_status')=='passed':groups[r['predicate'],r['kind'],r.get('summary_subtype') or ''].append(r)
            for (pred,kind,subtype),group in sorted(groups.items()):
                strata.append({'source':source,'method':method,'predicate':pred,'kind':kind,'summary_subtype':subtype,**stats(group,len(group))})
    rng=np.random.default_rng(int(protocol['uncertainty']['bootstrap_seed']));bootstrap=rng.integers(0,10,size=(protocol['uncertainty']['bootstrap_replicates'],10))
    comparisons=[]
    for source in sorted({r['source'] for r in complete}):
        methods={r['method'] for r in complete if r['source']==source}
        for scope in ['primary_nonranking','secondary_ranking']:
            for target,control in [('forecast','matched'),('forecast','dual_greedy'),('dual_greedy','matched')]+([('forecast','boundary')] if scope=='secondary_ranking' else []):
                if {target,control}<=methods:
                    item=paired(complete,source,target,control,scope,bootstrap)
                    if item:comparisons.append(item)
    planner=planner_summary(complete)
    report={'status':'audit_discrepancies_present' if failures else 'verified_observed_rows','audited_rows':len(rows),'audit_failures':len(failures),'micro_tables_lead':tables,'balanced_macro_secondary_table':macros,'paired_comparisons':comparisons,'fixed_stratified_descriptives':strata,'planner_diagnostics':planner,'uncertainty':protocol['uncertainty'],'analysis_provenance':'Internal analysis rules frozen before analyst method-outcome inspection, after source collection/policy freeze; not external preregistration. Root supplied preliminary aggregate readout during implementation.','timing_scope':'Fixed-label CPU execution times, not GPU inference or live semantic-query latency; model/feature setup are separate.'}
    (out/'independent_summary.json').write_text(json.dumps(report,indent=2)+'\n')
    for filename,data in [('micro_all_unit_tables.csv',tables),('balanced_macro_tables.csv',macros),('fixed_stratified_descriptives.csv',strata)]:
        if data:
            fields=list(dict.fromkeys(k for row in data for k in row))
            with (out/filename).open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(data)
    print(json.dumps({'status':report['status'],'audited_rows':len(rows),'audit_failures':len(failures),'primary_micro_tables':[r for r in tables if r['scope']=='primary_nonranking'],'primary_paired_comparisons':[{k:v for k,v in r.items() if k not in ['seed_block_estimates']} for r in comparisons if r['scope']=='primary_nonranking'],'planner_diagnostics':planner},indent=2),flush=True)
if __name__=='__main__':main()

