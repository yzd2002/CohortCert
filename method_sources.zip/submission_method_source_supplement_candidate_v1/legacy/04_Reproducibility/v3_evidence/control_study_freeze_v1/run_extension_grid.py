#!/usr/bin/env python3
"""V3 post-hoc allocation controls, using unchanged v2 runner/executor.

Only separately frozen extension policy construction and baseline-pairing audit
are added. No GPU, new source label, primary-source edit or implicit overwrite.
"""
from pathlib import Path
import argparse,copy,csv,hashlib,json,sys,shutil,itertools
from datetime import datetime,timezone

DEFAULT_OLD=Path('/root/autodl-tmp/cohortcert_strong_revision_20261102')
_GRID=None;_ORIGINAL_INIT=None;_ORIGINAL_AUDIT=None;_BASELINE={}

def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
 return h.hexdigest()
def write_new(p,obj):
 with Path(p).open('x') as f:f.write(json.dumps(obj,indent=2,allow_nan=False)+'\n')
def get_grid(old):
 global _GRID,_ORIGINAL_INIT,_ORIGINAL_AUDIT
 if _GRID is None:
  sys.path.insert(0,str(Path(old)/'policy_freeze_v1'))
  from executor_v2 import run_grid
  _GRID=run_grid;_ORIGINAL_INIT=run_grid.worker_initialize;_ORIGINAL_AUDIT=run_grid.audit_finished_shard
 return _GRID

def policy_for(method,seed,manifest):
 # The extension constructors are deliberately not given paths, labels,
 # reference outcomes, future permutations or mutable executor objects.
 if method=='width':
  from allocation_controls import NormalizedWidthGreedy
  return NormalizedWidthGreedy()
 if method=='neyman':
  from allocation_controls import NormalizedNeyman
  return NormalizedNeyman()
 if method=='max_dg':
  from mechanism_controls import MaxDG
  return MaxDG()
 raise ValueError('Unknown frozen v3 method: '+method)

def initialize(manifest,results,stop):
 grid=get_grid(manifest['v3_old_root'])
 sys.path.insert(0,manifest['v3_extension_dir'])
 grid.policy_for=policy_for
 _ORIGINAL_INIT(manifest,results,stop)

def audit_shard(results,shard,paired):
 n=_ORIGINAL_AUDIT(results,shard,paired)
 for row in csv.DictReader((Path(results)/'shards'/(shard['name']+'.csv')).open()):
  if row['framework_exception']=='True' or row['invariants_valid']!='True':continue
  key=tuple(row[k] for k in ['source','query_id','budget_share','seed_id','semantics'])
  cols=['pilot_ids_sha256','pilot_labels_sha256','scores_sha256','partition_sha256','priors_sha256','permutations_sha256']
  got=tuple(row[k] for k in cols)
  if key not in _BASELINE:raise RuntimeError('No original DG pairing row: '+str(key))
  if got!=_BASELINE[key]:raise RuntimeError('New/original baseline frozen initialization mismatch: '+str(key))
 return n

def freeze(a):
 old=a.old_root.resolve();out=a.out.resolve()
 if not 1<=a.workers<=20:raise ValueError('Use1to20CPUworkers')
 hm=old/'grid_human50_v1/run_manifest.json';mm=old/'grid_model50_v1/run_manifest.json'
 human=json.loads(hm.read_text());model=json.loads(mm.read_text())
 for field in ['inputs','seed_records','common_plan','forecast','source_sha256']:
  if human[field]!=model[field]:raise RuntimeError('Historical common design differs: '+field)
 m=copy.deepcopy(human)
 controls=a.controls.resolve();mechanism=a.mechanism.resolve()
 for p in [controls/'allocation_controls.py',controls/'VALIDATION.json',mechanism/'mechanism_controls.py',mechanism/'VALIDATION.json']:
  if not p.is_file():raise RuntimeError('Missing reviewed source/validation: '+str(p))
 out.mkdir(parents=True,exist_ok=False);ext=out/'extensions';ext.mkdir()
 shutil.copy2(controls/'allocation_controls.py',ext/'allocation_controls.py')
 shutil.copy2(mechanism/'mechanism_controls.py',ext/'mechanism_controls.py')
 shutil.copy2(Path(__file__),out/'run_extension_grid.py')
 for source_dir,label in [(controls,'conventional'),(mechanism,'mechanism')]:
  for p in source_dir.iterdir():
   if p.is_file() and p.suffix in ['.txt','.md','.json','.py']:
    dst=out/'design_sources'/label/p.name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dst)
 protocol=json.loads(a.protocol.read_text());write_new(out/'STUDY_PROTOCOL.json',protocol)
 m.update(created_utc=datetime.now(timezone.utc).isoformat(),status='frozen_before_grid_execution',
   phase='posthoc_v3_controls_and_sum_vs_max_mechanism',
   freeze_note='Post-hoc study designed after v2 results/reviews. All new policies frozen before this study execution; no claim of source/prior-outcome blindness.',
   v3_old_root=str(old),v3_extension_dir=str(ext),v3_protocol_sha256=sha(out/'STUDY_PROTOCOL.json'),
   v3_original_manifests={'human':{'path':str(hm),'sha256':sha(hm)},'model':{'path':str(mm),'sha256':sha(mm)}},
   sources=['human','model'],methods=['width','neyman','max_dg'],worker_count=a.workers)
 m['labels']={**human['labels'],**model['labels']};m['label_sha256']={**human['label_sha256'],**model['label_sha256']}
 shards=[]
 for source,method,seed in itertools.product(m['sources'],m['methods'],m['seed_records']):
  eligible=[q for q in m['query_metadata'] if method!='max_dg' or q['kind']=='summary']
  name=f'{source}__{method}__seed{seed["seed_id"]:02d}__cap50'
  shards.append({'name':name,'source':source,'method':method,'seed_id':seed['seed_id'],'budget_share':50.0,'query_ids':[q['query_id'] for q in eligible],'expected_rows':len(eligible),'order_key':hashlib.sha256(('cohortcert-v3-posthoc-controls-'+name).encode()).hexdigest()})
 shards.sort(key=lambda s:s['order_key']);m['shards']=shards
 m['counts']={'all_runs':sum(s['expected_rows'] for s in shards),'primary_nonranking_runs':sum(sum(q['kind']!='ranking' for q in m['query_metadata'] if q['query_id'] in set(s['query_ids'])) for s in shards)}
 m['counts']['secondary_ranking_runs']=m['counts']['all_runs']-m['counts']['primary_nonranking_runs']
 assert m['counts']['all_runs']==23680 and len(shards)==60
 for p in [out/'run_extension_grid.py',ext/'allocation_controls.py',ext/'mechanism_controls.py',out/'STUDY_PROTOCOL.json']:
  m['source_sha256'][str(p)]=sha(p)
 write_new(out/'run_manifest.json',m)
 print(json.dumps({'manifest':str(out/'run_manifest.json'),'sha256':sha(out/'run_manifest.json'),'counts':m['counts'],'shards':len(shards),'no_new_grid_or_model_execution':True},indent=2))

def execute(a):
 p=a.manifest.resolve();h=sha(p)
 if h!=a.expect_manifest_sha256:raise RuntimeError('Explicit manifest hash mismatch')
 m=json.loads(p.read_text());grid=get_grid(m['v3_old_root'])
 if Path(__file__).resolve()!=p.parent/'run_extension_grid.py':raise RuntimeError('Execute the separately frozen runner beside this manifest')
 for src,entry in m['v3_original_manifests'].items():
  if sha(entry['path'])!=entry['sha256']:raise RuntimeError('Historical baseline manifest changed')
  root=Path(entry['path']).parent/'results/shards'
  for path in root.glob(f'{src}__dual_greedy__*.csv'):
   for r in csv.DictReader(path.open()):
    if r['framework_exception']=='True' or r['invariants_valid']!='True':continue
    key=tuple(r[k] for k in ['source','query_id','budget_share','seed_id','semantics'])
    _BASELINE[key]=tuple(r[k] for k in ['pilot_ids_sha256','pilot_labels_sha256','scores_sha256','partition_sha256','priors_sha256','permutations_sha256'])
 if len(_BASELINE)!=10560:raise RuntimeError('Missing original main DG baseline records')
 grid.worker_initialize=initialize;grid.audit_finished_shard=audit_shard
 return grid.execute_manifest(argparse.Namespace(manifest=p,expect_manifest_sha256=h,workers=None))

def probe(a):
 import threading
 path=a.manifest.resolve();h=sha(path)
 if h!=a.expect_manifest_sha256:raise RuntimeError('Explicit manifest hash mismatch')
 m=json.loads(path.read_text());grid=get_grid(m['v3_old_root'])
 if Path(__file__).resolve()!=path.parent/'run_extension_grid.py':raise RuntimeError('Use frozen runner')
 root=a.out.resolve();root.mkdir(parents=True,exist_ok=False)
 shards=[]
 for s in m['shards']:
  if s['seed_id']!=0:continue
  kinds=['summary'] if s['method']=='max_dg' else ['pairwise','summary']
  ids=[next(q['query_id'] for q in m['query_metadata'] if q['kind']==k) for k in kinds]
  shards.append(dict(s,name='probe__'+s['name'],query_ids=ids,expected_rows=len(ids)))
 m['shards']=shards;m['counts']['all_runs']=sum(s['expected_rows'] for s in shards)
 m['v3_probe_scope']='First metadata-sorted pair/summary, seed0, bothsources, allthreecontrols; no primary estimates or policy retuning'
 write_new(root/'PROBE_MANIFEST.json',m);m['_runtime_manifest_sha256']=sha(root/'PROBE_MANIFEST.json')
 results=root/'results'
 for d in ['shards','progress']:(results/d).mkdir(parents=True,exist_ok=False)
 stop=threading.Event();initialize(m,str(results),stop)
 reports=[grid.run_shard(s) for s in shards]
 status={'status':'passed' if not stop.is_set() and all(not r['failure'] and r['completed']==r['expected'] for r in reports) else 'failed','rows':sum(r['completed'] for r in reports),'new_model_forwards':0,'source_frozen_manifest_sha256':h,'shards':reports}
 write_new(root/'PROBE_REPORT.json',status);print(json.dumps({k:v for k,v in status.items() if k!='shards'},indent=2))
 return 0 if status['status']=='passed' else 1

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--mode',choices=['freeze','probe','execute'],required=True);p.add_argument('--old-root',type=Path,default=DEFAULT_OLD);p.add_argument('--controls',type=Path);p.add_argument('--mechanism',type=Path);p.add_argument('--protocol',type=Path);p.add_argument('--out',type=Path);p.add_argument('--workers',type=int,default=16);p.add_argument('--manifest',type=Path);p.add_argument('--expect-manifest-sha256');a=p.parse_args()
 if a.mode=='freeze':
  if any(x is None for x in [a.controls,a.mechanism,a.protocol,a.out]):p.error('freeze needs --controls --mechanism --protocol --out')
  freeze(a);return 0
 return probe(a) if a.mode=='probe' else execute(a)
if __name__=='__main__':raise SystemExit(main())
