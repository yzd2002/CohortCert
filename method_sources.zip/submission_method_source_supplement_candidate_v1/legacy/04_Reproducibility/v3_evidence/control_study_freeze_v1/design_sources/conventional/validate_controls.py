"""Root finite property/closed-form checks; no corpus/label/GPU access."""
from pathlib import Path
import sys,math,json,hashlib
from fractions import Fraction as F
from types import MappingProxyType as RO
from dataclasses import replace
sys.path.insert(0,'/root/autodl-tmp/cohortcert_strong_revision_20261102/policy_freeze_v1')
sys.path.insert(0,str(Path(__file__).resolve().parent))
from executor_v2.state import CellView,AtomView,FamilyView,AcquisitionState
from executor_v2.baseline_policies import DualGreedy
from allocation_controls import NormalizedWidthGreedy,NormalizedNeyman

def state(cells,family):
 bounds={}
 for a in family.atoms:
  lo=hi=F(0)
  for c in cells:
   v=c.coefficients[a.row_index];lo+=v*(c.lower if v>=0 else c.upper);hi+=v*(c.upper if v>=0 else c.lower)
  bounds[a.index]=(lo,hi)
 return AcquisitionState(tuple(cells),family,RO(bounds),RO({}),101,17,16,'bidirectional',RO({}))
family=FamilyView((AtomView(0,'lower',F(0),0,'A>B',('A','B')),),((0,),),(0,),('compare',))
cells=[CellView(8,100,10,5,10,80,.01,1,1,.5,(F(1,100),)),CellView(2,100,20,10,15,60,.01,1,1,.5,(F(-1,100),))]
s=state(cells,family);original=repr(s);checks=0
for cls in [NormalizedWidthGreedy,NormalizedNeyman]:
 p=cls();base=p.score_candidates(s);assert p.choose(s).cell_id==8;checks+=1
 # Representation scale/sign and cell-order invariance.
 for scalar in [F(7),F(-7),F(1,13)]:
  cf=replace(family,atoms=(replace(family.atoms[0],kind='lower' if scalar>0 else 'upper'),))
  cs=[replace(c,coefficients=tuple(scalar*a for a in c.coefficients)) for c in cells]
  alt=state(list(reversed(cs)),cf);got=p.score_candidates(alt)
  a={r['cell_id']:r['score_per_cost'] for r in base['candidates']};b={r['cell_id']:r['score_per_cost'] for r in got['candidates']}
  assert a==b,(cls.__name__,scalar,a,b);checks+=1
 # Duplicate declarations share one precision target, not repeated weights.
 dup=FamilyView((family.atoms[0],replace(family.atoms[0],index=7)),((0,),(7,)),(0,1),('compare','compare'))
 got=p.score_candidates(state(cells,dup));assert got['live_contrast_classes']==1
 assert [x['score_per_cost'] for x in got['candidates']]==[x['score_per_cost'] for x in base['candidates']];checks+=1
 # Irrelevant huge stratum cannot steal positive precision gain.
 z=CellView(13,100000,100,50,100,90000,.01,1,1,.5,(F(0),))
 assert p.choose(state(cells+[z],family)).cell_id==8;checks+=1
 done=replace(s,bounds=RO({0:(F(1,10),F(3,10))}));assert p.choose(done).cell_id==-1;checks+=1
 assert p.choose(replace(s,remaining_calls=0)).cell_id==-1;checks+=1
 for bad in [0,-1,float('inf'),True]:
  try:p.choose(replace(s,unit_costs=RO({8:bad})))
  except ValueError:pass
  else:raise AssertionError('Invalid cost accepted')
  checks+=1
 assert repr(s)==original
# Independently hand-derived precision gains, using scalar algebra rather than
# the implementation's layout/normalization or internal helpers.
w=NormalizedWidthGreedy().score_candidates(s);rows={r['cell_id']:r for r in w['candidates']}
for c in cells:
 b=16;delta=(c.upper-c.lower)*(1-math.sqrt(c.n*(c.N-c.n-b)/((c.n+b)*(c.N-c.n))))
 expected=abs(float(c.coefficients[0]))*delta/(2*b)
 assert math.isclose(rows[c.cell_id]['score_per_cost'],expected,rel_tol=1e-13);checks+=1
n=NormalizedNeyman().score_candidates(s);rows={r['cell_id']:r for r in n['candidates']}
for c in cells:
 # Both observed fractions are exactly .5 even after Jeffreys smoothing.
 var=F(c.N,4*(c.N-1));expected=F(1,4)*var*(F(1,c.n)-F(1,c.n+16))/16
 assert math.isclose(rows[c.cell_id]['score_per_cost'],float(expected),rel_tol=1e-13);checks+=1
# Verify scalar reduction by cross-multiplying gains against expected common
# scaling across several thresholds and clipped batch prices.
lemma=0
for threshold in [F(-1,5),F(0),F(1,5)]:
 ff=replace(family,atoms=(replace(family.atoms[0],threshold=threshold),))
 for budget in [1,7,16,101]:
  ss=replace(state(cells,ff),remaining_calls=budget)
  dg=DualGreedy().score_candidates(ss);wg=NormalizedWidthGreedy().score_candidates(ss)
  a={r['cell_id']:r['gain_per_cost'] for r in dg['candidates']};b={r['cell_id']:r['score_per_cost'] for r in wg['candidates']}
  ids=sorted(a);assert set(a)==set(b)
  assert math.isclose(a[ids[0]]*b[ids[1]],a[ids[1]]*b[ids[0]],rel_tol=2e-11,abs_tol=1e-16)
  lemma+=1
report={'status':'passed','finite_property_and_closed_form_checks':checks,'scalar_DG_width_common_factor_states':lemma,'scale_sign_permutation_and_declaration_deduplication':True,'readonly_state_unchanged':True,'invalid_costs_rejected':True,'strong_control_fixture_expected_cell':8,'corpus_rows_opened':0,'model_forwards':0,'review_limit':'Root validation after subagent quota interruption; not an independent external/agent peer review or universal float proof.','source_sha256':hashlib.sha256((Path(__file__).parent/'allocation_controls.py').read_bytes()).hexdigest()}
(Path(__file__).parent/'VALIDATION.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
