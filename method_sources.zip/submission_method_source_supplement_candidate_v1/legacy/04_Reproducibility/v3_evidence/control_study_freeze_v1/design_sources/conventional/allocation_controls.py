"""Precision-directed controls for the frozen CohortCert v2 acquisition API.

These are allocation heuristics, not confidence bounds or named canonical query
engines. The caller must import the unmodified frozen executor_v2 package first.
Only public frozen state types and its exact decision checker are imported.
No corpus, label map, oracle, record identifier or sample permutation is opened.
"""
from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from functools import lru_cache
import math
import numpy as np
from executor_v2.state import AcquisitionState, Choice
from executor_v2.dual_certificate import evaluate

VERSION = "cohortcert.conventional-precision-controls.v3.1"


def _fraction(x):
    return x if isinstance(x, Fraction) else Fraction(str(x))


def _integer(x, name, *, lower=0):
    if type(x) is not int or x < lower:
        raise ValueError(name+" must be an integer >= "+str(lower))


def _validate(state):
    _integer(state.batch_size, "batch_size", lower=1)
    _integer(state.remaining_calls, "remaining_calls")
    if state.semantics not in ("bidirectional", "positive_only"):
        raise ValueError("Unknown completion semantics")
    cells = tuple(sorted(state.cells, key=lambda c: c.cell_id))
    if len({c.cell_id for c in cells}) != len(cells):
        raise ValueError("Duplicate cell IDs")
    for c in cells:
        _integer(c.cell_id, "cell_id"); _integer(c.N, "N")
        _integer(c.n, "n"); _integer(c.s, "s")
        _integer(c.lower, "lower"); _integer(c.upper, "upper")
        if not c.s <= c.n <= c.N or not c.lower <= c.upper <= c.N:
            raise ValueError("Invalid observed count or count interval")
        cost = state.unit_costs.get(c.cell_id, 1.0)
        if isinstance(cost, bool) or not math.isfinite(float(cost)) or float(cost) <= 0:
            raise ValueError("Per-record unit costs must be positive and finite")
    return cells


def _batch(state, c):
    return min(state.batch_size, state.remaining_calls, c.N-c.n)


@dataclass(frozen=True)
class _Layout:
    # One row per sign/scale-equivalent residual contrast direction.
    normalized_coefficients: np.ndarray
    row_to_class: dict


@lru_cache(maxsize=16)
def _layout(family, cell_metadata):
    row_ids = sorted({a.row_index for a in family.atoms})
    for j in row_ids:
        _integer(j, "contrast row")
        if any(j >= len(coefficients) for _, _, coefficients in cell_metadata):
            raise ValueError("Cell coefficient signature omits a contrast row")
    key_by_row = {}
    for j in row_ids:
        coefficients = tuple(_fraction(c[j]) if N else Fraction(0)
                             for _, N, c in cell_metadata)
        scale = sum((abs(a)*N for a, (_, N, _) in zip(coefficients, cell_metadata)), Fraction(0))
        if not scale:
            key_by_row[j] = None
            continue
        # The original residual full range is fixed after the pilot. Do not
        # rescale by the changing CS width or the requested threshold margin.
        sign = next(1 if a > 0 else -1 for a in coefficients if a)
        key_by_row[j] = tuple(sign*a/scale for a in coefficients)
    keys = sorted({key for key in key_by_row.values() if key is not None})
    index = {key: i for i, key in enumerate(keys)}
    rows = np.asarray([[float(x) for x in key] for key in keys], dtype=np.float64)
    rows = rows.reshape(len(keys), len(cell_metadata))
    if not np.isfinite(rows).all():
        raise ValueError("Normalized coefficients are not finite float64 values")
    rows.setflags(write=False)
    return _Layout(rows, {j: None if key is None else index[key] for j, key in key_by_row.items()})


def _live(state, layout):
    result = evaluate(state.family, state.bounds, mode=state.semantics)
    if result["complete"]:
        return result, (), ()
    unresolved_decisions = {d["decision"] for d in result["decisions"] if d["value"] is None}
    by_id = {a.index: a for a in state.family.atoms}
    atoms, classes = set(), set()
    # Prune only assertions already decided and witnesses already refuted.
    # There is no prediction of a proof side or midpoint-to-threshold gap.
    for witness, decision in zip(state.family.certificates, state.family.certificate_decisions):
        if decision not in unresolved_decisions or any(result["atom_states"][j] is False for j in witness):
            continue
        for j in witness:
            if result["atom_states"][j] is None:
                atoms.add(j)
                k = layout.row_to_class[by_id[j].row_index]
                if k is not None:
                    classes.add(k)
    return result, tuple(sorted(classes)), tuple(sorted(atoms))


def _width_reduction(c, b):
    if b <= 0:
        return 0.0
    if c.n+b == c.N:
        return float(c.width)
    if c.n == 0:
        return 0.0
    ratio = c.n*(c.N-c.n-b)/((c.n+b)*(c.N-c.n))
    return float(c.width)*(1.0-math.sqrt(max(0.0, ratio)))


class _PrecisionPolicy:
    policy_name = "abstract"

    def __init__(self, *, tie_tolerance=1e-12):
        self.tie_tolerance = float(tie_tolerance)
        if not math.isfinite(self.tie_tolerance) or self.tie_tolerance < 0:
            raise ValueError("tie_tolerance must be finite and nonnegative")

    def _scores(self, state):
        raise NotImplementedError

    def score_candidates(self, state: AcquisitionState):
        """Inspection aid; choose() emits only its small selected diagnostic."""
        return self._scores(state)

    def choose(self, state: AcquisitionState) -> Choice:
        scored = self._scores(state)
        active = sorted((c for c in state.cells if c.n < c.N), key=lambda c: c.cell_id) if state.remaining_calls else []
        common = {k: scored[k] for k in ("policy", "version", "objective", "objective_current",
                  "live_contrast_classes", "live_atoms", "exact_complete", "uninitialized_variance_fallback")}
        if scored["exact_complete"] or not active:
            return Choice(-1, 0, {**common, "reason": "complete" if scored["exact_complete"] else "no_available_calls_or_cells"})
        candidates = scored["candidates"]
        best = max((c["score_per_cost"] for c in candidates), default=0.0)
        if best <= 0:
            c = min(active, key=lambda c: (-c.N, c.cell_id))
            return Choice(c.cell_id, state.batch_size, {**common, "reason": "no_positive_precision_gain_largest_N_fallback",
                          "effective_batch": _batch(state, c), "score_per_cost": 0.0})
        tolerance = self.tie_tolerance*abs(best)
        chosen = min((c for c in candidates if c["score_per_cost"] >= best-tolerance), key=lambda c: c["cell_id"])
        return Choice(chosen["cell_id"], state.batch_size,
                      {**common, "reason": "initialize_unobserved_relevant_cell" if scored["uninitialized_variance_fallback"] else "maximum_precision_reduction_per_cost",
                       "effective_batch": chosen["effective_batch"], "predicted_gain": chosen["predicted_gain"],
                       "score_per_cost": chosen["score_per_cost"], "normalization": "fixed_postpilot_residual_full_range",
                       **({"estimated_population_variance": chosen["estimated_population_variance"]} if "estimated_population_variance" in chosen else {})})

    def _context(self, state):
        cells = _validate(state)
        metadata = tuple((c.cell_id, c.N, tuple(c.coefficients)) for c in cells)
        layout = _layout(state.family, metadata)
        result, live_classes, live_atoms = _live(state, layout)
        return cells, layout, result, live_classes, live_atoms

    def _header(self, result, classes, atoms):
        return {"policy": self.policy_name, "version": VERSION, "objective": self.objective_name,
                "objective_current": 0.0, "live_contrast_classes": len(classes), "live_atoms": len(atoms),
                "exact_complete": result["complete"], "uninitialized_variance_fallback": False, "candidates": []}


class NormalizedWidthGreedy(_PrecisionPolicy):
    """Greedy reduction of mean normalized live contrast interval width."""
    policy_name = "NormalizedWidthGreedy"
    objective_name = "mean_normalized_live_contrast_width"

    def _scores(self, state):
        cells, layout, result, classes, atoms = self._context(state)
        scored = self._header(result, classes, atoms)
        if result["complete"] or not classes:
            return scored
        weights = np.mean(np.abs(layout.normalized_coefficients[list(classes)]), axis=0)
        scored["objective_current"] = float(sum(float(w)*c.width for w, c in zip(weights, cells)))
        for weight, c in zip(weights, cells):
            b = _batch(state, c)
            if b <= 0:
                continue
            gain = float(weight)*_width_reduction(c, b)
            price = b*float(state.unit_costs.get(c.cell_id, 1.0))
            scored["candidates"].append({"cell_id": c.cell_id, "effective_batch": b,
                                          "predicted_gain": gain, "score_per_cost": gain/price})
        return scored


class NormalizedNeyman(_PrecisionPolicy):
    """Greedy plug-in weighted-variance reduction with finite-population FPC.

    The Bernoulli variance estimate uses Jeffreys-smoothed observed counts;
    it is held fixed for one lookahead. It is not a confidence interval, an
    unbiased adaptive estimate, or an asymptotically optimal query policy.
    """
    policy_name = "NormalizedNeyman"
    objective_name = "mean_normalized_live_contrast_variance_proxy"

    @staticmethod
    def _variance(c):
        p = (c.s+0.5)/(c.n+1.0)
        return (c.N/(c.N-1.0) if c.N > 1 else 1.0)*p*(1.0-p)

    def _scores(self, state):
        cells, layout, result, classes, atoms = self._context(state)
        scored = self._header(result, classes, atoms)
        if result["complete"] or not classes:
            return scored
        weights = np.mean(layout.normalized_coefficients[list(classes)]**2, axis=0)
        amounts = [float(w)*c.N*c.N*self._variance(c) for w, c in zip(weights, cells)]
        unseen = [(c, a) for c, a in zip(cells, amounts) if c.n == 0 and a > 0 and _batch(state, c) > 0]
        if unseen:
            # Common v2 initialization normally makes this branch unreachable.
            # An unobserved relevant stratum makes the classical variance
            # objective undefined; explicitly prioritize initialization instead
            # of inventing a finite/zero variance reduction or outputting inf.
            scored["objective_current"] = None
            scored["uninitialized_variance_fallback"] = True
            for c, amount in unseen:
                b = _batch(state, c)
                price = b*float(state.unit_costs.get(c.cell_id, 1.0))
                scored["candidates"].append({"cell_id": c.cell_id, "effective_batch": b,
                     "predicted_gain": None, "score_per_cost": amount/price,
                     "estimated_population_variance": self._variance(c)})
            return scored
        scored["objective_current"] = float(sum(amount*(1.0/c.n-1.0/c.N)
                                             for c, amount in zip(cells, amounts) if c.n and c.N))
        for c, amount in zip(cells, amounts):
            b = _batch(state, c)
            if b <= 0:
                continue
            gain = amount*(1.0/c.n-1.0/(c.n+b)) if c.n else 0.0
            price = b*float(state.unit_costs.get(c.cell_id, 1.0))
            scored["candidates"].append({"cell_id": c.cell_id, "effective_batch": b,
                  "predicted_gain": gain, "score_per_cost": gain/price,
                  "estimated_population_variance": self._variance(c)})
        return scored


POLICIES = {"normalized_width": NormalizedWidthGreedy, "normalized_neyman": NormalizedNeyman}
