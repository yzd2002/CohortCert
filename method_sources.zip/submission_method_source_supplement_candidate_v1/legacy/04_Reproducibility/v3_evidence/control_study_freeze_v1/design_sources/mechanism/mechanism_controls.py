"""V3 mechanism candidates; no corpus execution, labels, or model access.

MaxDG changes only the cross-decision aggregation of frozen DG lookahead gains.
Endpoint relaxation is an equal-observed-prefix diagnostic, not an executor.
The caller imports the unchanged frozen executor_v2 package before this module.
"""
from dataclasses import replace
from fractions import Fraction
from types import MappingProxyType
import math
from executor_v2.state import AcquisitionState,FamilyView,Choice
from executor_v2.baseline_policies import DualGreedy
from executor_v2.dual_certificate import evaluate


def project_decision(state: AcquisitionState, decision: int):
    """Keep original atom IDs/contrast-row indices and shared cell evidence."""
    f=state.family
    if decision not in f.decision_indices():raise ValueError('Undeclared decision')
    terms=tuple(f.certificates[i] for i,d in enumerate(f.certificate_decisions) if d==decision)
    used={j for w in terms for j in w}
    family=FamilyView(tuple(a for a in f.atoms if a.index in used),terms,
                      tuple(0 for _ in terms),(f.decision_types[decision],))
    return replace(state,family=family)


class MaxDG:
    """Max over LOCAL MARGINAL gain/cost, not maximum absolute difficulty.

    For fixed open sets and active h, frozen DG's per-decision score is D_d.
    Let Delta_dh=D_d(now)-D_d(width-lookahead h), and b_h be clipped size.
    This policy maximizes max_d Delta_dh/(b_h*unit_cost_h).
    Full DG maximizes [sum_d D_d(now)-sum_d D_d(h)]/(b_h*unit_cost_h).
    Arithmetic is shared through the unchanged frozen public score_candidates.
    The only treatment is sum of local gains versus max of local gains;
    initialization, exploration, inference and all cross-decision observations
    stay shared. Do not call this independent acquisition or a new optimal rule.
    """
    def __init__(self,gamma=1.,epsilon=1e-4,tie_tolerance=1e-12):
        self.base=DualGreedy(gamma=gamma,epsilon=epsilon,tie_tolerance=tie_tolerance)
        self.tie_tolerance=float(tie_tolerance)

    def score_candidates(self,state):
        exact=evaluate(state.family,state.bounds,mode=state.semantics)
        open_decisions=[d['decision'] for d in exact['decisions'] if d['value'] is None]
        # Read-only call; local projection never changes counts/bounds/costs.
        local={d:self.base.score_candidates(project_decision(state,d)) for d in open_decisions}
        active=sorted((c for c in state.cells if c.n<c.N),key=lambda c:c.cell_id) if state.remaining_calls else []
        rows=[]
        for cell in active:
            gains=[]
            for d,scores in local.items():
                candidates={c['cell_id']:c for c in scores['candidates']}
                c=candidates[cell.cell_id]
                gains.append((d,float(c['gain_per_cost']),float(c['gain'])))
            best=max((x[1] for x in gains),default=0.)
            leaders=[d for d,g,_ in gains if g>=best-self.tie_tolerance*max(1.,abs(best))]
            rows.append({'cell_id':cell.cell_id,'gain_per_cost':best,
                         'effective_batch':min(state.batch_size,state.remaining_calls,cell.N-cell.n),
                         'leading_decision':min(leaders) if leaders else None,
                         'local_gains':{str(d):g for d,g,_ in gains}})
        return {'exact_complete':exact['complete'],'open_decisions':open_decisions,'candidates':rows}

    def choose(self,state):
        # Exact single-decision delegation avoids floating aggregation drift and
        # provides a useful identity control on pair/equivalence/ranking tasks.
        if len(state.family.decision_types)<=1:
            chosen=self.base.choose(state)
            return Choice(chosen.cell_id,chosen.batch,{**(chosen.diagnostics or {}),
                'mechanism_control':'MaxDG','single_decision_exact_delegation':True})
        active=sorted((c for c in state.cells if c.n<c.N),key=lambda c:c.cell_id) if state.remaining_calls else []
        if not active:return Choice(-1,0,{'mechanism_control':'MaxDG','reason':'no_available_calls_or_cells'})
        scores=self.score_candidates(state)
        if scores['exact_complete']:return Choice(-1,0,{'mechanism_control':'MaxDG','reason':'already_complete'})
        best=max(x['gain_per_cost'] for x in scores['candidates'])
        if not math.isfinite(best):raise ArithmeticError('Nonfinite local gain/cost')
        if best<=0:
            chosen=min(active,key=lambda c:(-c.N,c.cell_id))
            return Choice(chosen.cell_id,state.batch_size,{'mechanism_control':'MaxDG',
                'reason':'no_positive_gain_largest_population','effective_batch':min(state.batch_size,state.remaining_calls,chosen.N-chosen.n)})
        tolerance=self.tie_tolerance*max(1.,abs(best))
        chosen=min((c for c in scores['candidates'] if c['gain_per_cost']>=best-tolerance),key=lambda c:c['cell_id'])
        return Choice(chosen['cell_id'],state.batch_size,{'mechanism_control':'MaxDG',
            'reason':'maximum_single_decision_marginal_gain_per_cost',
            'gain_per_cost':chosen['gain_per_cost'],'leading_decision':chosen['leading_decision'],
            'local_gains_for_chosen_cell':chosen['local_gains'],'effective_batch':chosen['effective_batch'],
            'gamma':self.base.gamma,'epsilon':self.base.epsilon,'tie_tolerance':self.tie_tolerance,
            'all_counts_and_labels_remain_shared':True})


def uncoupled_endpoint_shadow(state: AcquisitionState,cohort_sizes):
    """Return exact valid superset bounds at exactly the same observed prefix.

    All zero net coefficients remain cancelled in BOTH diagnostic arms.
    For each unscaled contrast row A-B with unequal denominators, a nonzero
    coefficient 1/|A|-1/|B| uniquely identifies an intersection cell. For such
    cells, separate marginal endpoint propagation loses
      P_j=sum_h min(1/|A|,1/|B|)*(upper_h-lower_h)
    on EACH side. Return [L_j-P_j,U_j+P_j]. This introduces no risk split,
    additional cell, duplicate read, new label or stronger inference guarantee.
    Snapshot membership and denominator consistency must be metadata-checked
    before use. Equal-denominator zero cells are intentionally still cancelled.
    """
    row_pairs={}
    for atom in state.family.atoms:
        pair=tuple(atom.cohort_pair)
        if len(pair)!=2:raise ValueError('Only direct cohort-rate contrast rows supported')
        if atom.row_index in row_pairs and row_pairs[atom.row_index]!=pair:raise ValueError('Inconsistent row/group mapping')
        row_pairs[atom.row_index]=pair
    penalties={}
    for row,(left,right) in row_pairs.items():
        nL,nR=cohort_sizes[left],cohort_sizes[right]
        if type(nL) is not int or type(nR) is not int or min(nL,nR)<=0:raise ValueError('Positive integer denominators required')
        aL,aR=Fraction(1,nL),Fraction(1,nR);intersection=aL-aR
        p=Fraction(0)
        for cell in state.cells:
            if row>=len(cell.coefficients):raise ValueError('Cell signature omits contrast row')
            a=Fraction(cell.coefficients[row])
            if a not in (Fraction(0),aL,-aR,intersection):raise ValueError('Coefficient cannot come from the declared two cohorts')
            if intersection and a==intersection:p+=min(aL,aR)*(cell.upper-cell.lower)
        penalties[row]=p
    bounds={}
    for atom in state.family.atoms:
        current=state.bounds.get(atom.index)
        if current is None:raise ValueError('Nonfailed state with all atom bounds required')
        lo,hi=map(Fraction,current)
        if lo>hi:raise ValueError('Reversed current interval')
        p=penalties[atom.row_index];bounds[atom.index]=(lo-p,hi+p)
    result=evaluate(state.family,MappingProxyType(bounds),mode=state.semantics)
    return {'bounds':MappingProxyType(bounds),'penalty_by_contrast_row':MappingProxyType(penalties),
            'verdict':result,'scope':'same observed prefix; no counterfactual acquisition-cost claim'}
