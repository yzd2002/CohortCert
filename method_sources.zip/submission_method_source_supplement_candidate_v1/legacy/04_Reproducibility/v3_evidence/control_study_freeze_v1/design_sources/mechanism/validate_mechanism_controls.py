"""Small independent algebra/selection fixtures; no corpus/source labels."""
from pathlib import Path
import sys,json,math,hashlib
from fractions import Fraction as F
from types import MappingProxyType as RO
from dataclasses import replace
FROZEN=Path('/root/autodl-tmp/cohortcert_strong_revision_20261102/policy_freeze_v1')
sys.path.insert(0,str(FROZEN));sys.path.insert(0,str(Path(__file__).resolve().parent))
from executor_v2.state import AtomView,FamilyView,CellView,AcquisitionState
from executor_v2.baseline_policies import DualGreedy
from executor_v2.dual_certificate import evaluate
from mechanism_controls import MaxDG,uncoupled_endpoint_shadow,project_decision

def state(cells,family,constants):
 bounds={}
 for a in family.atoms:
  lo=hi=constants.get(a.row_index,F(0))
  for c in cells:
   coeff=c.coefficients[a.row_index];lo+=coeff*(c.lower if coeff>=0 else c.upper);hi+=coeff*(c.upper if coeff>=0 else c.lower)
  bounds[a.index]=(lo,hi)
 return AcquisitionState(tuple(cells),family,RO(bounds),RO(constants),100,9,16,'bidirectional',RO({}))

# A shared cell offers two moderate benefits; separate cells offer one larger
# benefit. Max-marginal and sum-marginal should intentionally disagree.
f=FamilyView((AtomView(7,'lower',F(0),0,'A>B',('A','B')),
              AtomView(19,'lower',F(0),1,'C>B',('C','B'))),((7,),(19,)),(0,1),('compare','compare'))
cs=[CellView(0,200,20,10,40,120,.01,1,1,.5,(F(1,300),F(0))),
    CellView(1,200,20,10,40,120,.01,1,1,.5,(F(0),F(1,300))),
    CellView(2,100,10,5,30,70,.01,1,1,.5,(F(1,300),F(1,300)))]
s=state(cs,f,{0:F(-2,5),1:F(-2,5)});before=repr(s)
max_choice=MaxDG().choose(s);sum_choice=DualGreedy().choose(s)
assert max_choice.cell_id==0 and sum_choice.cell_id==2
# Independently derive the order from the fixed widths, population FPC and
# equal one-atom gaps. No call to either allocator computes these quantities.
own_delta=80*(1-math.sqrt(20*(200-20-16)/((20+16)*(200-20))))
shared_delta=40*(1-math.sqrt(10*(100-10-16)/((10+16)*(100-10))))
assert shared_delta<own_delta<2*shared_delta
assert repr(s)==before
local=project_decision(s,1);assert local.cells is s.cells and local.bounds is s.bounds
assert local.family.atoms[0].index==19 and local.family.atoms[0].row_index==1
assert MaxDG().choose(local).cell_id==DualGreedy().choose(local).cell_id
assert MaxDG().choose(replace(s,remaining_calls=0)).cell_id==-1

# Unequal overlap: independently enumerate EVERY possible cell count in the
# intervals and compare direct two-cohort rates to signed and relaxed bounds.
a=AtomView(0,'lower',F(1,20),0,'A-B>.05',('A','B'))
family=FamilyView((a,),((0,),),(0,),('compare',))
cells=[CellView(0,80,20,10,40,48,.01,1,1,.5,(F(1,100),)),
       CellView(1,20,4,2,8,12,.01,1,1,.5,(F(-1,400),)),
       CellView(2,60,10,5,20,24,.01,1,1,.5,(F(-1,80),))]
s2=state(cells,family,{0:F(0)});shadow=uncoupled_endpoint_shadow(s2,{'A':100,'B':80})
assert s2.bounds[0]==(F(7,100),F(21,100))
assert shadow['bounds'][0]==(F(3,100),F(1,4))
assert shadow['penalty_by_contrast_row'][0]==F(1,25)
assert evaluate(family,s2.bounds)['complete'] and not shadow['verdict']['complete']
count=0
for kA in range(40,49):
 for kI in range(8,13):
  for kB in range(20,25):
   theta=F(kA+kI,100)-F(kB+kI,80)
   assert s2.bounds[0][0]<=theta<=s2.bounds[0][1]
   assert shadow['bounds'][0][0]<=theta<=shadow['bounds'][0][1]
   # Direct independently varied marginal endpoints give the same relaxation.
   directlo=F(40,100)+F(8,100)-F(12,80)-F(24,80)
   directhi=F(48,100)+F(12,100)-F(8,80)-F(20,80)
   assert shadow['bounds'][0]==(directlo,directhi)
   count+=1
# Equal denominator shared rows cancel in both arms, not charged to this
# diagnostic as a sampling advantage. A zero coefficient may also be neither.
ce=[replace(cells[0],coefficients=(F(1,100),)),
    replace(cells[1],coefficients=(F(0),)),replace(cells[2],coefficients=(F(-1,100),))]
se=state(ce,family,{0:F(0)});xe=uncoupled_endpoint_shadow(se,{'A':100,'B':100})
assert dict(xe['bounds'])==dict(se.bounds) and xe['penalty_by_contrast_row'][0]==0
# Exact exhausted cells incur no interval-dependency penalty.
ex=[replace(c,lower=c.s,upper=c.s) for c in cells];sx=state(ex,family,{0:F(0)})
assert dict(uncoupled_endpoint_shadow(sx,{'A':100,'B':80})['bounds'])==dict(sx.bounds)
report={'status':'passed','synthetic_selection_disagreement':{'SumDG':sum_choice.cell_id,'MaxDG':max_choice.cell_id,'independent_gain_order_checked':True},'single_decision_delegation':True,'original_noncontiguous_atom_and_row_indices_preserved':True,'read_only_state_unchanged':True,'exhaustive_unequal_overlap_count_vectors':count,'same_prefix_bounds':{'signed':['7/100','21/100'],'uncoupled':['3/100','1/4']},'equal_denominator_zero_coefficients_still_cancel':True,'exhausted_count_bounds_identical':True,'corpus_rows_or_label_maps_opened':0,'model_forwards':0,'scope':'Finite illustrative arithmetic fixtures, not full executor or all-input floating-point validation.'}
p=Path(__file__).resolve().parent/'VALIDATION.json';p.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
