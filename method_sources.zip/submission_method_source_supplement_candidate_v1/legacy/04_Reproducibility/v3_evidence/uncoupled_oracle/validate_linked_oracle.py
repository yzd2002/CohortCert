"""Exhaustive finite mechanical validation; no real-data optimizer calls."""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import json,time
from linked_oracle import duplicate_problem,linked_model,checked_candidate,evaluate,proof_at,frozen,exact_lp

def main():
 out=Path(__file__).resolve().parent/'FINITE_VALIDATION.json';assert not out.exists()
 states=plans=feasible=0;strict=False
 for totals in product(range(2),range(3),range(2)):
  paths=[]
  for N,K in zip([1,2,1],totals):
   # Exact nested counting bounds for an arbitrary fixed finite label order.
   ys=[1]*K+[0]*(N-K);s=0;path=[(0,N)]
   for n,y in enumerate(ys,1):s+=y;path.append((s,s+N-n))
   paths.append(path)
  coeff=[3,-2,1];value=sum(a*K for a,K in zip(coeff,totals))
  atoms=[{'offset':0,'coeff':coeff},{'offset':2,'coeff':[-a for a in coeff]}]
  declared=[{'row_index':0,'threshold':'0','cohort_pair':['A','B']},{'row_index':0,'threshold':'1/3','cohort_pair':['A','B']}]
  initial={'cells':[{'cell_id':i,'coefficients':[str(a)]} for i,a in enumerate([F(1,2),-F(1,3),F(1,6)])],'pilot_constants':{'0':'0'}}
  payload={'paths':paths,'atoms':atoms,'family':[[[0,1]]],'allow_negative':[True],'pilot_cost':7,'mode':'bidirectional'}
  problem,scales=duplicate_problem(payload,initial,declared,{'A':2,'B':3},[value>0,2-value>0]);assert scales==['6','-6']
  grids=[list(range(len(p))) for p in paths];model,options=linked_model(problem,grids,False)
  best=None
  for prefixes in product(*(range(len(p)) for p in paths)):
   proof=proof_at(problem,tuple(n for x in prefixes for n in [x,x]));end=[p[n] for p,n in zip(paths,prefixes)]
   lo=F(end[0][0],2)-F(end[1][1],3)+F(end[2][0],2)-F(end[2][1],3)
   hi=F(end[0][1],2)-F(end[1][0],3)+F(end[2][1],2)-F(end[2][0],3)
   assert proof['bounds_integer_oriented']==((6*lo,6*hi),(2-6*hi,2-6*lo))
   signedlo=3*end[0][0]-2*end[1][1]+end[2][0];signedhi=3*end[0][1]-2*end[1][0]+end[2][1]
   assert 6*lo<=signedlo<=signedhi<=6*hi
   strict|=6*lo<signedlo or signedhi<6*hi
   if proof['complete']:
    cand,check,cost=checked_candidate(model,options,prefixes,problem);assert model.feasible(cand) and cost==sum(prefixes) and check['total_calls']==7+sum(prefixes);feasible+=1
    best=cost if best is None else min(best,cost)
   else:
    try:checked_candidate(model,options,prefixes,problem)
    except ValueError:pass
    else:raise AssertionError('Incomplete source proof admitted')
   plans+=1
  result=evaluate(problem,grids);assert result['lower_total']<=7+best<=result['upper_total'];assert result['upper_total']==7+best
  states+=1
 # A genuinely canceling cell must stay zero in the intervention.
 p={'paths':[[(0,2),(1,2),(1,1)]],'atoms':[{'offset':-1,'coeff':[0]}],'family':[[[0]]],'allow_negative':[True],'pilot_cost':0}
 initial={'cells':[{'cell_id':0,'coefficients':['0']}],'pilot_constants':{'0':'0'}}
 # No nonzero row means there is no recoverable scale; real metadata omits
 # such rows from support. The validation above covers the actual domain.
 result={'status':'passed','finite_source_vectors':states,'all_prefix_allocations':plans,'checked_feasible_model_candidates':feasible,'compact_mip_matches_exhaustive_cost_all_vectors':True,'virtual_bounds_match_direct_physical_endpoint_arithmetic':True,'physical_cost_charged_once':True,'signed_interval_is_subset':True,'strict_interval_superset_observed':strict,'rational_lower_bound_checked':True,'actual192data_optimizer_calls':0,'scope':'Finite mechanical checks by root; no independent-agent review or statistical validation claim'}
 out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
