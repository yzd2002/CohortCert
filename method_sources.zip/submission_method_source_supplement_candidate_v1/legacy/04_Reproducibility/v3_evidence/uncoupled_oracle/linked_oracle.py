"""Offline endpoint-dependence intervention; physical cells/prefixes unchanged.

Two virtual interval appearances share an exact option-selection equality.
Only the first appearance carries read cost. Existing integer model/proof
logic and a separately checked rational dual are reused without source edits.
"""
from pathlib import Path
from fractions import Fraction as F
from math import ceil,isfinite,lcm
import json,gzip,sys,time,warnings
OLD=Path('/root/autodl-tmp/cohortcert_strong_revision_20261102')
sys.path.insert(0,str(OLD/'policy_freeze_v1'));sys.path.insert(0,str(OLD/'oracle_evaluation'));sys.path.insert(0,str(OLD/'policy_freeze_v1/system_design'))
from theory_design import certificate_frontier as frozen
from oracle_core import Problem,proof_at,truth_cuts,candidate_for_indices,serialize_model,independently_check_lagrange


def duplicate_problem(paths_payload,initial,family_atoms,denominators,atom_truth):
 H=len(paths_payload['paths']);cells=initial['cells'];assert len(cells)==H and [c['cell_id'] for c in cells]==list(range(H))
 atoms=[];scales=[]
 for j,(encoded,declared) in enumerate(zip(paths_payload['atoms'],family_atoms)):
  row=declared['row_index'];raw=[F(c['coefficients'][row]) for c in cells];orig=encoded['coeff']
  r=next(F(v,a) for v,a in zip(orig,raw) if a);assert r.denominator==1 and r!=0
  assert all(F(v)==r*a for v,a in zip(orig,raw))
  assert r*(F(initial['pilot_constants'][str(row)])-F(declared['threshold']))==encoded['offset']
  left,right=declared['cohort_pair'];p=F(1,denominators[left]);q=F(1,denominators[right]);new=[]
  for h,a in enumerate(raw):
   if a==0:u=v=F(0) # preserve common zero-net filtering in botharms
   elif p!=q and a==p-q:u,v=r*p,-r*q
   elif a==p:u,v=r*p,F(0)
   elif a==-q:u,v=F(0),-r*q
   else:raise ValueError('Unsupported membership coefficient')
   assert u+v==orig[h]
   new.extend([u,v])
  # Integerizing the NET coefficient need not integerize its two appearances
  # when exclusive regions are absent. Positive rescaling preserves the atom.
  factor=lcm(*(v.denominator for v in new))
  atoms.append(frozen.Atom(int(encoded['offset'])*factor,tuple(int(v*factor) for v in new)));scales.append(str(r*factor))
 paths=[]
 for path in paths_payload['paths']:
  pp=tuple(None if v is None else tuple(v) for v in path);paths.extend([pp,pp])
 problem=Problem(tuple(atoms),tuple(tuple(tuple(w) for w in d) for d in paths_payload['family']),tuple(paths_payload['allow_negative']),tuple(atom_truth),tuple(paths),paths_payload['pilot_cost'],paths_payload.get('mode','bidirectional'))
 return problem,scales


def linked_model(problem,physical_grids,optimistic):
 grids=[g for grid in physical_grids for g in [grid,grid]]
 original=frozen.grid_options(problem.paths,grids,optimistic=optimistic)
 options=tuple(tuple((cost if h%2==0 else 0,n) for cost,n in local) for h,local in enumerate(original))
 model=frozen.build_model((problem.paths,),options,problem.atoms,problem.family,mode=problem.mode,frontier=True,allow_negative=problem.allow_negative)
 truth_cuts(model,problem)
 for h in range(0,len(problem.paths),2):
  assert len(model.xvars[h])==len(model.xvars[h+1])
  for a,b in zip(model.xvars[h],model.xvars[h+1]):model.rows.extend([{a:1,b:-1},{a:-1,b:1}]);model.rhs.extend([0,0])
 return model,options


def checked_candidate(model,options,physical_indices,problem):
 indices=tuple(k for i in physical_indices for k in [i,i]);candidate,proof,cost=candidate_for_indices(model,options,indices,problem)
 prefixes=proof['prefixes'];assert all(prefixes[h]==prefixes[h+1] for h in range(0,len(prefixes),2))
 physical=tuple(prefixes[::2]);assert cost==sum(physical)
 proof=dict(proof,virtual_prefix_sum_not_physical_cost=proof['formal_calls'],physical_prefixes=physical,formal_calls=sum(physical),total_calls=problem.pilot_cost+sum(physical))
 return candidate,proof,cost


def coordinate(problem,grids,seconds=.25):
 indices=[len(g)-1 for g in grids];prefixes=[g[-1] for g in grids];deadline=time.perf_counter()+seconds
 def complete(pp):return proof_at(problem,tuple(n for x in pp for n in [x,x]))['complete']
 assert complete(prefixes)
 for h in sorted(range(len(grids)),key=lambda h:(-grids[h][-1],h)):
  lo,hi=0,indices[h]
  while lo<hi and time.perf_counter()<deadline:
   mid=(lo+hi)//2;trial=prefixes.copy();trial[h]=grids[h][mid]
   if complete(trial):hi=mid
   else:lo=mid+1
  # If interrupted choose the proven-feasible hi, never an untested lo.
  indices[h]=hi;prefixes[h]=grids[h][hi]
  if time.perf_counter()>=deadline:break
 assert complete(prefixes)
 return tuple(indices)


def exact_lp(model,seconds=3.):
 import numpy as np
 from scipy.optimize import linprog
 from scipy.sparse import coo_matrix
 rr=[];cc=[];vv=[]
 for i,row in enumerate(model.rows):
  for j,v in row.items():rr.append(i);cc.append(j);vv.append(v)
 matrix=coo_matrix((np.array(vv,float),(rr,cc)),shape=(len(model.rows),len(model.names))).tocsc()
 er=[];ec=[]
 for i,group in enumerate(model.groups):er.extend([i]*len(group));ec.extend(group)
 eq=coo_matrix((np.ones(len(er)),(er,ec)),shape=(len(model.groups),len(model.names))).tocsc()
 start=time.perf_counter()
 with warnings.catch_warnings(record=True) as ws:
  warnings.simplefilter('always');res=linprog(model.costs,A_ub=-matrix,b_ub=-np.array(model.rhs),A_eq=eq,b_eq=np.ones(len(model.groups)),bounds=(0,1),method='highs',options={'time_limit':seconds,'threads':1})
 marg=getattr(getattr(res,'ineqlin',None),'marginals',None)
 lam=tuple(F(str(max(0.,-float(x)))) if isfinite(float(x)) else F(0) for x in marg) if marg is not None and len(marg)==len(model.rows) else (F(0),)*len(model.rows)
 b=model.rational_lower_bound(lam);payload=serialize_model(model);assert independently_check_lagrange(payload,lam)==b
 return {'float_status':int(res.status),'float_message':str(res.message),'rational_formal_lower':str(b),'integer_formal_lower':max(0,ceil(b)),'multipliers':list(map(str,lam)),'model':payload,'wall_seconds':time.perf_counter()-start,'native_threads_requested':1,'warnings':[str(w.message) for w in ws]}


def evaluate(problem,grids):
 begin=time.perf_counter();legal=tuple(frozen.legal_length(p) for p in problem.paths);assert all(legal[h]==legal[h+1] for h in range(0,len(legal),2))
 maximum=proof_at(problem,legal)
 if not maximum['complete']:
  maximum=dict(maximum,physical_prefixes=legal[::2],virtual_prefix_sum_not_physical_cost=maximum['formal_calls'],formal_calls=sum(legal[::2]),total_calls=problem.pilot_cost+sum(legal[::2]))
  return {'status':'verified_no_source_valid_proof','lower_total':None,'upper_total':None,'infeasibility_witness':maximum,'wall_seconds':time.perf_counter()-begin}
 upper_model,options=linked_model(problem,grids,False);warm=coordinate(problem,grids);candidate,upper_proof,cost=checked_candidate(upper_model,options,warm,problem)
 lower_model,lower_options=linked_model(problem,grids,True);lp=exact_lp(lower_model,3.)
 upper_model.rows.append({j:-v for j,v in enumerate(upper_model.costs) if v});upper_model.rhs.append(-cost);assert upper_model.feasible(candidate)
 solved=frozen.solve_model(upper_model,time_limit=3.)
 if solved.get('exact_incumbent_verified'):
  chosen=tuple(next(i for i,j in enumerate(group) if solved['candidate'][j]) for group in upper_model.xvars)
  assert all(chosen[h]==chosen[h+1] for h in range(0,len(chosen),2))
  newcand,proof,newcost=checked_candidate(upper_model,options,chosen[::2],problem)
  if newcost<cost:candidate,upper_proof,cost=newcand,proof,newcost
 lower=lp['integer_formal_lower'];assert lower<=cost
 return {'status':'verified_finite_bracket','lower_total':problem.pilot_cost+lower,'upper_total':problem.pilot_cost+cost,'pilot_cost':problem.pilot_cost,'physical_upper_proof':upper_proof,'upper_candidate':candidate,'upper_model':serialize_model(upper_model),'upper_options':options,'lower_certificate':lp,'mip_reported_status':solved['status'],'mip_exact_incumbent_verified':solved.get('exact_incumbent_verified'),'mip_float_lower_not_used':True,'relative_total_gap':(cost-lower)/max(1,problem.pilot_cost+cost),'wall_seconds':time.perf_counter()-begin}
