"""Separate exact checks of all192 linked frontier artifacts, then summarize."""
from pathlib import Path
from fractions import Fraction as F
from math import ceil
from collections import Counter
import json,gzip,hashlib,statistics
from linked_oracle import duplicate_problem,linked_model,serialize_model,independently_check_lagrange,OLD
HERE=Path(__file__).resolve().parent
def read(p):
 if str(p).endswith('.gz'):
  with gzip.open(p,'rt') as f:return json.load(f)
 return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'))
def main():
 root=HERE/'study_v1';m=read(root/'manifest.json');c=read(root/'completion.json');assert c['case_count']==len(c['summary'])==192
 entries={r['case_id']:r for r in m['cases']};checked=[]
 for row in c['summary']:
  e=entries[row['case_id']];dest=root/'cases'/row['case_id'];assert sha(dest/'verified_result.json.gz')==row['result_sha256']
  res=read(dest/'verified_result.json.gz');src=read(e['files']['paths']);ini=read(e['files']['initial']);problem,scales=duplicate_problem(src,ini,e['family_atoms'],e['denominators'],src['source_truth']);assert scales==res['oriented_integer_scales']
  proof=res.get('physical_upper_proof',res.get('infeasibility_witness'));prefixes=proof['physical_prefixes'];bounds=[];penalties=[]
  for j,(encoded,atom,scale) in enumerate(zip(src['atoms'],e['family_atoms'],map(F,scales))):
   raw=[F(cell['coefficients'][atom['row_index']]) for cell in ini['cells']];r0=next(F(v,a) for v,a in zip(encoded['coeff'],raw) if a);factor=scale/r0;assert factor.denominator==1 and factor>0
   lo=hi=F(encoded['offset'])*factor;penalty=F(0);A,B=atom['cohort_pair'];p,q=F(1,e['denominators'][A]),F(1,e['denominators'][B])
   for a,v,path,n in zip(raw,encoded['coeff'],src['paths'],prefixes):
    l,u=path[n];v*=factor;lo+=v*(l if v>=0 else u);hi+=v*(u if v>=0 else l)
    if p!=q and a==p-q:penalty+=abs(scale)*min(p,q)*(u-l)
   assert [lo-penalty,hi+penalty]==proof['bounds_integer_oriented'][j];bounds.append((lo-penalty,hi+penalty));penalties.append(penalty)
  truths=src['source_truth'];ta=[lo>=1 and truth for (lo,hi),truth in zip(bounds,truths)];fa=[hi<=0 and not truth for (lo,hi),truth in zip(bounds,truths)]
  complete=all(any(all(ta[j] for j in w) for w in family) or src['allow_negative'][d] and all(any(fa[j] for j in w) for w in family) for d,family in enumerate(src['family']))
  assert complete==proof['complete'];assert proof['formal_calls']==sum(prefixes);assert proof['total_calls']==src['pilot_cost']+sum(prefixes)
  if row['status']=='verified_finite_bracket':
   assert complete
   lower,_=linked_model(problem,res['physical_grids'],True);assert canon(serialize_model(lower))==canon(res['lower_certificate']['model'])
   b=independently_check_lagrange(res['lower_certificate']['model'],res['lower_certificate']['multipliers']);assert b==F(res['lower_certificate']['rational_formal_lower']);assert row['uncoupled_lower_total']==src['pilot_cost']+max(0,ceil(b))
   upper,options=linked_model(problem,res['physical_grids'],False);cost=proof['formal_calls']
   # The MIP retains the INITIAL warm incumbent's cost cut even when it
   # improves that incumbent. Rebuild that recorded cut, then verify that the
   # final proof cost satisfies it, rather than silently tightening the row.
   warm_cut=res['upper_model']['rhs'][-1];assert type(warm_cut) is int and -warm_cut>=cost
   upper.rows.append({i:-v for i,v in enumerate(upper.costs) if v});upper.rhs.append(warm_cut)
   assert canon(serialize_model(upper))==canon(res['upper_model']) and upper.feasible(tuple(res['upper_candidate']))
   assert sum(v*bit for v,bit in zip(upper.costs,res['upper_candidate']))==cost
   for h,group in enumerate(upper.xvars):
    selected=[k for k,v in enumerate(group) if res['upper_candidate'][v]];assert len(selected)==1
    assert options[h][selected[0]][1]==proof['prefixes'][h]
   assert src['pilot_cost']+cost==row['uncoupled_upper_total'];assert row['uncoupled_lower_total']<=row['uncoupled_upper_total']
  else:
   assert row['status']=='verified_no_source_valid_proof' and not complete
   assert prefixes==[next((n-1 for n,v in enumerate(path) if v is None),len(path)-1) for path in src['paths']]
  checked.append({'case_id':row['case_id'],'status':'passed','separate_endpoint_width_penalty_check':True,'dual_and_feasible_candidate_rechecked':row['status']=='verified_finite_bracket'})
 assert len(checked)==192
 audit={'status':'passed','cases':192,'checks':checked,'scope':'Separately implemented exact width-penalty endpoints, physical costs, Boolean source proofs and rational dual evaluator; root executed, no independent-agent recommendation.'}
 (root/'ALL192_ARTIFACT_VERIFICATION.json').write_text(json.dumps(audit,indent=2)+'\n')
 summary={'status':'complete_and_all192_verified','manifest_sha256':sha(root/'manifest.json'),'auditor_sha256':sha(Path(__file__)),'scope':m['semantics'],'by_source':{}}
 for source in ['human','model']:
  rows=[r for r in c['summary'] if r['source']==source];finite=[r for r in rows if r['uncoupled_lower_total'] is not None];strict=[r for r in rows if r['certified_strict_extra_proof_cost']]
  summary['by_source'][source]={'all_cases':len(rows),'finite_brackets':len(finite),'no_source_valid_proof':len(rows)-len(finite),'strict_extra_proof_cost_certified':len(strict),'strict_extra_total_calls_lower_sum':sum(r['certified_extra_calls_lower'] for r in strict),'strict_extra_total_calls_lower_median':statistics.median(r['certified_extra_calls_lower'] for r in strict) if strict else None,'within_cap_classification':dict(Counter(r['uncoupled_at_cap'] for r in rows)),'finite_gap_median':statistics.median(r['relative_total_gap'] for r in finite),'finite_gap_max':max(r['relative_total_gap'] for r in finite),'signed_within_but_uncoupled_above_cap':sum(r['signed_upper_total'] is not None and r['signed_upper_total']<=r['cap'] and r['uncoupled_lower_total'] is not None and r['uncoupled_lower_total']>r['cap'] for r in rows),'strict_by_kind':dict(Counter(r['kind'] for r in strict)),'strict_by_predicate':dict(Counter(r['predicate'] for r in strict))}
 summary['limitations']='SamecellcountCSandatomwiseexistentialproofsystem only; zero-netfiltercommon; wide finitebounds retained; no onlinecausalsavings, no independentcorpusinference.'
 (root/'FINAL_UNCOUPLED_MECHANISM_SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
