"""Freeze and retain all192 source-valid endpoint-dependence diagnostics."""
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
from fractions import Fraction as F
from collections import Counter
from datetime import datetime,timezone
import argparse,json,gzip,hashlib,sys,time,traceback,multiprocessing as mp
from linked_oracle import OLD,duplicate_problem,evaluate,frozen,proof_at
HERE=Path(__file__).resolve().parent

def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for x in iter(lambda:f.read(4*1024*1024),b''):h.update(x)
 return h.hexdigest()
def read(p):
 if str(p).endswith('.gz'):
  with gzip.open(p,'rt') as f:return json.load(f)
 return json.loads(Path(p).read_text())
def save(p,d):
 with Path(p).open('x') as f:f.write(json.dumps(d,indent=2,allow_nan=False)+'\n')
def freeze(out):
 import pyarrow.parquet as pq
 sys.path.insert(0,str(OLD/'policy_freeze_v1'))
 from executor_v2.run_grid import independent_family
 assert read(HERE/'FINITE_VALIDATION.json')['status']=='passed'
 out.mkdir(exist_ok=False);root=OLD/'oracle_evaluation';cases=[];hashes={}
 for source in ['human','model']:
  src=root/f'{source}_oracle_v1';om=read(src/'oracle_manifest.json');grid=read(om['grid_manifest_path'])
  qs={q['query_id']:q for q in [json.loads(x) for x in Path(grid['inputs']['queries']['path']).read_text().splitlines()]}
  metadata=pq.read_table(grid['inputs']['snapshot']['path']).to_pylist()
  hashes[om['grid_manifest_path']]=sha(Path(om['grid_manifest_path']));hashes[grid['inputs']['snapshot']['path']]=grid['inputs']['snapshot']['sha256'];hashes[str(src/'oracle_manifest.json')]=sha(src/'oracle_manifest.json')
  finalpath=root/('human_precision_recovery_v2' if source=='human' else 'model_formal_reconciliation_v1')/'completion.json';final={r['case_id']:r for r in read(finalpath)['summary']};hashes[str(finalpath)]=sha(finalpath)
  for entry in om['cases']:
   case=src/'cases'/entry['case_id'];contract=qs[entry['query_id']]['contract'];family=independent_family(contract)
   denominators={c['id']:sum(r[c['filter_ast']['eq'][0]] is True for r in metadata) for c in contract['cohorts']}
   files={k:case/v for k,v in {'paths':'actual_prefix_paths.json.gz','initial':'initial_n0_state.json','signed_result':'oracle_result.json','signed_grid':'verified_lower_bound_certificate.json.gz'}.items() if (case/v).exists()}
   if source=='model' and (root/'model_formal_reconciliation_v1/cases'/entry['case_id']/'combined_upper_proof.json').exists():files['signed_final_upper']=root/'model_formal_reconciliation_v1/cases'/entry['case_id']/'combined_upper_proof.json'
   for p in files.values():hashes[str(p)]=sha(p)
   row={**entry,'files':{k:str(p) for k,p in files.items()},'family_atoms':family['atoms'],'denominators':denominators,'signed_lower_total':final[entry['case_id']].get('lower_total'),'signed_upper_total':final[entry['case_id']].get('upper_total'),'signed_status':final[entry['case_id']]['status']}
   cases.append(row)
 assert len(cases)==192 and len({r['case_id'] for r in cases})==192
 sources=[*HERE.glob('*.py'),HERE/'FINITE_VALIDATION.json',HERE/'STUDY_PROTOCOL_BEFORE_NEW_OPTIMIZATION.json',OLD/'policy_freeze_v1/theory_design/certificate_frontier.py',OLD/'oracle_evaluation/oracle_core.py']
 manifest={'status':'frozen_before_first_new_uncoupled_optimization','created_utc':datetime.now(timezone.utc).isoformat(),'case_count':192,'cases':cases,'input_sha256':hashes,'source_sha256':{str(p):sha(p) for p in sources},'resource_limits':{'workers':2,'coordinate_seconds':.25,'LP_native_seconds':3,'MIP_native_seconds':3,'native_threads':1},'semantics':'Identical physical labels/pilot/countCS/risk/prefixes; two interval appearances linked to same prefix selection, cost chargedonce; zero-net filtering preserved. Existential atomwise proof cost, not an online first-stop counterfactual.','grid_rule':'Original verified signed grids plus original/final signed feasible prefix plus legalendpoint, same for every case. No refinements conditionedon new outcomes.'}
 save(out/'manifest.json',manifest);print(json.dumps({'manifest':str(out/'manifest.json'),'sha256':sha(out/'manifest.json'),'cases':192}))

def direct_check(problem,scales,payload,initial,entry,result):
 # No optimizer/model expressions: independently calculate separate physical
 # cohort endpoints from the declared coefficient signature and denominators.
 if result['status']=='verified_finite_bracket':proof=result['physical_upper_proof']
 else:proof=result['infeasibility_witness']
 prefixes=proof['physical_prefixes'];direct=[]
 for atom,r in zip(entry['family_atoms'],map(F,scales)):
  lo=hi=r*(F(initial['pilot_constants'][str(atom['row_index'])])-F(atom['threshold']))
  A,B=atom['cohort_pair'];a,b=F(1,entry['denominators'][A]),F(1,entry['denominators'][B])
  for cell,path,n in zip(initial['cells'],payload['paths'],prefixes):
   c=F(cell['coefficients'][atom['row_index']]);l,u=path[n]
   if c==0:continue
   if a!=b and c==a-b:parts=[r*a,-r*b]
   elif c==a:parts=[r*a]
   elif c==-b:parts=[-r*b]
   else:raise AssertionError('Unrecognized source coefficient')
   for v in parts:lo+=v*(l if v>=0 else u);hi+=v*(u if v>=0 else l)
  direct.append([int(lo),int(hi)]);assert lo.denominator==hi.denominator==1
 assert direct==[list(x) for x in proof['bounds_integer_oriented']]
 assert proof['formal_calls']==sum(prefixes) and proof['total_calls']==payload['pilot_cost']+sum(prefixes)
 K=payload['source_reference']['cell_source_totals'];assert tuple(a.offset+sum(v*k for v,k in zip(a.coeff,[n for x in K for n in [x,x]]))>0 for a in problem.atoms)==problem.atom_truth
 return {'direct_physical_endpoint_arithmetic':'passed','physical_label_cost_once':'passed','oriented_fullsource_truth':'passed'}

def work(entry,out):
 start=time.perf_counter();cpu=time.process_time();dest=Path(out)/'cases'/entry['case_id'];dest.mkdir(exist_ok=False)
 try:
  files=entry['files'];payload=read(files['paths']);initial=read(files['initial']);problem,scales=duplicate_problem(payload,initial,entry['family_atoms'],entry['denominators'],payload['source_truth'])
  signed=read(files['signed_result']);grids=[set([0,frozen.legal_length(p)]) for p in payload['paths']]
  if 'signed_grid' in files:
   for s,g in zip(grids,read(files['signed_grid'])['grids']):s.update(g)
  for proof in [signed.get('upper_proof'),read(files['signed_final_upper']).get('proof') if 'signed_final_upper' in files else None]:
   if proof:
    for g,n in zip(grids,proof['prefixes']):g.add(n)
  grids=[sorted(g) for g in grids];result=evaluate(problem,grids);checks=direct_check(problem,scales,payload,initial,entry,result)
  if result['lower_total'] is not None and entry['signed_lower_total'] is not None:assert entry['signed_lower_total']<=result['upper_total']
  result['physical_grids']=grids;result['oriented_integer_scales']=scales;result['direct_checks']=checks
  with gzip.open(dest/'verified_result.json.gz','xt') as f:json.dump(result,f,allow_nan=False)
  cap=(entry['support_size']+1)//2
  strict=result['lower_total'] is not None and entry['signed_upper_total'] is not None and entry['signed_upper_total']<result['lower_total']
  summary={k:entry[k] for k in ['case_id','source','query_id','kind','predicate','seed_id','support_size','signed_lower_total','signed_upper_total','signed_status']}
  summary.update(status=result['status'],uncoupled_lower_total=result['lower_total'],uncoupled_upper_total=result['upper_total'],certified_strict_extra_proof_cost=strict,certified_extra_calls_lower=result['lower_total']-entry['signed_upper_total'] if strict else 0,uncoupled_at_cap='no_source_valid_proof' if result['lower_total'] is None else 'within_cap' if result['upper_total']<=cap else 'above_cap' if result['lower_total']>cap else 'indeterminate',cap=cap,relative_total_gap=result.get('relative_total_gap'),checks=checks,result_sha256=sha(dest/'verified_result.json.gz'),wall_seconds=time.perf_counter()-start,cpu_seconds=time.process_time()-cpu)
 except Exception as e:
  summary={k:entry[k] for k in ['case_id','source','query_id','kind','predicate','seed_id','support_size']};summary.update(status='unknown_error_retained',error=str(e),traceback=traceback.format_exc(),wall_seconds=time.perf_counter()-start,cpu_seconds=time.process_time()-cpu)
 save(dest/'summary.json',summary);return summary

def execute(manifest,expected):
 assert sha(manifest)==expected;m=read(manifest);assert m['case_count']==192
 for group in ['input_sha256','source_sha256']:
  for p,h in m[group].items():assert sha(p)==h,'Frozen input/source changed:'+p
 out=manifest.parent;(out/'cases').mkdir(exist_ok=False);rows=[];start=time.perf_counter()
 save(out/'execution_binding.json',{'manifest_sha256':expected,'started_utc':datetime.now(timezone.utc).isoformat(),'workers':2})
 with (out/'case_results.jsonl').open('x') as f:
  with ProcessPoolExecutor(max_workers=2,mp_context=mp.get_context('spawn')) as pool:
   fs={pool.submit(work,e,str(out)):e for e in m['cases']}
   for future in as_completed(fs):
    row=future.result();rows.append(row);f.write(json.dumps(row,allow_nan=False)+'\n');f.flush();print(json.dumps({'completed':len(rows),'expected':192,'case_id':row['case_id'],'status':row['status']}),flush=True)
 assert len(rows)==192
 report={'status':'complete_all_cases_retained','manifest_sha256':expected,'case_count':192,'status_counts':dict(Counter(r['status'] for r in rows)),'wall_seconds':time.perf_counter()-start,'summary':sorted(rows,key=lambda r:r['case_id'])};save(out/'completion.json',report);print(json.dumps({k:v for k,v in report.items() if k!='summary'},indent=2))

if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--mode',choices=['freeze','execute'],required=True);p.add_argument('--out',type=Path);p.add_argument('--manifest',type=Path);p.add_argument('--expect-manifest-sha256');a=p.parse_args()
 if a.mode=='freeze':freeze(a.out.resolve())
 else:execute(a.manifest.resolve(),a.expect_manifest_sha256)
