"""Finalize only after all23680 extension rows and independent audits complete."""
from pathlib import Path
from collections import defaultdict
import json,csv,hashlib,sqlite3
import numpy as np
ROOT=Path(__file__).resolve().parent.parent;OUT=Path(__file__).resolve().parent
OLD=Path('/root/autodl-tmp/cohortcert_strong_revision_20261102')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 manifest=ROOT/'control_study_freeze_v1/run_manifest.json';mh=sha(manifest)
 done=json.loads((manifest.parent/'results/completion.json').read_text());assert done['status']=='complete' and done['written_rows']==23680
 audit=json.loads((OUT/f'audit_completion_{mh[:12]}.json').read_text());assert audit['status']=='complete' and audit['audited_records']==23680 and not audit['issues_this_pass']
 db=sqlite3.connect(OUT/'independent_audit.sqlite');audited={k:json.loads(b) for k,b in db.execute('SELECT run_key,body FROM runs WHERE manifest_sha=?',(mh,))};assert len(audited)==23680 and all(x['audit_status']=='passed' for x in audited.values())
 rows=[];hashes={};paths=[]
 for source in ['human','model']:paths.extend(sorted((OLD/f'grid_{source}50_v1/results/shards').glob('*.csv')))
 paths.extend(sorted((manifest.parent/'results/shards').glob('*.csv')))
 for path in paths:
  hashes[str(path)]=sha(path)
  for r in csv.DictReader(path.open()):
   if path.is_relative_to(manifest.parent):
    a=audited[r['run_key']];assert a['proof_valid_correct_complete']==(r['correct_complete']=='True')
   rows.append(r)
 assert len(rows)==55360
 proto=json.loads((OUT/'analysis_protocol_before_outcomes.json').read_text());rng=np.random.default_rng(proto['bootstrap_seed']);idx=rng.integers(0,10,size=(20000,10))
 groups=defaultdict(list)
 for r in rows:groups[r['source'],r['method']].append(r)
 def select(rr,scope):return [r for r in rr if (scope=='primary' and r['kind']!='ranking') or (scope=='summary' and r['kind']=='summary') or (scope=='ranking' and r['kind']=='ranking')]
 def cell(rr):
  return {'n':len(rr),'correct':sum(r['correct_complete']=='True' for r in rr),'mean_calls_per_support':sum(float(r['calls_per_support']) for r in rr)/len(rr),'sticky_or_other_execution_errors':sum(r['status']=='execution_error' for r in rr),'source_wrong_claim_or_proof_runs':sum(r['source_error']=='True' for r in rr),'cap_charged_mean_calls_per_support':sum(float(r['conservative_cap_charge'])/int(r['support_size']) for r in rr)/len(rr)}
 summary={}
 for (source,method),rr in groups.items():
  summary.setdefault(source,{})[method]={scope:cell(select(rr,scope)) for scope in (['summary'] if method=='max_dg' else ['primary','summary','ranking']) if select(rr,scope)}
 balanced={};breakdowns={}
 for (source,method),rr in groups.items():
  primary=select(rr,'summary' if method=='max_dg' else 'primary')
  if method!='max_dg':
   blocks=[]
   for sid in range(10):
    cells=[]
    for pred in sorted({r['predicate'] for r in primary}):
     for kind in ['pairwise','equivalence','summary']:
      cells.append(cell([r for r in primary if int(r['seed_id'])==sid and r['predicate']==pred and r['kind']==kind]))
    assert len(cells)==12 and all(c['n'] for c in cells)
    blocks.append({'seed_id':sid,'balanced_correct_rate':sum(c['correct']/c['n'] for c in cells)/12,'balanced_calls':sum(c['mean_calls_per_support'] for c in cells)/12})
   balanced.setdefault(source,{})[method]={'correct_rate':sum(b['balanced_correct_rate'] for b in blocks)/10,'mean_calls_per_support':sum(b['balanced_calls'] for b in blocks)/10,'all10seedblocks':blocks}
  type_of=lambda r:r['summary_subtype'] if r['kind']=='summary' else r['kind']
  breakdowns.setdefault(source,{})[method]={'predicate_primary_or_summary':{pred:cell([r for r in primary if r['predicate']==pred]) for pred in sorted({r['predicate'] for r in primary})},'task_subtype':{typ:cell([r for r in rr if type_of(r)==typ]) for typ in sorted({type_of(r) for r in rr})}}
 contrasts=[]
 for source in ['human','model']:
  for method,scope in [('width','primary'),('neyman','primary'),('max_dg','summary')]:
   base=select(groups[source,'dual_greedy'],scope);new=select(groups[source,method],scope)
   key=lambda r:(r['query_id'],int(r['seed_id']))
   a={key(r):r for r in base};b={key(r):r for r in new};assert set(a)==set(b)
   seeds=[]
   for sid in range(10):
    keys=[k for k in sorted(a) if k[1]==sid]
    seeds.append({'seed_id':sid,'n':len(keys),'DG_minus_control_completion_pp':100*sum((a[k]['correct_complete']=='True')-(b[k]['correct_complete']=='True') for k in keys)/len(keys),'DG_mean_calls':sum(float(a[k]['calls_per_support']) for k in keys)/len(keys),'control_mean_calls':sum(float(b[k]['calls_per_support']) for k in keys)/len(keys)})
   gaps=np.array([s['DG_minus_control_completion_pp'] for s in seeds]);costA=np.array([s['DG_mean_calls'] for s in seeds]);costB=np.array([s['control_mean_calls'] for s in seeds])
   bg=gaps[idx].mean(axis=1);bc=100*(1-costA[idx].mean(axis=1)/costB[idx].mean(axis=1))
   contrasts.append({'source':source,'control':method,'scope':scope,'n_per_arm':len(a),'DG_minus_control_correct':sum(r['correct_complete']=='True' for r in base)-sum(r['correct_complete']=='True' for r in new),'DG_minus_control_completion_pp':float(gaps.mean()),'completion_pp_seed_block_95_percentile':list(map(float,np.percentile(bg,[2.5,97.5]))),'DG_normalized_call_reduction_percent':float(100*(1-costA.mean()/costB.mean())),'normalized_call_reduction_seed_block_95_percentile':list(map(float,np.percentile(bc,[2.5,97.5]))),'all10seedblocks':seeds})
 result={'status':'complete','study_manifest_sha256':mh,'total_rows_new_plus_original_main':len(rows),'new_rows_independently_audited':23680,'primary_reference_views':2,'summary':summary,'balanced_primary':balanced,'breakdowns':breakdowns,'contrasts':contrasts,'uncertainty':'20000 paired whole-seed-block95%percentile intervals conditional on fixed population/workload; no naive query independence or cross-corpus generalization','source_CSV_SHA256':hashes,'analysis_protocol_sha256':sha(OUT/'analysis_protocol_before_outcomes.json')}
 (OUT/'FINAL_CONTROL_AND_MECHANISM_SUMMARY.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'summary':summary,'contrasts':[{k:v for k,v in x.items() if k!='all10seedblocks'} for x in contrasts]},indent=2))
if __name__=='__main__':main()
