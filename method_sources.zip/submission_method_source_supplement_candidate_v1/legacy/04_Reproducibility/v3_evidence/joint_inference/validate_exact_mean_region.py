from pathlib import Path
from fractions import Fraction as F
from functools import lru_cache
from itertools import product
from math import ceil
import json,hashlib
from exact_mean_region import Evidence,dual_lower,exact_projection
alpha=F(1,20);etas=[F(0)]+[F(2**e) if e>=0 else F(1,2**(-e)) for e in range(-8,9)]
states=[Evidence(12,n,s,3,5) for n in [2,4,6,8,10] for s in range(n+1)]
count=0;strict=0;dual_strict=0;witness=None
for c0,c1 in product(states,repeat=2):
 exact=exact_projection([c0,c1],[1,-1],alpha);assert exact is not None
 lower=dual_lower([c0,c1],[1,-1],alpha,etas);upper=dual_lower([c0,c1],[-1,1],alpha,etas)
 boxlo=min(k for k,m in lower['options'][0])-max(k for k,m in lower['options'][1]);boxhi=max(k for k,m in lower['options'][0])-min(k for k,m in lower['options'][1])
 assert boxlo<=exact[0]<=exact[1]<=boxhi
 assert lower['lower']<=exact[0] and -upper['lower']>=exact[1]
 assert lower['lower']>=boxlo and -upper['lower']<=boxhi
 if exact[0]>boxlo or exact[1]<boxhi:strict+=1
 if ceil(lower['lower'])>boxlo or -ceil(upper['lower'])<boxhi:
  dual_strict+=1
  if witness is None:witness={'cells':[[c.N,c.n,c.s,c.a,c.b] for c in [c0,c1]],'box':[str(boxlo),str(boxhi)],'mean_exact':[str(exact[0]),str(exact[1])],'checked_dual_integer':[ceil(lower['lower']),-ceil(upper['lower'])],'lower_multiplier':str(lower['eta']),'upper_multiplier':str(upper['eta'])}
 count+=1
# Exact adaptive finite audit: all49 binary total-count vectors, N=6 per cell.
# Recursion sums actual hypergeometric path probabilities, no simulation or
# assumption that adaptively observed counts are independent of stopping.
riska=F(2,5);probabilities={};nodes=0
for K0,K1 in product(range(7),repeat=2):
 @lru_cache(None)
 def event(n0,s0,n1,s1):
  global nodes
  nodes+=1
  ev=(Evidence(6,n0,s0).ratio(K0)+Evidence(6,n1,s1).ratio(K1))/2
  if ev>=1/riska:return F(1)
  if n0==n1==6:return F(0)
  if n0==0:h=0
  elif n1==0:h=1 if s0 else 0
  else:h=0 if (s0+s1)%2==0 else 1
  if (n0 if h==0 else n1)==6:h=1-h
  ns=[n0,n1];ss=[s0,s1];Ks=[K0,K1];p=F(Ks[h]-ss[h],6-ns[h]);v=F(0)
  for y,pr in [(0,1-p),(1,p)]:
   if not pr:continue
   nn=ns.copy();st=ss.copy();nn[h]+=1;st[h]+=y
   v+=pr*event(nn[0],st[0],nn[1],st[1])
  return v
 pr=event(0,0,0,0);assert pr<=riska;probabilities[f'{K0},{K1}']=str(pr)
report={'status':'passed','exact_region_states':count,'strict_mean_region_projection_cases':strict,'finite_multiplier_verified_tighter_integer_bounds_cases':dual_strict,'first_tighter_witness':witness,'adaptive_finite_Ville_audit':{'N_per_cell':6,'true_count_vectors':49,'visited_states':nodes,'alpha':str(riska),'maximum_exact_crossing_probability':str(max(F(v) for v in probabilities.values())),'all_probabilities':probabilities},'known_antecedent':'PEAKICML2024 averaging and Spertus2026 stratified testing; not a new e-merging theorem','limits':'Small exact enumeration; no universal floating-point result, scalableimplementation, realdatasetbenefit, or newformalpolicyexperiment claimed','corpus_rows_opened':0,'model_forwards':0,'source_sha256':hashlib.sha256((Path(__file__).parent/'exact_mean_region.py').read_bytes()).hexdigest()}
(Path(__file__).parent/'VALIDATION.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='adaptive_finite_Ville_audit'},indent=2))
