from exact_mean_region import Evidence
from fractions import Fraction as F
from pathlib import Path
import json
# Same two local prefixes [1,0], same finalK vector(1,1), different interleaving.
N=54;K=[1,1];local=[[1,0],[1,0]];alpha=F(1,20)
def follow(order):
 n=[0,0];s=[0,0];evalues=[]
 for h in order:
  y=local[h][n[h]];n[h]+=1;s[h]+=y
  e=(Evidence(N,n[0],s[0]).ratio(K[0])+Evidence(N,n[1],s[1]).ratio(K[1]))/2
  evalues.append(e)
 return evalues
interleaved=follow([0,1,0,1]);serial=follow([0,0,1,1])
assert interleaved[-1]==serial[-1]==9
assert max(interleaved)==27 and max(serial)==18
assert max(interleaved)>=1/alpha>max(serial)
# All compatible integer candidates, not just the excluded witness. This
# demonstrates different linear projections even for a true source retained
# by BOTH histories.
def e_history(order,ks):
 n=[0,0];s=[0,0];values=[]
 for h in order:
  y=local[h][n[h]];n[h]+=1;s[h]+=y
  values.append((Evidence(N,n[0],s[0]).ratio(ks[0])+Evidence(N,n[1],s[1]).ratio(ks[1]))/2)
 return values
projection={}
for label,order in [('interleaved',[0,1,0,1]),('serial',[0,0,1,1])]:
 feasible=[]
 for k0 in range(1,54):
  for k1 in range(1,54):
   if max(e_history(order,[k0,k1]))<1/alpha:feasible.append(k0+k1)
 projection[label]=[min(feasible),max(feasible)]
assert projection['interleaved'][0]==4 and projection['serial'][0]==2
source=[4,5]
assert max(e_history([0,1,0,1],source))<1/alpha and max(e_history([0,0,1,1],source))<1/alpha
report={'status':'passed','alpha':str(alpha),'N':[54,54],'candidate_K':[1,1],'local_label_prefixes':local,'interleaved':{'order':[0,1,0,1],'mean_evalues':list(map(str,interleaved)),'retained_by_global_running_intersection':False},'serial':{'order':[0,0,1,1],'mean_evalues':list(map(str,serial)),'retained_by_global_running_intersection':True},'same_final_prefix_vector':[2,2],'same_final_evalue':9,'linear_sum_projection':projection,'example_true_source_K_retained_in_both_histories':source,'proof_of_sum_K_gt_3_at_same_terminal_prefix':{'interleaved':True,'serial':False},'scope':'Mathematical current-region/running-history order example, not an observed dataset failure or a new inference theorem'}
(Path(__file__).parent/'ORDER_DEPENDENCE_COUNTEREXAMPLE.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
