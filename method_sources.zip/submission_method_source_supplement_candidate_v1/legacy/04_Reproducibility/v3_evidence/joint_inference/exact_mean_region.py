"""Small exact finite-population mean-e-region projection prototype.

Known PEAK-style averaging, not a new inference theorem. Enumerated integer
inner minimization is intentional here: this prototype is not a scalable query
executor and never opens corpus/model labels.
"""
from dataclasses import dataclass
from fractions import Fraction as F
from math import comb,ceil
from itertools import product
from functools import cached_property

@dataclass(frozen=True)
class Evidence:
 N:int;n:int;s:int;a:int=1;b:int=1;lam:F=F(1,2)
 def __post_init__(self):
  if not all(type(x) is int for x in (self.N,self.n,self.s,self.a,self.b)):raise ValueError('Integer parameters required')
  if not 0<=self.s<=self.n<=self.N or min(self.a,self.b)<1 or not 0<=self.lam<=1:raise ValueError('Invalid evidence')
 @cached_property
 def q(self):
  u=F(1,(self.n+1)*comb(self.n,self.s))
  v=F(comb(self.s+self.a-1,self.a-1)*comb(self.n-self.s+self.b-1,self.b-1),comb(self.n+self.a+self.b-1,self.a+self.b-1)*comb(self.n,self.s))
  return (1-self.lam)*u+self.lam*v
 def ratio(self,K):
  if not self.s<=K<=self.N-self.n+self.s:raise ValueError('Impossible candidate path')
  return self.q*F(comb(self.N,K),comb(self.N-self.n,K-self.s))
 def candidates(self,C):return tuple((K,self.ratio(K)) for K in range(self.s,self.N-self.n+self.s+1) if self.ratio(K)<C)

def dual_lower(cells,coefficients,alpha,multipliers):
 if not cells or len(cells)!=len(coefficients) or not 0<alpha<1:raise ValueError('Nonempty matched cells and valid risk required')
 C=F(len(cells),1)/alpha;options=[c.candidates(C) for c in cells]
 if any(not x for x in options):raise ValueError('No box candidate')
 best=None;best_eta=None
 for eta in multipliers:
  eta=F(eta)
  if eta<0:raise ValueError('Negative multiplier')
  value=-eta*C+sum(min(F(a)*K+eta*M for K,M in opts) for a,opts in zip(coefficients,options))
  if best is None or value>best:best,best_eta=value,eta
 if best is None:raise ValueError('At least one multiplier required')
 return {'lower':best,'eta':best_eta,'options':options,'C':C}

def exact_projection(cells,coefficients,alpha):
 C=F(len(cells),1)/alpha;options=[c.candidates(C) for c in cells];values=[]
 for point in product(*options):
  if sum(x[1] for x in point)<C:values.append(sum(F(a)*x[0] for a,x in zip(coefficients,point)))
 if not values:return None
 return min(values),max(values),len(values)
