from pathlib import Path
import urllib.request,hashlib,json,time
ROOT=Path(__file__).resolve().parent;raw=ROOT/'raw';raw.mkdir(exist_ok=True)
plan=json.loads((ROOT/'DESIGN_BEFORE_TARGET_INTERPRETATION.json').read_text());records=[]
for url in plan['provider_urls']:
 path=raw/url.rsplit('/',1)[1];part=path.with_suffix(path.suffix+'.part')
 if path.exists():raise RuntimeError('No implicit overwrite or unverified reuse: '+str(path))
 begin=time.monotonic();h=hashlib.sha256();size=0
 try:
  req=urllib.request.Request(url,headers={'User-Agent':'CohortCert-research-source-acquisition/3.0'})
  with urllib.request.urlopen(req,timeout=120) as response,part.open('xb') as f:
   for b in iter(lambda:response.read(1024*1024),b''):
    f.write(b);h.update(b);size+=len(b)
  part.rename(path)
  records.append({'url':url,'file':path.name,'bytes':size,'sha256':h.hexdigest(),'wall_seconds':time.monotonic()-begin,'target_columns_interpreted':False})
  (ROOT/'source_download_progress.json').write_text(json.dumps({'status':'running','completed':records},indent=2)+'\n');print(path.name+' complete '+str(size),flush=True)
 except Exception as e:
  (ROOT/'source_download_failure.json').write_text(json.dumps({'status':'failed_preserved','url':url,'bytes_retained':size,'error':repr(e),'completed':records},indent=2)+'\n');raise
(ROOT/'source_download_completion.json').write_text(json.dumps({'status':'complete','sources':records,'total_bytes':sum(r['bytes'] for r in records),'target_values_interpreted':False},indent=2)+'\n')
