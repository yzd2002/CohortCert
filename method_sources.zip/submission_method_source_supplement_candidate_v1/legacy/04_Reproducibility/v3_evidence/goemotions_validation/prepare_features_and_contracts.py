"""Metadata/text-only GoEmotions preparation; no emotion target interpretation."""
from pathlib import Path
from fractions import Fraction as F
from collections import Counter
import copy,json,hashlib,itertools,time
import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import TruncatedSVD
from sklearn.preprocessing import normalize
from threadpoolctl import threadpool_limits
ROOT=Path(__file__).resolve().parent;OLD=Path('/root/autodl-tmp/cohortcert_strong_revision_20261102')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 meta=ROOT/'metadata_v1';receipt=json.loads((meta/'METADATA_COMPLETION.json').read_text());assert receipt['status']=='metadata_only_complete' and not receipt['target_columns_numerically_interpreted']
 out=ROOT/'prepared_v1';out.mkdir(exist_ok=False)
 definitions=json.loads((meta/'cohort_definitions.json').read_text());fields=definitions['fields'];sizes=definitions['counts']
 civilfields=['mentions_male','mentions_female','mentions_LGBTQ','mentions_christian','mentions_muslim','mentions_other_religions','mentions_black','mentions_white']
 mapping=dict(zip(civilfields,fields));preds=['anger','joy','sadness','fear']
 templates=[json.loads(x) for x in (OLD/'natural_overlap/queries_before_annotation_access.jsonl').read_text().splitlines() if json.loads(x)['predicate_id']=='civilcomments_toxicity_v1'];assert len(templates)==132
 labels={f'cohort_subreddit_{i+1}':'Comment in subreddit '+v for i,v in enumerate(definitions['top_four_subreddits'])}
 labels.update(cohort_long_text='Comment character count at least '+definitions['length_cutoff_decimal'],cohort_late_comment='Comment timestamp at least '+definitions['created_utc_cutoff_decimal'],cohort_question_mark='Comment contains ASCII question mark',cohort_exclamation_mark='Comment contains ASCII exclamation mark')
 queries=[]
 for pi,pred in enumerate(preds):
  for qi,t in enumerate(templates):
   q=copy.deepcopy(t);q['query_id']=f'goemotions-{pred}-{pi*132+qi:04d}';q['dataset']='goemotions';q['predicate_id']=f'goemotions_{pred}_crowd_majority_v1';q['contract']['predicate_id']=q['predicate_id'];q['contract']['snapshot_id']='goemotions_selected30k_v1';q['contract']['population_scope']='One selected comment ID with at least two clear distinct existing annotators; fixed source and no emotion agreement filter.'
   for g in q['contract']['cohorts']:
    old=g['filter_ast']['eq'][0];field=mapping[old];g['filter_ast']['eq'][0]=field;g['label']=labels[field]
   queries.append(q)
 qpath=out/'queries_before_annotation_access.jsonl';qpath.write_text(''.join(json.dumps(q,sort_keys=True,separators=(',',':'))+'\n' for q in queries))
 rows=pq.read_table(meta/'metadata_only_snapshot.parquet').to_pylist();patterns=Counter(sum(int(r[f])<<i for i,f in enumerate(fields)) for r in rows);cache={};supports=[]
 for q in queries:
  cohort={g['id']:g['filter_ast']['eq'][0] for g in q['contract']['cohorts']};pairs=[]
  for d in q['contract']['decisions']:
   if d['type'] in ['compare','direction','equivalence']:new=[(d['left'],d['right'])]
   else:new=[(a,b) for a in d['candidates'] for b in d['candidates'] if a!=b]
   for pair in new:
    if pair not in pairs:pairs.append(pair)
  key=tuple((cohort[a],cohort[b]) for a,b in pairs)
  if key not in cache:
   signatures=Counter()
   for bits,count in patterns.items():
    coeff=tuple(F((bits>>fields.index(a))&1,sizes[a])-F((bits>>fields.index(b))&1,sizes[b]) for a,b in key)
    if any(coeff):signatures[coeff]+=count
   cache[key]=(sum(signatures.values()),len(signatures))
  support,H=cache[key];assert support>0 and H<=256
  subtype=('dominance_3' if all(d['type']=='compare' for d in q['contract']['decisions']) else 'mixed_3') if q['kind']=='summary' else None
  supports.append({'query_id':q['query_id'],'kind':q['kind'],'predicate_id':q['predicate_id'],'predicate':q['predicate_id'].split('_')[1],'summary_subtype':subtype,'support_size':support,'coefficient_cell_count_b1':H})
 (out/'metadata_coefficient_cells.jsonl').write_text(''.join(json.dumps(x,sort_keys=True)+'\n' for x in supports))
 feature_dir=out/'data/embeddings';feature_dir.mkdir(parents=True)
 text=pq.read_table(meta/'text_metadata_snapshot.parquet',columns=['record_id','text']).to_pylist();start=time.perf_counter()
 with threadpool_limits(limits=1):
  sparse=TfidfVectorizer(max_features=10000,ngram_range=(1,2),min_df=2,sublinear_tf=True).fit_transform([r['text'] for r in text]);vectors=TruncatedSVD(n_components=128,n_iter=5,random_state=431).fit_transform(sparse);vectors=normalize(vectors).astype(np.float32)
 np.save(feature_dir/'goemotions_emb.npy',vectors)
 pq.write_table(pa.Table.from_pylist([{'record_id':r['record_id'],'emb_row':i} for i,r in enumerate(text)]),feature_dir/'goemotions_index.parquet')
 seeds=[]
 for sid in range(10):
  seeds.append({'seed_id':sid,**{k:str(int.from_bytes(hashlib.sha256(f'cohortcert-goemotions-v3-20261102|{sid}|{k}'.encode()).digest(),'big')) for k in ['pilot_seed','formal_seed','planning_seed','exploration_seed']}})
 assert len({s[k] for s in seeds for k in ['pilot_seed','formal_seed','planning_seed','exploration_seed']})==40
 protocol={'study':'GoEmotionsv3metadataonlyprepared','population_size':30000,'reference_predicates':preds,'target_values_interpreted':False,'seed_records':seeds,'alpha':.05,'budget_shares':[50.0],'query_count':528,'query_counts':dict(Counter(q['kind'] for q in queries)),'queries_sha256':sha(qpath),'metadata_snapshot':str(meta/'metadata_only_snapshot.parquet'),'text_snapshot':str(meta/'text_metadata_snapshot.parquet'),'input_hashes':{str(p.relative_to(ROOT)):sha(p) for p in [meta/'metadata_only_snapshot.parquet',meta/'text_metadata_snapshot.parquet',meta/'selected_annotation_ordinals.jsonl',feature_dir/'goemotions_emb.npy',feature_dir/'goemotions_index.parquet']},'feature_build_seconds':time.perf_counter()-start,'feature_shape':list(vectors.shape),'metadata_only_support_range':[min(x['support_size'] for x in supports),max(x['support_size'] for x in supports)],'metadata_only_H1_range':[min(x['coefficient_cell_count_b1'] for x in supports),max(x['coefficient_cell_count_b1'] for x in supports)],'template_transfer':'Exactly the132abstractcohort-index templates from the original pre-annotation CivilCommentsdesign, transferred to new predefinedcohortaxes and4basicemotions. No Go outcome-dependent queryselection. This clarifies the initial design phrase reusedtemplate/metadatahash selection; index templates remain fixed acrosscorpora.','next_gate':'No emotion-label conversion until the new generalized wrapper/source and independent reference adaptations are mechanically validated and hash-frozen. Preparation alone is not execution.'}
 (out/'PREPARATION_COMPLETION.json').write_text(json.dumps(protocol,indent=2)+'\n');print(json.dumps({k:v for k,v in protocol.items() if k not in ['seed_records','input_hashes']},indent=2))
if __name__=='__main__':main()
