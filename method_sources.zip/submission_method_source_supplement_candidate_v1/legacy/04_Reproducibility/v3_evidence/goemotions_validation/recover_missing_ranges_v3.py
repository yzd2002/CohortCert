"""Verified terminal transport-failure recovery; no target parsing."""
from pathlib import Path
import urllib.request,hashlib,json,base64,time,threading,concurrent.futures
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'raw_recovery_v3';OUT.mkdir(exist_ok=False)
heads=json.loads((ROOT/'HEAD_AND_MD5_VERIFICATION.json').read_text());plan=json.loads((ROOT/'DESIGN_BEFORE_TARGET_INTERPRETATION.json').read_text())
(OUT/'RECOVERY_PROVENANCE.json').write_text(json.dumps({'v1_complete_receipt_invalidated':True,'basis':'All3 terminal local files shorter than authoritative HEAD ContentLength and fail GCS publishedMD5; old files/receipts preserved','label_or_query_use_before_detection':False,'next':'New explicit verified byte ranges pinned byETag inraw_recovery_v2'},indent=2)+'\n')
chunks=[]
for url,head in zip(plan['provider_urls'],heads):
 size=int(head['headers']['Content-Length']);etag=head['headers']['ETag'];name=head['file']
 for start in range(0,size,1024*1024):chunks.append({'url':url,'name':name,'start':start,'end':min(size,start+1024*1024)-1,'size':size,'etag':etag})
lock=threading.Lock();done=[];attempts=[]
def atomic(p,o):
 t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(o,indent=2)+'\n');t.replace(p)
def fetch(c):
 oldpart=ROOT/'raw_recovery_v2/parts'/f'{c["name"]}__{c["start"]:09d}_{c["end"]:09d}.bin'
 part=OUT/'parts'/f'{c["name"]}__{c["start"]:09d}_{c["end"]:09d}.bin';part.parent.mkdir(exist_ok=True)
 if oldpart.is_file() and oldpart.stat().st_size==c['end']-c['start']+1:
  data=oldpart.read_bytes()
  with part.open('xb') as f:f.write(data)
  receipt={**c,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'attempt':0,'part':part.name,'reused_validated_v2_range':True}
  with lock:
   done.append(receipt);atomic(OUT/'progress.json',{'status':'running','completed_chunks':len(done),'expected_chunks':len(chunks),'target_values_interpreted':False})
  return receipt
 for attempt in range(1,9):
  data=b''
  try:
   req=urllib.request.Request(c['url'],headers={'Range':f'bytes={c["start"]}-{c["end"]}','If-Match':c['etag'],'Accept-Encoding':'identity','User-Agent':'CohortCert-goemotions-byte-recovery/2.0'})
   opener=urllib.request.build_opener(urllib.request.ProxyHandler({})) if attempt%2==0 else urllib.request.build_opener()
   with opener.open(req,timeout=20) as f:
    status=f.status;cr=f.headers.get('Content-Range');tag=f.headers.get('ETag');enc=f.headers.get('Content-Encoding');data=f.read()
   if status!=206 or cr!=f'bytes {c["start"]}-{c["end"]}/{c["size"]}' or tag!=c['etag'] or enc not in [None,'identity'] or len(data)!=c['end']-c['start']+1:raise RuntimeError('Range/status/ETag/encoding/length mismatch')
   with part.open('xb') as f:f.write(data)
   receipt={**c,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'attempt':attempt,'part':part.name}
   with lock:
    done.append(receipt);atomic(OUT/'progress.json',{'status':'running','completed_chunks':len(done),'expected_chunks':len(chunks),'target_values_interpreted':False});print('verifiedchunks '+str(len(done))+'/'+str(len(chunks)),flush=True)
   return receipt
  except Exception as e:
   if data:
    failure=OUT/'parts'/f'{part.name}.attempt{attempt}.partial';failure.write_bytes(data)
   with lock:attempts.append({'name':c['name'],'start':c['start'],'attempt':attempt,'retained_bytes':len(data),'error':repr(e)});atomic(OUT/'attempts.json',attempts)
   if attempt==8:raise
   time.sleep(min(3,attempt))
try:
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:receipts=list(pool.map(fetch,chunks))
 files=[]
 for head in heads:
  p=OUT/head['file'];h=hashlib.sha256();md5=hashlib.md5();size=0
  with p.open('xb') as f:
   for c in sorted((r for r in receipts if r['name']==head['file']),key=lambda r:r['start']):
    b=(OUT/'parts'/c['part']).read_bytes();assert hashlib.sha256(b).hexdigest()==c['sha256'];f.write(b);h.update(b);md5.update(b);size+=len(b)
  expected=head['headers']['x-goog-hash'].split('md5=')[1].split(',')[0];actual=base64.b64encode(md5.digest()).decode();assert actual==expected and size==int(head['headers']['Content-Length'])
  files.append({'file':p.name,'bytes':size,'sha256':h.hexdigest(),'md5_base64':actual,'expected_published_GCS_md5':expected,'ETag':head['headers']['ETag']})
 atomic(OUT/'completion.json',{'status':'complete_verified','files':files,'chunk_receipts':receipts,'target_values_interpreted':False,'original_failed_transports_preserved':True});print('All3fullCSVs matchpublishedGCSMD5',flush=True)
except Exception as e:
 atomic(OUT/'failure.json',{'status':'failed_preserved','error':repr(e),'completed_chunks':len(done),'expected_chunks':len(chunks),'target_values_interpreted':False});raise
