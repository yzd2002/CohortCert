"""Project/deduplicate metadata without interpreting any emotion target field."""
from pathlib import Path
from collections import Counter
import csv,json,hashlib,statistics
from decimal import Decimal
import pyarrow as pa
import pyarrow.parquet as pq
ROOT=Path(__file__).resolve().parent

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def main():
 plan=json.loads((ROOT/'DESIGN_BEFORE_TARGET_INTERPRETATION.json').read_text());receipt=json.loads((ROOT/'raw_recovery_v3/completion.json').read_text());assert receipt['status']=='complete_verified'
 out=ROOT/'metadata_v1';out.mkdir(exist_ok=False)
 byid={};seen=set();duplicates=0;rows=0;unclear=0
 for source in receipt['files']:
  path=ROOT/'raw_recovery_v3'/source['file'];assert sha(path)==source['sha256']
  with path.open(newline='',encoding='utf-8') as f:
   reader=csv.DictReader(f)
   required=['text','id','subreddit','created_utc','rater_id','example_very_unclear'];assert all(k in reader.fieldnames for k in required)
   assert all(p in reader.fieldnames for p in plan['reference_predicates_fixed_now'])
   for ordinal,row in enumerate(reader,2):
    rows+=1;cid=row['id'];rater=row['rater_id'];key=(cid,rater)
    if key in seen:duplicates+=1;continue
    seen.add(key)
    created=Decimal(row['created_utc']);assert created.is_finite()
    meta=(row['text'],row['subreddit'],created)
    record=byid.setdefault(cid,{'metadata':meta,'clear_annotation_ordinals':[],'all_distinct_raters':0})
    if record['metadata']!=meta:raise RuntimeError('Metadata mismatch acrossannotations forID '+cid)
    record['all_distinct_raters']+=1
    flag=row['example_very_unclear'].strip().lower()
    if flag in ['true','1']:unclear+=1;continue
    if flag not in ['false','0']:raise RuntimeError('Unknown annotation availability flag')
    record['clear_annotation_ordinals'].append((source['file'],ordinal))
 # Annotation count/availability only; no emotion values were read numerically.
 eligible=[cid for cid,r in byid.items() if len(r['clear_annotation_ordinals'])>=2]
 if len(eligible)<30000:
  (out/'INSUFFICIENT_METADATA_POPULATION.json').write_text(json.dumps({'eligible':len(eligible),'unique_comments':len(byid),'target_values_interpreted':False},indent=2)+'\n');raise RuntimeError('Prespecified30000sample unavailable; no target-dependent substitution')
 salt='cohortcert-goemotions-v3-source-selection-20261102'
 selected=sorted(eligible,key=lambda cid:hashlib.sha256((salt+'|'+cid).encode()).digest())[:30000]
 selected.sort()
 subreddit_counts=Counter(byid[cid]['metadata'][1] for cid in selected)
 top=sorted(subreddit_counts,key=lambda v:(-subreddit_counts[v],v))[:4]
 lengths=[len(byid[cid]['metadata'][0]) for cid in selected]
 times=[byid[cid]['metadata'][2] for cid in selected]
 # Median of even number uses exactDecimal arithmetic, avoiding float drift.
 ll=sorted(lengths);tt=sorted(times);len_cut=Decimal(ll[14999]+ll[15000])/2;time_cut=(tt[14999]+tt[15000])/2
 meta_rows=[];text_rows=[];ordinals=[]
 for cid in selected:
  text,subreddit,created=byid[cid]['metadata'];rid='goemotions-comment-'+cid
  flags={f'cohort_subreddit_{i+1}':subreddit==v for i,v in enumerate(top)}
  flags.update(cohort_long_text=Decimal(len(text))>=len_cut,cohort_late_comment=created>=time_cut,cohort_question_mark='?' in text,cohort_exclamation_mark='!' in text)
  base={'record_id':rid,'source_comment_id':cid,'subreddit':subreddit,'created_utc_decimal':str(created),'text_character_count':len(text),**flags}
  meta_rows.append(base);text_rows.append({**base,'text':text});ordinals.append({'record_id':rid,'source_comment_id':cid,'clear_annotation_ordinals':byid[cid]['clear_annotation_ordinals']})
 fields=list(flags);sizes={k:sum(r[k] for r in meta_rows) for k in fields};assert all(sizes.values())
 intersections={a+'|'+b:sum(r[a] and r[b] for r in meta_rows) for i,a in enumerate(fields) for b in fields[i+1:]}
 pq.write_table(pa.Table.from_pylist(meta_rows),out/'metadata_only_snapshot.parquet')
 pq.write_table(pa.Table.from_pylist(text_rows),out/'text_metadata_snapshot.parquet')
 (out/'selected_annotation_ordinals.jsonl').write_text(''.join(json.dumps(r,sort_keys=True)+'\n' for r in ordinals))
 (out/'cohort_definitions.json').write_text(json.dumps({'fields':fields,'top_four_subreddits':top,'length_cutoff_decimal':str(len_cut),'created_utc_cutoff_decimal':str(time_cut),'counts':sizes,'pair_intersections':intersections,'multiple_membership_rows':sum(sum(r[k] for k in fields)>1 for r in meta_rows)},indent=2)+'\n')
 status={'status':'metadata_only_complete','source_annotation_rows':rows,'unique_comments':len(byid),'eligible_comments':len(eligible),'selected_comments':30000,'duplicate_annotation_pairs_first_kept':duplicates,'unclear_annotations_excluded_from_reference_availability':unclear,'target_columns_numerically_interpreted':False,'emotion_reference_labels_constructed':False,'cohort_counts':sizes,'source_receipt_sha256':sha(ROOT/'raw_recovery_v3/completion.json'),'design_sha256':sha(ROOT/'DESIGN_BEFORE_TARGET_INTERPRETATION.json'),'output_sha256':{p.name:sha(p) for p in out.iterdir() if p.is_file()}}
 (out/'METADATA_COMPLETION.json').write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(status,indent=2))
if __name__=='__main__':main()
