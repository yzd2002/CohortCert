"""Finalize fixed GoEmotions endpoints only after full execution and audit."""
from pathlib import Path
from collections import defaultdict
import hashlib,json,sqlite3
import numpy as np
OUT=Path(__file__).resolve().parent;ROOT=OUT.parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 mh=sha(ROOT/'grid_v1/run_manifest.json');done=json.loads((ROOT/'grid_v1/results/completion.json').read_text());assert done['status']=='complete' and done['written_rows']==17120
 audit=json.loads((OUT/f'audit_completion_{mh[:12]}.json').read_text());assert audit['status']=='complete' and audit['audited_records']==17120 and not audit['issues_this_pass']
 db=sqlite3.connect(OUT/'independent_audit.sqlite');rows=[json.loads(b) for b, in db.execute('SELECT body FROM runs WHERE manifest_sha=?',(mh,))];db.close();assert len(rows)==17120 and all(r['audit_status']=='passed' for r in rows)
 groups=defaultdict(list)
 for r in rows:groups[r['method']].append(r)
 def select(rr,scope):return [r for r in rr if (scope=='primary' and r['kind']!='ranking') or (scope=='summary' and r['kind']=='summary') or (scope=='ranking' and r['kind']=='ranking')]
 def cell(rr):
  return {'n':len(rr),'correct':sum(r['proof_valid_correct_complete'] for r in rr),'mean_calls_per_support':sum(r['calls_per_support'] for r in rr)/len(rr),'sticky_or_other_execution_errors':sum(r['status']=='execution_error' for r in rr),'source_wrong_claim_or_proof_runs':sum(r['source_error'] for r in rr),'cap_charged_mean_calls_per_support':sum(r['conservative_cap_charge']/r['support'] for r in rr)/len(rr)}
 summary={method:{scope:cell(select(rr,scope)) for scope in (['summary'] if method=='max_dg' else ['primary','summary','ranking'])} for method,rr in groups.items()}
 key=lambda r:(r['query_id'],r['seed_id']);paired=defaultdict(list)
 for r in rows:paired[key(r)].append(r)
 assert len(paired)==5280
 for rr in paired.values():
  assert len(rr)==(4 if rr[0]['kind']=='summary' else 3)
  assert all(r['frozen']==rr[0]['frozen'] for r in rr)
 proto=json.loads((ROOT/'ANALYSIS_PLAN_BEFORE_TARGET_CONVERSION.json').read_text());rng=np.random.default_rng(2026110207);idx=rng.integers(0,10,size=(20000,10))
 contrasts=[]
 for method,scope in [('width','primary'),('neyman','primary'),('max_dg','summary')]:
  a={key(r):r for r in select(groups['dual_greedy'],scope)};b={key(r):r for r in select(groups[method],scope)};assert set(a)==set(b)
  seed=[]
  for sid in range(10):
   keys=[k for k in sorted(a) if k[1]==sid];seed.append({'seed_id':sid,'n':len(keys),'DG_minus_control_completion_pp':100*sum(a[k]['proof_valid_correct_complete']-b[k]['proof_valid_correct_complete'] for k in keys)/len(keys),'DG_mean_calls':sum(a[k]['calls_per_support'] for k in keys)/len(keys),'control_mean_calls':sum(b[k]['calls_per_support'] for k in keys)/len(keys)})
  gaps=np.array([s['DG_minus_control_completion_pp'] for s in seed]);costA=np.array([s['DG_mean_calls'] for s in seed]);costB=np.array([s['control_mean_calls'] for s in seed]);bg=gaps[idx].mean(axis=1);bc=100*(1-costA[idx].mean(axis=1)/costB[idx].mean(axis=1))
  contrasts.append({'source':'GoEmotions_existing_crowd_majority','control':method,'scope':scope,'n_per_arm':len(a),'DG_minus_control_correct':sum(r['proof_valid_correct_complete'] for r in a.values())-sum(r['proof_valid_correct_complete'] for r in b.values()),'DG_minus_control_completion_pp':float(gaps.mean()),'completion_pp_seed_block_95_percentile':list(map(float,np.percentile(bg,[2.5,97.5]))),'DG_normalized_call_reduction_percent':float(100*(1-costA.mean()/costB.mean())),'normalized_call_reduction_seed_block_95_percentile':list(map(float,np.percentile(bc,[2.5,97.5]))),'all10seedblocks':seed})
 balanced={};breakdowns={}
 for method,rr in groups.items():
  pr=select(rr,'summary' if method=='max_dg' else 'primary')
  breakdowns[method]={'predicate_primary_or_summary':{p:cell([r for r in pr if r['predicate']==p]) for p in sorted({r['predicate'] for r in pr})},'task_subtype':{t:cell([r for r in rr if (r['summary_subtype'] if r['kind']=='summary' else r['kind'])==t]) for t in ['pairwise','equivalence','dominance_3','mixed_3','ranking'] if any((r['summary_subtype'] if r['kind']=='summary' else r['kind'])==t for r in rr)}}
  if method!='max_dg':
   cells=[cell([r for r in pr if r['predicate']==p and r['kind']==k]) for p in ['anger','joy','sadness','fear'] for k in ['pairwise','equivalence','summary']];balanced[method]={'correct_rate':sum(c['correct']/c['n'] for c in cells)/12,'mean_calls_per_support':sum(c['mean_calls_per_support'] for c in cells)/12}
 a={key(r):r for r in groups['dual_greedy'] if r['kind'] in ['pairwise','equivalence']};b={key(r):r for r in groups['width'] if r['kind'] in ['pairwise','equivalence']};fields=['calls','status','reason','proof_valid_correct_complete','vector_only_correct_complete','wrong_true_claims','wrong_false_claims','source_invalid_proofs','source_error']
 scalar={'pairs':len(a),'observable_mismatches':sum(any(a[k][f]!=b[k][f] for f in fields) for k in a),'fields':fields,'scope':'Observable field equality only, not raw acquisition order identity'}
 result={'status':'complete_and_all17120_audited','manifest_sha256':mh,'rows':17120,'query_seed_pairs':5280,'all_six_paired_fingerprints_equal':True,'summary':summary,'contrasts':contrasts,'balanced_primary':balanced,'breakdowns':breakdowns,'scalar_observable_agreement':scalar,'analysis_plan_sha256':sha(ROOT/'ANALYSIS_PLAN_BEFORE_TARGET_CONVERSION.json'),'audit_completion_sha256':sha(OUT/f'audit_completion_{mh[:12]}.json'),'population_scope':'Independent existing GoEmotions crowd-source validation on internally fixed 30k population and528contracts. Not new human/model labels, general-population inference or a fresh agent review.'}
 (OUT/'FINAL_GOEMOTIONS_SUMMARY.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'summary':summary,'contrasts':[{k:v for k,v in d.items() if k!='all10seedblocks'} for d in contrasts],'scalar':scalar},indent=2))
if __name__=='__main__':main()
