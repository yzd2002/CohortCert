"""Aggregate fixed GoEmotions clear-rater references AFTER code/metadata freeze."""
from pathlib import Path
from collections import Counter
import argparse,csv,json,hashlib,sys
from run_goemotions_grid import sha,write,verify_gate

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
 code=Path(__file__).resolve().parent;gate=verify_gate(code);root=a.root.resolve();out=a.out.resolve();out.mkdir(parents=True,exist_ok=False)
 plan=json.loads((root/'DESIGN_BEFORE_TARGET_INTERPRETATION.json').read_text());preds=plan['reference_predicates_fixed_now']
 selection=[json.loads(x) for x in (root/'metadata_v1/selected_annotation_ordinals.jsonl').read_text().splitlines()];assert len(selection)==30000
 wanted={};denom={};counts={}
 for row in selection:
  rid=row['record_id'];assert rid not in denom;denom[rid]=len(row['clear_annotation_ordinals']);assert denom[rid]>=2;counts[rid]=[0]*len(preds)
  for filename,n in row['clear_annotation_ordinals']:
   assert (filename,n) not in wanted;wanted[filename,n]=rid
 receipt=json.loads((root/'raw_recovery_v3/completion.json').read_text());assert receipt['status']=='complete_verified';seen=Counter();rows=0
 for source in receipt['files']:
  path=root/'raw_recovery_v3'/source['file'];assert sha(path)==source['sha256']
  with path.open(newline='',encoding='utf-8') as f:
   for ordinal,row in enumerate(csv.DictReader(f),2):
    rows+=1;rid=wanted.get((source['file'],ordinal))
    if rid is None:continue
    assert row['example_very_unclear'].strip().lower() in ['false','0'] and rid=='goemotions-comment-'+row['id']
    for i,pred in enumerate(preds):
     value=int(row[pred]);assert value in [0,1];counts[rid][i]+=value
    seen[rid]+=1
 assert all(seen[r]==n for r,n in denom.items()) and sum(seen.values())==len(wanted)
 maps={p:{} for p in preds}
 for rid in sorted(denom):
  for i,pred in enumerate(preds):maps[pred][rid]=int(2*counts[rid][i]>=denom[rid])
 for pred,m in maps.items():write(out/f'human_labels_{pred}_v1.json',m)
 with (out/'aggregated_existing_annotation_counts.jsonl').open('x') as f:
  for rid in sorted(denom):f.write(json.dumps({'record_id':rid,'clear_distinct_raters':denom[rid],'positive_counts':dict(zip(preds,counts[rid]))},sort_keys=True)+'\n')
 status={'status':'complete','source_annotation_rows_scanned':rows,'selected_comments':30000,'selected_clear_annotation_rows':sum(seen.values()),'reference_definition':'>=half of fixed clear distinct existingraters; tiespositive; no agreement or value filter','new_human_annotations':0,'new_model_forwards':0,'source_values_first_converted_after_codefreeze':True,'code_freeze_sha256':sha(code/'CODE_FREEZE_BEFORE_TARGETS.json'),'labels':{p:{'file':f'human_labels_{p}_v1.json','sha256':sha(out/f'human_labels_{p}_v1.json'),'positive_count':sum(m.values())} for p,m in maps.items()}}
 write(out/'LABEL_CONVERSION_COMPLETION.json',status);print(json.dumps(status,indent=2))
if __name__=='__main__':main()
