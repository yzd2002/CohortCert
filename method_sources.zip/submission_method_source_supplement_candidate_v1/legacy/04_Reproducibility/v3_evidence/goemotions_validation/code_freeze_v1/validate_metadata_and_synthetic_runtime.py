"""All-contract metadata equivalence and synthetic-label integration only."""
from pathlib import Path
import argparse,json,hashlib,sys
from run_goemotions_grid import manifest_for,get_grid,probe,write,sha
ROOT=Path(__file__).resolve().parent

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();out=a.out.resolve();out.mkdir(parents=True,exist_ok=False)
 import pyarrow.parquet as pq
 ids=pq.read_table(a.root/'metadata_v1/metadata_only_snapshot.parquet',columns=['record_id'])['record_id'].to_pylist();assert len(ids)==len(set(ids))==30000
 fake=out/'synthetic_maps';fake.mkdir()
 for pred in ['anger','joy','sadness','fear']:
  write(fake/f'human_labels_{pred}_v1.json',{rid:hashlib.sha256(('mechanical-synthetic|'+pred+'|'+rid).encode()).digest()[0]%2 for rid in ids})
 m=manifest_for(a.root,fake,1,ROOT)
 # Explicit synthetic source namespace prevents confusing fake tests with
 # actual existing crowd annotations. No source emotion column is opened.
 m['sources']=['synthetic'];m['labels']={'synthetic':m['labels']['human']};m['label_sha256']={'synthetic':m['label_sha256']['human']}
 for shard in m['shards']:shard['source']='synthetic';shard['name']=shard['name'].replace('human__','synthetic__')
 from reference import Reference
 ref=Reference(m);g=get_grid();snapshot=g.core_module(m['core_root'],'query.parquet_snapshot').ParquetSnapshot(m['inputs']['snapshot']['path']);compiler=g.core_module(m['core_root'],'query.compiler')
 metadata={q['query_id']:q for q in m['query_metadata']};checked=0
 for qid,c in ref.compiled.items():
  matrix,family=compiler.compile_signed_decisions(c['query']['contract'],snapshot)
  support={rid for row in matrix.rows for rid,v in row.items() if v};assert support==set(c['structure']['support']);assert len(support)==metadata[qid]['support_size']
  assert [(a.index,a.kind,str(a.threshold),a.row_index,tuple(a.cohort_pair)) for a in family.atoms]==[(a['index'],a['kind'],str(a['threshold']),a['row_index'],tuple(a['cohort_pair'])) for a in c['atoms']]
  # A conjunction is unordered; preserve witness and target order but compare
  # its atom members as sets, as the independent trace auditor already does.
  assert [sorted(w) for w in family.certificates]==[sorted(w) for w in c['certificates']] and list(family.certificate_decisions)==c['targets']
  for signature,members in c['structure']['groups']:
   for j,value in enumerate(signature):assert all(matrix.rows[j].get(rid,0)==value for rid in members)
  checked+=1
 assert checked==528
 write(out/'METADATA_EQUIVALENCE.json',{'status':'passed','all_contracts':checked,'exact_support_coefficients_family_witnesses_and_atom_order':True,'target_annotations_opened':False,'synthetic_label_maps_only':True,'reference_module_sha256':sha(ROOT/'reference.py')})
 rc=probe(m,None,out/'synthetic_runtime','SYNTHETIClabel mechanical integration on actual metadata; no real annotation values or primary outcomes')
 assert rc==0
 write(out/'VALIDATION_COMPLETE.json',{'status':'passed','metadata_contracts_checked':528,'synthetic_runtime_units':10,'target_annotations_numerically_interpreted':False,'new_model_forwards':0,'review_scope':'Root mechanical checks; not independent-agent review or a conference recommendation'})
 print('All528metadata contracts and10synthetic runtime units passed; target annotations unopened')
if __name__=='__main__':main()
