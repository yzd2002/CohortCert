#!/usr/bin/env python3
"""GoEmotions source validation on the unchanged frozen v2 execution loop."""
from pathlib import Path
import argparse,copy,hashlib,itertools,json,sys,threading
from datetime import datetime,timezone
OLD=Path('/root/autodl-tmp/cohortcert_strong_revision_20261102')
GRID=None;ORIGINAL_INIT=None

def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
 return h.hexdigest()
def write(p,o):
 with Path(p).open('x') as f:f.write(json.dumps(o,indent=2,allow_nan=False)+'\n')
def get_grid():
 global GRID,ORIGINAL_INIT
 if GRID is None:
  sys.path.insert(0,str(OLD/'policy_freeze_v1'))
  from executor_v2 import run_grid
  GRID=run_grid;ORIGINAL_INIT=run_grid.worker_initialize
 return GRID

def policy_for(method,seed,manifest):
 if method=='dual_greedy':
  from executor_v2.baseline_policies import DualGreedy
  return DualGreedy(**manifest['dual_greedy'])
 if method=='width':
  from allocation_controls import NormalizedWidthGreedy
  return NormalizedWidthGreedy()
 if method=='neyman':
  from allocation_controls import NormalizedNeyman
  return NormalizedNeyman()
 if method=='max_dg':
  from mechanism_controls import MaxDG
  return MaxDG()
 raise ValueError('Unknown fixed method')

def initialize(m,results,stop):
 g=get_grid();sys.path.insert(0,m['extension_root']);g.policy_for=policy_for;ORIGINAL_INIT(m,results,stop)

def manifest_for(root,label_dir,workers,code_dir=None):
 root=Path(root).resolve();prep=root/'prepared_v1';meta=root/'metadata_v1';code_dir=Path(code_dir or Path(__file__).parent).resolve()
 p=json.loads((prep/'PREPARATION_COMPLETION.json').read_text());assert p['target_values_interpreted'] is False and p['query_count']==528
 m=json.loads((OLD/'grid_human50_v1/run_manifest.json').read_text())
 inp={'protocol':prep/'PREPARATION_COMPLETION.json','queries':prep/'queries_before_annotation_access.jsonl','snapshot':meta/'metadata_only_snapshot.parquet','metadata_cells':prep/'metadata_coefficient_cells.jsonl','features':prep/'data/embeddings/goemotions_emb.npy','feature_index':prep/'data/embeddings/goemotions_index.parquet'}
 qmeta=[json.loads(x) for x in inp['metadata_cells'].read_text().splitlines()]
 m.update(created_utc=datetime.now(timezone.utc).isoformat(),workspace=str(meta),dataset_feature_prefix='goemotions',
  phase='v3_goemotions_crowd_source_validation',
  freeze_note='Different source metadata/templates/features and all policy code internally frozen before emotion-score conversion; v2/v3Civilresults alreadyknown. No external preregistration or new human annotation claim.',
  inputs={k:{'path':str(v),'sha256':sha(v)} for k,v in inp.items()},
  labels={'human':{pred:str(Path(label_dir).resolve()/f'human_labels_{pred}_v1.json') for pred in p['reference_predicates']}},
  seed_records=p['seed_records'],sources=['human'],methods=['dual_greedy','width','neyman','max_dg'],query_metadata=qmeta,worker_count=workers,
  extension_root=str(code_dir/'extensions'),membership_field_prefix='cohort_',population_size=30000,
  predicate_key_by_id={f'goemotions_{pred}_crowd_majority_v1':pred for pred in p['reference_predicates']},
  family_scope={'primary':'All464nonrankingcontracts; everyrequesteddecisionvalueandselectedproofsource-correct','secondary':'All64strictidentificationrankings; no tie/certifiabilityfilter','mechanism':'All128three-decision summaries; SumDGversusMaxDG'})
 m['label_sha256']={'human':{pred:sha(path) for pred,path in m['labels']['human'].items()}}
 m['source_sha256']={k:v for k,v in m['source_sha256'].items() if str(OLD/'policy_freeze_v1') in k or str(Path(m['core_root'])) in k}
 for f in sorted(code_dir.rglob('*.py')):m['source_sha256'][str(f)]=sha(f)
 gate=code_dir/'CODE_FREEZE_BEFORE_TARGETS.json'
 if gate.exists():m['source_sha256'][str(gate)]=sha(gate)
 shards=[]
 for method,seed in itertools.product(m['methods'],m['seed_records']):
  eligible=[q for q in qmeta if method!='max_dg' or q['kind']=='summary'];name=f'human__{method}__seed{seed["seed_id"]:02d}__cap50p0'
  shards.append({'name':name,'source':'human','method':method,'seed_id':seed['seed_id'],'budget_share':50.0,'query_ids':[q['query_id'] for q in eligible],'expected_rows':len(eligible),'order_key':hashlib.sha256(('goemotions-v3-shard-order|'+name).encode()).hexdigest()})
 shards.sort(key=lambda s:s['order_key']);m['shards']=shards;m['counts']={'all_runs':sum(s['expected_rows'] for s in shards),'primary_nonranking_runs':15200,'secondary_ranking_runs':1920}
 assert len(shards)==40 and m['counts']['all_runs']==17120 and len(m['seed_records'])==10
 m['status']='frozen_before_grid_execution'
 return m

def verify_gate(code_dir):
 p=code_dir/'CODE_FREEZE_BEFORE_TARGETS.json';d=json.loads(p.read_text());assert d['status']=='mechanically_checked_before_target_conversion'
 for rel,h in d['source_sha256'].items():
  if sha(code_dir/rel)!=h:raise RuntimeError('Source changed after pretargetfreeze:'+rel)
 for path,h in d['input_sha256'].items():
  if sha(path)!=h:raise RuntimeError('Metadata input changed after pretargetfreeze')
 return d

def freeze(a):
 code=Path(__file__).resolve().parent;verify_gate(code)
 if not 1<=a.workers<=20:raise ValueError('Use1to20workers')
 out=a.out.resolve();out.mkdir(parents=True,exist_ok=False);m=manifest_for(a.root,a.labels,a.workers,code)
 write(out/'run_manifest.json',m);print(json.dumps({'manifest':str(out/'run_manifest.json'),'sha256':sha(out/'run_manifest.json'),'counts':m['counts'],'new_model_forwards':0},indent=2))

def probe(m,path,out,scope):
 g=get_grid();out.mkdir(parents=True,exist_ok=False);shards=[]
 for s in m['shards']:
  if s['seed_id']!=0:continue
  kinds=['summary'] if s['method']=='max_dg' else ['pairwise','summary','ranking']
  ids=[next(q['query_id'] for q in m['query_metadata'] if q['kind']==k) for k in kinds]
  shards.append(dict(s,name='probe__'+s['name'],query_ids=ids,expected_rows=len(ids)))
 m=copy.deepcopy(m);m['shards']=shards;m['counts']['all_runs']=sum(s['expected_rows'] for s in shards);m['probe_scope']=scope
 write(out/'PROBE_MANIFEST.json',m);m['_runtime_manifest_sha256']=sha(out/'PROBE_MANIFEST.json')
 results=out/'results'
 for d in ['shards','progress']:(results/d).mkdir(parents=True,exist_ok=False)
 stop=threading.Event();initialize(m,str(results),stop);reports=[g.run_shard(s) for s in shards]
 result={'status':'passed' if not stop.is_set() and all(not r['failure'] and r['completed']==r['expected'] for r in reports) else 'failed','rows':sum(r['completed'] for r in reports),'new_model_forwards':0,'probe_scope':scope,'shards':reports}
 write(out/'PROBE_REPORT.json',result);print(json.dumps({k:v for k,v in result.items() if k!='shards'},indent=2));return 0 if result['status']=='passed' else 1

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--mode',choices=['freeze','probe','execute'],required=True);p.add_argument('--root',type=Path);p.add_argument('--labels',type=Path);p.add_argument('--out',type=Path);p.add_argument('--manifest',type=Path);p.add_argument('--expect-manifest-sha256');p.add_argument('--workers',type=int,default=16);a=p.parse_args()
 if a.mode=='freeze':freeze(a);return 0
 path=a.manifest.resolve()
 if sha(path)!=a.expect_manifest_sha256:raise RuntimeError('Explicit manifest hash mismatch')
 m=json.loads(path.read_text());verify_gate(Path(__file__).resolve().parent)
 if a.mode=='probe':return probe(m,path,a.out.resolve(),'FrozenGoEmotionsactual-reference mechanicalprobe; not additional primaryunits')
 g=get_grid();g.worker_initialize=initialize;return g.execute_manifest(argparse.Namespace(manifest=path,expect_manifest_sha256=a.expect_manifest_sha256,workers=None))
if __name__=='__main__':raise SystemExit(main())
