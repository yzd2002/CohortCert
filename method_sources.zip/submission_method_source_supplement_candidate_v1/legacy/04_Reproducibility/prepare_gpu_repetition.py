#!/usr/bin/env python3
"""Create a fresh path-bound repetition plan; never run GPU collection."""
from pathlib import Path
import argparse,hashlib,json,shutil,subprocess,sys,shlex
BASE=Path(__file__).resolve().parent;E=BASE/'revision_evidence'
sys.path.insert(0,str(BASE))
from reproduce import relocate,sha

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',type=Path,required=True);p.add_argument('--weights',type=Path,required=True);p.add_argument('--airline-text',type=Path);a=p.parse_args()
 out=a.out.resolve();out.mkdir(parents=True,exist_ok=False)
 old=E/'runtime_revision_v1';code=out/'driver';code.mkdir()
 for f in old.glob('*.py'):shutil.copy2(f,code/f.name)
 shutil.copy2(old/'TOKEN_COSTS.json',code/'TOKEN_COSTS.json')
 raw=(old/'DRAFT_SELECTION.json').read_bytes();s=relocate(json.loads(raw))
 legacy_old='/root/autodl-tmp/cohortcert_revision_20261101/airline_validation';legacy_new=str(BASE/'legacy_context/airline_validation')
 def airline(o):
  if isinstance(o,str):return legacy_new+o[len(legacy_old):] if o==legacy_old or o.startswith(legacy_old+'/') else o
  if isinstance(o,list):return [airline(v) for v in o]
  if isinstance(o,dict):return {k:airline(v) for k,v in o.items()}
  return o
 s=airline(s);s['model_dir']=str(a.weights.resolve());s['blocked_primary_pids']=[]
 if a.airline_text:
  oldtext=s['datasets']['airline']['texts'];newtext=str(a.airline_text.resolve())
  def textpath(o):
   if isinstance(o,str):return newtext if o==oldtext else o
   if isinstance(o,list):return [textpath(v) for v in o]
   if isinstance(o,dict):return {k:textpath(v) for k,v in o.items()}
   return o
  s=textpath(s)
 s['portable_repetition']={'historical_selection_sha256':hashlib.sha256(raw).hexdigest(),'scope':'Path relocation and fresh package/environment binding only; all original six queries, 23 units, order, caps, seeds and policies retained. Outcomes are already known. This is a repetition, not prospective selection.','historical_blocked_pids_removed':True,'new_model_forwards':0}
 sp=out/'REPETITION_SELECTION.json';sp.write_text(json.dumps(s,indent=2)+'\n')
 am=json.loads((old/'RESOURCE_DEADLINE_AMENDMENT.json').read_text());am['selection_sha256']=sha(sp);am['authority']='Fresh repetition using previously declared 10800s resource scope';am['scope']='Same resource limit, queries, order, seeds, policies and failure accounting; paths rebound for a new repetition';am['selection_modified']=True
 (code/'RESOURCE_DEADLINE_AMENDMENT.json').write_text(json.dumps(am,indent=2)+'\n')
 # Freeze validates exact input hashes, original policy bytes and installed packages.
 cmd=[sys.executable,str(code/'run_runtime.py'),'--mode','freeze','--selection',str(sp),'--out',str(out/'freeze')]
 subprocess.run(cmd,check=True)
 mp=out/'freeze/runtime_manifest.json';h=sha(mp)
 run=[sys.executable,str(code/'run_runtime.py'),'--mode','run','--manifest',str(mp),'--expect-manifest-sha256',h,'--results',str(out/'results')]
 audit=[sys.executable,str(code/'run_runtime.py'),'--mode','audit','--manifest',str(mp),'--expect-manifest-sha256',h,'--results',str(out/'results')]
 (out/'RUN_COMMANDS.txt').write_text('These commands launch a NEW GPU repetition only when explicitly executed. They were not executed by preparation. Stop unrelated CPU/GPU work before timing.\n\n'+shlex.join(run)+'\n\n'+shlex.join(audit)+'\n')
 (out/'PREPARATION_RECEIPT.json').write_text(json.dumps({'status':'fresh_repetition_frozen','new_model_forwards':0,'collection_launched':False,'manifest_sha256':h,'historical_selection_sha256':hashlib.sha256(raw).hexdigest()},indent=2)+'\n')
 print('Fresh repetition plan prepared. No GPU collection launched. Commands: '+str(out/'RUN_COMMANDS.txt'))
if __name__=='__main__':main()
