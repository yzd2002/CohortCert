CohortCert 方法源码与固定输入补充候选 v1（独立于两个fast-analysis候选）

本目录补足方法源码可审阅材料，不再只是绘图/汇总脚本。v1/v2 fast-analysis、原研究代码和原包均未修改。没有对外发布、原创许可证选择、source_ready/ActualPermit/新master签发，也没有完整方法/EAB通过声明。

实际内容
- 原始Python源码542份（另有1份只核本归档的verify_sources.py）。旧D的249个源码成员全部按原ARTIFACT_SHA逐字节复制。
- 原P3/P4/P5/P6/P7执行包、Aud9、admin6、C3/C4 composite和环境上下文修正helper共10个声明runtime闭包全部成员已按原SHA复制；P7为39成员，Aud9为22成员。worker/controller/launcher、七方法dispatch、Local-CS内核、Native原创adapter、两SSS rational adapter、独立审计及source admission源码都在mast/source。
- 主Civil/Go CPU replay所需的24个原固定输入已加入：12份保存参考label map、固定query/metadata/cell/protocol文件、两份15,360,128字节的embedding及其index。总49,404,005字节。所有输入同时匹配原run_manifest与旧ARTIFACT_SHA，没有投影、改写或空text替换。
- Civil原冻结metadata快照确有text列，但原独立ef94审查记录30,000行全部为空；本次复制的是该原hash文件，不是新造空文本。Go所需metadata快照的text_character_count为整数、cohort_long_text为bool，没有Reddit正文列。这里只检查parquet footer/schema，未解码表中行值。
- 原A专用LOCKED_LABEL_VECTORS（24,955字节，ffadb...）和唯一原ACTUAL_ENTROPY_RANKS（8,760字节，0d4...）已在外部exactref/hash通过后作opaque字节归档。没有JSON/数组解码、重新抽熵、重签master、替换original或回填四censor；源mtime前后相同。详见ARCHIVED_A_INPUTS_RECEIPT.json。
- 原703,009,005字节旧ZIP仅读中央目录：5,125成员、1,381,913,448未压缩字节。没有复制/解压该大包，没有读取/复制8.59GB raw载荷、巨型sqlite、CFPB/OpinRank大embedding、模型、venv或.git。

阅读入口
METHOD_ENTRYPOINTS.csv：逐方法/控制/审计入口、所需输入与可运行程度。
SOURCE_READABILITY_AND_EXECUTION_STATUS.json：把源码闭包/静态输入完备与未执行状态分开。
MAST_FIXED_PARAMETERS_FROM_CONTRACT.json：原A固定方法、risk/资源/参数原文及source symbol。
ORIGINAL_A_SOURCE_MAP.mmd和ORIGINAL_A_LOCATION_MAP.txt：原A数据、源码、外部依赖和once-permit定位图。
inventory/SOURCE_CODE_INDEX.csv：每份源码的确切来源、路径、字节/SHA；SOURCE_FUNCTIONS_AND_CLI.json给函数和CLI行号；IMPORT_DEPENDENCY_GRAPH和HARD_PATH_AND_PUBLIC_URL_LITERALS给依赖/硬路径，只做AST文本检查，没有import方法。
SOURCE_COPY_RECEIPT和inventory/MAST_RUNTIME_CLOSURES：各原闭包的成员hash完整性。
MAIN_CPU_FROZEN_INPUT_COPY_RECEIPT和inventory/MAIN_CPU_STATIC_LOADER_CLOSURE：主CPU输入以及193项原source pin比较。

主Civil/Go方法的重放范围
legacy/04_Reproducibility保留原相对布局和未改的reproduce.py/reproduce_v3.py。旧portable adapter按三个原绝对前缀重新定位到本目录，并创建新的运行身份；本任务没有调用freeze、smoke、execute、audit、profile或任何方法。
静态核对Civil两份主manifest、control和Go四份manifest全部193项source pin及24份必要冻结输入均存在且同SHA。这支持检查原保存label CPU路线的材料完备性，不是新机器执行通过或无差别历史轨迹重现保证。
供未来明确复现任务参考的原命令（本次未执行；fresh目录/实际打印SHA不可预填）：
  cd legacy/04_Reproducibility
  python3 -B reproduce.py freeze-grid --out /a/fresh/civil_plan
  python3 -B reproduce_v3.py freeze-controls --out /a/fresh/control_plan --workers 1
  python3 -B reproduce_v3.py freeze-go --out /a/fresh/go_plan --workers 1
  python3 -B reproduce_v3.py execute-controls --manifest /control_plan/run_manifest.json --expect-manifest-sha256 ACTUAL_PRINTED_SHA
  python3 -B reproduce_v3.py execute-go --manifest /go_plan/run_manifest.json --expect-manifest-sha256 ACTUAL_PRINTED_SHA
直接运行旧Go code_freeze_v1/run_goemotions_grid.py freeze会保留原pre-target gate，仍要求三份完整provider CSV、text_metadata_snapshot和selected_annotation_ordinals；这些约51MB额外源准备材料未收入薄包，不能声称该直接source-preparation入口已自足。保留的原portable freeze-go/execute-go使用已冻结/已转换label与manifest，不进行新annotation转换；原guard没有被本任务改写。
原reproduce.py/reproduce_v3.py verify面向完整旧5092成员，薄包没有假造替代该清单。这里只使用本目录verify_sources.py核归档。

MAST方法可读与实际运行边界
七方法在P7/method_dispatch.py中逐项固定；P7/core.py、native_routes.py、sss_routes.py、sss_common_loggreedy.py、uits.py为实际可审源码。P3..P7来源链来自原LAUNCH_REFS，保留前序版本，不把所有56路径都说成P7新执行。
原private_loader首先要求process-bound ActualPermit，随后严格检查DATA_CONTRACT、Data manifest、labels和RECORD_IDENTITIES。A身份文件117,283字节、SHA f65bcf90d2fef0c0826acf6a16b3d23014d827a5f5d1d3c43e464c2ab8f1bd05本轮没有获准复制，只有原定位/pin。
原Native路线还要求外部Evergreen-vendored源和固定环境；14762文件的既有allowlist metadata被原样保存，但本次没有hash其环境文件、安装依赖、重新import Native或运行CI。外部实现.py一份未复制；原创adapter完整保留，精确repo/commit/源hash与获取说明见EXTERNAL_SOURCE_FETCH_INSTRUCTIONS.txt。
worker/controller和Aud9的Root sibling路径、authority refs、代码hash、claim/全局锁、资源计时、原wall anchor/deadline、一次性slot身份和late AuditPermit都保留，不因源码拷贝产生新权限。原P7 deadline为1793926010943372110（2026-11-06 00:46:50.943372 UTC）；这里不重置/延长，不擅称当前是否过期。
原producer中artificial/production_ready=False等历史字面量与外层authoritative_request_scope的分工照原保留，未改成新的production/actual Ready。闭合A已准入50 COMPLETE/2 ERROR/4 UNKNOWN；本材料没有再次运行方法或再授原full scientific admission，四censor仍不可填补。

只执行本归档完整性核对
  nice -n 10 python3 -B verify_sources.py
它只读取本目录MANIFEST并hash本目录已复制文件；不跟随任何原private路径，不解码A label/rank或旧label/embedding，不import方法、不执行profile。AST语法/依赖名检查同样不是方法测试。
Linux/Python3.11为源码检查/原CPU说明环境；完整Native环境、跨机clean-room、Windows/macOS均未重建验证。

完整旧包与raw的关系
LEGACY_FULL_ARCHIVE_AND_RAW_REQUIREMENTS.txt与MISSING_SOURCE_REBUILD_INPUTS.csv逐项说明（含官方source URL/原hash/大小）：主Civil/Go保存label CPU材料已加入，但CFPB/OpinRank较早研究、重新构造Go源准备、完整old verify/部分lower-level诊断仍需原legacy703MB包；历史raw-proof审计另需其兄弟07_Raw_Trace_Archives约8.59GB。703MB是legacy补充，既不是当前唯一full artifact，也不含完整raw。Root若在外层附该已存在文件，须同时保留版本/来源/许可说明；本任务没有搬运它。
所有论文/数据/上游许可gaps见LICENSE_NOTICES.txt，原创软件统一license仍未定。此候选是实质源码/固定输入材料，不是EABcomplete、方法重跑成功、当前论文submission READY或公共发布许可。
