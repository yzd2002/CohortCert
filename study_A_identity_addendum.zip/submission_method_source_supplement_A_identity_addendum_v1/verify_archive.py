"""Hash only the local opaque archive addendum; never import a method."""
from pathlib import Path
from hashlib import sha256
import json
import os

ROOT = Path(__file__).resolve().parent


def main():
    if hasattr(os, "getpriority") and os.getpriority(os.PRIO_PROCESS, 0) < 10:
        os.nice(10 - os.getpriority(os.PRIO_PROCESS, 0))
    manifest = json.loads((ROOT / "MANIFEST.json").read_text())
    declared = {"MANIFEST.json"}
    for item in manifest["files"]:
        relative = Path(item["path"])
        if relative.is_absolute() or ".." in relative.parts:
            raise ValueError("relative archive path required")
        p = ROOT / relative
        if p.is_symlink() or not p.resolve().is_relative_to(ROOT) or not p.is_file():
            raise ValueError("bounded regular member required")
        raw = p.read_bytes()
        if len(raw) != item["bytes"] or sha256(raw).hexdigest() != item["sha256"]:
            raise ValueError("archive hash/size mismatch")
        declared.add(item["path"])
    actual = {str(p.relative_to(ROOT)) for p in ROOT.rglob("*") if p.is_file()}
    if actual != declared:
        raise ValueError("archive member set differs")
    print(json.dumps({"status": "PASS_OPAQUE_A_IDENTITY_ARCHIVE_INTEGRITY_ONLY",
                      "verified_members": len(manifest["files"]),
                      "payload_decode_or_method_CI_Native_RNG_calls": 0,
                      "new_actual_permission_or_EAB_ready": False}))


if __name__ == "__main__":
    main()
